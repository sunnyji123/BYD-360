import React, { useState, useEffect, useCallback } from 'react';
import {
  Building2,
  Shield,
  Lock,
  KeyRound,
  Mail,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  LogOut,
  RefreshCw,
  Users,
  GitBranch,
  Store,
  Car,
  UserCheck,
  DollarSign,
  FileSpreadsheet,
  Sparkles,
  Plus,
  Check,
  XCircle,
  ArrowRightLeft,
  Monitor,
  History,
  Trash2,
  Send,
  Printer,
  Download,
  Calendar,
  FileText,
  ShieldAlert,
  Clock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { TeamInvitePanel } from '../admin/TeamInvitePanel';
import { AdminDealerGovernancePanel } from '../dealer/AdminDealerGovernancePanel';
import { AdminCustomerGovernancePanel } from '../customer/AdminCustomerGovernancePanel';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { AdminVerificationApprovalPanel } from '../admin/AdminVerificationApprovalPanel';
import { EmployeeManagementHub } from '../employee/EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type CompanyAdminTab =
  | 'overview'
  | 'company'
  | 'employees'
  | 'employee-hub'
  | 'branches'
  | 'dealerships'
  | 'dealership-hub'
  | 'vehicles'
  | 'customers'
  | 'sales'
  | 'reports'
  | 'security';

type AuthStep = 'login' | 'verify-email' | '2fa' | 'forgot-password';

const VEHICLE_MODELS = [
  'BYD Seal Performance AWD',
  'BYD Atto 3 Extended Range',
  'BYD Dolphin Dynamic',
  'BYD Sealion 6 DM-i',
  'BYD Tang EV Flagship',
];

export const CompanyDashboard: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, formatPrice, setActiveTab } = useApp();
  const isCompanyAdmin = isAuthenticated && currentUser.subjectType === 'company_admin';

  // Portal status & auth flow state
  const [statusLoading, setStatusLoading] = useState(true);
  const [portalStatus, setPortalStatus] = useState<{
    hasCompanyAdmins: boolean;
    approvedCompaniesCount: number;
    twoFactorRequired: boolean;
    emailVerificationRequired: boolean;
    portalIsolated: boolean;
  } | null>(null);

  const [authStep, setAuthStep] = useState<AuthStep>('login');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // Login inputs (never hardcode passwords in frontend source)
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Email OTP Verification
  const [pendingEmail, setPendingEmail] = useState('');
  const [emailOtpCode, setEmailOtpCode] = useState('');
  const [devEmailOtpHint, setDevEmailOtpHint] = useState<string | null>(null);

  // Mandatory 2FA Challenge
  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [devLoginOtpHint, setDevLoginOtpHint] = useState<string | null>(null);
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);
  const [pendingCompanyName, setPendingCompanyName] = useState('');

  // Forgot / Reset Password
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetStage, setResetStage] = useState<'request' | 'confirm'>('request');
  const [resetToken, setResetToken] = useState('');
  const [resetOtpCode, setResetOtpCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [devResetHint, setDevResetHint] = useState<{ resetToken?: string; otpCode?: string } | null>(null);

  // Authenticated Dashboard State
  const [caTab, setCaTab] = useState<CompanyAdminTab>('overview');
  const [banner, setBanner] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [loadingDash, setLoadingDash] = useState(false);

  // Tab datasets
  const [dashboard, setDashboard] = useState<any>(null);
  const [aiBriefing, setAiBriefing] = useState<string | null>(null);
  const [aiBriefingLoading, setAiBriefingLoading] = useState(false);

  // Company profile tab state
  const [companyData, setCompanyData] = useState<any>(null);
  const [compEdit, setCompEdit] = useState({
    name: '',
    logoUrl: '',
    phone: '',
    city: '',
    address: '',
    website: '',
    taxId: '',
    authorizedRep: '',
    registrationDetails: '',
    departmentsText: '',
    sector: '',
    establishedYear: '',
  });
  const [docForm, setDocForm] = useState({ title: '', category: 'Corporate', refNo: '' });

  // Employees tab state
  const [empPayload, setEmpPayload] = useState<any>(null);
  const [newEmp, setNewEmp] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    password: '',
    jobPosition: 'Sales Executive',
    department: 'Sales',
    branchId: '',
    city: 'Karachi',
    employeeCode: '',
  });
  const [selectedEmp, setSelectedEmp] = useState<any>(null);
  const [attForm, setAttForm] = useState({ status: 'Present', checkIn: '09:00', checkOut: '18:00' });
  const [leaveForm, setLeaveForm] = useState({ type: 'Annual', startDate: '', endDate: '', reason: '' });
  const [perfForm, setPerfForm] = useState({ score: 90, notes: '' });

  // Branches tab state
  const [branchPayload, setBranchPayload] = useState<any>(null);
  const [newBranch, setNewBranch] = useState({
    name: '',
    code: '',
    city: 'Karachi',
    address: '',
    phone: '+92 ',
    managerUserId: '',
  });
  const [branchReport, setBranchReport] = useState<any>(null);

  // Dealerships tab state
  const [dealers, setDealers] = useState<any[]>([]);
  const [newDealer, setNewDealer] = useState({
    name: '',
    city: 'Karachi',
    address: '',
    phone: '+92 ',
    email: '',
    managerName: '',
    chargingBays: 4,
    serviceBays: 6,
  });
  const [dealerMsgTarget, setDealerMsgTarget] = useState<any>(null);
  const [dealerMsgForm, setDealerMsgForm] = useState({ subject: '', message: '' });

  // Vehicles tab state
  const [vehiclesData, setVehiclesData] = useState<any>(null);
  const [newVeh, setNewVeh] = useState({
    model: VEHICLE_MODELS[0],
    variant: 'Standard',
    color: 'Arctic White',
    vin: '',
    branchId: '',
    dealershipId: '',
    pricePkr: 15990000,
    batteryCapacityKwh: 82.5,
    rangeKm: 520,
    deliveryStatus: 'In Stock',
  });
  const [transferTarget, setTransferTarget] = useState<{ vehicleId: string; targetBranchId: string; deliveryStatus: string } | null>(null);

  // Customers & CRM tab state
  const [customersData, setCustomersData] = useState<any>(null);
  const [cnicRevealed, setCnicRevealed] = useState(false);
  const [newCust, setNewCust] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    city: 'Karachi',
    cnicOrId: '',
    password: '',
  });
  const [newCrm, setNewCrm] = useState({
    customerId: '',
    recordType: 'Enquiry',
    subject: '',
    details: '',
    priority: 'Medium',
    followUpDate: '',
  });

  // Sales & Finance tab state
  const [salesFinance, setSalesFinance] = useState<any>(null);
  const [invForm, setInvForm] = useState({
    customerId: '',
    vehicleId: '',
    branchId: '',
    amountPkr: 15990000,
    taxRate: 0.05,
    paymentGateway: 'HBL Corporate Transfer',
    status: 'Paid',
  });
  const [refundTarget, setRefundTarget] = useState<{ id: string; invoiceNumber: string; reason: string } | null>(null);

  // Reports tab state
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'monthly' | 'yearly'>('monthly');
  const [reportData, setReportData] = useState<any>(null);
  const [exporting, setExporting] = useState(false);

  // Security & Sessions tab state
  const [auditData, setAuditData] = useState<any>(null);
  const [caSessions, setCaSessions] = useState<any[]>([]);
  const [caLoginHistory, setCaLoginHistory] = useState<any[]>([]);

  const notify = (text: string, type: 'ok' | 'err' = 'ok') => {
    setBanner({ text, type });
    setTimeout(() => setBanner(null), 5000);
  };

  const hasPerm = (perm: string) => {
    const perms = currentUser?.permissions || [];
    return perms.includes(perm);
  };

  const loadPortalStatus = useCallback(async () => {
    setStatusLoading(true);
    try {
      const st = await api.getCompanyAdminStatus();
      setPortalStatus(st);
    } catch (err: any) {
      setAuthError(err.message || 'Unable to verify Company Admin portal status.');
    } finally {
      setStatusLoading(false);
    }
  }, []);

  const loadOverview = useCallback(async () => {
    if (!isCompanyAdmin) return;
    setLoadingDash(true);
    try {
      const d = await api.getCompanyAdminDashboard();
      setDashboard(d);
    } catch (err: any) {
      notify(err.message || 'Failed to load company overview.', 'err');
    } finally {
      setLoadingDash(false);
    }
  }, [isCompanyAdmin]);

  const loadTabData = useCallback(
    async (tab: CompanyAdminTab) => {
      if (!isCompanyAdmin) return;
      try {
        if (tab === 'overview') {
          await loadOverview();
        } else if (tab === 'company') {
          const res = await api.getCompanyAdminCompany();
          setCompanyData(res);
          const c = res.company || {};
          setCompEdit({
            name: c.name || '',
            logoUrl: c.logo_url || '',
            phone: c.phone || '',
            city: c.city || '',
            address: c.address || '',
            website: c.website || '',
            taxId: c.tax_id || '',
            authorizedRep: c.authorized_rep || '',
            registrationDetails: c.registration_details || '',
            departmentsText: (c.departments || []).join(', '),
            sector: c.businessInfo?.sector || 'Electric Mobility & Dealership Operations',
            establishedYear: String(c.businessInfo?.establishedYear || '2024'),
          });
        } else if (tab === 'employees') {
          const res = await api.getCompanyAdminEmployees();
          setEmpPayload(res);
          if (!newEmp.branchId && res.branches?.length) {
            setNewEmp((p) => ({ ...p, branchId: res.branches[0].id }));
          }
          if (selectedEmp) {
            const refreshed = (res.employees || []).find((e: any) => e.id === selectedEmp.id);
            if (refreshed) setSelectedEmp(refreshed);
          }
        } else if (tab === 'branches') {
          const res = await api.getCompanyAdminBranches();
          setBranchPayload(res);
        } else if (tab === 'dealerships') {
          const res = await api.getCompanyAdminDealerships();
          setDealers(res.dealerships || []);
        } else if (tab === 'vehicles') {
          const res = await api.getCompanyAdminVehicles();
          setVehiclesData(res);
          if (!newVeh.branchId && res.branches?.length) {
            setNewVeh((p) => ({ ...p, branchId: res.branches[0].id }));
          }
        } else if (tab === 'customers') {
          const res = await api.getCompanyAdminCustomers(cnicRevealed);
          setCustomersData(res);
        } else if (tab === 'sales') {
          const [sf, cust, veh, br] = await Promise.all([
            api.getCompanyAdminSalesFinance(),
            api.getCompanyAdminCustomers(false),
            api.getCompanyAdminVehicles(),
            api.getCompanyAdminBranches(),
          ]);
          setSalesFinance(sf);
          setCustomersData(cust);
          setVehiclesData(veh);
          setBranchPayload(br);
          setInvForm((p) => ({
            ...p,
            customerId: p.customerId || cust.customers?.[0]?.id || '',
            vehicleId: p.vehicleId || veh.vehicles?.[0]?.id || '',
            branchId: p.branchId || br.branches?.[0]?.id || '',
          }));
        } else if (tab === 'reports') {
          const res = await api.getCompanyAdminReports(reportPeriod);
          setReportData(res);
        } else if (tab === 'security') {
          const [aud, sess, hist] = await Promise.all([
            api.getCompanyAdminAuditLogs(),
            api.getCompanyAdminSessions(),
            api.getCompanyAdminLoginHistory(),
          ]);
          setAuditData(aud);
          setCaSessions(sess.sessions || []);
          setCaLoginHistory(hist.history || []);
        }
      } catch (err: any) {
        notify(err.message || `Access failed on ${tab} module.`, 'err');
      }
    },
    [isCompanyAdmin, loadOverview, cnicRevealed, reportPeriod, selectedEmp, newEmp.branchId, newVeh.branchId]
  );

  useEffect(() => {
    loadPortalStatus();
  }, [loadPortalStatus]);

  useEffect(() => {
    if (isCompanyAdmin) {
      loadTabData(caTab);
    }
  }, [isCompanyAdmin, caTab, loadTabData]);

  // ----------------- AUTH HANDLERS -----------------
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.companyAdminLogin({ identifier: identifier.trim(), password });
      if (res.requiresEmailVerification) {
        setPendingEmail(res.email);
        setDevEmailOtpHint(res.verificationOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('verify-email');
      } else if (res.requires2FA && res.challengeToken) {
        setPendingEmail(res.email);
        setPendingCompanyName(res.companyName || '');
        setChallengeToken(res.challengeToken);
        setSuspiciousAlert(Boolean(res.suspiciousIpDetected));
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('2fa');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Company Admin authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerifyEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.companyAdminVerifyEmail({ email: pendingEmail, code: emailOtpCode.trim() });
      setEmailOtpCode('');
      if (res.pendingCompanyApproval) {
        setAuthSuccess(res.message);
        setAuthStep('login');
      } else if (res.requires2FA && res.challengeToken) {
        setPendingCompanyName(res.companyName || '');
        setChallengeToken(res.challengeToken);
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('2fa');
      } else {
        setAuthSuccess(res.message);
        setAuthStep('login');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Email OTP verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerify2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.companyAdminVerify2FA({ challengeToken, code: twoFactorCode.trim() });
      setPassword('');
      setTwoFactorCode('');
      setChallengeToken('');
      loginUser(res.user);
    } catch (err: any) {
      setAuthError(err.message || 'Invalid 2FA verification code.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.companyAdminForgotPassword(forgotEmail.trim());
      setAuthSuccess(res.message);
      if (res.resetOutbox) {
        setDevResetHint({ resetToken: res.resetOutbox.resetToken, otpCode: res.resetOutbox.otpCode });
        setResetToken(res.resetOutbox.resetToken);
      }
      setResetStage('confirm');
    } catch (err: any) {
      setAuthError(err.message || 'Password reset request failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleResetConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.companyAdminResetPassword({
        token: resetToken.trim() || undefined,
        email: forgotEmail.trim() || undefined,
        otpCode: resetOtpCode.trim() || undefined,
        newPassword: resetNewPassword,
      });
      setAuthSuccess(res.message);
      setResetNewPassword('');
      setResetOtpCode('');
      setResetStage('request');
      setAuthStep('login');
    } catch (err: any) {
      setAuthError(err.message || 'Password reset failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  // ----------------- GATEWAY CHECKS (NON-COMPANY-ADMIN) -----------------
  if (!isCompanyAdmin) {
    if (isAuthenticated) {
      return (
        <div className="max-w-3xl mx-auto px-4 py-12">
          <div className="rounded-3xl bg-slate-900 border border-rose-500/40 p-8 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-950/60 border border-rose-500/40 flex items-center justify-center">
              <ShieldAlert className="w-7 h-7 text-rose-400" />
            </div>
            <h2 className="text-xl font-extrabold text-white">Isolated Company Admin Portal</h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl mx-auto">
              You are currently authenticated as <strong className="text-white">{currentUser.name}</strong> ({currentUser.role}).
              Company Admin accounts are strictly separated from Founder, Super Admin, Employee, Dealer, and Customer accounts.
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('landing')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold"
              >
                Return to Global Fleet
              </button>
              <button
                type="button"
                onClick={logoutUser}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xs font-bold flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out to Authenticate as Company Admin</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-2xl mx-auto px-4 py-10 space-y-6">
        <div className="rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/50 p-6 border-b border-slate-800">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-400">
                    Isolated Tenant Governance • Mandatory 2FA
                  </span>
                  <h1 className="text-xl font-black text-white">Company Admin Login Portal</h1>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                {statusLoading ? 'Checking...' : `${portalStatus?.approvedCompaniesCount ?? 0} Active Companies`}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-3">
              Dedicated server-enforced authentication for authorized Company Administrators. Strictly isolated from Founder, Super Admin, Employee, Dealer, and Customer accounts.
            </p>
          </div>

          <div className="p-6 space-y-5">
            {authError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{authError}</span>
              </div>
            )}
            {authSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{authSuccess}</span>
              </div>
            )}

            {authStep === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Company Admin Email, Mobile, or Username
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="admin@company.com"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-300">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthError('');
                        setAuthSuccess('');
                        setAuthStep('forgot-password');
                      }}
                      className="text-xs text-cyan-400 hover:text-cyan-300"
                    >
                      Forgot / Reset Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your Company Admin password"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={authSubmitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-cyan-600/20 disabled:opacity-50"
                >
                  {authSubmitting ? 'Verifying Credentials...' : 'Verify Credentials & Continue to 2FA'}
                </button>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Authorized Demo Company Admin Identifiers (Password &amp; 2FA Enforced on Server)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { company: 'BYD Mega Motor Pakistan', email: 'sarmad.khawaja@megamotor.demo' },
                      { company: 'BYD Al-Futtaim Mobility UAE', email: 'rashid.nuaimi@byduae.demo' },
                    ].map((acct) => (
                      <button
                        key={acct.email}
                        type="button"
                        onClick={() => setIdentifier(acct.email)}
                        className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left text-[11px]"
                      >
                        <div className="font-bold text-cyan-300">{acct.company}</div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">{acct.email}</div>
                      </button>
                    ))}
                  </div>
                </div>
              </form>
            )}

            {authStep === 'verify-email' && (
              <form onSubmit={handleVerifyEmailSubmit} className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 text-xs space-y-1">
                  <div className="font-bold text-cyan-300">Mandatory Email OTP Verification</div>
                  <p className="text-slate-300">
                    Enter the 6-digit verification OTP issued to <strong>{pendingEmail}</strong>.
                  </p>
                  {devEmailOtpHint && (
                    <p className="font-mono text-amber-300 pt-1">
                      Simulated Mailer Outbox OTP: <strong>{devEmailOtpHint}</strong>
                    </p>
                  )}
                </div>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={emailOtpCode}
                  onChange={(e) => setEmailOtpCode(e.target.value)}
                  placeholder="6-digit Email OTP"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setAuthStep('login')}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                  >
                    {authSubmitting ? 'Verifying OTP...' : 'Verify Email & Proceed'}
                  </button>
                </div>
              </form>
            )}

            {authStep === '2fa' && (
              <form onSubmit={handleVerify2FASubmit} className="space-y-4">
                {suspiciousAlert && (
                  <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 text-xs text-amber-200 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>New IP or device detected for your Company Admin account. Complete 2FA to log this session.</span>
                  </div>
                )}
                <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 text-xs space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4 text-cyan-400" />
                    <span>2FA Challenge — {pendingCompanyName || pendingEmail}</span>
                  </div>
                  <p className="text-slate-400">
                    Enter your 6-digit Authenticator TOTP code, your 6-digit single-use login OTP, or a 10-character backup recovery code.
                  </p>
                  {devLoginOtpHint && (
                    <p className="font-mono text-amber-300 pt-1">
                      Simulated Mailer Login 2FA OTP: <strong>{devLoginOtpHint}</strong>
                    </p>
                  )}
                </div>
                <input
                  type="text"
                  required
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value)}
                  placeholder="6-digit OTP / TOTP or Recovery Code"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthStep('login');
                      setChallengeToken('');
                    }}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xs font-bold"
                  >
                    {authSubmitting ? 'Verifying 2FA...' : 'Complete Sign In'}
                  </button>
                </div>
              </form>
            )}

            {authStep === 'forgot-password' && (
              resetStage === 'request' ? (
                <form onSubmit={handleForgotSubmit} className="space-y-4 text-xs">
                  <p className="text-slate-300">
                    Enter your authorized Company Admin email to receive a reset token and 6-digit OTP. Confirming reset revokes all active Company Admin sessions.
                  </p>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="Company Admin Email"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                    >
                      {authSubmitting ? 'Requesting...' : 'Send Reset Token & OTP'}
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleResetConfirm} className="space-y-3 text-xs">
                  {devResetHint && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 font-mono space-y-1 break-all">
                      <div>Reset Token: {devResetHint.resetToken}</div>
                      <div>Reset OTP: {devResetHint.otpCode}</div>
                    </div>
                  )}
                  <input
                    type="text"
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder="Reset Token (or leave empty if using OTP)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                  />
                  <input
                    type="text"
                    value={resetOtpCode}
                    onChange={(e) => setResetOtpCode(e.target.value)}
                    placeholder="6-digit Reset OTP"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                  />
                  <input
                    type="password"
                    required
                    value={resetNewPassword}
                    onChange={(e) => setResetNewPassword(e.target.value)}
                    placeholder="New Strong Password (10+ chars, Upper/Lower/Digit/Symbol)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                    >
                      {authSubmitting ? 'Resetting...' : 'Reset Password & Revoke Sessions'}
                    </button>
                  </div>
                </form>
              )
            )}
          </div>
        </div>
      </div>
    );
  }

  // ----------------- HANDLERS FOR AUTHENTICATED COMPANY ADMIN -----------------
  const m = dashboard?.metrics || {};
  const compProfile = dashboard?.companyProfile || companyData?.company || {};

  const handleGenerateBriefing = async () => {
    setAiBriefingLoading(true);
    try {
      const res = await api.getExecutiveSummary(
        {
          company: compProfile.name,
          branches: m.totalBranches || 0,
          employees: m.totalEmployees || 0,
          dealerships: m.totalDealerships || 0,
          customers: m.totalCustomers || 0,
          vehicles: m.totalVehicles || 0,
          availableStock: m.availableStock || 0,
          bookings: m.totalBookings || 0,
          sales: m.totalSales || 0,
          revenuePkr: m.companyRevenuePkr || 0,
        },
        `${compProfile.country || 'PK'} Live SQLite Telemetry`
      );
      setAiBriefing(res.summary);
    } catch (err: any) {
      notify(err.message || 'BYD AI executive briefing unavailable.', 'err');
    } finally {
      setAiBriefingLoading(false);
    }
  };

  const handleSaveCompanyProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const departments = compEdit.departmentsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      await api.updateCompanyAdminCompany({
        name: compEdit.name,
        logoUrl: compEdit.logoUrl,
        phone: compEdit.phone,
        city: compEdit.city,
        address: compEdit.address,
        website: compEdit.website,
        taxId: compEdit.taxId,
        authorizedRep: compEdit.authorizedRep,
        registrationDetails: compEdit.registrationDetails,
        departments,
        documents: companyData?.company?.documents || [],
        businessInfo: {
          ...(companyData?.company?.businessInfo || {}),
          sector: compEdit.sector,
          establishedYear: compEdit.establishedYear,
        },
      });
      notify('Company profile, departments & business info saved.');
      await loadTabData('company');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleAddCompanyDoc = async () => {
    if (!docForm.title.trim()) return;
    const docs = [...(companyData?.company?.documents || [])];
    docs.push({
      id: `doc_${Date.now()}`,
      title: docForm.title.trim(),
      category: docForm.category,
      refNo: docForm.refNo.trim() || `REF-${Math.floor(1000 + Math.random() * 9000)}`,
      verified: true,
      uploadedAt: new Date().toISOString().slice(0, 10),
    });
    try {
      await api.updateCompanyAdminCompany({ documents: docs });
      setDocForm({ title: '', category: 'Corporate', refNo: '' });
      notify('Company document record added.');
      await loadTabData('company');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createCompanyAdminEmployee(newEmp);
      notify(`Employee ${res.employeeCode} created.`);
      setNewEmp({
        fullName: '',
        email: '',
        mobile: '+92 300 ',
        password: '',
        jobPosition: 'Sales Executive',
        department: 'Sales',
        branchId: empPayload?.branches?.[0]?.id || '',
        city: compProfile.city || 'Karachi',
        employeeCode: '',
      });
      await loadTabData('employees');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleDownloadExport = async (format: 'xlsx' | 'csv') => {
    setExporting(true);
    try {
      const blob = await api.exportCompanyAdminReportBlob(format, reportPeriod);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `byd360-company-report-${reportPeriod}-${new Date().toISOString().slice(0, 10)}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
      notify(`Exported ${format.toUpperCase()} report for ${reportPeriod} period.`);
    } catch (err: any) {
      notify(err.message, 'err');
    } finally {
      setExporting(false);
    }
  };

  const navTabs: { id: CompanyAdminTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'overview', label: 'Overview', icon: Building2 },
    { id: 'company', label: 'Company', icon: FileText },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'employee-hub', label: 'Employee Management', icon: UserCheck },
    { id: 'branches', label: 'Branches', icon: GitBranch },
    { id: 'dealerships', label: 'Dealers', icon: Store },
    { id: 'dealership-hub', label: 'Dealership Hub', icon: Store },
    { id: 'vehicles', label: 'Vehicles', icon: Car },
    { id: 'customers', label: 'Customers & CRM', icon: UserCheck },
    { id: 'sales', label: 'Sales & Finance', icon: DollarSign },
    { id: 'reports', label: 'Reports & Export', icon: FileSpreadsheet },
    { id: 'security', label: 'Sessions & Logs', icon: Shield },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/60 border border-cyan-500/30 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              Company Admin Workspace
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
              Tenant Isolated: {compProfile.id || currentUser.companyId}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Building2 className="w-6 h-6 text-cyan-400" />
            <span>{compProfile.name || 'Company Administration Portal'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            Signed in as <strong className="text-slate-200">{currentUser.name}</strong> ({currentUser.designation || currentUser.role}) • {currentUser.email}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleGenerateBriefing}
            disabled={aiBriefingLoading}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>{aiBriefingLoading ? 'Analyzing...' : 'BYD AI Briefing'}</span>
          </button>
          <button
            type="button"
            onClick={() => loadTabData(caTab)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDash ? 'animate-spin' : ''}`} />
            <span>Refresh DB</span>
          </button>
          <button
            type="button"
            onClick={logoutUser}
            className="px-3 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-bold flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Secure Logout</span>
          </button>
        </div>
      </div>

      {banner && (
        <div
          className={`p-3.5 rounded-2xl border text-xs font-semibold flex items-center gap-2 ${
            banner.type === 'ok'
              ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
          }`}
        >
          {banner.type === 'ok' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
          <span>{banner.text}</span>
        </div>
      )}

      {aiBriefing && (
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> BYD AI Executive Briefing
            </span>
            <button onClick={() => setAiBriefing(null)} className="text-xs text-slate-400 hover:text-white">
              Dismiss
            </button>
          </div>
          <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-line leading-relaxed">{aiBriefing}</p>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 pb-1">
        {navTabs.map((t) => {
          const Icon = t.icon;
          const active = caTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setCaTab(t.id)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                active
                  ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: COMPANY OVERVIEW */}
      {caTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {[
              { label: 'Total Branches', value: m.totalBranches ?? 0, sub: 'Active Locations', color: 'text-cyan-400' },
              { label: 'Total Employees', value: m.totalEmployees ?? 0, sub: 'Company Staff', color: 'text-blue-400' },
              { label: 'Total Dealerships', value: m.totalDealerships ?? 0, sub: `${m.pendingDealers ?? 0} Pending`, color: 'text-indigo-400' },
              { label: 'Total Customers', value: m.totalCustomers ?? 0, sub: `${m.openCrm ?? 0} Open CRM`, color: 'text-emerald-400' },
              { label: 'Total Vehicles', value: m.totalVehicles ?? 0, sub: `${m.availableVehicleStock ?? 0} Available Stock`, color: 'text-sky-400' },
              { label: 'Available Stock', value: m.availableVehicleStock ?? 0, sub: 'Ready for Allocation', color: 'text-teal-400' },
              { label: 'Total Bookings', value: m.totalBookings ?? 0, sub: `${m.pendingBookings ?? 0} Pending`, color: 'text-amber-400' },
              { label: 'Total Sales', value: m.totalSales ?? 0, sub: 'Delivered / Paid', color: 'text-emerald-300' },
              { label: 'Company Revenue', value: formatPrice(m.companyRevenue || 0), sub: 'Collected Paid Invoices', color: 'text-emerald-400' },
              { label: 'Pending Tasks', value: m.pendingTasks ?? 0, sub: 'Approvals, Leaves & CRM', color: 'text-rose-400' },
            ].map((kpi) => (
              <div key={kpi.label} className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] font-semibold text-slate-400">{kpi.label}</div>
                <div className={`text-xl font-black mt-1 ${kpi.color}`}>{kpi.value}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{kpi.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Company Profile Snapshot & Branch Performance */}
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white">Company Profile &amp; Branch Overview</h3>
                <button
                  type="button"
                  onClick={() => setCaTab('company')}
                  className="text-xs text-cyan-400 hover:underline font-semibold"
                >
                  Manage Profile &rarr;
                </button>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                <div className="font-bold text-white">{compProfile.name}</div>
                <div className="text-slate-400">
                  HQ: {compProfile.address} ({compProfile.city}, {compProfile.country})
                </div>
                <div className="text-slate-400 font-mono">
                  Reg: {compProfile.registration_details} • Tax: {compProfile.tax_id || 'On File'}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-300">Branch Operations Summary</div>
                {(dashboard?.branchPerformance || []).map((b: any) => (
                  <div key={b.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">{b.name}</div>
                      <div className="text-[11px] text-slate-400">
                        {b.city} • Code: <span className="font-mono">{b.code}</span>
                      </div>
                    </div>
                    <div className="text-right text-[11px]">
                      <div className="text-cyan-300 font-semibold">{b.staff_count ?? 0} Staff • {b.vehicle_count ?? 0} Vehicles</div>
                      <div className="text-emerald-400 font-mono">{formatPrice(b.monthly_revenue_pkr || 0)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notifications & Recent Company Activities */}
            <div className="space-y-6">
              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">
                  Company Notifications ({dashboard?.notifications?.length || 0})
                </h3>
                <div className="space-y-2 max-h-44 overflow-y-auto">
                  {(dashboard?.notifications || []).map((n: any) => (
                    <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-cyan-300">{n.title}</span>
                        <span className="text-[10px] text-slate-500">{n.category}</span>
                      </div>
                      <p className="text-slate-300 mt-1">{n.message}</p>
                    </div>
                  ))}
                  {(!dashboard?.notifications || dashboard.notifications.length === 0) && (
                    <p className="text-xs text-slate-500">No recent company notifications.</p>
                  )}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Recent Company Activities</h3>
                <div className="space-y-2 max-h-52 overflow-y-auto">
                  {(dashboard?.recentActivities || []).map((act: any) => (
                    <div key={act.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs gap-2">
                      <div>
                        <span className="font-mono text-amber-300 font-semibold">{act.action}</span>
                        <span className="text-slate-400"> by {act.actor_name}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono shrink-0">
                        {act.created_at?.slice(0, 19).replace('T', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: COMPANY PROFILE, DOCUMENTS, DEPARTMENTS */}
      {caTab === 'company' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleSaveCompanyProfile} className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white">Company Profile &amp; Business Configuration</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Company Legal Name</label>
                <input
                  type="text"
                  required
                  value={compEdit.name}
                  onChange={(e) => setCompEdit({ ...compEdit, name: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Authorized Representative</label>
                <input
                  type="text"
                  required
                  value={compEdit.authorizedRep}
                  onChange={(e) => setCompEdit({ ...compEdit, authorizedRep: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Phone</label>
                <input
                  type="text"
                  value={compEdit.phone}
                  onChange={(e) => setCompEdit({ ...compEdit, phone: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">HQ City</label>
                <input
                  type="text"
                  value={compEdit.city}
                  onChange={(e) => setCompEdit({ ...compEdit, city: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Tax ID / NTN</label>
                <input
                  type="text"
                  value={compEdit.taxId}
                  onChange={(e) => setCompEdit({ ...compEdit, taxId: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Corporate Website</label>
                <input
                  type="text"
                  value={compEdit.website}
                  onChange={(e) => setCompEdit({ ...compEdit, website: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-slate-400 block mb-1">Logo URL</label>
                <input
                  type="text"
                  value={compEdit.logoUrl}
                  onChange={(e) => setCompEdit({ ...compEdit, logoUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-slate-400 block mb-1">Headquarters Street Address</label>
                <input
                  type="text"
                  value={compEdit.address}
                  onChange={(e) => setCompEdit({ ...compEdit, address: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Registration Details</label>
                <input
                  type="text"
                  value={compEdit.registrationDetails}
                  onChange={(e) => setCompEdit({ ...compEdit, registrationDetails: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Business Sector</label>
                <input
                  type="text"
                  value={compEdit.sector}
                  onChange={(e) => setCompEdit({ ...compEdit, sector: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-slate-400 block mb-1">Authorized Departments (Comma Separated)</label>
                <input
                  type="text"
                  value={compEdit.departmentsText}
                  onChange={(e) => setCompEdit({ ...compEdit, departmentsText: e.target.value })}
                  placeholder="Executive HQ, Sales, Service, Finance, Dealer Network"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={!hasPerm('company.profile.manage')}
              className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold disabled:opacity-40"
            >
              Save Company Profile
            </button>
          </form>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-white">Company Compliance Documents</h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {(companyData?.company?.documents || []).map((doc: any) => (
                <div key={doc.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-white">{doc.title}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {doc.category} • {doc.refNo}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      const nextDocs = (companyData?.company?.documents || []).filter((d: any) => d.id !== doc.id);
                      await api.updateCompanyAdminCompany({ documents: nextDocs });
                      await loadTabData('company');
                    }}
                    className="p-1.5 rounded-lg bg-rose-950 text-rose-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="font-bold text-slate-300">Add Document Record</div>
              <input
                type="text"
                placeholder="Document Title (e.g., SECP Certificate)"
                value={docForm.title}
                onChange={(e) => setDocForm({ ...docForm, title: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Category"
                  value={docForm.category}
                  onChange={(e) => setDocForm({ ...docForm, category: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Reference No."
                  value={docForm.refNo}
                  onChange={(e) => setDocForm({ ...docForm, refNo: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <button
                type="button"
                onClick={handleAddCompanyDoc}
                disabled={!hasPerm('company.profile.manage')}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold disabled:opacity-40"
              >
                + Register Document
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: EMPLOYEE MANAGEMENT (CRUD, ATTENDANCE, LEAVE, PERFORMANCE, PERMISSIONS) */}
      {caTab === 'employees' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form onSubmit={handleCreateEmployee} className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>Create Company Employee Account</span>
              </h3>
              <input
                type="text"
                required
                placeholder="Employee Full Name"
                value={newEmp.fullName}
                onChange={(e) => setNewEmp({ ...newEmp, fullName: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="email"
                required
                placeholder="Work Email"
                value={newEmp.email}
                onChange={(e) => setNewEmp({ ...newEmp, email: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="tel"
                  required
                  placeholder="Mobile"
                  value={newEmp.mobile}
                  onChange={(e) => setNewEmp({ ...newEmp, mobile: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Emp Code (Optional)"
                  value={newEmp.employeeCode}
                  onChange={(e) => setNewEmp({ ...newEmp, employeeCode: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newEmp.jobPosition}
                  onChange={(e) => setNewEmp({ ...newEmp, jobPosition: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {(empPayload?.allowedRoles || ['Sales Manager', 'Sales Executive', 'Service Manager', 'Finance Manager', 'Technical Support', 'Dealership Manager', 'Dealership Staff', 'Head Office Staff']).map((r: string) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  placeholder="Department"
                  value={newEmp.department}
                  onChange={(e) => setNewEmp({ ...newEmp, department: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newEmp.branchId}
                  onChange={(e) => setNewEmp({ ...newEmp, branchId: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="">Assign Branch...</option>
                  {(empPayload?.branches || []).map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
                <input
                  type="text"
                  placeholder="City"
                  value={newEmp.city}
                  onChange={(e) => setNewEmp({ ...newEmp, city: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="password"
                required
                placeholder="Initial Strong Password (10+ chars)"
                value={newEmp.password}
                onChange={(e) => setNewEmp({ ...newEmp, password: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button
                type="submit"
                disabled={!hasPerm('employees.manage')}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold disabled:opacity-40"
              >
                Create Employee Account
              </button>
            </form>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">
                Company Employees ({empPayload?.employees?.length || 0})
              </h3>
              <div className="space-y-2.5 max-h-[520px] overflow-y-auto">
                {(empPayload?.employees || []).map((emp: any) => (
                  <div key={emp.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white flex items-center gap-2">
                          <span>{emp.full_name}</span>
                          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300">
                            {emp.employee_code}
                          </span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              emp.status === 'Active'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : emp.status === 'On Leave'
                                ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                : 'bg-rose-950 text-rose-300 border border-rose-800'
                            }`}
                          >
                            {emp.status}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {emp.job_position} • {emp.department} • {emp.branch_name || emp.city} • Score: <strong className="text-cyan-300">{emp.performance_score}/100</strong>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedEmp(emp);
                            setPerfForm({ score: emp.performance_score || 90, notes: emp.performance_notes || '' });
                          }}
                          className="px-2.5 py-1 rounded-lg bg-cyan-950/60 text-cyan-300 border border-cyan-500/30 font-bold"
                        >
                          Manage HR &amp; Access
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            const next = emp.status === 'Active' ? 'Suspended' : 'Active';
                            try {
                              await api.updateCompanyAdminEmployeeStatus(emp.id, next);
                              notify(`${emp.full_name} set to ${next}.`);
                              await loadTabData('employees');
                            } catch (err: any) {
                              notify(err.message, 'err');
                            }
                          }}
                          className={`px-2.5 py-1 rounded-lg font-bold ${
                            emp.status === 'Active'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-emerald-600 text-white'
                          }`}
                        >
                          {emp.status === 'Active' ? 'Suspend' : 'Activate'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {selectedEmp && (
            <div className="rounded-2xl bg-slate-900/80 border border-cyan-500/40 p-5 space-y-5 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-base font-bold text-white">
                    HR, Attendance, Leave &amp; Permissions — {selectedEmp.full_name} ({selectedEmp.employee_code})
                  </h4>
                  <p className="text-slate-400">{selectedEmp.job_position} • {selectedEmp.email}</p>
                </div>
                <button onClick={() => setSelectedEmp(null)} className="text-slate-400 hover:text-white font-bold">
                  Close Panel
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Attendance & Performance */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> Record Attendance
                  </div>
                  <div className="grid grid-cols-3 gap-1.5">
                    <select
                      value={attForm.status}
                      onChange={(e) => setAttForm({ ...attForm, status: e.target.value })}
                      className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1.5 text-white"
                    >
                      <option value="Present">Present</option>
                      <option value="Remote">Remote</option>
                      <option value="Late">Late</option>
                      <option value="Absent">Absent</option>
                    </select>
                    <input
                      type="text"
                      value={attForm.checkIn}
                      onChange={(e) => setAttForm({ ...attForm, checkIn: e.target.value })}
                      placeholder="09:00"
                      className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1.5 text-white"
                    />
                    <input
                      type="text"
                      value={attForm.checkOut}
                      onChange={(e) => setAttForm({ ...attForm, checkOut: e.target.value })}
                      placeholder="18:00"
                      className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1.5 text-white"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await api.recordCompanyAdminAttendance(selectedEmp.id, attForm);
                        notify('Attendance logged.');
                        await loadTabData('employees');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="w-full py-1.5 rounded-lg bg-cyan-600 text-white font-bold"
                  >
                    Log Today&apos;s Attendance
                  </button>

                  <div className="pt-2 border-t border-slate-800 space-y-2">
                    <div className="font-bold text-white">Performance Review</div>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={perfForm.score}
                      onChange={(e) => setPerfForm({ ...perfForm, score: Number(e.target.value) })}
                      className="w-full rounded-lg bg-slate-900 border border-slate-700 px-2 py-1.5 text-white"
                    />
                    <input
                      type="text"
                      value={perfForm.notes}
                      onChange={(e) => setPerfForm({ ...perfForm, notes: e.target.value })}
                      placeholder="Review feedback notes"
                      className="w-full rounded-lg bg-slate-900 border border-slate-700 px-2 py-1.5 text-white"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await api.updateCompanyAdminEmployee(selectedEmp.id, {
                            performanceScore: perfForm.score,
                            performanceNotes: perfForm.notes,
                          });
                          notify('Performance updated.');
                          await loadTabData('employees');
                        } catch (err: any) {
                          notify(err.message, 'err');
                        }
                      }}
                      className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                    >
                      Save Score &amp; Notes
                    </button>
                  </div>
                </div>

                {/* Leave Requests */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" /> Leave Requests ({selectedEmp.leaveRequests?.length || 0})
                  </div>
                  <div className="space-y-1.5 max-h-32 overflow-y-auto">
                    {(selectedEmp.leaveRequests || []).map((lv: any) => (
                      <div key={lv.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                        <div>
                          <div className="font-semibold text-white">{lv.type}: {lv.startDate} &rarr; {lv.endDate}</div>
                          <div className="text-[10px] text-slate-400">{lv.reason} • <strong>{lv.status}</strong></div>
                        </div>
                        {lv.status === 'Pending' && (
                          <div className="flex gap-1">
                            <button
                              type="button"
                              onClick={async () => {
                                await api.updateCompanyAdminLeave(selectedEmp.id, { leaveId: lv.id, status: 'Approved' });
                                notify('Leave approved.');
                                await loadTabData('employees');
                              }}
                              className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold"
                            >
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={async () => {
                                await api.updateCompanyAdminLeave(selectedEmp.id, { leaveId: lv.id, status: 'Rejected' });
                                notify('Leave rejected.');
                                await loadTabData('employees');
                              }}
                              className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-bold"
                            >
                              Reject
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="pt-2 border-t border-slate-800 space-y-1.5">
                    <div className="grid grid-cols-3 gap-1">
                      <select
                        value={leaveForm.type}
                        onChange={(e) => setLeaveForm({ ...leaveForm, type: e.target.value })}
                        className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white"
                      >
                        <option value="Annual">Annual</option>
                        <option value="Medical">Medical</option>
                        <option value="Casual">Casual</option>
                      </select>
                      <input
                        type="date"
                        value={leaveForm.startDate}
                        onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                        className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white"
                      />
                      <input
                        type="date"
                        value={leaveForm.endDate}
                        onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                        className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white"
                      />
                    </div>
                    <input
                      type="text"
                      placeholder="Leave reason"
                      value={leaveForm.reason}
                      onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                      className="w-full rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!leaveForm.startDate || !leaveForm.endDate) return notify('Select leave dates.', 'err');
                        await api.createCompanyAdminLeave(selectedEmp.id, leaveForm);
                        setLeaveForm({ type: 'Annual', startDate: '', endDate: '', reason: '' });
                        notify('Leave request created.');
                        await loadTabData('employees');
                      }}
                      className="w-full py-1.5 rounded-lg bg-amber-600 text-slate-950 font-bold"
                    >
                      Add Leave Request
                    </button>
                  </div>
                </div>

                {/* Employee Module Permissions */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="font-bold text-emerald-300">Employee Workspace Permissions</div>
                  <div className="flex flex-wrap gap-1.5 max-h-56 overflow-y-auto">
                    {(empPayload?.grantablePermissions || []).map((pKey: string) => {
                      const active = (selectedEmp.permissions || []).includes(pKey);
                      return (
                        <button
                          key={pKey}
                          type="button"
                          disabled={!hasPerm('employees.permissions.manage')}
                          onClick={async () => {
                            const curr: string[] = selectedEmp.permissions || [];
                            const next = active ? curr.filter((x) => x !== pKey) : [...curr, pKey];
                            try {
                              await api.updateCompanyAdminEmployeePermissions(selectedEmp.id, next);
                              notify(`Permissions updated for ${selectedEmp.full_name}.`);
                              await loadTabData('employees');
                            } catch (err: any) {
                              notify(err.message, 'err');
                            }
                          }}
                          className={`px-2 py-1 rounded-md text-[10px] font-mono border ${
                            active
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-slate-900 text-slate-500 border-slate-800'
                          }`}
                        >
                          {active ? '✓ ' : ''}{pKey}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Preserved Invite Link Panel */}
          <TeamInvitePanel />
        </div>
      )}

      {/* TAB 4: BRANCH MANAGEMENT */}
      {caTab === 'branches' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await api.createCompanyAdminBranch(newBranch);
                  notify('Branch created.');
                  setNewBranch({ name: '', code: '', city: 'Karachi', address: '', phone: '+92 ', managerUserId: '' });
                  await loadTabData('branches');
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs"
            >
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-cyan-400" />
                <span>Create Company Branch</span>
              </h3>
              <input
                type="text"
                required
                placeholder="Branch Name (e.g., BYD Islamabad Flagship)"
                value={newBranch.name}
                onChange={(e) => setNewBranch({ ...newBranch, name: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Code (e.g., ISB-01)"
                  value={newBranch.code}
                  onChange={(e) => setNewBranch({ ...newBranch, code: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                />
                <input
                  type="text"
                  required
                  placeholder="City"
                  value={newBranch.city}
                  onChange={(e) => setNewBranch({ ...newBranch, city: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="text"
                required
                placeholder="Branch Address"
                value={newBranch.address}
                onChange={(e) => setNewBranch({ ...newBranch, address: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="tel"
                required
                placeholder="Branch Phone"
                value={newBranch.phone}
                onChange={(e) => setNewBranch({ ...newBranch, phone: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <select
                value={newBranch.managerUserId}
                onChange={(e) => setNewBranch({ ...newBranch, managerUserId: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="">Assign Branch Manager (Optional)</option>
                {(branchPayload?.employees || []).map((e: any) => (
                  <option key={e.id} value={e.id}>{e.full_name} ({e.job_position || e.role})</option>
                ))}
              </select>
              <button
                type="submit"
                disabled={!hasPerm('branches.manage')}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold disabled:opacity-40"
              >
                Create Branch
              </button>
            </form>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Company Branches ({branchPayload?.branches?.length || 0})</h3>
              <div className="space-y-3">
                {(branchPayload?.branches || []).map((b: any) => (
                  <div key={b.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white flex items-center gap-2">
                          <span>{b.name}</span>
                          <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-800 text-cyan-300">{b.code}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                            {b.status}
                          </span>
                        </div>
                        <div className="text-slate-400">
                          {b.city} • {b.address} • Manager: <strong className="text-slate-200">{b.manager_name || 'Unassigned'}</strong>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <select
                          value={b.manager_id || ''}
                          onChange={async (e) => {
                            await api.updateCompanyAdminBranch(b.id, { managerId: e.target.value || null });
                            notify('Branch Manager updated.');
                            await loadTabData('branches');
                          }}
                          className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[11px] text-white"
                        >
                          <option value="">Assign Manager...</option>
                          {(branchPayload?.employees || []).map((emp: any) => (
                            <option key={emp.id} value={emp.id}>{emp.full_name}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={async () => {
                            const rep = await api.getCompanyAdminBranchReport(b.id);
                            setBranchReport(rep);
                          }}
                          className="px-3 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 font-bold"
                        >
                          Branch Report
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 pt-1 text-[11px]">
                      <div className="p-2 rounded-lg bg-slate-900">Staff: <strong className="text-white">{b.employee_count ?? 0}</strong></div>
                      <div className="p-2 rounded-lg bg-slate-900">Stock / Sold: <strong className="text-cyan-300">{b.stock_count ?? 0} / {b.sold_count ?? 0}</strong></div>
                      <div className="p-2 rounded-lg bg-slate-900">Sales: <strong className="text-emerald-400">{formatPrice(b.monthly_revenue_pkr || 0)}</strong></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {branchReport && (
            <div className="rounded-2xl bg-slate-900 border border-cyan-500/40 p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white">Live Branch Operational Report — {branchReport.branch?.name}</h4>
                <button onClick={() => setBranchReport(null)} className="text-slate-400 hover:text-white font-bold">Close</button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-slate-950">Employees: <strong>{branchReport.summary?.staffCount ?? 0}</strong></div>
                <div className="p-3 rounded-xl bg-slate-950">Inventory: <strong>{branchReport.summary?.totalAssignedVehicles ?? 0}</strong></div>
                <div className="p-3 rounded-xl bg-slate-950">In Stock: <strong className="text-cyan-300">{branchReport.summary?.availableStock ?? 0}</strong></div>
                <div className="p-3 rounded-xl bg-slate-950">Revenue: <strong className="text-emerald-400">{formatPrice(branchReport.summary?.salesVolumePkr || 0)}</strong></div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: DEALERSHIP MANAGEMENT */}
      {caTab === 'dealerships' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await api.createCompanyAdminDealership(newDealer);
                notify('Company dealership created.');
                setNewDealer({ name: '', city: 'Karachi', address: '', phone: '+92 ', email: '', managerName: '', chargingBays: 4, serviceBays: 6 });
                await loadTabData('dealerships');
              } catch (err: any) {
                notify(err.message, 'err');
              }
            }}
            className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Store className="w-4 h-4 text-cyan-400" />
              <span>Add Authorized Dealership</span>
            </h3>
            <input
              type="text"
              required
              placeholder="Dealership Name"
              value={newDealer.name}
              onChange={(e) => setNewDealer({ ...newDealer, name: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                placeholder="City"
                value={newDealer.city}
                onChange={(e) => setNewDealer({ ...newDealer, city: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="text"
                required
                placeholder="Manager Name"
                value={newDealer.managerName}
                onChange={(e) => setNewDealer({ ...newDealer, managerName: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="email"
              placeholder="Dealer Email"
              value={newDealer.email}
              onChange={(e) => setNewDealer({ ...newDealer, email: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <input
              type="tel"
              required
              placeholder="Phone"
              value={newDealer.phone}
              onChange={(e) => setNewDealer({ ...newDealer, phone: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <input
              type="text"
              required
              placeholder="Showroom Street Address"
              value={newDealer.address}
              onChange={(e) => setNewDealer({ ...newDealer, address: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <button
              type="submit"
              disabled={!hasPerm('dealers.manage')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold disabled:opacity-40"
            >
              Register Dealership
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Company Dealership Network ({dealers.length})</h3>
            <div className="space-y-3">
              {dealers.map((d) => (
                <div key={d.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{d.name}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            d.status === 'Approved'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : d.status === 'Pending Approval'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {d.status}
                        </span>
                      </div>
                      <div className="text-slate-400">
                        {d.city} • Mgr: <strong className="text-slate-200">{d.manager_name}</strong> • Achieved: {d.achieved_units ?? 0} units • Rating: {d.rating ?? '4.8'}/5
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {d.status !== 'Approved' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await api.decideCompanyAdminDealership(d.id, 'Approved');
                            notify(`${d.name} Approved.`);
                            await loadTabData('dealerships');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" /> Approve
                        </button>
                      )}
                      {d.status === 'Pending Approval' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await api.decideCompanyAdminDealership(d.id, 'Rejected');
                            notify(`${d.name} Rejected.`);
                            await loadTabData('dealerships');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1"
                        >
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      )}
                      {d.status === 'Approved' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await api.decideCompanyAdminDealership(d.id, 'Suspended');
                            notify(`${d.name} Suspended.`);
                            await loadTabData('dealerships');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 text-rose-300 font-bold"
                        >
                          Suspend
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setDealerMsgTarget(d)}
                        className="px-2.5 py-1 rounded-lg bg-cyan-950/60 text-cyan-300 border border-cyan-500/30 font-bold flex items-center gap-1"
                      >
                        <Send className="w-3 h-3" /> Message
                      </button>
                    </div>
                  </div>

                  {dealerMsgTarget?.id === d.id && (
                    <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-2">
                      <input
                        type="text"
                        placeholder="Communication Subject"
                        value={dealerMsgForm.subject}
                        onChange={(e) => setDealerMsgForm({ ...dealerMsgForm, subject: e.target.value })}
                        className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white"
                      />
                      <textarea
                        placeholder="Directive or message to dealership..."
                        value={dealerMsgForm.message}
                        onChange={(e) => setDealerMsgForm({ ...dealerMsgForm, message: e.target.value })}
                        className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white"
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await api.communicateWithCompanyAdminDealership(d.id, dealerMsgForm);
                            notify(`Directive sent to ${d.name}.`);
                            setDealerMsgTarget(null);
                            setDealerMsgForm({ subject: '', message: '' });
                          }}
                          className="px-3 py-1 rounded-lg bg-cyan-600 text-white font-bold"
                        >
                          Send Directive
                        </button>
                        <button
                          type="button"
                          onClick={() => setDealerMsgTarget(null)}
                          className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 pt-2 border-t border-slate-800">
            <AdminDealerGovernancePanel scope="company-admin" />
          </div>
        </div>
      )}

      {/* TAB 6: VEHICLE & INVENTORY MANAGEMENT */}
      {caTab === 'vehicles' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.createCompanyAdminVehicle(newVeh);
                notify(`Vehicle ${res.vin} added to inventory.`);
                setNewVeh({ ...newVeh, vin: '' });
                await loadTabData('vehicles');
              } catch (err: any) {
                notify(err.message, 'err');
              }
            }}
            className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Car className="w-4 h-4 text-cyan-400" />
              <span>Add Vehicle to Inventory</span>
            </h3>
            <select
              value={newVeh.model}
              onChange={(e) => setNewVeh({ ...newVeh, model: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              {VEHICLE_MODELS.map((vm) => (
                <option key={vm} value={vm}>{vm}</option>
              ))}
            </select>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Variant"
                value={newVeh.variant}
                onChange={(e) => setNewVeh({ ...newVeh, variant: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="text"
                placeholder="Color"
                value={newVeh.color}
                onChange={(e) => setNewVeh({ ...newVeh, color: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="text"
              placeholder="VIN / Chassis (Auto-generated if blank)"
              value={newVeh.vin}
              onChange={(e) => setNewVeh({ ...newVeh, vin: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
            />
            <div className="grid grid-cols-2 gap-2">
              <select
                value={newVeh.branchId}
                onChange={(e) => setNewVeh({ ...newVeh, branchId: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="">Select Branch...</option>
                {(vehiclesData?.branches || []).map((b: any) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
              <input
                type="number"
                required
                placeholder="Price (PKR)"
                value={newVeh.pricePkr}
                onChange={(e) => setNewVeh({ ...newVeh, pricePkr: Number(e.target.value) })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <button
              type="submit"
              disabled={!hasPerm('vehicles.manage')}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold disabled:opacity-40"
            >
              Add Vehicle Stock
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Company Fleet Inventory ({vehiclesData?.vehicles?.length || 0})</h3>
            <div className="space-y-2.5 max-h-[540px] overflow-y-auto">
              {(vehiclesData?.vehicles || []).map((v: any) => (
                <div key={v.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{v.model}</span>
                        <span className="font-mono text-[10px] text-cyan-300">{v.vin}</span>
                      </div>
                      <div className="text-slate-400">
                        Branch: <strong className="text-slate-200">{v.branch_name || 'Unassigned'}</strong> • {v.color} • {formatPrice(v.sale_price_pkr || 0)} • SoH: {v.battery_health_soh}%
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        value={v.delivery_status || 'In Stock'}
                        onChange={async (e) => {
                          await api.updateCompanyAdminVehicle(v.id, { deliveryStatus: e.target.value });
                          notify('Vehicle stock status updated.');
                          await loadTabData('vehicles');
                        }}
                        className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-[11px] text-white"
                      >
                        <option value="In Stock">In Stock</option>
                        <option value="Reserved">Reserved</option>
                        <option value="In Transit">In Transit</option>
                        <option value="Delivered">Delivered</option>
                      </select>
                      <button
                        type="button"
                        onClick={() =>
                          setTransferTarget({
                            vehicleId: v.id,
                            targetBranchId: vehiclesData?.branches?.[0]?.id || '',
                            deliveryStatus: 'In Transit',
                          })
                        }
                        className="px-2.5 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 font-bold flex items-center gap-1"
                      >
                        <ArrowRightLeft className="w-3 h-3" /> Transfer
                      </button>
                    </div>
                  </div>

                  {transferTarget && transferTarget.vehicleId === v.id && (
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-cyan-500/30 flex flex-wrap items-center gap-2">
                      <select
                        value={transferTarget.targetBranchId}
                        onChange={(e) => setTransferTarget({ ...transferTarget, targetBranchId: e.target.value })}
                        className="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-white"
                      >
                        {(vehiclesData?.branches || []).map((b: any) => (
                          <option key={b.id} value={b.id}>{b.name} ({b.city})</option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const res = await api.transferCompanyAdminVehicle(v.id, {
                              targetBranchId: transferTarget.targetBranchId,
                              deliveryStatus: transferTarget.deliveryStatus,
                            });
                            notify(`Vehicle transferred to ${res.branchName}.`);
                            setTransferTarget(null);
                            await loadTabData('vehicles');
                          } catch (err: any) {
                            notify(err.message, 'err');
                          }
                        }}
                        className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-bold"
                      >
                        Confirm Transfer
                      </button>
                      <button
                        type="button"
                        onClick={() => setTransferTarget(null)}
                        className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: CUSTOMER & CRM MANAGEMENT */}
      {caTab === 'customers' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white">Company Customers ({customersData?.customers?.length || 0})</h3>
                <button
                  type="button"
                  onClick={() => setCnicRevealed(!cnicRevealed)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                >
                  {cnicRevealed ? 'Mask CNIC' : 'Reveal Full CNIC (Logged)'}
                </button>
              </div>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {(customersData?.customers || []).map((c: any) => (
                  <div key={c.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">{c.full_name}</div>
                      <div className="text-[11px] text-slate-400">
                        {c.email} • {c.mobile} • {c.city}
                      </div>
                      <div className="text-[10px] font-mono text-slate-500">
                        ID/CNIC: {c.cnic_or_id || c.cnic_masked || 'Not Provided'}
                      </div>
                    </div>
                    <div className="text-right text-[11px]">
                      <div className="text-cyan-300 font-bold">{c.booking_count ?? 0} Bookings</div>
                      <div className="text-emerald-400 font-mono">{formatPrice(c.lifetime_spend || 0)}</div>
                    </div>
                  </div>
                ))}
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    await api.createCompanyAdminCustomer(newCust);
                    notify('Customer record created.');
                    setNewCust({ fullName: '', email: '', mobile: '+92 300 ', city: 'Karachi', cnicOrId: '', password: '' });
                    await loadTabData('customers');
                  } catch (err: any) {
                    notify(err.message, 'err');
                  }
                }}
                className="pt-3 border-t border-slate-800 space-y-2"
              >
                <div className="font-bold text-slate-300">+ Register Company Customer</div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={newCust.fullName}
                    onChange={(e) => setNewCust({ ...newCust, fullName: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email"
                    value={newCust.email}
                    onChange={(e) => setNewCust({ ...newCust, email: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                  />
                  <input
                    type="tel"
                    required
                    placeholder="Mobile"
                    value={newCust.mobile}
                    onChange={(e) => setNewCust({ ...newCust, mobile: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                  />
                  <input
                    type="text"
                    placeholder="CNIC / ID"
                    value={newCust.cnicOrId}
                    onChange={(e) => setNewCust({ ...newCust, cnicOrId: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                  />
                </div>
                <input
                  type="password"
                  required
                  placeholder="Initial Password (10+ chars)"
                  value={newCust.password}
                  onChange={(e) => setNewCust({ ...newCust, password: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <button
                  type="submit"
                  disabled={!hasPerm('customers.manage')}
                  className="w-full py-2 rounded-xl bg-cyan-600 text-white font-bold disabled:opacity-40"
                >
                  Add Customer
                </button>
              </form>
            </div>

            {/* CRM Panel */}
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-white">Customer Enquiries, Complaints, Feedback &amp; Follow-Ups</h3>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {(customersData?.crmRecords || []).map((crm: any) => (
                  <div key={crm.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-white">
                        [{crm.record_type}] {crm.subject}
                      </span>
                      <select
                        value={crm.status}
                        onChange={async (e) => {
                          await api.updateCompanyAdminCrm(crm.id, { status: e.target.value });
                          notify('CRM record updated.');
                          await loadTabData('customers');
                        }}
                        className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-0.5 text-[11px] text-cyan-300"
                      >
                        <option value="Open">Open</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                        <option value="Closed">Closed</option>
                      </select>
                    </div>
                    <p className="text-slate-300">{crm.details}</p>
                    <div className="text-[10px] text-slate-500">
                      Customer: {crm.customer_name || 'General'} • Priority: {crm.priority} • Follow-Up: {crm.follow_up_date || 'None'}
                    </div>
                  </div>
                ))}
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    await api.createCompanyAdminCrm(newCrm);
                    notify('CRM record logged.');
                    setNewCrm({ customerId: '', recordType: 'Enquiry', subject: '', details: '', priority: 'Medium', followUpDate: '' });
                    await loadTabData('customers');
                  } catch (err: any) {
                    notify(err.message, 'err');
                  }
                }}
                className="pt-3 border-t border-slate-800 space-y-2"
              >
                <div className="font-bold text-slate-300">+ New CRM Interaction</div>
                <div className="grid grid-cols-3 gap-2">
                  <select
                    value={newCrm.recordType}
                    onChange={(e) => setNewCrm({ ...newCrm, recordType: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                  >
                    <option value="Enquiry">Enquiry</option>
                    <option value="Complaint">Complaint</option>
                    <option value="Feedback">Feedback</option>
                    <option value="Follow-Up">Follow-Up</option>
                  </select>
                  <select
                    value={newCrm.customerId}
                    onChange={(e) => setNewCrm({ ...newCrm, customerId: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                  >
                    <option value="">Customer...</option>
                    {(customersData?.customers || []).map((c: any) => (
                      <option key={c.id} value={c.id}>{c.full_name}</option>
                    ))}
                  </select>
                  <input
                    type="date"
                    value={newCrm.followUpDate}
                    onChange={(e) => setNewCrm({ ...newCrm, followUpDate: e.target.value })}
                    className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                  />
                </div>
                <input
                  type="text"
                  required
                  placeholder="Subject"
                  value={newCrm.subject}
                  onChange={(e) => setNewCrm({ ...newCrm, subject: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <textarea
                  required
                  rows={2}
                  placeholder="Interaction details & follow-up notes..."
                  value={newCrm.details}
                  onChange={(e) => setNewCrm({ ...newCrm, details: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <button
                  type="submit"
                  disabled={!hasPerm('customers.manage')}
                  className="w-full py-2 rounded-xl bg-emerald-600 text-white font-bold disabled:opacity-40"
                >
                  Log CRM Record
                </button>
              </form>
            </div>
          </div>

          <AdminCustomerGovernancePanel scope="company-admin" />
          <AdminVerificationApprovalPanel portalLabel="Company Admin" />
          <AccountSecurityCenter />
        </div>
      )}

      {/* TAB 8: SALES & FINANCE MANAGEMENT */}
      {caTab === 'sales' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  const res = await api.createCompanyAdminInvoice(invForm);
                  notify(`Official Invoice ${res.invoiceNumber} created (${res.status}).`);
                  await loadTabData('sales');
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3"
            >
              <h3 className="text-sm font-bold text-white">Issue Vehicle / Service Invoice</h3>
              <select
                value={invForm.customerId}
                onChange={(e) => setInvForm({ ...invForm, customerId: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                {(customersData?.customers || []).map((c: any) => (
                  <option key={c.id} value={c.id}>{c.full_name}</option>
                ))}
              </select>
              <select
                value={invForm.vehicleId}
                onChange={(e) => setInvForm({ ...invForm, vehicleId: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                {(vehiclesData?.vehicles || []).map((v: any) => (
                  <option key={v.id} value={v.id}>{v.model} ({v.vin})</option>
                ))}
              </select>
              <select
                value={invForm.branchId}
                onChange={(e) => setInvForm({ ...invForm, branchId: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="">Select Branch...</option>
                {(branchPayload?.branches || []).map((b: any) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  required
                  value={invForm.amountPkr}
                  onChange={(e) => setInvForm({ ...invForm, amountPkr: Number(e.target.value) })}
                  placeholder="Amount (PKR)"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <select
                  value={invForm.status}
                  onChange={(e) => setInvForm({ ...invForm, status: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="Paid">Paid</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
              <input
                type="text"
                value={invForm.paymentGateway}
                onChange={(e) => setInvForm({ ...invForm, paymentGateway: e.target.value })}
                placeholder="Payment Gateway"
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button
                type="submit"
                disabled={!hasPerm('finance.manage')}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold disabled:opacity-40"
              >
                Create Official Invoice
              </button>
            </form>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-white">Company Invoices &amp; Refunds</h3>
                <div className="text-emerald-400 font-bold">
                  Paid Revenue: {formatPrice(salesFinance?.totals?.paidTotal || 0)}
                </div>
              </div>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {(salesFinance?.invoices || []).map((inv: any) => (
                  <div key={inv.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-mono font-bold text-cyan-300">{inv.invoice_number}</span>
                        <span className="text-slate-300"> • {inv.customer_name} • {inv.payment_gateway}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white">{formatPrice(inv.total_amount || 0)}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            inv.status === 'Paid'
                              ? 'bg-emerald-950 text-emerald-300'
                              : inv.status === 'Refunded'
                              ? 'bg-rose-950 text-rose-300'
                              : 'bg-amber-950 text-amber-300'
                          }`}
                        >
                          {inv.status}
                        </span>
                        {inv.status !== 'Refunded' && hasPerm('finance.manage') && (
                          <button
                            type="button"
                            onClick={() => setRefundTarget({ id: inv.id, invoiceNumber: inv.invoice_number, reason: '' })}
                            className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold"
                          >
                            Refund
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {refundTarget && (
                <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/40 flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    placeholder={`Refund reason for ${refundTarget.invoiceNumber}...`}
                    value={refundTarget.reason}
                    onChange={(e) => setRefundTarget({ ...refundTarget, reason: e.target.value })}
                    className="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await api.refundCompanyAdminInvoice(refundTarget.id, refundTarget.reason || 'Authorized Company Admin refund');
                        notify(`Invoice ${refundTarget.invoiceNumber} refunded.`);
                        setRefundTarget(null);
                        await loadTabData('sales');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
                  >
                    Process Refund
                  </button>
                  <button onClick={() => setRefundTarget(null)} className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300">
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Bookings Management */}
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Company Vehicle Bookings ({salesFinance?.bookings?.length || 0})</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(salesFinance?.bookings || []).map((b: any) => (
                <div key={b.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-white">{b.customer_name} — {b.vehicle_model}</div>
                    <div className="text-[11px] text-slate-400">
                      {b.city} • Dealer: {b.dealer_name || 'Direct HQ'} • {formatPrice(b.price_pkr || 0)}
                    </div>
                  </div>
                  <select
                    value={b.status}
                    disabled={!hasPerm('sales.manage')}
                    onChange={async (e) => {
                      try {
                        await api.updateCompanyAdminBooking(b.id, { status: e.target.value });
                        notify('Booking status updated.');
                        await loadTabData('sales');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-cyan-300 font-bold"
                  >
                    <option value="Pending">Pending</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 9: REPORTS & REAL EXPORT */}
      {caTab === 'reports' && (
        <div className="space-y-6 text-xs">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-bold text-white">Reporting Window:</span>
              {(['daily', 'monthly', 'yearly'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setReportPeriod(p)}
                  className={`px-3 py-1.5 rounded-lg font-bold capitalize ${
                    reportPeriod === p ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={exporting || !hasPerm('reports.export')}
                onClick={() => handleDownloadExport('xlsx')}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 disabled:opacity-40"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Export Excel (.xlsx)</span>
              </button>
              <button
                type="button"
                disabled={exporting || !hasPerm('reports.export')}
                onClick={() => handleDownloadExport('csv')}
                className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold flex items-center gap-1.5 disabled:opacity-40"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save PDF</span>
              </button>
            </div>
          </div>

          {reportData && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 space-y-2">
                <h4 className="font-bold text-cyan-300">Financial Summary ({reportData.period})</h4>
                <div className="p-2.5 rounded-xl bg-slate-950">Paid Revenue: <strong className="text-emerald-400">{formatPrice(reportData.financialSummary?.paidTotal || 0)}</strong></div>
                <div className="p-2.5 rounded-xl bg-slate-950">Pending Invoices: <strong className="text-amber-300">{formatPrice(reportData.financialSummary?.pendingTotal || 0)}</strong></div>
                <div className="p-2.5 rounded-xl bg-slate-950">Refunded Total: <strong className="text-rose-400">{formatPrice(reportData.financialSummary?.refundedTotal || 0)}</strong></div>
              </div>

              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 space-y-2">
                <h4 className="font-bold text-cyan-300">Vehicle Inventory Report</h4>
                {(reportData.vehiclesByModel || []).map((v: any) => (
                  <div key={v.model} className="p-2 rounded-lg bg-slate-950 flex justify-between">
                    <span className="text-white">{v.model} ({v.availableUnits} avail / {v.soldUnits} sold)</span>
                    <strong className="text-cyan-300">{v.totalUnits} units</strong>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 space-y-2">
                <h4 className="font-bold text-cyan-300">Customer &amp; CRM Breakdown</h4>
                {(reportData.crmSummary || []).map((c: any) => (
                  <div key={`${c.record_type}-${c.status}`} className="p-2 rounded-lg bg-slate-950 flex justify-between">
                    <span className="text-white">{c.record_type} — {c.status}</span>
                    <strong className="text-emerald-400">{c.count}</strong>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 10: SESSIONS, LOGIN HISTORY, SECURITY & AUDIT LOGS */}
      {caTab === 'security' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-cyan-400" />
                <span>Active Company Admin Sessions ({caSessions.length})</span>
              </h3>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {caSessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current Session)</span> : ''}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        IP: {s.ip_address} • Expires: {s.expires_at?.slice(0, 19).replace('T', ' ')}
                      </div>
                    </div>
                    {!s.is_current && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.revokeCompanyAdminSession(s.id);
                          setCaSessions((prev) => prev.filter((x) => x.id !== s.id));
                          notify('Session revoked.');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold"
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <span>Company Admin Login History</span>
              </h3>
              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {caLoginHistory.map((h) => (
                  <div key={h.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-slate-300">{h.ip_address}</span>
                    <span className="text-slate-400">{h.created_at?.slice(0, 19).replace('T', ' ')}</span>
                    <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {h.success ? 'VERIFIED' : h.failure_reason || 'FAILED'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Company Activity &amp; Security Audit Trail</h3>
            <div className="flex flex-wrap gap-1.5 pb-2">
              {(auditData?.canonicalPermissions || []).map((p: string) => {
                const granted = (auditData?.assignedPermissions || []).includes(p);
                return (
                  <span
                    key={p}
                    className={`px-2 py-0.5 rounded-md font-mono text-[10px] border ${
                      granted
                        ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                        : 'bg-slate-950 text-slate-500 border-slate-800'
                    }`}
                  >
                    {granted ? '✓ ' : '✗ '}{p}
                  </span>
                );
              })}
            </div>
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {(auditData?.activityLogs || []).map((log: any) => (
                <div key={log.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <span className="font-mono text-amber-300">{log.action}</span>
                    <span className="text-slate-300"> — {log.actor_name} ({log.module})</span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-500">{log.created_at?.slice(0, 19).replace('T', ' ')}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {caTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {caTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
