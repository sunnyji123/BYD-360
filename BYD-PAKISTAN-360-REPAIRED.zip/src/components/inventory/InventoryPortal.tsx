import React, { useState, useEffect } from 'react';
import {
  Package,
  Layers,
  ArrowRightLeft,
  AlertTriangle,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  Download,
  Building,
  Truck,
  RotateCcw,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { Warehouse, SparePart, InventoryTransaction } from '../../types';

export const InventoryPortal: React.FC = () => {
  const { currentRole, currentUser, selectedCountry, formatPrice } = useApp();
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [parts, setParts] = useState<SparePart[]>([]);
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);

  const [activeTab, setActiveTab] = useState<'parts' | 'warehouses' | 'transfers'>('parts');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // New Transfer Modal
  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [transferSku, setTransferSku] = useState('BYD-HV-BLADE-MDL');
  const [transferQty, setTransferQty] = useState(2);
  const [transferSource, setTransferSource] = useState('WH-PK-KHI-01 (Port Qasim Depot)');
  const [transferDest, setTransferDest] = useState('Mega Motor Flagship 3S — Clifton');
  const [transferSuccess, setTransferSuccess] = useState(false);

  // New Part Modal
  const [addPartModalOpen, setAddPartModalOpen] = useState(false);
  const [newPartName, setNewPartName] = useState('');
  const [newPartSku, setNewPartSku] = useState('');
  const [newPartCategory, setNewPartCategory] = useState<SparePart['category']>('Battery & High Voltage');
  const [newPartQty, setNewPartQty] = useState(10);
  const [newPartCost, setNewPartCost] = useState(25000);
  const [newPartBin, setNewPartBin] = useState('SHELF-A1');

  useEffect(() => {
    const load = () => {
      setWarehouses(db.getWarehouses());
      setParts(db.getSpareParts());
      setTransactions(db.getInventoryTransactions());
    };
    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  const filteredParts = parts.filter((p) => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.locationBin.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const lowStockCount = parts.filter((p) => p.stockQuantity <= p.reorderLevel).length;
  const totalValuationPkr = parts.reduce((acc, p) => acc + p.stockQuantity * p.unitCostPkr, 0);

  const handleInitiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const part = parts.find((p) => p.sku === transferSku);
    if (!part || transferQty <= 0) return;

    const newTx: InventoryTransaction = {
      id: `tx_${Date.now()}`,
      sku: part.sku,
      partName: part.name,
      sourceLocation: transferSource,
      destinationLocation: transferDest,
      quantity: transferQty,
      type: 'TRANSFER_INTER_WAREHOUSE',
      status: 'In Transit',
      initiatedBy: currentUser.name,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      referencePo: `TR-BYD-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    db.addInventoryTransaction(newTx);
    db.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentRole,
      action: 'STOCK_TRANSFER_INITIATED',
      module: 'Global Inventory',
      targetId: `${newTx.referencePo} (${transferQty}x ${part.sku})`,
    });

    setTransferSuccess(true);
    setTimeout(() => {
      setTransferSuccess(false);
      setTransferModalOpen(false);
    }, 1500);
  };

  const handleCreatePart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPartName || !newPartSku) return;

    const newPart: SparePart = {
      id: `prt_${Date.now()}`,
      sku: newPartSku.toUpperCase(),
      name: newPartName,
      category: newPartCategory,
      compatibleModels: ['BYD Seal', 'BYD Atto 3', 'BYD Sealion 6'],
      stockQuantity: Number(newPartQty),
      reorderLevel: 5,
      unitCostPkr: Number(newPartCost),
      locationBin: newPartBin.toUpperCase(),
    };

    const currentParts = db.getSpareParts();
    currentParts.unshift(newPart);
    // update localStorage
    localStorage.setItem('byd_pk_360_v1_spare_parts', JSON.stringify(currentParts));

    db.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentRole,
      action: 'NEW_PART_CATALOGUED',
      module: 'Global Inventory',
      targetId: newPart.sku,
    });

    setAddPartModalOpen(false);
    setNewPartName('');
    setNewPartSku('');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total SKUs in Stock</span>
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-2xl font-black text-white mt-2">{parts.length} Active Items</h3>
          <p className="text-[11px] text-slate-400 mt-1">Multi-model certified EV parts</p>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Low Stock Threshold</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-2xl font-black text-amber-400 mt-2">{lowStockCount} Reorder Alerts</h3>
          <p className="text-[11px] text-slate-400 mt-1">Auto purchase order recommendations</p>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Distribution Depots</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-2xl font-black text-white mt-2">{warehouses.length} Global Hubs</h3>
          <p className="text-[11px] text-slate-400 mt-1">Shenzhen, Karachi, Lahore, Dubai, Riyadh</p>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total Inventory Valuation</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <h3 className="text-2xl font-black text-emerald-400 mt-2">{formatPrice(totalValuationPkr)}</h3>
          <p className="text-[11px] text-slate-400 mt-1">Consolidated multi-currency valuation</p>
        </div>
      </div>

      {/* Main Controls & Tab Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('parts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'parts'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Spare Parts Catalogue
          </button>
          <button
            onClick={() => setActiveTab('warehouses')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'warehouses'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Global Warehouses & Depots
          </button>
          <button
            onClick={() => setActiveTab('transfers')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'transfers'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Stock Movement & Transfers ({transactions.length})
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setTransferModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-slate-850 text-xs font-semibold"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-cyan-400" />
            <span>Initiate Transfer</span>
          </button>
          <button
            onClick={() => setAddPartModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Part SKU</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Spare Parts Catalogue */}
      {activeTab === 'parts' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search SKU, part name, bin..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              {['All', 'Battery & High Voltage', 'Powertrain', 'Braking & Tires', 'Thermal Management', 'Body & Glass'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    selectedCategory === cat
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-850'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3.5 px-4 font-semibold">SKU / Code</th>
                    <th className="py-3.5 px-4 font-semibold">Part Name</th>
                    <th className="py-3.5 px-4 font-semibold">Category</th>
                    <th className="py-3.5 px-4 font-semibold">Compatible Vehicles</th>
                    <th className="py-3.5 px-4 font-semibold text-center">Stock Level</th>
                    <th className="py-3.5 px-4 font-semibold">Bin Location</th>
                    <th className="py-3.5 px-4 font-semibold text-right">Unit Price</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredParts.map((p) => {
                    const isLow = p.stockQuantity <= p.reorderLevel;
                    return (
                      <tr key={p.id} className="hover:bg-slate-850/50 transition">
                        <td className="py-3 px-4 font-mono font-bold text-cyan-300">{p.sku}</td>
                        <td className="py-3 px-4 font-semibold text-white">{p.name}</td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                            {p.category}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px]">{p.compatibleModels.join(', ')}</td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`font-mono font-bold px-2.5 py-0.5 rounded-full text-xs ${
                              isLow
                                ? 'bg-amber-950 text-amber-400 border border-amber-800'
                                : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            }`}
                          >
                            {p.stockQuantity} units
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-400">{p.locationBin}</td>
                        <td className="py-3 px-4 text-right font-bold text-white">
                          {formatPrice(p.unitCostPkr)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Global Warehouses */}
      {activeTab === 'warehouses' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {warehouses.map((wh) => (
            <div
              key={wh.id}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4 shadow-lg hover:border-slate-700 transition"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                    {wh.code}
                  </span>
                  <h4 className="text-base font-extrabold text-white mt-2">{wh.name}</h4>
                  <p className="text-xs text-slate-400">{wh.city}, {wh.country}</p>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {wh.type}
                </span>
              </div>

              <p className="text-xs text-slate-300">{wh.address}</p>

              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-400">Warehouse Utilization:</span>
                  <span className="font-bold text-cyan-400">{wh.utilizedPercentage}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 h-full rounded-full"
                    style={{ width: `${wh.utilizedPercentage}%` }}
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">Total Capacity: {wh.capacityUnits.toLocaleString()} units</p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 text-xs text-slate-400 space-y-1">
                <p><strong>Hub Lead:</strong> {wh.managerName}</p>
                <p><strong>Emergency Logistics Contact:</strong> {wh.contactPhone}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Stock Movement & Transfers */}
      {activeTab === 'transfers' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Truck className="w-4 h-4 text-cyan-400" />
                <span>Inter-Warehouse & Workshop Transfer Log</span>
              </h4>
              <p className="text-xs text-slate-400">Audited custody handovers with dispatch PO numbers</p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono">
              ISO 9001 Certified Dispatch
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">PO Reference</th>
                  <th className="py-3 px-4 font-semibold">Item & SKU</th>
                  <th className="py-3 px-4 font-semibold">Route (Origin → Destination)</th>
                  <th className="py-3 px-4 font-semibold text-center">Qty</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Authorized By</th>
                  <th className="py-3 px-4 font-semibold">Date & Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-850/50 transition">
                    <td className="py-3 px-4 font-mono font-bold text-cyan-300">{tx.referencePo}</td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{tx.partName}</div>
                      <span className="font-mono text-[10px] text-slate-400">{tx.sku}</span>
                    </td>
                    <td className="py-3 px-4 text-[11px]">
                      <div className="text-slate-400">{tx.sourceLocation}</div>
                      <div className="text-cyan-400 font-semibold mt-0.5">↳ {tx.destinationLocation}</div>
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-white">{tx.quantity}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          tx.status === 'Completed'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                            : 'bg-amber-950 text-amber-400 border border-amber-800'
                        }`}
                      >
                        {tx.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{tx.initiatedBy}</td>
                    <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">{tx.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Transfer Modal */}
      {transferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Dispatch Stock Transfer</h3>
            <p className="text-xs text-slate-400 mb-4">Transfer verified parts between central depot and regional 3S centres.</p>

            {transferSuccess ? (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-white">Transfer Manifest Generated</h4>
                <p className="text-xs text-slate-300">Dispatch log recorded and sent to target warehouse manager.</p>
              </div>
            ) : (
              <form onSubmit={handleInitiateTransfer} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Select Part SKU</label>
                  <select
                    value={transferSku}
                    onChange={(e) => setTransferSku(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  >
                    {parts.map((p) => (
                      <option key={p.id} value={p.sku}>
                        {p.name} ({p.sku}) — Available: {p.stockQuantity}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Transfer Quantity</label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={transferQty}
                      onChange={(e) => setTransferQty(Number(e.target.value))}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Source Depot</label>
                    <input
                      type="text"
                      value={transferSource}
                      onChange={(e) => setTransferSource(e.target.value)}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white text-[11px]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Destination Facility</label>
                  <input
                    type="text"
                    value={transferDest}
                    onChange={(e) => setTransferDest(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setTransferModalOpen(false)}
                    className="px-4 py-2 text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold shadow-md shadow-cyan-500/20"
                  >
                    Confirm Dispatch
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Add Part Modal */}
      {addPartModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Catalogue New EV Spare Part</h3>
            <p className="text-xs text-slate-400 mb-4">Register new factory part with SKU and bin mapping.</p>

            <form onSubmit={handleCreatePart} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Part Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Blade Battery Thermal Coolant Pump"
                  value={newPartName}
                  onChange={(e) => setNewPartName(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Official SKU</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BYD-THM-PUMP-01"
                    value={newPartSku}
                    onChange={(e) => setNewPartSku(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Category</label>
                  <select
                    value={newPartCategory}
                    onChange={(e) => setNewPartCategory(e.target.value as SparePart['category'])}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  >
                    <option value="Battery & High Voltage">Battery & High Voltage</option>
                    <option value="Powertrain">Powertrain</option>
                    <option value="Braking & Tires">Braking & Tires</option>
                    <option value="Thermal Management">Thermal Management</option>
                    <option value="Body & Glass">Body & Glass</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Initial Qty</label>
                  <input
                    type="number"
                    min={1}
                    value={newPartQty}
                    onChange={(e) => setNewPartQty(Number(e.target.value))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Cost (PKR)</label>
                  <input
                    type="number"
                    min={100}
                    value={newPartCost}
                    onChange={(e) => setNewPartCost(Number(e.target.value))}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Bin Location</label>
                  <input
                    type="text"
                    value={newPartBin}
                    onChange={(e) => setNewPartBin(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-2.5 py-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setAddPartModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                >
                  Save to Catalogue
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
