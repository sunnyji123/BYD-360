import React, { useState, useEffect, useCallback } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  Plus,
  Car,
  Shield,
  DollarSign,
  FileText,
  Calendar,
  Activity,
  XCircle,
} from 'lucide-react';
import { api } from '../../services/api';

type GovernanceScope = 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager';

interface Props {
  scope: GovernanceScope;
}

export const AdminDealerGovernancePanel: React.FC<Props> = ({ scope }) => {
  const [subTab, setSubTab] = useState<'accounts' | 'stock' | 'bookings' | 'commissions' | 'documents' | 'logs'>('accounts');
  const [data, setData] = useState<{
    dealers: any[];
    bookings: any[];
    commissions: any[];
    documents: any[];
    inventory: any[];
    activityLogs: any[];
    canonicalPermissions: string[];
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState('');
  const [errMsg, setErrMsg] = useState('');

  // Create Dealer form state
  const [showCreate, setShowCreate] = useState(false);
  const [cBusinessName, setCBusinessName] = useState('');
  const [cOwnerName, setCOwnerName] = useState('');
  const [cEmail, setCEmail] = useState('');
  const [cMobile, setCMobile] = useState('+92 300 ');
  const [cPassword, setCPassword] = useState('');
  const [cCity, setCCity] = useState('Karachi');
  const [cCategory, setCCategory] = useState('3S Flagship Centre');
  const [cRate, setCRate] = useState(4.5);
  const [provisionedCreds, setProvisionedCreds] = useState<{ dealerCode: string; totpSecret: string; recoveryCodes: string[] } | null>(null);

  // Assign vehicle stock form
  const [vDealerId, setVDealerId] = useState('');
  const [vModel, setVModel] = useState('BYD Sealion 6');
  const [vVariant, setVVariant] = useState('Dynamic PHEV');
  const [vColor, setVColor] = useState('Arctic White');
  const [vPrice, setVPrice] = useState(14990000);

  // Permissions editor
  const [permDealer, setPermDealer] = useState<any | null>(null);
  const [selectedPerms, setSelectedPerms] = useState<string[]>([]);
  const [permRate, setPermRate] = useState<number>(4.5);

  const loadData = useCallback(async () => {
    setLoading(true);
    setErrMsg('');
    try {
      const res = await api.listAdminDealers(scope);
      setData(res);
      if (res.dealers?.[0]?.id && !vDealerId) {
        setVDealerId(res.dealers[0].id);
      }
    } catch (err: any) {
      setErrMsg(err?.message || 'Unable to load Dealer Governance registry.');
    } finally {
      setLoading(false);
    }
  }, [scope, vDealerId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const flash = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 5000);
  };

  return (
    <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 sm:p-6 space-y-5 text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400">
            Authorized Dealer Account Governance ({scope})
          </span>
          <h3 className="text-base font-bold text-white">
            Dealer Verification, Stock Allocation, Booking Payments &amp; Commission Payouts
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowCreate(!showCreate)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Dealer Account</span>
          </button>
          <button
            type="button"
            onClick={loadData}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-300 hover:text-white font-semibold"
          >
            Refresh
          </button>
        </div>
      </div>

      {errMsg && (
        <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errMsg}</span>
        </div>
      )}
      {notice && (
        <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notice}</span>
        </div>
      )}
      {provisionedCreds && (
        <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 space-y-1">
          <div className="font-bold">Dealer Account Provisioned: {provisionedCreds.dealerCode}</div>
          <div>2FA TOTP Secret: <code className="font-mono text-white">{provisionedCreds.totpSecret}</code></div>
          <div>Recovery Codes: <code className="font-mono text-white">{provisionedCreds.recoveryCodes.join(' • ')}</code></div>
        </div>
      )}

      {showCreate && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              const res = await api.createAdminDealer(scope, {
                businessName: cBusinessName,
                ownerContactName: cOwnerName,
                email: cEmail,
                mobile: cMobile,
                password: cPassword,
                city: cCity,
                category: cCategory,
                commissionRatePct: Number(cRate),
                approveImmediately: scope !== 'branch-manager',
              });
              setProvisionedCreds({
                dealerCode: res.dealer.dealerCode,
                totpSecret: res.twoFactorProvisioned.totpSecret,
                recoveryCodes: res.twoFactorProvisioned.recoveryCodes,
              });
              setCBusinessName('');
              setCOwnerName('');
              setCEmail('');
              setCPassword('');
              setShowCreate(false);
              flash(`Created dealer ${res.dealer.businessName} (${res.dealer.dealerCode}).`);
              loadData();
            } catch (err: any) {
              setErrMsg(err?.message || 'Failed to create dealer account.');
            }
          }}
          className="p-4 rounded-xl bg-slate-950 border border-blue-500/30 space-y-3"
        >
          <div className="font-bold text-white">Provision Authorized Dealer Login Account</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input required placeholder="Business Name" value={cBusinessName} onChange={(e) => setCBusinessName(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required placeholder="Owner / Principal Name" value={cOwnerName} onChange={(e) => setCOwnerName(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required type="email" placeholder="Official Dealer Email" value={cEmail} onChange={(e) => setCEmail(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input required placeholder="Mobile" value={cMobile} onChange={(e) => setCMobile(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required placeholder="City" value={cCity} onChange={(e) => setCCity(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <select value={cCategory} onChange={(e) => setCCategory(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="3S Flagship Centre">3S Flagship Centre</option>
              <option value="2S Service Facility">2S Service Facility</option>
              <option value="Retail Experience Studio">Retail Experience Studio</option>
              <option value="Authorized EV Reseller">Authorized EV Reseller</option>
            </select>
            <input type="number" step="0.5" min="1" max="15" value={cRate} onChange={(e) => setCRate(Number(e.target.value))} placeholder="Commission %" className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
          </div>
          <div className="flex gap-3">
            <input required type="password" placeholder="Strong Initial Password" value={cPassword} onChange={(e) => setCPassword(e.target.value)} className="flex-1 rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <button type="submit" className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Provision Dealer
            </button>
          </div>
        </form>
      )}

      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-1.5">
        {[
          { id: 'accounts', label: `Dealer Accounts (${data?.dealers?.length || 0})`, icon: Shield },
          { id: 'stock', label: `Assigned Vehicles (${data?.inventory?.length || 0})`, icon: Car },
          { id: 'bookings', label: `Bookings & Payments (${data?.bookings?.length || 0})`, icon: Calendar },
          { id: 'commissions', label: `Commissions (${data?.commissions?.length || 0})`, icon: DollarSign },
          { id: 'documents', label: `Documents (${data?.documents?.length || 0})`, icon: FileText },
          { id: 'logs', label: `Dealer Activity (${data?.activityLogs?.length || 0})`, icon: Activity },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition ${
                subTab === t.id ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {loading && <div className="py-4 text-center text-slate-400">Syncing dealer governance records...</div>}

      {/* SUBTAB 1: DEALER ACCOUNTS */}
      {subTab === 'accounts' && (
        <div className="space-y-3">
          {(data?.dealers || []).map((d) => (
            <div key={d.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-cyan-300">{d.dealer_code}</span>
                    <span className="text-sm font-bold text-white">{d.business_name}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        d.verification_status === 'Verified' && d.status === 'Active'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : d.status === 'Suspended' || d.status === 'Rejected'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {d.verification_status} • {d.status}
                    </span>
                  </div>
                  <div className="text-slate-400">
                    {d.owner_contact_name} • {d.email} • {d.category} • {d.company_name} ({d.city}) • Commission: <strong className="text-amber-300">{d.commission_rate_pct}%</strong>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {d.verification_status !== 'Verified' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.decideAdminDealer(scope, d.id, 'approve');
                        flash(`Approved dealer ${d.dealer_code}.`);
                        loadData();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                    >
                      Approve Dealer
                    </button>
                  )}
                  {d.verification_status === 'Pending Approval' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.decideAdminDealer(scope, d.id, 'reject', 'Did not meet dealership requirements');
                        flash(`Rejected ${d.dealer_code}.`);
                        loadData();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold"
                    >
                      Reject
                    </button>
                  )}
                  {d.status === 'Active' ? (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.decideAdminDealer(scope, d.id, 'suspend', 'Administrative compliance hold');
                        flash(`Suspended ${d.dealer_code} & revoked active sessions.`);
                        loadData();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-700 font-bold"
                    >
                      Suspend
                    </button>
                  ) : d.status === 'Suspended' ? (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.decideAdminDealer(scope, d.id, 'reactivate');
                        flash(`Reactivated ${d.dealer_code}.`);
                        loadData();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold"
                    >
                      Reactivate
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => {
                      setPermDealer(d);
                      setSelectedPerms(d.permissions || []);
                      setPermRate(Number(d.commission_rate_pct || 4.5));
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                  >
                    Permissions ({d.permissions?.length || 0})
                  </button>
                </div>
              </div>

              {d.pending_change_status === 'Pending Admin Approval' && (
                <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-700/50 flex items-center justify-between gap-2">
                  <span className="text-amber-200">
                    Sensitive Profile/Bank Change Request: {JSON.stringify(d.pendingChanges)}
                  </span>
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={async () => {
                        await api.reviewAdminDealerProfileChange(scope, d.id, 'approve');
                        flash(`Approved bank/profile changes for ${d.dealer_code}.`);
                        loadData();
                      }}
                      className="px-2 py-1 rounded bg-emerald-600 text-white font-bold"
                    >
                      Approve Change
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        await api.reviewAdminDealerProfileChange(scope, d.id, 'reject');
                        flash(`Rejected bank/profile changes for ${d.dealer_code}.`);
                        loadData();
                      }}
                      className="px-2 py-1 rounded bg-rose-700 text-white font-bold"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}

          {permDealer && (
            <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">Edit Permissions &amp; Commission Rate — {permDealer.business_name}</span>
                <button type="button" onClick={() => setPermDealer(null)} className="text-slate-400 hover:text-white">
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(data?.canonicalPermissions || []).map((p) => (
                  <label key={p} className="flex items-center gap-1.5 text-slate-300">
                    <input
                      type="checkbox"
                      checked={selectedPerms.includes(p)}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedPerms([...selectedPerms, p]);
                        else setSelectedPerms(selectedPerms.filter((x) => x !== p));
                      }}
                    />
                    <span className="truncate">{p}</span>
                  </label>
                ))}
              </div>
              <div className="flex items-center gap-3">
                <label className="text-slate-400">Commission Rate (%):</label>
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  max="20"
                  value={permRate}
                  onChange={(e) => setPermRate(Number(e.target.value))}
                  className="w-24 rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1 text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    await api.updateAdminDealerPermissions(scope, permDealer.id, selectedPerms, permRate);
                    flash(`Updated permissions and commission rate for ${permDealer.dealer_code}.`);
                    setPermDealer(null);
                    loadData();
                  }}
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold"
                >
                  Save Permissions
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: ASSIGN VEHICLES */}
      {subTab === 'stock' && (
        <div className="space-y-4">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!vDealerId) return;
              await api.assignAdminDealerVehicle(scope, vDealerId, {
                model: vModel,
                variant: vVariant,
                exteriorColor: vColor,
                approvedSellingPricePkr: Number(vPrice),
              });
              flash('Assigned new BYD vehicle unit to dealer showroom.');
              loadData();
            }}
            className="p-4 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-1 md:grid-cols-6 gap-2"
          >
            <select value={vDealerId} onChange={(e) => setVDealerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-2 text-white md:col-span-2">
              {(data?.dealers || []).map((d) => (
                <option key={d.id} value={d.id}>{d.dealer_code} — {d.business_name}</option>
              ))}
            </select>
            <input value={vModel} onChange={(e) => setVModel(e.target.value)} placeholder="Model" className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-2 text-white" />
            <input value={vVariant} onChange={(e) => setVVariant(e.target.value)} placeholder="Variant" className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-2 text-white" />
            <input type="number" value={vPrice} onChange={(e) => setVPrice(Number(e.target.value))} placeholder="Price PKR" className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-2 text-white" />
            <button type="submit" className="rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-2">
              Assign Vehicle
            </button>
          </form>

          <div className="space-y-2">
            {(data?.inventory || []).slice(0, 25).map((inv) => (
              <div key={inv.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div>
                  <span className="font-mono text-cyan-300 font-bold">{inv.stock_number}</span> •{' '}
                  <strong className="text-white">{inv.model} {inv.variant}</strong> ({inv.exterior_color})
                  <div className="text-slate-400">Dealer: {inv.dealer_name} ({inv.dealer_code}) • VIN: {inv.vin}</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-slate-800 font-bold text-emerald-300">{inv.availability_status}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: BOOKINGS & VERIFIED PAYMENTS */}
      {subTab === 'bookings' && (
        <div className="space-y-2.5">
          {(data?.bookings || []).map((bk) => (
            <div key={bk.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="font-mono font-bold text-cyan-300">{bk.booking_ref} • {bk.dealer_name} ({bk.dealer_code})</div>
                <div className="text-white font-semibold">{bk.vehicle_model} {bk.variant} • Customer: {bk.customer_name}</div>
                <div className="text-slate-400 tabular-nums">
                  Price: PKR {Number(bk.agreed_price_pkr).toLocaleString()} • Booking: {bk.booking_status} • Payment: {bk.payment_status}
                </div>
              </div>
              {bk.booking_status === 'Pending Approval' && (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      await api.reviewAdminDealerBooking(scope, bk.id, 'approve', true);
                      flash(`Approved booking ${bk.booking_ref}, verified payment settlement, & generated commission.`);
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                  >
                    Approve &amp; Verify Payment
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.reviewAdminDealerBooking(scope, bk.id, 'reject', false);
                      flash(`Rejected booking ${bk.booking_ref}.`);
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold"
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 4: COMMISSIONS & PAYOUTS */}
      {subTab === 'commissions' && (
        <div className="space-y-2.5">
          {(data?.commissions || []).map((c) => (
            <div key={c.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="font-mono font-bold text-amber-300">
                  {c.sale_ref} • {c.dealer_name} ({c.dealer_code})
                </div>
                <div className="text-white font-semibold tabular-nums">
                  Commission: PKR {Number(c.commission_amount_pkr).toLocaleString()} ({c.commission_rate_pct}% on PKR {Number(c.sale_amount_pkr).toLocaleString()})
                </div>
                <div className="text-slate-400">Status: {c.status} {c.payout_reference ? `• Ref: ${c.payout_reference}` : ''}</div>
              </div>
              <div className="flex gap-2">
                {c.status === 'Pending' && (
                  <button
                    type="button"
                    onClick={async () => {
                      await api.actionAdminDealerCommission(scope, c.id, 'approve');
                      flash('Commission approved for payout.');
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                  >
                    Approve Commission
                  </button>
                )}
                {c.status !== 'Paid' && (
                  <button
                    type="button"
                    onClick={async () => {
                      await api.actionAdminDealerCommission(scope, c.id, 'pay');
                      flash('Commission marked Paid with payout reference.');
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                  >
                    Mark Paid
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 5: DOCUMENTS REVIEW */}
      {subTab === 'documents' && (
        <div className="space-y-2.5">
          {(data?.documents || []).map((doc) => (
            <div key={doc.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
              <div>
                <div className="font-bold text-white">{doc.title} ({doc.doc_type})</div>
                <div className="text-slate-400">
                  {doc.dealer_name} ({doc.dealer_code}) • Status: <strong className="text-cyan-300">{doc.verification_status}</strong>
                </div>
              </div>
              <div className="flex gap-2">
                {doc.verification_status !== 'Verified' && (
                  <button
                    type="button"
                    onClick={async () => {
                      await api.verifyAdminDealerDocument(scope, doc.id, 'Verified');
                      flash(`Verified ${doc.title}.`);
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                  >
                    Verify Doc
                  </button>
                )}
                {doc.verification_status !== 'Rejected' && (
                  <button
                    type="button"
                    onClick={async () => {
                      await api.verifyAdminDealerDocument(scope, doc.id, 'Rejected', 'Resubmit clearer scan');
                      flash(`Rejected ${doc.title}.`);
                      loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold"
                  >
                    Reject
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 6: ACTIVITY LOGS */}
      {subTab === 'logs' && (
        <div className="max-h-72 overflow-y-auto space-y-1.5">
          {(data?.activityLogs || []).map((l) => (
            <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
              <span className="font-mono text-cyan-300 font-bold">{l.dealer_code} • {l.action}</span>
              <span className="text-slate-300 truncate max-w-md">{l.details}</span>
              <span className="text-slate-500 shrink-0">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
