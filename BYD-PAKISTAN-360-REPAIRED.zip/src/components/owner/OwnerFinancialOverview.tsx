import React, { useState, useEffect, useCallback } from 'react';
import { DollarSign, Download, Calendar, Filter, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { api } from '../../services/api';

interface OwnerFinancialOverviewProps {
  countries: Array<{ code: string; name: string }>;
}

function fmtMoney(val: number): string {
  return `₨ ${Math.round(val || 0).toLocaleString()}`;
}

export const OwnerFinancialOverview: React.FC<OwnerFinancialOverviewProps> = ({ countries }) => {
  const [period, setPeriod] = useState<'all' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom'>('all');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [countryId, setCountryId] = useState('ALL');
  const [finance, setFinance] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadFinance = useCallback(async () => {
    if (period === 'custom' && !fromDate && !toDate) return;
    setLoading(true);
    setError('');
    try {
      const data = await api.getOwnerFinance({
        period,
        fromDate: period === 'custom' ? fromDate : undefined,
        toDate: period === 'custom' ? toDate : undefined,
        countryId,
      });
      setFinance(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load financial intelligence report.');
    } finally {
      setLoading(false);
    }
  }, [period, fromDate, toDate, countryId]);

  useEffect(() => {
    loadFinance();
  }, [loadFinance]);

  const exportCsv = () => {
    if (!finance?.transactions?.length) return;
    const headers = ['ID', 'Reference', 'Type', 'Direction', 'Country', 'Entity', 'Description', 'Amount', 'Cleared', 'Pending', 'Currency', 'Status', 'Date'];
    const rows = finance.transactions.map((t: any) =>
      [t.id, t.ref, t.type, t.direction, t.countryCode, t.entityName, t.description, t.amount, t.clearedAmount, t.pendingAmount, t.currency, t.status, t.date]
        .map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`)
        .join(',')
    );
    const blob = new Blob([[headers.join(','), ...rows].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BYD_360_Financial_Report_${period}_${countryId}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const s = finance?.summary || {};

  return (
    <div className="space-y-6">
      {/* Period & Country Controls */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Total Revenue, Expenses &amp; Net Profit Intelligence</span>
            </h3>
            <p className="text-xs text-slate-400">
              Strict accounting separation: Unpaid orders &amp; pending invoices remain in Pending Payments and are never counted as Cleared Received Revenue.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={exportCsv}
              disabled={!finance?.transactions?.length}
              className="px-3.5 py-2 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-xs font-bold text-cyan-300 hover:text-white disabled:opacity-40 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV Report</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {([
            { id: 'all', label: 'All Time' },
            { id: 'daily', label: 'Daily (Today)' },
            { id: 'weekly', label: 'Weekly (7d)' },
            { id: 'monthly', label: 'Monthly' },
            { id: 'yearly', label: 'Yearly' },
            { id: 'custom', label: 'Custom Range' },
          ] as const).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                period === p.id
                  ? 'bg-amber-500 text-slate-950 border-amber-400'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white'
              }`}
            >
              {p.label}
            </button>
          ))}

          <div className="flex items-center gap-2 ml-auto">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={countryId}
              onChange={(e) => setCountryId(e.target.value)}
              className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-xs text-white"
            >
              <option value="ALL">All Countries (Global)</option>
              {countries.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.name} ({c.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {period === 'custom' && (
          <div className="flex flex-wrap items-end gap-3 pt-2 border-t border-slate-800 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3" /> Start Date
              </label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3" /> End Date
              </label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
              />
            </div>
            <button
              type="button"
              onClick={loadFinance}
              className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold"
            >
              Apply Range
            </button>
          </div>
        )}
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* 8 Core Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Total Cleared Revenue (Received)</div>
          <div className="text-xl font-black text-emerald-400 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.totalReceivedPayments)}
          </div>
          <div className="text-[10px] text-emerald-500/80 mt-0.5 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Verified paid settlements only
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Total Vehicle Sales Value</div>
          <div className="text-xl font-black text-white font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.totalVehicleSalesValue)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Contracted sales across channels</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Pending Payments &amp; Outstanding</div>
          <div className="text-xl font-black text-amber-300 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.pendingPayments)}
          </div>
          <div className="text-[10px] text-amber-500/80 mt-0.5">Excluded from cleared revenue</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Net Profit (Verified)</div>
          <div className={`text-xl font-black font-mono tabular-nums mt-1 ${(s.netProfit || 0) >= 0 ? 'text-cyan-300' : 'text-rose-400'}`}>
            {loading ? '...' : fmtMoney(s.netProfit)}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            Margin: {s.profitMarginPct ?? 0}%
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Total Expenses</div>
          <div className="text-xl font-black text-rose-300 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.totalExpenses)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Operating + Commissions + Payroll</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Operating Expenses (Branches)</div>
          <div className="text-xl font-black text-slate-200 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.operatingExpenses)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Verified branch expense ledger</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Dealer Commissions</div>
          <div className="text-xl font-black text-slate-200 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.commissionExpenses)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Paid &amp; approved dealer payouts</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Verified Payroll Disbursed</div>
          <div className="text-xl font-black text-slate-200 font-mono tabular-nums mt-1">
            {loading ? '...' : fmtMoney(s.payrollExpenses)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Paid employee salary records</div>
        </div>
      </div>

      {/* Country-Wise Financial Breakdown */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
        <h4 className="text-sm font-bold text-white">Country-Wise Financial Report ({finance?.filter?.label || 'All'})</h4>
        {!finance?.countryFinancialReports?.length ? (
          <div className="py-8 text-center text-xs text-slate-500">No Data Available for the selected period or country.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Country</th>
                  <th className="py-2.5 px-3 text-right">Sales Value</th>
                  <th className="py-2.5 px-3 text-right">Received Revenue</th>
                  <th className="py-2.5 px-3 text-right">Pending / Unpaid</th>
                  <th className="py-2.5 px-3 text-right">Operating Exp.</th>
                  <th className="py-2.5 px-3 text-right">Commissions &amp; Payroll</th>
                  <th className="py-2.5 px-3 text-right">Total Expenses</th>
                  <th className="py-2.5 px-3 text-right">Net Profit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {finance.countryFinancialReports.map((cf: any) => (
                  <tr key={cf.countryCode}>
                    <td className="py-2.5 px-3 font-mono font-bold text-white">{cf.countryCode}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{fmtMoney(cf.vehicleSalesValue)}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-400 font-bold">{fmtMoney(cf.receivedPayments)}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-amber-300">{fmtMoney(cf.pendingPayments)}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{fmtMoney(cf.operatingExpenses)}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{fmtMoney(cf.commissionExpenses + cf.payrollExpenses)}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-300">{fmtMoney(cf.totalExpenses)}</td>
                    <td className={`py-2.5 px-3 text-right font-mono tabular-nums font-black ${cf.netProfit >= 0 ? 'text-cyan-300' : 'text-rose-400'}`}>
                      {fmtMoney(cf.netProfit)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Verified Financial Audit Ledger */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
        <h4 className="text-sm font-bold text-white">Verified Financial Transactions Ledger ({finance?.transactions?.length || 0})</h4>
        {!finance?.transactions?.length ? (
          <div className="py-8 text-center text-xs text-slate-500">No Data Available for the selected period or filter.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Ref</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Country</th>
                  <th className="py-2.5 px-3">Entity / Counterparty</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {finance.transactions.map((t: any) => (
                  <tr key={`${t.type}-${t.id}`} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 font-mono text-slate-400 whitespace-nowrap">{String(t.date || '').slice(0, 10)}</td>
                    <td className="py-2 px-3 font-mono text-cyan-300">{t.ref}</td>
                    <td className="py-2 px-3 text-slate-200">{t.type}</td>
                    <td className="py-2 px-3 font-mono text-slate-300">{t.countryCode}</td>
                    <td className="py-2 px-3 text-white font-semibold">{t.entityName}</td>
                    <td className="py-2 px-3 text-slate-300">{t.description}</td>
                    <td
                      className={`py-2 px-3 text-right font-mono tabular-nums font-bold ${
                        t.direction === 'INFLOW' ? 'text-emerald-400' : t.direction === 'PENDING' ? 'text-amber-300' : 'text-rose-300'
                      }`}
                    >
                      {t.direction === 'OUTFLOW' ? '-' : ''}{fmtMoney(t.amount)}
                    </td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          t.direction === 'PENDING'
                            ? 'bg-amber-950 text-amber-300'
                            : t.direction === 'OUTFLOW'
                            ? 'bg-rose-950 text-rose-300'
                            : 'bg-emerald-950 text-emerald-300'
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
