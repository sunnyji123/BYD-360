import express, { Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import {
  sqlite,
  PRIVATE_EMPLOYEE_DOCS_DIR,
  generateSecureToken,
  hashPassword,
  validatePasswordStrength,
  generateNextEmployeeCode,
  recordEmployeeHistory,
  logEmployeeAudit,
  logSecurityEvent,
  nowIso,
} from './db';
import { getClientIp, requireAuth } from './auth';
import { buildSimplePdfBuffer } from './dealer';

const ALLOWED_DOC_MIMES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
});

const LEAVE_TYPES = [
  'Annual Leave',
  'Casual Leave',
  'Sick Leave',
  'Emergency Leave',
  'Unpaid Leave',
  'Maternity Leave',
  'Other Approved Leave',
];

const DOCUMENT_CATEGORIES = [
  'CNIC',
  'Passport',
  'Educational Certificate',
  'Experience Certificate',
  'Employment Contract',
  'Appointment Letter',
  'Joining Document',
  'Training Certificate',
  'Profile Photo',
  'Leave Supporting Document',
  'Other Official Document',
];

export interface EmpMgmtScope {
  mode:
    | 'founder'
    | 'super_admin'
    | 'company_admin'
    | 'country_manager'
    | 'branch_manager'
    | 'hr_manager'
    | 'finance_manager'
    | 'dept_manager'
    | 'employee';
  selfOnly: boolean;
  selfEmployeeId: string | null;
  restrictedCompanyId: string | null;
  restrictedCountryId: string | null;
  restrictedBranchId: string | null;
  restrictedDepartment: string | null;
  canViewAllEmployees: boolean;
  canManageProfiles: boolean;
  canToggleStatus: boolean;
  canManageAttendance: boolean;
  canAccessPayroll: boolean;
  canProcessPayroll: boolean;
  canApprovePayroll: boolean;
  canPayPayroll: boolean;
  canApplyLeave: boolean;
  canApproveLeave: boolean;
  canManagePositions: boolean;
  canEvaluatePerformance: boolean;
  canManageDocuments: boolean;
  canVerifyDocuments: boolean;
  canViewPii: boolean;
  canExportReports: boolean;
  canManageSettings: boolean;
}

function safeJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function maskSensitive(raw: string | null | undefined, reveal: boolean): string {
  if (!raw) return 'Not Provided';
  const s = String(raw).trim();
  if (!s) return 'Not Provided';
  if (reveal) return s;
  if (s.length <= 6) return '••••••';
  return `${s.slice(0, 4)}••••${s.slice(-3)}`;
}

function resolveEmpScope(req: Request): EmpMgmtScope | null {
  const auth = req.auth;
  if (!auth) return null;

  if (auth.subjectType === 'founder') {
    return {
      mode: 'founder',
      selfOnly: false,
      selfEmployeeId: null,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      restrictedDepartment: null,
      canViewAllEmployees: true,
      canManageProfiles: true,
      canToggleStatus: true,
      canManageAttendance: true,
      canAccessPayroll: true,
      canProcessPayroll: true,
      canApprovePayroll: true,
      canPayPayroll: true,
      canApplyLeave: false,
      canApproveLeave: true,
      canManagePositions: true,
      canEvaluatePerformance: true,
      canManageDocuments: true,
      canVerifyDocuments: true,
      canViewPii: true,
      canExportReports: true,
      canManageSettings: true,
    };
  }

  if (auth.subjectType === 'super_admin') {
    const p = new Set(auth.permissions || []);
    const canEmp = p.has('employees.manage');
    const canFinance = p.has('sales.view') || p.has('reports.view');
    return {
      mode: 'super_admin',
      selfOnly: false,
      selfEmployeeId: null,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      restrictedDepartment: null,
      canViewAllEmployees: canEmp || p.has('users.view') || p.has('reports.view'),
      canManageProfiles: canEmp || p.has('users.create') || p.has('users.update'),
      canToggleStatus: canEmp || p.has('users.suspend'),
      canManageAttendance: canEmp,
      canAccessPayroll: canEmp || canFinance,
      canProcessPayroll: canEmp && p.has('users.update'),
      canApprovePayroll: p.has('settings.manage'),
      canPayPayroll: false,
      canApplyLeave: false,
      canApproveLeave: canEmp,
      canManagePositions: canEmp || p.has('users.update'),
      canEvaluatePerformance: canEmp,
      canManageDocuments: canEmp,
      canVerifyDocuments: canEmp,
      canViewPii: canEmp,
      canExportReports: p.has('reports.view'),
      canManageSettings: p.has('settings.manage'),
    };
  }

  if (auth.subjectType === 'company_admin' && auth.companyId) {
    const p = new Set(auth.permissions || []);
    const canEmp = p.has('employees.manage');
    const canFin = p.has('finance.manage');
    return {
      mode: 'company_admin',
      selfOnly: false,
      selfEmployeeId: null,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: null,
      restrictedBranchId: null,
      restrictedDepartment: null,
      canViewAllEmployees: true,
      canManageProfiles: canEmp,
      canToggleStatus: canEmp,
      canManageAttendance: canEmp,
      canAccessPayroll: canFin || canEmp,
      canProcessPayroll: canFin,
      canApprovePayroll: canFin && p.has('company.profile.manage'),
      canPayPayroll: canFin,
      canApplyLeave: false,
      canApproveLeave: canEmp,
      canManagePositions: canEmp || p.has('branches.manage'),
      canEvaluatePerformance: canEmp,
      canManageDocuments: canEmp,
      canVerifyDocuments: canEmp,
      canViewPii: canEmp,
      canExportReports: p.has('reports.export') || p.has('reports.view'),
      canManageSettings: p.has('company.profile.manage') || canEmp,
    };
  }

  if (auth.subjectType === 'country_manager' && auth.country) {
    const p = new Set(auth.permissions || []);
    const canEmp = p.has('employees.manage');
    const canFin = p.has('finance.sensitive.manage');
    return {
      mode: 'country_manager',
      selfOnly: false,
      selfEmployeeId: null,
      restrictedCompanyId: null,
      restrictedCountryId: auth.country.toUpperCase(),
      restrictedBranchId: null,
      restrictedDepartment: null,
      canViewAllEmployees: p.has('employees.view') || canEmp,
      canManageProfiles: canEmp,
      canToggleStatus: canEmp,
      canManageAttendance: canEmp,
      canAccessPayroll: canFin || canEmp,
      canProcessPayroll: canFin,
      canApprovePayroll: canFin,
      canPayPayroll: canFin,
      canApplyLeave: false,
      canApproveLeave: canEmp,
      canManagePositions: canEmp || p.has('branches.manage'),
      canEvaluatePerformance: canEmp,
      canManageDocuments: canEmp,
      canVerifyDocuments: canEmp,
      canViewPii: canEmp,
      canExportReports: p.has('reports.export') || p.has('reports.view'),
      canManageSettings: false,
    };
  }

  if (auth.subjectType === 'branch_manager' && auth.branchId && auth.companyId) {
    const p = new Set(auth.permissions || []);
    const canEmp = p.has('employees.manage');
    const canFin = p.has('finance.view');
    return {
      mode: 'branch_manager',
      selfOnly: false,
      selfEmployeeId: null,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: auth.country ? auth.country.toUpperCase() : null,
      restrictedBranchId: auth.branchId,
      restrictedDepartment: null,
      canViewAllEmployees: p.has('employees.view') || canEmp,
      canManageProfiles: canEmp,
      canToggleStatus: canEmp,
      canManageAttendance: canEmp,
      canAccessPayroll: canFin || canEmp,
      canProcessPayroll: false,
      canApprovePayroll: false,
      canPayPayroll: false,
      canApplyLeave: false,
      canApproveLeave: canEmp,
      canManagePositions: canEmp || p.has('branch.profile.manage'),
      canEvaluatePerformance: canEmp,
      canManageDocuments: canEmp,
      canVerifyDocuments: canEmp,
      canViewPii: canEmp,
      canExportReports: p.has('reports.export') || p.has('reports.view'),
      canManageSettings: false,
    };
  }

  if (auth.subjectType === 'employee' && auth.employeeId && auth.companyId) {
    const roleLower = String(auth.role || '').toLowerCase();
    const p = new Set(auth.permissions || []);
    const isHr = roleLower.includes('hr') || roleLower.includes('human resource');
    const isFinance = roleLower.includes('finance') || roleLower.includes('payroll') || roleLower.includes('account');
    const isDeptMgr = !isHr && !isFinance && (roleLower.includes('manager') || roleLower.includes('head') || roleLower.includes('lead'));

    if (isHr) {
      return {
        mode: 'hr_manager',
        selfOnly: false,
        selfEmployeeId: auth.employeeId,
        restrictedCompanyId: auth.companyId,
        restrictedCountryId: null,
        restrictedBranchId: null,
        restrictedDepartment: null,
        canViewAllEmployees: true,
        canManageProfiles: true,
        canToggleStatus: true,
        canManageAttendance: true,
        canAccessPayroll: false,
        canProcessPayroll: false,
        canApprovePayroll: false,
        canPayPayroll: false,
        canApplyLeave: true,
        canApproveLeave: true,
        canManagePositions: true,
        canEvaluatePerformance: true,
        canManageDocuments: true,
        canVerifyDocuments: true,
        canViewPii: true,
        canExportReports: true,
        canManageSettings: false,
      };
    }

    if (isFinance) {
      return {
        mode: 'finance_manager',
        selfOnly: false,
        selfEmployeeId: auth.employeeId,
        restrictedCompanyId: auth.companyId,
        restrictedCountryId: null,
        restrictedBranchId: null,
        restrictedDepartment: null,
        canViewAllEmployees: true,
        canManageProfiles: false,
        canToggleStatus: false,
        canManageAttendance: false,
        canAccessPayroll: true,
        canProcessPayroll: true,
        canApprovePayroll: p.has('finance.approve'),
        canPayPayroll: true,
        canApplyLeave: true,
        canApproveLeave: false,
        canManagePositions: false,
        canEvaluatePerformance: false,
        canManageDocuments: false,
        canVerifyDocuments: false,
        canViewPii: false,
        canExportReports: true,
        canManageSettings: false,
      };
    }

    if (isDeptMgr) {
      return {
        mode: 'dept_manager',
        selfOnly: false,
        selfEmployeeId: auth.employeeId,
        restrictedCompanyId: auth.companyId,
        restrictedCountryId: null,
        restrictedBranchId: auth.branchId || null,
        restrictedDepartment: auth.department || null,
        canViewAllEmployees: true,
        canManageProfiles: false,
        canToggleStatus: false,
        canManageAttendance: true,
        canAccessPayroll: false,
        canProcessPayroll: false,
        canApprovePayroll: false,
        canPayPayroll: false,
        canApplyLeave: true,
        canApproveLeave: p.has('employee.leave.approve') || p.has('employees.manage'),
        canManagePositions: false,
        canEvaluatePerformance: true,
        canManageDocuments: false,
        canVerifyDocuments: false,
        canViewPii: false,
        canExportReports: true,
        canManageSettings: false,
      };
    }

    return {
      mode: 'employee',
      selfOnly: true,
      selfEmployeeId: auth.employeeId,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: null,
      restrictedBranchId: auth.branchId || null,
      restrictedDepartment: null,
      canViewAllEmployees: false,
      canManageProfiles: false,
      canToggleStatus: false,
      canManageAttendance: false,
      canAccessPayroll: false,
      canProcessPayroll: false,
      canApprovePayroll: false,
      canPayPayroll: false,
      canApplyLeave: true,
      canApproveLeave: false,
      canManagePositions: false,
      canEvaluatePerformance: false,
      canManageDocuments: p.has('employee.documents.manage'),
      canVerifyDocuments: false,
      canViewPii: false,
      canExportReports: false,
      canManageSettings: false,
    };
  }

  return null;
}

function rejectUnauthorized(req: Request, res: Response, reason: string) {
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'EMPLOYEE_MGMT_ACCESS_DENIED',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId || null,
    details: reason,
    ipAddress: getClientIp(req),
  });
  res.status(403).json({ error: reason });
}

function getScopedEmployeeRows(scope: EmpMgmtScope): any[] {
  const rows = sqlite
    .prepare(`
      SELECT e.*, c.name as company_name, b.name as branch_name, b.code as branch_code, b.city as branch_city,
             co.name as country_name, co.currency as country_currency, co.flag_emoji,
             d.name as dept_table_name, d.code as dept_code,
             p.bio, p.date_of_birth as prof_dob, p.gender as prof_gender, p.cnic_or_id as prof_cnic,
             p.address as prof_address, p.city as prof_city, p.emergency_contact_name as prof_emg_name,
             p.emergency_contact_phone as prof_emg_phone, p.employment_type as prof_emp_type,
             ss.basic_salary as ss_basic, ss.house_allowance, ss.medical_allowance, ss.transport_allowance,
             ss.other_allowances, ss.tax_deduction, ss.other_deductions, ss.bank_name as ss_bank,
             ss.bank_account_title as ss_bank_title, ss.bank_iban as ss_iban, ss.currency as ss_currency
      FROM employee_accounts e
      LEFT JOIN companies c ON c.id = e.company_id
      LEFT JOIN branches b ON b.id = e.branch_id
      LEFT JOIN countries co ON UPPER(co.id) = UPPER(COALESCE(e.country_id, 'PK'))
      LEFT JOIN employee_departments d ON d.id = e.department_id
      LEFT JOIN employee_profiles p ON p.employee_id = e.id
      LEFT JOIN employee_salary_structures ss ON ss.employee_id = e.id
      ORDER BY e.created_at DESC
    `)
    .all() as any[];

  return rows.filter((r) => {
    if (scope.selfOnly && r.id !== scope.selfEmployeeId) return false;
    if (scope.restrictedCompanyId && r.company_id !== scope.restrictedCompanyId) return false;
    if (scope.restrictedCountryId && String(r.country_id || 'PK').toUpperCase() !== scope.restrictedCountryId) return false;
    if (scope.restrictedBranchId && r.branch_id !== scope.restrictedBranchId) return false;
    if (scope.restrictedDepartment && String(r.department || '').toLowerCase() !== scope.restrictedDepartment.toLowerCase()) return false;
    return true;
  });
}

function canActorAccessEmployee(scope: EmpMgmtScope, emp: any): boolean {
  if (!emp) return false;
  if (scope.selfOnly) return emp.id === scope.selfEmployeeId;
  if (scope.restrictedCompanyId && emp.company_id !== scope.restrictedCompanyId) return false;
  if (scope.restrictedCountryId && String(emp.country_id || 'PK').toUpperCase() !== scope.restrictedCountryId) return false;
  if (scope.restrictedBranchId && emp.branch_id !== scope.restrictedBranchId) return false;
  if (scope.restrictedDepartment && String(emp.department || '').toLowerCase() !== scope.restrictedDepartment.toLowerCase()) {
    return emp.id === scope.selfEmployeeId;
  }
  return true;
}

function savePrivateEmployeeDocFile(params: {
  file: Express.Multer.File;
  employeeId: string;
  companyId: string;
  countryId: string;
  branchId: string | null;
  category: string;
  title: string;
  issueDate?: string | null;
  expiryDate?: string | null;
  notes?: string | null;
  verificationStatus?: string;
  uploadedById: string;
  uploadedByRole: string;
}) {
  if (!ALLOWED_DOC_MIMES.has(params.file.mimetype)) {
    throw new Error(`Unsupported file type "${params.file.mimetype}". Allowed: JPG, PNG, WEBP, PDF, TXT, CSV, DOC/DOCX.`);
  }
  if (!fs.existsSync(PRIVATE_EMPLOYEE_DOCS_DIR)) {
    fs.mkdirSync(PRIVATE_EMPLOYEE_DOCS_DIR, { recursive: true });
  }
  const ext = path.extname(params.file.originalname || '').replace(/[^a-zA-Z0-9.]/g, '').slice(0, 10) || '.bin';
  const storageKey = `${params.employeeId}_${Date.now()}_${generateSecureToken(8)}${ext}`;
  const fullPath = path.join(PRIVATE_EMPLOYEE_DOCS_DIR, path.basename(storageKey));
  fs.writeFileSync(fullPath, params.file.buffer);

  const id = `edoc_${generateSecureToken(6)}`;
  const ts = nowIso();
  sqlite
    .prepare(`
      INSERT INTO employee_documents (
        id, employee_id, company_id, country_id, branch_id, category, title,
        original_filename, mime_type, size_bytes, storage_key, issue_date, expiry_date,
        verification_status, document_notes, uploaded_by_id, uploaded_by_role, is_confidential, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `)
    .run(
      id,
      params.employeeId,
      params.companyId,
      params.countryId,
      params.branchId,
      params.category,
      params.title,
      params.file.originalname.slice(0, 180),
      params.file.mimetype,
      params.file.size,
      storageKey,
      params.issueDate || null,
      params.expiryDate || null,
      params.verificationStatus || 'Pending Verification',
      params.notes || null,
      params.uploadedById,
      params.uploadedByRole,
      ts
    );

  return { id, storageKey, createdAt: ts };
}

function computeEmployeeLeaveBalance(employeeId: string, leaveBalanceJson?: string | null) {
  const ent = safeJson<{ annual: number; sick: number; casual: number }>(leaveBalanceJson, { annual: 18, sick: 10, casual: 8 });
  const approved = sqlite
    .prepare("SELECT leave_type, COALESCE(SUM(total_days), 0) as used FROM employee_leave_requests WHERE employee_id = ? AND status = 'Approved' GROUP BY leave_type")
    .all(employeeId) as Array<{ leave_type: string; used: number }>;

  let usedAnnual = 0;
  let usedSick = 0;
  let usedCasual = 0;
  let usedOther = 0;
  for (const r of approved) {
    const t = String(r.leave_type || '').toLowerCase();
    if (t.includes('sick') || t.includes('medical')) usedSick += Number(r.used || 0);
    else if (t.includes('casual')) usedCasual += Number(r.used || 0);
    else if (t.includes('annual')) usedAnnual += Number(r.used || 0);
    else usedOther += Number(r.used || 0);
  }

  return {
    annual: { total: ent.annual || 18, used: usedAnnual, remaining: Math.max(0, (ent.annual || 18) - usedAnnual) },
    sick: { total: ent.sick || 10, used: usedSick, remaining: Math.max(0, (ent.sick || 10) - usedSick) },
    casual: { total: ent.casual || 8, used: usedCasual, remaining: Math.max(0, (ent.casual || 8) - usedCasual) },
    otherUsed: usedOther,
    totalRemaining:
      Math.max(0, (ent.annual || 18) - usedAnnual) +
      Math.max(0, (ent.sick || 10) - usedSick) +
      Math.max(0, (ent.casual || 8) - usedCasual),
  };
}

export function createEmployeeManagementRouter() {
  const router = express.Router();
  router.use(requireAuth);

  router.use((req: Request, res: Response, next) => {
    const scope = resolveEmpScope(req);
    if (!scope) {
      rejectUnauthorized(req, res, 'Access denied: Employee Management Module is restricted to authorized employees and leadership roles.');
      return;
    }
    (req as any).empScope = scope;
    next();
  });

  // =========================================================================
  // 1. EMPLOYEE MANAGEMENT DASHBOARD (100% REAL DB QUERIES)
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);
    const todayDate = nowIso().slice(0, 10);
    const currentMonth = todayDate.slice(0, 7);

    const activeEmployees = employees.filter((e) => e.status === 'Active').length;
    const inactiveEmployees = employees.filter((e) => e.status === 'Suspended' || e.status === 'Inactive').length;
    const onLeaveEmployees = employees.filter((e) => e.status === 'On Leave').length;

    let presentToday = 0;
    let absentToday = 0;
    let lateToday = 0;
    let halfDayToday = 0;
    let totalMonthlyPayroll = 0;
    let paidMonthlyPayroll = 0;
    let pendingLeavesCount = 0;
    let expiringDocsCount = 0;
    const attendance7DayTrend: Array<{ date: string; present: number; late: number; absent: number }> = [];

    if (empIds.length > 0) {
      const ph = empIds.map(() => '?').join(',');
      const todayAtt = sqlite
        .prepare(`SELECT status FROM employee_attendance WHERE attendance_date = ? AND employee_id IN (${ph})`)
        .all(todayDate, ...empIds) as Array<{ status: string }>;

      presentToday = todayAtt.filter((a) => ['Present', 'Remote'].includes(a.status)).length;
      lateToday = todayAtt.filter((a) => a.status === 'Late').length;
      halfDayToday = todayAtt.filter((a) => a.status === 'Half Day').length;
      const markedAbsent = todayAtt.filter((a) => a.status === 'Absent').length;
      absentToday = markedAbsent;

      // Active employees on approved leave today
      const approvedLeaveToday = (
        sqlite
          .prepare(`SELECT COUNT(DISTINCT employee_id) as c FROM employee_leave_requests WHERE status = 'Approved' AND ? BETWEEN start_date AND end_date AND employee_id IN (${ph})`)
          .get(todayDate, ...empIds) as any
      ).c;

      // Monthly Payroll Totals (only employees whose payroll can be seen)
      if (scope.canAccessPayroll || scope.selfOnly) {
        const payrollRows = sqlite
          .prepare(`SELECT net_salary, payment_status FROM employee_salary_records WHERE pay_period = ? AND employee_id IN (${ph})`)
          .all(currentMonth, ...empIds) as Array<{ net_salary: number; payment_status: string }>;
        totalMonthlyPayroll = payrollRows.reduce((s, r) => s + Number(r.net_salary || 0), 0);
        paidMonthlyPayroll = payrollRows.filter((r) => r.payment_status === 'Paid').reduce((s, r) => s + Number(r.net_salary || 0), 0);
      }

      pendingLeavesCount = (
        sqlite
          .prepare(`SELECT COUNT(*) as c FROM employee_leave_requests WHERE status = 'Pending' AND employee_id IN (${ph})`)
          .get(...empIds) as any
      ).c;

      const plus30Days = new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10);
      expiringDocsCount = (
        sqlite
          .prepare(`SELECT COUNT(*) as c FROM employee_documents WHERE expiry_date IS NOT NULL AND expiry_date != '' AND expiry_date <= ? AND employee_id IN (${ph})`)
          .get(plus30Days, ...empIds) as any
      ).c;

      for (let i = 6; i >= 0; i -= 1) {
        const d = new Date(Date.now() - i * 86400_000).toISOString().slice(0, 10);
        const dayRows = sqlite
          .prepare(`SELECT status FROM employee_attendance WHERE attendance_date = ? AND employee_id IN (${ph})`)
          .all(d, ...empIds) as Array<{ status: string }>;
        attendance7DayTrend.push({
          date: d,
          present: dayRows.filter((x) => ['Present', 'Remote', 'Half Day'].includes(x.status)).length,
          late: dayRows.filter((x) => x.status === 'Late').length,
          absent: dayRows.filter((x) => x.status === 'Absent').length,
        });
      }

      // Override onLeaveEmployees if approved leaves exist today
      const effectiveOnLeave = Math.max(onLeaveEmployees, approvedLeaveToday);

      const deptMap = new Map<string, number>();
      const branchMap = new Map<string, number>();
      for (const e of employees) {
        const dn = e.department || 'Unassigned';
        deptMap.set(dn, (deptMap.get(dn) || 0) + 1);
        const bn = e.branch_name || 'Head Office';
        branchMap.set(bn, (branchMap.get(bn) || 0) + 1);
      }

      const recentLogs = sqlite
        .prepare(`SELECT * FROM employee_audit_logs WHERE (employee_id IN (${ph}) OR employee_id IS NULL) ORDER BY created_at DESC LIMIT 20`)
        .all(...empIds)
        .filter((l: any) => !scope.restrictedCompanyId || !l.company_id || l.company_id === scope.restrictedCompanyId);

      const companies = sqlite
        .prepare('SELECT id, name, country, city, status FROM companies ORDER BY name ASC')
        .all()
        .filter((c: any) => !scope.restrictedCompanyId || c.id === scope.restrictedCompanyId);

      const branches = sqlite
        .prepare('SELECT id, company_id, country_id, name, code, city FROM branches ORDER BY name ASC')
        .all()
        .filter((b: any) => (!scope.restrictedCompanyId || b.company_id === scope.restrictedCompanyId) && (!scope.restrictedBranchId || b.id === scope.restrictedBranchId) && (!scope.restrictedCountryId || String(b.country_id).toUpperCase() === scope.restrictedCountryId));

      const departments = sqlite
        .prepare('SELECT id, company_id, branch_id, name, code, head_name FROM employee_departments ORDER BY name ASC')
        .all()
        .filter((d: any) => !scope.restrictedCompanyId || d.company_id === scope.restrictedCompanyId);

      const countries = sqlite
        .prepare('SELECT id, code, name, flag_emoji, currency FROM countries ORDER BY name ASC')
        .all()
        .filter((co: any) => !scope.restrictedCountryId || co.id.toUpperCase() === scope.restrictedCountryId);

      res.json({
        scope,
        payPeriod: currentMonth,
        todayDate,
        metrics: {
          totalEmployees: employees.length,
          activeEmployees,
          inactiveEmployees,
          onLeaveEmployees: effectiveOnLeave,
          presentToday,
          absentToday,
          lateArrivalsToday: lateToday,
          halfDayToday,
          totalMonthlyPayroll,
          paidMonthlyPayroll,
          pendingLeavesCount,
          expiringDocsCount,
        },
        departmentDistribution: Array.from(deptMap.entries()).map(([department, count]) => ({ department, count })),
        branchDistribution: Array.from(branchMap.entries()).map(([branch, count]) => ({ branch, count })),
        attendance7DayTrend,
        recentAuditLogs: recentLogs,
        referenceData: {
          companies,
          branches,
          departments,
          countries,
          leaveTypes: LEAVE_TYPES,
          documentCategories: DOCUMENT_CATEGORIES,
        },
      });
      return;
    }

    const companies = sqlite
      .prepare('SELECT id, name, country, city, status FROM companies ORDER BY name ASC')
      .all()
      .filter((c: any) => !scope.restrictedCompanyId || c.id === scope.restrictedCompanyId);
    const branches = sqlite
      .prepare('SELECT id, company_id, country_id, name, code, city FROM branches ORDER BY name ASC')
      .all()
      .filter((b: any) => (!scope.restrictedCompanyId || b.company_id === scope.restrictedCompanyId) && (!scope.restrictedBranchId || b.id === scope.restrictedBranchId));
    const departments = sqlite
      .prepare('SELECT id, company_id, branch_id, name, code, head_name FROM employee_departments ORDER BY name ASC')
      .all()
      .filter((d: any) => !scope.restrictedCompanyId || d.company_id === scope.restrictedCompanyId);
    const countries = sqlite.prepare('SELECT id, code, name, flag_emoji, currency FROM countries ORDER BY name ASC').all();

    res.json({
      scope,
      payPeriod: currentMonth,
      todayDate,
      metrics: {
        totalEmployees: 0,
        activeEmployees: 0,
        inactiveEmployees: 0,
        onLeaveEmployees: 0,
        presentToday: 0,
        absentToday: 0,
        lateArrivalsToday: 0,
        halfDayToday: 0,
        totalMonthlyPayroll: 0,
        paidMonthlyPayroll: 0,
        pendingLeavesCount: 0,
        expiringDocsCount: 0,
      },
      departmentDistribution: [],
      branchDistribution: [],
      attendance7DayTrend: [],
      recentAuditLogs: [],
      referenceData: {
        companies,
        branches,
        departments,
        countries,
        leaveTypes: LEAVE_TYPES,
        documentCategories: DOCUMENT_CATEGORIES,
      },
    });
  });

  // =========================================================================
  // 2. EMPLOYEE ID GENERATOR & COMPLETE PROFILES CRUD
  // =========================================================================
  router.get('/employees/next-code', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canManageProfiles) {
      rejectUnauthorized(req, res, 'Permission denied: cannot reserve new employee IDs.');
      return;
    }
    const companyId = scope.restrictedCompanyId || String(req.query.companyId || 'comp_byd_pk').trim();
    const countryId = scope.restrictedCountryId || String(req.query.countryId || 'PK').trim().toUpperCase();
    res.json({ nextEmployeeCode: generateNextEmployeeCode(companyId, countryId) });
  });

  router.get('/employees', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const q = String(req.query.q || '').trim().toLowerCase();
    const branchId = String(req.query.branchId || '').trim();
    const department = String(req.query.department || '').trim();
    const status = String(req.query.status || '').trim();
    const employmentType = String(req.query.employmentType || '').trim();
    const companyId = String(req.query.companyId || '').trim();
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(200, Math.max(1, Number(req.query.limit || 50)));

    const rows = getScopedEmployeeRows(scope).filter((r) => {
      if (companyId && companyId !== 'ALL' && r.company_id !== companyId) return false;
      if (branchId && branchId !== 'ALL' && r.branch_id !== branchId) return false;
      if (department && department !== 'ALL' && String(r.department || '').toLowerCase() !== department.toLowerCase()) return false;
      if (status && status !== 'ALL' && r.status !== status) return false;
      if (employmentType && employmentType !== 'ALL' && String(r.employment_type || '').toLowerCase() !== employmentType.toLowerCase()) return false;
      if (q) {
        const hay = `${r.employee_code} ${r.full_name} ${r.email} ${r.mobile} ${r.department} ${r.job_position} ${r.branch_name || ''} ${r.cnic_number || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const total = rows.length;
    const offset = (page - 1) * limit;
    const paged = rows.slice(offset, offset + limit).map((e) => {
      const revealPii = scope.canViewPii || e.id === req.auth?.employeeId;
      const revealPay = scope.canAccessPayroll || e.id === req.auth?.employeeId;
      const cnic = e.cnic_number || e.prof_cnic || '';
      const iban = e.bank_iban || e.ss_iban || '';
      return {
        id: e.id,
        employeeCode: e.employee_code,
        fullName: e.full_name,
        fatherName: e.father_name || '',
        dateOfBirth: e.date_of_birth || e.prof_dob || '',
        gender: e.gender || e.prof_gender || '',
        cnicNumber: maskSensitive(cnic, revealPii),
        cnicMasked: !revealPii && Boolean(cnic),
        email: e.email,
        mobile: e.mobile,
        residentialAddress: e.residential_address || e.prof_address || '',
        countryId: e.country_id || 'PK',
        countryName: e.country_name || e.country_id || 'Pakistan',
        city: e.city || e.prof_city || e.branch_city || '',
        companyId: e.company_id,
        companyName: e.company_name,
        branchId: e.branch_id,
        branchName: e.branch_name || 'Head Office',
        branchCode: e.branch_code || null,
        departmentId: e.department_id,
        department: e.department,
        jobPosition: e.job_position,
        reportingManagerId: e.reporting_manager_id,
        reportingManagerName: e.reporting_manager_name || 'Assigned Manager',
        joiningDate: e.joined_at,
        employmentType: e.employment_type || e.prof_emp_type || 'Full-Time',
        status: e.status,
        basicSalary: revealPay ? Number(e.ss_basic ?? e.basic_salary ?? 0) : null,
        currency: e.ss_currency || e.country_currency || 'PKR',
        emergencyContactName: e.emergency_contact_name || e.prof_emg_name || '',
        emergencyContactPhone: e.emergency_contact_phone || e.prof_emg_phone || '',
        bankName: e.bank_name || e.ss_bank || '',
        bankAccountTitle: e.bank_account_title || e.ss_bank_title || '',
        bankIban: maskSensitive(iban, revealPii || scope.canAccessPayroll),
        photoDocId: e.photo_doc_id || null,
        photoUrl: e.photo_doc_id ? `/api/employee-management/documents/${e.photo_doc_id}/download?inline=1` : null,
        performanceScore: e.performance_score,
        piiRevealed: revealPii,
      };
    });

    res.json({
      employees: paged,
      pagination: { total, page, limit, totalPages: Math.max(1, Math.ceil(total / limit)) },
    });
  });

  router.get('/employees/:id', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const empRow = getScopedEmployeeRows({ ...scope, selfOnly: false }).find((r) => r.id === req.params.id);
    const rawEmp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!rawEmp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (!canActorAccessEmployee(scope, rawEmp) || !empRow) {
      rejectUnauthorized(req, res, 'Access Denied: You cannot view another employee profile outside your authorized scope.');
      return;
    }

    const revealPii = scope.canViewPii || rawEmp.id === req.auth?.employeeId;
    const revealPay = scope.canAccessPayroll || rawEmp.id === req.auth?.employeeId;

    const salaryStructure = revealPay
      ? sqlite.prepare('SELECT * FROM employee_salary_structures WHERE employee_id = ?').get(rawEmp.id)
      : null;
    const payrollHistory = revealPay
      ? sqlite.prepare('SELECT * FROM employee_salary_records WHERE employee_id = ? ORDER BY pay_period DESC LIMIT 24').all(rawEmp.id)
      : [];
    const attendance = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? ORDER BY attendance_date DESC LIMIT 45')
      .all(rawEmp.id);
    const leaveBalance = computeEmployeeLeaveBalance(rawEmp.id, rawEmp.leave_balance_json);
    const leaves = sqlite
      .prepare('SELECT * FROM employee_leave_requests WHERE employee_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(rawEmp.id);
    const history = sqlite
      .prepare('SELECT * FROM employee_history WHERE employee_id = ? ORDER BY created_at DESC LIMIT 60')
      .all(rawEmp.id);
    const reviews = sqlite
      .prepare('SELECT * FROM employee_performance_reviews WHERE employee_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(rawEmp.id)
      .filter((r: any) => !scope.selfOnly || r.visibility === 'EmployeeVisible');
    const targets = sqlite
      .prepare('SELECT * FROM employee_targets WHERE employee_id = ? ORDER BY created_at DESC')
      .all(rawEmp.id);
    const documents = sqlite
      .prepare('SELECT id, category, title, original_filename, mime_type, size_bytes, issue_date, expiry_date, verification_status, uploaded_by_role, created_at FROM employee_documents WHERE employee_id = ? ORDER BY created_at DESC')
      .all(rawEmp.id);
    const auditLogs = sqlite
      .prepare('SELECT * FROM employee_audit_logs WHERE employee_id = ? ORDER BY created_at DESC LIMIT 40')
      .all(rawEmp.id);

    const cnic = empRow.cnic_number || empRow.prof_cnic || '';
    const iban = empRow.bank_iban || empRow.ss_iban || '';

    res.json({
      employee: {
        id: empRow.id,
        employeeCode: empRow.employee_code,
        fullName: empRow.full_name,
        fatherName: empRow.father_name || '',
        dateOfBirth: empRow.date_of_birth || empRow.prof_dob || '',
        gender: empRow.gender || empRow.prof_gender || '',
        cnicNumber: maskSensitive(cnic, revealPii),
        rawCnic: revealPii ? cnic : undefined,
        email: empRow.email,
        mobile: empRow.mobile,
        residentialAddress: empRow.residential_address || empRow.prof_address || '',
        countryId: empRow.country_id || 'PK',
        countryName: empRow.country_name || 'Pakistan',
        city: empRow.city || empRow.prof_city || empRow.branch_city || '',
        companyId: empRow.company_id,
        companyName: empRow.company_name,
        branchId: empRow.branch_id,
        branchName: empRow.branch_name || 'Head Office',
        departmentId: empRow.department_id,
        department: empRow.department,
        jobPosition: empRow.job_position,
        reportingManagerId: empRow.reporting_manager_id,
        reportingManagerName: empRow.reporting_manager_name || 'Assigned Manager',
        joiningDate: empRow.joined_at,
        employmentType: empRow.employment_type || empRow.prof_emp_type || 'Full-Time',
        status: empRow.status,
        basicSalary: revealPay ? Number(empRow.ss_basic ?? empRow.basic_salary ?? 0) : null,
        currency: empRow.ss_currency || empRow.country_currency || 'PKR',
        emergencyContactName: empRow.emergency_contact_name || empRow.prof_emg_name || '',
        emergencyContactPhone: empRow.emergency_contact_phone || empRow.prof_emg_phone || '',
        bankName: empRow.bank_name || empRow.ss_bank || '',
        bankAccountTitle: empRow.bank_account_title || empRow.ss_bank_title || '',
        bankIban: maskSensitive(iban, revealPii || scope.canAccessPayroll),
        photoDocId: empRow.photo_doc_id || null,
        photoUrl: empRow.photo_doc_id ? `/api/employee-management/documents/${empRow.photo_doc_id}/download?inline=1` : null,
        performanceScore: empRow.performance_score,
      },
      salaryStructure,
      payrollHistory,
      attendance,
      leaveBalance,
      leaves,
      history,
      reviews,
      targets,
      documents,
      auditLogs,
    });
  });

  router.post('/employees', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canManageProfiles) {
      rejectUnauthorized(req, res, 'Permission denied: you are not authorized to register new employees.');
      return;
    }

    const b = req.body || {};
    const fullName = String(b.fullName || '').trim();
    const email = String(b.email || '').trim().toLowerCase();
    const mobile = String(b.mobile || '').trim();
    const companyId = scope.restrictedCompanyId || String(b.companyId || '').trim();
    const countryId = (scope.restrictedCountryId || String(b.countryId || 'PK')).trim().toUpperCase();
    const branchId = scope.restrictedBranchId || (b.branchId ? String(b.branchId).trim() : null);
    const department = String(b.department || 'Operations').trim();
    let departmentId = b.departmentId ? String(b.departmentId).trim() : null;
    const jobPosition = String(b.jobPosition || '').trim();
    const employmentType = String(b.employmentType || 'Full-Time Permanent').trim();
    const joiningDate = String(b.joiningDate || nowIso().slice(0, 10)).slice(0, 10);
    const password = String(b.password || '').trim();
    const fatherName = String(b.fatherName || '').trim();
    const dateOfBirth = String(b.dateOfBirth || '').trim();
    const gender = String(b.gender || '').trim();
    const cnicNumber = String(b.cnicNumber || '').trim();
    const residentialAddress = String(b.residentialAddress || '').trim();
    const city = String(b.city || '').trim();
    const reportingManagerId = b.reportingManagerId ? String(b.reportingManagerId).trim() : null;
    let reportingManagerName = String(b.reportingManagerName || '').trim();
    const basicSalary = Math.max(0, Number(b.basicSalary || 0));
    const houseAllowance = Math.max(0, Number(b.houseAllowance || 0));
    const medicalAllowance = Math.max(0, Number(b.medicalAllowance || 0));
    const transportAllowance = Math.max(0, Number(b.transportAllowance || 0));
    const otherAllowances = Math.max(0, Number(b.otherAllowances || 0));
    const taxDeduction = Math.max(0, Number(b.taxDeduction || 0));
    const emergencyContactName = String(b.emergencyContactName || '').trim();
    const emergencyContactPhone = String(b.emergencyContactPhone || '').trim();
    const bankName = String(b.bankName || '').trim();
    const bankAccountTitle = String(b.bankAccountTitle || '').trim();
    const bankIban = String(b.bankIban || '').trim();

    if (!fullName || !email || !mobile || !companyId || !jobPosition || !department) {
      res.status(400).json({ error: 'Full name, email, mobile, company, department, and job position are required.' });
      return;
    }

    const pwCheck = validatePasswordStrength(password);
    if (!pwCheck.valid) {
      res.status(400).json({ error: pwCheck.reason });
      return;
    }

    const comp = sqlite.prepare('SELECT id, name FROM companies WHERE id = ?').get(companyId) as any;
    if (!comp) {
      res.status(404).json({ error: 'Parent company not found.' });
      return;
    }

    if (branchId) {
      const br = sqlite.prepare('SELECT id, company_id, country_id FROM branches WHERE id = ?').get(branchId) as any;
      if (!br || br.company_id !== companyId) {
        res.status(400).json({ error: 'Invalid hierarchy: assigned branch must belong to the parent company.' });
        return;
      }
    }

    if (!departmentId) {
      const existingDept = sqlite
        .prepare('SELECT id FROM employee_departments WHERE company_id = ? AND LOWER(name) = LOWER(?) LIMIT 1')
        .get(companyId, department) as any;
      if (existingDept) departmentId = existingDept.id;
    }

    const dupEmail =
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM user_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (dupEmail) {
      res.status(409).json({ error: 'An employee or user account with this email already exists.' });
      return;
    }

    if (cnicNumber) {
      const dupCnic = sqlite
        .prepare("SELECT id, employee_code FROM employee_accounts WHERE cnic_number != '' AND LOWER(cnic_number) = LOWER(?)")
        .get(cnicNumber) as any;
      if (dupCnic) {
        res.status(409).json({ error: `CNIC "${cnicNumber}" is already registered to employee ${dupCnic.employee_code}.` });
        return;
      }
    }

    if (reportingManagerId && !reportingManagerName) {
      const rm = sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(reportingManagerId) as any;
      if (rm) reportingManagerName = rm.full_name;
    }

    const countryRow = sqlite.prepare('SELECT currency FROM countries WHERE UPPER(id) = ?').get(countryId) as any;
    const currency = countryRow?.currency || 'PKR';

    const settings = sqlite.prepare('SELECT * FROM employee_module_settings WHERE company_id = ?').get(companyId) as any;
    const leaveBal = {
      annual: settings?.annual_leave_default ?? 18,
      sick: settings?.sick_leave_default ?? 10,
      casual: settings?.casual_leave_default ?? 8,
    };

    const empId = `emp_${generateSecureToken(6)}`;
    let employeeCode = '';
    const ts = nowIso();
    const baseUser = email.split('@')[0].replace(/[^a-zA-Z0-9._-]/g, '').slice(0, 24) || 'emp';
    const username = `${baseUser}_${generateSecureToken(2)}`;
    const permissions = Array.isArray(b.permissions) && b.permissions.length > 0
      ? b.permissions.map((x: unknown) => String(x).trim())
      : [
          'employee.profile.manage',
          'employee.attendance.manage',
          'employee.leave.manage',
          'employee.tasks.manage',
          'employee.salary.view',
          'employee.documents.manage',
          'employee.performance.view',
          'employee.support.manage',
        ];

    sqlite.transaction(() => {
      employeeCode = generateNextEmployeeCode(companyId, countryId);
      sqlite
        .prepare(`
          INSERT INTO employee_accounts (
            id, company_id, branch_id, country_id, department_id, reporting_manager_id, reporting_manager_name,
            employee_code, full_name, email, mobile, department, job_position, employment_type,
            father_name, date_of_birth, gender, cnic_number, residential_address, city, basic_salary,
            emergency_contact_name, emergency_contact_phone, bank_name, bank_account_title, bank_iban,
            status, permissions_json, leave_balance_json, username, password_hash, email_verified,
            two_factor_enabled, personal_info_json, joined_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, 1, 0, ?, ?, ?, ?)
        `)
        .run(
          empId,
          companyId,
          branchId,
          countryId,
          departmentId,
          reportingManagerId,
          reportingManagerName || 'Assigned Manager',
          employeeCode,
          fullName,
          email,
          mobile,
          department,
          jobPosition,
          employmentType,
          fatherName,
          dateOfBirth,
          gender,
          cnicNumber,
          residentialAddress,
          city,
          basicSalary,
          emergencyContactName,
          emergencyContactPhone,
          bankName,
          bankAccountTitle,
          bankIban,
          JSON.stringify(permissions),
          JSON.stringify(leaveBal),
          username,
          hashPassword(password),
          JSON.stringify({ cnic: cnicNumber, emergencyContact: emergencyContactPhone }),
          joiningDate,
          ts,
          ts
        );

      sqlite
        .prepare(`
          INSERT INTO employee_profiles (
            id, employee_id, company_id, country_id, branch_id, department_id, reporting_manager_id,
            reporting_manager_name, date_of_birth, gender, cnic_or_id, address, city,
            emergency_contact_name, emergency_contact_phone, employment_type, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          `eprof_${generateSecureToken(5)}`,
          empId,
          companyId,
          countryId,
          branchId,
          departmentId,
          reportingManagerId,
          reportingManagerName || 'Assigned Manager',
          dateOfBirth || null,
          gender || null,
          cnicNumber || null,
          residentialAddress,
          city || 'Lahore',
          emergencyContactName,
          emergencyContactPhone,
          employmentType,
          ts
        );

      sqlite
        .prepare(`
          INSERT INTO employee_salary_structures (
            id, employee_id, company_id, currency, basic_salary, house_allowance, medical_allowance,
            transport_allowance, other_allowances, tax_deduction, other_deductions,
            bank_name, bank_account_title, bank_iban, effective_from, updated_by, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          `ess_${generateSecureToken(5)}`,
          empId,
          companyId,
          currency,
          basicSalary,
          houseAllowance,
          medicalAllowance,
          transportAllowance,
          otherAllowances,
          taxDeduction,
          bankName,
          bankAccountTitle,
          bankIban,
          joiningDate,
          req.auth!.fullName,
          ts,
          ts
        );

      if (branchId) {
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO branch_employee_relationships (
              id, branch_id, company_id, employee_id, employee_code, assigned_by, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
          `)
          .run(`ber_${generateSecureToken(5)}`, branchId, companyId, empId, employeeCode, req.auth!.fullName, ts);
      }

      sqlite
        .prepare(`
          INSERT OR REPLACE INTO user_accounts (
            id, subject_type, source_table, role, full_name, email, mobile, company_id, country_id, branch_id,
            account_code, status, verification_status, email_verified, mobile_verified, mfa_enabled,
            approved_by, approved_at, created_at, updated_at
          ) VALUES (?, 'employee', 'employee_accounts', ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 'Verified', 1, 1, 0, ?, ?, ?, ?)
        `)
        .run(empId, jobPosition, fullName, email, mobile, companyId, countryId, branchId, employeeCode, req.auth!.fullName, ts, ts, ts);
    })();

    recordEmployeeHistory({
      employeeId: empId,
      companyId,
      changeType: 'Profile',
      previousValue: null,
      newValue: `${employeeCode} | ${jobPosition} (${department})`,
      effectiveDate: joiningDate,
      notes: `Employee registered by ${req.auth!.fullName}`,
      changedById: req.auth!.userId,
      changedByName: req.auth!.fullName,
    });

    logEmployeeAudit({
      employeeId: empId,
      companyId,
      branchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_CREATED',
      module: 'Employee Profiles',
      targetId: employeeCode,
      details: `Created employee ${fullName} (${employeeCode}) — ${jobPosition}, ${department}`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, id: empId, employeeCode });
  });

  router.patch('/employees/:id', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (!scope.canManageProfiles || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: you are not authorized to modify this employee profile.');
      return;
    }

    const b = req.body || {};
    if (b.employeeCode !== undefined && String(b.employeeCode).trim() !== emp.employee_code) {
      rejectUnauthorized(req, res, 'Security violation: Employee ID codes are system-generated and immutable.');
      return;
    }

    const fullName = b.fullName !== undefined ? String(b.fullName).trim() : emp.full_name;
    const mobile = b.mobile !== undefined ? String(b.mobile).trim() : emp.mobile;
    const fatherName = b.fatherName !== undefined ? String(b.fatherName).trim() : emp.father_name;
    const dateOfBirth = b.dateOfBirth !== undefined ? String(b.dateOfBirth).trim() : emp.date_of_birth;
    const gender = b.gender !== undefined ? String(b.gender).trim() : emp.gender;
    const cnicNumber = b.cnicNumber !== undefined ? String(b.cnicNumber).trim() : emp.cnic_number;
    const residentialAddress = b.residentialAddress !== undefined ? String(b.residentialAddress).trim() : emp.residential_address;
    const city = b.city !== undefined ? String(b.city).trim() : emp.city;
    const countryId = b.countryId !== undefined ? String(b.countryId).trim().toUpperCase() : emp.country_id;
    const branchId = b.branchId !== undefined ? (b.branchId ? String(b.branchId).trim() : null) : emp.branch_id;
    const department = b.department !== undefined ? String(b.department).trim() : emp.department;
    const jobPosition = b.jobPosition !== undefined ? String(b.jobPosition).trim() : emp.job_position;
    const employmentType = b.employmentType !== undefined ? String(b.employmentType).trim() : emp.employment_type;
    const reportingManagerName = b.reportingManagerName !== undefined ? String(b.reportingManagerName).trim() : emp.reporting_manager_name;
    const emergencyContactName = b.emergencyContactName !== undefined ? String(b.emergencyContactName).trim() : emp.emergency_contact_name;
    const emergencyContactPhone = b.emergencyContactPhone !== undefined ? String(b.emergencyContactPhone).trim() : emp.emergency_contact_phone;
    const bankName = b.bankName !== undefined ? String(b.bankName).trim() : emp.bank_name;
    const bankAccountTitle = b.bankAccountTitle !== undefined ? String(b.bankAccountTitle).trim() : emp.bank_account_title;
    const bankIban = b.bankIban !== undefined ? String(b.bankIban).trim() : emp.bank_iban;
    const basicSalary = b.basicSalary !== undefined ? Math.max(0, Number(b.basicSalary)) : Number(emp.basic_salary || 0);

    const ts = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare(`
          UPDATE employee_accounts
          SET full_name = ?, mobile = ?, father_name = ?, date_of_birth = ?, gender = ?, cnic_number = ?,
              residential_address = ?, city = ?, country_id = ?, branch_id = ?, department = ?,
              job_position = ?, employment_type = ?, reporting_manager_name = ?,
              emergency_contact_name = ?, emergency_contact_phone = ?,
              bank_name = ?, bank_account_title = ?, bank_iban = ?, basic_salary = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          fullName,
          mobile,
          fatherName,
          dateOfBirth,
          gender,
          cnicNumber,
          residentialAddress,
          city,
          countryId,
          branchId,
          department,
          jobPosition,
          employmentType,
          reportingManagerName,
          emergencyContactName,
          emergencyContactPhone,
          bankName,
          bankAccountTitle,
          bankIban,
          basicSalary,
          ts,
          emp.id
        );

      sqlite
        .prepare(`
          UPDATE employee_profiles
          SET branch_id = ?, reporting_manager_name = ?, date_of_birth = ?, gender = ?, cnic_or_id = ?,
              address = ?, city = ?, emergency_contact_name = ?, emergency_contact_phone = ?,
              employment_type = ?, updated_at = ?
          WHERE employee_id = ?
        `)
        .run(branchId, reportingManagerName, dateOfBirth, gender, cnicNumber, residentialAddress, city, emergencyContactName, emergencyContactPhone, employmentType, ts, emp.id);

      sqlite
        .prepare('UPDATE user_accounts SET full_name = ?, role = ?, branch_id = ?, country_id = ?, updated_at = ? WHERE id = ?')
        .run(fullName, jobPosition, branchId, countryId, ts, emp.id);

      if (b.basicSalary !== undefined && Number(b.basicSalary) !== Number(emp.basic_salary || 0)) {
        sqlite
          .prepare('UPDATE employee_salary_structures SET basic_salary = ?, bank_name = ?, bank_account_title = ?, bank_iban = ?, updated_by = ?, updated_at = ? WHERE employee_id = ?')
          .run(basicSalary, bankName, bankAccountTitle, bankIban, req.auth!.fullName, ts, emp.id);
        recordEmployeeHistory({
          employeeId: emp.id,
          companyId: emp.company_id,
          changeType: 'Salary',
          previousValue: String(emp.basic_salary || 0),
          newValue: String(basicSalary),
          notes: 'Basic salary updated via Employee Profile.',
          changedById: req.auth!.userId,
          changedByName: req.auth!.fullName,
        });
      }
    })();

    if (branchId !== emp.branch_id) {
      recordEmployeeHistory({
        employeeId: emp.id,
        companyId: emp.company_id,
        changeType: 'Transfer',
        previousValue: emp.branch_id || 'Head Office',
        newValue: branchId || 'Head Office',
        notes: 'Branch updated via profile',
        changedById: req.auth!.userId,
        changedByName: req.auth!.fullName,
      });
    }
    if (jobPosition !== emp.job_position || department !== emp.department) {
      recordEmployeeHistory({
        employeeId: emp.id,
        companyId: emp.company_id,
        changeType: 'Position',
        previousValue: `${emp.job_position} (${emp.department})`,
        newValue: `${jobPosition} (${department})`,
        notes: 'Position/department updated via profile',
        changedById: req.auth!.userId,
        changedByName: req.auth!.fullName,
      });
    }

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_UPDATED',
      module: 'Employee Profiles',
      targetId: emp.employee_code,
      details: `Updated profile for ${fullName} (${emp.employee_code})`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  router.patch('/employees/:id/status', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (!scope.canToggleStatus || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: cannot activate/deactivate employees.');
      return;
    }

    const nextStatus = String(req.body.status || '').trim();
    if (!['Active', 'Inactive', 'Suspended', 'On Leave'].includes(nextStatus)) {
      res.status(400).json({ error: 'Valid status required: Active, Inactive, Suspended, or On Leave.' });
      return;
    }
    const reason = String(req.body.reason || 'Administrative status update').trim();
    const ts = nowIso();

    sqlite.transaction(() => {
      sqlite.prepare('UPDATE employee_accounts SET status = ?, updated_at = ? WHERE id = ?').run(nextStatus, ts, emp.id);
      sqlite.prepare('UPDATE user_accounts SET status = ?, updated_at = ? WHERE id = ?').run(nextStatus, ts, emp.id);
    })();

    recordEmployeeHistory({
      employeeId: emp.id,
      companyId: emp.company_id,
      changeType: 'Status',
      previousValue: emp.status,
      newValue: nextStatus,
      notes: reason,
      changedById: req.auth!.userId,
      changedByName: req.auth!.fullName,
    });

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_STATUS_CHANGED',
      module: 'Employee Profiles',
      targetId: emp.employee_code,
      details: `${emp.employee_code}: ${emp.status} -> ${nextStatus}. Reason: ${reason}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status: nextStatus });
  });

  router.post('/employees/:id/photo', upload.single('photo'), (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    const isSelf = req.auth?.employeeId === emp.id;
    if ((!scope.canManageProfiles && !isSelf) || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: cannot update profile photo.');
      return;
    }
    if (!req.file || !['image/jpeg', 'image/png', 'image/webp'].includes(req.file.mimetype)) {
      res.status(400).json({ error: 'Valid JPG, PNG, or WEBP profile image is required (max 5MB).' });
      return;
    }

    try {
      const saved = savePrivateEmployeeDocFile({
        file: req.file,
        employeeId: emp.id,
        companyId: emp.company_id,
        countryId: emp.country_id || 'PK',
        branchId: emp.branch_id || null,
        category: 'Profile Photo',
        title: `Profile Photograph — ${emp.employee_code}`,
        verificationStatus: 'Verified',
        uploadedById: req.auth!.userId,
        uploadedByRole: req.auth!.role,
      });
      const ts = nowIso();
      sqlite.prepare('UPDATE employee_accounts SET photo_doc_id = ?, updated_at = ? WHERE id = ?').run(saved.id, ts, emp.id);
      sqlite.prepare('UPDATE employee_profiles SET photo_doc_id = ?, updated_at = ? WHERE employee_id = ?').run(saved.id, ts, emp.id);

      logEmployeeAudit({
        employeeId: emp.id,
        companyId: emp.company_id,
        branchId: emp.branch_id,
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'EMPLOYEE_PHOTO_UPDATED',
        module: 'Employee Profiles',
        targetId: saved.id,
        details: `Uploaded profile photo for ${emp.employee_code}`,
        ipAddress: getClientIp(req),
      });
      res.status(201).json({ success: true, photoDocId: saved.id, photoUrl: `/api/employee-management/documents/${saved.id}/download?inline=1` });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Photo upload failed.' });
    }
  });

  // =========================================================================
  // 3. ATTENDANCE MANAGEMENT (DAILY PUNCHES, MARKING, AUDIT, REPORTS)
  // =========================================================================
  router.get('/attendance', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);

    const dateFilter = String(req.query.date || '').slice(0, 10);
    const monthFilter = String(req.query.month || '').slice(0, 7);
    const branchFilter = String(req.query.branchId || '').trim();
    const deptFilter = String(req.query.department || '').trim();
    const statusFilter = String(req.query.status || '').trim();
    const employeeFilter = String(req.query.employeeId || '').trim();

    if (empIds.length === 0) {
      res.json({ records: [], summary: { total: 0, present: 0, late: 0, absent: 0, halfDay: 0, totalHours: 0, overtimeHours: 0 } });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const rows = sqlite
      .prepare(`
        SELECT a.*, e.employee_code, e.full_name, e.department, e.job_position, b.name as branch_name
        FROM employee_attendance a
        JOIN employee_accounts e ON e.id = a.employee_id
        LEFT JOIN branches b ON b.id = COALESCE(a.branch_id, e.branch_id)
        WHERE a.employee_id IN (${ph})
        ORDER BY a.attendance_date DESC, e.full_name ASC
        LIMIT 400
      `)
      .all(...empIds) as any[];

    const filtered = rows.filter((r) => {
      if (dateFilter && r.attendance_date !== dateFilter) return false;
      if (monthFilter && !String(r.attendance_date).startsWith(monthFilter)) return false;
      if (branchFilter && branchFilter !== 'ALL' && r.branch_id !== branchFilter) return false;
      if (deptFilter && deptFilter !== 'ALL' && String(r.department).toLowerCase() !== deptFilter.toLowerCase()) return false;
      if (statusFilter && statusFilter !== 'ALL' && r.status !== statusFilter) return false;
      if (employeeFilter && employeeFilter !== 'ALL' && r.employee_id !== employeeFilter) return false;
      return true;
    });

    res.json({
      records: filtered,
      summary: {
        total: filtered.length,
        present: filtered.filter((r) => ['Present', 'Remote'].includes(r.status)).length,
        late: filtered.filter((r) => r.status === 'Late').length,
        absent: filtered.filter((r) => r.status === 'Absent').length,
        halfDay: filtered.filter((r) => r.status === 'Half Day').length,
        totalHours: Number(filtered.reduce((s, r) => s + Number(r.working_hours || 0), 0).toFixed(2)),
        overtimeHours: Number(filtered.reduce((s, r) => s + Number(r.overtime_hours || 0), 0).toFixed(2)),
      },
    });
  });

  router.post('/attendance/mark', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const b = req.body || {};
    const targetEmpId = b.employeeId ? String(b.employeeId).trim() : req.auth?.employeeId || '';
    const action = String(b.action || 'mark').toLowerCase(); // 'check-in' | 'check-out' | 'mark'
    const attendanceDate = String(b.attendanceDate || nowIso().slice(0, 10)).slice(0, 10);

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(targetEmpId) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }

    const isSelfPunch = req.auth?.employeeId === emp.id && (action === 'check-in' || action === 'check-out');
    if (!isSelfPunch && (!scope.canManageAttendance || !canActorAccessEmployee(scope, emp))) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized HR / Managers can record or edit employee attendance.');
      return;
    }

    const existing = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?')
      .get(emp.id, attendanceDate) as any;

    const now = new Date();
    const serverTs = now.toISOString();

    if (action === 'check-in') {
      if (existing && existing.check_in_at) {
        res.status(409).json({ error: `Duplicate Check-In blocked: ${emp.employee_code} already checked in on ${attendanceDate}.` });
        return;
      }
      const shiftStart = new Date(`${attendanceDate}T09:15:00.000Z`);
      const lateMins = Math.max(0, Math.round((now.getTime() - shiftStart.getTime()) / 60000));
      const status = lateMins > 15 ? 'Late' : 'Present';
      const id = existing?.id || `att_${generateSecureToken(6)}`;
      if (existing) {
        sqlite
          .prepare('UPDATE employee_attendance SET check_in_at = ?, status = ?, late_minutes = ?, marked_by_id = ?, marked_by_name = ?, updated_at = ? WHERE id = ?')
          .run(serverTs, status, lateMins, req.auth!.userId, req.auth!.fullName, serverTs, existing.id);
      } else {
        sqlite
          .prepare(`
            INSERT INTO employee_attendance (
              id, employee_id, company_id, country_id, branch_id, attendance_date,
              check_in_at, working_hours, status, late_minutes, work_mode, notes,
              marked_by_id, marked_by_name, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)
          `)
          .run(
            id,
            emp.id,
            emp.company_id,
            emp.country_id || 'PK',
            emp.branch_id || null,
            attendanceDate,
            serverTs,
            status,
            lateMins,
            String(b.workMode || 'On-Site'),
            String(b.notes || 'Server timestamp check-in'),
            req.auth!.userId,
            req.auth!.fullName,
            serverTs,
            serverTs
          );
      }
      logEmployeeAudit({
        employeeId: emp.id,
        companyId: emp.company_id,
        branchId: emp.branch_id,
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'ATTENDANCE_CHECK_IN',
        module: 'Attendance',
        targetId: attendanceDate,
        details: `${emp.employee_code} checked in (${status}) at ${serverTs}`,
        ipAddress: getClientIp(req),
      });
      res.status(201).json({ success: true, id });
      return;
    }

    if (action === 'check-out') {
      if (!existing || !existing.check_in_at) {
        res.status(400).json({ error: `Cannot check out: no active check-in found on ${attendanceDate}.` });
        return;
      }
      if (existing.check_out_at) {
        res.status(409).json({ error: `Duplicate Check-Out blocked for ${attendanceDate}.` });
        return;
      }
      const hours = Number(Math.max(0.01, (now.getTime() - new Date(existing.check_in_at).getTime()) / 3600000).toFixed(2));
      const overtimeHours = hours > 9 ? Number((hours - 9).toFixed(2)) : 0;
      sqlite
        .prepare('UPDATE employee_attendance SET check_out_at = ?, working_hours = ?, overtime_hours = ?, marked_by_id = ?, marked_by_name = ?, updated_at = ? WHERE id = ?')
        .run(serverTs, hours, overtimeHours, req.auth!.userId, req.auth!.fullName, serverTs, existing.id);

      logEmployeeAudit({
        employeeId: emp.id,
        companyId: emp.company_id,
        branchId: emp.branch_id,
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'ATTENDANCE_CHECK_OUT',
        module: 'Attendance',
        targetId: attendanceDate,
        details: `${emp.employee_code} checked out. Hours=${hours}h, Overtime=${overtimeHours}h`,
        ipAddress: getClientIp(req),
      });
      res.json({ success: true, workingHours: hours, overtimeHours });
      return;
    }

    // Explicit manager/HR mark
    if (existing) {
      res.status(409).json({ error: `Attendance entry already exists for ${emp.employee_code} on ${attendanceDate}. Duplicate entry prevented; use Update to amend.` });
      return;
    }

    const status = ['Present', 'Absent', 'Late', 'Half Day', 'Remote'].includes(String(b.status)) ? String(b.status) : 'Present';
    const workingHours = status === 'Absent' ? 0 : Math.max(0, Number(b.workingHours ?? (status === 'Half Day' ? 4 : 8)));
    const overtimeHours = Math.max(0, Number(b.overtimeHours || 0));
    const lateMinutes = status === 'Late' ? Math.max(15, Number(b.lateMinutes || 20)) : 0;
    const notes = String(b.notes || `Marked ${status} by ${req.auth!.fullName}`).trim();
    const id = `att_${generateSecureToken(6)}`;

    sqlite
      .prepare(`
        INSERT INTO employee_attendance (
          id, employee_id, company_id, country_id, branch_id, attendance_date,
          check_in_at, check_out_at, working_hours, overtime_hours, status, late_minutes,
          work_mode, notes, marked_by_id, marked_by_name, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id,
        emp.id,
        emp.company_id,
        emp.country_id || 'PK',
        emp.branch_id || null,
        attendanceDate,
        status === 'Absent' ? null : serverTs,
        b.checkOutNow ? serverTs : null,
        workingHours,
        overtimeHours,
        status,
        lateMinutes,
        String(b.workMode || 'On-Site'),
        notes,
        req.auth!.userId,
        req.auth!.fullName,
        serverTs,
        serverTs
      );

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'ATTENDANCE_MARKED',
      module: 'Attendance',
      targetId: attendanceDate,
      details: `Marked ${emp.employee_code} as ${status} (${workingHours}h, OT ${overtimeHours}h)`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, id });
  });

  router.patch('/attendance/:id', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const att = sqlite.prepare('SELECT * FROM employee_attendance WHERE id = ?').get(req.params.id) as any;
    if (!att) {
      res.status(404).json({ error: 'Attendance record not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(att.employee_id) as any;
    if (!scope.canManageAttendance || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized HR / Management can modify attendance logs.');
      return;
    }

    const b = req.body || {};
    const status = b.status && ['Present', 'Absent', 'Late', 'Half Day', 'Remote'].includes(String(b.status)) ? String(b.status) : att.status;
    const workingHours = b.workingHours !== undefined ? Math.max(0, Number(b.workingHours)) : att.working_hours;
    const overtimeHours = b.overtimeHours !== undefined ? Math.max(0, Number(b.overtimeHours)) : att.overtime_hours;
    const notes = b.notes !== undefined ? String(b.notes).trim() : att.notes;
    const ts = nowIso();

    sqlite
      .prepare('UPDATE employee_attendance SET status = ?, working_hours = ?, overtime_hours = ?, notes = ?, marked_by_id = ?, marked_by_name = ?, updated_at = ? WHERE id = ?')
      .run(status, workingHours, overtimeHours, notes, req.auth!.userId, req.auth!.fullName, ts, att.id);

    logEmployeeAudit({
      employeeId: att.employee_id,
      companyId: att.company_id,
      branchId: att.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'ATTENDANCE_AMENDED',
      module: 'Attendance',
      targetId: att.attendance_date,
      details: `Amended ${att.attendance_date}: ${att.status} -> ${status}, Hours=${workingHours}h, OT=${overtimeHours}h`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  router.get('/attendance/reports', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const month = String(req.query.month || nowIso().slice(0, 7)).slice(0, 7);
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);

    if (empIds.length === 0) {
      res.json({ month, branchWise: [], departmentWise: [], monthlySummary: [] });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const rows = sqlite
      .prepare(`
        SELECT a.*, e.employee_code, e.full_name, e.department, b.name as branch_name
        FROM employee_attendance a
        JOIN employee_accounts e ON e.id = a.employee_id
        LEFT JOIN branches b ON b.id = COALESCE(a.branch_id, e.branch_id)
        WHERE a.attendance_date LIKE ? AND a.employee_id IN (${ph})
      `)
      .all(`${month}%`, ...empIds) as any[];

    const byBranch = new Map<string, { branch: string; present: number; late: number; absent: number; halfDay: number; hours: number; overtime: number }>();
    const byDept = new Map<string, { department: string; present: number; late: number; absent: number; halfDay: number; hours: number; overtime: number }>();

    for (const r of rows) {
      const bKey = r.branch_name || 'Head Office';
      const dKey = r.department || 'Unassigned';
      const bAgg = byBranch.get(bKey) || { branch: bKey, present: 0, late: 0, absent: 0, halfDay: 0, hours: 0, overtime: 0 };
      const dAgg = byDept.get(dKey) || { department: dKey, present: 0, late: 0, absent: 0, halfDay: 0, hours: 0, overtime: 0 };

      for (const agg of [bAgg, dAgg]) {
        if (['Present', 'Remote'].includes(r.status)) agg.present += 1;
        else if (r.status === 'Late') agg.late += 1;
        else if (r.status === 'Absent') agg.absent += 1;
        else if (r.status === 'Half Day') agg.halfDay += 1;
        agg.hours = Number((agg.hours + Number(r.working_hours || 0)).toFixed(2));
        agg.overtime = Number((agg.overtime + Number(r.overtime_hours || 0)).toFixed(2));
      }
      byBranch.set(bKey, bAgg);
      byDept.set(dKey, dAgg);
    }

    res.json({
      month,
      branchWise: Array.from(byBranch.values()),
      departmentWise: Array.from(byDept.values()),
      totalRecords: rows.length,
    });
  });

  // =========================================================================
  // 4. SALARY STRUCTURES & PAYROLL PROCESSING + VERIFIED PAYMENTS + PDF SLIP
  // =========================================================================
  router.get('/payroll', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const payPeriod = String(req.query.payPeriod || '').slice(0, 7);
    const statusFilter = String(req.query.status || '').trim();

    // Employees can view only their own payslips; HR/Dept without payroll access can only view own payslips
    const effectiveEmployees = scope.canAccessPayroll
      ? getScopedEmployeeRows(scope)
      : scope.selfEmployeeId
      ? getScopedEmployeeRows({ ...scope, selfOnly: true })
      : [];

    const empIds = effectiveEmployees.map((e) => e.id);
    if (empIds.length === 0) {
      res.json({ structures: [], payrollRecords: [], summary: { totalGross: 0, totalNet: 0, paidTotal: 0, unpaidTotal: 0, pendingApprovalCount: 0 } });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const structures = sqlite
      .prepare(`
        SELECT s.*, e.employee_code, e.full_name, e.department, e.job_position, b.name as branch_name
        FROM employee_salary_structures s
        JOIN employee_accounts e ON e.id = s.employee_id
        LEFT JOIN branches b ON b.id = e.branch_id
        WHERE s.employee_id IN (${ph})
        ORDER BY e.full_name ASC
      `)
      .all(...empIds);

    const records = (
      sqlite
        .prepare(`
          SELECT sr.*, e.employee_code, e.full_name, e.department, e.job_position, b.name as branch_name
          FROM employee_salary_records sr
          JOIN employee_accounts e ON e.id = sr.employee_id
          LEFT JOIN branches b ON b.id = COALESCE(sr.branch_id, e.branch_id)
          WHERE sr.employee_id IN (${ph})
          ORDER BY sr.pay_period DESC, e.full_name ASC
        `)
        .all(...empIds) as any[]
    )
      .filter((r) => !payPeriod || payPeriod === 'ALL' || r.pay_period === payPeriod)
      .filter((r) => !statusFilter || statusFilter === 'ALL' || r.payment_status === statusFilter || r.approval_status === statusFilter)
      .map((r) => {
        const items = sqlite.prepare('SELECT * FROM payroll_items WHERE payroll_record_id = ?').all(r.id);
        return { ...r, items };
      });

    const totalNet = records.reduce((s, r) => s + Number(r.net_salary || 0), 0);
    const totalGross = records.reduce(
      (s, r) => s + Number(r.basic_salary || r.base_salary || 0) + Number(r.allowances || 0) + Number(r.overtime_payment || 0) + Number(r.bonuses || 0),
      0
    );
    const paidTotal = records.filter((r) => r.payment_status === 'Paid' && r.verified_payment_ref).reduce((s, r) => s + Number(r.net_salary || 0), 0);
    const pendingApprovalCount = records.filter((r) => r.approval_status === 'Pending Approval').length;

    res.json({
      structures,
      payrollRecords: records,
      summary: {
        totalGross,
        totalNet,
        paidTotal,
        unpaidTotal: Math.max(0, totalNet - paidTotal),
        pendingApprovalCount,
      },
    });
  });

  router.put('/payroll/structure/:employeeId', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.employeeId) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (!scope.canProcessPayroll || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized Finance / Company Admins / Founder can update salary structures.');
      return;
    }

    const b = req.body || {};
    const basicSalary = Math.max(0, Number(b.basicSalary || 0));
    const houseAllowance = Math.max(0, Number(b.houseAllowance || 0));
    const medicalAllowance = Math.max(0, Number(b.medicalAllowance || 0));
    const transportAllowance = Math.max(0, Number(b.transportAllowance || 0));
    const otherAllowances = Math.max(0, Number(b.otherAllowances || 0));
    const taxDeduction = Math.max(0, Number(b.taxDeduction || 0));
    const otherDeductions = Math.max(0, Number(b.otherDeductions || 0));
    const currency = String(b.currency || 'PKR').toUpperCase();
    const bankName = String(b.bankName || emp.bank_name || '').trim();
    const bankAccountTitle = String(b.bankAccountTitle || emp.bank_account_title || '').trim();
    const bankIban = String(b.bankIban || emp.bank_iban || '').trim();

    const existing = sqlite.prepare('SELECT * FROM employee_salary_structures WHERE employee_id = ?').get(emp.id) as any;
    const ts = nowIso();

    sqlite.transaction(() => {
      if (existing) {
        sqlite
          .prepare(`
            UPDATE employee_salary_structures
            SET currency = ?, basic_salary = ?, house_allowance = ?, medical_allowance = ?,
                transport_allowance = ?, other_allowances = ?, tax_deduction = ?, other_deductions = ?,
                bank_name = ?, bank_account_title = ?, bank_iban = ?, updated_by = ?, updated_at = ?
            WHERE employee_id = ?
          `)
          .run(currency, basicSalary, houseAllowance, medicalAllowance, transportAllowance, otherAllowances, taxDeduction, otherDeductions, bankName, bankAccountTitle, bankIban, req.auth!.fullName, ts, emp.id);
      } else {
        sqlite
          .prepare(`
            INSERT INTO employee_salary_structures (
              id, employee_id, company_id, currency, basic_salary, house_allowance, medical_allowance,
              transport_allowance, other_allowances, tax_deduction, other_deductions,
              bank_name, bank_account_title, bank_iban, effective_from, updated_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `)
          .run(`ess_${generateSecureToken(5)}`, emp.id, emp.company_id, currency, basicSalary, houseAllowance, medicalAllowance, transportAllowance, otherAllowances, taxDeduction, otherDeductions, bankName, bankAccountTitle, bankIban, ts.slice(0, 10), req.auth!.fullName, ts, ts);
      }
      sqlite.prepare('UPDATE employee_accounts SET basic_salary = ?, bank_name = ?, bank_account_title = ?, bank_iban = ?, updated_at = ? WHERE id = ?')
        .run(basicSalary, bankName, bankAccountTitle, bankIban, ts, emp.id);
    })();

    recordEmployeeHistory({
      employeeId: emp.id,
      companyId: emp.company_id,
      changeType: 'Salary',
      previousValue: existing ? `Basic ${existing.basic_salary}` : 'Unset',
      newValue: `Basic ${basicSalary} + Allow ${houseAllowance + medicalAllowance + transportAllowance + otherAllowances} - Ded ${taxDeduction + otherDeductions}`,
      notes: String(b.notes || 'Salary structure updated'),
      changedById: req.auth!.userId,
      changedByName: req.auth!.fullName,
    });

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SALARY_STRUCTURE_UPDATED',
      module: 'Payroll',
      targetId: emp.employee_code,
      details: `Updated salary structure for ${emp.employee_code}: Basic=${basicSalary} ${currency}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  router.post('/payroll/process', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canProcessPayroll) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized Finance / Company Admins / Founder can process payroll.');
      return;
    }

    const b = req.body || {};
    const payPeriod = String(b.payPeriod || nowIso().slice(0, 7)).slice(0, 7);
    const targetEmployeeId = b.employeeId ? String(b.employeeId).trim() : null;
    const bonusOverride = Math.max(0, Number(b.bonuses || 0));
    const overtimeOverride = b.overtimePayment !== undefined && b.overtimePayment !== '' ? Math.max(0, Number(b.overtimePayment)) : null;
    const advanceOverride = Math.max(0, Number(b.advanceSalary || 0));
    const otherDedOverride = b.otherDeductions !== undefined && b.otherDeductions !== '' ? Math.max(0, Number(b.otherDeductions)) : null;

    if (!/^\d{4}-\d{2}$/.test(payPeriod)) {
      res.status(400).json({ error: 'Valid pay period (YYYY-MM) is required.' });
      return;
    }

    const candidates = getScopedEmployeeRows(scope).filter((e) => e.status === 'Active' && (!targetEmployeeId || e.id === targetEmployeeId));
    if (candidates.length === 0) {
      res.status(404).json({ error: 'No eligible active employees found for payroll processing.' });
      return;
    }

    if (targetEmployeeId) {
      const dup = sqlite.prepare('SELECT id FROM employee_salary_records WHERE employee_id = ? AND pay_period = ?').get(targetEmployeeId, payPeriod);
      if (dup) {
        res.status(409).json({ error: `Duplicate payroll blocked: payroll for ${payPeriod} has already been generated for this employee.` });
        return;
      }
    }

    const processed: any[] = [];
    const skipped: string[] = [];
    const ts = nowIso();

    sqlite.transaction(() => {
      for (const emp of candidates) {
        const dup = sqlite.prepare('SELECT id FROM employee_salary_records WHERE employee_id = ? AND pay_period = ?').get(emp.id, payPeriod);
        if (dup) {
          skipped.push(`${emp.employee_code} (already processed for ${payPeriod})`);
          continue;
        }

        const struct = sqlite.prepare('SELECT * FROM employee_salary_structures WHERE employee_id = ?').get(emp.id) as any;
        const basicSalary = Number(struct?.basic_salary ?? emp.basic_salary ?? 0);
        const houseAllowance = Number(struct?.house_allowance ?? 0);
        const medicalAllowance = Number(struct?.medical_allowance ?? 0);
        const transportAllowance = Number(struct?.transport_allowance ?? 0);
        const otherAllowances = Number(struct?.other_allowances ?? 0);
        const allowancesTotal = houseAllowance + medicalAllowance + transportAllowance + otherAllowances;

        // Calculate overtime from verified attendance records in payPeriod
        const attOtRow = sqlite
          .prepare('SELECT COALESCE(SUM(overtime_hours), 0) as otHours FROM employee_attendance WHERE employee_id = ? AND attendance_date LIKE ?')
          .get(emp.id, `${payPeriod}%`) as { otHours: number };
        const settings = sqlite.prepare('SELECT overtime_hourly_rate FROM employee_module_settings WHERE company_id = ?').get(emp.company_id) as any;
        const otRate = Number(settings?.overtime_hourly_rate || 1200);
        const overtimePayment = overtimeOverride !== null ? overtimeOverride : Math.round(Number(attOtRow?.otHours || 0) * otRate);

        const taxDeduction = Number(struct?.tax_deduction ?? 0);
        const otherDeductions = otherDedOverride !== null ? otherDedOverride : Number(struct?.other_deductions ?? 0);
        const deductionsTotal = taxDeduction + otherDeductions + advanceOverride;

        // Core Formula: Net Salary = Basic Salary + Allowances + Overtime - Deductions (+ Bonuses)
        const netSalary = Math.max(0, basicSalary + allowancesTotal + overtimePayment + bonusOverride - deductionsTotal);
        const recId = `sal_${generateSecureToken(6)}`;

        sqlite
          .prepare(`
            INSERT INTO employee_salary_records (
              id, employee_id, company_id, country_id, branch_id, pay_period, currency,
              base_salary, basic_salary, allowances, house_allowance, medical_allowance,
              transport_allowance, other_allowances, overtime_payment, bonuses,
              deductions, tax_deduction, other_deductions, advance_salary, net_salary,
              payment_status, approval_status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Pending Approval', ?, ?, ?)
          `)
          .run(
            recId,
            emp.id,
            emp.company_id,
            emp.country_id || 'PK',
            emp.branch_id || null,
            payPeriod,
            struct?.currency || emp.country_currency || 'PKR',
            basicSalary,
            basicSalary,
            allowancesTotal,
            houseAllowance,
            medicalAllowance,
            transportAllowance,
            otherAllowances,
            overtimePayment,
            bonusOverride,
            otherDeductions + advanceOverride,
            taxDeduction,
            otherDeductions,
            advanceOverride,
            netSalary,
            `Generated payroll run for ${payPeriod}`,
            ts,
            ts
          );

        const insertItem = sqlite.prepare('INSERT INTO payroll_items (id, payroll_record_id, employee_id, item_type, label, amount, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Basic Salary', basicSalary, ts);
        if (houseAllowance > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'House Allowance', houseAllowance, ts);
        if (medicalAllowance > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Medical Allowance', medicalAllowance, ts);
        if (transportAllowance > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Transport Allowance', transportAllowance, ts);
        if (otherAllowances > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Other Allowances', otherAllowances, ts);
        if (overtimePayment > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Overtime Payment', overtimePayment, ts);
        if (bonusOverride > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'earning', 'Performance Bonus', bonusOverride, ts);
        if (taxDeduction > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'deduction', 'Tax Deduction', taxDeduction, ts);
        if (otherDeductions > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'deduction', 'Other Deductions', otherDeductions, ts);
        if (advanceOverride > 0) insertItem.run(`pi_${generateSecureToken(5)}`, recId, emp.id, 'deduction', 'Advance Salary Recovery', advanceOverride, ts);

        processed.push({ id: recId, employeeCode: emp.employee_code, netSalary });

        logEmployeeAudit({
          employeeId: emp.id,
          companyId: emp.company_id,
          branchId: emp.branch_id,
          actorId: req.auth!.userId,
          actorName: req.auth!.fullName,
          actorRole: req.auth!.role,
          action: 'PAYROLL_PROCESSED',
          module: 'Payroll',
          targetId: payPeriod,
          details: `Processed ${payPeriod} payroll for ${emp.employee_code}: Net=${netSalary} (Pending Approval & Unpaid)`,
          ipAddress: getClientIp(req),
        });
      }
    })();

    res.status(201).json({ success: true, processedCount: processed.length, processed, skipped });
  });

  router.patch('/payroll/:id/approve', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const rec = sqlite.prepare('SELECT * FROM employee_salary_records WHERE id = ?').get(req.params.id) as any;
    if (!rec) {
      res.status(404).json({ error: 'Payroll record not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(rec.employee_id) as any;
    if (!scope.canApprovePayroll || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: only Founder or authorized Payroll Approver can approve monthly payroll.');
      return;
    }
    if (req.auth?.employeeId === rec.employee_id && scope.mode !== 'founder') {
      rejectUnauthorized(req, res, 'Conflict of interest: you cannot approve your own payroll.');
      return;
    }

    const decision = String(req.body.decision || 'Approved');
    if (!['Approved', 'Rejected'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
      return;
    }
    const ts = nowIso();
    sqlite
      .prepare('UPDATE employee_salary_records SET approval_status = ?, approved_by_id = ?, approved_by_name = ?, approved_at = ?, updated_at = ? WHERE id = ?')
      .run(decision, req.auth!.userId, req.auth!.fullName, ts, ts, rec.id);

    logEmployeeAudit({
      employeeId: rec.employee_id,
      companyId: rec.company_id,
      branchId: rec.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: decision === 'Approved' ? 'PAYROLL_APPROVED' : 'PAYROLL_REJECTED',
      module: 'Payroll',
      targetId: rec.pay_period,
      details: `${decision} payroll for ${emp.employee_code} (${rec.pay_period})`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, approvalStatus: decision });
  });

  router.patch('/payroll/:id/pay', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const rec = sqlite.prepare('SELECT * FROM employee_salary_records WHERE id = ?').get(req.params.id) as any;
    if (!rec) {
      res.status(404).json({ error: 'Payroll record not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(rec.employee_id) as any;
    if (!scope.canPayPayroll || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: only Founder or authorized Finance Officer can mark salaries as Paid.');
      return;
    }
    if (rec.approval_status !== 'Approved') {
      res.status(400).json({ error: 'Cannot pay unapproved payroll. Payroll must be Approved before payment disbursement.' });
      return;
    }
    if (rec.payment_status === 'Paid' && rec.verified_payment_ref) {
      res.status(409).json({ error: `Salary already disbursed under payment reference ${rec.verified_payment_ref}.` });
      return;
    }

    const bankRef = String(req.body.bankReference || '').trim();
    const paymentDate = String(req.body.paymentDate || nowIso().slice(0, 10)).slice(0, 10);
    if (!bankRef || bankRef.length < 4) {
      res.status(400).json({ error: 'Verified bank transfer reference / transaction ID (min 4 chars) is required to mark salary Paid.' });
      return;
    }

    const ts = nowIso();
    sqlite
      .prepare("UPDATE employee_salary_records SET payment_status = 'Paid', payment_date = ?, bank_reference = ?, verified_payment_ref = ?, paid_by_name = ?, updated_at = ? WHERE id = ?")
      .run(paymentDate, bankRef, bankRef, req.auth!.fullName, ts, rec.id);

    logEmployeeAudit({
      employeeId: rec.employee_id,
      companyId: rec.company_id,
      branchId: rec.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SALARY_PAYMENT_VERIFIED',
      module: 'Payroll',
      targetId: bankRef,
      details: `Marked ${rec.pay_period} salary PAID (${rec.net_salary} ${rec.currency}) for ${emp.employee_code}. Ref: ${bankRef}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, paymentStatus: 'Paid', bankReference: bankRef });
  });

  router.get('/payroll/:id/payslip.pdf', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const rec = sqlite
      .prepare(`
        SELECT sr.*, e.employee_code, e.full_name, e.department, e.job_position, e.bank_name, e.bank_iban,
               c.name as company_name, b.name as branch_name
        FROM employee_salary_records sr
        JOIN employee_accounts e ON e.id = sr.employee_id
        JOIN companies c ON c.id = sr.company_id
        LEFT JOIN branches b ON b.id = COALESCE(sr.branch_id, e.branch_id)
        WHERE sr.id = ?
      `)
      .get(req.params.id) as any;

    if (!rec) {
      res.status(404).json({ error: 'Payslip record not found.' });
      return;
    }
    const isSelf = req.auth?.employeeId === rec.employee_id;
    const empRow = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(rec.employee_id) as any;
    if ((!scope.canAccessPayroll && !isSelf) || !canActorAccessEmployee({ ...scope, selfOnly: !scope.canAccessPayroll }, empRow)) {
      rejectUnauthorized(req, res, 'Access Denied: Payslips are private and restricted.');
      return;
    }

    const lines = [
      `BYD PAKISTAN 360 - OFFICIAL EMPLOYEE PAYSLIP (${rec.pay_period})`,
      `Company: ${rec.company_name} | Branch: ${rec.branch_name || 'Head Office'}`,
      `Founder & CEO: Intekhab Alam`,
      '--------------------------------------------------------------------',
      `Employee Name: ${rec.full_name} (${rec.employee_code})`,
      `Department: ${rec.department} | Position: ${rec.job_position}`,
      `Bank Account: ${rec.bank_name || 'Standard Payroll Bank'} (${maskSensitive(rec.bank_iban, true)})`,
      '--------------------------------------------------------------------',
      `EARNINGS (${rec.currency}):`,
      `  Basic Salary:        ${Number(rec.basic_salary || rec.base_salary || 0).toLocaleString()}`,
      `  House Allowance:     ${Number(rec.house_allowance || 0).toLocaleString()}`,
      `  Medical Allowance:   ${Number(rec.medical_allowance || 0).toLocaleString()}`,
      `  Transport Allowance: ${Number(rec.transport_allowance || 0).toLocaleString()}`,
      `  Other Allowances:    ${Number(rec.other_allowances || 0).toLocaleString()}`,
      `  Overtime Payment:    ${Number(rec.overtime_payment || 0).toLocaleString()}`,
      `  Bonuses:             ${Number(rec.bonuses || 0).toLocaleString()}`,
      '--------------------------------------------------------------------',
      `DEDUCTIONS (${rec.currency}):`,
      `  Tax Deduction:       ${Number(rec.tax_deduction || 0).toLocaleString()}`,
      `  Other Deductions:    ${Number(rec.other_deductions || 0).toLocaleString()}`,
      `  Advance Salary:      ${Number(rec.advance_salary || 0).toLocaleString()}`,
      '--------------------------------------------------------------------',
      `NET PAYABLE SALARY:    ${rec.currency} ${Number(rec.net_salary || 0).toLocaleString()}`,
      `Approval Status:       ${rec.approval_status} ${rec.approved_by_name ? `(By ${rec.approved_by_name})` : ''}`,
      `Payment Status:        ${rec.payment_status}`,
      `Payment Reference:     ${rec.verified_payment_ref || rec.bank_reference || 'Pending Verified Disbursement'}`,
      `Payment Date:          ${rec.payment_date || 'N/A'}`,
    ];

    const pdfBuf = buildSimplePdfBuffer(`BYD 360 Payslip - ${rec.employee_code} (${rec.pay_period})`, lines);
    logEmployeeAudit({
      employeeId: rec.employee_id,
      companyId: rec.company_id,
      branchId: rec.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'PAYSLIP_PDF_DOWNLOADED',
      module: 'Payroll',
      targetId: rec.pay_period,
      details: `Generated PDF payslip for ${rec.employee_code} (${rec.pay_period})`,
      ipAddress: getClientIp(req),
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="Payslip_${rec.employee_code}_${rec.pay_period}.pdf"`);
    res.send(pdfBuf);
  });

  // =========================================================================
  // 5. LEAVE MANAGEMENT (TYPES, BALANCES, DOCS, APPROVALS, DEPT REPORTS)
  // =========================================================================
  router.get('/leaves', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);
    const statusFilter = String(req.query.status || '').trim();
    const typeFilter = String(req.query.leaveType || '').trim();

    if (empIds.length === 0) {
      res.json({ requests: [], balances: [], departmentSummary: [], leaveTypes: LEAVE_TYPES });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const requests = (
      sqlite
        .prepare(`
          SELECT l.*, e.employee_code, e.full_name, e.department, b.name as branch_name
          FROM employee_leave_requests l
          JOIN employee_accounts e ON e.id = l.employee_id
          LEFT JOIN branches b ON b.id = COALESCE(l.branch_id, e.branch_id)
          WHERE l.employee_id IN (${ph})
          ORDER BY l.created_at DESC
        `)
        .all(...empIds) as any[]
    )
      .filter((r) => !statusFilter || statusFilter === 'ALL' || r.status === statusFilter)
      .filter((r) => !typeFilter || typeFilter === 'ALL' || r.leave_type === typeFilter);

    const balances = employees.map((e) => ({
      employeeId: e.id,
      employeeCode: e.employee_code,
      fullName: e.full_name,
      department: e.department,
      ...computeEmployeeLeaveBalance(e.id, e.leave_balance_json),
    }));

    const deptMap = new Map<string, { department: string; totalRequests: number; approvedDays: number; pending: number }>();
    for (const r of requests) {
      const k = r.department || 'Unassigned';
      const agg = deptMap.get(k) || { department: k, totalRequests: 0, approvedDays: 0, pending: 0 };
      agg.totalRequests += 1;
      if (r.status === 'Approved') agg.approvedDays += Number(r.total_days || 0);
      if (r.status === 'Pending') agg.pending += 1;
      deptMap.set(k, agg);
    }

    res.json({
      requests,
      balances,
      departmentSummary: Array.from(deptMap.values()),
      leaveTypes: LEAVE_TYPES,
    });
  });

  router.post('/leaves', upload.single('supportingDocument'), (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const b = req.body || {};
    const targetEmpId = b.employeeId ? String(b.employeeId).trim() : req.auth?.employeeId || '';

    if (!targetEmpId) {
      res.status(400).json({ error: 'Employee target is required to submit a leave application.' });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(targetEmpId) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }

    const isSelf = req.auth?.employeeId === emp.id;
    if (!isSelf && (!scope.canManageProfiles || !canActorAccessEmployee(scope, emp))) {
      rejectUnauthorized(req, res, 'Permission denied: cannot submit leave applications for another employee.');
      return;
    }

    if (b.status && String(b.status) !== 'Pending' && scope.mode !== 'founder') {
      rejectUnauthorized(req, res, 'Leave applications cannot be pre-approved upon submission.');
      return;
    }

    const leaveType = String(b.leaveType || 'Annual Leave').trim();
    const startDate = String(b.startDate || '').slice(0, 10);
    const endDate = String(b.endDate || '').slice(0, 10);
    const reason = String(b.reason || '').trim();

    if (!startDate || !endDate || reason.length < 4) {
      res.status(400).json({ error: 'Leave type, start date, end date, and reason are required.' });
      return;
    }

    const sMs = new Date(`${startDate}T00:00:00Z`).getTime();
    const eMs = new Date(`${endDate}T00:00:00Z`).getTime();
    if (Number.isNaN(sMs) || Number.isNaN(eMs) || eMs < sMs) {
      res.status(400).json({ error: 'End date must be on or after start date.' });
      return;
    }
    const totalDays = Math.min(90, Math.floor((eMs - sMs) / 86400_000) + 1);

    const bal = computeEmployeeLeaveBalance(emp.id, emp.leave_balance_json);
    const lt = leaveType.toLowerCase();
    if (lt.includes('annual') && totalDays > bal.annual.remaining) {
      res.status(400).json({ error: `Requested ${totalDays} day(s) exceeds remaining Annual Leave balance (${bal.annual.remaining}).` });
      return;
    }
    if (lt.includes('sick') && totalDays > bal.sick.remaining) {
      res.status(400).json({ error: `Requested ${totalDays} day(s) exceeds remaining Sick Leave balance (${bal.sick.remaining}).` });
      return;
    }
    if (lt.includes('casual') && totalDays > bal.casual.remaining) {
      res.status(400).json({ error: `Requested ${totalDays} day(s) exceeds remaining Casual Leave balance (${bal.casual.remaining}).` });
      return;
    }

    let supportingDocId: string | null = null;
    if (req.file) {
      try {
        const saved = savePrivateEmployeeDocFile({
          file: req.file,
          employeeId: emp.id,
          companyId: emp.company_id,
          countryId: emp.country_id || 'PK',
          branchId: emp.branch_id || null,
          category: 'Leave Supporting Document',
          title: `${leaveType} Proof (${startDate})`,
          uploadedById: req.auth!.userId,
          uploadedByRole: req.auth!.role,
        });
        supportingDocId = saved.id;
      } catch (err: any) {
        res.status(400).json({ error: err?.message || 'Supporting document upload failed.' });
        return;
      }
    }

    const leaveId = `lv_${generateSecureToken(5)}`;
    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT INTO employee_leave_requests (
          id, employee_id, company_id, country_id, branch_id, leave_type,
          start_date, end_date, total_days, reason, supporting_doc_id, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)
      `)
      .run(leaveId, emp.id, emp.company_id, emp.country_id || 'PK', emp.branch_id || null, leaveType, startDate, endDate, totalDays, reason, supportingDocId, ts, ts);

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'LEAVE_APPLIED',
      module: 'Leave Management',
      targetId: leaveId,
      details: `${emp.employee_code} applied for ${leaveType} (${startDate} to ${endDate}, ${totalDays} day(s))`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, leaveId, totalDays });
  });

  router.patch('/leaves/:id/decide', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const lv = sqlite.prepare('SELECT * FROM employee_leave_requests WHERE id = ?').get(req.params.id) as any;
    if (!lv) {
      res.status(404).json({ error: 'Leave request not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(lv.employee_id) as any;
    if (!scope.canApproveLeave || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: you are not authorized to approve or reject leave applications.');
      return;
    }
    if (req.auth?.employeeId === lv.employee_id && scope.mode !== 'founder') {
      rejectUnauthorized(req, res, 'Security violation: self-approval of leave requests is strictly prohibited.');
      return;
    }

    const decision = String(req.body.decision || '').trim();
    if (!['Approved', 'Rejected'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
      return;
    }
    const reviewNotes = String(req.body.reviewNotes || '').trim();
    const ts = nowIso();

    sqlite
      .prepare('UPDATE employee_leave_requests SET status = ?, reviewed_by_id = ?, reviewed_by_name = ?, review_notes = ?, reviewed_at = ?, updated_at = ? WHERE id = ?')
      .run(decision, req.auth!.userId, req.auth!.fullName, reviewNotes, ts, ts, lv.id);

    logEmployeeAudit({
      employeeId: lv.employee_id,
      companyId: lv.company_id,
      branchId: lv.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: decision === 'Approved' ? 'LEAVE_APPROVED' : 'LEAVE_REJECTED',
      module: 'Leave Management',
      targetId: lv.id,
      details: `${decision} ${lv.leave_type} (${lv.total_days}d) for ${emp.employee_code}. Notes: ${reviewNotes || 'N/A'}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status: decision });
  });

  // =========================================================================
  // 6. JOB POSITIONS, DEPARTMENTS & PROMOTION/TRANSFER HISTORY
  // =========================================================================
  router.get('/positions', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const positions = (
      sqlite
        .prepare(`
          SELECT p.*, c.name as company_name, b.name as branch_name, d.name as department_name
          FROM employee_positions p
          JOIN companies c ON c.id = p.company_id
          LEFT JOIN branches b ON b.id = p.branch_id
          LEFT JOIN employee_departments d ON d.id = p.department_id
          ORDER BY p.created_at DESC
        `)
        .all() as any[]
    ).filter((p) => (!scope.restrictedCompanyId || p.company_id === scope.restrictedCompanyId) && (!scope.restrictedBranchId || !p.branch_id || p.branch_id === scope.restrictedBranchId));

    const departments = (
      sqlite
        .prepare(`
          SELECT d.*, c.name as company_name, b.name as branch_name
          FROM employee_departments d
          JOIN companies c ON c.id = d.company_id
          LEFT JOIN branches b ON b.id = d.branch_id
          ORDER BY d.name ASC
        `)
        .all() as any[]
    ).filter((d) => (!scope.restrictedCompanyId || d.company_id === scope.restrictedCompanyId) && (!scope.restrictedBranchId || !d.branch_id || d.branch_id === scope.restrictedBranchId));

    const empIds = getScopedEmployeeRows(scope).map((e) => e.id);
    const history = empIds.length > 0
      ? sqlite
          .prepare(`SELECT h.*, e.employee_code, e.full_name FROM employee_history h JOIN employee_accounts e ON e.id = h.employee_id WHERE h.employee_id IN (${empIds.map(() => '?').join(',')}) ORDER BY h.created_at DESC LIMIT 80`)
          .all(...empIds)
      : [];

    res.json({ positions, departments, history });
  });

  router.post('/positions', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canManagePositions) {
      rejectUnauthorized(req, res, 'Permission denied: cannot create job positions.');
      return;
    }

    const b = req.body || {};
    const companyId = scope.restrictedCompanyId || String(b.companyId || '').trim();
    const branchId = scope.restrictedBranchId || (b.branchId ? String(b.branchId).trim() : null);
    const departmentId = b.departmentId ? String(b.departmentId).trim() : null;
    const title = String(b.title || '').trim();
    const designation = String(b.designation || title).trim();
    const employmentType = String(b.employmentType || 'Full-Time Permanent').trim();
    const reportingManagerName = String(b.reportingManagerName || '').trim();
    const responsibilities = String(b.responsibilities || '').trim();
    const minSalary = Math.max(0, Number(b.minSalary || 0));
    const maxSalary = Math.max(0, Number(b.maxSalary || 0));

    if (!companyId || !title) {
      res.status(400).json({ error: 'Company and job title are required.' });
      return;
    }

    const id = `pos_${generateSecureToken(5)}`;
    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT INTO employee_positions (
          id, company_id, branch_id, department_id, title, designation, employment_type,
          reporting_manager_name, responsibilities, min_salary, max_salary, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
      `)
      .run(id, companyId, branchId, departmentId, title, designation, employmentType, reportingManagerName, responsibilities, minSalary, maxSalary, ts, ts);

    logEmployeeAudit({
      companyId,
      branchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'JOB_POSITION_CREATED',
      module: 'Job Positions',
      targetId: id,
      details: `Created job position "${title}" (${employmentType})`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, id });
  });

  router.post('/employees/:id/promote-transfer', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (!scope.canManagePositions || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: cannot execute promotions or transfers.');
      return;
    }

    const b = req.body || {};
    const changeType = ['Promotion', 'Transfer', 'Position'].includes(String(b.changeType)) ? (String(b.changeType) as 'Promotion' | 'Transfer' | 'Position') : 'Promotion';
    const newJobPosition = b.jobPosition ? String(b.jobPosition).trim() : emp.job_position;
    const newDepartment = b.department ? String(b.department).trim() : emp.department;
    const newBranchId = b.branchId !== undefined ? (b.branchId ? String(b.branchId).trim() : null) : emp.branch_id;
    const newManagerName = b.reportingManagerName ? String(b.reportingManagerName).trim() : emp.reporting_manager_name;
    const effectiveDate = String(b.effectiveDate || nowIso().slice(0, 10)).slice(0, 10);
    const notes = String(b.notes || '').trim();

    if (newBranchId) {
      const br = sqlite.prepare('SELECT id, company_id FROM branches WHERE id = ?').get(newBranchId) as any;
      if (!br || br.company_id !== emp.company_id) {
        res.status(400).json({ error: 'Invalid transfer: target branch must belong to the same parent company.' });
        return;
      }
    }

    const ts = nowIso();
    const prevSummary = `${emp.job_position} | ${emp.department} | Branch:${emp.branch_id || 'HQ'}`;
    const nextSummary = `${newJobPosition} | ${newDepartment} | Branch:${newBranchId || 'HQ'}`;

    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE employee_accounts SET job_position = ?, department = ?, branch_id = ?, reporting_manager_name = ?, updated_at = ? WHERE id = ?')
        .run(newJobPosition, newDepartment, newBranchId, newManagerName, ts, emp.id);
      sqlite
        .prepare('UPDATE user_accounts SET role = ?, branch_id = ?, updated_at = ? WHERE id = ?')
        .run(newJobPosition, newBranchId, ts, emp.id);
      if (newBranchId) {
        sqlite
          .prepare('INSERT OR REPLACE INTO branch_employee_relationships (id, branch_id, company_id, employee_id, employee_code, assigned_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .run(`ber_${generateSecureToken(5)}`, newBranchId, emp.company_id, emp.id, emp.employee_code, req.auth!.fullName, ts);
      }
    })();

    recordEmployeeHistory({
      employeeId: emp.id,
      companyId: emp.company_id,
      changeType,
      previousValue: prevSummary,
      newValue: nextSummary,
      effectiveDate,
      notes,
      changedById: req.auth!.userId,
      changedByName: req.auth!.fullName,
    });

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: newBranchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `EMPLOYEE_${changeType.toUpperCase()}`,
      module: 'Job Positions',
      targetId: emp.employee_code,
      details: `${changeType}: ${prevSummary} -> ${nextSummary}. ${notes}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  // =========================================================================
  // 7. PERFORMANCE EVALUATIONS & EMPLOYEE TARGETS
  // =========================================================================
  router.get('/performance', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);
    if (empIds.length === 0) {
      res.json({ reviews: [], targets: [] });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const reviews = (
      sqlite
        .prepare(`
          SELECT r.*, e.employee_code, e.full_name, e.department, e.job_position
          FROM employee_performance_reviews r
          JOIN employee_accounts e ON e.id = r.employee_id
          WHERE r.employee_id IN (${ph})
          ORDER BY r.created_at DESC
        `)
        .all(...empIds) as any[]
    ).filter((r) => !scope.selfOnly || r.visibility === 'EmployeeVisible');

    const targets = sqlite
      .prepare(`
        SELECT t.*, e.employee_code, e.full_name, e.department
        FROM employee_targets t
        JOIN employee_accounts e ON e.id = t.employee_id
        WHERE t.employee_id IN (${ph})
        ORDER BY t.created_at DESC
      `)
      .all(...empIds);

    res.json({ reviews, targets });
  });

  router.post('/performance/reviews', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canEvaluatePerformance) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized Managers / HR / Founder can submit performance evaluations.');
      return;
    }

    const b = req.body || {};
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(String(b.employeeId || '').trim()) as any;
    if (!emp || !canActorAccessEmployee(scope, emp)) {
      res.status(404).json({ error: 'Employee not found within your scope.' });
      return;
    }
    if (req.auth?.employeeId === emp.id && scope.mode !== 'founder') {
      rejectUnauthorized(req, res, 'Employees cannot submit self-evaluations.');
      return;
    }

    const reviewCycle = ['Monthly', 'Quarterly', 'Annual'].includes(String(b.reviewCycle)) ? String(b.reviewCycle) : 'Monthly';
    const period = String(b.period || nowIso().slice(0, 7)).trim();
    const productivityScore = Math.min(100, Math.max(0, Number(b.productivityScore ?? 90)));
    const workQualityScore = Math.min(100, Math.max(0, Number(b.workQualityScore ?? 90)));
    const attendanceScore = Math.min(100, Math.max(0, Number(b.attendanceScore ?? 95)));
    const taskCompletionScore = Math.min(100, Math.max(0, Number(b.taskCompletionScore ?? 92)));
    const rating = Number(((productivityScore + workQualityScore + attendanceScore + taskCompletionScore) / 4).toFixed(1));
    const feedback = String(b.feedback || '').trim();
    const improvementPlan = String(b.improvementPlan || '').trim();
    const visibility = b.visibility === 'ManagerOnly' ? 'ManagerOnly' : 'EmployeeVisible';

    if (!feedback) {
      res.status(400).json({ error: 'Manager evaluation feedback is required.' });
      return;
    }

    const id = `perf_${generateSecureToken(5)}`;
    const ts = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO employee_performance_reviews (
            id, employee_id, company_id, branch_id, period, review_cycle, rating,
            attendance_score, task_completion_score, productivity_score, work_quality_score,
            reviewer_id, reviewer_name, reviewer_role, feedback, improvement_plan, visibility, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          id,
          emp.id,
          emp.company_id,
          emp.branch_id || null,
          period,
          reviewCycle,
          rating,
          attendanceScore,
          taskCompletionScore,
          productivityScore,
          workQualityScore,
          req.auth!.userId,
          req.auth!.fullName,
          req.auth!.role,
          feedback,
          improvementPlan,
          visibility,
          ts,
          ts
        );
      sqlite.prepare('UPDATE employee_accounts SET performance_score = ?, performance_notes = ?, updated_at = ? WHERE id = ?').run(rating, feedback, ts, emp.id);
    })();

    logEmployeeAudit({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'PERFORMANCE_REVIEW_SUBMITTED',
      module: 'Performance',
      targetId: period,
      details: `${reviewCycle} review (${rating}/100) submitted for ${emp.employee_code}`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, id, rating });
  });

  router.post('/performance/targets', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canEvaluatePerformance) {
      rejectUnauthorized(req, res, 'Permission denied: cannot assign employee targets.');
      return;
    }
    const b = req.body || {};
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(String(b.employeeId || '').trim()) as any;
    if (!emp || !canActorAccessEmployee(scope, emp)) {
      res.status(404).json({ error: 'Employee not found within your scope.' });
      return;
    }

    const title = String(b.title || '').trim();
    const metricName = String(b.metricName || 'Target KPI').trim();
    const period = String(b.period || nowIso().slice(0, 7)).trim();
    const targetValue = Number(b.targetValue || 0);
    const achievedValue = Number(b.achievedValue || 0);
    const unit = String(b.unit || '%').trim();
    if (!title) {
      res.status(400).json({ error: 'Target title is required.' });
      return;
    }

    const id = `tgt_${generateSecureToken(5)}`;
    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT INTO employee_targets (
          id, employee_id, company_id, period, title, metric_name, target_value, achieved_value,
          unit, status, assigned_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(id, emp.id, emp.company_id, period, title, metricName, targetValue, achievedValue, unit, achievedValue >= targetValue && targetValue > 0 ? 'Achieved' : 'In Progress', req.auth!.fullName, ts, ts);

    res.status(201).json({ success: true, id });
  });

  router.patch('/performance/targets/:id', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canEvaluatePerformance) {
      rejectUnauthorized(req, res, 'Permission denied: cannot update target progress.');
      return;
    }
    const tgt = sqlite.prepare('SELECT * FROM employee_targets WHERE id = ?').get(req.params.id) as any;
    if (!tgt) {
      res.status(404).json({ error: 'Target not found.' });
      return;
    }
    const achievedValue = Number(req.body.achievedValue ?? tgt.achieved_value);
    const status = req.body.status || (achievedValue >= Number(tgt.target_value) && Number(tgt.target_value) > 0 ? 'Achieved' : 'In Progress');
    sqlite.prepare('UPDATE employee_targets SET achieved_value = ?, status = ?, updated_at = ? WHERE id = ?').run(achievedValue, status, nowIso(), tgt.id);
    res.json({ success: true });
  });

  // =========================================================================
  // 8. PRIVATE EMPLOYEE DOCUMENT VAULT (NO PUBLIC URLs + SERVER-SIDE AUTHZ)
  // =========================================================================
  router.get('/documents', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);
    const categoryFilter = String(req.query.category || '').trim();
    const verificationFilter = String(req.query.verificationStatus || '').trim();

    if (empIds.length === 0) {
      res.json({ documents: [], categories: DOCUMENT_CATEGORIES });
      return;
    }

    const ph = empIds.map(() => '?').join(',');
    const docs = (
      sqlite
        .prepare(`
          SELECT d.id, d.employee_id, d.company_id, d.category, d.title, d.original_filename, d.mime_type,
                 d.size_bytes, d.issue_date, d.expiry_date, d.verification_status, d.verified_by,
                 d.document_notes, d.uploaded_by_role, d.created_at,
                 e.employee_code, e.full_name, e.department
          FROM employee_documents d
          JOIN employee_accounts e ON e.id = d.employee_id
          WHERE d.employee_id IN (${ph})
          ORDER BY d.created_at DESC
        `)
        .all(...empIds) as any[]
    )
      .filter((d) => !categoryFilter || categoryFilter === 'ALL' || d.category === categoryFilter)
      .filter((d) => !verificationFilter || verificationFilter === 'ALL' || d.verification_status === verificationFilter);

    res.json({ documents: docs, categories: DOCUMENT_CATEGORIES });
  });

  router.post('/documents', upload.single('file'), (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const b = req.body || {};
    const targetEmpId = b.employeeId ? String(b.employeeId).trim() : req.auth?.employeeId || '';

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(targetEmpId) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }

    const isSelf = req.auth?.employeeId === emp.id;
    if ((!scope.canManageDocuments && !isSelf) || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: cannot upload documents for this employee.');
      return;
    }
    if (!req.file) {
      res.status(400).json({ error: 'Document file is required.' });
      return;
    }

    try {
      const category = String(b.category || 'Other Official Document').trim();
      const title = String(b.title || req.file.originalname).trim();
      const saved = savePrivateEmployeeDocFile({
        file: req.file,
        employeeId: emp.id,
        companyId: emp.company_id,
        countryId: emp.country_id || 'PK',
        branchId: emp.branch_id || null,
        category,
        title,
        issueDate: b.issueDate ? String(b.issueDate).slice(0, 10) : null,
        expiryDate: b.expiryDate ? String(b.expiryDate).slice(0, 10) : null,
        notes: b.notes ? String(b.notes).trim() : null,
        verificationStatus: scope.canVerifyDocuments ? 'Verified' : 'Pending Verification',
        uploadedById: req.auth!.userId,
        uploadedByRole: req.auth!.role,
      });

      logEmployeeAudit({
        employeeId: emp.id,
        companyId: emp.company_id,
        branchId: emp.branch_id,
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'DOCUMENT_UPLOADED',
        module: 'Employee Documents',
        targetId: saved.id,
        details: `Uploaded private ${category}: ${title} (${req.file.originalname})`,
        ipAddress: getClientIp(req),
      });

      res.status(201).json({ success: true, id: saved.id });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Document upload failed.' });
    }
  });

  router.patch('/documents/:id/verify', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const doc = sqlite.prepare('SELECT * FROM employee_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(doc.employee_id) as any;
    if (!scope.canVerifyDocuments || !canActorAccessEmployee(scope, emp)) {
      rejectUnauthorized(req, res, 'Permission denied: only authorized HR / Admins can verify employee documents.');
      return;
    }
    const status = ['Verified', 'Rejected', 'Pending Verification'].includes(String(req.body.verificationStatus))
      ? String(req.body.verificationStatus)
      : 'Verified';
    const ts = nowIso();
    sqlite
      .prepare('UPDATE employee_documents SET verification_status = ?, verified_by = ?, verified_at = ?, document_notes = COALESCE(?, document_notes) WHERE id = ?')
      .run(status, req.auth!.fullName, ts, req.body.notes ? String(req.body.notes) : null, doc.id);

    logEmployeeAudit({
      employeeId: doc.employee_id,
      companyId: doc.company_id,
      branchId: doc.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DOCUMENT_VERIFIED',
      module: 'Employee Documents',
      targetId: doc.id,
      details: `${status} document "${doc.title}"`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, verificationStatus: status });
  });

  router.get('/documents/:id/download', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const doc = sqlite.prepare('SELECT * FROM employee_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(doc.employee_id) as any;
    const isSelf = req.auth?.employeeId === doc.employee_id;
    const allowed = isSelf || (scope.canManageDocuments && canActorAccessEmployee(scope, emp)) || (scope.mode === 'founder');
    if (!allowed) {
      rejectUnauthorized(req, res, `Security Alert: Unauthorized attempt to download confidential document ${doc.id}.`);
      return;
    }

    const safeFile = path.basename(String(doc.storage_key));
    const fullPath = path.join(PRIVATE_EMPLOYEE_DOCS_DIR, safeFile);
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'File missing from secure private storage.' });
      return;
    }

    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `${req.query.inline === '1' ? 'inline' : 'attachment'}; filename="${encodeURIComponent(doc.original_filename || safeFile)}"`);
    fs.createReadStream(fullPath).pipe(res);
  });

  // =========================================================================
  // 9. REAL REPORTS & EXCEL (.XLSX) + PDF + CSV EXPORTS
  // =========================================================================
  function buildEmployeeReportDataset(scope: EmpMgmtScope, reportType: string, month: string) {
    const employees = getScopedEmployeeRows(scope);
    const empIds = employees.map((e) => e.id);
    const ph = empIds.length > 0 ? empIds.map(() => '?').join(',') : "''";

    if (reportType === 'attendance') {
      const rows = empIds.length
        ? (sqlite
            .prepare(`
              SELECT a.attendance_date as Date, e.employee_code as EmployeeID, e.full_name as Name,
                     e.department as Department, COALESCE(b.name, 'Head Office') as Branch,
                     a.status as Status, a.working_hours as Hours, a.overtime_hours as OvertimeHours,
                     a.work_mode as Mode
              FROM employee_attendance a
              JOIN employee_accounts e ON e.id = a.employee_id
              LEFT JOIN branches b ON b.id = COALESCE(a.branch_id, e.branch_id)
              WHERE a.attendance_date LIKE ? AND a.employee_id IN (${ph})
              ORDER BY a.attendance_date DESC
            `)
            .all(`${month}%`, ...empIds) as any[])
        : [];
      return { title: `Attendance Report (${month})`, rows };
    }

    if (reportType === 'monthly-payroll' || reportType === 'salary-history') {
      if (!scope.canAccessPayroll && !scope.selfOnly) {
        return { title: 'Payroll Report', rows: [], denied: true };
      }
      const targetIds = scope.canAccessPayroll ? empIds : [scope.selfEmployeeId!];
      const pph = targetIds.map(() => '?').join(',');
      const wherePeriod = reportType === 'monthly-payroll' ? 'AND sr.pay_period = ?' : '';
      const args = reportType === 'monthly-payroll' ? [...targetIds, month] : [...targetIds];
      const rows = targetIds.length
        ? (sqlite
            .prepare(`
              SELECT sr.pay_period as PayPeriod, e.employee_code as EmployeeID, e.full_name as Name,
                     e.department as Department, sr.currency as Currency,
                     sr.basic_salary as BasicSalary, sr.allowances as Allowances, sr.overtime_payment as Overtime,
                     (sr.tax_deduction + sr.deductions) as Deductions, sr.net_salary as NetSalary,
                     sr.approval_status as ApprovalStatus, sr.payment_status as PaymentStatus,
                     COALESCE(sr.verified_payment_ref, sr.bank_reference, 'Pending') as PaymentRef
              FROM employee_salary_records sr
              JOIN employee_accounts e ON e.id = sr.employee_id
              WHERE sr.employee_id IN (${pph}) ${wherePeriod}
              ORDER BY sr.pay_period DESC
            `)
            .all(...args) as any[])
        : [];
      return { title: reportType === 'monthly-payroll' ? `Monthly Payroll Report (${month})` : 'Salary History Report', rows };
    }

    if (reportType === 'leaves') {
      const rows = empIds.length
        ? (sqlite
            .prepare(`
              SELECT e.employee_code as EmployeeID, e.full_name as Name, e.department as Department,
                     l.leave_type as LeaveType, l.start_date as StartDate, l.end_date as EndDate,
                     l.total_days as Days, l.status as Status, COALESCE(l.reviewed_by_name, 'Pending') as Approver
              FROM employee_leave_requests l
              JOIN employee_accounts e ON e.id = l.employee_id
              WHERE l.employee_id IN (${ph})
              ORDER BY l.created_at DESC
            `)
            .all(...empIds) as any[])
        : [];
      return { title: 'Employee Leave Report', rows };
    }

    if (reportType === 'department-wise') {
      const map = new Map<string, { Department: string; Total: number; Active: number; OnLeave: number; AvgPerformance: number }>();
      for (const e of employees) {
        const k = e.department || 'Unassigned';
        const agg = map.get(k) || { Department: k, Total: 0, Active: 0, OnLeave: 0, AvgPerformance: 0 };
        agg.Total += 1;
        if (e.status === 'Active') agg.Active += 1;
        if (e.status === 'On Leave') agg.OnLeave += 1;
        agg.AvgPerformance += Number(e.performance_score || 0);
        map.set(k, agg);
      }
      const rows = Array.from(map.values()).map((r) => ({ ...r, AvgPerformance: r.Total > 0 ? Number((r.AvgPerformance / r.Total).toFixed(1)) : 0 }));
      return { title: 'Department-Wise Employee Report', rows };
    }

    if (reportType === 'branch-wise') {
      const map = new Map<string, { Branch: string; Total: number; Active: number; Inactive: number }>();
      for (const e of employees) {
        const k = e.branch_name || 'Head Office';
        const agg = map.get(k) || { Branch: k, Total: 0, Active: 0, Inactive: 0 };
        agg.Total += 1;
        if (e.status === 'Active') agg.Active += 1;
        else agg.Inactive += 1;
        map.set(k, agg);
      }
      return { title: 'Branch-Wise Employee Report', rows: Array.from(map.values()) };
    }

    if (reportType === 'performance') {
      const rows = empIds.length
        ? (sqlite
            .prepare(`
              SELECT r.period as Period, r.review_cycle as Cycle, e.employee_code as EmployeeID,
                     e.full_name as Name, e.department as Department, r.rating as OverallRating,
                     r.productivity_score as Productivity, r.work_quality_score as Quality,
                     r.attendance_score as AttendanceScore, r.reviewer_name as Reviewer
              FROM employee_performance_reviews r
              JOIN employee_accounts e ON e.id = r.employee_id
              WHERE r.employee_id IN (${ph})
              ORDER BY r.created_at DESC
            `)
            .all(...empIds) as any[])
        : [];
      return { title: 'Employee Performance Report', rows };
    }

    if (reportType === 'document-expiry') {
      const rows = empIds.length
        ? (sqlite
            .prepare(`
              SELECT e.employee_code as EmployeeID, e.full_name as Name, d.category as Category,
                     d.title as DocumentTitle, COALESCE(d.issue_date, 'N/A') as IssueDate,
                     COALESCE(d.expiry_date, 'No Expiry') as ExpiryDate, d.verification_status as Verification
              FROM employee_documents d
              JOIN employee_accounts e ON e.id = d.employee_id
              WHERE d.expiry_date IS NOT NULL AND d.expiry_date != '' AND d.employee_id IN (${ph})
              ORDER BY d.expiry_date ASC
            `)
            .all(...empIds) as any[])
        : [];
      return { title: 'Employee Document Expiry Report', rows };
    }

    // Default: total-employees
    const rows = employees.map((e) => ({
      EmployeeID: e.employee_code,
      FullName: e.full_name,
      Department: e.department,
      Position: e.job_position,
      Branch: e.branch_name || 'Head Office',
      Company: e.company_name,
      EmploymentType: e.employment_type || 'Full-Time',
      JoiningDate: e.joined_at?.slice(0, 10),
      Status: e.status,
    }));
    return { title: 'Total Employee Report', rows };
  }

  router.get('/reports', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const type = String(req.query.type || 'total-employees');
    const month = String(req.query.month || nowIso().slice(0, 7)).slice(0, 7);
    const data = buildEmployeeReportDataset(scope, type, month);
    if ((data as any).denied) {
      rejectUnauthorized(req, res, 'Permission denied: payroll reports require Finance or Founder access.');
      return;
    }
    res.json({ type, month, generatedAt: nowIso(), ...data });
  });

  router.get('/reports/export', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canExportReports) {
      rejectUnauthorized(req, res, 'Permission denied: you are not authorized to export employee reports.');
      return;
    }
    const type = String(req.query.type || 'total-employees');
    const format = String(req.query.format || 'xlsx').toLowerCase();
    const month = String(req.query.month || nowIso().slice(0, 7)).slice(0, 7);
    const data = buildEmployeeReportDataset(scope, type, month);
    if ((data as any).denied) {
      rejectUnauthorized(req, res, 'Permission denied: payroll report export requires Finance or Founder access.');
      return;
    }

    logEmployeeAudit({
      companyId: scope.restrictedCompanyId,
      branchId: scope.restrictedBranchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_REPORT_EXPORTED',
      module: 'Reports',
      targetId: `${type}:${format.toUpperCase()}`,
      details: `Exported ${data.title} as ${format.toUpperCase()} (${data.rows.length} rows)`,
      ipAddress: getClientIp(req),
    });

    if (format === 'pdf') {
      const lines = [
        `BYD PAKISTAN 360 - ${data.title.toUpperCase()}`,
        `Founder & CEO: Intekhab Alam | Exported By: ${req.auth!.fullName} (${req.auth!.role})`,
        `Generated: ${nowIso()} | Rows: ${data.rows.length}`,
        '-----------------------------------------------------------------------',
        ...(data.rows.length === 0
          ? ['No records matched the selected report filters.']
          : data.rows.slice(0, 60).map((r) => Object.entries(r).map(([k, v]) => `${k}: ${v}`).join(' | '))),
      ];
      const pdf = buildSimplePdfBuffer(`BYD 360 - ${data.title}`, lines);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360_${type}_${month}.pdf"`);
      res.send(pdf);
      return;
    }

    const wb = XLSX.utils.book_new();
    const sheet = XLSX.utils.json_to_sheet(data.rows.length > 0 ? data.rows : [{ Message: 'No records matched filter' }]);
    XLSX.utils.book_append_sheet(wb, sheet, type.slice(0, 28));
    if (format === 'csv') {
      const csv = XLSX.utils.sheet_to_csv(sheet);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360_${type}_${month}.csv"`);
      res.send('\uFEFF' + csv);
      return;
    }
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="BYD360_${type}_${month}.xlsx"`);
    res.send(buf);
  });

  // =========================================================================
  // 10. SETTINGS & IMMUTABLE AUDIT LOGS
  // =========================================================================
  router.get('/settings', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const companyId = scope.restrictedCompanyId || String(req.query.companyId || 'comp_byd_pk').trim();
    const row = sqlite.prepare('SELECT * FROM employee_module_settings WHERE company_id = ?').get(companyId) as any;
    res.json({
      settings: row || {
        company_id: companyId,
        employee_id_prefix: 'BYD-PAK-EMP-',
        work_start_time: '09:00',
        work_end_time: '18:00',
        late_grace_minutes: 15,
        annual_leave_default: 18,
        sick_leave_default: 10,
        casual_leave_default: 8,
        overtime_hourly_rate: 1200,
      },
      canEdit: scope.canManageSettings,
    });
  });

  router.put('/settings', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    if (!scope.canManageSettings) {
      rejectUnauthorized(req, res, 'Permission denied: only Founder or authorized Company Admins can update Employee Module settings.');
      return;
    }

    const b = req.body || {};
    const companyId = scope.restrictedCompanyId || String(b.companyId || 'comp_byd_pk').trim();
    const prefix = String(b.employeeIdPrefix || 'BYD-PAK-EMP-').trim().toUpperCase();
    const workStart = String(b.workStartTime || '09:00').trim();
    const workEnd = String(b.workEndTime || '18:00').trim();
    const lateGrace = Math.max(0, Number(b.lateGraceMinutes ?? 15));
    const annualDefault = Math.max(0, Number(b.annualLeaveDefault ?? 18));
    const sickDefault = Math.max(0, Number(b.sickLeaveDefault ?? 10));
    const casualDefault = Math.max(0, Number(b.casualLeaveDefault ?? 8));
    const overtimeRate = Math.max(0, Number(b.overtimeHourlyRate ?? 1200));
    const ts = nowIso();

    sqlite
      .prepare(`
        INSERT INTO employee_module_settings (
          id, company_id, employee_id_prefix, work_start_time, work_end_time, late_grace_minutes,
          annual_leave_default, sick_leave_default, casual_leave_default, overtime_hourly_rate, updated_by, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(company_id) DO UPDATE SET
          employee_id_prefix = excluded.employee_id_prefix,
          work_start_time = excluded.work_start_time,
          work_end_time = excluded.work_end_time,
          late_grace_minutes = excluded.late_grace_minutes,
          annual_leave_default = excluded.annual_leave_default,
          sick_leave_default = excluded.sick_leave_default,
          casual_leave_default = excluded.casual_leave_default,
          overtime_hourly_rate = excluded.overtime_hourly_rate,
          updated_by = excluded.updated_by,
          updated_at = excluded.updated_at
      `)
      .run(`ems_${generateSecureToken(5)}`, companyId, prefix, workStart, workEnd, lateGrace, annualDefault, sickDefault, casualDefault, overtimeRate, req.auth!.fullName, ts);

    logEmployeeAudit({
      companyId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_SETTINGS_UPDATED',
      module: 'Settings',
      targetId: companyId,
      details: `Updated Employee Module rules: Prefix=${prefix}, Shift=${workStart}-${workEnd}, OT=${overtimeRate}/hr`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  router.get('/audit-logs', (req: Request, res: Response) => {
    const scope = (req as any).empScope as EmpMgmtScope;
    const empIds = new Set(getScopedEmployeeRows(scope).map((e) => e.id));
    const logs = (sqlite.prepare('SELECT * FROM employee_audit_logs ORDER BY created_at DESC LIMIT 200').all() as any[]).filter((l) => {
      if (scope.selfOnly) return l.employee_id === scope.selfEmployeeId;
      if (scope.restrictedCompanyId && l.company_id && l.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedBranchId && l.branch_id && l.branch_id !== scope.restrictedBranchId) return false;
      if (l.employee_id && !empIds.has(l.employee_id) && scope.mode !== 'founder') return false;
      return true;
    });
    res.json({ immutable: true, logs });
  });

  return router;
}
