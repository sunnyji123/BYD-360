import React, { useState } from 'react';
import {
  ShieldAlert,
  FileText,
  Lock,
  Building,
  Scale,
  Award,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Mail,
  Phone,
  Server,
  Globe,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AboutProject: React.FC = () => {
  const { setActiveTab } = useApp();
  const [activeTab, setActiveTabLocal] = useState<'about' | 'disclaimer' | 'privacy' | 'terms'>('about');

  return (
    <div className="space-y-8 pb-16 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-8 text-center space-y-4 shadow-xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-cyan-950 border border-cyan-500/40 text-xs font-bold text-cyan-300">
          <Scale className="w-3.5 h-3.5 text-cyan-400" />
          <span>Independent Proposal & Legal Compliance Notice</span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          About BYD GLOBAL MOBILITY & OPERATIONS PLATFORM
        </h1>
        <p className="text-sm text-slate-300 max-w-3xl mx-auto leading-relaxed">
          An independent enterprise automotive and electric vehicle management ecosystem proposal with a proposed target project value of <strong>PKR 20–25 Million (2–2.5 Crore Pakistani Rupees)</strong>. Designed as a scalable software architecture for potential evaluation across Pakistan, Middle East, and international expansion corridors.
        </p>

        {/* Tab Pills */}
        <div className="pt-2 flex flex-wrap justify-center gap-2">
          {[
            { id: 'about', label: 'About This Project' },
            { id: 'disclaimer', label: 'Legal Disclaimers & IP' },
            { id: 'privacy', label: 'Privacy & Data Protection' },
            { id: 'terms', label: 'Terms of Evaluation' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTabLocal(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === tab.id
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: About This Project */}
      {activeTab === 'about' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          {/* Official Founder & Creator Section */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border border-cyan-500/40 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                  OFFICIAL FOUNDER & CREATOR ATTRIBUTION
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">
                  INTEKHAB ALAM
                </h3>
                <p className="text-xs text-cyan-300 font-semibold tracking-wide">
                  FOUNDER &amp; CEO — PRIMARY OWNER — BYD PAKISTAN 360
                </p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800 text-xs font-semibold text-cyan-300">
                <Award className="w-4 h-4 text-cyan-400" />
                <span>Primary Owner &amp; Creator</span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              <strong>BYD PAKISTAN 360</strong> was founded, conceptualized, and architected by <strong>INTEKHAB ALAM</strong> (Founder &amp; CEO) as an independent enterprise automotive software ecosystem and commercial solution proposal designed for potential evaluation by <strong>BYD Pakistan / Mega Motor Company (Private) Limited</strong>.
            </p>

            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-400">
              <strong className="text-slate-300 font-semibold">Primary Owner Governance Notice:</strong> Intekhab Alam holds the segregated Global Primary Owner portal with mandatory 2FA, company registration approvals, Super Admin RBAC governance, and BYD AI policy oversight. Public registration never grants Owner privileges.
            </div>
          </div>

          <div className="flex items-center gap-2 text-cyan-400 font-bold text-base border-b border-slate-800 pb-3 pt-2">
            <Award className="w-5 h-5 text-cyan-400" />
            <span>Project Objectives & Demonstration Scope</span>
          </div>

          <p>
            The <strong>BYD PAKISTAN 360</strong> platform has been architected to showcase how a modern automotive enterprise software ecosystem can power the rapid growth of New Energy Vehicles (NEVs) in Pakistan.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider text-cyan-300">Customer Empowerment & Data Isolation</h4>
              <p className="text-slate-400 text-xs">
                Enables verified EV owners across Karachi, Lahore, Islamabad, and beyond to manage authenticated vehicles, track Blade Battery health, monitor real-time service job cards, and manage verified digital title ownership transfers.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-white text-xs uppercase tracking-wider text-cyan-300">3S Dealership & Workshop Backbone</h4>
              <p className="text-xs text-slate-400">
                Provides authorized dealers with sales inquiry pipelines, vehicle ownership transfer desk with multi-document verification, high-voltage safety inspection checklists, spare parts inventory, and warranty claim submission workflows.
              </p>
            </div>
          </div>

          <p className="pt-2">
            The platform is built on modern Progressive Web App (PWA) standards, ensuring that corporate management, service technicians, and customers can install and run the application natively across Android, iOS Safari, tablets, and desktop workstations with offline support.
          </p>
        </div>
      )}

      {/* Tab 2: Legal Disclaimers & IP */}
      {activeTab === 'disclaimer' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-base border-b border-slate-800 pb-3">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <span>Independent Demonstration & Brand Compliance</span>
          </div>

          <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs space-y-2">
            <p className="font-bold">CRITICAL DISCLOSURE:</p>
            <p>
              This application is an independent software design demonstration and functional proposal. It is <strong>NOT</strong> officially owned, operated, approved, endorsed, or affiliated with <strong>BYD Company Limited</strong>, <strong>BYD Auto</strong>, or <strong>Mega Motor Company (Private) Limited</strong>.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Permitted Use of Brand Names & Trademarks:</h4>
            <p>
              All trademarks, vehicle model designations (such as "BYD Seal", "BYD Atto 3", "BYD Sealion 6", "BYD Shark 6", "Blade Battery", "e-Platform 3.0", "DM-i"), and trade names referenced herein are the intellectual property of their respective owners. Their inclusion in this software prototype is solely for descriptive, technological demonstration, and illustrative evaluation purposes.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Simulated Telematics & Demo Data Notice:</h4>
            <p>
              This system does not have live access to internal BYD vehicle telematics servers, proprietary CAN-bus networks, confidential customer databases, or Mega Motor internal dealership management systems (DMS). All vehicle battery readings, sensor traces, booking counts, revenue numbers, and customer names displayed in this prototype are clearly labeled as <strong>DEMO DATA</strong>.
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Privacy & Data Protection */}
      {activeTab === 'privacy' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-base border-b border-slate-800 pb-3">
            <Lock className="w-5 h-5 text-emerald-400" />
            <span>Privacy Policy & Pakistan Data Protection Compliance</span>
          </div>

          <p>
            We adhere to privacy-by-design standards in alignment with the <strong>Prevention of Electronic Crimes Act (PECA 2016)</strong> of the Islamic Republic of Pakistan and international data sovereignty principles.
          </p>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">1. Information Collection:</h4>
            <p>
              In this demonstration sandbox, all user accounts, vehicle registrations, and service records are stored securely in local browser storage (or optional user-provisioned Firebase Firestore). No private personal data or national identity card (CNIC) numbers are sold, broadcast, or shared with third parties.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">2. Role-Based Data Isolation:</h4>
            <p>
              Role-Based Access Control (RBAC) ensures that customer contact details and private vehicle VIN records are accessible only to authorized service managers and the vehicle owner. Sales executives and technicians are strictly restricted to their assigned work orders.
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">3. AI Safety & Confidentiality:</h4>
            <p>
              Automotive advisory inquiries sent to the Gemini AI backend are sanitized and proxied securely through server-side functions. No customer credentials, passwords, or payment tokens are transmitted to large language model training pipelines.
            </p>
          </div>
        </div>
      )}

      {/* Tab 4: Terms of Use */}
      {activeTab === 'terms' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed">
          <div className="flex items-center gap-2 text-blue-400 font-bold text-base border-b border-slate-800 pb-3">
            <FileText className="w-5 h-5 text-blue-400" />
            <span>Terms of Prototype Evaluation</span>
          </div>

          <p>
            By evaluating and testing the <strong>BYD PAKISTAN 360</strong> application, reviewers and stakeholders agree to the following terms:
          </p>

          <ul className="list-disc pl-5 space-y-2 text-slate-300">
            <li><strong>Evaluation Only:</strong> The software is provided as a working proposal prototype for potential commercial partnership and evaluation. It must not be deployed in life-critical automotive operations without official hardware validation.</li>
            <li><strong>No Official Warranty Guarantee:</strong> Warranty claim submissions and approvals processed in this demo are illustrative workflows and do not constitute legal financial obligations upon BYD or Mega Motor Company.</li>
            <li><strong>Audit Logging:</strong> All administrative modifications, role alterations, and mock diagnostic uploads are logged to the tamper-evident audit trail for verification.</li>
          </ul>

          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <span className="text-slate-400">Formal Inquiries: contact@bydpakistan.demo</span>
            <button
              onClick={() => setActiveTab('presentation')}
              className="text-cyan-400 hover:text-cyan-300 font-bold"
            >
              Review Business Presentation Deck →
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
