export interface ApiError extends Error {
  status?: number;
  code?: string;
}

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const isFormData = options.body instanceof FormData;
  const headers: Record<string, string> = isFormData
    ? { ...((options.headers as Record<string, string>) || {}) }
    : {
        'Content-Type': 'application/json',
        ...((options.headers as Record<string, string>) || {}),
      };

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || data.details || `Request failed with HTTP ${res.status}`) as ApiError;
    err.status = res.status;
    err.code = data.code;
    throw err;
  }
  return data as T;
}

export interface ChatResponse {
  reply: string;
  model: string;
  conversationId?: string | null;
  biScope?: string;
}

export interface BatteryAnalysisResponse {
  analysis: string;
  model: string;
  isFallback?: boolean;
}

export interface ExecutiveSummaryResponse {
  summary: string;
  model: string;
  isFallback?: boolean;
}

export const api = {
  // ---------------- Health & Public ----------------
  getHealth() {
    return request<any>('/api/health');
  },
  getPublicCompanies() {
    return request<{ companies: any[]; dealerships: any[] }>('/api/public/companies');
  },

  // ---------------- Founder / Owner Auth & Governance ----------------
  getFounderStatus() {
    return request<{
      initialized: boolean;
      founderName: string;
      role: string;
      accountType: string;
      accessLevel: string;
      twoFactorRequired: boolean;
      requiresSetupSecret: boolean;
    }>('/api/auth/founder/status');
  },

  initializeFounder(payload: { email: string; mobile: string; password: string; setupSecret?: string }) {
    return request<{
      success: boolean;
      message: string;
      founder: any;
      twoFactorSetup: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
    }>('/api/auth/founder/initialize', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  founderLogin(payload: { identifier: string; password: string }) {
    return request<{
      requires2FA: boolean;
      challengeToken: string;
      founderName: string;
      role: string;
      suspiciousIpDetected: boolean;
      message: string;
    }>('/api/auth/founder/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  founderVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any; message?: string }>('/api/auth/founder/verify-2fa', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getOwnerOverview() {
    return request<any>('/api/owner/overview');
  },

  createSuperAdmin(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    country: string;
    city: string;
    permissions: string[];
  }) {
    return request<{
      success: boolean;
      superAdmin: any;
      twoFactorSetup?: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/owner/super-admins', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  inviteSuperAdmin(payload: {
    fullName: string;
    email: string;
    mobile?: string;
    country: string;
    city: string;
    permissions: string[];
  }) {
    return request<{
      success: boolean;
      invitationId: string;
      inviteToken: string;
      inviteUrl: string;
      expiresAt: string;
      message: string;
    }>('/api/owner/super-admins/invite', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminPermissions(id: string, payload: { permissions?: string[]; status?: 'Active' | 'Suspended' }) {
    return request<{ success: boolean }>(`/api/owner/super-admins/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  approveCompany(id: string, payload: { status: 'Approved' | 'Rejected' | 'Suspended'; reason?: string }) {
    return request<{ success: boolean }>(`/api/owner/companies/${id}/approve`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createCompanyAdmin(payload: {
    companyId: string;
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    designation?: string;
    permissions?: string[];
  }) {
    return request<{
      success: boolean;
      companyAdmin: any;
      twoFactorSetup?: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/owner/company-admins', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminPermissions(id: string, payload: { permissions?: string[]; status?: 'Active' | 'Suspended' }) {
    return request<{ success: boolean }>(`/api/owner/company-admins/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createCountryManager(payload: {
    countryId: string;
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    designation?: string;
    managerCode?: string;
    permissions?: string[];
  }) {
    return request<{
      success: boolean;
      countryManager: any;
      twoFactorSetup?: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/owner/country-managers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  assignCountryManagerCountry(id: string, payload: { countryId: string; notes?: string }) {
    return request<{ success: boolean; previousCountry: string; countryId: string; countryName: string }>(
      `/api/owner/country-managers/${id}/assign-country`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    );
  },

  updateCountryManagerPermissions(id: string, payload: { permissions?: string[]; status?: 'Active' | 'Suspended' }) {
    return request<{ success: boolean }>(`/api/owner/country-managers/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  decideCountryEscalation(id: string, payload: { status: 'Approved' | 'Rejected'; reviewNotes?: string }) {
    return request<{ success: boolean; id: string; status: string }>(`/api/owner/country-escalations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getOwnerSecurityEvents() {
    return request<{ events: any[]; loginHistory: any[]; activeSessions: any[] }>('/api/owner/security-events');
  },

  acknowledgeSecurityEvent(id: string) {
    return request<{ success: boolean }>(`/api/owner/security-events/${id}/ack`, {
      method: 'PATCH',
    });
  },

  getOwnerAuditLogs() {
    return request<{ logs: any[] }>('/api/owner/audit-logs');
  },

  getOwnerSettings() {
    return request<{ securityPolicy: any; aiConfig: any }>('/api/owner/settings');
  },

  updateOwnerSettings(securityPolicy: any) {
    return request<{ success: boolean; securityPolicy: any }>('/api/owner/settings', {
      method: 'PUT',
      body: JSON.stringify({ securityPolicy }),
    });
  },

  exportOwnerBackup() {
    return request<any>('/api/owner/backup/export');
  },

  getOwnerAiSettings() {
    return request<any>('/api/owner/ai-settings');
  },

  updateOwnerAiSettings(payload: {
    globalEnabled: boolean;
    defaultModel: string;
    dailyLimitPerCompany: number;
    dailyLimitPerUser: number;
    allowDocumentAnalysis: boolean;
    allowVoiceAssistant: boolean;
    companyOverrides?: Array<{ id: string; ai_enabled: boolean; ai_daily_limit: number }>;
  }) {
    return request<{ success: boolean; aiConfig: any }>('/api/owner/ai-settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  getOwnerAnalyticsOverview(track = false) {
    return request<{ overview: any; timeSeries: any[] }>(`/api/owner/analytics-overview${track ? '?track=1' : ''}`);
  },

  getOwnerCountries() {
    return request<{ totalRegisteredCountries: number; activeOperationalCountries: number; countries: any[] }>(
      '/api/owner/countries'
    );
  },

  getOwnerFinance(params?: { period?: string; fromDate?: string; toDate?: string; countryId?: string }) {
    const qs = new URLSearchParams();
    if (params?.period) qs.set('period', params.period);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    if (params?.countryId) qs.set('countryId', params.countryId);
    const query = qs.toString();
    return request<{
      filter: any;
      summary: any;
      countryFinancialReports: any[];
      timeSeries: any[];
      transactions: any[];
    }>(`/api/owner/finance${query ? `?${query}` : ''}`);
  },

  getOwnerSales(params?: {
    period?: string;
    fromDate?: string;
    toDate?: string;
    countryId?: string;
    status?: string;
    search?: string;
  }) {
    const qs = new URLSearchParams();
    if (params?.period) qs.set('period', params.period);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    if (params?.countryId) qs.set('countryId', params.countryId);
    if (params?.status) qs.set('status', params.status);
    if (params?.search) qs.set('search', params.search);
    const query = qs.toString();
    return request<{
      summary: any;
      byCountry: any[];
      byModel: any[];
      monthlyTrend: any[];
      yearlyTrend: any[];
      records: any[];
    }>(`/api/owner/sales${query ? `?${query}` : ''}`);
  },

  getOwnerSaleDetail(recordId: string) {
    return request<{ source: string; record: any; commission: any; customer: any }>(
      `/api/owner/sales/${encodeURIComponent(recordId)}`
    );
  },

  getOwnerWorkforce() {
    return request<{
      employeesOverview: { summary: any; byCountry: any[]; byDepartment: any[]; employees: any[] };
      dealershipsOverview: { summary: any; byCountry: any[]; dealerships: any[] };
    }>('/api/owner/workforce');
  },

  getOwnerEmployeeDetail(employeeId: string) {
    return request<{ employee: any; salaryHistory: any[]; loginLogs: any[] }>(
      `/api/owner/workforce/employees/${encodeURIComponent(employeeId)}`
    );
  },

  getOwnerDealershipDetail(dealershipId: string) {
    return request<{ dealership: any; dealerAccount: any; sales: any[]; bookings: any[]; commissions: any[]; vehicles: any[] }>(
      `/api/owner/workforce/dealerships/${encodeURIComponent(dealershipId)}`
    );
  },

  getOwnerSuperAdminActivity() {
    return request<{ superAdmins: any[]; activeSessions: any[]; loginLogs: any[]; activities: any[] }>(
      '/api/owner/super-admins/activity'
    );
  },

  revokeSuperAdminAccess(id: string, reason?: string) {
    return request<{ success: boolean; message: string }>(`/api/owner/super-admins/${encodeURIComponent(id)}/revoke-access`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  getOwnerRbacOverview() {
    return request<{ roles: string[]; modules: string[]; matrix: any[]; roleSummaries: any[] }>(
      '/api/owner/rbac-overview'
    );
  },

  updateOwnerRbacOverview(updates: Array<{
    roleKey: string;
    moduleKey: string;
    canView: boolean;
    canCreate: boolean;
    canEdit: boolean;
    canDelete: boolean;
    canApprove: boolean;
  }>) {
    return request<{ success: boolean; updatedCount: number }>('/api/owner/rbac-overview', {
      method: 'PUT',
      body: JSON.stringify({ updates }),
    });
  },

  getOwnerActivityLogs(params?: { category?: string; search?: string; fromDate?: string; toDate?: string; limit?: number }) {
    const qs = new URLSearchParams();
    if (params?.category) qs.set('category', params.category);
    if (params?.search) qs.set('search', params.search);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    if (params?.limit) qs.set('limit', String(params.limit));
    const query = qs.toString();
    return request<{ immutable: boolean; totalMatched: number; logs: any[] }>(
      `/api/owner/activity-logs${query ? `?${query}` : ''}`
    );
  },

  // ---------------- Isolated Super Admin Auth & Management APIs ----------------
  getSuperAdminStatus() {
    return request<{
      hasSuperAdmin: boolean;
      founderProvisioned: boolean;
      twoFactorRequired: boolean;
      inviteOnly: boolean;
    }>('/api/auth/super-admin/status');
  },

  lookupSuperAdminInvite(token: string) {
    return request<{
      valid: boolean;
      fullName: string;
      email: string;
      mobile: string;
      country: string;
      city: string;
      permissions: string[];
      expiresAt: string;
    }>(`/api/auth/super-admin/invite/${encodeURIComponent(token)}`);
  },

  acceptSuperAdminInvite(payload: { token: string; password: string; mobile?: string }) {
    return request<{
      success: boolean;
      requiresEmailVerification: boolean;
      email: string;
      message: string;
      twoFactorSetup: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/auth/super-admin/accept-invite', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  superAdminLogin(payload: { identifier: string; password: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      challengeToken?: string;
      email: string;
      fullName?: string;
      suspiciousIpDetected?: boolean;
      message: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/super-admin/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  superAdminVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requires2FA: boolean;
      challengeToken: string;
      email: string;
      fullName: string;
      message: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/super-admin/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  superAdminVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any }>('/api/auth/super-admin/verify-2fa', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  superAdminForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/super-admin/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  superAdminResetPassword(payload: { token?: string; email?: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/super-admin/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  superAdminLogout() {
    return request<{ success: boolean }>('/api/auth/super-admin/logout', { method: 'POST' });
  },

  getSuperAdminDashboard() {
    return request<{
      actor: any;
      metrics: any;
      pendingDealerships: any[];
      recentActivitiesList: any[];
      recentSecurityAlerts: any[];
      recentNotifications: any[];
    }>('/api/super-admin/dashboard');
  },

  getSuperAdminCompanies() {
    return request<{ companies: any[] }>('/api/super-admin/companies');
  },

  updateSuperAdminCompany(id: string, payload: { phone?: string; city?: string; address?: string; authorizedRep?: string }) {
    return request<{ success: boolean }>(`/api/super-admin/companies/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminDealerships() {
    return request<{ dealerships: any[] }>('/api/super-admin/dealerships');
  },

  createSuperAdminDealership(payload: any) {
    return request<{ success: boolean; id: string }>('/api/super-admin/dealerships', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminDealershipStatus(id: string, status: 'Approved' | 'Pending Approval' | 'Rejected' | 'Suspended') {
    return request<{ success: boolean }>(`/api/super-admin/dealerships/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  getSuperAdminUsers(category: 'all' | 'employees' | 'dealers' | 'customers' = 'all') {
    return request<{ users: any[] }>(`/api/super-admin/users?category=${category}`);
  },

  createSuperAdminUser(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    role: string;
    companyId?: string;
    dealershipId?: string;
    country?: string;
    city?: string;
  }) {
    return request<{ success: boolean; id: string; role: string }>('/api/super-admin/users', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminUser(id: string, payload: {
    fullName?: string;
    mobile?: string;
    role?: string;
    city?: string;
    status?: 'Active' | 'Suspended' | 'Pending Verification';
    emailVerified?: boolean;
  }) {
    return request<{ success: boolean }>(`/api/super-admin/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminVehicles() {
    return request<{ vehicles: any[] }>('/api/super-admin/vehicles');
  },

  createSuperAdminVehicle(payload: any) {
    return request<{ success: boolean; id: string; vin: string }>('/api/super-admin/vehicles', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminVehicle(id: string, payload: { status?: string; batteryHealthSoh?: number; markAsSold?: boolean }) {
    return request<{ success: boolean }>(`/api/super-admin/vehicles/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminBookingsSales() {
    return request<{ bookings: any[]; serviceJobs: any[]; warrantyClaims: any[]; invoices: any[]; soldVehicles: any[] }>(
      '/api/super-admin/bookings-sales'
    );
  },

  updateSuperAdminBookingStatus(id: string, status: string) {
    return request<{ success: boolean }>(`/api/super-admin/bookings/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  updateSuperAdminWarrantyClaim(id: string, payload: { status: string; reviewNotes?: string }) {
    return request<{ success: boolean }>(`/api/super-admin/warranty-claims/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminReports() {
    return request<{
      generatedAt: string;
      regionalDealerships: any[];
      vehiclesByModel: any[];
      usersByRole: any[];
      revenueByGateway: any[];
      serviceStatusBreakdown: any[];
    }>('/api/super-admin/reports');
  },

  getSuperAdminSupportRequests() {
    return request<{ tickets: any[] }>('/api/super-admin/support-requests');
  },

  createSuperAdminSupportRequest(payload: any) {
    return request<{ success: boolean; id: string; ticketNumber: string }>('/api/super-admin/support-requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminSupportRequest(id: string, payload: { status?: string; assignedTo?: string; resolutionNotes?: string }) {
    return request<{ success: boolean }>(`/api/super-admin/support-requests/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminNotifications() {
    return request<{ notifications: any[] }>('/api/super-admin/notifications');
  },

  createSuperAdminNotification(payload: { title: string; message: string; category?: string; companyId?: string }) {
    return request<{ success: boolean; id: string }>('/api/super-admin/notifications', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminSettings() {
    return request<{ operationalSettings: any }>('/api/super-admin/settings');
  },

  updateSuperAdminSettings(operationalSettings: any) {
    return request<{ success: boolean; operationalSettings: any }>('/api/super-admin/settings', {
      method: 'PUT',
      body: JSON.stringify({ operationalSettings }),
    });
  },

  getSuperAdminAuditLogs() {
    return request<{ adminActivities: any[]; loginHistory: any[]; securityEvents: any[] }>('/api/super-admin/audit-logs');
  },

  // ---------------- Super Admin Enterprise Extensions ----------------
  getSuperAdminUsersDirectory(params?: { search?: string; role?: string; status?: string; country?: string }) {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.role) qs.set('role', params.role);
    if (params?.status) qs.set('status', params.status);
    if (params?.country) qs.set('country', params.country);
    return request<{ users: any[]; totalCount: number; availableRoles: string[] }>(
      `/api/super-admin/users/directory?${qs.toString()}`
    );
  },

  getSuperAdminUserProfile(id: string) {
    return request<{
      profile: any;
      assignedPermissions: string[];
      loginHistory: any[];
      approvalHistory: any[];
      documents: any[];
    }>(`/api/super-admin/users/${encodeURIComponent(id)}/profile`);
  },

  updateSuperAdminUserAccess(
    id: string,
    payload: { status?: string; verificationStatus?: string; permissions?: string[] }
  ) {
    return request<{ success: boolean; status: string; verificationStatus: string }>(
      `/api/super-admin/users/${encodeURIComponent(id)}/access`,
      { method: 'PATCH', body: JSON.stringify(payload) }
    );
  },

  createSuperAdminCompany(payload: {
    name: string;
    country: string;
    city: string;
    officialEmail: string;
    phone: string;
    address: string;
    registrationDetails: string;
    authorizedRep: string;
    website?: string;
    taxId?: string;
  }) {
    return request<{ success: boolean; id: string; status: string }>('/api/super-admin/companies', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminCompanyDetail(id: string) {
    return request<{
      company: any;
      branches: any[];
      dealerships: any[];
      employees: any[];
      activityLogs: any[];
      performance: any;
    }>(`/api/super-admin/companies/${encodeURIComponent(id)}/detail`);
  },

  updateSuperAdminCompanyDocuments(
    id: string,
    payload: {
      website?: string;
      taxId?: string;
      registrationDetails?: string;
      newDocument?: { title: string; docType?: string; referenceNo?: string; status?: string };
    }
  ) {
    return request<{ success: boolean; documents: any[] }>(
      `/api/super-admin/companies/${encodeURIComponent(id)}/documents`,
      { method: 'PATCH', body: JSON.stringify(payload) }
    );
  },

  getSuperAdminEmployees(params?: {
    search?: string;
    country?: string;
    companyId?: string;
    branchId?: string;
    department?: string;
    status?: string;
  }) {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.country) qs.set('country', params.country);
    if (params?.companyId) qs.set('companyId', params.companyId);
    if (params?.branchId) qs.set('branchId', params.branchId);
    if (params?.department) qs.set('department', params.department);
    if (params?.status) qs.set('status', params.status);
    return request<{
      employees: any[];
      summary: { totalEmployees: number; activeEmployees: number; onLeaveEmployees: number; suspendedEmployees: number };
      countryBreakdown: any[];
      branches: any[];
      countries: any[];
      departments: string[];
    }>(`/api/super-admin/employees?${qs.toString()}`);
  },

  createSuperAdminEmployee(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    companyId: string;
    branchId?: string;
    countryId: string;
    department: string;
    jobPosition: string;
    permissions?: string[];
  }) {
    return request<{ success: boolean; id: string; employeeCode: string }>('/api/super-admin/employees', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateSuperAdminEmployee(
    id: string,
    payload: {
      fullName?: string;
      mobile?: string;
      department?: string;
      jobPosition?: string;
      branchId?: string | null;
      countryId?: string;
      status?: 'Active' | 'Suspended' | 'On Leave';
      permissions?: string[];
    }
  ) {
    return request<{ success: boolean }>(`/api/super-admin/employees/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getSuperAdminEmployeeDetail(id: string) {
    return request<{ employee: any; activityLogs: any[]; loginHistory: any[] }>(
      `/api/super-admin/employees/${encodeURIComponent(id)}/detail`
    );
  },

  getSuperAdminDealersAnalytics() {
    return request<{ countryBreakdown: any[]; recentTransactions: any[]; dealerPerformance: any[] }>(
      '/api/super-admin/dealers/analytics'
    );
  },

  getSuperAdminCustomerDetail(id: string) {
    return request<{
      customer: any;
      profile: any;
      vehicles: any[];
      inquiries: any[];
      bookings: any[];
      payments: any[];
      serviceRequests: any[];
      warrantyClaims: any[];
      activity: any[];
      privacyMode: string;
    }>(`/api/super-admin/customers/${encodeURIComponent(id)}/detail`);
  },

  getSuperAdminMonitoring() {
    return request<{
      checkedAt: string;
      server: any;
      database: any;
      api: any;
      security: any;
      backgroundJobs: any[];
      alerts: Array<{ severity: 'INFO' | 'WARNING' | 'CRITICAL'; code: string; message: string }>;
    }>('/api/super-admin/monitoring');
  },

  getSuperAdminVerificationHub() {
    return request<{ companies: any[]; companyReviewLogs: any[] }>('/api/super-admin/verification-hub');
  },

  decideSuperAdminCompanyVerification(
    id: string,
    payload: { decision: 'mark_under_review' | 'request_documents' | 'verify_documents' | 'approve_company'; remarks?: string }
  ) {
    return request<{ success: boolean; verificationSummary: any }>(
      `/api/super-admin/verification-hub/companies/${encodeURIComponent(id)}/decision`,
      { method: 'POST', body: JSON.stringify(payload) }
    );
  },

  getSuperAdminEnterpriseAnalytics(params?: {
    period?: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom' | 'all';
    fromDate?: string;
    toDate?: string;
    country?: string;
  }) {
    const qs = new URLSearchParams();
    if (params?.period) qs.set('period', params.period);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    if (params?.country) qs.set('country', params.country);
    return request<any>(`/api/super-admin/reports/analytics?${qs.toString()}`);
  },

  getSuperAdminReportExportUrl(
    format: 'csv' | 'pdf',
    params?: { period?: string; fromDate?: string; toDate?: string; country?: string }
  ) {
    const qs = new URLSearchParams({ format });
    if (params?.period) qs.set('period', params.period);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    if (params?.country) qs.set('country', params.country);
    return `/api/super-admin/reports/export?${qs.toString()}`;
  },

  getSuperAdminEnterpriseActivityLogs(params?: {
    search?: string;
    module?: string;
    status?: string;
    fromDate?: string;
    toDate?: string;
  }) {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.module) qs.set('module', params.module);
    if (params?.status) qs.set('status', params.status);
    if (params?.fromDate) qs.set('fromDate', params.fromDate);
    if (params?.toDate) qs.set('toDate', params.toDate);
    return request<{
      immutable: boolean;
      activities: any[];
      saLoginHistory: any[];
      securityEvents: any[];
      modules: string[];
    }>(`/api/super-admin/activity-logs/enterprise?${qs.toString()}`);
  },

  // ---------------- Isolated Company Admin Auth & Management APIs ----------------
  getCompanyAdminStatus() {
    return request<{
      hasCompanyAdmins: boolean;
      approvedCompaniesCount: number;
      twoFactorRequired: boolean;
      emailVerificationRequired: boolean;
      portalIsolated: boolean;
    }>('/api/auth/company-admin/status');
  },

  companyAdminLogin(payload: { identifier: string; password: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      challengeToken?: string;
      email: string;
      fullName?: string;
      companyId?: string;
      companyName?: string;
      suspiciousIpDetected?: boolean;
      message: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/company-admin/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  companyAdminVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requires2FA?: boolean;
      pendingCompanyApproval?: boolean;
      challengeToken?: string;
      email?: string;
      fullName?: string;
      companyName?: string;
      message: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/company-admin/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  companyAdminVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any; company: any }>('/api/auth/company-admin/verify-2fa', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  companyAdminForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/company-admin/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  companyAdminResetPassword(payload: { token?: string; email?: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/company-admin/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  companyAdminLogout() {
    return request<{ success: boolean }>('/api/auth/company-admin/logout', { method: 'POST' });
  },

  getCompanyAdminSessions() {
    return request<{ sessions: any[] }>('/api/auth/company-admin/sessions');
  },

  revokeCompanyAdminSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/company-admin/sessions/${id}`, { method: 'DELETE' });
  },

  getCompanyAdminLoginHistory() {
    return request<{ history: any[] }>('/api/auth/company-admin/login-history');
  },

  getCompanyAdminDashboard() {
    return request<{
      actor: any;
      companyProfile: any;
      metrics: any;
      branchPerformance: any[];
      pendingDealerApplications: any[];
      recentActivities: any[];
      notifications: any[];
    }>('/api/company-admin/dashboard');
  },

  getCompanyAdminCompany() {
    return request<{ company: any; roles: any[]; branches: any[] }>('/api/company-admin/company');
  },

  updateCompanyAdminCompany(payload: {
    name?: string;
    logoUrl?: string;
    phone?: string;
    city?: string;
    address?: string;
    website?: string;
    taxId?: string;
    authorizedRep?: string;
    registrationDetails?: string;
    departments?: string[];
    documents?: any[];
    businessInfo?: Record<string, any>;
  }) {
    return request<{ success: boolean }>('/api/company-admin/company', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  getCompanyAdminEmployees() {
    return request<{ employees: any[]; branches: any[]; roles: any[]; grantablePermissions: string[]; allowedRoles: string[] }>(
      '/api/company-admin/employees'
    );
  },

  createCompanyAdminEmployee(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    jobPosition: string;
    department: string;
    branchId?: string;
    city?: string;
    employeeCode?: string;
    permissions?: string[];
  }) {
    return request<{ success: boolean; id: string; userId: string; employeeCode: string }>('/api/company-admin/employees', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminEmployee(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/employees/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminEmployeeStatus(id: string, status: 'Active' | 'Suspended' | 'On Leave') {
    return request<{ success: boolean; status: string }>(`/api/company-admin/employees/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  recordCompanyAdminAttendance(id: string, payload: { date?: string; status: string; checkIn?: string; checkOut?: string }) {
    return request<{ success: boolean; attendance: any[] }>(`/api/company-admin/employees/${id}/attendance`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  createCompanyAdminLeave(id: string, payload: { type: string; startDate: string; endDate: string; reason: string }) {
    return request<{ success: boolean; leaveId: string; leaveRequests: any[] }>(`/api/company-admin/employees/${id}/leave`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminLeave(id: string, payload: { leaveId: string; status: 'Approved' | 'Rejected' | 'Pending' }) {
    return request<{ success: boolean; leaveRequests: any[] }>(`/api/company-admin/employees/${id}/leave`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminEmployeePermissions(id: string, permissions: string[]) {
    return request<{ success: boolean; permissions: string[] }>(`/api/company-admin/employees/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify({ permissions }),
    });
  },

  getCompanyAdminBranches() {
    return request<{ branches: any[]; employees: any[] }>('/api/company-admin/branches');
  },

  createCompanyAdminBranch(payload: any) {
    return request<{ success: boolean; id: string; code: string }>('/api/company-admin/branches', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminBranch(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/branches/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCompanyAdminBranchReport(id: string) {
    return request<{ branch: any; summary: any; staff: any[]; inventory: any[]; cityBookings: any[] }>(
      `/api/company-admin/branches/${id}/report`
    );
  },

  getCompanyAdminDealerships() {
    return request<{ dealerships: any[] }>('/api/company-admin/dealerships');
  },

  createCompanyAdminDealership(payload: any) {
    return request<{ success: boolean; id: string }>('/api/company-admin/dealerships', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminDealership(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/dealerships/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  decideCompanyAdminDealership(id: string, status: 'Approved' | 'Rejected' | 'Suspended' | 'Pending Approval') {
    return request<{ success: boolean; status: string }>(`/api/company-admin/dealerships/${id}/decision`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  communicateWithCompanyAdminDealership(id: string, payload: { subject: string; message: string }) {
    return request<{ success: boolean; notificationId: string }>(`/api/company-admin/dealerships/${id}/communicate`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCompanyAdminVehicles() {
    return request<{ vehicles: any[]; branches: any[]; dealerships: any[] }>('/api/company-admin/vehicles');
  },

  createCompanyAdminVehicle(payload: any) {
    return request<{ success: boolean; id: string; vin: string }>('/api/company-admin/vehicles', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminVehicle(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/vehicles/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  transferCompanyAdminVehicle(id: string, payload: { targetBranchId: string; deliveryStatus?: string }) {
    return request<{ success: boolean; branchId: string; branchName: string; deliveryStatus: string }>(
      `/api/company-admin/vehicles/${id}/transfer`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  getCompanyAdminCustomers(reveal = false) {
    return request<{ customers: any[]; crmRecords: any[] }>(`/api/company-admin/customers${reveal ? '?reveal=1' : ''}`);
  },

  createCompanyAdminCustomer(payload: any) {
    return request<{ success: boolean; id: string }>('/api/company-admin/customers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminCustomer(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/customers/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createCompanyAdminCrm(payload: any) {
    return request<{ success: boolean; id: string }>('/api/company-admin/crm', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCompanyAdminCrm(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/company-admin/crm/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCompanyAdminSalesFinance() {
    return request<{ bookings: any[]; invoices: any[]; soldVehicles: any[]; branchRevenue: any[]; totals: any }>(
      '/api/company-admin/sales-finance'
    );
  },

  updateCompanyAdminBooking(id: string, payload: { status: string; notes?: string }) {
    return request<{ success: boolean; status: string }>(`/api/company-admin/bookings/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createCompanyAdminInvoice(payload: any) {
    return request<{ success: boolean; id: string; invoiceNumber: string; totalAmount: number; status: string }>(
      '/api/company-admin/invoices',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  refundCompanyAdminInvoice(id: string, reason: string) {
    return request<{ success: boolean; invoiceNumber: string; status: string }>(`/api/company-admin/invoices/${id}/refund`, {
      method: 'PATCH',
      body: JSON.stringify({ reason }),
    });
  },

  getCompanyAdminReports(period: 'daily' | 'monthly' | 'yearly' = 'monthly') {
    return request<any>(`/api/company-admin/reports?period=${period}`);
  },

  async exportCompanyAdminReportBlob(format: 'xlsx' | 'csv', period: 'daily' | 'monthly' | 'yearly' = 'monthly') {
    const res = await fetch(`/api/company-admin/export?format=${format}&period=${period}`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Export failed with HTTP ${res.status}`);
    }
    return res.blob();
  },

  getCompanyAdminAuditLogs() {
    return request<{
      activityLogs: any[];
      loginHistory: any[];
      securityEvents: any[];
      assignedPermissions: string[];
      canonicalPermissions: string[];
    }>('/api/company-admin/audit-logs');
  },

  // ---------------- Isolated Country Manager Auth & Management APIs ----------------
  getCountryManagerStatus() {
    return request<{
      hasCountryManagers: boolean;
      activeCountriesCount: number;
      twoFactorRequired: boolean;
      emailVerificationRequired: boolean;
      portalIsolated: boolean;
    }>('/api/auth/country-manager/status');
  },

  countryManagerLogin(payload: { identifier: string; password: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      challengeToken?: string;
      email: string;
      fullName?: string;
      managerCode?: string;
      countryId?: string;
      countryName?: string;
      flagEmoji?: string;
      suspiciousIpDetected?: boolean;
      message: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/country-manager/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  countryManagerVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requires2FA: boolean;
      challengeToken: string;
      email: string;
      fullName: string;
      managerCode: string;
      countryId: string;
      countryName: string;
      flagEmoji: string;
      message: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/country-manager/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  countryManagerVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{
      success: boolean;
      sessionExpiresAt: string;
      user: any;
      country: any;
      assignment: any;
    }>('/api/auth/country-manager/verify-2fa', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  countryManagerForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/country-manager/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  countryManagerResetPassword(payload: { token?: string; email?: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/country-manager/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  countryManagerLogout() {
    return request<{ success: boolean }>('/api/auth/country-manager/logout', { method: 'POST' });
  },

  getCountryManagerSessions() {
    return request<{ sessions: any[] }>('/api/auth/country-manager/sessions');
  },

  revokeCountryManagerSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/country-manager/sessions/${id}`, { method: 'DELETE' });
  },

  getCountryManagerLoginHistory() {
    return request<{ history: any[] }>('/api/auth/country-manager/login-history');
  },

  getCountryManagerDashboard() {
    return request<{
      actor: any;
      countryProfile: any;
      assignment: any;
      metrics: any;
      companyOverview: any[];
      branchPerformance: any[];
      pendingDealerships: any[];
      recentActivities: any[];
      notifications: any[];
    }>('/api/country-manager/dashboard');
  },

  getCountryManagerCountry() {
    return request<{ country: any; branchesOverview: any[] }>('/api/country-manager/country');
  },

  updateCountryManagerCountry(payload: {
    headquartersCity?: string;
    legalEntity?: string;
    profile?: Record<string, any>;
    offices?: any[];
    departments?: string[];
    authorizedOperations?: string[];
    documents?: any[];
    contacts?: any[];
  }) {
    return request<{ success: boolean }>('/api/country-manager/country', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerCompanies() {
    return request<{ companies: any[]; escalations: any[] }>('/api/country-manager/companies');
  },

  updateCountryManagerCompanyOps(
    id: string,
    payload: {
      phone?: string;
      city?: string;
      authorizedRep?: string;
      operationalStatus?: string;
      performanceRating?: number;
      notes?: string;
    }
  ) {
    return request<{ success: boolean }>(`/api/country-manager/companies/${id}/operations`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  submitCountryManagerCompanyEscalation(id: string, payload: { title: string; details: string }) {
    return request<{ success: boolean; id: string; status: string }>(`/api/country-manager/companies/${id}/escalation`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerBranches() {
    return request<{ branches: any[]; companies: any[]; employees: any[] }>('/api/country-manager/branches');
  },

  createCountryManagerBranch(payload: {
    companyId: string;
    name: string;
    code: string;
    city: string;
    address: string;
    managerId?: string;
    managerName: string;
    phone: string;
    email: string;
    monthlyTargetUnits?: number;
  }) {
    return request<{ success: boolean; id: string; escalationId: string; approvalStatus: string; message: string }>(
      '/api/country-manager/branches',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  updateCountryManagerBranch(
    id: string,
    payload: {
      managerId?: string;
      managerName?: string;
      monthlyTargetUnits?: number;
      phone?: string;
      address?: string;
      status?: 'Active' | 'Inactive';
    }
  ) {
    return request<{ success: boolean }>(`/api/country-manager/branches/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerBranchReport(id: string) {
    return request<{ branch: any; summary: any; staff: any[]; inventory: any[]; cityBookings: any[] }>(
      `/api/country-manager/branches/${id}/report`
    );
  },

  getCountryManagerDealerships() {
    return request<{ dealerships: any[] }>('/api/country-manager/dealerships');
  },

  updateCountryManagerDealership(
    id: string,
    payload: { managerName?: string; phone?: string; monthlyTargetUnits?: number; serviceBays?: number; activeTechs?: number }
  ) {
    return request<{ success: boolean }>(`/api/country-manager/dealerships/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  decideCountryManagerDealership(id: string, status: 'Approved' | 'Rejected' | 'Suspended' | 'Pending Approval') {
    return request<{ success: boolean; status: string }>(`/api/country-manager/dealerships/${id}/decision`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  communicateCountryManagerDealership(id: string, payload: { subject: string; message: string }) {
    return request<{ success: boolean; notificationId: string }>(`/api/country-manager/dealerships/${id}/communicate`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerEmployees() {
    return request<{ employees: any[]; deptBreakdown: any[] }>('/api/country-manager/employees');
  },

  updateCountryManagerEmployee(
    id: string,
    payload: { department?: string; jobPosition?: string; performanceScore?: number; performanceNotes?: string }
  ) {
    return request<{ success: boolean }>(`/api/country-manager/employees/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerVehicles() {
    return request<{ vehicles: any[]; branches: any[] }>('/api/country-manager/vehicles');
  },

  transferCountryManagerVehicle(id: string, payload: { targetBranchId: string; deliveryStatus?: string }) {
    return request<{ success: boolean; branchId: string; branchName: string; deliveryStatus: string }>(
      `/api/country-manager/vehicles/${id}/transfer`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  getCountryManagerCustomers(reveal = false) {
    return request<{ customers: any[]; crmRecords: any[]; bookings: any[]; csiSummary: any; piiRevealed: boolean }>(
      `/api/country-manager/customers${reveal ? '?reveal=1' : ''}`
    );
  },

  updateCountryManagerCrm(id: string, payload: { status?: string; resolutionNotes?: string }) {
    return request<{ success: boolean }>(`/api/country-manager/customers/crm/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCountryManagerSalesFinance() {
    return request<{
      invoices: any[];
      bookings: any[];
      soldVehicles: any[];
      companyRevenueBreakdown: any[];
      dealershipRevenueBreakdown: any[];
      branchRevenueBreakdown: any[];
      refundRequests: any[];
      totals: any;
    }>('/api/country-manager/sales-finance');
  },

  requestCountryManagerInvoiceRefund(id: string, reason: string) {
    return request<{ success: boolean; id: string; status: string }>(`/api/country-manager/invoices/${id}/refund-request`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  refundCountryManagerInvoice(id: string, reason: string) {
    return request<{ success: boolean; invoiceNumber: string; status: string }>(`/api/country-manager/invoices/${id}/refund`, {
      method: 'PATCH',
      body: JSON.stringify({ reason }),
    });
  },

  getCountryManagerReports(period: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'monthly') {
    return request<any>(`/api/country-manager/reports?period=${period}`);
  },

  async exportCountryManagerReportBlob(format: 'xlsx' | 'csv', period: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'monthly') {
    const res = await fetch(`/api/country-manager/export?format=${format}&period=${period}`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Export failed with HTTP ${res.status}`);
    }
    return res.blob();
  },

  getCountryManagerAuditLogs() {
    return request<{
      activityLogs: any[];
      loginHistory: any[];
      securityEvents: any[];
      escalations: any[];
      assignedPermissions: string[];
      canonicalPermissions: string[];
    }>('/api/country-manager/audit-logs');
  },

  // ---------------- Owner Branch Manager Governance ----------------
  createBranchManager(payload: {
    branchId: string;
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    managerCode?: string;
    designation?: string;
    permissions?: string[];
  }) {
    return request<{
      success: boolean;
      branchManagerId: string;
      managerCode: string;
      branchId: string;
      branchName: string;
      companyId: string;
      countryId: string;
      email: string;
      requiresEmailVerification: boolean;
      totpSecret: string;
      otpAuthUri: string;
      recoveryCodes: string[];
      verificationOutbox?: { notice: string; code: string };
    }>('/api/owner/branch-managers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  assignBranchManagerBranch(id: string, payload: { branchId: string; notes?: string }) {
    return request<{
      success: boolean;
      branchId: string;
      branchName: string;
      previousBranchId: string;
      sessionsRevoked: boolean;
    }>(`/api/owner/branch-managers/${id}/assign-branch`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateBranchManagerPermissions(id: string, payload: { permissions?: string[]; status?: 'Active' | 'Suspended' }) {
    return request<{ success: boolean }>(`/api/owner/branch-managers/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  decideBranchEscalation(id: string, payload: { status: 'Approved' | 'Rejected'; reviewNotes?: string }) {
    return request<{ success: boolean; status: string }>(`/api/owner/branch-escalations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  // ---------------- Isolated Branch Manager Authentication ----------------
  getBranchManagerStatus() {
    return request<{
      hasBranchManagers: boolean;
      activeBranchesCount: number;
      twoFactorRequired: boolean;
      emailVerificationRequired: boolean;
      portalIsolated: boolean;
    }>('/api/auth/branch-manager/status');
  },

  branchManagerLogin(payload: { identifier: string; password: string; branchCode?: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      email?: string;
      managerCode?: string;
      branchId?: string;
      branchCode?: string;
      branchName?: string;
      challengeToken?: string;
      suspiciousIpDetected?: boolean;
      message?: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/branch-manager/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  branchManagerVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requires2FA: boolean;
      challengeToken: string;
      managerCode: string;
      branchId: string;
      branchCode: string;
      branchName: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/branch-manager/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  branchManagerVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any }>(
      '/api/auth/branch-manager/verify-2fa',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  branchManagerForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/branch-manager/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  branchManagerResetPassword(payload: { token: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/branch-manager/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  branchManagerLogout() {
    return request<{ success: boolean }>('/api/auth/branch-manager/logout', { method: 'POST' });
  },

  getBranchManagerSessions() {
    return request<{ sessions: any[] }>('/api/auth/branch-manager/sessions');
  },

  revokeBranchManagerSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/branch-manager/sessions/${id}`, { method: 'DELETE' });
  },

  getBranchManagerLoginHistory() {
    return request<{ history: any[] }>('/api/auth/branch-manager/login-history');
  },

  // ---------------- Branch Manager Operational Workspace (Branch-Isolated) ----------------
  getBranchManagerDashboard() {
    return request<{
      branch: any;
      company: any;
      country: any;
      assignment: any;
      permissions: string[];
      canonicalPermissions: string[];
      metrics: any;
      recentActivities: any[];
      notifications: any[];
    }>('/api/branch-manager/dashboard');
  },

  getBranchManagerBranch() {
    return request<{ branch: any; company: any; country: any }>('/api/branch-manager/branch');
  },

  updateBranchManagerBranch(payload: {
    address?: string;
    phone?: string;
    email?: string;
    workingHours?: Record<string, string>;
    departments?: string[];
    documents?: any[];
    dailyOperations?: Record<string, any>;
    announcements?: any[];
  }) {
    return request<{ success: boolean; message: string }>('/api/branch-manager/branch', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  getBranchManagerEmployees() {
    return request<{ employees: any[] }>('/api/branch-manager/employees');
  },

  createBranchManagerEmployee(payload: {
    fullName: string;
    email: string;
    mobile: string;
    role: string;
    department?: string;
    jobPosition?: string;
    employeeCode?: string;
    password?: string;
    shiftSchedule?: string;
    dailyTask?: string;
  }) {
    return request<{ success: boolean; employeeId: string; userId: string; employeeCode: string; message: string }>(
      '/api/branch-manager/employees',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  updateBranchManagerEmployee(
    id: string,
    payload: {
      employeeCode?: string;
      department?: string;
      jobPosition?: string;
      status?: 'Active' | 'Suspended' | 'On Leave';
      performanceScore?: number;
      performanceNotes?: string;
    }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/employees/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  recordBranchEmployeeAttendance(
    id: string,
    payload: { date?: string; status: 'Present' | 'Absent' | 'Late' | 'Remote' | 'Half-Day'; checkIn?: string; checkOut?: string; notes?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/employees/${id}/attendance`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchEmployeeLeave(
    id: string,
    payload: { leaveId?: string; action: 'create' | 'Approved' | 'Rejected'; startDate?: string; endDate?: string; leaveType?: string; reason?: string }
  ) {
    return request<{ success: boolean; leaves: any[] }>(`/api/branch-manager/employees/${id}/leave`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateBranchEmployeeTaskSchedule(
    id: string,
    payload: { shiftSchedule?: string; dailyTask?: string; taskStatus?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/employees/${id}/task-schedule`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getBranchEmployeesReport() {
    return request<any>('/api/branch-manager/employees/report');
  },

  getBranchManagerVehicles() {
    return request<{ vehicles: any[]; siblingBranches: any[]; transferRequests: any[] }>('/api/branch-manager/vehicles');
  },

  addBranchManagerVehicle(payload: {
    vin: string;
    chassisNumber?: string;
    model: string;
    variant: string;
    color?: string;
    year?: number;
    salePricePkr?: number;
    conditionGrade?: string;
    conditionNotes?: string;
    stockState?: 'Available' | 'Reserved' | 'Sold' | 'In Transit';
  }) {
    return request<{ success: boolean; vehicleId: string; vin: string }>('/api/branch-manager/vehicles', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchManagerVehicle(
    id: string,
    payload: {
      stockState?: 'Available' | 'Reserved' | 'Sold' | 'In Transit';
      conditionGrade?: string;
      conditionNotes?: string;
      reservedCustomerName?: string;
      odometerKm?: number;
      batteryHealthSoh?: number;
      licensePlate?: string;
    }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/vehicles/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  requestBranchVehicleTransfer(id: string, payload: { targetBranchId: string; reason?: string }) {
    return request<{ success: boolean; escalationId: string }>(`/api/branch-manager/vehicles/${id}/transfer-request`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getBranchManagerSalesBookings() {
    return request<{ bookings: any[]; salesOrders: any[]; invoices: any[]; targets: any }>('/api/branch-manager/sales-bookings');
  },

  createBranchBooking(payload: {
    customerName: string;
    customerPhone: string;
    bookingType: string;
    vehicleModel: string;
    preferredDate?: string;
    preferredTime?: string;
    notes?: string;
  }) {
    return request<{ success: boolean; bookingId: string }>('/api/branch-manager/bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchBooking(id: string, payload: { status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled'; notes?: string }) {
    return request<{ success: boolean }>(`/api/branch-manager/bookings/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createBranchSalesOrder(payload: {
    vehicleId?: string;
    bookingId?: string;
    vehicleModel: string;
    customerName: string;
    customerPhone: string;
    salesExecName?: string;
    saleAmountPkr: number;
    paidAmountPkr?: number;
    paymentStatus?: string;
    deliveryStatus?: string;
  }) {
    return request<{ success: boolean; salesOrderId: string; orderNumber: string }>('/api/branch-manager/sales-orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchSalesOrder(
    id: string,
    payload: { paidAmountPkr?: number; paymentStatus?: string; deliveryStatus?: string; salesExecName?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/sales-orders/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createBranchInvoice(payload: {
    customerName: string;
    itemCategory?: string;
    subtotal: number;
    taxRate?: number;
    paymentGateway?: string;
    status?: 'Paid' | 'Pending Payment';
    salesOrderId?: string;
  }) {
    return request<{ success: boolean; invoiceId: string; invoiceNumber: string; totalAmount: number }>(
      '/api/branch-manager/invoices',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  getBranchDailySalesReport(date?: string) {
    const q = date ? `?date=${encodeURIComponent(date)}` : '';
    return request<any>(`/api/branch-manager/sales/daily-report${q}`);
  },

  getBranchManagerCustomers(reveal = false) {
    return request<{ customers: any[]; crmRecords: any[]; piiRevealed: boolean }>(
      `/api/branch-manager/customers${reveal ? '?reveal=1' : ''}`
    );
  },

  createBranchCustomer(payload: {
    fullName: string;
    email: string;
    mobile: string;
    cnicOrId?: string;
    password?: string;
  }) {
    return request<{ success: boolean; customerId: string }>('/api/branch-manager/customers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  createBranchCrmRecord(payload: {
    customerName: string;
    customerEmail?: string;
    customerPhone: string;
    recordType: 'Enquiry' | 'Test Drive' | 'Follow-Up' | 'Complaint' | 'Feedback';
    subject: string;
    details: string;
    priority?: string;
    assignedTo?: string;
    followUpDate?: string;
  }) {
    return request<{ success: boolean; crmId: string }>('/api/branch-manager/crm', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchCrmRecord(
    id: string,
    payload: { status?: string; priority?: string; assignedTo?: string; followUpDate?: string; resolutionNotes?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/crm/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getBranchManagerDealerships() {
    return request<{ dealerships: any[]; escalations: any[] }>('/api/branch-manager/dealerships');
  },

  updateBranchDealership(
    id: string,
    payload: { managerName?: string; phone?: string; activeTechs?: number; serviceBays?: number; monthlyTargetUnits?: number }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/dealerships/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  requestBranchDealerApproval(id: string, notes?: string) {
    return request<{ success: boolean; escalationId: string }>(`/api/branch-manager/dealerships/${id}/approval-request`, {
      method: 'POST',
      body: JSON.stringify({ notes }),
    });
  },

  communicateBranchDealership(id: string, payload: { subject: string; message: string }) {
    return request<{ success: boolean; notificationId: string }>(`/api/branch-manager/dealerships/${id}/communicate`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getBranchManagerFinance() {
    return request<{ summary: any; invoices: any[]; expenses: any[]; refundEscalations: any[] }>('/api/branch-manager/finance');
  },

  createBranchExpense(payload: { category: string; title: string; amountPkr: number; expenseDate?: string }) {
    return request<{ success: boolean; expenseId: string }>('/api/branch-manager/expenses', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  requestBranchInvoiceRefund(id: string, reason: string) {
    return request<{ success: boolean; escalationId: string }>(`/api/branch-manager/invoices/${id}/refund-request`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  refundBranchInvoice(id: string, reason: string) {
    return request<{ success: boolean }>(`/api/branch-manager/invoices/${id}/refund`, {
      method: 'PATCH',
      body: JSON.stringify({ reason }),
    });
  },

  getBranchServiceWarranty() {
    return request<{ serviceJobs: any[]; warrantyClaims: any[]; spareParts: any[] }>('/api/branch-manager/service-warranty');
  },

  createBranchServiceJob(payload: {
    vin: string;
    model: string;
    licensePlate?: string;
    customerName: string;
    customerPhone: string;
    serviceType: string;
    scheduledDate?: string;
    scheduledTime?: string;
    technicianAssigned?: string;
    estimatedCostPkr?: number;
    reminderDate?: string;
    customerNotes?: string;
  }) {
    return request<{ success: boolean; serviceJobId: string; ticketNumber: string }>('/api/branch-manager/service-jobs', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchServiceJob(
    id: string,
    payload: { status?: string; technicianAssigned?: string; technicianNotes?: string; actualCostPkr?: number; reminderDate?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/service-jobs/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateBranchWarrantyClaim(id: string, payload: { status?: string; reviewNotes?: string; approvedAmountPkr?: number }) {
    return request<{ success: boolean }>(`/api/branch-manager/warranty-claims/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  createBranchSparePart(payload: {
    sku: string;
    name: string;
    category: string;
    compatibleModels?: string;
    stockQuantity: number;
    reorderLevel: number;
    unitCostPkr: number;
    locationBin?: string;
  }) {
    return request<{ success: boolean; partId: string }>('/api/branch-manager/spare-parts', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateBranchSparePart(
    id: string,
    payload: { stockQuantity?: number; reorderLevel?: number; unitCostPkr?: number; locationBin?: string }
  ) {
    return request<{ success: boolean }>(`/api/branch-manager/spare-parts/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getBranchManagerReports(period: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'monthly') {
    return request<any>(`/api/branch-manager/reports?period=${period}`);
  },

  async exportBranchManagerReportBlob(format: 'xlsx' | 'csv', period: 'daily' | 'weekly' | 'monthly' | 'yearly' = 'monthly') {
    const res = await fetch(`/api/branch-manager/export?format=${format}&period=${period}`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Export failed with HTTP ${res.status}`);
    }
    return res.blob();
  },

  getBranchManagerAuditLogs() {
    return request<{ activityLogs: any[]; escalations: any[] }>('/api/branch-manager/audit-logs');
  },

  // ---------------- Standard User Auth & Onboarding ----------------
  getMe() {
    return request<{ authenticated: boolean; user: any | null }>('/api/auth/me');
  },

  login(payload: { identifier: string; password: string }) {
    return request<{
      requires2FA?: boolean;
      challengeToken?: string;
      founderName?: string;
      role?: string;
      suspiciousIpDetected?: boolean;
      message: string;
      success?: boolean;
      sessionExpiresAt?: string;
      user?: any;
    }>('/api/auth/founder/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  registerCustomer(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    country: string;
    city: string;
    cnicOrId?: string;
    companyId?: string;
    termsAccepted: boolean;
    privacyAccepted: boolean;
  }) {
    return request<{
      success: boolean;
      requiresEmailVerification: boolean;
      email: string;
      message: string;
      verificationOutbox?: { notice: string; code: string; verificationToken?: string };
    }>('/api/auth/register-customer', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  verifyEmail(payload: { email: string; code: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  registerCompany(payload: {
    companyName: string;
    country: string;
    city: string;
    officialEmail: string;
    phone: string;
    address: string;
    registrationDetails: string;
    authorizedRep: string;
    adminPassword: string;
  }) {
    return request<{
      success: boolean;
      companyId: string;
      companyAdminId?: string;
      status: string;
      requiresEmailVerification?: boolean;
      message: string;
      twoFactorSetup?: { secret: string; otpAuthUri: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/auth/register-company', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  lookupInvite(token: string) {
    return request<{
      valid: boolean;
      fullName: string;
      email: string;
      role: string;
      companyName: string;
      city: string;
      expiresAt: string;
    }>(`/api/auth/invite/${encodeURIComponent(token)}`);
  },

  acceptInvite(payload: { token: string; password: string; mobile?: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/accept-invite', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  forgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string };
    }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  resetPassword(payload: { token: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getSessions() {
    return request<{ sessions: any[] }>('/api/auth/sessions');
  },

  revokeSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/sessions/${id}`, {
      method: 'DELETE',
    });
  },

  getLoginHistory() {
    return request<{ history: any[] }>('/api/auth/login-history');
  },

  logout() {
    return request<{ success: boolean }>('/api/auth/logout', { method: 'POST' });
  },

  // ---------------- Employee Management ----------------
  getEmployees(companyId?: string) {
    const q = companyId ? `?companyId=${encodeURIComponent(companyId)}` : '';
    return request<{ employees: any[]; invitations: any[] }>(`/api/employees${q}`);
  },

  inviteEmployee(payload: {
    fullName: string;
    email: string;
    mobile?: string;
    role: string;
    city: string;
    dealershipId?: string;
    companyId?: string;
  }) {
    return request<{
      success: boolean;
      invitationId: string;
      inviteToken: string;
      inviteUrl: string;
      expiresAt: string;
      message: string;
    }>('/api/employees/invite', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateEmployeeStatus(id: string, status: 'Active' | 'Suspended') {
    return request<{ success: boolean }>(`/api/employees/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },

  // ---------------- Domain APIs (Company & User Isolated) ----------------
  getVehicles() {
    return request<{ vehicles: any[] }>('/api/vehicles');
  },
  getBookings() {
    return request<{ bookings: any[] }>('/api/bookings');
  },
  createBooking(payload: any) {
    return request<{ success: boolean; bookingId: string }>('/api/bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getServiceJobs() {
    return request<{ serviceJobs: any[] }>('/api/service-jobs');
  },
  getWarrantyClaims() {
    return request<{ claims: any[] }>('/api/warranty-claims');
  },
  getInvoices() {
    return request<{ invoices: any[] }>('/api/invoices');
  },
  getAdminOverview() {
    return request<{ companies: any[]; users: any[]; vehicles: any[]; dealerships: any[] }>('/api/admin/overview');
  },

  // ---------------- BYD AI (Real Server-Side Gemini API) ----------------
  getAiStatus() {
    return request<{
      aiName: string;
      configured: boolean;
      enabled: boolean;
      model: string;
      allowedModels: string[];
      allowDocumentAnalysis: boolean;
      allowVoiceAssistant: boolean;
      statusReason: string;
    }>('/api/ai/status');
  },

  getAiConversations() {
    return request<{ conversations: any[] }>('/api/ai/conversations');
  },

  createAiConversation(title?: string) {
    return request<{ conversation: any }>('/api/ai/conversations', {
      method: 'POST',
      body: JSON.stringify({ title }),
    });
  },

  getAiConversationMessages(id: string) {
    return request<{ conversation: any; messages: any[] }>(`/api/ai/conversations/${id}`);
  },

  deleteAiConversation(id: string) {
    return request<{ success: boolean }>(`/api/ai/conversations/${id}`, { method: 'DELETE' });
  },

  clearAiConversation(id: string) {
    return request<{ success: boolean }>(`/api/ai/conversations/${id}/clear`, { method: 'POST' });
  },

  sendChatMessage(
    message: string,
    _role?: string,
    options?: { conversationId?: string | null; language?: string }
  ): Promise<ChatResponse> {
    return request<ChatResponse>('/api/ai/chat', {
      method: 'POST',
      body: JSON.stringify({
        message,
        conversationId: options?.conversationId || null,
        language: options?.language || 'auto',
      }),
    });
  },

  uploadAndAnalyzeDocument(file: File, prompt: string, conversationId?: string | null) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('prompt', prompt);
    if (conversationId) {
      formData.append('conversationId', conversationId);
    }
    return request<{ analysis: string; fileName: string; model: string; conversationId: string }>(
      '/api/ai/upload-analyze',
      {
        method: 'POST',
        body: formData,
      }
    );
  },

  analyzeBattery(batteryData: any, vin: string, modelName: string): Promise<BatteryAnalysisResponse> {
    return request<BatteryAnalysisResponse>('/api/gemini/analyze-battery', {
      method: 'POST',
      body: JSON.stringify({ batteryData, vin, modelName }),
    });
  },

  getExecutiveSummary(metrics: any, period?: string): Promise<ExecutiveSummaryResponse> {
    return request<ExecutiveSummaryResponse>('/api/gemini/executive-summary', {
      method: 'POST',
      body: JSON.stringify({ metrics, period }),
    });
  },

  // ---------------- Separate Employee Authentication ----------------
  getEmployeeAuthStatus() {
    return request<{
      hasEmployees: boolean;
      twoFactorRequired: boolean;
      emailVerificationRequired: boolean;
      portalIsolated: boolean;
    }>('/api/auth/employee/status');
  },

  employeeLogin(payload: { identifier: string; password: string; employeeCodeCheck?: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      email?: string;
      employeeCode?: string;
      fullName?: string;
      department?: string;
      challengeToken?: string;
      suspiciousIpDetected?: boolean;
      message?: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/employee/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  employeeVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requires2FA: boolean;
      challengeToken: string;
      employeeCode: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/employee/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  employeeVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any }>(
      '/api/auth/employee/verify-2fa',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  employeeForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/employee/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  employeeResetPassword(payload: { token: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/employee/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  employeeLogout() {
    return request<{ success: boolean }>('/api/auth/employee/logout', { method: 'POST' });
  },

  getEmployeeSessions() {
    return request<{ sessions: any[] }>('/api/auth/employee/sessions');
  },

  revokeEmployeeSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/employee/sessions/${id}`, { method: 'DELETE' });
  },

  getEmployeeLoginHistory() {
    return request<{ history: any[] }>('/api/auth/employee/login-history');
  },

  // ---------------- Personal Employee Workspace (Self-Only RBAC) ----------------
  getEmployeeDashboard() {
    return request<{
      employee: any;
      todayAttendance: any;
      metrics: any;
      leaveBalance: Record<string, any>;
      salarySummary: {
        authorized: boolean;
        latestPayPeriod?: string | null;
        currency?: string;
        netSalary?: number;
        paymentStatus?: string;
      };
      recentAttendance: any[];
      pendingTasks: any[];
      notifications: any[];
      recentActivities: any[];
    }>('/api/employee/dashboard');
  },

  getEmployeeProfile() {
    return request<{
      employee: any;
      profile: any;
      assignments: any[];
      permissions: string[];
      canonicalPermissions: string[];
    }>('/api/employee/profile');
  },

  updateEmployeeProfile(payload: {
    mobile?: string;
    bio?: string;
    address?: string;
    city?: string;
    dateOfBirth?: string;
    gender?: string;
    cnicOrId?: string;
    emergencyContactName?: string;
    emergencyContactPhone?: string;
    emergencyContactRelation?: string;
    skills?: string[];
  }) {
    return request<{ success: boolean; message: string }>('/api/employee/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  uploadEmployeePhoto(file: File) {
    const fd = new FormData();
    fd.append('photo', file);
    return request<{ success: boolean; photoDocId: string; photoUrl: string }>(
      '/api/employee/profile/photo',
      {
        method: 'POST',
        body: fd,
      }
    );
  },

  getEmployeeAttendance() {
    return request<{
      todayRecord: any;
      records: any[];
      summary: {
        totalDays: number;
        presentDays: number;
        lateDays: number;
        absentDays: number;
        totalHours: number;
      };
    }>('/api/employee/attendance');
  },

  employeeCheckIn(payload?: { workMode?: 'On-Site' | 'Remote' | 'Field Duty'; notes?: string }) {
    return request<{ success: boolean; record: any }>('/api/employee/attendance/check-in', {
      method: 'POST',
      body: JSON.stringify(payload || {}),
    });
  },

  employeeCheckOut(payload?: { notes?: string }) {
    return request<{ success: boolean; workingHours: number; record: any }>('/api/employee/attendance/check-out', {
      method: 'POST',
      body: JSON.stringify(payload || {}),
    });
  },

  employeeCorrectionRequest(payload: { attendanceDate: string; reason: string }) {
    return request<{ success: boolean; message: string }>('/api/employee/attendance/correction-request', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getEmployeeLeaves() {
    return request<{
      balance: Record<string, any>;
      requests: any[];
    }>('/api/employee/leaves');
  },

  applyEmployeeLeave(payload: {
    leaveType: string;
    startDate: string;
    endDate: string;
    reason: string;
    supportingDocument?: File | null;
  }) {
    if (payload.supportingDocument) {
      const fd = new FormData();
      fd.append('leaveType', payload.leaveType);
      fd.append('startDate', payload.startDate);
      fd.append('endDate', payload.endDate);
      fd.append('reason', payload.reason);
      fd.append('supportingDocument', payload.supportingDocument);
      return request<{ success: boolean; leaveId: string; request: any }>(
        '/api/employee/leaves',
        { method: 'POST', body: fd }
      );
    }
    return request<{ success: boolean; leaveId: string; request: any }>(
      '/api/employee/leaves',
      {
        method: 'POST',
        body: JSON.stringify({
          leaveType: payload.leaveType,
          startDate: payload.startDate,
          endDate: payload.endDate,
          reason: payload.reason,
        }),
      }
    );
  },

  cancelEmployeeLeave(id: string) {
    return request<{ success: boolean }>(`/api/employee/leaves/${id}/cancel`, {
      method: 'PATCH',
    });
  },

  getEmployeeTasks() {
    return request<{ tasks: any[] }>('/api/employee/tasks');
  },

  startEmployeeTask(id: string) {
    return request<{ success: boolean; status: string }>(`/api/employee/tasks/${id}/start`, {
      method: 'PATCH',
    });
  },

  addEmployeeTaskUpdate(id: string, note: string) {
    return request<{ success: boolean; workUpdates: any[] }>(`/api/employee/tasks/${id}/update`, {
      method: 'POST',
      body: JSON.stringify({ note }),
    });
  },

  uploadEmployeeTaskDocument(id: string, file: File, title?: string) {
    const fd = new FormData();
    fd.append('file', file);
    if (title) fd.append('title', title);
    return request<{ success: boolean; docId: string; attachmentDocIds: string[] }>(
      `/api/employee/tasks/${id}/document`,
      { method: 'POST', body: fd }
    );
  },

  completeEmployeeTask(id: string, note?: string) {
    return request<{ success: boolean; status: string }>(`/api/employee/tasks/${id}/complete`, {
      method: 'PATCH',
      body: JSON.stringify({ note }),
    });
  },

  getEmployeeSalary() {
    return request<{
      structure: {
        currency: string;
        baseSalary: number;
        allowances: number;
        bonuses: number;
        deductions: number;
        taxDeduction: number;
        netSalary: number;
      } | null;
      records: any[];
    }>('/api/employee/salary');
  },

  getEmployeeSalarySlip(id: string) {
    return request<{ slip: any }>(`/api/employee/salary/${id}/slip`);
  },

  getEmployeeDocuments() {
    return request<{ documents: any[] }>('/api/employee/documents');
  },

  uploadEmployeeDocument(payload: { title: string; category: string; file: File }) {
    const fd = new FormData();
    fd.append('title', payload.title);
    fd.append('category', payload.category);
    fd.append('file', payload.file);
    return request<{ success: boolean; document: any }>('/api/employee/documents', {
      method: 'POST',
      body: fd,
    });
  },

  async downloadEmployeePrivateFile(docId: string, suggestedName?: string) {
    const res = await fetch(`/api/employee/documents/${encodeURIComponent(docId)}/download`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Download failed with HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = suggestedName || `employee-doc-${docId}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  getEmployeePerformance() {
    return request<{
      currentScore: number;
      managerNotes: string;
      taskCompletionRate: number;
      attendanceRate: number;
      totalHoursLogged: number;
      reviews: any[];
    }>('/api/employee/performance');
  },

  getEmployeeCommunications() {
    return request<{
      notifications: any[];
    }>('/api/employee/communications');
  },

  markEmployeeCommunicationRead(id: string) {
    return request<{ success: boolean }>(`/api/employee/communications/${id}/read`, {
      method: 'PATCH',
    });
  },

  getEmployeeSupportTickets() {
    return request<{ tickets: any[] }>('/api/employee/support');
  },

  createEmployeeSupportTicket(payload: { category: string; priority: string; subject: string; description: string }) {
    return request<{ success: boolean; id: string; ticketNumber: string }>('/api/employee/support', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getEmployeeAuditLogs() {
    return request<{
      logs: any[];
    }>('/api/employee/audit-logs');
  },

  // ---------------- Separate Dealer Authentication ----------------
  getDealerAuthStatus() {
    return request<{
      hasVerifiedDealers: boolean;
      verifiedDealersCount: number;
      approvedCompanies: Array<{ id: string; name: string; country: string; city: string }>;
      twoFactorRequired: boolean;
      emailVerificationRequired: boolean;
      adminApprovalRequired: boolean;
      portalIsolated: boolean;
    }>('/api/auth/dealer/status');
  },

  dealerRegister(payload: {
    businessName: string;
    ownerContactName: string;
    email: string;
    mobile: string;
    password: string;
    companyId: string;
    countryId: string;
    city: string;
    businessAddress: string;
    category: string;
    registrationNo?: string;
    taxIdNtn?: string;
  }) {
    return request<{
      success: boolean;
      pendingAdminApproval: boolean;
      requiresEmailVerification: boolean;
      dealer: any;
      message: string;
      twoFactorProvisioned?: { totpSecret: string; recoveryCodes: string[] };
      verificationOutbox?: { notice: string; code: string };
    }>('/api/auth/dealer/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  dealerLogin(payload: { identifier: string; password: string; dealerCodeCheck?: string }) {
    return request<{
      requiresEmailVerification?: boolean;
      requires2FA?: boolean;
      challengeToken?: string;
      email?: string;
      businessName?: string;
      dealerCode?: string;
      category?: string;
      branchName?: string;
      companyName?: string;
      suspiciousIpDetected?: boolean;
      message?: string;
      verificationOutbox?: { notice: string; code: string };
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/dealer/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  dealerVerifyEmail(payload: { email: string; code: string }) {
    return request<{
      success: boolean;
      requiresAdminApproval?: boolean;
      requires2FA: boolean;
      challengeToken?: string;
      email: string;
      dealerCode: string;
      verificationStatus?: string;
      message: string;
      otpOutbox?: { notice: string; code: string };
    }>('/api/auth/dealer/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  dealerVerify2FA(payload: { challengeToken: string; code: string }) {
    return request<{ success: boolean; sessionExpiresAt: string; user: any; organization: any }>(
      '/api/auth/dealer/verify-2fa',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  dealerForgotPassword(email: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/dealer/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  dealerResetPassword(payload: { token?: string; email?: string; otpCode?: string; newPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/dealer/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  dealerLogout() {
    return request<{ success: boolean }>('/api/auth/dealer/logout', { method: 'POST' });
  },

  getDealerSessions() {
    return request<{ sessions: any[] }>('/api/auth/dealer/sessions');
  },

  revokeDealerSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/dealer/sessions/${id}`, { method: 'DELETE' });
  },

  getDealerLoginHistory() {
    return request<{ history: any[] }>('/api/auth/dealer/login-history');
  },

  // ---------------- Private Dealer Workspace ----------------
  getDealerDashboard() {
    return request<{
      dealer: any;
      summary: any;
      notifications: any[];
      recentActivity: any[];
      permissions: string[];
    }>('/api/dealer/dashboard');
  },

  getDealerProfile() {
    return request<{ profile: any }>('/api/dealer/profile');
  },

  updateDealerProfile(payload: {
    businessName?: string;
    ownerContactName?: string;
    mobile?: string;
    businessAddress?: string;
    city?: string;
    website?: string;
    notes?: string;
    bankName?: string;
    bankAccountTitle?: string;
    bankIbanMasked?: string;
    taxIdNtn?: string;
    registrationNo?: string;
    requestedCategory?: string;
  }) {
    return request<{ success: boolean; pendingAdminApproval: boolean; message: string }>('/api/dealer/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  uploadDealerLogo(file: File) {
    const fd = new FormData();
    fd.append('logo', file);
    return request<{ success: boolean; logoDocId: string }>('/api/dealer/profile/logo', {
      method: 'POST',
      body: fd,
    });
  },

  getDealerInventory() {
    return request<{ vehicles: any[]; canViewVin: boolean }>('/api/dealer/inventory');
  },

  getDealerCustomers() {
    return request<{ customers: any[] }>('/api/dealer/customers');
  },

  createDealerCustomer(payload: {
    fullName: string;
    phone: string;
    email?: string;
    city?: string;
    interestedModel: string;
    requirements?: string;
    followUpDate?: string;
    appointmentDate?: string;
    requestTestDrive?: boolean;
    initialNote?: string;
  }) {
    return request<{ success: boolean; customer: any }>('/api/dealer/customers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateDealerCustomer(
    id: string,
    payload: {
      inquiryStatus?: string;
      followUpDate?: string;
      appointmentDate?: string;
      testDriveStatus?: string;
      requirements?: string;
      communicationNote?: string;
      channel?: string;
    }
  ) {
    return request<{ success: boolean; customer: any }>(`/api/dealer/customers/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getDealerBookings() {
    return request<{ bookings: any[] }>('/api/dealer/bookings');
  },

  createDealerBooking(payload: { customerId: string; inventoryId: string; notes?: string; file?: File | null }) {
    if (payload.file) {
      const fd = new FormData();
      fd.append('customerId', payload.customerId);
      fd.append('inventoryId', payload.inventoryId);
      if (payload.notes) fd.append('notes', payload.notes);
      fd.append('file', payload.file);
      return request<{ success: boolean; booking: any }>('/api/dealer/bookings', {
        method: 'POST',
        body: fd,
      });
    }
    return request<{ success: boolean; booking: any }>('/api/dealer/bookings', {
      method: 'POST',
      body: JSON.stringify({
        customerId: payload.customerId,
        inventoryId: payload.inventoryId,
        notes: payload.notes,
      }),
    });
  },

  cancelDealerBooking(id: string) {
    return request<{ success: boolean }>(`/api/dealer/bookings/${id}/cancel`, { method: 'PATCH' });
  },

  getDealerSales() {
    return request<{ sales: any[] }>('/api/dealer/sales');
  },

  async downloadDealerSaleReceipt(saleId: string, saleRef?: string) {
    const res = await fetch(`/api/dealer/sales/${encodeURIComponent(saleId)}/receipt`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Receipt download failed with HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BYD360-Receipt-${saleRef || saleId}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  getDealerCommissions() {
    return request<{
      commissions: any[];
      summary: {
        assignedRatePct: number;
        approvedPkr: number;
        pendingPkr: number;
        paidPkr: number;
        lifetimePkr: number;
      };
    }>('/api/dealer/commissions');
  },

  getDealerDocuments() {
    return request<{ documents: any[] }>('/api/dealer/documents');
  },

  uploadDealerDocument(payload: { docType: string; title: string; file: File }) {
    const fd = new FormData();
    fd.append('docType', payload.docType);
    fd.append('title', payload.title);
    fd.append('file', payload.file);
    return request<{ success: boolean; document: any }>('/api/dealer/documents', {
      method: 'POST',
      body: fd,
    });
  },

  async downloadDealerPrivateDoc(docId: string, suggestedName?: string) {
    const res = await fetch(`/api/dealer/documents/${encodeURIComponent(docId)}/download`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Document download failed with HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = suggestedName || `dealer-doc-${docId}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  getDealerCommunications() {
    return request<{ notifications: any[] }>('/api/dealer/communications');
  },

  markDealerCommunicationRead(id: string) {
    return request<{ success: boolean }>(`/api/dealer/communications/${id}/read`, { method: 'PATCH' });
  },

  getDealerSupportRequests() {
    return request<{ supportRequests: any[] }>('/api/dealer/support');
  },

  createDealerSupportRequest(payload: { category: string; priority: string; subject: string; description: string }) {
    return request<{ success: boolean; supportRequest: any }>('/api/dealer/support', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getDealerReports() {
    return request<{ report: any }>('/api/dealer/reports');
  },

  async downloadDealerReportExport(format: 'pdf' | 'xlsx', dealerCode?: string) {
    const res = await fetch(`/api/dealer/reports/export?format=${format}`, {
      credentials: 'include',
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Export failed with HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `byd360-dealer-report-${dealerCode || 'export'}.${format}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },

  getDealerAuditLogs() {
    return request<{ logs: any[]; loginHistory: any[]; canonicalPermissions: string[] }>('/api/dealer/audit-logs');
  },

  // ---------------- Admin Dealer Governance (Hierarchical Scopes) ----------------
  listAdminDealers(scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager') {
    return request<{
      dealers: any[];
      bookings: any[];
      commissions: any[];
      documents: any[];
      inventory: any[];
      activityLogs: any[];
      canonicalPermissions: string[];
    }>(`/api/${scope}/dealers`);
  },

  createAdminDealer(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    payload: any
  ) {
    return request<{ success: boolean; dealer: any; twoFactorProvisioned: { totpSecret: string; recoveryCodes: string[] } }>(
      `/api/${scope}/dealers`,
      { method: 'POST', body: JSON.stringify(payload) }
    );
  },

  decideAdminDealer(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    decision: 'approve' | 'reject' | 'suspend' | 'reactivate',
    reason?: string
  ) {
    return request<{ success: boolean; dealer: any }>(`/api/${scope}/dealers/${id}/decision`, {
      method: 'PATCH',
      body: JSON.stringify({ decision, reason }),
    });
  },

  updateAdminDealerPermissions(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    permissions: string[],
    commissionRatePct?: number
  ) {
    return request<{ success: boolean; permissions: string[] }>(`/api/${scope}/dealers/${id}/permissions`, {
      method: 'PATCH',
      body: JSON.stringify({ permissions, commissionRatePct }),
    });
  },

  assignAdminDealerVehicle(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    payload: {
      model: string;
      variant: string;
      modelYear?: number;
      exteriorColor: string;
      vin?: string;
      approvedSellingPricePkr: number;
    }
  ) {
    return request<{ success: boolean; vehicle: any }>(`/api/${scope}/dealers/${id}/vehicles`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  reviewAdminDealerProfileChange(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    decision: 'approve' | 'reject'
  ) {
    return request<{ success: boolean }>(`/api/${scope}/dealers/${id}/profile-change`, {
      method: 'PATCH',
      body: JSON.stringify({ decision }),
    });
  },

  verifyAdminDealerDocument(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    docId: string,
    status: 'Verified' | 'Rejected',
    notes?: string
  ) {
    return request<{ success: boolean; verificationStatus: string }>(`/api/${scope}/dealers/documents/${docId}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ status, notes }),
    });
  },

  reviewAdminDealerBooking(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    bookingId: string,
    decision: 'approve' | 'reject',
    verifyPayment = true,
    paymentProviderRef?: string
  ) {
    return request<{ success: boolean; sale?: any; commission?: any }>(`/api/${scope}/dealers/bookings/${bookingId}/review`, {
      method: 'PATCH',
      body: JSON.stringify({ decision, verifyPayment, paymentProviderRef }),
    });
  },

  actionAdminDealerCommission(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    commId: string,
    action: 'approve' | 'pay',
    payoutReference?: string
  ) {
    return request<{ success: boolean; commission: any }>(`/api/${scope}/dealers/commissions/${commId}`, {
      method: 'PATCH',
      body: JSON.stringify({ action, payoutReference }),
    });
  },

  notifyAdminDealer(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    payload: { title: string; message: string; category?: string; priority?: string }
  ) {
    return request<{ success: boolean; id: string }>(`/api/${scope}/dealers/${id}/notify`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  // =========================================================================
  // DEDICATED CUSTOMER AUTHENTICATION & CUSTOMER PORTAL WORKSPACE
  // =========================================================================

  getCustomerPortalStatus() {
    return request<{
      portal: string;
      customersCount: number;
      smsConfigured: boolean;
      smtpConfigured: boolean;
      paymentGatewayConfigured: boolean;
    }>('/api/auth/customer/status');
  },

  customerRegister(payload: {
    fullName: string;
    email: string;
    mobile: string;
    password: string;
    confirmPassword: string;
    country: string;
    city: string;
    address?: string;
    cnicOrId?: string;
    termsAccepted: boolean;
    privacyAccepted: boolean;
  }) {
    return request<{
      success: boolean;
      requiresEmailVerification: boolean;
      smsConfigured: boolean;
      emailDeliveryMode?: string;
      customer: any;
      message: string;
      verificationOutbox?: { notice: string; code: string; verificationToken?: string };
    }>('/api/auth/customer/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  customerVerifyEmail(payload: { email: string; code: string }) {
    return request<{ success: boolean; message: string }>('/api/auth/customer/verify-email', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  customerResendOtp(email: string) {
    return request<{ success: boolean; message: string; verificationOutbox?: { notice: string; code: string } }>(
      '/api/auth/customer/resend-otp',
      {
        method: 'POST',
        body: JSON.stringify({ email }),
      }
    );
  },

  customerLogin(payload: { identifier: string; password: string }) {
    return request<{
      success: boolean;
      sessionExpiresAt: string;
      suspiciousLoginAlert?: boolean;
      user: any;
    }>('/api/auth/customer/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  customerForgotPassword(identifier: string) {
    return request<{
      success: boolean;
      message: string;
      resetOutbox?: { notice: string; resetToken: string; otpCode: string };
    }>('/api/auth/customer/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ identifier }),
    });
  },

  customerResetPassword(payload: {
    token?: string;
    email?: string;
    otpCode?: string;
    newPassword: string;
    confirmPassword?: string;
  }) {
    return request<{ success: boolean; message: string }>('/api/auth/customer/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  customerLogout() {
    return request<{ success: boolean }>('/api/auth/customer/logout', { method: 'POST' });
  },

  getCustomerSessions() {
    return request<{ sessions: any[] }>('/api/auth/customer/sessions');
  },

  revokeCustomerSession(id: string) {
    return request<{ success: boolean }>(`/api/auth/customer/sessions/${id}`, { method: 'DELETE' });
  },

  getCustomerLoginHistory() {
    return request<{ history: any[] }>('/api/auth/customer/login-history');
  },

  getCustomerDashboard() {
    return request<{
      customer: any;
      metrics: any;
      systemCapabilities: {
        smsConfigured: boolean;
        smtpConfigured: boolean;
        paymentGatewayConfigured: boolean;
      };
      vehicles: any[];
      notifications: any[];
      recentActivity: any[];
      ownershipTransfers: any[];
    }>('/api/customer/dashboard');
  },

  getCustomerProfile() {
    return request<{
      account: any;
      profile: any;
      verifications: any[];
      sessions: any[];
      loginHistory: any[];
      smsConfigured: boolean;
    }>('/api/customer/profile');
  },

  updateCustomerProfile(payload: {
    fullName?: string;
    email?: string;
    mobile?: string;
    country?: string;
    city?: string;
    address?: string;
    cnicOrId?: string;
    emergencyContact?: string;
    preferredLanguage?: string;
    preferredCurrency?: string;
    communicationPrefs?: Record<string, boolean>;
  }) {
    return request<{
      success: boolean;
      emailChanged: boolean;
      mobileChanged: boolean;
      verificationOutbox?: { notice: string; code: string };
      message: string;
    }>('/api/customer/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },

  changeCustomerPassword(payload: { currentPassword: string; newPassword: string; confirmPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/customer/change-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  requestCustomerDeletion(reason: string) {
    return request<{ success: boolean; message: string }>('/api/customer/deletion-request', {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  },

  exploreCustomerVehicles(params?: { q?: string; model?: string; city?: string; country?: string; availability?: string }) {
    const sp = new URLSearchParams();
    if (params?.q) sp.set('q', params.q);
    if (params?.model) sp.set('model', params.model);
    if (params?.city) sp.set('city', params.city);
    if (params?.country) sp.set('country', params.country);
    if (params?.availability) sp.set('availability', params.availability);
    const qs = sp.toString();
    return request<{ vehicles: any[]; showrooms: any[]; serviceDealerships: any[] }>(
      `/api/customer/vehicles/explore${qs ? `?${qs}` : ''}`
    );
  },

  getCustomerFavorites() {
    return request<{ favorites: any[] }>('/api/customer/favorites');
  },

  addCustomerFavorite(inventoryId: string, notes?: string) {
    return request<{ success: boolean; favoriteId: string }>('/api/customer/favorites', {
      method: 'POST',
      body: JSON.stringify({ inventoryId, notes }),
    });
  },

  removeCustomerFavorite(idOrInventoryId: string) {
    return request<{ success: boolean }>(`/api/customer/favorites/${idOrInventoryId}`, {
      method: 'DELETE',
    });
  },

  getCustomerInquiries() {
    return request<{ inquiries: any[] }>('/api/customer/inquiries');
  },

  createCustomerInquiry(payload: {
    inventoryId?: string | null;
    dealerId?: string | null;
    vehicleModel: string;
    variant?: string;
    inquiryType: string;
    subject: string;
    message: string;
    preferredContact?: string;
  }) {
    return request<{ success: boolean; inquiryId: string; inquiryRef: string }>('/api/customer/inquiries', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCustomerTestDrives() {
    return request<{ testDrives: any[] }>('/api/customer/test-drives');
  },

  requestCustomerTestDrive(payload: {
    dealerId: string;
    inventoryId?: string | null;
    vehicleModel: string;
    variant?: string;
    preferredDate: string;
    preferredTime: string;
    city?: string;
    notes?: string;
  }) {
    return request<{ success: boolean; id: string; requestNumber: string; status: string }>('/api/customer/test-drives', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  updateCustomerTestDrive(
    id: string,
    payload: { action?: 'reschedule' | 'cancel'; preferredDate?: string; preferredTime?: string; notes?: string }
  ) {
    return request<{ success: boolean; status: string }>(`/api/customer/test-drives/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  getCustomerBookings() {
    return request<{ bookings: any[]; documents: any[] }>('/api/customer/bookings');
  },

  createCustomerBooking(payload: {
    inventoryId: string;
    exteriorColor?: string;
    interiorColor?: string;
    customerNotes?: string;
  }) {
    return request<{
      success: boolean;
      bookingId: string;
      bookingRef: string;
      invoiceNumber: string;
      bookingStatus: string;
      paymentInstructions: string;
    }>('/api/customer/bookings', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  uploadCustomerBookingDocument(bookingId: string, payload: { docCategory: string; docTitle: string; file: File }) {
    const fd = new FormData();
    fd.append('docCategory', payload.docCategory);
    fd.append('docTitle', payload.docTitle);
    fd.append('file', payload.file);
    return request<{ success: boolean; documentId: string; fileName: string }>(
      `/api/customer/bookings/${bookingId}/documents`,
      { method: 'POST', body: fd }
    );
  },

  getCustomerPayments() {
    return request<{ payments: any[]; invoices: any[]; paymentGatewayConfigured: boolean }>('/api/customer/payments');
  },

  getCustomerVehicles() {
    return request<{ vehicles: any[] }>('/api/customer/my-vehicles');
  },

  registerCustomerVehicle(payload: {
    vin: string;
    model: string;
    variant?: string;
    licensePlate: string;
    color?: string;
    modelYear?: number;
    registrationDate?: string;
    dealershipName?: string;
  }) {
    return request<{ success: boolean; vehicleId: string; warrantyId: string }>('/api/customer/my-vehicles', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCustomerService() {
    return request<{ serviceRequests: any[]; serviceHistory: any[] }>('/api/customer/service-requests');
  },

  createCustomerServiceRequest(payload: {
    customerVehicleId: string;
    dealershipId: string;
    serviceType: string;
    preferredDate: string;
    preferredTime: string;
    complaintDetails?: string;
  }) {
    return request<{ success: boolean; id: string; requestNumber: string; status: string }>(
      '/api/customer/service-requests',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  getCustomerWarranty() {
    return request<{ warranties: any[]; claims: any[]; warrantyServiceHistory: any[] }>('/api/customer/warranty');
  },

  submitCustomerWarrantyClaim(payload: {
    warrantyRecordId: string;
    dealershipName?: string;
    componentCategory: string;
    issueDescription: string;
    faultCode?: string;
  }) {
    return request<{ success: boolean; id: string; claimNumber: string; status: string }>('/api/customer/warranty/claims', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCustomerNotifications() {
    return request<{ notifications: any[] }>('/api/customer/notifications');
  },

  markCustomerNotificationRead(id: string) {
    return request<{ success: boolean }>(`/api/customer/notifications/${id}/read`, { method: 'PATCH' });
  },

  getCustomerSupportTickets() {
    return request<{ tickets: any[] }>('/api/customer/support');
  },

  createCustomerSupportTicket(payload: { category: string; priority: string; subject: string; description: string }) {
    return request<{ success: boolean; id: string; ticketNumber: string; status: string }>('/api/customer/support', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getCustomerDocuments() {
    return request<{ documents: any[] }>('/api/customer/documents');
  },

  // Admin Customer Governance APIs
  getAdminCustomersOverview(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    params?: { q?: string; status?: string; verification?: string }
  ) {
    const sp = new URLSearchParams();
    if (params?.q) sp.set('q', params.q);
    if (params?.status) sp.set('status', params.status);
    if (params?.verification) sp.set('verification', params.verification);
    const qs = sp.toString();
    return request<{
      scope: string;
      summary: any;
      customers: any[];
      inquiries: any[];
      testDrives: any[];
      bookings: any[];
      payments: any[];
      serviceRequests: any[];
      warrantyClaims: any[];
      supportTickets: any[];
    }>(`/api/${scope}/customer-governance${qs ? `?${qs}` : ''}`);
  },

  getAdminCustomerDetail(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string
  ) {
    return request<{
      customer: any;
      profile: any;
      vehicles: any[];
      bookings: any[];
      invoices: any[];
      payments: any[];
      documents: any[];
      activity: any[];
    }>(`/api/${scope}/customer-governance/${id}`);
  },

  getAdminCustomerAuditLogs(scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager') {
    return request<{ logs: any[] }>(`/api/${scope}/customer-governance/audit-logs`);
  },

  verifyAdminCustomer(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string
  ) {
    return request<{ success: boolean; verificationStatus: string }>(`/api/${scope}/customer-governance/${id}/verify`, {
      method: 'PATCH',
    });
  },

  updateAdminCustomerStatus(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    id: string,
    status: 'Active' | 'Suspended',
    reason?: string
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason }),
    });
  },

  updateAdminCustomerInquiry(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    inqId: string,
    payload: { status?: string; assignedToName?: string; replyText?: string }
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/inquiries/${inqId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateAdminCustomerTestDrive(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    tdId: string,
    payload: { status: string; assignedStaffName?: string; showroomNotes?: string }
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/test-drives/${tdId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  updateAdminCustomerBooking(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    bookingId: string,
    payload: {
      bookingStatus?: string;
      paymentStatus?: string;
      deliveryStatus?: string;
      adminNotes?: string;
      paymentMethod?: string;
      transactionRef?: string;
    }
  ) {
    return request<{ success: boolean; bookingStatus: string; paymentStatus: string; deliveryStatus: string }>(
      `/api/${scope}/customer-governance/bookings/${bookingId}`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    );
  },

  updateAdminCustomerService(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    svcId: string,
    payload: { status: string; technicianAssigned?: string; advisorNotes?: string; actualCostPkr?: number }
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/service-requests/${svcId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  reviewAdminCustomerWarrantyClaim(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    claimId: string,
    payload: { status: string; approvedAmountPkr?: number; reviewNotes?: string }
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/warranty-claims/${claimId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  replyAdminCustomerSupportTicket(
    scope: 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager',
    ticketId: string,
    payload: { status?: string; replyText: string }
  ) {
    return request<{ success: boolean; status: string }>(`/api/${scope}/customer-governance/support-tickets/${ticketId}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },

  // ---------------- Centralized Security, Identity Verification & Admin Approval ----------------
  logoutAllDevices() {
    return request<{ success: boolean; revokedSessions: number; message: string }>('/api/auth/logout-all', {
      method: 'POST',
    });
  },

  getVerificationCapabilities() {
    return request<{
      smtpConfigured: boolean;
      smsConfigured: boolean;
      sessionTimeoutMinutes: number;
      idleTimeoutMinutes: number;
      mandatoryMfaRoles: string[];
    }>('/api/verification/capabilities');
  },

  verifyEmailToken(token: string) {
    return request<{ success: boolean; email: string; subjectType: string; message: string }>(
      '/api/verification/email/verify-token',
      {
        method: 'POST',
        body: JSON.stringify({ token }),
      }
    );
  },

  resendEmailVerification(email?: string) {
    return request<{
      success: boolean;
      expiresAt?: string;
      message: string;
      verificationOutbox?: { notice: string; code: string; verificationToken: string };
    }>('/api/verification/email/resend', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  requestMobileOtp(phone?: string) {
    return request<{ success: boolean; provider: string; expiresAt: string; message: string }>(
      '/api/verification/mobile/request-otp',
      {
        method: 'POST',
        body: JSON.stringify({ phone }),
      }
    );
  },

  verifyMobileOtp(payload: { phone?: string; code: string }) {
    return request<{ success: boolean; message: string }>('/api/verification/mobile/verify-otp', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getMySecurityProfile() {
    return request<{
      account: any;
      profile: any;
      verificationRecord: any;
      documents: any[];
      mfa: {
        totpEnabled: boolean;
        emailOtpEnabled: boolean;
        smsOtpEnabled: boolean;
        mfaRequired: boolean;
        pendingEnrollment: boolean;
        enrolledAt: string | null;
        remainingRecoveryCodes: number;
      };
      sessions: any[];
      loginActivity: any[];
      approvalHistory: any[];
      capabilities: { smtpConfigured: boolean; smsConfigured: boolean };
    }>('/api/verification/me/security-profile');
  },

  uploadVerificationDocument(formData: FormData) {
    return request<{ success: boolean; document: any; message: string }>('/api/verification/documents', {
      method: 'POST',
      body: formData,
    });
  },

  changeUnifiedPassword(payload: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
    revokeOtherSessions?: boolean;
  }) {
    return request<{ success: boolean; message: string }>('/api/verification/password/change', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  unifiedForgotPassword(email: string) {
    return request<{
      success: boolean;
      expiresAt?: string;
      message: string;
      resetOutbox?: { notice: string; resetToken: string };
    }>('/api/verification/password/forgot', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  unifiedResetPassword(payload: { token: string; newPassword: string; confirmPassword: string }) {
    return request<{ success: boolean; message: string }>('/api/verification/password/reset', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  enrollMfaTotp(currentPassword: string) {
    return request<{ success: boolean; secret: string; otpAuthUri: string; message: string }>(
      '/api/verification/mfa/enroll',
      {
        method: 'POST',
        body: JSON.stringify({ currentPassword }),
      }
    );
  },

  confirmMfaTotp(code: string) {
    return request<{ success: boolean; recoveryCodes: string[]; message: string }>(
      '/api/verification/mfa/confirm',
      {
        method: 'POST',
        body: JSON.stringify({ code }),
      }
    );
  },

  disableMfaTotp(payload: { currentPassword: string; code: string }) {
    return request<{ success: boolean; message: string }>('/api/verification/mfa/disable', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  regenerateMfaRecoveryCodes(payload: { currentPassword: string; code: string }) {
    return request<{ success: boolean; recoveryCodes: string[]; message: string }>(
      '/api/verification/mfa/recovery-codes/regenerate',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    );
  },

  revokeUnifiedSession(sessionId: string) {
    return request<{ success: boolean; message: string }>(`/api/verification/sessions/revoke/${sessionId}`, {
      method: 'POST',
    });
  },

  getAdminVerificationAccounts(params?: {
    role?: string;
    status?: string;
    verificationStatus?: string;
    q?: string;
  }) {
    const sp = new URLSearchParams();
    if (params?.role) sp.set('role', params.role);
    if (params?.status) sp.set('status', params.status);
    if (params?.verificationStatus) sp.set('verificationStatus', params.verificationStatus);
    if (params?.q) sp.set('q', params.q);
    const qs = sp.toString();
    return request<{ accounts: any[]; summary: any }>(`/api/admin/verifications/accounts${qs ? `?${qs}` : ''}`);
  },

  getAdminVerificationAccountDetail(userId: string) {
    return request<{
      account: any;
      profile: any;
      verificationRecord: any;
      documents: any[];
      approvalHistory: any[];
      loginActivity: any[];
      mfa: any;
    }>(`/api/admin/verifications/accounts/${userId}`);
  },

  submitAdminVerificationDecision(
    userId: string,
    payload: {
      action:
        | 'mark_under_review'
        | 'approve'
        | 'reject'
        | 'request_documents'
        | 'suspend'
        | 'reactivate'
        | 'verify_email_manual';
      reason?: string;
      notes?: string;
      documentId?: string;
    }
  ) {
    return request<{
      success: boolean;
      newStatus: string;
      newVerificationStatus: string;
      message: string;
    }>(`/api/admin/verifications/accounts/${userId}/decision`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  unifiedForgotPasswordOtp(email: string, channel: 'email' | 'sms' = 'email') {
    return request<{
      success: boolean;
      expiresAt?: string;
      expiryMinutes?: number;
      message: string;
      resetOutbox?: { notice: string; otpCode: string };
    }>('/api/verification/password/forgot-otp', {
      method: 'POST',
      body: JSON.stringify({ email, channel }),
    });
  },

  unifiedResetPasswordOtp(payload: {
    email: string;
    otpCode: string;
    newPassword: string;
    confirmPassword: string;
  }) {
    return request<{ success: boolean; message: string }>('/api/verification/password/reset-otp', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  getAdminVerificationAuditLogs() {
    return request<{ logs: any[] }>('/api/admin/verifications/audit-logs');
  },

  getAdminVerificationLoginActivity(params?: {
    q?: string;
    role?: string;
    status?: string;
    fromDate?: string;
    toDate?: string;
  }) {
    const sp = new URLSearchParams();
    if (params?.q) sp.set('q', params.q);
    if (params?.role) sp.set('role', params.role);
    if (params?.status) sp.set('status', params.status);
    if (params?.fromDate) sp.set('fromDate', params.fromDate);
    if (params?.toDate) sp.set('toDate', params.toDate);
    const qs = sp.toString();
    return request<{
      logs: any[];
      stats?: {
        totalAttempts: number;
        successfulLogins: number;
        failedLogins: number;
        suspiciousAlerts: number;
        activeSessions: number;
      };
    }>(`/api/admin/verifications/login-activity${qs ? `?${qs}` : ''}`);
  },

  getAdminVerificationSessions() {
    return request<{ sessions: any[] }>('/api/admin/verifications/sessions');
  },

  terminateAdminVerificationSession(sessionId: string) {
    return request<{ success: boolean; message: string }>(`/api/admin/verifications/sessions/${encodeURIComponent(sessionId)}/terminate`, {
      method: 'POST',
    });
  },

  getAdminRbacMatrix() {
    return request<{
      roles: string[];
      modules: string[];
      matrix: any[];
      canEditFounder: boolean;
      canEditMatrix: boolean;
    }>('/api/admin/verifications/rbac-matrix');
  },

  updateAdminRbacMatrix(
    updates: Array<{
      roleKey: string;
      moduleKey: string;
      canView: boolean;
      canCreate: boolean;
      canEdit: boolean;
      canDelete: boolean;
      canApprove: boolean;
    }>
  ) {
    return request<{ success: boolean; updatedCount: number; message: string }>('/api/admin/verifications/rbac-matrix', {
      method: 'PUT',
      body: JSON.stringify({ updates }),
    });
  },

  getAdminSecuritySettings() {
    return request<{
      securityPolicy: any;
      smtpConfigured: boolean;
      smsConfigured: boolean;
      canEdit: boolean;
    }>('/api/admin/verifications/security-settings');
  },

  updateAdminSecuritySettings(securityPolicy: any) {
    return request<{ success: boolean; securityPolicy: any; message: string }>('/api/admin/verifications/security-settings', {
      method: 'PUT',
      body: JSON.stringify({ securityPolicy }),
    });
  },

  // =========================================================================
  // COMPANY & BRANCH MANAGEMENT HUB (/api/org-management/*)
  // =========================================================================
  getOrgOverview() {
    return request<{
      scope: any;
      defaultDepartments: string[];
      companies: any[];
      metrics: any;
      recentLogs: any[];
    }>('/api/org-management/overview');
  },
  getOrgHeadOffices() {
    return request<{ headOffices: any[]; companies: any[] }>('/api/org-management/head-offices');
  },
  createOrgHeadOffice(payload: any) {
    return request<{ success: boolean; id: string }>('/api/org-management/head-offices', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgHeadOffice(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/head-offices/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  addOrgHeadOfficeDoc(id: string, payload: any) {
    return request<{ success: boolean; documents: any[] }>(`/api/org-management/head-offices/${encodeURIComponent(id)}/documents`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getOrgRegionalOffices(params?: { search?: string; countryId?: string; companyId?: string; status?: string }) {
    const q = new URLSearchParams();
    if (params?.search) q.set('search', params.search);
    if (params?.countryId) q.set('countryId', params.countryId);
    if (params?.companyId) q.set('companyId', params.companyId);
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return request<{ regionalOffices: any[] }>(`/api/org-management/regional-offices${qs ? `?${qs}` : ''}`);
  },
  createOrgRegionalOffice(payload: any) {
    return request<{ success: boolean; id: string; officeCode: string }>('/api/org-management/regional-offices', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgRegionalOffice(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/regional-offices/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getOrgBranches(params?: { search?: string; countryId?: string; companyId?: string; status?: string }) {
    const q = new URLSearchParams();
    if (params?.search) q.set('search', params.search);
    if (params?.countryId) q.set('countryId', params.countryId);
    if (params?.companyId) q.set('companyId', params.companyId);
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return request<{ branches: any[] }>(`/api/org-management/branches${qs ? `?${qs}` : ''}`);
  },
  createOrgBranch(payload: any) {
    return request<{ success: boolean; id: string; code: string }>('/api/org-management/branches', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getOrgBranchDetail(id: string) {
    return request<{ branch: any; employees: any[]; departmentRows: any[]; activityLogs: any[] }>(`/api/org-management/branches/${encodeURIComponent(id)}`);
  },
  updateOrgBranch(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/branches/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  addOrgBranchDoc(id: string, payload: any) {
    return request<{ success: boolean; documents: any[] }>(`/api/org-management/branches/${encodeURIComponent(id)}/documents`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  transferOrgEmployee(payload: { employeeId: string; targetBranchId: string; reason?: string }) {
    return request<{ success: boolean }>('/api/org-management/branches/transfer-employee', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getOrgDepartments(companyId?: string) {
    const qs = companyId && companyId !== 'ALL' ? `?companyId=${encodeURIComponent(companyId)}` : '';
    return request<{ departments: any[]; standardCatalog: string[] }>(`/api/org-management/departments${qs}`);
  },
  createOrgDepartment(payload: any) {
    return request<{ success: boolean; id: string; code: string }>('/api/org-management/departments', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgDepartment(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/departments/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getOrgCountries() {
    return request<{ countries: any[] }>('/api/org-management/countries');
  },
  createOrgCountry(payload: any) {
    return request<{ success: boolean; id: string }>('/api/org-management/countries', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgCountry(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/countries/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getOrgCities(countryId?: string) {
    const qs = countryId && countryId !== 'ALL' ? `?countryId=${encodeURIComponent(countryId)}` : '';
    return request<{ cities: any[] }>(`/api/org-management/cities${qs}`);
  },
  createOrgCity(payload: any) {
    return request<{ success: boolean; id: string }>('/api/org-management/cities', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgCity(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/cities/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getOrgStaff(params?: { search?: string; branchId?: string; department?: string; status?: string }) {
    const q = new URLSearchParams();
    if (params?.search) q.set('search', params.search);
    if (params?.branchId) q.set('branchId', params.branchId);
    if (params?.department) q.set('department', params.department);
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return request<{ staff: any[] }>(`/api/org-management/staff${qs ? `?${qs}` : ''}`);
  },
  createOrgStaff(payload: any) {
    return request<{ success: boolean; id: string; employeeCode: string }>('/api/org-management/staff', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateOrgStaff(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/org-management/staff/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getOrgHierarchy() {
    return request<{ hierarchy: any[] }>('/api/org-management/hierarchy');
  },
  getOrgMapLocations(params?: { countryId?: string; city?: string; search?: string }) {
    const q = new URLSearchParams();
    if (params?.countryId) q.set('countryId', params.countryId);
    if (params?.city) q.set('city', params.city);
    if (params?.search) q.set('search', params.search);
    const qs = q.toString();
    return request<{ countries: any[]; cities: any[]; markers: any[]; countrySvgCoords: any }>(`/api/org-management/map-locations${qs ? `?${qs}` : ''}`);
  },
  getOrgReports(params?: { period?: string; fromDate?: string; toDate?: string; countryId?: string; companyId?: string }) {
    const q = new URLSearchParams();
    if (params?.period) q.set('period', params.period);
    if (params?.fromDate) q.set('fromDate', params.fromDate);
    if (params?.toDate) q.set('toDate', params.toDate);
    if (params?.countryId) q.set('countryId', params.countryId);
    if (params?.companyId) q.set('companyId', params.companyId);
    const qs = q.toString();
    return request<any>(`/api/org-management/reports${qs ? `?${qs}` : ''}`);
  },
  getOrgReportExportUrl(format: 'xlsx' | 'csv' | 'pdf', params?: { period?: string; fromDate?: string; toDate?: string; countryId?: string; companyId?: string }) {
    const q = new URLSearchParams({ format });
    if (params?.period) q.set('period', params.period);
    if (params?.fromDate) q.set('fromDate', params.fromDate);
    if (params?.toDate) q.set('toDate', params.toDate);
    if (params?.countryId) q.set('countryId', params.countryId);
    if (params?.companyId) q.set('companyId', params.companyId);
    return `/api/org-management/reports/export?${q.toString()}`;
  },
  getOrgActivityLogs(params?: { module?: string; search?: string }) {
    const q = new URLSearchParams();
    if (params?.module) q.set('module', params.module);
    if (params?.search) q.set('search', params.search);
    const qs = q.toString();
    return request<{ immutable: boolean; logs: any[]; modules: string[] }>(`/api/org-management/activity-logs${qs ? `?${qs}` : ''}`);
  },

  // ---------------- Employee Management Module (/api/employee-management) ----------------
  getEmpMgmtDashboard() {
    return request<{
      scope: any;
      payPeriod: string;
      todayDate: string;
      metrics: {
        totalEmployees: number;
        activeEmployees: number;
        inactiveEmployees: number;
        onLeaveEmployees: number;
        presentToday: number;
        absentToday: number;
        lateArrivalsToday: number;
        halfDayToday: number;
        totalMonthlyPayroll: number;
        paidMonthlyPayroll: number;
        pendingLeavesCount: number;
        expiringDocsCount: number;
      };
      departmentDistribution: Array<{ department: string; count: number }>;
      branchDistribution: Array<{ branch: string; count: number }>;
      attendance7DayTrend: Array<{ date: string; present: number; late: number; absent: number }>;
      recentAuditLogs: any[];
      referenceData: {
        companies: any[];
        branches: any[];
        departments: any[];
        countries: any[];
        leaveTypes: string[];
        documentCategories: string[];
      };
    }>('/api/employee-management/dashboard');
  },
  getEmpMgmtNextCode(companyId?: string, countryId?: string) {
    const q = new URLSearchParams();
    if (companyId) q.set('companyId', companyId);
    if (countryId) q.set('countryId', countryId);
    const qs = q.toString();
    return request<{ nextEmployeeCode: string }>(`/api/employee-management/employees/next-code${qs ? `?${qs}` : ''}`);
  },
  getEmpMgmtEmployees(params?: { q?: string; branchId?: string; department?: string; status?: string; employmentType?: string; companyId?: string; page?: number; limit?: number }) {
    const q = new URLSearchParams();
    if (params?.q) q.set('q', params.q);
    if (params?.branchId) q.set('branchId', params.branchId);
    if (params?.department) q.set('department', params.department);
    if (params?.status) q.set('status', params.status);
    if (params?.employmentType) q.set('employmentType', params.employmentType);
    if (params?.companyId) q.set('companyId', params.companyId);
    if (params?.page) q.set('page', String(params.page));
    if (params?.limit) q.set('limit', String(params.limit));
    const qs = q.toString();
    return request<{ employees: any[]; pagination: { total: number; page: number; limit: number; totalPages: number } }>(`/api/employee-management/employees${qs ? `?${qs}` : ''}`);
  },
  getEmpMgmtEmployeeDetail(id: string) {
    return request<{
      employee: any;
      salaryStructure: any;
      payrollHistory: any[];
      attendance: any[];
      leaveBalance: any;
      leaves: any[];
      history: any[];
      reviews: any[];
      targets: any[];
      documents: any[];
      auditLogs: any[];
    }>(`/api/employee-management/employees/${encodeURIComponent(id)}`);
  },
  createEmpMgmtEmployee(payload: any) {
    return request<{ success: boolean; id: string; employeeCode: string }>('/api/employee-management/employees', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateEmpMgmtEmployee(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/employee-management/employees/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  updateEmpMgmtEmployeeStatus(id: string, status: string, reason?: string) {
    return request<{ success: boolean; status: string }>(`/api/employee-management/employees/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason }),
    });
  },
  uploadEmpMgmtPhoto(id: string, file: File) {
    const fd = new FormData();
    fd.append('photo', file);
    return request<{ success: boolean; photoDocId: string; photoUrl: string }>(`/api/employee-management/employees/${encodeURIComponent(id)}/photo`, {
      method: 'POST',
      body: fd,
    });
  },
  getEmpMgmtAttendance(params?: { date?: string; month?: string; branchId?: string; department?: string; status?: string; employeeId?: string }) {
    const q = new URLSearchParams();
    if (params?.date) q.set('date', params.date);
    if (params?.month) q.set('month', params.month);
    if (params?.branchId) q.set('branchId', params.branchId);
    if (params?.department) q.set('department', params.department);
    if (params?.status) q.set('status', params.status);
    if (params?.employeeId) q.set('employeeId', params.employeeId);
    const qs = q.toString();
    return request<{ records: any[]; summary: { total: number; present: number; late: number; absent: number; halfDay: number; totalHours: number; overtimeHours: number } }>(
      `/api/employee-management/attendance${qs ? `?${qs}` : ''}`
    );
  },
  markEmpMgmtAttendance(payload: any) {
    return request<{ success: boolean; id?: string; workingHours?: number; overtimeHours?: number }>('/api/employee-management/attendance/mark', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateEmpMgmtAttendance(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/employee-management/attendance/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getEmpMgmtAttendanceReport(month?: string) {
    const qs = month ? `?month=${encodeURIComponent(month)}` : '';
    return request<{ month: string; branchWise: any[]; departmentWise: any[]; totalRecords: number }>(`/api/employee-management/attendance/reports${qs}`);
  },
  getEmpMgmtPayroll(params?: { payPeriod?: string; status?: string }) {
    const q = new URLSearchParams();
    if (params?.payPeriod) q.set('payPeriod', params.payPeriod);
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return request<{ structures: any[]; payrollRecords: any[]; summary: { totalGross: number; totalNet: number; paidTotal: number; unpaidTotal: number; pendingApprovalCount: number } }>(
      `/api/employee-management/payroll${qs ? `?${qs}` : ''}`
    );
  },
  saveEmpMgmtSalaryStructure(employeeId: string, payload: any) {
    return request<{ success: boolean }>(`/api/employee-management/payroll/structure/${encodeURIComponent(employeeId)}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },
  processEmpMgmtPayroll(payload: any) {
    return request<{ success: boolean; processedCount: number; processed: any[]; skipped: string[] }>('/api/employee-management/payroll/process', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  approveEmpMgmtPayroll(id: string, decision: 'Approved' | 'Rejected') {
    return request<{ success: boolean; approvalStatus: string }>(`/api/employee-management/payroll/${encodeURIComponent(id)}/approve`, {
      method: 'PATCH',
      body: JSON.stringify({ decision }),
    });
  },
  payEmpMgmtPayroll(id: string, bankReference: string, paymentDate?: string) {
    return request<{ success: boolean; paymentStatus: string; bankReference: string }>(`/api/employee-management/payroll/${encodeURIComponent(id)}/pay`, {
      method: 'PATCH',
      body: JSON.stringify({ bankReference, paymentDate }),
    });
  },
  async downloadEmpMgmtBlob(url: string): Promise<{ blob: Blob; filename: string }> {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Download failed (HTTP ${res.status})`);
    }
    const cd = res.headers.get('Content-Disposition') || '';
    const match = cd.match(/filename="?([^"]+)"?/i);
    return {
      blob: await res.blob(),
      filename: match ? decodeURIComponent(match[1]) : 'download',
    };
  },
  getEmpMgmtLeaves(params?: { status?: string; leaveType?: string }) {
    const q = new URLSearchParams();
    if (params?.status) q.set('status', params.status);
    if (params?.leaveType) q.set('leaveType', params.leaveType);
    const qs = q.toString();
    return request<{ requests: any[]; balances: any[]; departmentSummary: any[]; leaveTypes: string[] }>(`/api/employee-management/leaves${qs ? `?${qs}` : ''}`);
  },
  submitEmpMgmtLeave(payload: FormData | Record<string, any>) {
    const body = payload instanceof FormData ? payload : JSON.stringify(payload);
    return request<{ success: boolean; leaveId: string; totalDays: number }>('/api/employee-management/leaves', {
      method: 'POST',
      body,
    });
  },
  decideEmpMgmtLeave(id: string, decision: 'Approved' | 'Rejected', reviewNotes?: string) {
    return request<{ success: boolean; status: string }>(`/api/employee-management/leaves/${encodeURIComponent(id)}/decide`, {
      method: 'PATCH',
      body: JSON.stringify({ decision, reviewNotes }),
    });
  },
  getEmpMgmtPositions() {
    return request<{ positions: any[]; departments: any[]; history: any[] }>('/api/employee-management/positions');
  },
  createEmpMgmtPosition(payload: any) {
    return request<{ success: boolean; id: string }>('/api/employee-management/positions', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  promoteTransferEmpMgmtEmployee(employeeId: string, payload: any) {
    return request<{ success: boolean }>(`/api/employee-management/employees/${encodeURIComponent(employeeId)}/promote-transfer`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getEmpMgmtPerformance() {
    return request<{ reviews: any[]; targets: any[] }>('/api/employee-management/performance');
  },
  createEmpMgmtReview(payload: any) {
    return request<{ success: boolean; id: string; rating: number }>('/api/employee-management/performance/reviews', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  createEmpMgmtTarget(payload: any) {
    return request<{ success: boolean; id: string }>('/api/employee-management/performance/targets', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateEmpMgmtTarget(id: string, payload: any) {
    return request<{ success: boolean }>(`/api/employee-management/performance/targets/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getEmpMgmtDocuments(params?: { category?: string; verificationStatus?: string }) {
    const q = new URLSearchParams();
    if (params?.category) q.set('category', params.category);
    if (params?.verificationStatus) q.set('verificationStatus', params.verificationStatus);
    const qs = q.toString();
    return request<{ documents: any[]; categories: string[] }>(`/api/employee-management/documents${qs ? `?${qs}` : ''}`);
  },
  uploadEmpMgmtDocument(formData: FormData) {
    return request<{ success: boolean; id: string }>('/api/employee-management/documents', {
      method: 'POST',
      body: formData,
    });
  },
  verifyEmpMgmtDocument(id: string, verificationStatus: 'Verified' | 'Rejected' | 'Pending Verification', notes?: string) {
    return request<{ success: boolean; verificationStatus: string }>(`/api/employee-management/documents/${encodeURIComponent(id)}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ verificationStatus, notes }),
    });
  },
  getEmpMgmtReports(type: string, month?: string) {
    const q = new URLSearchParams({ type });
    if (month) q.set('month', month);
    return request<{ type: string; month: string; generatedAt: string; title: string; rows: any[] }>(`/api/employee-management/reports?${q.toString()}`);
  },
  getEmpMgmtReportExportUrl(type: string, format: 'xlsx' | 'pdf' | 'csv', month?: string) {
    const q = new URLSearchParams({ type, format });
    if (month) q.set('month', month);
    return `/api/employee-management/reports/export?${q.toString()}`;
  },
  getEmpMgmtSettings(companyId?: string) {
    const qs = companyId ? `?companyId=${encodeURIComponent(companyId)}` : '';
    return request<{ settings: any; canEdit: boolean }>(`/api/employee-management/settings${qs}`);
  },
  updateEmpMgmtSettings(payload: any) {
    return request<{ success: boolean }>('/api/employee-management/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  },
  getEmpMgmtAuditLogs() {
    return request<{ immutable: boolean; logs: any[] }>('/api/employee-management/audit-logs');
  },

  // ---------------- Enterprise Dealership Management Module ----------------
  getDealershipDashboard() {
    return request<{
      scope: any;
      metrics: any;
      monthlySeries: any[];
      modelBreakdown: any[];
      dealerRanking: any[];
      recentAuditLogs: any[];
      catalogs: { companies: any[]; countries: any[]; branches: any[]; dealers: any[] };
    }>('/api/dealership-management/dashboard');
  },
  getNextDealerAndShowroomCode(countryId = 'PK', city = 'Karachi') {
    const q = new URLSearchParams({ countryId, city });
    return request<{ dealerCode: string; showroomCode: string }>(`/api/dealership-management/dealers/next-code?${q.toString()}`);
  },
  getDealershipDealers(params?: { q?: string; status?: string; verification?: string; city?: string; companyId?: string }) {
    const q = new URLSearchParams();
    if (params?.q) q.set('q', params.q);
    if (params?.status) q.set('status', params.status);
    if (params?.verification) q.set('verification', params.verification);
    if (params?.city) q.set('city', params.city);
    if (params?.companyId) q.set('companyId', params.companyId);
    const qs = q.toString();
    return request<{ dealers: any[]; total: number }>(`/api/dealership-management/dealers${qs ? `?${qs}` : ''}`);
  },
  getDealershipDealerDetail(id: string) {
    return request<{
      dealer: any;
      showrooms: any[];
      documents: any[];
      verificationHistory: any[];
      inventory: any[];
      sales: any[];
      targets: any[];
    }>(`/api/dealership-management/dealers/${encodeURIComponent(id)}`);
  },
  registerDealershipDealer(payload: any) {
    return request<{ success: boolean; dealer: any; showroom: any }>('/api/dealership-management/dealers', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateDealershipDealer(id: string, payload: any) {
    return request<{ success: boolean; dealer: any }>(`/api/dealership-management/dealers/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  sendDealershipVerificationOtp(id: string, channel: 'email' | 'mobile') {
    return request<{ success: boolean; channel: string; message: string; devOtpPreview?: string }>(
      `/api/dealership-management/dealers/${encodeURIComponent(id)}/send-verification`,
      { method: 'POST', body: JSON.stringify({ channel }) }
    );
  },
  confirmDealershipVerificationOtp(id: string, channel: 'email' | 'mobile', otpCode: string) {
    return request<{ success: boolean; channel: string; dealer: any }>(
      `/api/dealership-management/dealers/${encodeURIComponent(id)}/confirm-verification`,
      { method: 'POST', body: JSON.stringify({ channel, otpCode }) }
    );
  },
  getDealershipVerificationQueue() {
    return request<{ dealers: any[]; documents: any[]; history: any[] }>('/api/dealership-management/verification-queue');
  },
  verifyDealershipDealer(id: string, payload: { decision: 'approve' | 'reject' | 'suspend' | 'reactivate'; rejectionReason?: string; notes?: string }) {
    return request<{ success: boolean; dealer: any }>(`/api/dealership-management/dealers/${encodeURIComponent(id)}/verify`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getDealershipShowrooms(params?: { dealerId?: string; status?: string }) {
    const q = new URLSearchParams();
    if (params?.dealerId) q.set('dealerId', params.dealerId);
    if (params?.status) q.set('status', params.status);
    const qs = q.toString();
    return request<{ showrooms: any[] }>(`/api/dealership-management/showrooms${qs ? `?${qs}` : ''}`);
  },
  createDealershipShowroom(payload: any) {
    return request<{ success: boolean; showroom: any }>('/api/dealership-management/showrooms', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateDealershipShowroom(id: string, payload: any) {
    return request<{ success: boolean; showroom: any }>(`/api/dealership-management/showrooms/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getDealershipInventory(params?: { dealerId?: string; status?: string; q?: string }) {
    const q = new URLSearchParams();
    if (params?.dealerId) q.set('dealerId', params.dealerId);
    if (params?.status) q.set('status', params.status);
    if (params?.q) q.set('q', params.q);
    const qs = q.toString();
    return request<{ inventory: any[]; history: any[] }>(`/api/dealership-management/inventory${qs ? `?${qs}` : ''}`);
  },
  addDealershipInventory(payload: any) {
    return request<{ success: boolean; vehicle: any }>('/api/dealership-management/inventory', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateDealershipInventory(id: string, payload: any) {
    return request<{ success: boolean; vehicle: any }>(`/api/dealership-management/inventory/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  transferDealershipInventory(id: string, payload: { toDealerId: string; toShowroomId?: string; notes?: string }) {
    return request<{ success: boolean; vehicle: any }>(`/api/dealership-management/inventory/${encodeURIComponent(id)}/transfer`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getDealershipSales(params?: { dealerId?: string; paymentStatus?: string }) {
    const q = new URLSearchParams();
    if (params?.dealerId) q.set('dealerId', params.dealerId);
    if (params?.paymentStatus) q.set('paymentStatus', params.paymentStatus);
    const qs = q.toString();
    return request<{ sales: any[]; customers: any[] }>(`/api/dealership-management/sales${qs ? `?${qs}` : ''}`);
  },
  recordDealershipSale(payload: any) {
    return request<{ success: boolean; sale: any }>('/api/dealership-management/sales', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  decideDealershipSaleDiscount(id: string, decision: 'approve' | 'reject') {
    return request<{ success: boolean; sale: any }>(`/api/dealership-management/sales/${encodeURIComponent(id)}/discount`, {
      method: 'PATCH',
      body: JSON.stringify({ decision }),
    });
  },
  verifyDealershipSalePayment(id: string, payload: { paymentProviderRef: string; paidAmountPkr: number }) {
    return request<{ success: boolean; sale: any }>(`/api/dealership-management/sales/${encodeURIComponent(id)}/payment`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  updateDealershipSaleDelivery(id: string, deliveryStatus: string) {
    return request<{ success: boolean; sale: any }>(`/api/dealership-management/sales/${encodeURIComponent(id)}/delivery`, {
      method: 'PATCH',
      body: JSON.stringify({ deliveryStatus }),
    });
  },
  cancelRefundDealershipSale(id: string, payload: { reason: string; refundAmountPkr?: number }) {
    return request<{ success: boolean; sale: any }>(`/api/dealership-management/sales/${encodeURIComponent(id)}/cancel-refund`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  getDealershipCommissions() {
    return request<{ commissions: any[]; rules: any[]; summary: any }>('/api/dealership-management/commissions');
  },
  createDealershipCommissionRule(payload: any) {
    return request<{ success: boolean; rule: any }>('/api/dealership-management/commissions/rules', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  approveDealershipCommission(id: string) {
    return request<{ success: boolean; commission: any }>(`/api/dealership-management/commissions/${encodeURIComponent(id)}/approve`, {
      method: 'PATCH',
    });
  },
  payDealershipCommission(id: string, payoutReference: string) {
    return request<{ success: boolean; commission: any }>(`/api/dealership-management/commissions/${encodeURIComponent(id)}/pay`, {
      method: 'PATCH',
      body: JSON.stringify({ payoutReference }),
    });
  },
  getDealershipTargets() {
    return request<{ targets: any[] }>('/api/dealership-management/targets');
  },
  createDealershipTarget(payload: any) {
    return request<{ success: boolean; target: any }>('/api/dealership-management/targets', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },
  updateDealershipTarget(id: string, payload: any) {
    return request<{ success: boolean; target: any }>(`/api/dealership-management/targets/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
  },
  getDealershipDocuments() {
    return request<{ documents: any[] }>('/api/dealership-management/documents');
  },
  uploadDealershipDocument(formData: FormData) {
    return request<{ success: boolean; document: any }>('/api/dealership-management/documents', {
      method: 'POST',
      body: formData,
    });
  },
  verifyDealershipDocument(id: string, status: 'Verified' | 'Rejected', notes?: string) {
    return request<{ success: boolean; verificationStatus: string }>(`/api/dealership-management/documents/${encodeURIComponent(id)}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ status, notes }),
    });
  },
  async downloadDealershipBlob(url: string): Promise<{ blob: Blob; filename: string }> {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `Download failed (HTTP ${res.status})`);
    }
    const cd = res.headers.get('Content-Disposition') || '';
    const match = cd.match(/filename="?([^"]+)"?/i);
    return {
      blob: await res.blob(),
      filename: match ? decodeURIComponent(match[1]) : 'export',
    };
  },
};



