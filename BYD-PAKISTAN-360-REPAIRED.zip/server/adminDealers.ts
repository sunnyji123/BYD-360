import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import {
  sqlite,
  PRIVATE_DEALER_DOCS_DIR,
  hashPassword,
  sha256,
  generateSecureToken,
  generateNumericOtp,
  generateTotpSecret,
  validatePasswordStrength,
  logOwnerAudit,
  logAdminActivity,
  logCompanyActivity,
  logCountryActivity,
  logBranchActivity,
  logDealerActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  CANONICAL_DEALER_PERMISSIONS,
  sanitizeDealerPermissions,
  resolveDealerPermissions,
  getClientIp,
} from './auth';
import { buildSimplePdfBuffer, savePrivateDealerFile } from './dealer';

export type AdminScopeLevel = 'founder' | 'super_admin' | 'company_admin' | 'country_manager' | 'branch_manager';

interface ScopeOptions {
  scope: AdminScopeLevel;
  middlewares: Array<(req: Request, res: Response, next: NextFunction) => void>;
}

function logAdminScopedAction(
  req: Request,
  scope: AdminScopeLevel,
  action: string,
  targetId: string | null,
  details: string
) {
  const actor = req.auth!;
  const ip = getClientIp(req);
  if (scope === 'founder') {
    logOwnerAudit({
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action,
      module: 'Dealer Governance',
      targetId,
      companyId: actor.companyId,
      details,
      ipAddress: ip,
    });
  } else if (scope === 'super_admin') {
    logAdminActivity({
      adminId: actor.userId,
      adminName: actor.fullName,
      adminRole: actor.role,
      action,
      module: 'Dealer Governance',
      targetId,
      details,
      ipAddress: ip,
    });
  } else if (scope === 'company_admin' && actor.companyId) {
    logCompanyActivity({
      companyId: actor.companyId,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action,
      module: 'Dealer Governance',
      targetId,
      details,
      ipAddress: ip,
    });
  } else if (scope === 'country_manager') {
    logCountryActivity({
      countryId: actor.country,
      managerId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action,
      module: 'Dealer Governance',
      targetId,
      details,
      ipAddress: ip,
    });
  } else if (scope === 'branch_manager' && actor.branchId && actor.companyId) {
    logBranchActivity({
      branchId: actor.branchId,
      companyId: actor.companyId,
      countryId: actor.country,
      managerId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action,
      module: 'Dealer Governance',
      targetId,
      details,
      ipAddress: ip,
    });
  }
}

function assertDealerInAdminScope(req: Request, res: Response, scope: AdminScopeLevel, dealer: any): boolean {
  if (!dealer) {
    res.status(404).json({ error: 'Dealer account not found.' });
    return false;
  }
  const actor = req.auth!;
  if (scope === 'company_admin' && dealer.company_id !== actor.companyId) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'CROSS_COMPANY_DEALER_GOVERNANCE_BLOCKED',
      userId: actor.userId,
      identifier: actor.email,
      companyId: actor.companyId,
      details: `Company Admin ${actor.email} attempted governance on dealer ${dealer.dealer_code} (company ${dealer.company_id}).`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Scope Denied: Dealer belongs to a different company.' });
    return false;
  }
  if (scope === 'country_manager' && dealer.country_id !== actor.country) {
    res.status(403).json({ error: 'Scope Denied: Dealer belongs to a different country region.' });
    return false;
  }
  if (scope === 'branch_manager' && dealer.branch_id !== actor.branchId) {
    res.status(403).json({ error: 'Scope Denied: Dealer is not assigned to your branch.' });
    return false;
  }
  return true;
}

export function createAdminDealersRouter(options: ScopeOptions) {
  const router = express.Router();
  for (const mw of options.middlewares) {
    router.use(mw);
  }
  const { scope } = options;

  // =========================================================================
  // 1. LIST DEALER ACCOUNTS + INVENTORY + BOOKINGS + COMMISSIONS + DOCS
  // =========================================================================
  router.get('/', (req: Request, res: Response) => {
    const actor = req.auth!;
    const params: any[] = [];
    let whereClause = 'WHERE 1=1';

    if (scope === 'company_admin' && actor.companyId) {
      whereClause += ' AND da.company_id = ?';
      params.push(actor.companyId);
    } else if (scope === 'country_manager') {
      whereClause += ' AND da.country_id = ?';
      params.push(actor.country);
    } else if (scope === 'branch_manager' && actor.branchId) {
      whereClause += ' AND da.branch_id = ?';
      params.push(actor.branchId);
    }

    const dealers = sqlite
      .prepare(`
        SELECT da.id, da.dealer_code, da.dealership_id, da.company_id, da.country_id, da.branch_id,
               da.business_name, da.owner_contact_name, da.username, da.email, da.mobile,
               da.category, da.verification_status, da.status, da.email_verified,
               da.commission_rate_pct, da.authorized_by, da.approved_by, da.approved_at,
               da.rejected_reason, da.last_login_at, da.created_at, da.updated_at,
               dp.business_address, dp.city, dp.tax_id_ntn, dp.registration_no, dp.website,
               dp.bank_name, dp.bank_account_title, dp.bank_iban_masked,
               dp.pending_changes_json, dp.pending_change_status,
               c.name as company_name, b.name as branch_name, co.name as country_name,
               asgn.assigned_manager_name
        FROM dealer_accounts da
        LEFT JOIN dealer_profiles dp ON dp.dealer_id = da.id
        LEFT JOIN companies c ON c.id = da.company_id
        LEFT JOIN branches b ON b.id = da.branch_id
        LEFT JOIN countries co ON co.id = da.country_id
        LEFT JOIN dealer_assignments asgn ON asgn.dealer_id = da.id AND asgn.status = 'Active'
        ${whereClause}
        ORDER BY da.created_at DESC
      `)
      .all(...params)
      .map((d: any) => {
        const inv = sqlite
          .prepare('SELECT COUNT(*) as total, SUM(CASE WHEN availability_status = \'Available\' THEN 1 ELSE 0 END) as available FROM dealer_vehicle_inventory WHERE dealer_id = ?')
          .get(d.id) as any;
        const bk = sqlite
          .prepare('SELECT COUNT(*) as total, SUM(CASE WHEN booking_status = \'Pending Approval\' THEN 1 ELSE 0 END) as pending FROM dealer_bookings WHERE dealer_id = ?')
          .get(d.id) as any;
        const sales = sqlite
          .prepare('SELECT COUNT(*) as count, COALESCE(SUM(sale_amount_pkr), 0) as volume FROM dealer_sales WHERE dealer_id = ?')
          .get(d.id) as any;
        const comm = sqlite
          .prepare(`
            SELECT
              COALESCE(SUM(CASE WHEN status = 'Pending' THEN commission_amount_pkr ELSE 0 END), 0) as pendingPkr,
              COALESCE(SUM(CASE WHEN status = 'Approved' THEN commission_amount_pkr ELSE 0 END), 0) as approvedPkr,
              COALESCE(SUM(CASE WHEN status = 'Paid' THEN commission_amount_pkr ELSE 0 END), 0) as paidPkr
            FROM dealer_commissions WHERE dealer_id = ?
          `)
          .get(d.id) as any;

        let pendingChanges: Record<string, unknown> | null = null;
        if (d.pending_changes_json) {
          try {
            pendingChanges = JSON.parse(d.pending_changes_json);
          } catch {
            pendingChanges = null;
          }
        }

        return {
          ...d,
          emailVerified: Boolean(d.email_verified),
          permissions: resolveDealerPermissions(d.id),
          pendingChanges,
          metrics: {
            assignedVehicles: inv?.total || 0,
            availableVehicles: inv?.available || 0,
            totalBookings: bk?.total || 0,
            pendingBookings: bk?.pending || 0,
            completedSales: sales?.count || 0,
            salesVolumePkr: sales?.volume || 0,
            pendingCommissionPkr: comm?.pendingPkr || 0,
            approvedCommissionPkr: comm?.approvedPkr || 0,
            paidCommissionPkr: comm?.paidPkr || 0,
          },
        };
      });

    const dealerIds = dealers.map((d) => d.id);
    let bookings: any[] = [];
    let commissions: any[] = [];
    let documents: any[] = [];
    let activityLogs: any[] = [];
    let inventory: any[] = [];

    if (dealerIds.length > 0) {
      const ph = dealerIds.map(() => '?').join(',');
      bookings = sqlite
        .prepare(`
          SELECT b.*, da.business_name as dealer_name, da.dealer_code, c.full_name as customer_name, c.phone as customer_phone
          FROM dealer_bookings b
          LEFT JOIN dealer_accounts da ON da.id = b.dealer_id
          LEFT JOIN dealer_customers c ON c.id = b.customer_id
          WHERE b.dealer_id IN (${ph})
          ORDER BY b.created_at DESC LIMIT 80
        `)
        .all(...dealerIds);

      commissions = sqlite
        .prepare(`
          SELECT dc.*, da.business_name as dealer_name, da.dealer_code, ds.sale_ref, ds.vehicle_model
          FROM dealer_commissions dc
          LEFT JOIN dealer_accounts da ON da.id = dc.dealer_id
          LEFT JOIN dealer_sales ds ON ds.id = dc.sale_id
          WHERE dc.dealer_id IN (${ph})
          ORDER BY dc.created_at DESC LIMIT 80
        `)
        .all(...dealerIds);

      documents = sqlite
        .prepare(`
          SELECT dd.*, da.business_name as dealer_name, da.dealer_code
          FROM dealer_documents dd
          LEFT JOIN dealer_accounts da ON da.id = dd.dealer_id
          WHERE dd.dealer_id IN (${ph})
          ORDER BY dd.created_at DESC LIMIT 80
        `)
        .all(...dealerIds);

      activityLogs = sqlite
        .prepare(`
          SELECT dal.*, da.business_name as dealer_name, da.dealer_code
          FROM dealer_activity_logs dal
          LEFT JOIN dealer_accounts da ON da.id = dal.dealer_id
          WHERE dal.dealer_id IN (${ph})
          ORDER BY dal.created_at DESC LIMIT 100
        `)
        .all(...dealerIds);

      inventory = sqlite
        .prepare(`
          SELECT inv.*, da.business_name as dealer_name, da.dealer_code
          FROM dealer_vehicle_inventory inv
          LEFT JOIN dealer_accounts da ON da.id = inv.dealer_id
          WHERE inv.dealer_id IN (${ph})
          ORDER BY inv.created_at DESC LIMIT 120
        `)
        .all(...dealerIds);
    }

    res.json({
      dealers,
      bookings,
      commissions,
      documents,
      inventory,
      activityLogs,
      canonicalPermissions: [...CANONICAL_DEALER_PERMISSIONS],
    });
  });

  // =========================================================================
  // 2. ADMIN CREATE DEALER ACCOUNT (Pre-verified or Pending, with Unique ID & 2FA)
  // =========================================================================
  router.post('/', (req: Request, res: Response) => {
    const actor = req.auth!;
    const body = req.body || {};

    const businessName = String(body.businessName || '').trim();
    const ownerContactName = String(body.ownerContactName || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const mobile = String(body.mobile || '').trim();
    const password = String(body.password || '');
    const companyId =
      scope === 'company_admin' || scope === 'branch_manager'
        ? actor.companyId!
        : String(body.companyId || actor.companyId || 'comp_byd_pk').trim();
    const countryId =
      scope === 'country_manager' || scope === 'branch_manager'
        ? actor.country
        : String(body.countryId || actor.country || 'PK').trim().toUpperCase();
    const branchId =
      scope === 'branch_manager'
        ? actor.branchId || null
        : body.branchId
        ? String(body.branchId).trim()
        : null;
    const city = String(body.city || actor.city || 'Karachi').trim();
    const businessAddress = String(body.businessAddress || '').trim();
    const category = String(body.category || '3S Flagship Centre').trim();
    const commissionRatePct = Math.min(20, Math.max(0.5, Number(body.commissionRatePct ?? 4.5)));
    const permissions = sanitizeDealerPermissions(body.permissions);

    if (!businessName || !ownerContactName || !email || !mobile || !password) {
      res.status(400).json({ error: 'Business name, owner/contact name, email, mobile, and password are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const compRow = sqlite.prepare("SELECT id, name, status FROM companies WHERE id = ? AND status = 'Approved'").get(companyId) as any;
    if (!compRow) {
      res.status(400).json({ error: 'Target company must exist and be Approved.' });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const dealerId = `dlr_${generateSecureToken(6)}`;
    const dealerCode = body.dealerCode
      ? String(body.dealerCode).trim().toUpperCase()
      : `DLR-${countryId.slice(0, 2)}-${city.slice(0, 3).toUpperCase()}-${generateNumericOtp(3)}`;
    const codeConflict = sqlite.prepare('SELECT id FROM dealer_accounts WHERE dealer_code = ?').get(dealerCode);
    if (codeConflict) {
      res.status(409).json({ error: `Dealer ID "${dealerCode}" already exists.` });
      return;
    }

    const dealershipId = `dl_${generateSecureToken(6)}`;
    const username = `${email.split('@')[0].replace(/[^a-z0-9._-]/g, '')}_${generateNumericOtp(3)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () => `${generateNumericOtp(4)}-${generateNumericOtp(4)}`);
    const hashedRecovery = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();
    const approveImmediately = body.approveImmediately !== false && scope !== 'branch_manager';

    // Sync dealership directory row
    sqlite
      .prepare(`
        INSERT INTO dealerships (
          id, company_id, branch_id, name, code, country, city, address, manager_name,
          phone, email, facility_type, status, active_techs, service_bays,
          monthly_target_units, achieved_units, monthly_revenue_pkr, rating, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 6, 4, 25, 0, 0, 4.8, ?)
      `)
      .run(
        dealershipId,
        compRow.id,
        branchId,
        businessName,
        dealerCode,
        countryId,
        city,
        businessAddress || `${city} Commercial EV Zone`,
        ownerContactName,
        mobile,
        email,
        category === '2S Service Facility' || category === 'Retail Experience Studio' ? category : '3S Flagship Centre',
        approveImmediately ? 'Approved' : 'Pending Approval',
        now
      );

    sqlite
      .prepare(`
        INSERT INTO dealer_accounts (
          id, dealer_code, dealership_id, company_id, country_id, branch_id,
          business_name, owner_contact_name, username, email, mobile, password_hash,
          category, verification_status, status, email_verified, two_factor_enabled,
          two_factor_secret, recovery_codes_json, commission_rate_pct, authorized_by,
          approved_by, approved_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        dealerId,
        dealerCode,
        dealershipId,
        compRow.id,
        countryId,
        branchId,
        businessName,
        ownerContactName,
        username,
        email,
        mobile,
        hashPassword(password),
        category,
        approveImmediately ? 'Verified' : 'Pending Approval',
        approveImmediately ? 'Active' : 'Pending Verification',
        approveImmediately ? 1 : 0,
        totpSecret,
        JSON.stringify(hashedRecovery),
        commissionRatePct,
        actor.fullName,
        approveImmediately ? actor.fullName : null,
        approveImmediately ? now : null,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO dealer_profiles (
          id, dealer_id, business_address, city, country_id, tax_id_ntn, registration_no,
          website, bank_name, bank_account_title, bank_iban_masked,
          pending_change_status, notes, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, 'None', ?, ?)
      `)
      .run(
        `dpf_${generateSecureToken(6)}`,
        dealerId,
        businessAddress,
        city,
        countryId,
        String(body.taxIdNtn || ''),
        String(body.registrationNo || ''),
        String(body.bankName || ''),
        String(body.bankAccountTitle || ''),
        String(body.bankIbanMasked || ''),
        `Provisioned by ${actor.fullName} (${actor.role}).`,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO dealer_permissions (id, dealer_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?)
      `)
      .run(`dpm_${generateSecureToken(6)}`, dealerId, JSON.stringify(permissions), actor.fullName, now);

    sqlite
      .prepare(`
        INSERT INTO dealer_assignments (
          id, dealer_id, company_id, country_id, branch_id, assigned_manager_id,
          assigned_manager_name, status, assigned_by, effective_from, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `dasg_${generateSecureToken(6)}`,
        dealerId,
        compRow.id,
        countryId,
        branchId,
        actor.userId,
        actor.fullName,
        actor.fullName,
        now,
        'Initial dealer network assignment',
        now,
        now
      );

    logDealerActivity({
      dealerId,
      companyId: compRow.id,
      countryId,
      branchId,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'DEALER_ACCOUNT_CREATED',
      module: 'Dealer Governance',
      targetId: dealerCode,
      details: `Created dealer "${businessName}" (${dealerCode}); Verification=${approveImmediately ? 'Verified' : 'Pending Approval'}.`,
      ipAddress: getClientIp(req),
    });
    logAdminScopedAction(req, scope, 'DEALER_ACCOUNT_CREATED', dealerCode, `Provisioned ${businessName} (${email}).`);

    res.status(201).json({
      success: true,
      dealer: {
        id: dealerId,
        dealerCode,
        dealershipId,
        businessName,
        email,
        verificationStatus: approveImmediately ? 'Verified' : 'Pending Approval',
        status: approveImmediately ? 'Active' : 'Pending Verification',
        permissions,
      },
      twoFactorProvisioned: {
        totpSecret,
        recoveryCodes,
      },
    });
  });

  // =========================================================================
  // 3. APPROVE / REJECT / SUSPEND / REACTIVATE DEALER ACCOUNT
  // =========================================================================
  router.patch('/:id/decision', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const decision = String(req.body?.decision || '').trim().toLowerCase();
    const reason = String(req.body?.reason || '').trim();
    const now = nowIso();

    if (!['approve', 'reject', 'suspend', 'reactivate'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be "approve", "reject", "suspend", or "reactivate".' });
      return;
    }

    if (decision === 'approve') {
      let dealershipId = dealer.dealership_id;
      if (!dealershipId) {
        dealershipId = `dl_${generateSecureToken(6)}`;
        const prof = sqlite.prepare('SELECT city, business_address FROM dealer_profiles WHERE dealer_id = ?').get(dealer.id) as any;
        sqlite
          .prepare(`
            INSERT INTO dealerships (
              id, company_id, branch_id, name, code, country, city, address, manager_name,
              phone, email, facility_type, status, active_techs, service_bays,
              monthly_target_units, achieved_units, monthly_revenue_pkr, rating, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', 4, 3, 20, 0, 0, 4.7, ?)
          `)
          .run(
            dealershipId,
            dealer.company_id,
            dealer.branch_id,
            dealer.business_name,
            dealer.dealer_code,
            dealer.country_id,
            prof?.city || 'Karachi',
            prof?.business_address || 'Authorized Showroom',
            dealer.owner_contact_name,
            dealer.mobile,
            dealer.email,
            dealer.category === '2S Service Facility' || dealer.category === 'Retail Experience Studio' ? dealer.category : '3S Flagship Centre',
            now
          );
      } else {
        sqlite.prepare("UPDATE dealerships SET status = 'Approved' WHERE id = ?").run(dealershipId);
      }

      const nextStatus = dealer.email_verified ? 'Active' : 'Pending Verification';
      sqlite
        .prepare(`
          UPDATE dealer_accounts
          SET verification_status = 'Verified', status = ?, dealership_id = ?,
              approved_by = ?, approved_at = ?, authorized_by = ?, rejected_reason = NULL, updated_at = ?
          WHERE id = ?
        `)
        .run(nextStatus, dealershipId, actor.fullName, now, actor.fullName, now, dealer.id);

      sqlite
        .prepare(`
          INSERT INTO dealer_notifications (
            id, dealer_id, company_id, country_id, branch_id, category, title, message,
            sender_name, sender_role, priority, is_read, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Announcement', ?, ?, ?, ?, 'High', 0, ?)
        `)
        .run(
          `dnt_${generateSecureToken(6)}`,
          dealer.id,
          dealer.company_id,
          dealer.country_id,
          dealer.branch_id,
          `Dealer Account Approved (${dealer.dealer_code})`,
          `Your dealership "${dealer.business_name}" has been verified and approved by ${actor.fullName}.`,
          actor.fullName,
          actor.role,
          now
        );

      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'DEALER_ACCOUNT_APPROVED',
        module: 'Dealer Governance',
        targetId: dealer.dealer_code,
        details: `Verified and approved by ${actor.fullName} (${actor.role}).`,
        ipAddress: getClientIp(req),
      });
    } else if (decision === 'reject') {
      sqlite
        .prepare("UPDATE dealer_accounts SET verification_status = 'Rejected', status = 'Rejected', rejected_reason = ?, updated_at = ? WHERE id = ?")
        .run(reason || 'Application rejected by authorized administrator.', now, dealer.id);
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'dealer'").run(dealer.id);
      if (dealer.dealership_id) {
        sqlite.prepare("UPDATE dealerships SET status = 'Rejected' WHERE id = ?").run(dealer.dealership_id);
      }
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'DEALER_ACCOUNT_REJECTED',
        module: 'Dealer Governance',
        targetId: dealer.dealer_code,
        details: reason || 'Application rejected.',
        ipAddress: getClientIp(req),
        status: 'WARNING',
      });
    } else if (decision === 'suspend') {
      sqlite
        .prepare("UPDATE dealer_accounts SET status = 'Suspended', rejected_reason = ?, updated_at = ? WHERE id = ?")
        .run(reason || 'Suspended by administrator', now, dealer.id);
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'dealer'").run(dealer.id);
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'DEALER_ACCOUNT_SUSPENDED',
        module: 'Dealer Governance',
        targetId: dealer.dealer_code,
        details: `${reason || 'Suspended'} — active sessions revoked.`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
    } else if (decision === 'reactivate') {
      const nextStatus = dealer.verification_status === 'Verified' && dealer.email_verified ? 'Active' : 'Pending Verification';
      sqlite
        .prepare('UPDATE dealer_accounts SET status = ?, rejected_reason = NULL, updated_at = ? WHERE id = ?')
        .run(nextStatus, now, dealer.id);
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'DEALER_ACCOUNT_REACTIVATED',
        module: 'Dealer Governance',
        targetId: dealer.dealer_code,
        details: `Reactivated by ${actor.fullName}.`,
        ipAddress: getClientIp(req),
      });
    }

    logAdminScopedAction(req, scope, `DEALER_${decision.toUpperCase()}`, dealer.dealer_code, reason || `Executed ${decision} on ${dealer.business_name}.`);
    res.json({
      success: true,
      dealer: sqlite.prepare('SELECT id, dealer_code, business_name, verification_status, status, email_verified FROM dealer_accounts WHERE id = ?').get(dealer.id),
    });
  });

  // =========================================================================
  // 4. UPDATE DEALER PERMISSIONS & COMMISSION RATE / ASSIGNMENTS
  // =========================================================================
  router.patch('/:id/permissions', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const permissions = sanitizeDealerPermissions(req.body?.permissions);
    const now = nowIso();
    const existing = sqlite.prepare('SELECT id FROM dealer_permissions WHERE dealer_id = ?').get(dealer.id);
    if (existing) {
      sqlite
        .prepare('UPDATE dealer_permissions SET permissions_json = ?, updated_by = ?, updated_at = ? WHERE dealer_id = ?')
        .run(JSON.stringify(permissions), actor.fullName, now, dealer.id);
    } else {
      sqlite
        .prepare('INSERT INTO dealer_permissions (id, dealer_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?, ?)')
        .run(`dpm_${generateSecureToken(6)}`, dealer.id, JSON.stringify(permissions), actor.fullName, now);
    }

    if (req.body?.commissionRatePct !== undefined && ['founder', 'super_admin', 'company_admin', 'country_manager'].includes(scope)) {
      const rate = Math.min(20, Math.max(0.5, Number(req.body.commissionRatePct)));
      sqlite.prepare('UPDATE dealer_accounts SET commission_rate_pct = ?, updated_at = ? WHERE id = ?').run(rate, now, dealer.id);
    }

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'DEALER_PERMISSIONS_UPDATED',
      module: 'Dealer Governance',
      targetId: dealer.dealer_code,
      details: `Permissions set (${permissions.length} flags).`,
      ipAddress: getClientIp(req),
    });
    logAdminScopedAction(req, scope, 'DEALER_PERMISSIONS_UPDATED', dealer.dealer_code, `Updated permissions (${permissions.length} items).`);

    res.json({ success: true, permissions });
  });

  router.patch('/:id/assignment', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const companyId = req.body?.companyId ? String(req.body.companyId).trim() : dealer.company_id;
    const countryId = req.body?.countryId ? String(req.body.countryId).trim().toUpperCase() : dealer.country_id;
    const branchId = req.body?.branchId !== undefined ? (req.body.branchId ? String(req.body.branchId).trim() : null) : dealer.branch_id;
    const now = nowIso();

    sqlite
      .prepare('UPDATE dealer_accounts SET company_id = ?, country_id = ?, branch_id = ?, updated_at = ? WHERE id = ?')
      .run(companyId, countryId, branchId, now, dealer.id);

    sqlite.prepare("UPDATE dealer_assignments SET status = 'Reassigned', updated_at = ? WHERE dealer_id = ? AND status = 'Active'").run(now, dealer.id);
    sqlite
      .prepare(`
        INSERT INTO dealer_assignments (
          id, dealer_id, company_id, country_id, branch_id, assigned_manager_id,
          assigned_manager_name, status, assigned_by, effective_from, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `dasg_${generateSecureToken(6)}`,
        dealer.id,
        companyId,
        countryId,
        branchId,
        actor.userId,
        String(req.body?.assignedManagerName || actor.fullName),
        actor.fullName,
        now,
        String(req.body?.notes || 'Admin updated dealer organizational assignment'),
        now,
        now
      );

    logDealerActivity({
      dealerId: dealer.id,
      companyId,
      countryId,
      branchId,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'DEALER_ASSIGNMENT_UPDATED',
      module: 'Dealer Governance',
      targetId: dealer.dealer_code,
      details: `Assigned Company=${companyId}, Country=${countryId}, Branch=${branchId || 'HQ'}.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  // =========================================================================
  // 5. ASSIGN VEHICLE INVENTORY TO DEALER
  // =========================================================================
  router.post('/:id/vehicles', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const body = req.body || {};
    const model = String(body.model || 'BYD Sealion 6').trim();
    const variant = String(body.variant || 'Dynamic PHEV').trim();
    const modelYear = Number(body.modelYear || 2026);
    const exteriorColor = String(body.exteriorColor || 'Arctic White').trim();
    const interiorColor = String(body.interiorColor || 'Eclipse Black Vegan Leather').trim();
    const vin = String(body.vin || `LC0CE4CC0R0${generateNumericOtp(6)}`).trim().toUpperCase();
    const approvedPricePkr = Number(body.approvedSellingPricePkr || 14990000);
    const stockNumber = String(body.stockNumber || `STK-${dealer.country_id}-${generateNumericOtp(4)}`).trim().toUpperCase();
    const imageUrl = String(body.imageUrl || 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=900&q=80');
    const now = nowIso();
    const invId = `dinv_${generateSecureToken(6)}`;

    sqlite
      .prepare(`
        INSERT INTO dealer_vehicle_inventory (
          id, dealer_id, company_id, country_id, branch_id, vehicle_id, stock_number,
          model, variant, model_year, exterior_color, interior_color, vin, image_url,
          availability_status, approved_selling_price_pkr, booking_status, delivery_status,
          assigned_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Available', ?, 'Unbooked', 'At Showroom', ?, ?, ?)
      `)
      .run(
        invId,
        dealer.id,
        dealer.company_id,
        dealer.country_id,
        dealer.branch_id,
        body.vehicleId || null,
        stockNumber,
        model,
        variant,
        modelYear,
        exteriorColor,
        interiorColor,
        vin,
        imageUrl,
        approvedPricePkr,
        actor.fullName,
        now,
        now
      );

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'VEHICLE_ASSIGNED_TO_DEALER',
      module: 'Dealer Inventory',
      targetId: stockNumber,
      details: `Assigned ${model} ${variant} (${exteriorColor}) at official price PKR ${approvedPricePkr.toLocaleString()}.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      vehicle: sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(invId),
    });
  });

  // =========================================================================
  // 6. APPROVE/REJECT SENSITIVE PROFILE & BANK CHANGE REQUESTS
  // =========================================================================
  router.patch('/:id/profile-change', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const profile = sqlite.prepare('SELECT * FROM dealer_profiles WHERE dealer_id = ?').get(dealer.id) as any;
    if (!profile || profile.pending_change_status !== 'Pending Admin Approval' || !profile.pending_changes_json) {
      res.status(400).json({ error: 'No pending sensitive profile change request found for this dealer.' });
      return;
    }

    const decision = String(req.body?.decision || '').trim().toLowerCase();
    const now = nowIso();
    const changes = JSON.parse(profile.pending_changes_json) as Record<string, string>;

    if (decision === 'approve') {
      sqlite
        .prepare(`
          UPDATE dealer_profiles
          SET bank_name = ?, bank_account_title = ?, bank_iban_masked = ?,
              tax_id_ntn = ?, registration_no = ?,
              pending_changes_json = NULL, pending_change_status = 'Approved',
              pending_change_reviewed_by = ?, updated_at = ?
          WHERE dealer_id = ?
        `)
        .run(
          changes.bankName ?? profile.bank_name,
          changes.bankAccountTitle ?? profile.bank_account_title,
          changes.bankIbanMasked ?? profile.bank_iban_masked,
          changes.taxIdNtn ?? profile.tax_id_ntn,
          changes.registrationNo ?? profile.registration_no,
          actor.fullName,
          now,
          dealer.id
        );
      if (changes.category) {
        sqlite.prepare('UPDATE dealer_accounts SET category = ?, updated_at = ? WHERE id = ?').run(changes.category, now, dealer.id);
      }
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'SENSITIVE_PROFILE_CHANGES_APPROVED',
        module: 'Dealer Profile',
        targetId: dealer.dealer_code,
        details: `Approved pending updates: ${Object.keys(changes).join(', ')}.`,
        ipAddress: getClientIp(req),
      });
    } else if (decision === 'reject') {
      sqlite
        .prepare("UPDATE dealer_profiles SET pending_changes_json = NULL, pending_change_status = 'Rejected', pending_change_reviewed_by = ?, updated_at = ? WHERE dealer_id = ?")
        .run(actor.fullName, now, dealer.id);
    } else {
      res.status(400).json({ error: 'Decision must be "approve" or "reject".' });
      return;
    }

    res.json({ success: true });
  });

  // =========================================================================
  // 7. DOCUMENT VERIFICATION & DOWNLOAD
  // =========================================================================
  router.patch('/documents/:docId/verify', (req: Request, res: Response) => {
    const actor = req.auth!;
    const doc = sqlite.prepare('SELECT * FROM dealer_documents WHERE id = ?').get(req.params.docId) as any;
    if (!doc) {
      res.status(404).json({ error: 'Dealer document not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(doc.dealer_id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const status = req.body?.status === 'Rejected' ? 'Rejected' : 'Verified';
    const notes = String(req.body?.notes || '').trim();
    const now = nowIso();
    sqlite
      .prepare('UPDATE dealer_documents SET verification_status = ?, reviewed_by = ?, review_notes = ?, updated_at = ? WHERE id = ?')
      .run(status, actor.fullName, notes || null, now, doc.id);

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: `DEALER_DOC_${status.toUpperCase()}`,
      module: 'Dealer Documents',
      targetId: doc.id,
      details: `${doc.title}: ${status}${notes ? ` (${notes})` : ''}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, verificationStatus: status });
  });

  router.get('/documents/:docId/download', (req: Request, res: Response) => {
    const doc = sqlite.prepare('SELECT * FROM dealer_documents WHERE id = ?').get(req.params.docId) as any;
    if (!doc) {
      res.status(404).json({ error: 'Dealer document not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(doc.dealer_id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const diskPath = path.join(PRIVATE_DEALER_DOCS_DIR, path.basename(doc.storage_key));
    if (!fs.existsSync(diskPath)) {
      res.status(404).json({ error: 'Document file missing on disk.' });
      return;
    }
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(doc.original_filename || 'document')}"`);
    fs.createReadStream(diskPath).pipe(res);
  });

  // =========================================================================
  // 8. BOOKING APPROVAL -> VERIFIED SALE & COMMISSION AUTO-GENERATION
  // =========================================================================
  router.patch('/bookings/:bookingId/review', (req: Request, res: Response) => {
    const actor = req.auth!;
    const bk = sqlite.prepare('SELECT * FROM dealer_bookings WHERE id = ?').get(req.params.bookingId) as any;
    if (!bk) {
      res.status(404).json({ error: 'Dealer booking not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(bk.dealer_id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const decision = String(req.body?.decision || '').trim().toLowerCase();
    const verifyPayment = Boolean(req.body?.verifyPayment ?? true);
    const paymentRef = String(req.body?.paymentProviderRef || `1LINK-${generateNumericOtp(6)}`).trim();
    const now = nowIso();

    if (decision === 'reject') {
      sqlite
        .prepare("UPDATE dealer_bookings SET booking_status = 'Rejected', reviewed_by = ?, reviewed_at = ?, updated_at = ? WHERE id = ?")
        .run(actor.fullName, now, now, bk.id);
      sqlite
        .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Available', booking_status = 'Unbooked', updated_at = ? WHERE id = ?")
        .run(now, bk.inventory_id);
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: actor.userId,
        actorName: actor.fullName,
        actorRole: actor.role,
        action: 'DEALER_BOOKING_REJECTED',
        module: 'Dealer Bookings',
        targetId: bk.booking_ref,
        details: 'Booking rejected by administrator; inventory restored to Available.',
        ipAddress: getClientIp(req),
        status: 'WARNING',
      });
      res.json({ success: true, bookingStatus: 'Rejected' });
      return;
    }

    if (decision !== 'approve') {
      res.status(400).json({ error: 'Decision must be "approve" or "reject".' });
      return;
    }

    const inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(bk.inventory_id) as any;
    const cust = sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ?').get(bk.customer_id) as any;

    if (!verifyPayment) {
      sqlite
        .prepare("UPDATE dealer_bookings SET booking_status = 'Approved', payment_status = 'Deposit Verified', reviewed_by = ?, reviewed_at = ?, updated_at = ? WHERE id = ?")
        .run(actor.fullName, now, now, bk.id);
      sqlite
        .prepare("UPDATE dealer_vehicle_inventory SET booking_status = 'Booking Approved', updated_at = ? WHERE id = ?")
        .run(now, bk.inventory_id);
      res.json({ success: true, bookingStatus: 'Approved' });
      return;
    }

    // Verified Settlement -> Create Official Sale + Receipt PDF + Auto-Calculate Commission
    const saleId = `dsale_${generateSecureToken(6)}`;
    const saleRef = `SLS-${new Date().getFullYear()}-${generateNumericOtp(4)}`;
    const saleAmount = Number(bk.agreed_price_pkr || inv?.approved_selling_price_pkr || 0);
    const ratePct = Number(dealer.commission_rate_pct || 4.5);
    const commissionAmount = Math.round((saleAmount * ratePct) / 100);

    const receiptPdf = buildSimplePdfBuffer(`BYD 360 Official Sale Receipt - ${saleRef}`, [
      'BYD PAKISTAN 360 — VERIFIED VEHICLE SALE RECEIPT',
      `Founder & CEO: Intekhab Alam`,
      `Sale Reference: ${saleRef} | Booking Ref: ${bk.booking_ref}`,
      `Dealer: ${dealer.business_name} (${dealer.dealer_code})`,
      `Customer: ${cust?.full_name || 'Verified Customer'} (${cust?.phone || ''})`,
      `Vehicle: ${bk.vehicle_model} ${bk.variant} | VIN: ${inv?.vin || 'ASSIGNED'}`,
      `Amount Verified (PKR): ${saleAmount.toLocaleString()}`,
      `Payment Settlement Ref: ${paymentRef}`,
      `Verified By: ${actor.fullName} (${actor.role}) at ${now}`,
    ]);
    const receiptDoc = savePrivateDealerFile({
      buffer: receiptPdf,
      originalName: `${saleRef}-Verified-Receipt.pdf`,
      mimeType: 'application/pdf',
      dealerId: dealer.id,
      companyId: dealer.company_id,
      docType: 'Sale Receipt',
      title: `Verified Sale Receipt — ${saleRef}`,
      uploadedById: actor.userId,
      uploadedByRole: actor.role,
      verificationStatus: 'Verified',
      reviewedBy: actor.fullName,
    });

    sqlite
      .prepare(`
        INSERT INTO dealer_sales (
          id, sale_ref, booking_id, dealer_id, customer_id, inventory_id,
          company_id, country_id, branch_id, vehicle_model, vin, sale_amount_pkr,
          paid_amount_pkr, payment_status, payment_provider_ref, delivery_status,
          delivered_at, receipt_doc_id, verified_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Payment Verified', ?, 'Delivered', ?, ?, ?, ?, ?)
      `)
      .run(
        saleId,
        saleRef,
        bk.id,
        dealer.id,
        bk.customer_id,
        bk.inventory_id,
        dealer.company_id,
        dealer.country_id,
        dealer.branch_id,
        `${bk.vehicle_model} ${bk.variant}`,
        inv?.vin || 'ASSIGNED-VIN',
        saleAmount,
        saleAmount,
        paymentRef,
        now,
        receiptDoc.id,
        actor.fullName,
        now,
        now
      );

    sqlite
      .prepare("UPDATE dealer_bookings SET booking_status = 'Converted to Sale', payment_status = 'Fully Paid', delivery_status = 'Delivered', reviewed_by = ?, reviewed_at = ?, updated_at = ? WHERE id = ?")
      .run(actor.fullName, now, now, bk.id);

    sqlite
      .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Sold', booking_status = 'Completed', delivery_status = 'Delivered', updated_at = ? WHERE id = ?")
      .run(now, bk.inventory_id);

    const commId = `dcom_${generateSecureToken(6)}`;
    sqlite
      .prepare(`
        INSERT INTO dealer_commissions (
          id, dealer_id, sale_id, company_id, country_id, branch_id,
          sale_amount_pkr, commission_rate_pct, commission_amount_pkr, status,
          approved_by, approved_at, paid_at, payout_reference, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?, ?, NULL, NULL, ?, ?, ?)
      `)
      .run(
        commId,
        dealer.id,
        saleId,
        dealer.company_id,
        dealer.country_id,
        dealer.branch_id,
        saleAmount,
        ratePct,
        commissionAmount,
        actor.fullName,
        now,
        `Auto-calculated ${ratePct}% commission upon verified settlement (${paymentRef}).`,
        now,
        now
      );

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'BOOKING_APPROVED_AND_SALE_VERIFIED',
      module: 'Dealer Sales & Commissions',
      targetId: saleRef,
      details: `Booking ${bk.booking_ref} verified & converted to Sale ${saleRef}; Commission PKR ${commissionAmount.toLocaleString()} (${ratePct}%) Approved.`,
      ipAddress: getClientIp(req),
    });
    logAdminScopedAction(req, scope, 'DEALER_SALE_VERIFIED', saleRef, `Verified booking ${bk.booking_ref} for ${dealer.dealer_code}; commission approved.`);

    res.json({
      success: true,
      sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(saleId),
      commission: sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(commId),
    });
  });

  // =========================================================================
  // 9. APPROVE / MARK PAID DEALER COMMISSIONS
  // =========================================================================
  router.patch('/commissions/:commId', (req: Request, res: Response) => {
    const actor = req.auth!;
    const comm = sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(req.params.commId) as any;
    if (!comm) {
      res.status(404).json({ error: 'Commission record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(comm.dealer_id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const action = String(req.body?.action || '').trim().toLowerCase();
    const payoutRef = String(req.body?.payoutReference || `PAYOUT-BYD-${generateNumericOtp(5)}`).trim();
    const now = nowIso();

    if (action === 'approve') {
      sqlite
        .prepare("UPDATE dealer_commissions SET status = 'Approved', approved_by = ?, approved_at = ?, updated_at = ? WHERE id = ?")
        .run(actor.fullName, now, now, comm.id);
    } else if (action === 'pay') {
      sqlite
        .prepare("UPDATE dealer_commissions SET status = 'Paid', approved_by = COALESCE(approved_by, ?), approved_at = COALESCE(approved_at, ?), paid_at = ?, payout_reference = ?, updated_at = ? WHERE id = ?")
        .run(actor.fullName, now, now, payoutRef, now, comm.id);
    } else {
      res.status(400).json({ error: 'Commission action must be "approve" or "pay".' });
      return;
    }

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: action === 'pay' ? 'COMMISSION_PAID' : 'COMMISSION_APPROVED',
      module: 'Dealer Commissions',
      targetId: comm.id,
      details: `${action === 'pay' ? `Paid (${payoutRef})` : 'Approved'} PKR ${Number(comm.commission_amount_pkr).toLocaleString()} by ${actor.fullName}.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      commission: sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(comm.id),
    });
  });

  // =========================================================================
  // 10. SEND OFFICIAL DEALER NOTIFICATION / ANNOUNCEMENT
  // =========================================================================
  router.post('/:id/notify', (req: Request, res: Response) => {
    const actor = req.auth!;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerInAdminScope(req, res, scope, dealer)) return;

    const title = String(req.body?.title || '').trim();
    const message = String(req.body?.message || '').trim();
    const category = String(req.body?.category || 'Announcement').trim();
    const priority = ['Low', 'Normal', 'High'].includes(String(req.body?.priority)) ? String(req.body.priority) : 'Normal';
    if (!title || !message) {
      res.status(400).json({ error: 'Notification title and message are required.' });
      return;
    }

    const notifId = `dnt_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO dealer_notifications (
          id, dealer_id, company_id, country_id, branch_id, category, title, message,
          sender_name, sender_role, priority, is_read, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
      `)
      .run(notifId, dealer.id, dealer.company_id, dealer.country_id, dealer.branch_id, category, title, message, actor.fullName, actor.role, priority, now);

    res.status(201).json({ success: true, id: notifId });
  });

  return router;
}
