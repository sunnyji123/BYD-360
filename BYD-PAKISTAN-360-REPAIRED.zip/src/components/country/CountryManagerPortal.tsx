import React, { useState, useEffect, useCallback } from 'react';
import {
  Globe,
  Shield,
  Lock,
  KeyRound,
  Mail,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  LogOut,
  RefreshCw,
  Building2,
  Users,
  GitBranch,
  Store,
  Car,
  UserCheck,
  DollarSign,
  FileSpreadsheet,
  Sparkles,
  Plus,
  Check,
  XCircle,
  ArrowRightLeft,
  Monitor,
  History,
  Trash2,
  Send,
  Printer,
  Download,
  FileText,
  ShieldAlert,
  Bell,
  ArrowUpRight,
  MapPin,
  Briefcase,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AdminDealerGovernancePanel } from '../dealer/AdminDealerGovernancePanel';
import { AdminCustomerGovernancePanel } from '../customer/AdminCustomerGovernancePanel';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { AdminVerificationApprovalPanel } from '../admin/AdminVerificationApprovalPanel';
import { EmployeeManagementHub } from '../employee/EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type CountryPortalTab =
  | 'overview'
  | 'country'
  | 'companies'
  | 'branches'
  | 'dealerships'
  | 'dealership-hub'
  | 'employees'
  | 'employee-hub'
  | 'vehicles'
  | 'customers'
  | 'sales'
  | 'reports'
  | 'security';

type AuthStep = 'login' | 'verify-email' | '2fa' | 'forgot-password';

const SAFE_JOB_POSITIONS = [
  'Head Office Staff',
  'Regional Manager',
  'Company Management',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Service Manager',
  'Service Advisor',
  'Workshop Technician',
  'Technical Support',
  'Warranty Manager',
  'Inventory Manager',
  'Finance Manager',
  'Customer Support Agent',
];

export const CountryManagerPortal: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, setActiveTab } = useApp();
  const isCountryManager = isAuthenticated && currentUser.subjectType === 'country_manager';

  // Portal Status & Auth Flow State
  const [statusLoading, setStatusLoading] = useState(true);
  const [portalStatus, setPortalStatus] = useState<{
    hasCountryManagers: boolean;
    activeCountriesCount: number;
    twoFactorRequired: boolean;
    emailVerificationRequired: boolean;
    portalIsolated: boolean;
  } | null>(null);

  const [authStep, setAuthStep] = useState<AuthStep>('login');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [pendingEmail, setPendingEmail] = useState('');
  const [pendingCountryLabel, setPendingCountryLabel] = useState('');
  const [emailOtpCode, setEmailOtpCode] = useState('');
  const [devEmailOtpHint, setDevEmailOtpHint] = useState<string | null>(null);

  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [devLoginOtpHint, setDevLoginOtpHint] = useState<string | null>(null);
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);

  const [forgotEmail, setForgotEmail] = useState('');
  const [resetStage, setResetStage] = useState<'request' | 'confirm'>('request');
  const [resetToken, setResetToken] = useState('');
  const [resetOtpCode, setResetOtpCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [devResetHint, setDevResetHint] = useState<{ resetToken?: string; otpCode?: string } | null>(null);

  // Dashboard State
  const [cmTab, setCmTab] = useState<CountryPortalTab>('overview');
  const [banner, setBanner] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [loadingDash, setLoadingDash] = useState(false);

  const [dashboard, setDashboard] = useState<any>(null);
  const [aiBriefing, setAiBriefing] = useState<string | null>(null);
  const [aiBriefingLoading, setAiBriefingLoading] = useState(false);

  // Tab 2: Country Profile & Operations
  const [countryData, setCountryData] = useState<any>(null);
  const [countryForm, setCountryForm] = useState({
    headquartersCity: '',
    legalEntity: '',
    sector: '',
    regulator: '',
    emergencyHotline: '',
    evPolicySummary: '',
    departmentsText: '',
    operationsText: '',
  });
  const [newOffice, setNewOffice] = useState({ name: '', city: '', address: '', type: 'Regional Office', phone: '' });
  const [newDoc, setNewDoc] = useState({ title: '', category: 'Regulatory', refNo: '' });
  const [newContact, setNewContact] = useState({ role: '', name: '', email: '', phone: '' });

  // Tab 3: Companies
  const [companiesData, setCompaniesData] = useState<any>(null);
  const [editingCompany, setEditingCompany] = useState<any>(null);
  const [companyOpsForm, setCompanyOpsForm] = useState({
    phone: '',
    city: '',
    authorizedRep: '',
    operationalStatus: 'Active',
    performanceRating: 95,
    notes: '',
  });
  const [escTargetCompany, setEscTargetCompany] = useState<any>(null);
  const [escForm, setEscForm] = useState({ title: '', details: '' });

  // Tab 4: Branches
  const [branchesData, setBranchesData] = useState<any>(null);
  const [newBranch, setNewBranch] = useState({
    companyId: '',
    name: '',
    code: '',
    city: '',
    address: '',
    managerId: '',
    managerName: '',
    phone: '+92 ',
    email: '',
    monthlyTargetUnits: 25,
  });
  const [editingBranch, setEditingBranch] = useState<any>(null);
  const [branchEditForm, setBranchEditForm] = useState({
    managerId: '',
    managerName: '',
    monthlyTargetUnits: 25,
    phone: '',
    address: '',
    status: 'Active' as 'Active' | 'Inactive',
  });
  const [branchReport, setBranchReport] = useState<any>(null);

  // Tab 5: Dealerships
  const [dealerships, setDealerships] = useState<any[]>([]);
  const [editingDealer, setEditingDealer] = useState<any>(null);
  const [dealerEditForm, setDealerEditForm] = useState({
    managerName: '',
    phone: '',
    monthlyTargetUnits: 20,
    serviceBays: 6,
    activeTechs: 8,
  });
  const [commTargetDealer, setCommTargetDealer] = useState<any>(null);
  const [commForm, setCommForm] = useState({ subject: '', message: '' });

  // Tab 6: Employees
  const [employeesData, setEmployeesData] = useState<any>(null);
  const [editingEmp, setEditingEmp] = useState<any>(null);
  const [empEditForm, setEmpEditForm] = useState({
    department: '',
    jobPosition: '',
    performanceScore: 90,
    performanceNotes: '',
  });

  // Tab 7: Vehicles & Transfers
  const [vehiclesData, setVehiclesData] = useState<any>(null);
  const [transferModal, setTransferModal] = useState<{
    vehicle: any;
    targetBranchId: string;
    deliveryStatus: string;
  } | null>(null);

  // Tab 8: Customers & CRM
  const [customersData, setCustomersData] = useState<any>(null);
  const [piiRevealed, setPiiRevealed] = useState(false);
  const [editingCrm, setEditingCrm] = useState<any>(null);
  const [crmEditForm, setCrmEditForm] = useState({ status: 'In Progress', resolutionNotes: '' });

  // Tab 9: Sales & Finance
  const [salesFinance, setSalesFinance] = useState<any>(null);
  const [refundModal, setRefundModal] = useState<{
    invoice: any;
    mode: 'request' | 'direct';
    reason: string;
  } | null>(null);

  // Tab 10: Reports
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [reportData, setReportData] = useState<any>(null);
  const [exporting, setExporting] = useState(false);

  // Tab 11: Security, Sessions & Escalations
  const [auditData, setAuditData] = useState<any>(null);
  const [cmSessions, setCmSessions] = useState<any[]>([]);
  const [cmLoginHistory, setCmLoginHistory] = useState<any[]>([]);

  const notify = (text: string, type: 'ok' | 'err' = 'ok') => {
    setBanner({ text, type });
    setTimeout(() => setBanner(null), 5000);
  };

  const hasPerm = (perm: string) => (currentUser?.permissions || []).includes(perm);

  const loadPortalStatus = useCallback(async () => {
    setStatusLoading(true);
    try {
      const st = await api.getCountryManagerStatus();
      setPortalStatus(st);
    } catch (err: any) {
      setAuthError(err.message || 'Unable to verify Country Manager portal status.');
    } finally {
      setStatusLoading(false);
    }
  }, []);

  const loadOverview = useCallback(async () => {
    if (!isCountryManager) return;
    setLoadingDash(true);
    try {
      const d = await api.getCountryManagerDashboard();
      setDashboard(d);
    } catch (err: any) {
      notify(err.message || 'Failed to load Country Manager overview.', 'err');
    } finally {
      setLoadingDash(false);
    }
  }, [isCountryManager]);

  const loadTabData = useCallback(
    async (tab: CountryPortalTab) => {
      if (!isCountryManager) return;
      try {
        if (tab === 'overview') {
          await loadOverview();
        } else if (tab === 'country') {
          const res = await api.getCountryManagerCountry();
          setCountryData(res);
          const c = res.country || {};
          setCountryForm({
            headquartersCity: c.headquarters_city || '',
            legalEntity: c.legal_entity || '',
            sector: c.profile?.sector || '',
            regulator: c.profile?.regulator || '',
            emergencyHotline: c.profile?.emergencyHotline || '',
            evPolicySummary: c.profile?.evPolicySummary || '',
            departmentsText: (c.departments || []).join(', '),
            operationsText: (c.authorizedOperations || []).join(', '),
          });
        } else if (tab === 'companies') {
          const res = await api.getCountryManagerCompanies();
          setCompaniesData(res);
        } else if (tab === 'branches') {
          const res = await api.getCountryManagerBranches();
          setBranchesData(res);
          if (!newBranch.companyId && res.companies?.length) {
            setNewBranch((p) => ({
              ...p,
              companyId: res.companies[0].id,
              city: res.companies[0].city || '',
            }));
          }
        } else if (tab === 'dealerships') {
          const res = await api.getCountryManagerDealerships();
          setDealerships(res.dealerships || []);
        } else if (tab === 'employees') {
          const res = await api.getCountryManagerEmployees();
          setEmployeesData(res);
        } else if (tab === 'vehicles') {
          const res = await api.getCountryManagerVehicles();
          setVehiclesData(res);
        } else if (tab === 'customers') {
          const res = await api.getCountryManagerCustomers(piiRevealed);
          setCustomersData(res);
        } else if (tab === 'sales') {
          const res = await api.getCountryManagerSalesFinance();
          setSalesFinance(res);
        } else if (tab === 'reports') {
          const res = await api.getCountryManagerReports(reportPeriod);
          setReportData(res);
        } else if (tab === 'security') {
          const [aud, sess, hist] = await Promise.all([
            api.getCountryManagerAuditLogs(),
            api.getCountryManagerSessions(),
            api.getCountryManagerLoginHistory(),
          ]);
          setAuditData(aud);
          setCmSessions(sess.sessions || []);
          setCmLoginHistory(hist.history || []);
        }
      } catch (err: any) {
        notify(err.message || `Failed to load ${tab} module.`, 'err');
      }
    },
    [isCountryManager, loadOverview, piiRevealed, reportPeriod, newBranch.companyId]
  );

  useEffect(() => {
    loadPortalStatus();
  }, [loadPortalStatus]);

  useEffect(() => {
    if (isCountryManager) {
      loadOverview();
      loadTabData(cmTab);
    }
  }, [isCountryManager, cmTab, loadTabData, loadOverview]);

  // ----------------- AUTH HANDLERS -----------------
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.countryManagerLogin({ identifier: identifier.trim(), password });
      const label = [res.flagEmoji, res.countryName || res.countryId, res.managerCode].filter(Boolean).join(' • ');
      setPendingCountryLabel(label);
      if (res.requiresEmailVerification) {
        setPendingEmail(res.email);
        setDevEmailOtpHint(res.verificationOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('verify-email');
      } else if (res.requires2FA && res.challengeToken) {
        setPendingEmail(res.email);
        setChallengeToken(res.challengeToken);
        setSuspiciousAlert(Boolean(res.suspiciousIpDetected));
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('2fa');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Country Manager authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerifyEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.countryManagerVerifyEmail({ email: pendingEmail, code: emailOtpCode.trim() });
      setEmailOtpCode('');
      setPendingCountryLabel([res.flagEmoji, res.countryName, res.managerCode].filter(Boolean).join(' • '));
      if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setAuthSuccess(res.message);
        setAuthStep('2fa');
      } else {
        setAuthSuccess(res.message);
        setAuthStep('login');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Email verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerify2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.countryManagerVerify2FA({ challengeToken, code: twoFactorCode.trim() });
      setPassword('');
      setTwoFactorCode('');
      setChallengeToken('');
      loginUser(res.user);
    } catch (err: any) {
      setAuthError(err.message || '2FA verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.countryManagerForgotPassword(forgotEmail.trim());
      setAuthSuccess(res.message);
      if (res.resetOutbox) {
        setDevResetHint({ resetToken: res.resetOutbox.resetToken, otpCode: res.resetOutbox.otpCode });
        setResetToken(res.resetOutbox.resetToken);
      }
      setResetStage('confirm');
    } catch (err: any) {
      setAuthError(err.message || 'Password reset request failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleResetConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.countryManagerResetPassword({
        token: resetToken.trim() || undefined,
        email: forgotEmail.trim() || undefined,
        otpCode: resetOtpCode.trim() || undefined,
        newPassword: resetNewPassword,
      });
      setAuthSuccess(res.message);
      setResetNewPassword('');
      setResetOtpCode('');
      setResetStage('request');
      setAuthStep('login');
    } catch (err: any) {
      setAuthError(err.message || 'Password reset failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  // ----------------- ISOLATED GATEWAY IF NOT LOGGED IN AS COUNTRY MANAGER -----------------
  if (!isCountryManager) {
    if (isAuthenticated) {
      return (
        <div className="max-w-3xl mx-auto px-4 py-12">
          <div className="rounded-3xl bg-slate-900 border border-rose-500/40 p-8 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-950/60 border border-rose-500/40 flex items-center justify-center">
              <ShieldAlert className="w-7 h-7 text-rose-400" />
            </div>
            <h2 className="text-xl font-extrabold text-white">Isolated Country Manager Login Portal</h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl mx-auto">
              You are currently signed in as <strong className="text-white">{currentUser.name}</strong> ({currentUser.role}).
              Country Manager accounts are strictly isolated from Founder, Super Admin, Company Admin, Branch Manager, Employee, Dealer, and Customer accounts.
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('landing')}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold"
              >
                Return to Global Fleet
              </button>
              <button
                type="button"
                onClick={logoutUser}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xs font-bold flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out to Authenticate as Country Manager</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-2xl mx-auto px-4 py-10 space-y-6">
        <div className="rounded-3xl bg-slate-900 border border-slate-700/80 shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 p-6 border-b border-slate-800">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400">
                    National Jurisdiction Portal • Mandatory 2FA
                  </span>
                  <h1 className="text-xl font-black text-white">Country Manager Login Portal</h1>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                {statusLoading ? 'Checking...' : `${portalStatus?.activeCountriesCount ?? 0} Active Countries`}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-3">
              Dedicated server-enforced authentication for authorized National Country Managers assigned by the Primary Owner (Intekhab Alam). Strictly bound to one assigned country.
            </p>
          </div>

          <div className="p-6 space-y-5">
            {authError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{authError}</span>
              </div>
            )}
            {authSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{authSuccess}</span>
              </div>
            )}

            {authStep === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Manager ID (e.g. CM-PK-001), Official Email, Username, or Mobile
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="CM-PK-001 or country.pk@byd360.demo"
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-300">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setAuthError('');
                        setAuthSuccess('');
                        setAuthStep('forgot-password');
                      }}
                      className="text-xs text-cyan-400 hover:text-cyan-300"
                    >
                      Forgot / Reset Password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your Country Manager password"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-emerald-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={authSubmitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/20 disabled:opacity-50"
                >
                  {authSubmitting ? 'Verifying Country Credentials...' : 'Verify Credentials & Continue to 2FA'}
                </button>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Assigned National Country Managers (Click to Autofill Identifier)
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {[
                      { label: '🇵🇰 Pakistan Country Manager', code: 'CM-PK-001', email: 'country.pk@byd360.demo' },
                      { label: '🇦🇪 UAE Country Manager', code: 'CM-AE-001', email: 'country.ae@byd360.demo' },
                    ].map((acct) => (
                      <button
                        key={acct.code}
                        type="button"
                        onClick={() => setIdentifier(acct.code)}
                        className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left text-[11px]"
                      >
                        <div className="font-bold text-emerald-300">{acct.label}</div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">
                          {acct.code} • {acct.email}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </form>
            )}

            {authStep === 'verify-email' && (
              <form onSubmit={handleVerifyEmailSubmit} className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 text-xs space-y-1">
                  <div className="font-bold text-cyan-300">Mandatory Email OTP Verification ({pendingCountryLabel})</div>
                  <p className="text-slate-300">
                    Enter the 6-digit verification OTP sent to <strong>{pendingEmail}</strong>.
                  </p>
                  {devEmailOtpHint && (
                    <p className="font-mono text-amber-300 pt-1">
                      Simulated Mailer Outbox OTP: <strong>{devEmailOtpHint}</strong>
                    </p>
                  )}
                </div>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={emailOtpCode}
                  onChange={(e) => setEmailOtpCode(e.target.value)}
                  placeholder="6-digit Email OTP"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-emerald-300"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setAuthStep('login')}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                  >
                    {authSubmitting ? 'Verifying OTP...' : 'Verify Email & Proceed to 2FA'}
                  </button>
                </div>
              </form>
            )}

            {authStep === '2fa' && (
              <form onSubmit={handleVerify2FASubmit} className="space-y-4">
                {suspiciousAlert && (
                  <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 text-xs text-amber-200 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>New IP/device detected for your Country Manager account. 2FA verification is required.</span>
                  </div>
                )}
                <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 text-xs space-y-1">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <KeyRound className="w-4 h-4 text-emerald-400" />
                    <span>2FA Challenge — {pendingCountryLabel || pendingEmail}</span>
                  </div>
                  <p className="text-slate-400">
                    Enter your 6-digit Authenticator TOTP code, your 6-digit single-use login OTP, or a backup recovery code.
                  </p>
                  {devLoginOtpHint && (
                    <p className="font-mono text-amber-300 pt-1">
                      Simulated Mailer Login 2FA OTP: <strong>{devLoginOtpHint}</strong>
                    </p>
                  )}
                </div>
                <input
                  type="text"
                  required
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value)}
                  placeholder="6-digit OTP / TOTP or Recovery Code"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-emerald-300"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthStep('login');
                      setChallengeToken('');
                    }}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 text-white text-xs font-bold"
                  >
                    {authSubmitting ? 'Verifying 2FA...' : 'Complete Country Manager Sign In'}
                  </button>
                </div>
              </form>
            )}

            {authStep === 'forgot-password' && (
              resetStage === 'request' ? (
                <form onSubmit={handleForgotSubmit} className="space-y-4 text-xs">
                  <p className="text-slate-300">
                    Enter your authorized Country Manager email to issue a single-use password reset token &amp; 6-digit OTP. Confirming reset revokes all active Country Manager sessions.
                  </p>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="Country Manager Email"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                    >
                      {authSubmitting ? 'Requesting...' : 'Send Reset Token & OTP'}
                    </button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleResetConfirm} className="space-y-3 text-xs">
                  {devResetHint && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 font-mono space-y-1 break-all">
                      <div>Reset Token: {devResetHint.resetToken}</div>
                      <div>Reset OTP: {devResetHint.otpCode}</div>
                    </div>
                  )}
                  <input
                    type="text"
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder="Reset Token (or leave empty if using OTP)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                  />
                  <input
                    type="text"
                    value={resetOtpCode}
                    onChange={(e) => setResetOtpCode(e.target.value)}
                    placeholder="6-digit Reset OTP"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                  />
                  <input
                    type="password"
                    required
                    value={resetNewPassword}
                    onChange={(e) => setResetNewPassword(e.target.value)}
                    placeholder="New Strong Password (10+ chars, Upper/Lower/Digit/Symbol)"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                    >
                      {authSubmitting ? 'Resetting...' : 'Reset Password & Revoke Sessions'}
                    </button>
                  </div>
                </form>
              )
            )}
          </div>
        </div>
      </div>
    );
  }

  // ----------------- HANDLERS FOR AUTHENTICATED COUNTRY MANAGER -----------------
  const m = dashboard?.metrics || {};
  const cProfile = dashboard?.countryProfile || {};
  const countryCurrency = cProfile.currency || 'PKR';

  const fmtMoney = (amt: number) => `${countryCurrency} ${Number(amt || 0).toLocaleString()}`;

  const handleGenerateBriefing = async () => {
    setAiBriefingLoading(true);
    try {
      const res = await api.getExecutiveSummary(
        {
          country: `${cProfile.name} (${cProfile.code})`,
          companies: m.totalCompanies || 0,
          branches: m.totalBranches || 0,
          dealerships: m.totalDealerships || 0,
          employees: m.totalEmployees || 0,
          customers: m.totalCustomers || 0,
          vehicles: m.totalVehicles || 0,
          availableVehicles: m.availableVehicles || 0,
          bookings: m.totalBookings || 0,
          vehicleSales: m.totalVehicleSales || 0,
          revenue: m.countryRevenue || 0,
          currency: countryCurrency,
          pendingApprovals: m.pendingApprovals || 0,
        },
        `${cProfile.name || currentUser.country} National Operations Telemetry`
      );
      setAiBriefing(res.summary);
    } catch (err: any) {
      notify(err.message || 'BYD AI executive briefing unavailable.', 'err');
    } finally {
      setAiBriefingLoading(false);
    }
  };

  const handleSaveCountryProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const departments = countryForm.departmentsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const authorizedOperations = countryForm.operationsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      await api.updateCountryManagerCountry({
        headquartersCity: countryForm.headquartersCity,
        legalEntity: countryForm.legalEntity,
        profile: {
          ...(countryData?.country?.profile || {}),
          sector: countryForm.sector,
          regulator: countryForm.regulator,
          emergencyHotline: countryForm.emergencyHotline,
          evPolicySummary: countryForm.evPolicySummary,
        },
        departments,
        authorizedOperations,
        offices: countryData?.country?.offices || [],
        documents: countryData?.country?.documents || [],
        contacts: countryData?.country?.contacts || [],
      });
      notify('Country profile, departments & operations updated.');
      await loadTabData('country');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleAddCountryOffice = async () => {
    if (!newOffice.name.trim() || !newOffice.city.trim()) return;
    const offices = [...(countryData?.country?.offices || [])];
    offices.push({ id: `off_${Date.now()}`, ...newOffice });
    try {
      await api.updateCountryManagerCountry({ offices });
      setNewOffice({ name: '', city: '', address: '', type: 'Regional Office', phone: '' });
      notify('Country/regional office added.');
      await loadTabData('country');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleAddCountryDoc = async () => {
    if (!newDoc.title.trim()) return;
    const documents = [...(countryData?.country?.documents || [])];
    documents.push({
      id: `cdoc_${Date.now()}`,
      title: newDoc.title.trim(),
      category: newDoc.category,
      refNo: newDoc.refNo.trim() || `REG-${Math.floor(1000 + Math.random() * 9000)}`,
      verified: true,
      uploadedAt: new Date().toISOString().slice(0, 10),
    });
    try {
      await api.updateCountryManagerCountry({ documents });
      setNewDoc({ title: '', category: 'Regulatory', refNo: '' });
      notify('Country compliance document saved.');
      await loadTabData('country');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleAddCountryContact = async () => {
    if (!newContact.name.trim() || !newContact.role.trim()) return;
    const contacts = [...(countryData?.country?.contacts || [])];
    contacts.push({ id: `cnt_${Date.now()}`, ...newContact });
    try {
      await api.updateCountryManagerCountry({ contacts });
      setNewContact({ role: '', name: '', email: '', phone: '' });
      notify('Local business contact added.');
      await loadTabData('country');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSaveCompanyOps = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCompany) return;
    try {
      await api.updateCountryManagerCompanyOps(editingCompany.id, companyOpsForm);
      notify(`Updated country operations for ${editingCompany.name}.`);
      setEditingCompany(null);
      await loadTabData('companies');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSubmitCompanyEscalation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!escTargetCompany) return;
    try {
      const res = await api.submitCountryManagerCompanyEscalation(escTargetCompany.id, escForm);
      notify(`Escalation ${res.id} submitted for Primary Owner approval.`);
      setEscTargetCompany(null);
      setEscForm({ title: '', details: '' });
      await loadTabData('companies');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleCreateBranch = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createCountryManagerBranch(newBranch);
      notify(`${res.message} (${res.escalationId})`);
      setNewBranch({
        companyId: branchesData?.companies?.[0]?.id || '',
        name: '',
        code: '',
        city: cProfile.headquartersCity || '',
        address: '',
        managerId: '',
        managerName: '',
        phone: '+92 ',
        email: '',
        monthlyTargetUnits: 25,
      });
      await loadTabData('branches');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSaveBranchEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBranch) return;
    try {
      await api.updateCountryManagerBranch(editingBranch.id, branchEditForm);
      notify(`Branch ${editingBranch.name} updated.`);
      setEditingBranch(null);
      await loadTabData('branches');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleDealerDecision = async (id: string, decision: 'Approved' | 'Rejected' | 'Suspended') => {
    try {
      await api.decideCountryManagerDealership(id, decision);
      notify(`Dealership status set to ${decision}.`);
      await loadTabData('dealerships');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSaveDealerEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDealer) return;
    try {
      await api.updateCountryManagerDealership(editingDealer.id, dealerEditForm);
      notify(`Updated dealership ${editingDealer.name}.`);
      setEditingDealer(null);
      await loadTabData('dealerships');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSendDealerComm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commTargetDealer) return;
    try {
      await api.communicateCountryManagerDealership(commTargetDealer.id, commForm);
      notify(`Country directive delivered to ${commTargetDealer.name}.`);
      setCommTargetDealer(null);
      setCommForm({ subject: '', message: '' });
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSaveEmployeeEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmp) return;
    try {
      await api.updateCountryManagerEmployee(editingEmp.id, empEditForm);
      notify(`Updated employee responsibilities for ${editingEmp.full_name}.`);
      setEditingEmp(null);
      await loadTabData('employees');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleVehicleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferModal) return;
    try {
      const res = await api.transferCountryManagerVehicle(transferModal.vehicle.id, {
        targetBranchId: transferModal.targetBranchId,
        deliveryStatus: transferModal.deliveryStatus,
      });
      notify(`Vehicle ${transferModal.vehicle.vin} transferred to ${res.branchName} (${res.deliveryStatus}).`);
      setTransferModal(null);
      await loadTabData('vehicles');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleSaveCrm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCrm) return;
    try {
      await api.updateCountryManagerCrm(editingCrm.id, crmEditForm);
      notify(`CRM record "${editingCrm.subject}" updated to ${crmEditForm.status}.`);
      setEditingCrm(null);
      await loadTabData('customers');
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleRefundAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundModal) return;
    try {
      if (refundModal.mode === 'direct') {
        const res = await api.refundCountryManagerInvoice(refundModal.invoice.id, refundModal.reason);
        notify(`Invoice ${res.invoiceNumber} refunded directly.`);
      } else {
        const res = await api.requestCountryManagerInvoiceRefund(refundModal.invoice.id, refundModal.reason);
        notify(`Refund escalation ${res.id} submitted for Primary Owner approval.`);
      }
      setRefundModal(null);
      await loadTabData('sales');
      await loadOverview();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleDownloadExport = async (format: 'xlsx' | 'csv') => {
    setExporting(true);
    try {
      const blob = await api.exportCountryManagerReportBlob(format, reportPeriod);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `BYD_360_${cProfile.code || currentUser.country}_${reportPeriod}_Report.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      notify(`Downloaded ${format.toUpperCase()} report for ${cProfile.name || currentUser.country} (${reportPeriod}).`);
    } catch (err: any) {
      notify(err.message, 'err');
    } finally {
      setExporting(false);
    }
  };

  const navTabs: { id: CountryPortalTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'overview', label: 'Country Overview', icon: Globe },
    { id: 'country', label: 'Country Profile & Offices', icon: MapPin },
    { id: 'companies', label: 'Companies', icon: Building2 },
    { id: 'branches', label: 'Branches', icon: GitBranch },
    { id: 'dealerships', label: 'Dealerships', icon: Store },
    { id: 'dealership-hub', label: 'Dealership Hub', icon: Store },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'employee-hub', label: 'Employee Management', icon: Briefcase },
    { id: 'vehicles', label: 'Vehicles & Stock', icon: Car },
    { id: 'customers', label: 'Customers & CRM', icon: UserCheck },
    { id: 'sales', label: 'Sales & Finance', icon: DollarSign },
    { id: 'reports', label: 'Reports & Export', icon: FileSpreadsheet },
    { id: 'security', label: 'Security & Logs', icon: Shield },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Country Command Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/50 border border-emerald-500/30 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              Country Manager Command • Isolated Jurisdiction
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
              ID: {currentUser.managerCode || dashboard?.actor?.managerCode || 'CM'} • Scope: {cProfile.id || currentUser.country}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
            <span className="text-2xl">{cProfile.flagEmoji || '🌐'}</span>
            <span>{cProfile.name || currentUser.country} — National Operations &amp; Country Management</span>
          </h1>
          <p className="text-xs text-slate-400">
            Signed in as <strong className="text-slate-200">{currentUser.name}</strong> ({currentUser.designation || 'Country Manager'}) • Legal Entity: <span className="text-slate-300">{cProfile.legalEntity || 'BYD National Operations'}</span> • Currency: <span className="font-mono text-emerald-300">{countryCurrency}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleGenerateBriefing}
            disabled={aiBriefingLoading}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white text-xs font-bold flex items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>{aiBriefingLoading ? 'Analyzing...' : 'BYD AI Country Briefing'}</span>
          </button>
          <button
            type="button"
            onClick={() => loadTabData(cmTab)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDash ? 'animate-spin' : ''}`} />
            <span>Refresh DB</span>
          </button>
          <button
            type="button"
            onClick={logoutUser}
            className="px-3 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-bold flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Secure Logout</span>
          </button>
        </div>
      </div>

      {banner && (
        <div
          className={`p-3.5 rounded-2xl border text-xs font-semibold flex items-center gap-2 ${
            banner.type === 'ok'
              ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
          }`}
        >
          {banner.type === 'ok' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
          <span>{banner.text}</span>
        </div>
      )}

      {aiBriefing && (
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" /> BYD AI National Executive Briefing ({cProfile.name})
            </span>
            <button onClick={() => setAiBriefing(null)} className="text-xs text-slate-400 hover:text-white">
              Dismiss
            </button>
          </div>
          <p className="text-xs sm:text-sm text-slate-200 whitespace-pre-line leading-relaxed">{aiBriefing}</p>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 pb-1">
        {navTabs.map((t) => {
          const Icon = t.icon;
          const active = cmTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setCmTab(t.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition ${
                active
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* ===================================================================== */}
      {/* TAB 1: COUNTRY OVERVIEW DASHBOARD                                     */}
      {/* ===================================================================== */}
      {cmTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {[
              { label: 'Total Companies', value: m.totalCompanies ?? 0, sub: `${m.approvedCompanies ?? 0} Approved`, color: 'text-cyan-400' },
              { label: 'Total Branches', value: m.totalBranches ?? 0, sub: `${m.pendingBranchApprovals ?? 0} Pending Approval`, color: 'text-emerald-400' },
              { label: 'Total Dealerships', value: m.totalDealerships ?? 0, sub: `${m.pendingDealers ?? 0} Pending Applications`, color: 'text-blue-400' },
              { label: 'Total Employees', value: m.totalEmployees ?? 0, sub: 'Country Workforce', color: 'text-indigo-400' },
              { label: 'Total Customers', value: m.totalCustomers ?? 0, sub: `${m.openCrm ?? 0} Open CRM Items`, color: 'text-sky-400' },
              { label: 'Vehicle Inventory', value: m.totalVehicles ?? 0, sub: `${m.availableVehicles ?? 0} Available In Stock`, color: 'text-teal-400' },
              { label: 'Bookings & Sales', value: `${m.totalBookings ?? 0} / ${m.totalVehicleSales ?? 0}`, sub: `${m.pendingBookings ?? 0} Bookings Pending`, color: 'text-amber-400' },
              { label: 'Country Revenue', value: fmtMoney(m.countryRevenue || 0), sub: `${m.pendingApprovals ?? 0} Pending Approvals`, color: 'text-emerald-300' },
            ].map((kpi) => (
              <div key={kpi.label} className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 font-semibold">{kpi.label}</div>
                <div className={`text-xl font-black ${kpi.color} truncate`}>{kpi.value}</div>
                <div className="text-[10px] text-slate-400">{kpi.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Country Companies Summary */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-cyan-400" />
                  <span>Assigned Companies in {cProfile.name}</span>
                </h3>
                <button onClick={() => setCmTab('companies')} className="text-xs text-cyan-400 hover:underline">
                  Manage &rarr;
                </button>
              </div>
              <div className="space-y-2">
                {(dashboard?.companyOverview || []).map((c: any) => (
                  <div key={c.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs gap-2">
                    <div>
                      <div className="font-bold text-white">{c.name}</div>
                      <div className="text-[11px] text-slate-400">
                        {c.city} • {c.branch_count} Branches • {c.employee_count} Staff • {c.vehicle_count} Vehicles
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-emerald-300">{fmtMoney(c.revenue_total)}</div>
                      <span className="text-[10px] text-cyan-300">{c.operational_status || c.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pending Dealership Approvals & Escalations */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Store className="w-4 h-4 text-amber-400" />
                  <span>Pending Dealership Applications ({dashboard?.pendingDealerships?.length || 0})</span>
                </h3>
                <button onClick={() => setCmTab('dealerships')} className="text-xs text-cyan-400 hover:underline">
                  All Dealers &rarr;
                </button>
              </div>
              {(dashboard?.pendingDealerships || []).length === 0 ? (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
                  No pending dealership applications in {cProfile.name}.
                </div>
              ) : (
                <div className="space-y-2">
                  {(dashboard?.pendingDealerships || []).map((d: any) => (
                    <div key={d.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
                      <div>
                        <div className="font-bold text-white">{d.name} ({d.code})</div>
                        <div className="text-[11px] text-slate-400">{d.city} • {d.company_name}</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleDealerDecision(d.id, 'Approved')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px]"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleDealerDecision(d.id, 'Rejected')}
                          className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold text-[11px]"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* System Notifications */}
              <div className="pt-2 space-y-2">
                <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Country Directives &amp; System Notifications</span>
                </div>
                <div className="max-h-40 overflow-y-auto space-y-1.5">
                  {(dashboard?.notifications || []).slice(0, 6).map((n: any) => (
                    <div key={n.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px]">
                      <div className="font-bold text-cyan-300">{n.title}</div>
                      <div className="text-slate-400">{n.message}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Recent Country Activities */}
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Recent Country Activity Audit Trail</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="py-2 px-3">Timestamp</th>
                    <th className="py-2 px-3">Actor</th>
                    <th className="py-2 px-3">Action</th>
                    <th className="py-2 px-3">Module</th>
                    <th className="py-2 px-3">Target / Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {(dashboard?.recentActivities || []).map((a: any) => (
                    <tr key={a.id} className="hover:bg-slate-900">
                      <td className="py-2 px-3 font-mono text-slate-400">{a.created_at?.slice(0, 19).replace('T', ' ')}</td>
                      <td className="py-2 px-3 text-white font-semibold">{a.actor_name}</td>
                      <td className="py-2 px-3 font-mono text-emerald-300">{a.action}</td>
                      <td className="py-2 px-3 text-cyan-300">{a.module}</td>
                      <td className="py-2 px-3 text-slate-300">{a.target_id} {a.details ? `— ${a.details}` : ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 2: COUNTRY PROFILE, OFFICES, DEPARTMENTS, DOCS & CONTACTS         */}
      {/* ===================================================================== */}
      {cmTab === 'country' && countryData && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleSaveCountryProfile} className="lg:col-span-2 rounded-2xl bg-slate-900/70 border border-slate-800 p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>National Profile &amp; Authorized Business Operations ({countryData.country?.name})</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Headquarters City</label>
                <input
                  type="text"
                  value={countryForm.headquartersCity}
                  onChange={(e) => setCountryForm({ ...countryForm, headquartersCity: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-semibold mb-1">National Legal Entity</label>
                <input
                  type="text"
                  value={countryForm.legalEntity}
                  onChange={(e) => setCountryForm({ ...countryForm, legalEntity: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-semibold mb-1">National Industry Sector</label>
                <input
                  type="text"
                  value={countryForm.sector}
                  onChange={(e) => setCountryForm({ ...countryForm, sector: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Regulatory Authority</label>
                <input
                  type="text"
                  value={countryForm.regulator}
                  onChange={(e) => setCountryForm({ ...countryForm, regulator: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-semibold mb-1">National Helpline / Emergency Hotline</label>
                <input
                  type="text"
                  value={countryForm.emergencyHotline}
                  onChange={(e) => setCountryForm({ ...countryForm, emergencyHotline: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-semibold mb-1">EV Policy &amp; Compliance Summary</label>
                <input
                  type="text"
                  value={countryForm.evPolicySummary}
                  onChange={(e) => setCountryForm({ ...countryForm, evPolicySummary: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Country Departments (comma-separated)</label>
              <input
                type="text"
                value={countryForm.departmentsText}
                onChange={(e) => setCountryForm({ ...countryForm, departmentsText: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Authorized Business Operations (comma-separated)</label>
              <input
                type="text"
                value={countryForm.operationsText}
                onChange={(e) => setCountryForm({ ...countryForm, operationsText: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
            >
              Save Country Profile &amp; Operations
            </button>
          </form>

          {/* Offices, Compliance Docs & Contacts */}
          <div className="space-y-4 text-xs">
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h4 className="font-bold text-white">Country &amp; Regional Offices</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {(countryData.country?.offices || []).map((o: any, i: number) => (
                  <div key={o.id || i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="font-bold text-cyan-300">{o.name} ({o.city})</div>
                    <div className="text-[11px] text-slate-400">{o.type} • {o.address} • {o.phone}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-1.5 pt-2 border-t border-slate-800">
                <input
                  placeholder="Office Name"
                  value={newOffice.name}
                  onChange={(e) => setNewOffice({ ...newOffice, name: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <input
                  placeholder="City"
                  value={newOffice.city}
                  onChange={(e) => setNewOffice({ ...newOffice, city: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <input
                  placeholder="Address"
                  value={newOffice.address}
                  onChange={(e) => setNewOffice({ ...newOffice, address: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <input
                  placeholder="Phone"
                  value={newOffice.phone}
                  onChange={(e) => setNewOffice({ ...newOffice, phone: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
              </div>
              <button type="button" onClick={handleAddCountryOffice} className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold">
                + Add Country/Regional Office
              </button>
            </div>

            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h4 className="font-bold text-white">National Compliance Documents</h4>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {(countryData.country?.documents || []).map((doc: any, i: number) => (
                  <div key={doc.id || i} className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white">{doc.title}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{doc.category} • {doc.refNo}</div>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-bold">Verified</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-1.5">
                <input
                  placeholder="Document Title"
                  value={newDoc.title}
                  onChange={(e) => setNewDoc({ ...newDoc, title: e.target.value })}
                  className="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                />
                <input
                  placeholder="Ref No."
                  value={newDoc.refNo}
                  onChange={(e) => setNewDoc({ ...newDoc, refNo: e.target.value })}
                  className="w-24 rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                />
              </div>
              <button type="button" onClick={handleAddCountryDoc} className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold">
                + Add Compliance Document
              </button>
            </div>

            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h4 className="font-bold text-white">Local Business Contacts</h4>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {(countryData.country?.contacts || []).map((c: any, i: number) => (
                  <div key={c.id || i} className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="font-bold text-white">{c.name} — <span className="text-cyan-300">{c.role}</span></div>
                    <div className="text-[10px] text-slate-400 font-mono">{c.email} • {c.phone}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                <input
                  placeholder="Contact Name"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                />
                <input
                  placeholder="Role / Title"
                  value={newContact.role}
                  onChange={(e) => setNewContact({ ...newContact, role: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                />
                <input
                  placeholder="Email"
                  value={newContact.email}
                  onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                />
                <input
                  placeholder="Phone"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1.5 text-white"
                />
              </div>
              <button type="button" onClick={handleAddCountryContact} className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold">
                + Add Business Contact
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 3: COMPANY MANAGEMENT & HIGHER APPROVAL ESCALATIONS               */}
      {/* ===================================================================== */}
      {cmTab === 'companies' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(companiesData?.companies || []).map((c: any) => (
              <div key={c.id} className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base font-bold text-white">{c.name}</h3>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {c.operational_status || c.status}
                      </span>
                    </div>
                    <p className="text-slate-400">
                      {c.city} • Rep: <strong className="text-slate-200">{c.authorized_rep}</strong> ({c.phone})
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-400">Performance</div>
                    <div className="text-lg font-black text-cyan-300">{c.performance_rating ?? 95}%</div>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div>
                    <div className="text-[10px] text-slate-400">Branches</div>
                    <div className="font-bold text-white">{c.branch_count}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Staff</div>
                    <div className="font-bold text-white">{c.employee_count}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Sales</div>
                    <div className="font-bold text-emerald-300">{c.sales_count}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400">Revenue</div>
                    <div className="font-bold text-cyan-300 truncate">{fmtMoney(c.paid_revenue)}</div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {hasPerm('companies.operations.manage') && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingCompany(c);
                        setCompanyOpsForm({
                          phone: c.phone || '',
                          city: c.city || '',
                          authorizedRep: c.authorized_rep || '',
                          operationalStatus: c.operational_status || 'Active',
                          performanceRating: Number(c.performance_rating ?? 95),
                          notes: c.relationship_notes || '',
                        });
                      }}
                      className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                    >
                      Manage Operations &amp; Rating
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setEscTargetCompany(c);
                      setEscForm({ title: '', details: '' });
                    }}
                    className="px-3 py-1.5 rounded-xl bg-amber-950 text-amber-300 border border-amber-800 hover:bg-amber-900 font-bold flex items-center gap-1"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>Request Higher Approval</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {editingCompany && (
            <form onSubmit={handleSaveCompanyOps} className="rounded-2xl bg-slate-900 border border-cyan-500/40 p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white text-sm">Update Country Operations: {editingCompany.name}</h4>
                <button type="button" onClick={() => setEditingCompany(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  placeholder="Phone"
                  value={companyOpsForm.phone}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, phone: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  placeholder="City"
                  value={companyOpsForm.city}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, city: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  placeholder="Authorized Rep"
                  value={companyOpsForm.authorizedRep}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, authorizedRep: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <select
                  value={companyOpsForm.operationalStatus}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, operationalStatus: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="Active">Active</option>
                  <option value="Under Compliance Review">Under Compliance Review</option>
                  <option value="Monitored Expansion">Monitored Expansion</option>
                </select>
                <input
                  type="number"
                  min={0}
                  max={100}
                  step="0.5"
                  value={companyOpsForm.performanceRating}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, performanceRating: Number(e.target.value) })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  placeholder="Operational Notes"
                  value={companyOpsForm.notes}
                  onChange={(e) => setCompanyOpsForm({ ...companyOpsForm, notes: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <button type="submit" className="px-4 py-2 rounded-xl bg-cyan-600 text-white font-bold">
                Save Company Country Operations
              </button>
            </form>
          )}

          {escTargetCompany && (
            <form onSubmit={handleSubmitCompanyEscalation} className="rounded-2xl bg-slate-900 border border-amber-500/40 p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-amber-300 text-sm">
                  Submit Escalation Request to Primary Owner ({escTargetCompany.name})
                </h4>
                <button type="button" onClick={() => setEscTargetCompany(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <input
                type="text"
                required
                placeholder="Escalation Title (e.g. Approve Special Fleet Allocation or Audit Review)"
                value={escForm.title}
                onChange={(e) => setEscForm({ ...escForm, title: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <textarea
                required
                rows={3}
                placeholder="Detailed business justification for Primary Owner review..."
                value={escForm.details}
                onChange={(e) => setEscForm({ ...escForm, details: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black">
                Submit for Primary Owner Approval
              </button>
            </form>
          )}

          {(companiesData?.escalations || []).length > 0 && (
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-2 text-xs">
              <h4 className="font-bold text-white">Company Escalation Requests Status</h4>
              {companiesData.escalations.map((e: any) => (
                <div key={e.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-white">{e.title}</div>
                    <div className="text-[11px] text-slate-400">{e.details}</div>
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${e.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : e.status === 'Rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                    {e.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 4: BRANCH MANAGEMENT (APPROVAL PROPOSALS & BRANCH REPORTS)        */}
      {/* ===================================================================== */}
      {cmTab === 'branches' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleCreateBranch} className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs h-fit">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Propose New Country Branch</span>
            </h3>
            <p className="text-[11px] text-slate-400">
              New branch registrations in {cProfile.name} remain <strong>Pending Approval</strong> until approved by the Primary Owner.
            </p>
            <select
              required
              value={newBranch.companyId}
              onChange={(e) => setNewBranch({ ...newBranch, companyId: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              {(branchesData?.companies || []).map((c: any) => (
                <option key={c.id} value={c.id}>{c.name} ({c.city})</option>
              ))}
            </select>
            <input
              type="text"
              required
              placeholder="Branch Name"
              value={newBranch.name}
              onChange={(e) => setNewBranch({ ...newBranch, name: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                placeholder="Branch Code (e.g. ISB-02)"
                value={newBranch.code}
                onChange={(e) => setNewBranch({ ...newBranch, code: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
              />
              <input
                type="text"
                required
                placeholder="City"
                value={newBranch.city}
                onChange={(e) => setNewBranch({ ...newBranch, city: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="text"
              required
              placeholder="Street Address"
              value={newBranch.address}
              onChange={(e) => setNewBranch({ ...newBranch, address: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <select
              value={newBranch.managerId}
              onChange={(e) => {
                const emp = (branchesData?.employees || []).find((x: any) => x.id === e.target.value);
                setNewBranch({
                  ...newBranch,
                  managerId: e.target.value,
                  managerName: emp ? emp.full_name : newBranch.managerName,
                });
              }}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">Assign Existing Employee (Optional)</option>
              {(branchesData?.employees || []).map((emp: any) => (
                <option key={emp.id} value={emp.id}>
                  {emp.full_name} ({emp.employee_code}) — {emp.job_position}
                </option>
              ))}
            </select>
            <input
              type="text"
              required
              placeholder="Branch Manager Full Name"
              value={newBranch.managerName}
              onChange={(e) => setNewBranch({ ...newBranch, managerName: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="tel"
                required
                placeholder="Branch Phone"
                value={newBranch.phone}
                onChange={(e) => setNewBranch({ ...newBranch, phone: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="number"
                required
                min={1}
                placeholder="Monthly Target"
                value={newBranch.monthlyTargetUnits}
                onChange={(e) => setNewBranch({ ...newBranch, monthlyTargetUnits: Number(e.target.value) })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="email"
              required
              placeholder="Branch Official Email"
              value={newBranch.email}
              onChange={(e) => setNewBranch({ ...newBranch, email: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <button
              type="submit"
              disabled={!hasPerm('branches.manage')}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold disabled:opacity-50"
            >
              Submit Branch Proposal for Approval
            </button>
          </form>

          <div className="lg:col-span-2 space-y-4 text-xs">
            {(branchesData?.branches || []).map((b: any) => (
              <div key={b.id} className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-white">{b.name}</span>
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-950 text-cyan-300 border border-slate-800">{b.code}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${b.approval_status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : b.approval_status === 'Rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                        {b.approval_status} • {b.status}
                      </span>
                    </div>
                    <div className="text-slate-400 mt-0.5">
                      {b.company_name} • {b.city} ({b.address}) • Mgr: <strong className="text-slate-200">{b.manager_name}</strong>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold text-emerald-300">{fmtMoney(b.monthly_revenue_pkr)}</div>
                    <div className="text-[10px] text-slate-400">
                      Target: {b.achieved_units}/{b.monthly_target_units} units • {b.staff_count} staff • {b.vehicle_count} vehicles
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      const rep = await api.getCountryManagerBranchReport(b.id);
                      setBranchReport(rep);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                  >
                    View Branch Report
                  </button>
                  {hasPerm('branches.manage') && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingBranch(b);
                        setBranchEditForm({
                          managerId: b.manager_id || '',
                          managerName: b.manager_name || '',
                          monthlyTargetUnits: b.monthly_target_units || 25,
                          phone: b.phone || '',
                          address: b.address || '',
                          status: b.status === 'Inactive' ? 'Inactive' : 'Active',
                        });
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold"
                    >
                      Assign Manager / Edit Target
                    </button>
                  )}
                </div>
              </div>
            ))}

            {editingBranch && (
              <form onSubmit={handleSaveBranchEdit} className="rounded-2xl bg-slate-900 border border-emerald-500/40 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white">Update Branch: {editingBranch.name}</h4>
                  <button type="button" onClick={() => setEditingBranch(null)} className="text-slate-400 hover:text-white">Close</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <select
                    value={branchEditForm.managerId}
                    onChange={(e) => {
                      const emp = (branchesData?.employees || []).find((x: any) => x.id === e.target.value);
                      setBranchEditForm({
                        ...branchEditForm,
                        managerId: e.target.value,
                        managerName: emp ? emp.full_name : branchEditForm.managerName,
                      });
                    }}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  >
                    <option value="">Select Employee as Manager</option>
                    {(branchesData?.employees || []).map((emp: any) => (
                      <option key={emp.id} value={emp.id}>{emp.full_name} ({emp.employee_code})</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={1}
                    value={branchEditForm.monthlyTargetUnits}
                    onChange={(e) => setBranchEditForm({ ...branchEditForm, monthlyTargetUnits: Number(e.target.value) })}
                    placeholder="Monthly Target Units"
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    value={branchEditForm.phone}
                    onChange={(e) => setBranchEditForm({ ...branchEditForm, phone: e.target.value })}
                    placeholder="Phone"
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <select
                    value={branchEditForm.status}
                    onChange={(e) => setBranchEditForm({ ...branchEditForm, status: e.target.value as 'Active' | 'Inactive' })}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
                <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold">
                  Save Branch Changes
                </button>
              </form>
            )}

            {branchReport && (
              <div className="rounded-2xl bg-slate-950 border border-cyan-500/40 p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-cyan-300 text-sm">
                    Branch Performance Report: {branchReport.branch?.name} ({branchReport.branch?.code})
                  </h4>
                  <button type="button" onClick={() => setBranchReport(null)} className="text-slate-400 hover:text-white">Close</button>
                </div>
                <div className="grid grid-cols-4 gap-2 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-900">
                    <div className="text-[10px] text-slate-400">Staff</div>
                    <div className="font-black text-white">{branchReport.summary?.staffCount}</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900">
                    <div className="text-[10px] text-slate-400">Vehicles</div>
                    <div className="font-black text-cyan-300">{branchReport.summary?.vehicleCount}</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900">
                    <div className="text-[10px] text-slate-400">Sold Units</div>
                    <div className="font-black text-emerald-300">{branchReport.summary?.soldCount}</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900">
                    <div className="text-[10px] text-slate-400">Target Met</div>
                    <div className="font-black text-amber-300">{branchReport.summary?.targetAchievementPct}%</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 5: DEALERSHIP MANAGEMENT                                          */}
      {/* ===================================================================== */}
      {cmTab === 'dealerships' && (
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {dealerships.map((d) => (
              <div key={d.id} className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-white">{d.name}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-950 font-mono text-[10px] text-cyan-300">{d.code}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${d.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : d.status === 'Pending Approval' ? 'bg-amber-950 text-amber-300' : 'bg-rose-950 text-rose-300'}`}>
                        {d.status}
                      </span>
                    </div>
                    <p className="text-slate-400 mt-0.5">
                      {d.city} • {d.facility_type} • {d.company_name}
                    </p>
                    <p className="text-slate-400">
                      Mgr: <strong className="text-slate-200">{d.manager_name}</strong> • {d.phone}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-bold text-emerald-300">{fmtMoney(d.monthly_revenue_pkr)}</div>
                    <div className="text-[10px] text-slate-400">
                      {d.achieved_units}/{d.monthly_target_units} units • ★ {d.rating}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {d.status !== 'Approved' && (
                    <button
                      onClick={() => handleDealerDecision(d.id, 'Approved')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" /> Approve
                    </button>
                  )}
                  {d.status === 'Pending Approval' && (
                    <button
                      onClick={() => handleDealerDecision(d.id, 'Rejected')}
                      className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" /> Reject
                    </button>
                  )}
                  {d.status === 'Approved' && (
                    <button
                      onClick={() => handleDealerDecision(d.id, 'Suspended')}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-300 font-bold"
                    >
                      Suspend
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setEditingDealer(d);
                      setDealerEditForm({
                        managerName: d.manager_name || '',
                        phone: d.phone || '',
                        monthlyTargetUnits: d.monthly_target_units || 20,
                        serviceBays: d.service_bays || 6,
                        activeTechs: d.active_techs || 8,
                      });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                  >
                    Update Info &amp; Targets
                  </button>
                  <button
                    onClick={() => {
                      setCommTargetDealer(d);
                      setCommForm({ subject: '', message: '' });
                    }}
                    className="px-3 py-1.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold flex items-center gap-1"
                  >
                    <Send className="w-3 h-3" /> Send Directive
                  </button>
                </div>
              </div>
            ))}
          </div>

          {editingDealer && (
            <form onSubmit={handleSaveDealerEdit} className="rounded-2xl bg-slate-900 border border-cyan-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Edit Dealership: {editingDealer.name}</h4>
                <button type="button" onClick={() => setEditingDealer(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                <input
                  value={dealerEditForm.managerName}
                  onChange={(e) => setDealerEditForm({ ...dealerEditForm, managerName: e.target.value })}
                  placeholder="Manager Name"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  value={dealerEditForm.phone}
                  onChange={(e) => setDealerEditForm({ ...dealerEditForm, phone: e.target.value })}
                  placeholder="Phone"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="number"
                  value={dealerEditForm.monthlyTargetUnits}
                  onChange={(e) => setDealerEditForm({ ...dealerEditForm, monthlyTargetUnits: Number(e.target.value) })}
                  placeholder="Monthly Target"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="number"
                  value={dealerEditForm.serviceBays}
                  onChange={(e) => setDealerEditForm({ ...dealerEditForm, serviceBays: Number(e.target.value) })}
                  placeholder="Service Bays"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="number"
                  value={dealerEditForm.activeTechs}
                  onChange={(e) => setDealerEditForm({ ...dealerEditForm, activeTechs: Number(e.target.value) })}
                  placeholder="Active Techs"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <button type="submit" className="px-4 py-2 rounded-xl bg-cyan-600 text-white font-bold">
                Save Dealership Updates
              </button>
            </form>
          )}

          {commTargetDealer && (
            <form onSubmit={handleSendDealerComm} className="rounded-2xl bg-slate-900 border border-emerald-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-emerald-300">Send Country Directive to {commTargetDealer.name}</h4>
                <button type="button" onClick={() => setCommTargetDealer(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <input
                type="text"
                required
                placeholder="Directive Subject"
                value={commForm.subject}
                onChange={(e) => setCommForm({ ...commForm, subject: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <textarea
                required
                rows={3}
                placeholder="Message to Dealership Management..."
                value={commForm.message}
                onChange={(e) => setCommForm({ ...commForm, message: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold">
                Send National Directive
              </button>
            </form>
          )}

          <div className="pt-4 border-t border-slate-800">
            <AdminDealerGovernancePanel scope="country-manager" />
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 6: EMPLOYEE & WORKFORCE MANAGEMENT                                */}
      {/* ===================================================================== */}
      {cmTab === 'employees' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {(employeesData?.deptBreakdown || []).map((d: any) => (
              <div key={d.department} className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-slate-400 font-semibold">{d.department}</div>
                <div className="text-xl font-black text-white mt-0.5">{d.headcount} Staff</div>
                <div className="text-[11px] text-emerald-400">Avg Performance: {d.avg_score}%</div>
              </div>
            ))}
          </div>

          {editingEmp && (
            <form onSubmit={handleSaveEmployeeEdit} className="rounded-2xl bg-slate-900 border border-emerald-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">
                  Update Country Responsibilities: {editingEmp.full_name} ({editingEmp.employee_code})
                </h4>
                <button type="button" onClick={() => setEditingEmp(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input
                  value={empEditForm.department}
                  onChange={(e) => setEmpEditForm({ ...empEditForm, department: e.target.value })}
                  placeholder="Department"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <select
                  value={empEditForm.jobPosition}
                  onChange={(e) => setEmpEditForm({ ...empEditForm, jobPosition: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {SAFE_JOB_POSITIONS.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={empEditForm.performanceScore}
                  onChange={(e) => setEmpEditForm({ ...empEditForm, performanceScore: Number(e.target.value) })}
                  placeholder="Performance Score"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  value={empEditForm.performanceNotes}
                  onChange={(e) => setEmpEditForm({ ...empEditForm, performanceNotes: e.target.value })}
                  placeholder="Notes / KPI Evaluation"
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold">
                Save Employee Assignment
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Employee</th>
                  <th className="py-2.5 px-3">Company / Branch</th>
                  <th className="py-2.5 px-3">Dept &amp; Position</th>
                  <th className="py-2.5 px-3">Score</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {(employeesData?.employees || []).map((e: any) => (
                  <tr key={e.id} className="hover:bg-slate-900">
                    <td className="py-2.5 px-3 font-mono text-cyan-300">{e.employee_code}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-white">{e.full_name}</div>
                      <div className="text-[10px] text-slate-400">{e.email}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{e.company_name} • {e.branch_name || 'HQ'}</td>
                    <td className="py-2.5 px-3 text-slate-200">{e.department} — {e.job_position}</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-300">{e.performance_score}%</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300">{e.status}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      {hasPerm('employees.manage') && (
                        <button
                          onClick={() => {
                            setEditingEmp(e);
                            setEmpEditForm({
                              department: e.department || 'Sales',
                              jobPosition: e.job_position || 'Sales Executive',
                              performanceScore: Number(e.performance_score ?? 90),
                              performanceNotes: e.performance_notes || '',
                            });
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                        >
                          Edit Role / KPI
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 7: VEHICLE & INVENTORY MANAGEMENT (INTRA-COUNTRY TRANSFERS)       */}
      {/* ===================================================================== */}
      {cmTab === 'vehicles' && (
        <div className="space-y-4 text-xs">
          {transferModal && (
            <form onSubmit={handleVehicleTransfer} className="rounded-2xl bg-slate-900 border border-cyan-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">
                  Intra-Country Stock Transfer: {transferModal.vehicle.model} ({transferModal.vehicle.vin})
                </h4>
                <button type="button" onClick={() => setTransferModal(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  required
                  value={transferModal.targetBranchId}
                  onChange={(e) => setTransferModal({ ...transferModal, targetBranchId: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {(vehiclesData?.branches || []).map((b: any) => (
                    <option key={b.id} value={b.company_branch_id || b.id}>
                      {b.name} ({b.code} — {b.city})
                    </option>
                  ))}
                </select>
                <select
                  value={transferModal.deliveryStatus}
                  onChange={(e) => setTransferModal({ ...transferModal, deliveryStatus: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="In Transit">In Transit</option>
                  <option value="In Stock">In Stock</option>
                  <option value="Allocated">Allocated</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>
              <button type="submit" className="px-4 py-2 rounded-xl bg-cyan-600 text-white font-bold">
                Execute Intra-Country Transfer
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">VIN</th>
                  <th className="py-2.5 px-3">Model / Color</th>
                  <th className="py-2.5 px-3">Company / Branch</th>
                  <th className="py-2.5 px-3">Battery SoH</th>
                  <th className="py-2.5 px-3">Stock / Delivery</th>
                  <th className="py-2.5 px-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {(vehiclesData?.vehicles || []).map((v: any) => (
                  <tr key={v.id} className="hover:bg-slate-900">
                    <td className="py-2.5 px-3 font-mono text-cyan-300">{v.vin}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-white">{v.model} ({v.variant})</div>
                      <div className="text-[10px] text-slate-400">{v.color} • {fmtMoney(v.sale_price_pkr)}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{v.company_name} • {v.branch_name || 'Central Yard'}</td>
                    <td className="py-2.5 px-3 font-bold text-emerald-300">{v.battery_health_soh}%</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-amber-300 font-semibold">
                        {v.delivery_status || v.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <button
                        type="button"
                        onClick={() =>
                          setTransferModal({
                            vehicle: v,
                            targetBranchId: vehiclesData?.branches?.[0]?.company_branch_id || vehiclesData?.branches?.[0]?.id || '',
                            deliveryStatus: 'In Transit',
                          })
                        }
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold flex items-center gap-1"
                      >
                        <ArrowRightLeft className="w-3 h-3" /> Transfer
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 8: CUSTOMERS, BOOKINGS & CRM MANAGEMENT (PII PROTECTION)          */}
      {/* ===================================================================== */}
      {cmTab === 'customers' && (
        <div className="space-y-6 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-slate-900/70 border border-slate-800 p-4">
            <div className="flex items-center gap-4">
              <div>
                <div className="text-slate-400">Country Customers</div>
                <div className="text-lg font-black text-white">{customersData?.csiSummary?.totalCustomers ?? 0}</div>
              </div>
              <div>
                <div className="text-slate-400">Open Complaints</div>
                <div className="text-lg font-black text-amber-300">{customersData?.csiSummary?.openComplaints ?? 0}</div>
              </div>
              <div>
                <div className="text-slate-400">CSI Satisfaction</div>
                <div className="text-lg font-black text-emerald-300">{customersData?.csiSummary?.satisfactionScore ?? 96.2}%</div>
              </div>
            </div>
            {hasPerm('customers.pii.reveal') && (
              <button
                type="button"
                onClick={() => setPiiRevealed((v) => !v)}
                className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-1.5 border ${
                  piiRevealed
                    ? 'bg-amber-950 text-amber-300 border-amber-500/40'
                    : 'bg-slate-800 text-slate-200 border-slate-700'
                }`}
              >
                {piiRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{piiRevealed ? 'Mask Customer PII' : 'Reveal Customer PII (Audit Logged)'}</span>
              </button>
            )}
          </div>

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 overflow-x-auto">
            <h4 className="font-bold text-white mb-3">Registered Customers ({cProfile.name})</h4>
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-3">Customer</th>
                  <th className="py-2 px-3">Mobile ({customersData?.piiRevealed ? 'Unmasked' : 'Masked'})</th>
                  <th className="py-2 px-3">CNIC / National ID</th>
                  <th className="py-2 px-3">Company / City</th>
                  <th className="py-2 px-3">Bookings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {(customersData?.customers || []).map((c: any) => (
                  <tr key={c.id}>
                    <td className="py-2 px-3">
                      <div className="font-bold text-white">{c.full_name}</div>
                      <div className="text-[10px] text-slate-400">{c.email}</div>
                    </td>
                    <td className="py-2 px-3 font-mono text-cyan-300">{c.mobileDisplay}</td>
                    <td className="py-2 px-3 font-mono text-amber-300">{c.cnicMasked}</td>
                    <td className="py-2 px-3 text-slate-300">{c.company_name} • {c.city}</td>
                    <td className="py-2 px-3 font-bold text-white">{c.booking_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {editingCrm && (
            <form onSubmit={handleSaveCrm} className="rounded-2xl bg-slate-900 border border-emerald-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-white">Resolve / Update CRM: {editingCrm.subject}</h4>
                <button type="button" onClick={() => setEditingCrm(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select
                  value={crmEditForm.status}
                  onChange={(e) => setCrmEditForm({ ...crmEditForm, status: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="Open">Open</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Closed">Closed</option>
                </select>
                <input
                  value={crmEditForm.resolutionNotes}
                  onChange={(e) => setCrmEditForm({ ...crmEditForm, resolutionNotes: e.target.value })}
                  placeholder="Resolution Notes"
                  className="sm:col-span-2 rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold">
                Save CRM Status
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h4 className="font-bold text-white">Country CRM Enquiries, Complaints &amp; Feedback</h4>
            <div className="space-y-2">
              {(customersData?.crmRecords || []).map((r: any) => (
                <div key={r.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300">{r.record_type}</span>
                      <span className="font-bold text-white">{r.subject}</span>
                      <span className="text-[10px] text-amber-300 font-bold">{r.priority}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {r.customer_name} ({r.customerPhoneDisplay}) • {r.details}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-emerald-300">{r.status}</span>
                    <button
                      onClick={() => {
                        setEditingCrm(r);
                        setCrmEditForm({ status: r.status || 'In Progress', resolutionNotes: r.resolution_notes || '' });
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                    >
                      Update
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <AdminCustomerGovernancePanel scope="country-manager" />
          <AdminVerificationApprovalPanel portalLabel="Country Manager" />
          <AccountSecurityCenter />
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 9: SALES & FINANCE (SENSITIVE REFUND ESCALATION WORKFLOW)         */}
      {/* ===================================================================== */}
      {cmTab === 'sales' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Paid Country Revenue</div>
              <div className="text-xl font-black text-emerald-300 font-mono">{fmtMoney(salesFinance?.totals?.paidRevenue)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Pending Payment</div>
              <div className="text-xl font-black text-amber-300 font-mono">{fmtMoney(salesFinance?.totals?.pendingRevenue)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Refunded Volume</div>
              <div className="text-xl font-black text-rose-300 font-mono">{fmtMoney(salesFinance?.totals?.refundedTotal)}</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Vehicles Delivered</div>
              <div className="text-xl font-black text-cyan-300">{salesFinance?.totals?.soldCount ?? 0}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2">
              <h4 className="font-bold text-white">Revenue by Company</h4>
              {(salesFinance?.companyRevenueBreakdown || []).map((c: any) => (
                <div key={c.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-white font-semibold truncate">{c.company_name}</span>
                  <span className="font-mono text-emerald-300">{fmtMoney(c.paid_revenue)}</span>
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2">
              <h4 className="font-bold text-white">Revenue by Dealership</h4>
              {(salesFinance?.dealershipRevenueBreakdown || []).map((d: any) => (
                <div key={d.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-white font-semibold truncate">{d.name}</span>
                  <span className="font-mono text-cyan-300">{fmtMoney(d.monthly_revenue_pkr)}</span>
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2">
              <h4 className="font-bold text-white">Revenue by Branch</h4>
              {(salesFinance?.branchRevenueBreakdown || []).map((b: any) => (
                <div key={b.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="text-white font-semibold truncate">{b.name}</span>
                  <span className="font-mono text-emerald-300">{fmtMoney(b.monthly_revenue_pkr)}</span>
                </div>
              ))}
            </div>
          </div>

          {refundModal && (
            <form onSubmit={handleRefundAction} className="rounded-2xl bg-slate-900 border border-amber-500/40 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-amber-300">
                  {refundModal.mode === 'direct' ? 'Direct Refund Authorization' : 'Request Primary Owner Refund Approval'}: {refundModal.invoice.invoice_number}
                </h4>
                <button type="button" onClick={() => setRefundModal(null)} className="text-slate-400 hover:text-white">Close</button>
              </div>
              <input
                type="text"
                required
                placeholder="Compliance / Finance Justification Reason"
                value={refundModal.reason}
                onChange={(e) => setRefundModal({ ...refundModal, reason: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-black">
                {refundModal.mode === 'direct' ? 'Execute Direct Refund' : 'Submit Refund Escalation'}
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 overflow-x-auto">
            <h4 className="font-bold text-white mb-3">Country Invoices &amp; Payments Ledger</h4>
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-3">Invoice</th>
                  <th className="py-2 px-3">Customer / Company</th>
                  <th className="py-2 px-3">Category</th>
                  <th className="py-2 px-3">Amount</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3">Governance Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {(salesFinance?.invoices || []).map((inv: any) => (
                  <tr key={inv.id}>
                    <td className="py-2 px-3 font-mono text-cyan-300">{inv.invoice_number}</td>
                    <td className="py-2 px-3">
                      <div className="font-bold text-white">{inv.customer_name}</div>
                      <div className="text-[10px] text-slate-400">{inv.company_name} • {inv.payment_gateway}</div>
                    </td>
                    <td className="py-2 px-3 text-slate-300">{inv.item_category}</td>
                    <td className="py-2 px-3 font-mono font-bold text-emerald-300">{inv.currency} {Number(inv.total_amount).toLocaleString()}</td>
                    <td className="py-2 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${inv.status === 'Paid' ? 'bg-emerald-950 text-emerald-300' : inv.status === 'Refunded' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 flex flex-wrap gap-1.5">
                      {inv.status !== 'Refunded' && (
                        <>
                          <button
                            type="button"
                            onClick={() => setRefundModal({ invoice: inv, mode: 'request', reason: '' })}
                            className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-800 font-bold"
                          >
                            Request Refund Approval
                          </button>
                          {hasPerm('finance.sensitive.manage') && (
                            <button
                              type="button"
                              onClick={() => setRefundModal({ invoice: inv, mode: 'direct', reason: '' })}
                              className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold"
                            >
                              Direct Refund
                            </button>
                          )}
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 10: COUNTRY REPORTS & REAL EXCEL (.xlsx) / CSV / PRINT EXPORT     */}
      {/* ===================================================================== */}
      {cmTab === 'reports' && (
        <div className="space-y-6 text-xs">
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setReportPeriod(p)}
                  className={`px-3.5 py-1.5 rounded-xl font-bold capitalize ${
                    reportPeriod === p ? 'bg-emerald-500 text-slate-950' : 'bg-slate-950 border border-slate-800 text-slate-300'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={exporting || !hasPerm('reports.export')}
                onClick={() => handleDownloadExport('xlsx')}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5 disabled:opacity-50"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Excel (.xlsx)</span>
              </button>
              <button
                type="button"
                disabled={exporting || !hasPerm('reports.export')}
                onClick={() => handleDownloadExport('csv')}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold flex items-center gap-1.5 disabled:opacity-50"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / PDF</span>
              </button>
            </div>
          </div>

          {reportData && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <div className="text-slate-400">Period Paid Revenue</div>
                  <div className="text-lg font-black text-emerald-300 font-mono">{fmtMoney(reportData.summary?.periodPaidRevenue)}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <div className="text-slate-400">Period Invoices</div>
                  <div className="text-lg font-black text-white">{reportData.summary?.invoicesCount}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <div className="text-slate-400">Branches</div>
                  <div className="text-lg font-black text-cyan-300">{reportData.summary?.branchesCount}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <div className="text-slate-400">Dealerships</div>
                  <div className="text-lg font-black text-blue-300">{reportData.summary?.dealershipsCount}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                  <div className="text-slate-400">Total Units Sold</div>
                  <div className="text-lg font-black text-amber-300">{reportData.summary?.totalSoldUnits}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2">
                  <h4 className="font-bold text-white">Vehicles by Model</h4>
                  {(reportData.vehiclesByModel || []).map((vm: any) => (
                    <div key={vm.model} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <span className="text-white font-semibold">{vm.model}</span>
                      <span className="text-slate-300">{vm.sold_units}/{vm.total_units} Sold • SoH {vm.avg_soh}%</span>
                    </div>
                  ))}
                </div>
                <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2">
                  <h4 className="font-bold text-white">Employees by Department</h4>
                  {(reportData.employeesSummary || []).map((es: any) => (
                    <div key={es.department} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <span className="text-white font-semibold">{es.department}</span>
                      <span className="text-emerald-300">{es.count} Staff • Avg {es.avg_performance}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 11: SECURITY, SESSIONS, PERMISSIONS & AUDIT LOGS                  */}
      {/* ===================================================================== */}
      {cmTab === 'security' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Sessions */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h4 className="font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-emerald-400" />
                <span>Active Country Manager Sessions ({cmSessions.length})</span>
              </h4>
              <div className="space-y-2">
                {cmSessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current Session)</span> : null}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400">
                        IP: {s.ip_address} • Expires: {s.expires_at?.slice(0, 19).replace('T', ' ')}
                      </div>
                    </div>
                    {!s.is_current && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.revokeCountryManagerSession(s.id);
                          setCmSessions((prev) => prev.filter((x) => x.id !== s.id));
                          notify('Session revoked.');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Canonical Country Manager Permissions */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h4 className="font-bold text-white flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-cyan-400" />
                <span>Assigned Canonical Country Permissions (Owner-Governed)</span>
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {(auditData?.canonicalPermissions || []).map((p: string) => {
                  const active = (auditData?.assignedPermissions || []).includes(p);
                  return (
                    <span
                      key={p}
                      className={`px-2 py-1 rounded-lg font-mono text-[10px] border ${
                        active ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-slate-950 text-slate-500 border-slate-800'
                      }`}
                    >
                      {active ? '✓ ' : '✗ '}
                      {p}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h4 className="font-bold text-white flex items-center gap-2">
              <History className="w-4 h-4 text-amber-400" />
              <span>Country Manager Login History</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {cmLoginHistory.map((h) => (
                <div key={h.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="font-mono text-slate-300">{h.ip_address}</span>
                  <span className="text-slate-400">{h.created_at?.slice(0, 19).replace('T', ' ')}</span>
                  <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {h.success ? 'SUCCESS' : h.failure_reason || 'FAILED'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {cmTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {cmTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
