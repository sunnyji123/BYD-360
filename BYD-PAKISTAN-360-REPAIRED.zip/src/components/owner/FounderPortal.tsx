import React, { useState, useEffect, useCallback } from 'react';
import {
  Crown,
  Shield,
  Lock,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Users,
  Car,
  DollarSign,
  Activity,
  Sparkles,
  Download,
  RefreshCw,
  LogOut,
  Plus,
  Check,
  XCircle,
  Eye,
  EyeOff,
  Server,
  FileText,
  Sliders,
  ShieldAlert,
  Copy,
  Globe,
  Store,
  TrendingUp,
  BarChart3,
  Ban,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AdminDealerGovernancePanel } from '../dealer/AdminDealerGovernancePanel';
import { AdminCustomerGovernancePanel } from '../customer/AdminCustomerGovernancePanel';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { AdminVerificationApprovalPanel } from '../admin/AdminVerificationApprovalPanel';
import { OwnerGlobalMap } from './OwnerGlobalMap';
import { OwnerAnalyticsCharts } from './OwnerAnalyticsCharts';
import { OwnerFinancialOverview } from './OwnerFinancialOverview';
import { OwnerSalesOverview } from './OwnerSalesOverview';
import { OwnerWorkforceOverview } from './OwnerWorkforceOverview';
import { OwnerPermissionsMatrix } from './OwnerPermissionsMatrix';
import { OwnerActivityLogsPanel } from './OwnerActivityLogsPanel';
import { EmployeeManagementHub } from '../employee/EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type OwnerTab =
  | 'overview'
  | 'countries'
  | 'finance'
  | 'sales'
  | 'employees'
  | 'employee-hub'
  | 'dealers'
  | 'dealership-hub'
  | 'companies'
  | 'country-managers'
  | 'branch-managers'
  | 'customers'
  | 'super-admins'
  | 'permissions'
  | 'activity-logs'
  | 'ai-settings'
  | 'security'
  | 'settings';

const AVAILABLE_SA_PERMISSIONS = [
  { key: 'users.view', label: 'users.view — View Registered Users & Profiles' },
  { key: 'users.create', label: 'users.create — Create Authorized User Accounts' },
  { key: 'users.update', label: 'users.update — Update User Details & Roles' },
  { key: 'users.suspend', label: 'users.suspend — Suspend / Reactivate Accounts' },
  { key: 'employees.manage', label: 'employees.manage — Manage Company Employees' },
  { key: 'dealers.manage', label: 'dealers.manage — Manage & Approve Dealerships' },
  { key: 'customers.manage', label: 'customers.manage — Manage & Verify Customers' },
  { key: 'vehicles.manage', label: 'vehicles.manage — Manage Vehicle Registry' },
  { key: 'bookings.manage', label: 'bookings.manage — Manage Bookings & Claims' },
  { key: 'sales.view', label: 'sales.view — View Sales & Payment Records' },
  { key: 'reports.view', label: 'reports.view — Access Operational Reports' },
  { key: 'notifications.manage', label: 'notifications.manage — Broadcast Announcements' },
  { key: 'settings.manage', label: 'settings.manage — Manage App Operational Settings' },
  { key: 'audit_logs.view', label: 'audit_logs.view — View Admin Activity & Audit Logs' },
];

const AVAILABLE_CA_PERMISSIONS = [
  { key: 'company.profile.manage', label: 'company.profile.manage — Edit Company Profile, Docs & Departments' },
  { key: 'employees.manage', label: 'employees.manage — Hire, Manage Attendance, Leave & Status' },
  { key: 'employees.permissions.manage', label: 'employees.permissions.manage — Grant / Revoke Staff Permissions' },
  { key: 'branches.manage', label: 'branches.manage — Create & Manage Company Branches' },
  { key: 'dealers.manage', label: 'dealers.manage — Manage, Approve & Message Dealerships' },
  { key: 'vehicles.manage', label: 'vehicles.manage — Manage Fleet Inventory & Transfers' },
  { key: 'customers.manage', label: 'customers.manage — Customer Records, CNIC Unmask & CRM' },
  { key: 'sales.manage', label: 'sales.manage — Bookings & Vehicle Sales Fulfillment' },
  { key: 'finance.manage', label: 'finance.manage — Invoices & Payment Refunds' },
  { key: 'reports.view', label: 'reports.view — View Daily / Monthly / Yearly Reports' },
  { key: 'reports.export', label: 'reports.export — Export .xlsx / .csv / Printable Reports' },
];

const AVAILABLE_CM_PERMISSIONS = [
  { key: 'country.profile.manage', label: 'country.profile.manage — Edit Country Profile, Offices, Docs & Contacts' },
  { key: 'companies.view', label: 'companies.view — View Country Companies & Performance' },
  { key: 'companies.operations.manage', label: 'companies.operations.manage — Update Company Country Ops & Ratings' },
  { key: 'branches.view', label: 'branches.view — View Country Branches & Branch Reports' },
  { key: 'branches.manage', label: 'branches.manage — Propose Branches & Assign Managers' },
  { key: 'dealers.manage', label: 'dealers.manage — Approve, Reject, Suspend & Message Dealers' },
  { key: 'employees.view', label: 'employees.view — View National Workforce & Depts' },
  { key: 'employees.manage', label: 'employees.manage — Update Country Employee Responsibilities & KPI' },
  { key: 'vehicles.manage', label: 'vehicles.manage — Manage Inventory & Intra-Country Transfers' },
  { key: 'customers.view', label: 'customers.view — View Country Customers, Bookings & CRM' },
  { key: 'customers.pii.reveal', label: 'customers.pii.reveal — Unmask Customer CNIC / Mobile (Audit Logged)' },
  { key: 'sales.view', label: 'sales.view — View Revenue, Invoices & Submit Refund Requests' },
  { key: 'finance.sensitive.manage', label: 'finance.sensitive.manage — Execute Direct Invoice Refunds (High Privilege)' },
  { key: 'reports.view', label: 'reports.view — Access Daily / Weekly / Monthly / Yearly Country Reports' },
  { key: 'reports.export', label: 'reports.export — Export .xlsx / .csv Country Reports' },
];

const AVAILABLE_BM_PERMISSIONS = [
  { key: 'branch.profile.manage', label: 'branch.profile.manage — Manage Branch Info, Hours, Depts & Announcements' },
  { key: 'employees.view', label: 'employees.view — View Branch Employees & Workforce Reports' },
  { key: 'employees.manage', label: 'employees.manage — Add Staff, Attendance, Leaves, Shifts & Tasks' },
  { key: 'vehicles.view', label: 'vehicles.view — View Branch EV Stock & Condition Records' },
  { key: 'vehicles.manage', label: 'vehicles.manage — Add Vehicles, Update Stock & Request Transfers' },
  { key: 'sales.view', label: 'sales.view — View Branch Bookings, Orders & Daily Sales Reports' },
  { key: 'sales.manage', label: 'sales.manage — Register Bookings, Orders & Branch Invoices' },
  { key: 'customers.view', label: 'customers.view — View Masked Customer Profiles & CRM Tickets' },
  { key: 'customers.manage', label: 'customers.manage — Register Customers & Manage CRM Follow-Ups' },
  { key: 'customers.pii.reveal', label: 'customers.pii.reveal — Unmask Customer CNIC & Phone (Audit Logged)' },
  { key: 'dealers.manage', label: 'dealers.manage — Monitor Dealers, Escalate Approvals & Send Dispatches' },
  { key: 'finance.view', label: 'finance.view — View Revenue, Expenses & Request Refunds' },
  { key: 'finance.refund.manage', label: 'finance.refund.manage — Execute Direct Invoice Refunds (High Privilege)' },
  { key: 'service.manage', label: 'service.manage — Service Tickets, Reminders, Warranty & Spare Parts' },
  { key: 'reports.view', label: 'reports.view — Access Branch Daily/Weekly/Monthly/Yearly Reports' },
  { key: 'reports.export', label: 'reports.export — Export .xlsx / .csv Branch Reports' },
];

export const FounderPortal: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, setActiveTab } = useApp();
  const isFounderLoggedIn = isAuthenticated && currentUser.subjectType === 'founder';

  const [statusLoading, setStatusLoading] = useState(true);
  const [founderStatus, setFounderStatus] = useState<{
    initialized: boolean;
    founderName: string;
    role: string;
    accountType: string;
    accessLevel: string;
    twoFactorRequired: boolean;
    requiresSetupSecret: boolean;
  } | null>(null);

  // Initialization state
  const [initEmail, setInitEmail] = useState('');
  const [initMobile, setInitMobile] = useState('+92 ');
  const [initPassword, setInitPassword] = useState('');
  const [initConfirmPassword, setInitConfirmPassword] = useState('');
  const [initSetupSecret, setInitSetupSecret] = useState('');
  const [showInitPassword, setShowInitPassword] = useState(false);
  const [setupCompleteData, setSetupCompleteData] = useState<{
    secret: string;
    otpAuthUri: string;
    recoveryCodes: string[];
  } | null>(null);

  // Login + 2FA state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [challengeToken, setChallengeToken] = useState<string | null>(null);
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);

  const [authError, setAuthError] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  // Authenticated Dashboard State
  const [ownerTab, setOwnerTab] = useState<OwnerTab>('overview');
  const [overview, setOverview] = useState<any>(null);
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [countriesData, setCountriesData] = useState<any>(null);
  const [workforceData, setWorkforceData] = useState<any>(null);
  const [salesOverviewData, setSalesOverviewData] = useState<any>(null);
  const [saActivityData, setSaActivityData] = useState<any>(null);
  const [securityData, setSecurityData] = useState<any>(null);
  const [aiSettingsData, setAiSettingsData] = useState<any>(null);
  const [actionBanner, setActionBanner] = useState('');
  const [loadingDash, setLoadingDash] = useState(false);

  // Super Admin creation & invite state
  const [saProvisionMode, setSaProvisionMode] = useState<'invite' | 'direct'>('invite');
  const [saFullName, setSaFullName] = useState('');
  const [saEmail, setSaEmail] = useState('');
  const [saMobile, setSaMobile] = useState('+92 300 ');
  const [saCity, setSaCity] = useState('Karachi');
  const [saCountry, setSaCountry] = useState('PK');
  const [saPassword, setSaPassword] = useState('');
  const [saPermissions, setSaPermissions] = useState<string[]>(AVAILABLE_SA_PERMISSIONS.map((p) => p.key));
  const [saProvisionResult, setSaProvisionResult] = useState<{
    type: 'invite' | 'direct';
    email: string;
    inviteToken?: string;
    inviteUrl?: string;
    totpSecret?: string;
    recoveryCodes?: string[];
    emailOtp?: string;
  } | null>(null);

  // Company Admin creation state (Founder-governed)
  const [caCompanyId, setCaCompanyId] = useState('comp_byd_pk');
  const [caFullName, setCaFullName] = useState('');
  const [caEmail, setCaEmail] = useState('');
  const [caMobile, setCaMobile] = useState('+92 300 ');
  const [caDesignation, setCaDesignation] = useState('Company Administrator');
  const [caPassword, setCaPassword] = useState('');
  const [caPermissions, setCaPermissions] = useState<string[]>(AVAILABLE_CA_PERMISSIONS.map((p) => p.key));
  const [caProvisionResult, setCaProvisionResult] = useState<{
    email: string;
    totpSecret?: string;
    recoveryCodes?: string[];
    emailOtp?: string;
  } | null>(null);

  // Country Manager provisioning & global assignment state
  const [cmCountryId, setCmCountryId] = useState('PK');
  const [cmFullName, setCmFullName] = useState('');
  const [cmEmail, setCmEmail] = useState('');
  const [cmMobile, setCmMobile] = useState('+92 300 ');
  const [cmCode, setCmCode] = useState('');
  const [cmDesignation, setCmDesignation] = useState('Country Manager');
  const [cmPassword, setCmPassword] = useState('');
  const [cmPermissions, setCmPermissions] = useState<string[]>(
    AVAILABLE_CM_PERMISSIONS.map((p) => p.key).filter((k) => k !== 'finance.sensitive.manage')
  );
  const [cmReassignMap, setCmReassignMap] = useState<Record<string, string>>({});
  const [cmProvisionResult, setCmProvisionResult] = useState<{
    email: string;
    managerCode?: string;
    countryId?: string;
    totpSecret?: string;
    recoveryCodes?: string[];
    emailOtp?: string;
  } | null>(null);

  // Branch Manager provisioning & branch assignment state
  const [bmBranchId, setBmBranchId] = useState('br_pk_khi');
  const [bmFullName, setBmFullName] = useState('');
  const [bmEmail, setBmEmail] = useState('');
  const [bmMobile, setBmMobile] = useState('+92 300 ');
  const [bmCode, setBmCode] = useState('');
  const [bmDesignation, setBmDesignation] = useState('Branch Manager');
  const [bmPassword, setBmPassword] = useState('');
  const [bmPermissions, setBmPermissions] = useState<string[]>(
    AVAILABLE_BM_PERMISSIONS.map((p) => p.key).filter((k) => k !== 'finance.refund.manage')
  );
  const [bmReassignMap, setBmReassignMap] = useState<Record<string, string>>({});
  const [bmProvisionResult, setBmProvisionResult] = useState<{
    email: string;
    managerCode?: string;
    branchName?: string;
    totpSecret?: string;
    recoveryCodes?: string[];
    emailOtp?: string;
  } | null>(null);

  // Security Policy editable state
  const [policyTimeout, setPolicyTimeout] = useState(120);
  const [policyMaxFails, setPolicyMaxFails] = useState(5);
  const [policyLockoutMins, setPolicyLockoutMins] = useState(15);
  const [policyBackupSched, setPolicyBackupSched] = useState('Daily 02:00 UTC');

  const loadFounderStatus = useCallback(async () => {
    setStatusLoading(true);
    try {
      const st = await api.getFounderStatus();
      setFounderStatus(st);
    } catch (err: any) {
      setAuthError(err.message || 'Unable to verify Founder portal status.');
    } finally {
      setStatusLoading(false);
    }
  }, []);

  const loadDashboardData = useCallback(async () => {
    if (!isFounderLoggedIn) return;
    setLoadingDash(true);
    try {
      const [ov, sec, aiCfg, analytics, countriesRes, workforceRes, saActRes, salesRes] = await Promise.all([
        api.getOwnerOverview(),
        api.getOwnerSecurityEvents(),
        api.getOwnerAiSettings(),
        api.getOwnerAnalyticsOverview(true),
        api.getOwnerCountries(),
        api.getOwnerWorkforce(),
        api.getOwnerSuperAdminActivity(),
        api.getOwnerSales(),
      ]);
      setOverview(ov);
      setSecurityData(sec);
      setAiSettingsData(aiCfg);
      setAnalyticsData(analytics);
      setCountriesData(countriesRes);
      setWorkforceData(workforceRes);
      setSaActivityData(saActRes);
      setSalesOverviewData(salesRes);
      if (ov?.securityPolicy) {
        setPolicyTimeout(ov.securityPolicy.sessionTimeoutMinutes || 120);
        setPolicyMaxFails(ov.securityPolicy.maxFailedLoginAttempts || 5);
        setPolicyLockoutMins(ov.securityPolicy.lockoutMinutes || 15);
        setPolicyBackupSched(ov.securityPolicy.backupSchedule || 'Daily 02:00 UTC');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Failed to load Owner dashboard data.');
    } finally {
      setLoadingDash(false);
    }
  }, [isFounderLoggedIn]);

  useEffect(() => {
    loadFounderStatus();
  }, [loadFounderStatus]);

  useEffect(() => {
    if (isFounderLoggedIn) {
      loadDashboardData();
    }
  }, [isFounderLoggedIn, loadDashboardData]);

  const handleInitializeFounder = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (initPassword !== initConfirmPassword) {
      setAuthError('Passwords do not match.');
      return;
    }
    setAuthSubmitting(true);
    try {
      const res = await api.initializeFounder({
        email: initEmail.trim(),
        mobile: initMobile.trim(),
        password: initPassword,
        setupSecret: initSetupSecret || undefined,
      });
      setSetupCompleteData(res.twoFactorSetup);
      setLoginIdentifier(initEmail.trim());
      await loadFounderStatus();
    } catch (err: any) {
      setAuthError(err.message || 'Initialization failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleFounderPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.founderLogin({
        identifier: loginIdentifier.trim(),
        password: loginPassword,
      });
      setChallengeToken(res.challengeToken);
      setSuspiciousAlert(res.suspiciousIpDetected);
    } catch (err: any) {
      setAuthError(err.message || 'Founder authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleFounder2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!challengeToken) return;
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.founderVerify2FA({
        challengeToken,
        code: twoFactorCode.trim(),
      });
      setChallengeToken(null);
      setTwoFactorCode('');
      setLoginPassword('');
      loginUser(res.user);
    } catch (err: any) {
      setAuthError(err.message || 'Invalid 2FA verification code.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const showBanner = (msg: string) => {
    setActionBanner(msg);
    setTimeout(() => setActionBanner(''), 4500);
  };

  const handleCompanyDecision = async (companyId: string, decision: 'Approved' | 'Rejected' | 'Suspended') => {
    try {
      await api.approveCompany(companyId, { status: decision });
      showBanner(`Company status updated to ${decision}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleCreateSuperAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaProvisionResult(null);
    try {
      if (saProvisionMode === 'invite') {
        const res = await api.inviteSuperAdmin({
          fullName: saFullName,
          email: saEmail,
          mobile: saMobile,
          city: saCity,
          country: saCountry,
          permissions: saPermissions,
        });
        setSaProvisionResult({
          type: 'invite',
          email: saEmail,
          inviteToken: res.inviteToken,
          inviteUrl: res.inviteUrl,
        });
        showBanner(`Single-use Super Admin activation invite generated for ${saEmail}.`);
      } else {
        const res = await api.createSuperAdmin({
          fullName: saFullName,
          email: saEmail,
          mobile: saMobile,
          password: saPassword,
          city: saCity,
          country: saCountry,
          permissions: saPermissions,
        });
        setSaProvisionResult({
          type: 'direct',
          email: saEmail,
          totpSecret: res.twoFactorSetup?.secret,
          recoveryCodes: res.twoFactorSetup?.recoveryCodes,
          emailOtp: res.verificationOutbox?.code,
        });
        showBanner('Super Admin account provisioned under Owner-governed canonical permissions.');
      }
      setSaFullName('');
      setSaEmail('');
      setSaPassword('');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleSaPermission = async (sa: any, permKey: string) => {
    const current: string[] = sa.permissions || [];
    const next = current.includes(permKey)
      ? current.filter((p) => p !== permKey)
      : [...current, permKey];
    try {
      await api.updateSuperAdminPermissions(sa.id, { permissions: next });
      showBanner(`Permissions updated for ${sa.full_name}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleSaStatus = async (sa: any) => {
    const nextStatus = sa.status === 'Active' ? 'Suspended' : 'Active';
    try {
      await api.updateSuperAdminPermissions(sa.id, { status: nextStatus });
      showBanner(`${sa.full_name} is now ${nextStatus}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleCreateCompanyAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCaProvisionResult(null);
    try {
      const res = await api.createCompanyAdmin({
        companyId: caCompanyId,
        fullName: caFullName,
        email: caEmail,
        mobile: caMobile,
        password: caPassword,
        designation: caDesignation,
        permissions: caPermissions,
      });
      setCaProvisionResult({
        email: caEmail,
        totpSecret: res.twoFactorSetup?.secret,
        recoveryCodes: res.twoFactorSetup?.recoveryCodes,
        emailOtp: res.verificationOutbox?.code,
      });
      showBanner(`Company Admin provisioned for ${caEmail}.`);
      setCaFullName('');
      setCaEmail('');
      setCaPassword('');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleCaPermission = async (ca: any, permKey: string) => {
    const current: string[] = ca.permissions || [];
    const next = current.includes(permKey)
      ? current.filter((p) => p !== permKey)
      : [...current, permKey];
    try {
      await api.updateCompanyAdminPermissions(ca.id, { permissions: next });
      showBanner(`Permissions updated for Company Admin ${ca.full_name}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleCaStatus = async (ca: any) => {
    const nextStatus = ca.status === 'Active' ? 'Suspended' : 'Active';
    try {
      await api.updateCompanyAdminPermissions(ca.id, { status: nextStatus });
      showBanner(`Company Admin ${ca.full_name} is now ${nextStatus}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleCreateCountryManager = async (e: React.FormEvent) => {
    e.preventDefault();
    setCmProvisionResult(null);
    try {
      const res = await api.createCountryManager({
        countryId: cmCountryId,
        fullName: cmFullName,
        email: cmEmail,
        mobile: cmMobile,
        password: cmPassword,
        designation: cmDesignation,
        managerCode: cmCode.trim() || undefined,
        permissions: cmPermissions,
      });
      setCmProvisionResult({
        email: cmEmail,
        managerCode: res.countryManager?.manager_code,
        countryId: res.countryManager?.country_id,
        totpSecret: res.twoFactorSetup?.secret,
        recoveryCodes: res.twoFactorSetup?.recoveryCodes,
        emailOtp: res.verificationOutbox?.code,
      });
      showBanner(`Country Manager ${res.countryManager?.manager_code || ''} provisioned for ${cmCountryId}.`);
      setCmFullName('');
      setCmEmail('');
      setCmPassword('');
      setCmCode('');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleReassignCountry = async (cm: any) => {
    const targetCountry = cmReassignMap[cm.id] || cm.country_id;
    if (!targetCountry || targetCountry === cm.country_id) return;
    try {
      const res = await api.assignCountryManagerCountry(cm.id, { countryId: targetCountry });
      showBanner(`${cm.full_name} reassigned from ${res.previousCountry} to ${res.countryName} (${res.countryId}). Active sessions revoked.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleCmPermission = async (cm: any, permKey: string) => {
    const current: string[] = cm.permissions || [];
    const next = current.includes(permKey)
      ? current.filter((p) => p !== permKey)
      : [...current, permKey];
    try {
      await api.updateCountryManagerPermissions(cm.id, { permissions: next });
      showBanner(`Permissions updated for Country Manager ${cm.full_name}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleCmStatus = async (cm: any) => {
    const nextStatus = cm.status === 'Active' ? 'Suspended' : 'Active';
    try {
      await api.updateCountryManagerPermissions(cm.id, { status: nextStatus });
      showBanner(`Country Manager ${cm.full_name} is now ${nextStatus}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleDecideCountryEscalation = async (escId: string, status: 'Approved' | 'Rejected') => {
    try {
      await api.decideCountryEscalation(escId, { status });
      showBanner(`Country escalation request ${status}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleCreateBranchManager = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createBranchManager({
        branchId: bmBranchId,
        fullName: bmFullName.trim(),
        email: bmEmail.trim(),
        mobile: bmMobile.trim(),
        password: bmPassword,
        managerCode: bmCode.trim() || undefined,
        designation: bmDesignation.trim() || 'Branch Manager',
        permissions: bmPermissions,
      });
      setBmProvisionResult({
        email: res.email,
        managerCode: res.managerCode,
        branchName: res.branchName,
        totpSecret: res.totpSecret,
        recoveryCodes: res.recoveryCodes,
        emailOtp: res.verificationOutbox?.code,
      });
      setBmFullName('');
      setBmEmail('');
      setBmMobile('+92 300 ');
      setBmCode('');
      setBmPassword('');
      showBanner(`Branch Manager ${res.managerCode} assigned to ${res.branchName}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleReassignBranch = async (bm: any) => {
    const targetBranch = bmReassignMap[bm.id];
    if (!targetBranch || targetBranch === bm.branch_id) return;
    try {
      const res = await api.assignBranchManagerBranch(bm.id, { branchId: targetBranch });
      showBanner(`${bm.full_name} reassigned to ${res.branchName}. Previous active sessions revoked.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleBmPermission = async (bm: any, permKey: string) => {
    const current: string[] = bm.permissions || [];
    const next = current.includes(permKey) ? current.filter((p) => p !== permKey) : [...current, permKey];
    try {
      await api.updateBranchManagerPermissions(bm.id, { permissions: next });
      showBanner(`Permissions updated for Branch Manager ${bm.full_name}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleToggleBmStatus = async (bm: any) => {
    const nextStatus = bm.status === 'Active' ? 'Suspended' : 'Active';
    try {
      await api.updateBranchManagerPermissions(bm.id, { status: nextStatus });
      showBanner(`Branch Manager ${bm.full_name} is now ${nextStatus}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleDecideBranchEscalation = async (escId: string, status: 'Approved' | 'Rejected') => {
    try {
      await api.decideBranchEscalation(escId, { status });
      showBanner(`Branch escalation request ${status}.`);
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleSaveAiSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiSettingsData) return;
    try {
      await api.updateOwnerAiSettings({
        globalEnabled: aiSettingsData.aiConfig.globalEnabled,
        defaultModel: aiSettingsData.aiConfig.defaultModel,
        dailyLimitPerCompany: Number(aiSettingsData.aiConfig.dailyLimitPerCompany || 250),
        dailyLimitPerUser: Number(aiSettingsData.aiConfig.dailyLimitPerUser || 60),
        allowDocumentAnalysis: aiSettingsData.aiConfig.allowDocumentAnalysis !== false,
        allowVoiceAssistant: aiSettingsData.aiConfig.allowVoiceAssistant !== false,
        companyOverrides: (aiSettingsData.companies || []).map((c: any) => ({
          id: c.id,
          ai_enabled: Boolean(c.ai_enabled),
          ai_daily_limit: Number(c.ai_daily_limit || 250),
        })),
      });
      showBanner('BYD AI global & per-company configuration saved.');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleSaveSecurityPolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateOwnerSettings({
        sessionTimeoutMinutes: Number(policyTimeout),
        maxFailedLoginAttempts: Number(policyMaxFails),
        lockoutMinutes: Number(policyLockoutMins),
        backupSchedule: policyBackupSched,
      });
      showBanner('Owner security & session expiration policy saved.');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Error: ${err.message}`);
    }
  };

  const handleDownloadBackup = async () => {
    try {
      const backup = await api.exportOwnerBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `BYD_PAKISTAN_360_OWNER_BACKUP_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showBanner('Sanitized enterprise database backup exported.');
      await loadDashboardData();
    } catch (err: any) {
      showBanner(`Backup error: ${err.message}`);
    }
  };

  // =========================================================================
  // RENDER: UNAUTHENTICATED PRIVATE FOUNDER LOGIN / ONE-TIME INITIALIZATION
  // =========================================================================
  if (!isFounderLoggedIn) {
    return (
      <div className="max-w-2xl mx-auto py-8 pb-16 space-y-6">
        <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950/20 border border-amber-500/30 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-500/20">
                <Crown className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-400">
                  Isolated Primary Owner Portal
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  BYD PAKISTAN 360 — Founder Access
                </h1>
                <p className="text-xs text-slate-400">
                  Intekhab Alam • Founder &amp; CEO • Primary Owner (Global Owner)
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('landing')}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900"
            >
              Exit Portal
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              This portal is strictly segregated from Super Admin, Company Admin, Dealer, Employee, and Customer logins. Mandatory password verification + Two-Factor Authentication (2FA) enforced on the server.
            </span>
          </div>

          {authError && (
            <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {setupCompleteData && (
            <div className="p-5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-4">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>Primary Owner Security Credentials Initialized</span>
              </div>
              <p className="text-xs text-slate-300">
                Add this Base32 TOTP secret to your Authenticator app (Google Authenticator / Authy / 1Password) and store your one-time backup recovery codes securely. They will never be displayed again.
              </p>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">2FA TOTP Authenticator Secret</div>
                <div className="flex items-center justify-between gap-2">
                  <code className="text-sm font-mono font-bold text-amber-300 break-all">{setupCompleteData.secret}</code>
                  <button
                    type="button"
                    onClick={() => navigator.clipboard?.writeText(setupCompleteData.secret)}
                    className="px-2 py-1 rounded bg-slate-800 text-xs text-slate-200 hover:bg-slate-700 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy
                  </button>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">One-Time Backup Recovery Codes</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {setupCompleteData.recoveryCodes.map((rc) => (
                    <code key={rc} className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-300 text-center">
                      {rc}
                    </code>
                  ))}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSetupCompleteData(null)}
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
              >
                I Have Saved My 2FA Secret &amp; Recovery Codes — Proceed to Sign In
              </button>
            </div>
          )}

          {statusLoading ? (
            <div className="py-10 text-center text-xs text-slate-400">Checking Founder security state...</div>
          ) : !founderStatus?.initialized && !setupCompleteData ? (
            /* ONE-TIME INITIAL FOUNDER PROVISIONING */
            <form onSubmit={handleInitializeFounder} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
                <strong>First-Time Setup Required:</strong> No hardcoded Owner password exists in this application. Provision the single Primary Owner security credentials for <strong>Intekhab Alam</strong> below. Once saved, setup locks permanently.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Private Owner Email</label>
                  <input
                    type="email"
                    required
                    value={initEmail}
                    onChange={(e) => setInitEmail(e.target.value)}
                    placeholder="founder.private@domain.com"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Private Owner Mobile</label>
                  <input
                    type="tel"
                    required
                    value={initMobile}
                    onChange={(e) => setInitMobile(e.target.value)}
                    placeholder="+92 300 0000000"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Strong Owner Password</label>
                  <div className="relative">
                    <input
                      type={showInitPassword ? 'text' : 'password'}
                      required
                      value={initPassword}
                      onChange={(e) => setInitPassword(e.target.value)}
                      placeholder="Min 10 chars, Upper, Lower, Digit, Symbol"
                      className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 pr-9 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowInitPassword(!showInitPassword)}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showInitPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Confirm Password</label>
                  <input
                    type="password"
                    required
                    value={initConfirmPassword}
                    onChange={(e) => setInitConfirmPassword(e.target.value)}
                    placeholder="Re-enter strong password"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {founderStatus?.requiresSetupSecret && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Environment Setup Secret</label>
                  <input
                    type="password"
                    required
                    value={initSetupSecret}
                    onChange={(e) => setInitSetupSecret(e.target.value)}
                    placeholder="Enter server FOUNDER_SETUP_SECRET"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 disabled:opacity-50"
              >
                {authSubmitting ? 'Provisioning Cryptographic Identity...' : 'Provision Primary Owner Credentials & Generate 2FA'}
              </button>
            </form>
          ) : !setupCompleteData && challengeToken ? (
            /* STEP 2: MANDATORY FOUNDER 2FA CHALLENGE */
            <form onSubmit={handleFounder2FASubmit} className="space-y-4">
              {suspiciousAlert && (
                <div className="p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-xs text-amber-200 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Security Notice: Sign-in detected from a new IP address. 2FA verification is strictly required.</span>
                </div>
              )}

              <div className="p-4 rounded-xl bg-slate-900 border border-amber-500/30 space-y-1">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <KeyRound className="w-4 h-4" />
                  <span>Founder Two-Factor Authentication (2FA)</span>
                </div>
                <p className="text-xs text-slate-300">
                  Enter the 6-digit TOTP code from your Authenticator app or one of your saved backup recovery codes.
                </p>
              </div>

              <input
                type="text"
                required
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value)}
                placeholder="6-digit TOTP or recovery code (e.g. 123456 or 1234-5678)"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-amber-300 focus:border-amber-400 focus:outline-none"
                autoFocus
              />

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setChallengeToken(null);
                    setTwoFactorCode('');
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={authSubmitting}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs uppercase tracking-wider"
                >
                  {authSubmitting ? 'Verifying 2FA...' : 'Verify 2FA & Open Founder Dashboard'}
                </button>
              </div>
            </form>
          ) : !setupCompleteData ? (
            /* STEP 1: FOUNDER LOGIN */
            <form onSubmit={handleFounderPasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Founder Email or Registered Mobile
                </label>
                <input
                  type="text"
                  required
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder="Enter private Founder email or mobile"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Founder Password
                </label>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 pr-9 text-xs text-white focus:border-amber-400 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Lock className="w-4 h-4" />
                <span>{authSubmitting ? 'Verifying Credentials...' : 'Continue to 2FA Challenge'}</span>
              </button>
            </form>
          ) : null}
        </div>
      </div>
    );
  }

  // =========================================================================
  // RENDER: AUTHENTICATED FOUNDER / OWNER DASHBOARD
  // =========================================================================
  const m = overview?.metrics || {};

  return (
    <div className="space-y-6 pb-12">
      {/* Top Founder Governance Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-950 to-amber-950/30 border border-amber-500/30 p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg">
            <Crown className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Primary Owner • Global Owner
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                2FA Session Verified
              </span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">
              Intekhab Alam — Founder &amp; CEO Command Center
            </h1>
            <p className="text-xs text-slate-400">
              Private Global Governance, Company Approvals, Super Admin RBAC, BYD AI Controls &amp; Database Backup
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={loadDashboardData}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-800 bg-slate-900 text-xs text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDash ? 'animate-spin' : ''}`} />
            <span>Refresh DB</span>
          </button>
          <button
            onClick={handleDownloadBackup}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-xs font-bold text-cyan-300 hover:text-white"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export DB Backup</span>
          </button>
          <button
            onClick={logoutUser}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-500/40 bg-rose-950/40 text-xs font-bold text-rose-300 hover:text-white"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Secure Logout</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-slate-900 border border-slate-800">
        {[
          { id: 'overview', label: 'Global Overview & Analytics', icon: Activity },
          { id: 'countries', label: `Global Map & Countries (${countriesData?.totalRegisteredCountries || overview?.countries?.length || 0})`, icon: Globe },
          { id: 'finance', label: 'Revenue & Finance', icon: DollarSign },
          { id: 'sales', label: 'Vehicle Sales', icon: Car },
          { id: 'employees', label: `Employees (${analyticsData?.overview?.totalEmployees ?? m.totalEmployees ?? 0})`, icon: Users },
          { id: 'employee-hub', label: 'Employee Management', icon: Users },
          { id: 'dealers', label: `Dealerships (${analyticsData?.overview?.totalDealerships ?? m.totalDealerships ?? 0})`, icon: Store },
          { id: 'dealership-hub', label: 'Dealership Hub', icon: Store },
          { id: 'companies', label: `Companies (${overview?.companies?.length || 0})`, icon: Building2 },
          { id: 'country-managers', label: `Country Mgrs (${overview?.countryManagers?.length || 0})`, icon: Globe },
          { id: 'branch-managers', label: `Branch Mgrs (${overview?.branchManagers?.length || 0})`, icon: Server },
          { id: 'customers', label: `Customers (${analyticsData?.overview?.totalCustomers ?? m.totalCustomers ?? 0})`, icon: Users },
          { id: 'super-admins', label: `Super Admins (${overview?.superAdmins?.length || 0})`, icon: Shield },
          { id: 'permissions', label: 'System Permissions', icon: Lock },
          { id: 'activity-logs', label: 'Owner Activity Logs', icon: FileText },
          { id: 'ai-settings', label: 'BYD AI Governance', icon: Sparkles },
          { id: 'security', label: `Security (${m.unacknowledgedAlerts || 0} Alerts)`, icon: ShieldAlert },
          { id: 'settings', label: 'Policy & Backups', icon: Sliders },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = ownerTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setOwnerTab(tab.id as OwnerTab)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition ${
                active
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {actionBanner && (
        <div className="p-3.5 rounded-xl bg-cyan-950/70 border border-cyan-500/40 text-xs text-cyan-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{actionBanner}</span>
        </div>
      )}

      {/* TAB 1: GLOBAL COMPANY OVERVIEW & ANALYTICS */}
      {ownerTab === 'overview' && (() => {
        const ao = analyticsData?.overview || {};
        return (
          <div className="space-y-6">
            {/* Complete 11+ Enterprise Database Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Total Countries</span>
                  <Globe className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalCountries ?? m.totalCountries ?? 0}</div>
                <div className="text-[11px] text-emerald-400 mt-0.5">{ao.operationalCountries ?? 0} Operational</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Companies</span>
                  <Building2 className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalRegisteredCompanies ?? m.totalCompanies ?? 0}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{ao.approvedCompanies ?? m.approvedCompanies ?? 0} Approved • {ao.pendingCompanies ?? m.pendingCompanies ?? 0} Pending</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Branches</span>
                  <Server className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalBranches ?? m.totalBranches ?? 0}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{ao.activeBranches ?? 0} Active hubs</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Dealerships</span>
                  <Store className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalDealerships ?? m.totalDealerships ?? 0}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{ao.activeDealerships ?? 0} Approved 3S</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Employees</span>
                  <Users className="w-4 h-4 text-blue-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalEmployees ?? m.totalEmployees ?? 0}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{ao.activeEmployees ?? 0} Active staff</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Customers</span>
                  <Users className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ao.totalCustomers ?? m.totalCustomers ?? 0}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{ao.verifiedCustomers ?? 0} Verified</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Total Vehicles</span>
                  <Car className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-xl font-black text-white font-mono tabular-nums">{ao.totalVehicles ?? m.totalVehicles ?? 0}</div>
                <div className="text-[11px] text-slate-400">{ao.availableVehicles ?? 0} In Stock • {ao.soldVehicles ?? m.totalSoldVehicles ?? 0} Sold</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Vehicle Sales Orders</span>
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-xl font-black text-white font-mono tabular-nums">{ao.totalVehicleSales ?? 0} Completed</div>
                <div className="text-[11px] text-amber-300 font-mono">{ao.pendingOrders ?? 0} Pending • {ao.cancelledOrders ?? 0} Cancelled</div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Total Revenue (Cleared)</span>
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-xl font-black text-emerald-400 font-mono tabular-nums">
                  ₨ {Math.round(ao.totalRevenue ?? m.paidRevenueTotal ?? 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-amber-300 font-mono">
                  Pending: ₨ {Math.round(ao.pendingPayments ?? m.pendingRevenueTotal ?? 0).toLocaleString()}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Total Expenses</span>
                  <BarChart3 className="w-4 h-4 text-rose-400" />
                </div>
                <div className="text-xl font-black text-rose-300 font-mono tabular-nums">
                  ₨ {Math.round(ao.totalExpenses ?? 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Ops + Commissions + Payroll
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Net Profit (Verified)</span>
                  <Shield className="w-4 h-4 text-amber-400" />
                </div>
                <div className={`text-xl font-black font-mono tabular-nums ${(ao.netProfit ?? 0) >= 0 ? 'text-cyan-300' : 'text-rose-400'}`}>
                  ₨ {Math.round(ao.netProfit ?? 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Margin: {ao.profitMarginPct ?? 0}% • {ao.activeSessions ?? m.activeSessions ?? 0} Active Sessions
                </div>
              </div>
            </div>

            {/* Company Performance Analytics */}
            <OwnerAnalyticsCharts
              timeSeries={analyticsData?.timeSeries || []}
              countries={countriesData?.countries || []}
              models={salesOverviewData?.byModel || []}
              dealerships={workforceData?.dealershipsOverview?.dealerships || []}
              employeesByDept={workforceData?.employeesOverview?.byDepartment || []}
            />

            {/* Recent Global Activities */}
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Recent Global Governance &amp; System Activities</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="py-2.5 px-3">Timestamp</th>
                      <th className="py-2.5 px-3">Actor</th>
                      <th className="py-2.5 px-3">Role</th>
                      <th className="py-2.5 px-3">Action</th>
                      <th className="py-2.5 px-3">Target</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {(overview?.recentActivities || []).map((act: any) => (
                      <tr key={act.id} className="hover:bg-slate-900">
                        <td className="py-2 px-3 font-mono text-slate-400">{act.created_at?.slice(0, 19).replace('T', ' ')}</td>
                        <td className="py-2 px-3 font-semibold text-white">{act.actor_name}</td>
                        <td className="py-2 px-3 text-cyan-300">{act.actor_role}</td>
                        <td className="py-2 px-3 font-mono text-amber-300">{act.action}</td>
                        <td className="py-2 px-3 text-slate-300">{act.target_id || act.module}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      })()}

      {/* NEW ENTERPRISE FOUNDER TABS */}
      {ownerTab === 'countries' && (
        <OwnerGlobalMap data={countriesData} loading={loadingDash} />
      )}

      {ownerTab === 'finance' && (
        <OwnerFinancialOverview
          countries={(countriesData?.countries || []).map((c: any) => ({ code: c.code, name: c.name }))}
        />
      )}

      {ownerTab === 'sales' && (
        <OwnerSalesOverview
          countries={(countriesData?.countries || []).map((c: any) => ({ code: c.code, name: c.name }))}
        />
      )}

      {ownerTab === 'employees' && (
        <OwnerWorkforceOverview mode="employees" data={workforceData} loading={loadingDash} />
      )}

      {ownerTab === 'permissions' && (
        <OwnerPermissionsMatrix onSaved={loadDashboardData} />
      )}

      {ownerTab === 'activity-logs' && (
        <OwnerActivityLogsPanel />
      )}

      {/* TAB 2: COMPANY REGISTRATION APPROVALS & COMPANY ADMIN GOVERNANCE */}
      {ownerTab === 'companies' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
            <div>
              <h3 className="text-base font-bold text-white">Independent Company Registrations &amp; Workspace Isolation</h3>
              <p className="text-xs text-slate-400">
                Approve pending registrations to activate isolated company workspaces, or suspend non-compliant entities.
              </p>
            </div>
            <div className="space-y-3">
              {(overview?.companies || []).map((comp: any) => (
                <div
                  key={comp.id}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-white">{comp.name}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          comp.status === 'Approved'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : comp.status === 'Pending Approval'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}
                      >
                        {comp.status}
                      </span>
                    </div>
                    <p className="text-slate-400">
                      {comp.city}, {comp.country} • Reg: <span className="font-mono text-slate-300">{comp.registration_details}</span>
                    </p>
                    <p className="text-slate-400">
                      Rep: <strong className="text-slate-200">{comp.authorized_rep}</strong> ({comp.official_email} • {comp.phone})
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {comp.status !== 'Approved' && (
                      <button
                        onClick={() => handleCompanyDecision(comp.id, 'Approved')}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Approve
                      </button>
                    )}
                    {comp.status === 'Pending Approval' && (
                      <button
                        onClick={() => handleCompanyDecision(comp.id, 'Rejected')}
                        className="px-3 py-1.5 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-bold flex items-center gap-1"
                      >
                        <XCircle className="w-3.5 h-3.5" /> Reject
                      </button>
                    )}
                    {comp.status === 'Approved' && (
                      <button
                        onClick={() => handleCompanyDecision(comp.id, 'Suspended')}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-300 text-xs font-bold"
                      >
                        Suspend
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dedicated Company Admin Provisioning & Permission Matrix */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>Provision Company Admin</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Create an isolated Company Admin bound strictly to a single company workspace and governed by canonical permissions.
              </p>

              {caProvisionResult && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-[11px] space-y-1">
                  <div className="font-bold text-emerald-300">Company Admin Created ({caProvisionResult.email})</div>
                  {caProvisionResult.emailOtp && (
                    <div className="font-mono text-amber-300">Email OTP: {caProvisionResult.emailOtp}</div>
                  )}
                  {caProvisionResult.totpSecret && (
                    <div className="font-mono text-cyan-300 break-all">TOTP Secret: {caProvisionResult.totpSecret}</div>
                  )}
                  {caProvisionResult.recoveryCodes && (
                    <div className="font-mono text-slate-300">
                      Backup Codes: {caProvisionResult.recoveryCodes.join(' | ')}
                    </div>
                  )}
                </div>
              )}

              <form onSubmit={handleCreateCompanyAdmin} className="space-y-2.5 text-xs">
                <select
                  value={caCompanyId}
                  onChange={(e) => setCaCompanyId(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {(overview?.companies || []).map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.status})
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  placeholder="Full Legal Name"
                  value={caFullName}
                  onChange={(e) => setCaFullName(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="email"
                  required
                  placeholder="Company Admin Email"
                  value={caEmail}
                  onChange={(e) => setCaEmail(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="tel"
                    required
                    placeholder="Mobile"
                    value={caMobile}
                    onChange={(e) => setCaMobile(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Designation"
                    value={caDesignation}
                    onChange={(e) => setCaDesignation(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                </div>
                <input
                  type="password"
                  required
                  placeholder="Strong Initial Password (10+ chars)"
                  value={caPassword}
                  onChange={(e) => setCaPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="max-h-36 overflow-y-auto space-y-1 p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] font-bold uppercase text-cyan-400 mb-1">Assigned Capabilities</div>
                  {AVAILABLE_CA_PERMISSIONS.map((perm) => (
                    <label key={perm.key} className="flex items-start gap-2 text-[11px] text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={caPermissions.includes(perm.key)}
                        onChange={(e) => {
                          if (e.target.checked) setCaPermissions([...caPermissions, perm.key]);
                          else setCaPermissions(caPermissions.filter((x) => x !== perm.key));
                        }}
                      />
                      <span>{perm.label}</span>
                    </label>
                  ))}
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-xs"
                >
                  Provision Company Admin
                </button>
              </form>
            </div>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">
                Authorized Company Admins ({overview?.companyAdmins?.length || 0})
              </h3>
              <div className="space-y-3">
                {(overview?.companyAdmins || []).map((ca: any) => (
                  <div key={ca.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                          <span>{ca.full_name}</span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                              ca.status === 'Active'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-rose-950 text-rose-300 border border-rose-800'
                            }`}
                          >
                            {ca.status}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold">
                            {ca.company_name || ca.company_id}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 font-mono">
                          {ca.email} • {ca.designation} • 2FA: {ca.two_factor_enabled ? 'Enforced' : 'Off'}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleCaStatus(ca)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                          ca.status === 'Active'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900'
                            : 'bg-emerald-600 text-white hover:bg-emerald-500'
                        }`}
                      >
                        {ca.status === 'Active' ? 'Suspend Account' : 'Reactivate'}
                      </button>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {AVAILABLE_CA_PERMISSIONS.map((perm) => {
                        const active = (ca.permissions || []).includes(perm.key);
                        return (
                          <button
                            key={perm.key}
                            type="button"
                            onClick={() => handleToggleCaPermission(ca, perm.key)}
                            className={`px-2 py-1 rounded-md text-[10px] font-mono border transition ${
                              active
                                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                                : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                            }`}
                          >
                            {active ? '✓ ' : ''}
                            {perm.key}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2B: GLOBAL COUNTRY ASSIGNMENT, COUNTRY MANAGERS & ESCALATIONS */}
      {ownerTab === 'country-managers' && (
        <div className="space-y-6">
          {/* Escalations Pending Primary Owner Approval */}
          <div className="rounded-2xl bg-slate-900/60 border border-amber-500/30 p-5 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-400" />
                <span>Country Manager Escalation &amp; Approval Queue ({(overview?.countryEscalations || []).filter((e: any) => e.status === 'Pending Founder Approval').length} Pending)</span>
              </h3>
            </div>
            {(overview?.countryEscalations || []).length === 0 ? (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
                No Country Manager escalations submitted yet.
              </div>
            ) : (
              <div className="space-y-2">
                {(overview?.countryEscalations || []).map((esc: any) => (
                  <div key={esc.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-bold text-[10px]">{esc.country_id}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300 font-semibold text-[10px]">{esc.request_type}</span>
                        <span className="font-bold text-white">{esc.title}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${esc.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : esc.status === 'Rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                          {esc.status}
                        </span>
                      </div>
                      <p className="text-slate-400">
                        Submitted by <strong>{esc.manager_name}</strong> • {esc.details}
                      </p>
                    </div>
                    {esc.status === 'Pending Founder Approval' && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleDecideCountryEscalation(esc.id, 'Approved')}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" /> Approve
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDecideCountryEscalation(esc.id, 'Rejected')}
                          className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900 font-bold flex items-center gap-1"
                        >
                          <XCircle className="w-3.5 h-3.5" /> Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Provision New Country Manager */}
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>Provision Country Manager</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Assign a dedicated Country Manager to one sovereign country jurisdiction with server-enforced RBAC and mandatory 2FA.
              </p>

              {cmProvisionResult && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-[11px] space-y-1">
                  <div className="font-bold text-emerald-300">
                    Country Manager Created: {cmProvisionResult.managerCode} ({cmProvisionResult.countryId})
                  </div>
                  <div className="text-slate-300 font-mono">{cmProvisionResult.email}</div>
                  {cmProvisionResult.emailOtp && (
                    <div className="font-mono text-amber-300">Email OTP: {cmProvisionResult.emailOtp}</div>
                  )}
                  {cmProvisionResult.totpSecret && (
                    <div className="font-mono text-cyan-300 break-all">TOTP Secret: {cmProvisionResult.totpSecret}</div>
                  )}
                  {cmProvisionResult.recoveryCodes && (
                    <div className="font-mono text-slate-300">Backup Codes: {cmProvisionResult.recoveryCodes.join(' | ')}</div>
                  )}
                </div>
              )}

              <form onSubmit={handleCreateCountryManager} className="space-y-2.5 text-xs">
                <select
                  value={cmCountryId}
                  onChange={(e) => setCmCountryId(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {(overview?.countries || []).map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.flag_emoji} {c.name} ({c.id}) — {c.currency}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  placeholder="Full Legal Name"
                  value={cmFullName}
                  onChange={(e) => setCmFullName(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="email"
                  required
                  placeholder="Official Country Manager Email"
                  value={cmEmail}
                  onChange={(e) => setCmEmail(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="tel"
                    required
                    placeholder="Mobile"
                    value={cmMobile}
                    onChange={(e) => setCmMobile(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    placeholder="Manager ID (e.g. CM-SA-001)"
                    value={cmCode}
                    onChange={(e) => setCmCode(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                </div>
                <input
                  type="text"
                  required
                  placeholder="Designation"
                  value={cmDesignation}
                  onChange={(e) => setCmDesignation(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="password"
                  required
                  placeholder="Strong Password (10+ chars, Upper/Lower/Digit/Symbol)"
                  value={cmPassword}
                  onChange={(e) => setCmPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="max-h-40 overflow-y-auto space-y-1 p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] font-bold uppercase text-emerald-400 mb-1">Country Manager Permissions</div>
                  {AVAILABLE_CM_PERMISSIONS.map((perm) => (
                    <label key={perm.key} className="flex items-start gap-2 text-[11px] text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={cmPermissions.includes(perm.key)}
                        onChange={(e) => {
                          if (e.target.checked) setCmPermissions([...cmPermissions, perm.key]);
                          else setCmPermissions(cmPermissions.filter((x) => x !== perm.key));
                        }}
                      />
                      <span>{perm.label}</span>
                    </label>
                  ))}
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 text-white font-bold text-xs"
                >
                  Provision Country Manager
                </button>
              </form>
            </div>

            {/* Authorized Country Managers & Reassignment */}
            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">
                Global Country Assignments &amp; Permissions ({overview?.countryManagers?.length || 0})
              </h3>
              <div className="space-y-3">
                {(overview?.countryManagers || []).map((cm: any) => {
                  const selectedAssignCountry = cmReassignMap[cm.id] ?? cm.country_id;
                  return (
                    <div key={cm.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                            <span>{cm.flag_emoji} {cm.full_name}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">
                              {cm.manager_code}
                            </span>
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                                cm.status === 'Active'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : cm.status === 'Pending Verification'
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-rose-950 text-rose-300 border border-rose-800'
                              }`}
                            >
                              {cm.status}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 font-mono">
                            {cm.email} • Assigned Country: <strong className="text-emerald-300">{cm.country_name || cm.country_id}</strong> • 2FA: Enforced
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleCmStatus(cm)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold ${
                            cm.status === 'Active'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900'
                              : 'bg-emerald-600 text-white hover:bg-emerald-500'
                          }`}
                        >
                          {cm.status === 'Active' ? 'Suspend Account' : 'Reactivate'}
                        </button>
                      </div>

                      {/* Owner Global Country Assignment Switcher */}
                      <div className="flex flex-wrap items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                        <span className="text-slate-400 font-semibold">Assign / Transfer Country:</span>
                        <select
                          value={selectedAssignCountry}
                          onChange={(e) => setCmReassignMap((prev) => ({ ...prev, [cm.id]: e.target.value }))}
                          className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1 text-white"
                        >
                          {(overview?.countries || []).map((c: any) => (
                            <option key={c.id} value={c.id}>
                              {c.flag_emoji} {c.name} ({c.id})
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          disabled={selectedAssignCountry === cm.country_id}
                          onClick={() => handleReassignCountry(cm)}
                          className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black disabled:opacity-40"
                        >
                          Apply Jurisdiction Transfer
                        </button>
                      </div>

                      {/* Canonical Permission Toggles */}
                      <div className="flex flex-wrap gap-1.5">
                        {AVAILABLE_CM_PERMISSIONS.map((perm) => {
                          const active = (cm.permissions || []).includes(perm.key);
                          return (
                            <button
                              key={perm.key}
                              type="button"
                              onClick={() => handleToggleCmPermission(cm, perm.key)}
                              className={`px-2 py-1 rounded-md text-[10px] font-mono border transition ${
                                active
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                  : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                              }`}
                              title={perm.label}
                            >
                              {active ? '✓ ' : ''}
                              {perm.key}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: BRANCH MANAGERS GOVERNANCE, BRANCH ASSIGNMENTS & ESCALATIONS */}
      {ownerTab === 'branch-managers' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Branch Escalation Queue ({(overview?.branchEscalations || []).filter((e: any) => e.status === 'Pending Higher Approval').length} Pending)</span>
            </h3>
            {(overview?.branchEscalations || []).length === 0 ? (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
                No branch-level escalations queued. Dealer approvals, inter-branch vehicle transfers, and high-privilege refund requests appear here.
              </div>
            ) : (
              <div className="space-y-2.5">
                {(overview?.branchEscalations || []).map((esc: any) => (
                  <div key={esc.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-bold text-[10px]">{esc.branch_id}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300 font-semibold text-[10px]">{esc.request_type}</span>
                        <span className="font-bold text-white">{esc.title}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${esc.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : esc.status === 'Rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                          {esc.status}
                        </span>
                      </div>
                      <p className="text-slate-400">Submitted by <strong>{esc.manager_name}</strong> • {esc.details}</p>
                    </div>
                    {esc.status === 'Pending Higher Approval' && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button type="button" onClick={() => handleDecideBranchEscalation(esc.id, 'Approved')} className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> Approve
                        </button>
                        <button type="button" onClick={() => handleDecideBranchEscalation(esc.id, 'Rejected')} className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900 font-bold flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" /> Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>Provision Branch Manager</span>
              </h3>
              <p className="text-[11px] text-slate-400">Assign an authorized Branch Manager to a specific company branch with mandatory 2FA and branch-level RBAC.</p>

              {bmProvisionResult && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-[11px] space-y-1">
                  <div className="font-bold text-emerald-300">Branch Manager Created: {bmProvisionResult.managerCode} ({bmProvisionResult.branchName})</div>
                  <div className="text-slate-300 font-mono">{bmProvisionResult.email}</div>
                  {bmProvisionResult.emailOtp && <div className="font-mono text-amber-300">Email OTP: {bmProvisionResult.emailOtp}</div>}
                  {bmProvisionResult.totpSecret && <div className="font-mono text-cyan-300 break-all">TOTP Secret: {bmProvisionResult.totpSecret}</div>}
                  {bmProvisionResult.recoveryCodes && <div className="font-mono text-slate-300">Backup Codes: {bmProvisionResult.recoveryCodes.join(' | ')}</div>}
                </div>
              )}

              <form onSubmit={handleCreateBranchManager} className="space-y-2.5 text-xs">
                <select value={bmBranchId} onChange={(e) => setBmBranchId(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  {(overview?.branches || []).map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name} ({b.code}) — {b.city}, {b.country_id}</option>
                  ))}
                </select>
                <input type="text" required placeholder="Full Legal Name" value={bmFullName} onChange={(e) => setBmFullName(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="email" required placeholder="Official Branch Manager Email" value={bmEmail} onChange={(e) => setBmEmail(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="grid grid-cols-2 gap-2">
                  <input type="tel" required placeholder="Mobile" value={bmMobile} onChange={(e) => setBmMobile(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                  <input type="text" placeholder="Manager ID (e.g. BM-PK-ISB-01)" value={bmCode} onChange={(e) => setBmCode(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono" />
                </div>
                <input type="text" required placeholder="Designation" value={bmDesignation} onChange={(e) => setBmDesignation(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="password" required placeholder="Strong Password (10+ chars)" value={bmPassword} onChange={(e) => setBmPassword(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="max-h-40 overflow-y-auto space-y-1 p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[10px] font-bold uppercase text-cyan-400 mb-1">Branch Manager Permissions</div>
                  {AVAILABLE_BM_PERMISSIONS.map((perm) => (
                    <label key={perm.key} className="flex items-start gap-2 text-[11px] text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={bmPermissions.includes(perm.key)}
                        onChange={(e) => {
                          if (e.target.checked) setBmPermissions([...bmPermissions, perm.key]);
                          else setBmPermissions(bmPermissions.filter((x) => x !== perm.key));
                        }}
                      />
                      <span>{perm.label}</span>
                    </label>
                  ))}
                </div>
                <button type="submit" className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-xs">
                  Provision Branch Manager
                </button>
              </form>
            </div>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Assigned Branch Managers &amp; Permissions ({overview?.branchManagers?.length || 0})</h3>
              <div className="space-y-3">
                {(overview?.branchManagers || []).map((bm: any) => {
                  const selectedAssignBranch = bmReassignMap[bm.id] ?? bm.branch_id;
                  return (
                    <div key={bm.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                            <span>{bm.full_name}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">{bm.manager_code}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${bm.status === 'Active' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : bm.status === 'Pending Verification' ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                              {bm.status}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 font-mono">
                            {bm.email} • Branch: <strong className="text-cyan-300">{bm.branch_name || bm.branch_id} ({bm.branch_code})</strong> • {bm.company_name}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleBmStatus(bm)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold ${bm.status === 'Active' ? 'bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900' : 'bg-emerald-600 text-white hover:bg-emerald-500'}`}
                        >
                          {bm.status === 'Active' ? 'Suspend Account' : 'Reactivate'}
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                        <span className="text-slate-400 font-semibold">Reassign Branch:</span>
                        <select
                          value={selectedAssignBranch}
                          onChange={(e) => setBmReassignMap((prev) => ({ ...prev, [bm.id]: e.target.value }))}
                          className="rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1 text-white"
                        >
                          {(overview?.branches || []).map((b: any) => (
                            <option key={b.id} value={b.id}>{b.name} ({b.code}) — {b.city}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          disabled={selectedAssignBranch === bm.branch_id}
                          onClick={() => handleReassignBranch(bm)}
                          className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black disabled:opacity-40"
                        >
                          Apply Branch Assignment
                        </button>
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        {AVAILABLE_BM_PERMISSIONS.map((perm) => {
                          const active = (bm.permissions || []).includes(perm.key);
                          return (
                            <button
                              key={perm.key}
                              type="button"
                              onClick={() => handleToggleBmPermission(bm, perm.key)}
                              className={`px-2 py-1 rounded-md text-[10px] font-mono border transition ${active ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'}`}
                              title={perm.label}
                            >
                              {active ? '✓ ' : ''}{perm.key}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: DEALERSHIP MANAGEMENT OVERVIEW & GOVERNANCE */}
      {ownerTab === 'dealers' && (
        <div className="space-y-6">
          <OwnerWorkforceOverview mode="dealerships" data={workforceData} loading={loadingDash} />
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5">
            <AdminDealerGovernancePanel scope="owner" />
          </div>
        </div>
      )}

      {/* TAB: CUSTOMER PORTAL GOVERNANCE */}
      {ownerTab === 'customers' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5">
          <AdminCustomerGovernancePanel scope="owner" />
        </div>
      )}

      {/* TAB 3: SUPER ADMIN PROVISIONING & CANONICAL PERMISSIONS (OWNER-ONLY) */}
      {ownerTab === 'super-admins' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Authorize Super Admin</span>
              </h3>
              <div className="flex rounded-lg bg-slate-950 border border-slate-800 p-0.5 text-[10px] font-bold">
                <button
                  type="button"
                  onClick={() => setSaProvisionMode('invite')}
                  className={`px-2 py-1 rounded ${saProvisionMode === 'invite' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
                >
                  Invite Link
                </button>
                <button
                  type="button"
                  onClick={() => setSaProvisionMode('direct')}
                  className={`px-2 py-1 rounded ${saProvisionMode === 'direct' ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
                >
                  Direct
                </button>
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              Only the Primary Owner can authorize Super Admins. Super Admins remain subordinate to the Founder and are bound by your exact canonical permission grants.
            </p>

            {saProvisionResult && (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 space-y-2 text-[11px]">
                <div className="font-bold text-emerald-300">
                  {saProvisionResult.type === 'invite' ? 'Single-Use Activation Invite Issued' : 'Direct Super Admin Provisioned'}
                </div>
                {saProvisionResult.inviteToken && (
                  <div className="space-y-1">
                    <div className="text-slate-300">Share this secure activation token / link with <strong>{saProvisionResult.email}</strong>:</div>
                    <code className="block p-2 rounded bg-slate-950 text-cyan-300 break-all font-mono">
                      {saProvisionResult.inviteUrl}
                    </code>
                    <div className="flex items-center justify-between gap-2">
                      <code className="text-[10px] text-amber-300 font-mono truncate">{saProvisionResult.inviteToken}</code>
                      <button
                        type="button"
                        onClick={() => navigator.clipboard?.writeText(saProvisionResult.inviteToken || '')}
                        className="px-2 py-0.5 rounded bg-slate-800 text-white shrink-0"
                      >
                        Copy Token
                      </button>
                    </div>
                  </div>
                )}
                {saProvisionResult.totpSecret && (
                  <div className="space-y-1">
                    <div className="text-slate-300">2FA TOTP Secret: <code className="text-amber-300 font-mono">{saProvisionResult.totpSecret}</code></div>
                    {saProvisionResult.emailOtp && (
                      <div className="text-slate-300">Initial Email Verify OTP: <code className="text-cyan-300 font-mono font-bold">{saProvisionResult.emailOtp}</code></div>
                    )}
                    {saProvisionResult.recoveryCodes && (
                      <div className="text-[10px] text-slate-400 font-mono">Recovery: {saProvisionResult.recoveryCodes.join(' • ')}</div>
                    )}
                  </div>
                )}
              </div>
            )}

            <form onSubmit={handleCreateSuperAdmin} className="space-y-3 text-xs">
              <input
                type="text"
                required
                placeholder="Full Name"
                value={saFullName}
                onChange={(e) => setSaFullName(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="email"
                required
                placeholder="Official Email"
                value={saEmail}
                onChange={(e) => setSaEmail(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="tel"
                  required={saProvisionMode === 'direct'}
                  placeholder="Mobile"
                  value={saMobile}
                  onChange={(e) => setSaMobile(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  required
                  placeholder="City"
                  value={saCity}
                  onChange={(e) => setSaCity(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              {saProvisionMode === 'direct' && (
                <input
                  type="password"
                  required
                  placeholder="Strong Password (10+ chars, upper/lower/digit/symbol)"
                  value={saPassword}
                  onChange={(e) => setSaPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              )}
              <div className="space-y-1.5 pt-1 max-h-56 overflow-y-auto pr-1">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Canonical Permissions ({saPermissions.length}/14)</span>
                {AVAILABLE_SA_PERMISSIONS.map((perm) => (
                  <label key={perm.key} className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={saPermissions.includes(perm.key)}
                      onChange={() =>
                        setSaPermissions((prev) =>
                          prev.includes(perm.key) ? prev.filter((k) => k !== perm.key) : [...prev, perm.key]
                        )
                      }
                      className="rounded bg-slate-950 border-slate-700"
                    />
                    <span>{perm.label}</span>
                  </label>
                ))}
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs"
              >
                {saProvisionMode === 'invite' ? 'Issue Super Admin Activation Invite' : 'Provision Super Admin Directly'}
              </button>
            </form>
          </div>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white">Provisioned Super Admins &amp; Canonical Permission Matrix</h3>
            {(overview?.superAdmins || []).length === 0 ? (
              <div className="p-6 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 text-center">
                No Super Admin accounts provisioned yet. Use the form on the left to issue a single-use activation invite or create an authorized Super Admin.
              </div>
            ) : (
              <div className="space-y-3">
                {(overview?.superAdmins || []).map((sa: any) => (
                  <div key={sa.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">{sa.full_name}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${sa.email_verified ? 'bg-cyan-950 text-cyan-300' : 'bg-amber-950 text-amber-300'}`}>
                            {sa.email_verified ? 'Email Verified + 2FA' : 'Pending Email Verify'}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">{sa.email} • {sa.city}, {sa.country}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleToggleSaStatus(sa)}
                          className={`px-3 py-1 rounded-lg text-xs font-bold ${
                            sa.status === 'Active'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : sa.status === 'Pending Verification'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {sa.status} (Toggle)
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await api.revokeSuperAdminAccess(sa.id, 'Access revoked via Founder Super Admin monitor');
                              showBanner(res.message);
                              await loadDashboardData();
                            } catch (err: any) {
                              showBanner(`Error: ${err.message}`);
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-bold inline-flex items-center gap-1"
                        >
                          <Ban className="w-3 h-3" /> Revoke Access
                        </button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {AVAILABLE_SA_PERMISSIONS.map((perm) => {
                        const has = (sa.permissions || []).includes(perm.key);
                        return (
                          <button
                            key={perm.key}
                            onClick={() => handleToggleSaPermission(sa, perm.key)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-semibold border transition ${
                              has
                                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                                : 'bg-slate-900 text-slate-500 border-slate-800'
                            }`}
                            title={perm.label}
                          >
                            {has ? '✓ ' : '+ '}
                            {perm.key}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {(overview?.pendingSaInvites || []).length > 0 && (
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  Pending Super Admin Invitations ({overview.pendingSaInvites.length})
                </h4>
                <div className="space-y-1.5">
                  {overview.pendingSaInvites.map((inv: any) => (
                    <div key={inv.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-white">{inv.full_name}</span>{' '}
                        <span className="font-mono text-slate-400">({inv.email})</span>
                      </div>
                      <span className="text-[10px] text-amber-300 font-mono">Expires {inv.expires_at?.slice(0, 10)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Super Admin Activity Monitor & Active Sessions */}
            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider">
                  Super Admin Administrative Operations &amp; Activity ({saActivityData?.activities?.length || 0})
                </h4>
                <span className="text-[11px] font-mono text-slate-400">
                  Active SA Sessions: {saActivityData?.activeSessions?.length || 0}
                </span>
              </div>
              {!(saActivityData?.activities?.length) ? (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-500 text-center">
                  No Data Available — No Super Admin operational logs recorded yet.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                      <tr>
                        <th className="py-2 px-3">Time</th>
                        <th className="py-2 px-3">Super Admin</th>
                        <th className="py-2 px-3">Action</th>
                        <th className="py-2 px-3">Module / Details</th>
                        <th className="py-2 px-3">IP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {saActivityData.activities.slice(0, 20).map((act: any) => (
                        <tr key={act.id}>
                          <td className="py-2 px-3 font-mono text-slate-400 whitespace-nowrap">{String(act.createdAt || '').slice(0, 19).replace('T', ' ')}</td>
                          <td className="py-2 px-3 font-semibold text-white">{act.actorName}</td>
                          <td className="py-2 px-3 font-mono text-amber-300">{act.action}</td>
                          <td className="py-2 px-3 text-slate-300">{act.module}: {act.details || act.targetId}</td>
                          <td className="py-2 px-3 font-mono text-slate-400">{act.ipAddress}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: BYD AI GOVERNANCE & LOGS */}
      {ownerTab === 'ai-settings' && aiSettingsData && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400">Server GEMINI_API_KEY</div>
              <div className={`text-sm font-black mt-1 ${aiSettingsData.geminiKeyConfigured ? 'text-emerald-400' : 'text-rose-400'}`}>
                {aiSettingsData.geminiKeyConfigured ? 'Configured in Environment' : 'Missing in Server Env'}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Never exposed to browser</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400">Total AI Requests</div>
              <div className="text-2xl font-black text-white mt-1">{aiSettingsData.stats?.totalRequests || 0}</div>
              <div className="text-[10px] text-emerald-400">{aiSettingsData.stats?.successCount || 0} Succeeded</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400">Errors / Blocked</div>
              <div className="text-2xl font-black text-amber-400 mt-1">
                {(aiSettingsData.stats?.errorCount || 0) + (aiSettingsData.stats?.blockedCount || 0)}
              </div>
              <div className="text-[10px] text-slate-400">Tracked transparently</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400">Estimated Token Spend</div>
              <div className="text-2xl font-black text-cyan-400 mt-1 font-mono">
                ${Number(aiSettingsData.stats?.totalEstimatedCostUsd || 0).toFixed(4)}
              </div>
              <div className="text-[10px] text-slate-400">Server usage telemetry</div>
            </div>
          </div>

          <form onSubmit={handleSaveAiSettings} className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-5 text-xs">
            <h3 className="text-sm font-bold text-white">BYD AI Global Controls &amp; Per-Company Limits</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Active Gemini Model</label>
                <select
                  value={aiSettingsData.aiConfig.defaultModel}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, defaultModel: e.target.value },
                    })
                  }
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                >
                  {(aiSettingsData.supportedModels || ['gemini-4-hydrogen', 'gemini-3.1-flash-lite']).map((mod: string) => (
                    <option key={mod} value={mod}>{mod}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Default Daily Limit / Company</label>
                <input
                  type="number"
                  min={1}
                  value={aiSettingsData.aiConfig.dailyLimitPerCompany || 250}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, dailyLimitPerCompany: Number(e.target.value) },
                    })
                  }
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Daily Limit / User</label>
                <input
                  type="number"
                  min={1}
                  value={aiSettingsData.aiConfig.dailyLimitPerUser || 60}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, dailyLimitPerUser: Number(e.target.value) },
                    })
                  }
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(aiSettingsData.aiConfig.globalEnabled)}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, globalEnabled: e.target.checked },
                    })
                  }
                />
                <span className="font-semibold text-white">Enable BYD AI Globally</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={aiSettingsData.aiConfig.allowDocumentAnalysis !== false}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, allowDocumentAnalysis: e.target.checked },
                    })
                  }
                />
                <span className="text-slate-300">Allow Document Upload Intelligence</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={aiSettingsData.aiConfig.allowVoiceAssistant !== false}
                  onChange={(e) =>
                    setAiSettingsData({
                      ...aiSettingsData,
                      aiConfig: { ...aiSettingsData.aiConfig, allowVoiceAssistant: e.target.checked },
                    })
                  }
                />
                <span className="text-slate-300">Allow Voice Assistant (STT/TTS)</span>
              </label>
            </div>

            <div className="space-y-2">
              <div className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">Company AI Access Overrides</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {(aiSettingsData.companies || []).map((c: any, idx: number) => (
                  <div key={c.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <span className="text-white font-semibold truncate">{c.name}</span>
                    <input
                      type="checkbox"
                      checked={Boolean(c.ai_enabled)}
                      onChange={(e) => {
                        const copy = [...aiSettingsData.companies];
                        copy[idx] = { ...c, ai_enabled: e.target.checked ? 1 : 0 };
                        setAiSettingsData({ ...aiSettingsData, companies: copy });
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs"
            >
              Save BYD AI Governance Settings
            </button>
          </form>

          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
            <h4 className="text-sm font-bold text-white">Recent BYD AI Usage &amp; Error Logs</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="py-2 px-3">Time</th>
                    <th className="py-2 px-3">Role</th>
                    <th className="py-2 px-3">Model</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Details / Error</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {(aiSettingsData.recentLogs || []).slice(0, 15).map((l: any) => (
                    <tr key={l.id}>
                      <td className="py-2 px-3 font-mono text-slate-400">{l.created_at?.slice(0, 19).replace('T', ' ')}</td>
                      <td className="py-2 px-3 text-white">{l.role}</td>
                      <td className="py-2 px-3 font-mono text-cyan-300">{l.model}</td>
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${l.status === 'SUCCESS' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                          {l.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-400">{l.error_message || `${l.prompt_chars} -> ${l.response_chars} chars`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: SECURITY EVENTS, LOGIN HISTORY & ACTIVE SESSIONS */}
      {ownerTab === 'security' && (
        <div className="space-y-6">
          <AdminVerificationApprovalPanel portalLabel="Founder / Primary Owner" />
          <AccountSecurityCenter />

          {securityData && (
            <>
              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Security Alerts &amp; Intrusion Detection</h3>
                <div className="space-y-2">
                  {(securityData.events || []).map((ev: any) => (
                    <div key={ev.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${ev.severity === 'CRITICAL' ? 'bg-rose-950 text-rose-300' : ev.severity === 'WARNING' ? 'bg-amber-950 text-amber-300' : 'bg-cyan-950 text-cyan-300'}`}>
                            {ev.severity}
                          </span>
                          <span className="font-mono font-bold text-white">{ev.event_type}</span>
                          <span className="text-slate-500">{ev.ip_address}</span>
                        </div>
                        <p className="text-slate-300 mt-1">{ev.details}</p>
                      </div>
                      {!ev.acknowledged && (
                        <button
                          onClick={async () => {
                            await api.acknowledgeSecurityEvent(ev.id);
                            await loadDashboardData();
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-semibold shrink-0"
                        >
                          Acknowledge
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Recent Authentication Attempts (All Accounts)</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                      <tr>
                        <th className="py-2 px-3">Time</th>
                        <th className="py-2 px-3">Identifier</th>
                        <th className="py-2 px-3">Type</th>
                        <th className="py-2 px-3">IP</th>
                        <th className="py-2 px-3">Result</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {(securityData.loginHistory || []).slice(0, 20).map((lh: any) => (
                        <tr key={lh.id}>
                          <td className="py-2 px-3 font-mono text-slate-400">{lh.created_at?.slice(0, 19).replace('T', ' ')}</td>
                          <td className="py-2 px-3 text-white">{lh.identifier}</td>
                          <td className="py-2 px-3 text-cyan-300">{lh.subject_type}</td>
                          <td className="py-2 px-3 font-mono text-slate-400">{lh.ip_address}</td>
                          <td className="py-2 px-3">
                            <span className={lh.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                              {lh.success ? 'SUCCESS' : `FAILED (${lh.failure_reason || 'Denied'})`}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 6: OWNER SETTINGS & DATABASE BACKUPS */}
      {ownerTab === 'settings' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-5 max-w-2xl">
          <h3 className="text-sm font-bold text-white">Security Policy &amp; Database Backup Settings</h3>
          <form onSubmit={handleSaveSecurityPolicy} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Session Expiration (Minutes)</label>
                <input
                  type="number"
                  min={5}
                  value={policyTimeout}
                  onChange={(e) => setPolicyTimeout(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Max Failed Logins</label>
                <input
                  type="number"
                  min={3}
                  max={15}
                  value={policyMaxFails}
                  onChange={(e) => setPolicyMaxFails(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Lockout Duration (Mins)</label>
                <input
                  type="number"
                  min={5}
                  value={policyLockoutMins}
                  onChange={(e) => setPolicyLockoutMins(Number(e.target.value))}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">Automated Backup Schedule</label>
              <input
                type="text"
                value={policyBackupSched}
                onChange={(e) => setPolicyBackupSched(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>

            <div className="flex items-center gap-3">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs"
              >
                Save Security Policy
              </button>
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="px-4 py-2.5 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 font-bold text-xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Full Database Snapshot (JSON)</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {ownerTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {ownerTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
