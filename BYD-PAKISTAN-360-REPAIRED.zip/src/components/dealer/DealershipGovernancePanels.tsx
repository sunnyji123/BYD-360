import React, { useState, useEffect, useCallback } from 'react';
import {
  DollarSign,
  Target,
  FileText,
  Download,
  Upload,
  Plus,
  CheckCircle2,
  XCircle,
  Award,
  RefreshCw,
  Eye,
} from 'lucide-react';
import { api } from '../../services/api';

interface PanelCommonProps {
  scope: any;
  dealersCatalog: any[];
  companiesCatalog?: any[];
  onRefreshParent?: () => void;
}

const fmtPkr = (n: number | string | undefined) =>
  `PKR ${Number(n || 0).toLocaleString('en-PK')}`;

const triggerBlobDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

// ============================================================================
// 1. DEALER COMMISSIONS & RULES PANEL
// ============================================================================
export const DealerCommissionsPanel: React.FC<PanelCommonProps> = ({ scope, dealersCatalog, companiesCatalog = [], onRefreshParent }) => {
  const [commissions, setCommissions] = useState<any[]>([]);
  const [rules, setRules] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [showRuleForm, setShowRuleForm] = useState(false);
  const [payComm, setPayComm] = useState<any | null>(null);
  const [payoutRef, setPayoutRef] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Rule form
  const [rCompanyId, setRCompanyId] = useState(companiesCatalog[0]?.id || 'comp_byd_pk');
  const [rDealerId, setRDealerId] = useState('');
  const [rModel, setRModel] = useState('ALL');
  const [rName, setRName] = useState('');
  const [rType, setRType] = useState<'Percentage' | 'Fixed'>('Percentage');
  const [rRate, setRRate] = useState(4.5);
  const [rFixedAmt, setRFixedAmt] = useState(450000);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getDealershipCommissions();
      setCommissions(res.commissions || []);
      setRules(res.rules || []);
      setSummary(res.summary || {});
    } catch (e: any) {
      setError(e?.message || 'Failed to load commissions.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCreateRule = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await api.createDealershipCommissionRule({
        companyId: rCompanyId,
        dealerId: rDealerId || null,
        vehicleModel: rModel,
        ruleName: rName,
        ruleType: rType,
        ratePct: rType === 'Percentage' ? Number(rRate) : 0,
        fixedAmountPkr: rType === 'Fixed' ? Number(rFixedAmt) : 0,
      });
      setNotice(`Saved commission rule "${rName}".`);
      setRName('');
      setShowRuleForm(false);
      load();
    } catch (err: any) {
      setError(err?.message || 'Failed to save rule.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-400" />
            Dealer Commissions &amp; Payout Governance
          </h3>
          <p className="text-xs text-slate-400">
            Configurable percentage/fixed commission rules, 2-step approval workflow, and duplicate-payout protection.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scope?.canManageCommissionRules && (
            <button
              type="button"
              onClick={() => setShowRuleForm(!showRuleForm)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> New Commission Rule
            </button>
          )}
          <button type="button" onClick={load} className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        <div className="rounded-xl bg-slate-950 border border-slate-800 p-3.5">
          <div className="text-slate-400 text-[11px]">Pending Approval</div>
          <div className="text-lg font-mono font-bold text-amber-300 mt-1">{fmtPkr(summary.pendingPkr)}</div>
        </div>
        <div className="rounded-xl bg-slate-950 border border-slate-800 p-3.5">
          <div className="text-slate-400 text-[11px]">Approved for Payout</div>
          <div className="text-lg font-mono font-bold text-blue-300 mt-1">{fmtPkr(summary.approvedPkr)}</div>
        </div>
        <div className="rounded-xl bg-slate-950 border border-slate-800 p-3.5">
          <div className="text-slate-400 text-[11px]">Verified Paid Out</div>
          <div className="text-lg font-mono font-bold text-emerald-400 mt-1">{fmtPkr(summary.paidPkr)}</div>
        </div>
        <div className="rounded-xl bg-slate-950 border border-slate-800 p-3.5">
          <div className="text-slate-400 text-[11px]">Active Commission Rules</div>
          <div className="text-lg font-mono font-bold text-white mt-1">{rules.filter((r) => r.is_active).length}</div>
        </div>
      </div>

      {showRuleForm && (
        <form onSubmit={handleCreateRule} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
          <div className="font-bold text-amber-300">Configure Dealer Commission Rule</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input required value={rName} onChange={(e) => setRName(e.target.value)} placeholder="Rule Title (e.g. BYD Seal Flagship Bonus)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <select value={rCompanyId} onChange={(e) => setRCompanyId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              {(companiesCatalog.length ? companiesCatalog : [{ id: 'comp_byd_pk', name: 'BYD Pakistan' }]).map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <select value={rDealerId} onChange={(e) => setRDealerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="">All Dealers (Company Default)</option>
              {dealersCatalog.map((d) => (
                <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input value={rModel} onChange={(e) => setRModel(e.target.value)} placeholder="Vehicle Model or ALL" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <select value={rType} onChange={(e) => setRType(e.target.value as any)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="Percentage">Percentage (%)</option>
              <option value="Fixed">Fixed Amount (PKR)</option>
            </select>
            {rType === 'Percentage' ? (
              <input type="number" step="0.1" min="0.5" max="20" value={rRate} onChange={(e) => setRRate(Number(e.target.value))} placeholder="Rate %" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            ) : (
              <input type="number" min="1000" value={rFixedAmt} onChange={(e) => setRFixedAmt(Number(e.target.value))} placeholder="Fixed PKR" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            )}
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowRuleForm(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Save Rule</button>
          </div>
        </form>
      )}

      {payComm && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setError('');
            try {
              await api.payDealershipCommission(payComm.id, payoutRef);
              setNotice(`Commission payout settled (${payoutRef}).`);
              setPayComm(null);
              setPayoutRef('');
              load();
              onRefreshParent?.();
            } catch (err: any) {
              setError(err?.message || 'Payout failed.');
            }
          }}
          className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-3 text-xs"
        >
          <div className="font-bold text-emerald-300">
            Record Verified Bank Payout — {payComm.dealer_name} ({fmtPkr(payComm.commission_amount_pkr)})
          </div>
          <div className="flex gap-2">
            <input required minLength={4} value={payoutRef} onChange={(e) => setPayoutRef(e.target.value)} placeholder="Verified Bank / RTGS Reference *" className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <button type="button" onClick={() => setPayComm(null)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold">Confirm Paid</button>
          </div>
        </form>
      )}

      {rules.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-xs">
          <div className="font-bold text-slate-300 mb-2">Active Commission Rules</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {rules.map((r) => (
              <div key={r.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">{r.rule_name}</div>
                  <div className="text-[11px] text-slate-400">
                    {r.dealer_name || r.company_name || 'Company Wide'} • Model: {r.vehicle_model}
                  </div>
                </div>
                <div className="font-mono font-bold text-amber-300">
                  {r.rule_type === 'Fixed' ? fmtPkr(r.fixed_amount_pkr) : `${r.rate_pct}%`}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Dealer</th>
              <th className="px-3 py-2.5">Sale Ref &amp; Vehicle</th>
              <th className="px-3 py-2.5">Sale Amount</th>
              <th className="px-3 py-2.5">Commission</th>
              <th className="px-3 py-2.5">Status / Payout Ref</th>
              <th className="px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {commissions.map((c) => (
              <tr key={c.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{c.dealer_name}</div>
                  <div className="font-mono text-[10px] text-slate-500">{c.dealer_code}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className="font-mono text-amber-300">{c.sale_ref || c.sale_id}</div>
                  <div className="text-[11px] text-slate-400">{c.vehicle_model}</div>
                </td>
                <td className="px-3 py-2.5 font-mono text-slate-300">{fmtPkr(c.sale_amount_pkr)}</td>
                <td className="px-3 py-2.5 font-mono">
                  <div className="text-emerald-300 font-bold">{fmtPkr(c.commission_amount_pkr)}</div>
                  <div className="text-[10px] text-slate-400">
                    {c.rule_type === 'Fixed' ? 'Fixed Fee' : `${c.commission_rate_pct}% Rate`}
                  </div>
                </td>
                <td className="px-3 py-2.5">
                  <div className={c.status === 'Paid' ? 'text-emerald-400 font-semibold' : c.status === 'Approved' ? 'text-blue-300 font-semibold' : c.status === 'Voided' ? 'text-rose-400' : 'text-amber-300'}>
                    {c.status}
                  </div>
                  {c.payout_reference && <div className="font-mono text-[10px] text-slate-400">{c.payout_reference}</div>}
                </td>
                <td className="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
                  {scope?.canApprovePayCommissions && c.status === 'Pending' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.approveDealershipCommission(c.id);
                        setNotice(`Approved commission ${c.id}.`);
                        load();
                        onRefreshParent?.();
                      }}
                      className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold"
                    >
                      Approve
                    </button>
                  )}
                  {scope?.canApprovePayCommissions && c.status === 'Approved' && (
                    <button
                      type="button"
                      onClick={() => { setPayComm(c); setPayoutRef(''); }}
                      className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                    >
                      Record Payout
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {commissions.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-slate-500">No commission records found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// 2. DEALER TARGETS & PERFORMANCE PANEL
// ============================================================================
export const DealerTargetsPerformancePanel: React.FC<PanelCommonProps & { ranking: any[] }> = ({
  scope,
  dealersCatalog,
  ranking,
  onRefreshParent,
}) => {
  const [targets, setTargets] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [tDealerId, setTDealerId] = useState(dealersCatalog[0]?.id || '');
  const [tPeriodType, setTPeriodType] = useState<'Monthly' | 'Quarterly' | 'Yearly'>('Monthly');
  const [tPeriodKey, setTPeriodKey] = useState(new Date().toISOString().slice(0, 7));
  const [tModel, setTModel] = useState('ALL');
  const [tUnits, setTUnits] = useState(12);
  const [tRevenue, setTRevenue] = useState(150000000);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getDealershipTargets();
      setTargets(res.targets || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load targets.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await api.createDealershipTarget({
        dealerId: tDealerId,
        periodType: tPeriodType,
        periodKey: tPeriodKey,
        vehicleModel: tModel,
        targetUnits: Number(tUnits),
        targetRevenuePkr: Number(tRevenue),
      });
      setNotice('Assigned sales target.');
      setShowAdd(false);
      load();
      onRefreshParent?.();
    } catch (err: any) {
      setError(err?.message || 'Failed to assign target.');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-amber-400" />
            Dealer Sales Targets &amp; Performance Analytics
          </h3>
          <p className="text-xs text-slate-400">
            Monthly, quarterly, yearly &amp; model-wise sales quotas computed in real time from active sales records.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scope?.canManageTargets && (
            <button
              type="button"
              onClick={() => setShowAdd(!showAdd)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> Assign Target
            </button>
          )}
          <button type="button" onClick={load} className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      {showAdd && (
        <form onSubmit={handleAssign} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
          <div className="font-bold text-amber-300">Assign Dealer Sales Target</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <select value={tDealerId} onChange={(e) => setTDealerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              {dealersCatalog.map((d) => (
                <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
              ))}
            </select>
            <select
              value={tPeriodType}
              onChange={(e) => {
                const pt = e.target.value as any;
                setTPeriodType(pt);
                const yr = new Date().getFullYear();
                if (pt === 'Yearly') setTPeriodKey(String(yr));
                else if (pt === 'Quarterly') setTPeriodKey(`${yr}-Q${Math.ceil((new Date().getMonth() + 1) / 3)}`);
                else setTPeriodKey(new Date().toISOString().slice(0, 7));
              }}
              className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="Monthly">Monthly</option>
              <option value="Quarterly">Quarterly</option>
              <option value="Yearly">Yearly</option>
            </select>
            <input required value={tPeriodKey} onChange={(e) => setTPeriodKey(e.target.value)} placeholder="YYYY-MM or YYYY-Q2 or YYYY" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input value={tModel} onChange={(e) => setTModel(e.target.value)} placeholder="Model or ALL" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required type="number" min="1" value={tUnits} onChange={(e) => setTUnits(Number(e.target.value))} placeholder="Target Units *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input type="number" min="0" value={tRevenue} onChange={(e) => setTRevenue(Number(e.target.value))} placeholder="Target Revenue PKR" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Save Target</button>
          </div>
        </form>
      )}

      {/* Target Attainment Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Dealer</th>
              <th className="px-3 py-2.5">Period &amp; Model</th>
              <th className="px-3 py-2.5">Target vs Achieved</th>
              <th className="px-3 py-2.5">Achievement %</th>
              <th className="px-3 py-2.5">Revenue Achieved</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {targets.map((t) => (
              <tr key={t.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{t.dealer_name}</div>
                  <div className="font-mono text-[10px] text-slate-500">{t.dealer_code}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className="font-mono text-amber-300">{t.period_type} • {t.period_key}</div>
                  <div className="text-[11px] text-slate-400">Model: {t.vehicle_model}</div>
                </td>
                <td className="px-3 py-2.5 font-mono">
                  <span className="text-emerald-400 font-bold">{t.achievedUnits}</span> / <span className="text-white">{t.target_units}</span> units
                  <span className="text-slate-500 ml-2">({t.remainingUnits} rem)</span>
                </td>
                <td className="px-3 py-2.5 w-44">
                  <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                    <span className="text-white">{t.achievementPct}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full ${t.achievementPct >= 100 ? 'bg-emerald-400' : t.achievementPct >= 60 ? 'bg-amber-400' : 'bg-rose-400'}`}
                      style={{ width: `${Math.min(100, t.achievementPct)}%` }}
                    />
                  </div>
                </td>
                <td className="px-3 py-2.5 font-mono text-emerald-300">{fmtPkr(t.achievedRevenuePkr)}</td>
              </tr>
            ))}
            {targets.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-slate-500">No sales targets assigned yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Dealer Ranking Performance Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3">
        <div className="text-xs font-bold text-white flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-400" /> Dealer Network Performance Ranking
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2 pr-3">Rank</th>
                <th className="py-2 pr-3">Dealership</th>
                <th className="py-2 pr-3">Showrooms</th>
                <th className="py-2 pr-3">Stock</th>
                <th className="py-2 pr-3">Sold</th>
                <th className="py-2 pr-3">Sales Revenue</th>
                <th className="py-2">Commissions Earned</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {ranking.map((r, idx) => (
                <tr key={r.dealerId}>
                  <td className="py-2.5 pr-3 font-mono font-bold text-amber-400">#{idx + 1}</td>
                  <td className="py-2.5 pr-3">
                    <div className="font-semibold text-white">{r.businessName}</div>
                    <div className="text-[10px] font-mono text-slate-400">{r.dealerCode} • {r.city}</div>
                  </td>
                  <td className="py-2.5 pr-3 font-mono text-slate-300">{r.activeShowrooms}</td>
                  <td className="py-2.5 pr-3 font-mono text-slate-300">{r.availableStock}</td>
                  <td className="py-2.5 pr-3 font-mono font-bold text-white">{r.unitsSold}</td>
                  <td className="py-2.5 pr-3 font-mono text-emerald-300">{fmtPkr(r.revenuePkr)}</td>
                  <td className="py-2.5 font-mono text-amber-300">{fmtPkr(r.commissionTotalPkr)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 3. DEALER DOCUMENTS VAULT & REPORTS EXPORTS PANEL
// ============================================================================
export const DealerDocumentsReportsPanel: React.FC<PanelCommonProps> = ({ scope, dealersCatalog }) => {
  const [docs, setDocs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [dDealerId, setDDealerId] = useState(scope?.selfOnly ? scope.selfDealerId : dealersCatalog[0]?.id || '');
  const [dType, setDType] = useState('CNIC Verification');
  const [dTitle, setDTitle] = useState('');
  const [dFile, setDFile] = useState<File | null>(null);
  const [expSection, setExpSection] = useState('all');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getDealershipDocuments();
      setDocs(res.documents || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load documents.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dFile) return;
    setError('');
    try {
      const fd = new FormData();
      fd.append('dealerId', dDealerId);
      fd.append('docType', dType);
      fd.append('title', dTitle || dFile.name);
      fd.append('file', dFile);
      await api.uploadDealershipDocument(fd);
      setNotice('Uploaded document to private encrypted dealer vault.');
      setDTitle('');
      setDFile(null);
      load();
    } catch (err: any) {
      setError(err?.message || 'Document upload failed.');
    }
  };

  const handleExport = async (format: 'xlsx' | 'pdf' | 'csv') => {
    setError('');
    try {
      const { blob, filename } = await api.downloadDealershipBlob(
        `/api/dealership-management/reports/export?format=${format}&section=${encodeURIComponent(expSection)}`
      );
      triggerBlobDownload(blob, filename);
      setNotice(`Exported ${format.toUpperCase()} report (${filename}).`);
    } catch (err: any) {
      setError(err?.message || 'Export failed.');
    }
  };

  return (
    <div className="space-y-5">
      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      {/* Export Suite */}
      {scope?.canExportReports && (
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div>
            <div className="font-bold text-white">Dealership Reports &amp; Multi-Format Exports</div>
            <div className="text-slate-400">Generate Excel workbooks, PDF summaries, or CSV feeds scoped to your authorized network.</div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select value={expSection} onChange={(e) => setExpSection(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="all">Full Network Report</option>
              <option value="dealers">Dealers Directory</option>
              <option value="showrooms">Showrooms</option>
              <option value="inventory">Inventory</option>
              <option value="sales">Sales</option>
              <option value="commissions">Commissions</option>
            </select>
            <button type="button" onClick={() => handleExport('xlsx')} className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold inline-flex items-center gap-1">
              <Download className="w-3.5 h-3.5" /> Excel (.xlsx)
            </button>
            <button type="button" onClick={() => handleExport('pdf')} className="px-3 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold inline-flex items-center gap-1">
              <Download className="w-3.5 h-3.5" /> PDF
            </button>
            <button type="button" onClick={() => handleExport('csv')} className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold inline-flex items-center gap-1">
              <Download className="w-3.5 h-3.5" /> CSV
            </button>
          </div>
        </div>
      )}

      {/* Upload Form */}
      {scope?.canUploadDocuments && (
        <form onSubmit={handleUpload} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
          <div className="font-bold text-white flex items-center gap-2">
            <Upload className="w-4 h-4 text-amber-400" /> Upload Dealership / Compliance Document
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {!scope?.selfOnly && (
              <select value={dDealerId} onChange={(e) => setDDealerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                {dealersCatalog.map((d) => (
                  <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
                ))}
              </select>
            )}
            <select value={dType} onChange={(e) => setDType(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="CNIC Verification">CNIC Document</option>
              <option value="Business Registration">Business Registration</option>
              <option value="Showroom Photo">Showroom Photograph</option>
              <option value="Tax Certificate">Tax Certificate (NTN)</option>
              <option value="Agreement">Authorized Dealer Agreement</option>
            </select>
            <input value={dTitle} onChange={(e) => setDTitle(e.target.value)} placeholder="Document Title" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required type="file" onChange={(e) => setDFile(e.target.files?.[0] || null)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 text-slate-300" />
          </div>
          <div className="flex justify-end">
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Upload Document</button>
          </div>
        </form>
      )}

      {/* Documents List */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
          <span className="text-xs font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" /> Private Dealer Compliance Documents Vault ({docs.length})
          </span>
          <button type="button" onClick={load} className="text-slate-400 hover:text-white">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Title &amp; File</th>
              <th className="px-3 py-2.5">Type</th>
              <th className="px-3 py-2.5">Dealer</th>
              <th className="px-3 py-2.5">Verification Status</th>
              <th className="px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {docs.map((doc) => (
              <tr key={doc.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{doc.title}</div>
                  <div className="text-[10px] text-slate-400">{doc.original_filename} ({Math.max(1, Math.round(Number(doc.size_bytes || 0) / 1024))} KB)</div>
                </td>
                <td className="px-3 py-2.5 text-slate-300">{doc.doc_type}</td>
                <td className="px-3 py-2.5">
                  <div className="text-slate-200">{doc.dealer_name}</div>
                  <div className="font-mono text-[10px] text-slate-500">{doc.dealer_code}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className={doc.verification_status === 'Verified' ? 'text-emerald-400 font-semibold' : doc.verification_status === 'Rejected' ? 'text-rose-400' : 'text-amber-300'}>
                    {doc.verification_status}
                  </div>
                  {doc.reviewed_by && <div className="text-[10px] text-slate-500">By {doc.reviewed_by}</div>}
                </td>
                <td className="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={async () => {
                      const { blob, filename } = await api.downloadDealershipBlob(`/api/dealership-management/documents/${encodeURIComponent(doc.id)}/download`);
                      triggerBlobDownload(blob, filename);
                    }}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 inline-flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" /> Download
                  </button>
                  {scope?.canVerifyDocuments && doc.verification_status !== 'Verified' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.verifyDealershipDocument(doc.id, 'Verified');
                        setNotice(`Verified document ${doc.title}.`);
                        load();
                      }}
                      className="px-2 py-1 rounded bg-emerald-600/80 hover:bg-emerald-500 text-white"
                    >
                      Verify
                    </button>
                  )}
                  {scope?.canVerifyDocuments && doc.verification_status !== 'Rejected' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.verifyDealershipDocument(doc.id, 'Rejected', 'Document clarity/compliance review failed.');
                        setNotice(`Rejected document ${doc.title}.`);
                        load();
                      }}
                      className="px-2 py-1 rounded bg-rose-700/80 hover:bg-rose-600 text-white"
                    >
                      Reject
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {docs.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-slate-500">No documents uploaded yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
