# BYD PAKISTAN 360 — Technical Documentation & Architecture Manual

## 1. Executive System Overview
**BYD PAKISTAN 360** is a full-stack Enterprise Automotive Management Platform and Progressive Web Application (PWA). It provides a unified digital operational backbone for BYD electric vehicle owners, authorized 3S dealerships (Mega Motor Company / Hubco), certified service technicians, corporate executive management, and national charging infrastructure across Pakistan.

### Key Architectural Pillars:
1. **PWA Standalone Compliance**: Full offline resilience, Web App Manifest, auto-updating service worker, and in-app install prompts for Android, iOS Safari, and Chromium desktops.
2. **Server-Side AI Intelligence**: Powered by `@google/genai` with model `gemini-3.8-flash` on an Express backend proxy. Zero client-side API key exposure.
3. **Role-Based Access Control (RBAC)**: Strict separation across 7 personas (Customer, Technician, Service Manager, Sales Executive, Dealer Manager, Company Management, Super Admin).
4. **Persistent Data Layer**: High-performance local database engine backed by `localStorage` with Cloud Firestore schema compatibility and verifiable audit logging.

---

## 2. Main Modules & Capabilities

| Module | Core Functionality |
| :--- | :--- |
| **1. Company Dashboard** | Multi-city sales metrics, booked revenue in PKR (₨), delivery quotas, CSAT index, and Gemini AI C-suite briefing generation. |
| **2. Customer Portal** | Multi-vehicle garage, VIN registration, real-time battery status, service booking, live 7-step digital job card tracker, and downloadable PDF service certificates. |
| **3. Dealer Management** | Multi-dealership switcher (Clifton, Gulberg, Blue Area, Faisalabad), sales inquiry pipeline, test drive booking, stock allocation, and PDI handover checklist. |
| **4. Service Management** | Workshop scheduling, technician assignment, high-voltage safety lockouts, 138-cell Blade battery scanning, spare parts inventory, and billing quotations. |
| **5. Blade Battery Lab** | Cell voltage balance (float range 3.25V-3.32V, delta <0.025V), core thermal liquid-cooling monitoring, file upload diagnostic interpretation, and 8-Year warranty tracking. |
| **6. Charging Network** | Interactive Pakistan highway map (M-2 Bhera & Sukheke corridors, Karachi, Lahore, Islamabad), 60kW–240kW DC Fast Chargers, plug reservations, and rate calculation in PKR. |
| **7. Warranty Center** | 8-Year / 160,000 km battery & drive unit policy, 6-Year bumper-to-bumper vehicle coverage, claim submission with error codes, and manager approval workflows. |
| **8. AI Automotive Advisor**| Bilingual (English & Urdu) engineering advisor answering EV queries, range estimations, nail penetration test explanations, and maintenance tips via Gemini 3.8 Flash. |
| **9. Notifications** | Centralized alerts feed, multi-channel delivery simulator (In-App, WhatsApp/SMS to +92 numbers, Email), and administrator broadcast broadcasts. |
| **10. Analytics & Reports** | Monthly delivery trends, city-wise demand charts, service turnaround benchmarks, and single-click CSV and PDF report export. |
| **11. Admin Panel** | User management, dealership master data, vehicle VIN registry, tamper-evident audit logs, and Cloud Firestore security rules viewer. |
| **12. Business Pitch** | Corporate presentation deck for executive evaluation by BYD Pakistan and Mega Motor Company. |

---

## 3. Database Schema Structure (Firestore Compatible)

### Collection: `vehicles`
- `id`: string
- `vin`: string (17 characters)
- `model`: 'BYD Seal' | 'BYD Atto 3' | 'BYD Sealion 6' | 'BYD Shark 6'
- `variant`: string
- `licensePlate`: string (e.g. KHI-EV-924)
- `ownerId`: string
- `batteryCapacityKwh`: number
- `batteryHealthSoH`: number
- `batteryHealthSoC`: number
- `warrantyExpiryDate`: string (ISO date)
- `odometerKm`: number

### Collection: `serviceJobs`
- `id`: string
- `ticketNumber`: string (e.g. BYD-SVC-2026-101)
- `vin`: string
- `serviceType`: string
- `status`: 'Pending Approval' | 'Confirmed' | 'Vehicle Received' | 'In Progress' | 'Quality Check' | 'Ready for Pickup' | 'Completed'
- `technicianAssigned`: string
- `checklist`: object (hvLockChecked, bladeBatteryScanned, coolantLevelInspected, etc.)
- `partsUsed`: array of { partId, partName, quantity, unitPricePkr }
- `actualCostPkr`: number

### Collection: `chargingStations`
- `id`: string
- `name`: string
- `city`: 'Karachi' | 'Lahore' | 'Islamabad' | 'Motorways' | 'Faisalabad'
- `powerKw`: number (60, 120, 180, 240)
- `plugTypes`: array ('CCS2 Combo DC', 'GB/T DC', 'Type 2 AC')
- `pricePerKwhPkr`: number
- `availablePlugs`: number
- `totalPlugs`: number

### Collection: `warrantyClaims`
- `claimNumber`: string
- `vin`: string
- `componentCategory`: string
- `faultCode`: string
- `status`: 'Submitted' | 'Technical Review' | 'Approved' | 'Rejected'
- `claimAmountPkr`: number

---

## 4. Local Installation & Development Instructions

### Prerequisites
- Node.js version 20.x or 22.x
- npm version 9.x or higher

### Steps
1. Clone or extract the repository:
   ```bash
   cd /app/applet
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Ensure `.env` is configured with:
   ```bash
   GEMINI_API_KEY="your-google-ai-studio-api-key"
   ```
4. Start development full-stack server (runs Express with Vite middleware on port 3000):
   ```bash
   npm run dev
   ```
5. Open browser at `http://localhost:3000`.

---

## 5. Production Build & Deployment Instructions

1. Build the frontend client:
   ```bash
   npm run build
   ```
2. Run production server:
   ```bash
   npm start
   ```
3. Cloud Deployment (Cloud Run / Containerized environments):
   - Dev server and production server listen on port `3000` via `0.0.0.0`.
   - The production server serves pre-rendered static assets from `/dist` and serves `/api/*` endpoints via Express.
