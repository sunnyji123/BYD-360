import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Award,
  BarChart3,
  Briefcase,
  Building2,
  Calendar,
  Camera,
  CheckCircle2,
  Clock,
  DollarSign,
  Edit3,
  Eye,
  FileSpreadsheet,
  FolderLock,
  LayoutDashboard,
  Menu,
  RefreshCw,
  Search,
  Settings,
  ShieldAlert,
  UserCheck,
  UserPlus,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import { api } from '../../services/api';
import {
  AttendancePanel,
  LeaveManagementPanel,
  PayrollPanel,
  triggerBlobDownload,
} from './EmployeeOperationsPanels';
import {
  DocumentsPanel,
  EmployeeReportsPanel,
  EmployeeSettingsPanel,
  PerformancePanel,
  PositionsPanel,
} from './EmployeeGovernancePanels';

export type EmpHubSection =
  | 'dashboard'
  | 'employees'
  | 'add-employee'
  | 'attendance'
  | 'payroll'
  | 'leaves'
  | 'positions'
  | 'performance'
  | 'documents'
  | 'reports'
  | 'settings';

export const EmployeeManagementHub: React.FC<{ initialSection?: EmpHubSection }> = ({
  initialSection = 'dashboard',
}) => {
  const [activeSection, setActiveSection] = useState<EmpHubSection>(initialSection);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [banner, setBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [loading, setLoading] = useState(true);

  const [dashboard, setDashboard] = useState<any>(null);
  const [employees, setEmployees] = useState<any[]>([]);
  const [empFilters, setEmpFilters] = useState({
    q: '',
    branchId: 'ALL',
    department: 'ALL',
    status: 'ALL',
    employmentType: 'ALL',
  });

  // Profile View / Edit Drawer
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);
  const [selectedDetail, setSelectedDetail] = useState<any>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState<any>({});

  // Add New Employee state
  const [nextCode, setNextCode] = useState('BYD-PAK-EMP-0001');
  const [addForm, setAddForm] = useState({
    fullName: '',
    fatherName: '',
    dateOfBirth: '',
    gender: 'Male',
    cnicNumber: '',
    mobile: '',
    email: '',
    password: '',
    residentialAddress: '',
    countryId: 'PK',
    city: 'Lahore',
    companyId: '',
    branchId: '',
    department: 'Operations',
    jobPosition: 'Sales Executive',
    reportingManagerName: '',
    joiningDate: new Date().toISOString().slice(0, 10),
    employmentType: 'Full-Time Permanent',
    basicSalary: '120000',
    houseAllowance: '25000',
    medicalAllowance: '10000',
    transportAllowance: '10000',
    otherAllowances: '0',
    taxDeduction: '5000',
    emergencyContactName: '',
    emergencyContactPhone: '',
    bankName: '',
    bankAccountTitle: '',
    bankIban: '',
  });
  const [creatingEmp, setCreatingEmp] = useState(false);

  const notify = (type: 'success' | 'error', text: string) => {
    setBanner({ type, text });
  };

  const loadHub = async () => {
    setLoading(true);
    try {
      const [dashRes, empRes] = await Promise.all([
        api.getEmpMgmtDashboard(),
        api.getEmpMgmtEmployees({ limit: 200 }),
      ]);
      setDashboard(dashRes);
      setEmployees(empRes.employees || []);

      const defaultCompany = dashRes.referenceData?.companies?.[0]?.id || 'comp_byd_pk';
      const defaultCountry = dashRes.referenceData?.countries?.[0]?.id || 'PK';
      setAddForm((prev) => ({
        ...prev,
        companyId: prev.companyId || defaultCompany,
        countryId: prev.countryId || defaultCountry,
      }));

      if (dashRes.scope?.canManageProfiles) {
        try {
          const nc = await api.getEmpMgmtNextCode(defaultCompany, defaultCountry);
          setNextCode(nc.nextEmployeeCode);
        } catch {
          // ignore if restricted
        }
      }
    } catch (err: any) {
      notify('error', err?.message || 'Unable to load Employee Management Hub.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHub();
  }, []);

  const refreshNextCode = async (companyId: string, countryId: string) => {
    if (!dashboard?.scope?.canManageProfiles) return;
    try {
      const res = await api.getEmpMgmtNextCode(companyId, countryId);
      setNextCode(res.nextEmployeeCode);
    } catch {
      // ignore
    }
  };

  const openEmployeeProfile = async (empId: string) => {
    setSelectedEmpId(empId);
    setEditingProfile(false);
    setLoadingDetail(true);
    try {
      const detail = await api.getEmpMgmtEmployeeDetail(empId);
      setSelectedDetail(detail);
      const e = detail.employee;
      setProfileForm({
        fullName: e.fullName || '',
        fatherName: e.fatherName || '',
        dateOfBirth: e.dateOfBirth || '',
        gender: e.gender || 'Male',
        cnicNumber: e.rawCnic || '',
        mobile: e.mobile || '',
        residentialAddress: e.residentialAddress || '',
        countryId: e.countryId || 'PK',
        city: e.city || '',
        branchId: e.branchId || '',
        department: e.department || '',
        jobPosition: e.jobPosition || '',
        employmentType: e.employmentType || 'Full-Time Permanent',
        reportingManagerName: e.reportingManagerName || '',
        emergencyContactName: e.emergencyContactName || '',
        emergencyContactPhone: e.emergencyContactPhone || '',
        bankName: e.bankName || '',
        bankAccountTitle: e.bankAccountTitle || '',
        bankIban: e.bankIban || '',
        basicSalary: e.basicSalary ?? 0,
      });
    } catch (err: any) {
      notify('error', err?.message || 'Unable to load employee profile.');
      setSelectedEmpId(null);
    } finally {
      setLoadingDetail(false);
    }
  };

  const handleSaveProfileEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmpId) return;
    try {
      await api.updateEmpMgmtEmployee(selectedEmpId, {
        ...profileForm,
        branchId: profileForm.branchId || null,
        basicSalary: Number(profileForm.basicSalary || 0),
      });
      notify('success', 'Employee profile updated successfully.');
      setEditingProfile(false);
      await openEmployeeProfile(selectedEmpId);
      await loadHub();
    } catch (err: any) {
      notify('error', err?.message || 'Failed to update employee profile.');
    }
  };

  const handlePhotoUpload = async (file: File | undefined) => {
    if (!file || !selectedEmpId) return;
    try {
      await api.uploadEmpMgmtPhoto(selectedEmpId, file);
      notify('success', 'Profile photo updated.');
      await openEmployeeProfile(selectedEmpId);
      await loadHub();
    } catch (err: any) {
      notify('error', err?.message || 'Photo upload failed.');
    }
  };

  const handleStatusToggle = async (emp: any, nextStatus: 'Active' | 'Inactive' | 'Suspended' | 'On Leave') => {
    try {
      await api.updateEmpMgmtEmployeeStatus(emp.id, nextStatus, `Status set to ${nextStatus} via Employee Management`);
      notify('success', `${emp.employeeCode} status changed to ${nextStatus}.`);
      await loadHub();
      if (selectedEmpId === emp.id) {
        await openEmployeeProfile(emp.id);
      }
    } catch (err: any) {
      notify('error', err?.message || 'Status update failed.');
    }
  };

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingEmp(true);
    try {
      const res = await api.createEmpMgmtEmployee({
        ...addForm,
        branchId: addForm.branchId || null,
        basicSalary: Number(addForm.basicSalary || 0),
        houseAllowance: Number(addForm.houseAllowance || 0),
        medicalAllowance: Number(addForm.medicalAllowance || 0),
        transportAllowance: Number(addForm.transportAllowance || 0),
        otherAllowances: Number(addForm.otherAllowances || 0),
        taxDeduction: Number(addForm.taxDeduction || 0),
      });
      notify('success', `Employee registered cleanly with unique ID ${res.employeeCode}.`);
      setAddForm((p) => ({
        ...p,
        fullName: '',
        fatherName: '',
        cnicNumber: '',
        mobile: '',
        email: '',
        password: '',
        residentialAddress: '',
        emergencyContactName: '',
        emergencyContactPhone: '',
        bankIban: '',
      }));
      await loadHub();
      setActiveSection('employees');
    } catch (err: any) {
      notify('error', err?.message || 'Employee registration failed.');
    } finally {
      setCreatingEmp(false);
    }
  };

  const scope = dashboard?.scope || {};
  const metrics = dashboard?.metrics || {};
  const ref = dashboard?.referenceData || {
    companies: [],
    branches: [],
    departments: [],
    countries: [],
    leaveTypes: [],
    documentCategories: [],
  };

  const filteredEmployees = useMemo(() => {
    const q = empFilters.q.trim().toLowerCase();
    return employees.filter((e) => {
      if (empFilters.branchId !== 'ALL' && e.branchId !== empFilters.branchId) return false;
      if (empFilters.department !== 'ALL' && String(e.department).toLowerCase() !== empFilters.department.toLowerCase()) return false;
      if (empFilters.status !== 'ALL' && e.status !== empFilters.status) return false;
      if (empFilters.employmentType !== 'ALL' && String(e.employmentType).toLowerCase() !== empFilters.employmentType.toLowerCase()) return false;
      if (q) {
        const hay = `${e.employeeCode} ${e.fullName} ${e.email} ${e.mobile} ${e.department} ${e.jobPosition} ${e.branchName}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [employees, empFilters]);

  const deptOptions = useMemo(() => {
    const names = new Set<string>();
    (ref.departments || []).forEach((d: any) => d.name && names.add(d.name));
    employees.forEach((e) => e.department && names.add(e.department));
    ['Operations', 'Sales', 'EV Service & Technical', 'Finance & Payroll', 'Human Resources', 'Customer Support'].forEach((d) =>
      names.add(d)
    );
    return Array.from(names);
  }, [ref.departments, employees]);

  const sidebarItems: Array<{ id: EmpHubSection; label: string; icon: React.FC<{ className?: string }>; visible: boolean }> = [
    { id: 'dashboard', label: 'Employee Dashboard', icon: LayoutDashboard, visible: true },
    { id: 'employees', label: scope.selfOnly ? 'My Employee Record' : 'All Employees', icon: Users, visible: true },
    { id: 'add-employee', label: 'Add New Employee', icon: UserPlus, visible: Boolean(scope.canManageProfiles) },
    { id: 'attendance', label: 'Attendance', icon: Clock, visible: true },
    { id: 'payroll', label: 'Salary & Payroll', icon: DollarSign, visible: Boolean(scope.canAccessPayroll || scope.selfOnly) },
    { id: 'leaves', label: 'Leave Management', icon: Calendar, visible: true },
    { id: 'positions', label: 'Job Positions', icon: Briefcase, visible: Boolean(!scope.selfOnly || scope.canManagePositions) },
    { id: 'performance', label: 'Performance', icon: Award, visible: true },
    { id: 'documents', label: 'Employee Documents', icon: FolderLock, visible: true },
    { id: 'reports', label: 'Employee Reports', icon: FileSpreadsheet, visible: Boolean(scope.canExportReports || scope.canViewAllEmployees) },
    { id: 'settings', label: 'Settings', icon: Settings, visible: Boolean(!scope.selfOnly) },
  ];

  const visibleSidebar = sidebarItems.filter((item) => item.visible);
  const deptDist: Array<{ department: string; count: number }> = dashboard?.departmentDistribution || [];
  const maxDeptCount = Math.max(1, ...deptDist.map((d) => d.count));
  const trend7: Array<{ date: string; present: number; late: number; absent: number }> = dashboard?.attendance7DayTrend || [];
  const maxTrend = Math.max(1, ...trend7.map((t) => t.present + t.late + t.absent));

  return (
    <div className="rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-xl">
      {/* Top Module Bar */}
      <div className="px-4 sm:px-6 py-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileNavOpen((o) => !o)}
            className="lg:hidden p-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-300"
            aria-label="Toggle Employee Navigation"
          >
            <Menu className="w-4 h-4" />
          </button>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
              BYD PAKISTAN 360 • WORKFORCE &amp; HR COMMAND
            </div>
            <h1 className="text-base sm:text-lg font-extrabold text-white">Employee Management System</h1>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 font-mono text-slate-300">
            Scope: <strong className="text-amber-400 uppercase">{String(scope.mode || 'authorized').replace('_', ' ')}</strong>
          </span>
          <button
            type="button"
            onClick={loadHub}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-amber-500/50 text-slate-200 font-semibold flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
        </div>
      </div>

      {/* Feedback Banner */}
      {banner && (
        <div
          className={`mx-4 sm:mx-6 mt-4 px-4 py-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between gap-3 ${
            banner.type === 'success'
              ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
          }`}
        >
          <span>{banner.text}</span>
          <button type="button" onClick={() => setBanner(null)} className="text-slate-300 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Layout: Clean Left Sidebar + Active Workspace */}
      <div className="flex flex-col lg:flex-row min-h-[640px]">
        {/* Left Sidebar */}
        <aside
          className={`${
            mobileNavOpen ? 'block' : 'hidden'
          } lg:block lg:w-64 shrink-0 bg-slate-900/70 border-b lg:border-b-0 lg:border-r border-slate-800 p-3 space-y-1`}
        >
          {visibleSidebar.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveSection(item.id);
                  setMobileNavOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition text-left ${
                  active
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Active Workspace */}
        <main className="flex-1 p-4 sm:p-6 overflow-x-hidden">
          {loading && !dashboard ? (
            <div className="py-16 text-center text-xs text-slate-400">Loading real-time workforce metrics...</div>
          ) : (
            <>
              {/* 1. EMPLOYEE DASHBOARD */}
              {activeSection === 'dashboard' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider text-slate-400">Total Employees</div>
                      <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">{metrics.totalEmployees ?? 0}</div>
                      <div className="text-[11px] text-emerald-400 mt-1 font-mono tabular-nums">
                        Active: {metrics.activeEmployees ?? 0} • Inactive: {metrics.inactiveEmployees ?? 0}
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider text-slate-400">Present Today</div>
                      <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">{metrics.presentToday ?? 0}</div>
                      <div className="text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
                        Late: {metrics.lateArrivalsToday ?? 0} • Half Day: {metrics.halfDayToday ?? 0}
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider text-slate-400">On Leave &amp; Absent</div>
                      <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums mt-1">
                        {metrics.onLeaveEmployees ?? 0} / <span className="text-rose-400">{metrics.absentToday ?? 0}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
                        Pending Leaves: {metrics.pendingLeavesCount ?? 0}
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider text-slate-400">Monthly Payroll ({dashboard?.payPeriod})</div>
                      <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">
                        PKR {Number(metrics.totalMonthlyPayroll || 0).toLocaleString()}
                      </div>
                      <div className="text-[11px] text-emerald-400 mt-1 font-mono tabular-nums">
                        Disbursed: PKR {Number(metrics.paidMonthlyPayroll || 0).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  {/* Live DB Charts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white">7-Day Attendance Activity</h3>
                        <span className="text-[11px] text-slate-400">Real SQLite Logs</span>
                      </div>
                      <div className="grid grid-cols-7 gap-2 items-end h-36 pt-4">
                        {trend7.map((d) => {
                          const totalDay = d.present + d.late + d.absent;
                          const hPct = totalDay > 0 ? Math.max(14, Math.round((totalDay / maxTrend) * 100)) : 4;
                          return (
                            <div key={d.date} className="flex flex-col items-center gap-1 h-full justify-end">
                              <span className="text-[10px] font-mono tabular-nums text-slate-300">{totalDay}</span>
                              <div
                                className="w-full max-w-[28px] rounded-t-md bg-amber-500/80 border border-amber-400/50 transition-all"
                                style={{ height: `${hPct}%` }}
                                title={`${d.date}: Present ${d.present}, Late ${d.late}, Absent ${d.absent}`}
                              />
                              <span className="text-[10px] font-mono text-slate-500">{d.date.slice(5)}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white">Department Headcount Breakdown</h3>
                        <span className="text-[11px] text-slate-400">Expiring Docs (30d): {metrics.expiringDocsCount ?? 0}</span>
                      </div>
                      {deptDist.length === 0 ? (
                        <p className="text-xs text-slate-400 py-8 text-center">No active department headcount data yet.</p>
                      ) : (
                        <div className="space-y-2.5">
                          {deptDist.slice(0, 6).map((d) => (
                            <div key={d.department} className="space-y-1 text-xs">
                              <div className="flex justify-between">
                                <span className="text-slate-200 font-medium">{d.department}</span>
                                <span className="font-mono tabular-nums text-amber-400">{d.count}</span>
                              </div>
                              <div className="h-2 rounded-full bg-slate-950 overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-amber-500"
                                  style={{ width: `${Math.round((d.count / maxDeptCount) * 100)}%` }}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Quick Actions & Audit Stream */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                      <h3 className="text-sm font-bold text-white">Quick HR Actions</h3>
                      <div className="grid grid-cols-1 gap-2">
                        {scope.canManageProfiles && (
                          <button
                            type="button"
                            onClick={() => setActiveSection('add-employee')}
                            className="p-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-left flex items-center gap-2"
                          >
                            <UserPlus className="w-4 h-4" /> Register New Employee ({nextCode})
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setActiveSection('attendance')}
                          className="p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-semibold text-left flex items-center gap-2"
                        >
                          <Clock className="w-4 h-4 text-amber-400" /> Open Daily Attendance &amp; Shifts
                        </button>
                        {(scope.canAccessPayroll || scope.selfOnly) && (
                          <button
                            type="button"
                            onClick={() => setActiveSection('payroll')}
                            className="p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-semibold text-left flex items-center gap-2"
                          >
                            <DollarSign className="w-4 h-4 text-emerald-400" /> Payroll Runs &amp; PDF Payslips
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setActiveSection('leaves')}
                          className="p-2.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-white font-semibold text-left flex items-center gap-2"
                        >
                          <Calendar className="w-4 h-4 text-cyan-400" /> Leave Requests &amp; Balances
                        </button>
                      </div>
                    </div>

                    <div className="lg:col-span-2 p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                      <h3 className="text-sm font-bold text-white">Recent Employee Audit Activity</h3>
                      <div className="space-y-1.5 max-h-52 overflow-y-auto">
                        {(dashboard?.recentAuditLogs || []).length === 0 ? (
                          <p className="text-slate-400">No recent employee module actions logged.</p>
                        ) : (
                          (dashboard?.recentAuditLogs || []).map((l: any) => (
                            <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-wrap justify-between gap-2">
                              <div>
                                <span className="font-mono font-bold text-amber-400 mr-2">{l.action}</span>
                                <span className="text-slate-300">{l.details}</span>
                              </div>
                              <span className="font-mono text-[11px] text-slate-500">
                                {l.actor_name} • {String(l.created_at).slice(0, 16).replace('T', ' ')}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. ALL EMPLOYEES DIRECTORY */}
              {activeSection === 'employees' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-bold text-white">Employee Directory ({filteredEmployees.length})</h2>
                      <p className="text-xs text-slate-400">Unique system IDs, profile verification, status controls &amp; CNIC privacy masking.</p>
                    </div>
                    {scope.canManageProfiles && (
                      <button
                        type="button"
                        onClick={() => setActiveSection('add-employee')}
                        className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
                      >
                        <UserPlus className="w-3.5 h-3.5" /> Add New Employee
                      </button>
                    )}
                  </div>

                  {/* Search & Filter Bar */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
                    <div className="relative lg:col-span-2">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={empFilters.q}
                        onChange={(e) => setEmpFilters({ ...empFilters, q: e.target.value })}
                        placeholder="Search by Name, Employee ID, Email, CNIC..."
                        className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white"
                      />
                    </div>
                    <select
                      value={empFilters.branchId}
                      onChange={(e) => setEmpFilters({ ...empFilters, branchId: e.target.value })}
                      className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white"
                    >
                      <option value="ALL">All Branches</option>
                      {(ref.branches || []).map((b: any) => (
                        <option key={b.id} value={b.id}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                    <select
                      value={empFilters.department}
                      onChange={(e) => setEmpFilters({ ...empFilters, department: e.target.value })}
                      className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white"
                    >
                      <option value="ALL">All Departments</option>
                      {deptOptions.map((d) => (
                        <option key={d} value={d}>
                          {d}
                        </option>
                      ))}
                    </select>
                    <select
                      value={empFilters.status}
                      onChange={(e) => setEmpFilters({ ...empFilters, status: e.target.value })}
                      className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white"
                    >
                      <option value="ALL">All Statuses</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                      <option value="On Leave">On Leave</option>
                      <option value="Suspended">Suspended</option>
                    </select>
                  </div>

                  {/* Table */}
                  <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
                        <tr>
                          <th className="py-2.5 px-3">Employee &amp; ID</th>
                          <th className="py-2.5 px-3">Department &amp; Position</th>
                          <th className="py-2.5 px-3">Branch &amp; City</th>
                          <th className="py-2.5 px-3">Contact &amp; CNIC</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80">
                        {filteredEmployees.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-10 text-center text-slate-400">
                              No employees match the active search or filters.
                            </td>
                          </tr>
                        ) : (
                          filteredEmployees.map((emp) => (
                            <tr key={emp.id} className="hover:bg-slate-950/60">
                              <td className="py-2.5 px-3">
                                <div className="flex items-center gap-2.5">
                                  {emp.photoUrl ? (
                                    <img src={emp.photoUrl} alt={emp.fullName} className="w-8 h-8 rounded-lg object-cover border border-slate-700" />
                                  ) : (
                                    <div className="w-8 h-8 rounded-lg bg-slate-800 text-amber-400 font-bold flex items-center justify-center">
                                      {String(emp.fullName || 'E').slice(0, 2).toUpperCase()}
                                    </div>
                                  )}
                                  <div>
                                    <div className="font-semibold text-white">{emp.fullName}</div>
                                    <div className="text-[11px] font-mono text-amber-400">{emp.employeeCode}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="py-2.5 px-3">
                                <div className="text-slate-200">{emp.jobPosition}</div>
                                <div className="text-[11px] text-slate-400">{emp.department}</div>
                              </td>
                              <td className="py-2.5 px-3 text-slate-300">
                                <div>{emp.branchName || 'Head Office'}</div>
                                <div className="text-[11px] text-slate-500">{emp.city || emp.countryName}</div>
                              </td>
                              <td className="py-2.5 px-3 text-slate-300">
                                <div>{emp.email}</div>
                                <div className="text-[11px] font-mono text-slate-400">
                                  {emp.mobile} • CNIC: {emp.cnicNumber}
                                </div>
                              </td>
                              <td className="py-2.5 px-3">
                                <span
                                  className={`font-semibold ${
                                    emp.status === 'Active'
                                      ? 'text-emerald-400'
                                      : emp.status === 'On Leave'
                                      ? 'text-amber-400'
                                      : 'text-rose-400'
                                  }`}
                                >
                                  {emp.status}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <div className="inline-flex gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => openEmployeeProfile(emp.id)}
                                    className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white font-semibold inline-flex items-center gap-1"
                                  >
                                    <Eye className="w-3 h-3" /> Profile
                                  </button>
                                  {scope.canToggleStatus && (
                                    <button
                                      type="button"
                                      onClick={() => handleStatusToggle(emp, emp.status === 'Active' ? 'Inactive' : 'Active')}
                                      className={`px-2.5 py-1 rounded font-semibold ${
                                        emp.status === 'Active'
                                          ? 'bg-rose-950 hover:bg-rose-900 text-rose-200 border border-rose-800'
                                          : 'bg-emerald-950 hover:bg-emerald-900 text-emerald-200 border border-emerald-800'
                                      }`}
                                    >
                                      {emp.status === 'Active' ? 'Deactivate' : 'Activate'}
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 3. ADD NEW EMPLOYEE */}
              {activeSection === 'add-employee' && scope.canManageProfiles && (
                <form onSubmit={handleCreateEmployee} className="space-y-5 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="text-lg font-bold text-white">Register New BYD Pakistan 360 Employee</h2>
                      <p className="text-slate-400">
                        Automatically assigns sequential permanent ID{' '}
                        <span className="font-mono font-bold text-amber-400">{nextCode}</span> &amp; initializes salary structure + leave quotas.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                    <div className="font-bold text-amber-400 uppercase tracking-wider">1. Personal &amp; Identity Details</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-slate-400 mb-1">Full Legal Name *</label>
                        <input
                          type="text"
                          required
                          value={addForm.fullName}
                          onChange={(e) => setAddForm({ ...addForm, fullName: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Father Name</label>
                        <input
                          type="text"
                          value={addForm.fatherName}
                          onChange={(e) => setAddForm({ ...addForm, fatherName: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">CNIC / National ID</label>
                        <input
                          type="text"
                          value={addForm.cnicNumber}
                          onChange={(e) => setAddForm({ ...addForm, cnicNumber: e.target.value })}
                          placeholder="e.g. 35202-1234567-1"
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Official Email *</label>
                        <input
                          type="email"
                          required
                          value={addForm.email}
                          onChange={(e) => setAddForm({ ...addForm, email: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Mobile Number *</label>
                        <input
                          type="text"
                          required
                          value={addForm.mobile}
                          onChange={(e) => setAddForm({ ...addForm, mobile: e.target.value })}
                          placeholder="+923001234567"
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Portal Login Password * (10+ strong)</label>
                        <input
                          type="password"
                          required
                          value={addForm.password}
                          onChange={(e) => setAddForm({ ...addForm, password: e.target.value })}
                          placeholder="Min 10 chars (Upper/Lower/Digit/Symbol)"
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Date of Birth</label>
                        <input
                          type="date"
                          value={addForm.dateOfBirth}
                          onChange={(e) => setAddForm({ ...addForm, dateOfBirth: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Gender</label>
                        <select
                          value={addForm.gender}
                          onChange={(e) => setAddForm({ ...addForm, gender: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        >
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Residential Address</label>
                        <input
                          type="text"
                          value={addForm.residentialAddress}
                          onChange={(e) => setAddForm({ ...addForm, residentialAddress: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                    <div className="font-bold text-amber-400 uppercase tracking-wider">2. Organization, Branch &amp; Role Placement</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-slate-400 mb-1">Country</label>
                        <select
                          value={addForm.countryId}
                          onChange={(e) => {
                            const cid = e.target.value;
                            setAddForm({ ...addForm, countryId: cid });
                            refreshNextCode(addForm.companyId, cid);
                          }}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        >
                          {(ref.countries || []).map((c: any) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Company *</label>
                        <select
                          required
                          value={addForm.companyId}
                          onChange={(e) => {
                            const comp = e.target.value;
                            setAddForm({ ...addForm, companyId: comp, branchId: '' });
                            refreshNextCode(comp, addForm.countryId);
                          }}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        >
                          {(ref.companies || []).map((c: any) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Branch</label>
                        <select
                          value={addForm.branchId}
                          onChange={(e) => setAddForm({ ...addForm, branchId: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        >
                          <option value="">Head Office (Unassigned Branch)</option>
                          {(ref.branches || [])
                            .filter((b: any) => !addForm.companyId || b.company_id === addForm.companyId)
                            .map((b: any) => (
                              <option key={b.id} value={b.id}>
                                {b.name} ({b.city})
                              </option>
                            ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">City</label>
                        <input
                          type="text"
                          value={addForm.city}
                          onChange={(e) => setAddForm({ ...addForm, city: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Department *</label>
                        <input
                          type="text"
                          list="byd-dept-list"
                          required
                          value={addForm.department}
                          onChange={(e) => setAddForm({ ...addForm, department: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                        <datalist id="byd-dept-list">
                          {deptOptions.map((d) => (
                            <option key={d} value={d} />
                          ))}
                        </datalist>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Job Position / Designation *</label>
                        <input
                          type="text"
                          required
                          value={addForm.jobPosition}
                          onChange={(e) => setAddForm({ ...addForm, jobPosition: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Employment Type</label>
                        <select
                          value={addForm.employmentType}
                          onChange={(e) => setAddForm({ ...addForm, employmentType: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        >
                          <option value="Full-Time Permanent">Full-Time Permanent</option>
                          <option value="Contract">Contract</option>
                          <option value="Probation">Probation</option>
                          <option value="Part-Time">Part-Time</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Joining Date</label>
                        <input
                          type="date"
                          value={addForm.joiningDate}
                          onChange={(e) => setAddForm({ ...addForm, joiningDate: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                    <div className="font-bold text-amber-400 uppercase tracking-wider">3. Compensation, Bank &amp; Emergency Contact</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-slate-400 mb-1">Basic Salary</label>
                        <input
                          type="number"
                          min="0"
                          value={addForm.basicSalary}
                          onChange={(e) => setAddForm({ ...addForm, basicSalary: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">House Allowance</label>
                        <input
                          type="number"
                          min="0"
                          value={addForm.houseAllowance}
                          onChange={(e) => setAddForm({ ...addForm, houseAllowance: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Medical Allowance</label>
                        <input
                          type="number"
                          min="0"
                          value={addForm.medicalAllowance}
                          onChange={(e) => setAddForm({ ...addForm, medicalAllowance: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Transport Allowance</label>
                        <input
                          type="number"
                          min="0"
                          value={addForm.transportAllowance}
                          onChange={(e) => setAddForm({ ...addForm, transportAllowance: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Bank Name</label>
                        <input
                          type="text"
                          value={addForm.bankName}
                          onChange={(e) => setAddForm({ ...addForm, bankName: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Bank IBAN / Account No.</label>
                        <input
                          type="text"
                          value={addForm.bankIban}
                          onChange={(e) => setAddForm({ ...addForm, bankIban: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Emergency Contact Name</label>
                        <input
                          type="text"
                          value={addForm.emergencyContactName}
                          onChange={(e) => setAddForm({ ...addForm, emergencyContactName: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Emergency Contact Phone</label>
                        <input
                          type="text"
                          value={addForm.emergencyContactPhone}
                          onChange={(e) => setAddForm({ ...addForm, emergencyContactPhone: e.target.value })}
                          className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={creatingEmp}
                      className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs"
                    >
                      {creatingEmp ? 'Registering Employee...' : `Register Employee (${nextCode})`}
                    </button>
                  </div>
                </form>
              )}

              {/* 4. ATTENDANCE */}
              {activeSection === 'attendance' && (
                <AttendancePanel
                  scope={scope}
                  employees={employees}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  leaveTypes={ref.leaveTypes || []}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 5. SALARY & PAYROLL */}
              {activeSection === 'payroll' && (
                <PayrollPanel
                  scope={scope}
                  employees={employees}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  leaveTypes={ref.leaveTypes || []}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 6. LEAVE MANAGEMENT */}
              {activeSection === 'leaves' && (
                <LeaveManagementPanel
                  scope={scope}
                  employees={employees}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  leaveTypes={ref.leaveTypes || ['Annual Leave', 'Casual Leave', 'Sick Leave', 'Emergency Leave', 'Unpaid Leave']}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 7. JOB POSITIONS */}
              {activeSection === 'positions' && (
                <PositionsPanel
                  scope={scope}
                  employees={employees}
                  companies={ref.companies || []}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  documentCategories={ref.documentCategories || []}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 8. PERFORMANCE */}
              {activeSection === 'performance' && (
                <PerformancePanel
                  scope={scope}
                  employees={employees}
                  companies={ref.companies || []}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  documentCategories={ref.documentCategories || []}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 9. DOCUMENTS */}
              {activeSection === 'documents' && (
                <DocumentsPanel
                  scope={scope}
                  employees={employees}
                  companies={ref.companies || []}
                  branches={ref.branches || []}
                  departments={ref.departments || []}
                  documentCategories={ref.documentCategories || ['CNIC', 'Passport', 'Employment Contract', 'Appointment Letter']}
                  onNotify={notify}
                  onRefreshDashboard={loadHub}
                />
              )}

              {/* 10. REPORTS */}
              {activeSection === 'reports' && <EmployeeReportsPanel scope={scope} onNotify={notify} />}

              {/* 11. SETTINGS & AUDIT LOGS */}
              {activeSection === 'settings' && <EmployeeSettingsPanel onNotify={notify} />}
            </>
          )}
        </main>
      </div>

      {/* EMPLOYEE FULL PROFILE MODAL / DRAWER */}
      {selectedEmpId && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-4xl rounded-2xl bg-slate-900 border border-slate-700 p-5 sm:p-6 space-y-5 max-h-[90vh] overflow-y-auto text-xs">
            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="relative">
                  {selectedDetail?.employee?.photoUrl ? (
                    <img
                      src={selectedDetail.employee.photoUrl}
                      alt={selectedDetail.employee.fullName}
                      className="w-14 h-14 rounded-xl object-cover border border-amber-500/40"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center text-lg font-extrabold text-amber-400">
                      {String(selectedDetail?.employee?.fullName || 'BYD').slice(0, 2).toUpperCase()}
                    </div>
                  )}
                  {(scope.canManageProfiles || scope.selfEmployeeId === selectedEmpId) && (
                    <label className="absolute -bottom-1.5 -right-1.5 p-1 rounded-full bg-amber-500 text-slate-950 cursor-pointer shadow">
                      <Camera className="w-3 h-3" />
                      <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => handlePhotoUpload(e.target.files?.[0])} />
                    </label>
                  )}
                </div>
                <div>
                  <div className="font-mono font-bold text-amber-400">{selectedDetail?.employee?.employeeCode}</div>
                  <h3 className="text-lg font-bold text-white">{selectedDetail?.employee?.fullName || 'Loading...'}</h3>
                  <div className="text-slate-400">
                    {selectedDetail?.employee?.jobPosition} • {selectedDetail?.employee?.department} •{' '}
                    {selectedDetail?.employee?.branchName}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {scope.canManageProfiles && selectedDetail && (
                  <button
                    type="button"
                    onClick={() => setEditingProfile((v) => !v)}
                    className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold inline-flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> {editingProfile ? 'Cancel Edit' : 'Edit Profile'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedEmpId(null);
                    setSelectedDetail(null);
                  }}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {loadingDetail || !selectedDetail ? (
              <div className="py-12 text-center text-slate-400">Loading complete employee dossier...</div>
            ) : editingProfile ? (
              <form onSubmit={handleSaveProfileEdit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={profileForm.fullName}
                      onChange={(e) => setProfileForm({ ...profileForm, fullName: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Father Name</label>
                    <input
                      type="text"
                      value={profileForm.fatherName}
                      onChange={(e) => setProfileForm({ ...profileForm, fatherName: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">CNIC</label>
                    <input
                      type="text"
                      value={profileForm.cnicNumber}
                      onChange={(e) => setProfileForm({ ...profileForm, cnicNumber: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Mobile</label>
                    <input
                      type="text"
                      value={profileForm.mobile}
                      onChange={(e) => setProfileForm({ ...profileForm, mobile: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Department</label>
                    <input
                      type="text"
                      value={profileForm.department}
                      onChange={(e) => setProfileForm({ ...profileForm, department: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Job Position</label>
                    <input
                      type="text"
                      value={profileForm.jobPosition}
                      onChange={(e) => setProfileForm({ ...profileForm, jobPosition: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">City</label>
                    <input
                      type="text"
                      value={profileForm.city}
                      onChange={(e) => setProfileForm({ ...profileForm, city: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Basic Salary</label>
                    <input
                      type="number"
                      min="0"
                      value={profileForm.basicSalary}
                      onChange={(e) => setProfileForm({ ...profileForm, basicSalary: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Emergency Phone</label>
                    <input
                      type="text"
                      value={profileForm.emergencyContactPhone}
                      onChange={(e) => setProfileForm({ ...profileForm, emergencyContactPhone: e.target.value })}
                      className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button type="submit" className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold">
                    Save Profile Changes
                  </button>
                </div>
              </form>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="font-bold text-amber-400 uppercase tracking-wider">Identity &amp; Employment</div>
                  <div className="grid grid-cols-2 gap-y-1.5 text-slate-300">
                    <span className="text-slate-500">Father Name:</span>
                    <span>{selectedDetail.employee.fatherName || '—'}</span>
                    <span className="text-slate-500">CNIC:</span>
                    <span className="font-mono">{selectedDetail.employee.cnicNumber}</span>
                    <span className="text-slate-500">Email:</span>
                    <span>{selectedDetail.employee.email}</span>
                    <span className="text-slate-500">Mobile:</span>
                    <span className="font-mono">{selectedDetail.employee.mobile}</span>
                    <span className="text-slate-500">Joining Date:</span>
                    <span className="font-mono">{String(selectedDetail.employee.joiningDate || '').slice(0, 10)}</span>
                    <span className="text-slate-500">Employment Type:</span>
                    <span>{selectedDetail.employee.employmentType}</span>
                    <span className="text-slate-500">Status:</span>
                    <span className="font-bold text-emerald-400">{selectedDetail.employee.status}</span>
                    <span className="text-slate-500">Basic Salary:</span>
                    <span className="font-mono font-bold text-white">
                      {selectedDetail.employee.basicSalary !== null
                        ? `${selectedDetail.employee.currency} ${Number(selectedDetail.employee.basicSalary).toLocaleString()}`
                        : 'Restricted'}
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="font-bold text-amber-400 uppercase tracking-wider">Leave Balance &amp; Recent Career History</div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 font-mono tabular-nums text-slate-200">
                    Annual: {selectedDetail.leaveBalance.annual.remaining}/{selectedDetail.leaveBalance.annual.total} • Sick:{' '}
                    {selectedDetail.leaveBalance.sick.remaining}/{selectedDetail.leaveBalance.sick.total} • Casual:{' '}
                    {selectedDetail.leaveBalance.casual.remaining}/{selectedDetail.leaveBalance.casual.total}
                  </div>
                  <div className="space-y-1.5 max-h-40 overflow-y-auto pt-1">
                    {(selectedDetail.history || []).map((h: any) => (
                      <div key={h.id} className="p-2 rounded bg-slate-900 border border-slate-800">
                        <span className="text-amber-400 font-semibold mr-1.5">{h.change_type}:</span>
                        <span className="text-slate-300">{h.new_value}</span>
                        <span className="text-slate-500 ml-2">({h.effective_date})</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
