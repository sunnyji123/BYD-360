import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Users,
  ShieldCheck,
  Building2,
  Car,
  Receipt,
  DollarSign,
  Target,
  FileText,
  Menu,
  X,
  Plus,
  Search,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Mail,
  Phone,
  Eye,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';
import { api } from '../../services/api';
import { ShowroomsPanel, DealerInventoryPanel, DealerSalesPanel } from './DealershipOperationsPanels';
import {
  DealerCommissionsPanel,
  DealerTargetsPerformancePanel,
  DealerDocumentsReportsPanel,
} from './DealershipGovernancePanels';

export type DealershipHubSection =
  | 'dashboard'
  | 'dealers'
  | 'verification'
  | 'showrooms'
  | 'inventory'
  | 'sales'
  | 'commissions'
  | 'targets'
  | 'documents';

const fmtPkr = (n: number | string | undefined) =>
  `PKR ${Number(n || 0).toLocaleString('en-PK')}`;

export const DealershipManagementHub: React.FC<{ initialSection?: DealershipHubSection }> = ({
  initialSection = 'dashboard',
}) => {
  const [section, setSection] = useState<DealershipHubSection>(initialSection);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [dashboard, setDashboard] = useState<any>(null);
  const [dealersList, setDealersList] = useState<any[]>([]);
  const [verificationData, setVerificationData] = useState<{ dealers: any[]; documents: any[]; history: any[] }>({
    dealers: [],
    documents: [],
    history: [],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Directory filters & pagination
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [verificationFilter, setVerificationFilter] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 8;

  // Registration Form State
  const [showRegister, setShowRegister] = useState(false);
  const [nextCodes, setNextCodes] = useState<{ dealerCode: string; showroomCode: string }>({ dealerCode: '', showroomCode: '' });
  const [rBusinessName, setRBusinessName] = useState('');
  const [rOwnerName, setROwnerName] = useState('');
  const [rEmail, setREmail] = useState('');
  const [rMobile, setRMobile] = useState('+92 300 ');
  const [rCnic, setRCnic] = useState('');
  const [rCompanyId, setRCompanyId] = useState('comp_byd_pk');
  const [rCountryId, setRCountryId] = useState('PK');
  const [rProvince, setRProvince] = useState('Sindh');
  const [rCity, setRCity] = useState('Karachi');
  const [rAddress, setRAddress] = useState('');
  const [rRegNo, setRRegNo] = useState('');
  const [rTaxNtn, setRTaxNtn] = useState('');
  const [rCategory, setRCategory] = useState('3S Flagship Centre');
  const [rShowroomName, setRShowroomName] = useState('');
  const [rApproveNow, setRApproveNow] = useState(false);

  // Detail / Verification Modal State
  const [detailData, setDetailData] = useState<any>(null);
  const [otpInput, setOtpInput] = useState('');
  const [otpHint, setOtpHint] = useState('');
  const [rejectTarget, setRejectTarget] = useState<{ id: string; code: string; action: 'reject' | 'suspend' } | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getDealershipDashboard();
      setDashboard(res);
      if (res.catalogs?.companies?.[0]?.id && !rCompanyId) {
        setRCompanyId(res.catalogs.companies[0].id);
      }
    } catch (err: any) {
      setError(err?.message || 'Access denied or failed to load Dealership Management Hub.');
    } finally {
      setLoading(false);
    }
  }, [rCompanyId]);

  const loadDealers = useCallback(async () => {
    try {
      const res = await api.getDealershipDealers({
        q: q || undefined,
        status: statusFilter || undefined,
        verification: verificationFilter || undefined,
      });
      setDealersList(res.dealers || []);
      setPage(1);
    } catch {
      // handled at hub level
    }
  }, [q, statusFilter, verificationFilter]);

  const loadVerification = useCallback(async () => {
    try {
      const res = await api.getDealershipVerificationQueue();
      setVerificationData(res);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    if (section === 'dealers') loadDealers();
    if (section === 'verification') loadVerification();
  }, [section, loadDealers, loadVerification]);

  useEffect(() => {
    if (showRegister) {
      api
        .getNextDealerAndShowroomCode(rCountryId, rCity)
        .then((res) => setNextCodes(res))
        .catch(() => {});
    }
  }, [showRegister, rCountryId, rCity]);

  const scope = dashboard?.scope || {};
  const metrics = dashboard?.metrics || {};
  const catalogs = dashboard?.catalogs || { companies: [], countries: [], branches: [], dealers: [] };

  const navItems: Array<{ id: DealershipHubSection; label: string; icon: any }> = [
    { id: 'dashboard', label: 'Dealership Dashboard', icon: LayoutDashboard },
    { id: 'dealers', label: 'Dealers & Registration', icon: Users },
    ...(scope?.canVerifyDealers
      ? [{ id: 'verification' as DealershipHubSection, label: `Verification Queue (${metrics.pendingVerification || 0})`, icon: ShieldCheck }]
      : []),
    { id: 'showrooms', label: 'Showrooms', icon: Building2 },
    { id: 'inventory', label: 'Dealer Inventory', icon: Car },
    { id: 'sales', label: 'Sales & Invoices', icon: Receipt },
    { id: 'commissions', label: 'Commissions & Rules', icon: DollarSign },
    { id: 'targets', label: 'Targets & Performance', icon: Target },
    { id: 'documents', label: 'Documents & Reports', icon: FileText },
  ];

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.registerDealershipDealer({
        businessName: rBusinessName,
        ownerContactName: rOwnerName,
        email: rEmail,
        mobile: rMobile,
        cnicNumber: rCnic,
        companyId: rCompanyId,
        countryId: rCountryId,
        province: rProvince,
        city: rCity,
        address: rAddress,
        registrationNo: rRegNo,
        taxIdNtn: rTaxNtn,
        category: rCategory,
        showroomName: rShowroomName || `${rBusinessName} Flagship Showroom`,
        approveImmediately: rApproveNow,
      });
      setNotice(`Registered dealer ${res.dealer?.dealer_code} (${res.dealer?.business_name}) with showroom ${res.showroom?.showroom_code}.`);
      setShowRegister(false);
      setRBusinessName('');
      setROwnerName('');
      setREmail('');
      setRCnic('');
      setRAddress('');
      setRShowroomName('');
      await Promise.all([loadDashboard(), loadDealers()]);
    } catch (err: any) {
      setError(err?.message || 'Registration failed.');
    }
  };

  const openDetail = async (id: string) => {
    setError('');
    setOtpHint('');
    setOtpInput('');
    try {
      const res = await api.getDealershipDealerDetail(id);
      setDetailData(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to load dealer profile.');
    }
  };

  const pagedDealers = dealersList.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.max(1, Math.ceil(dealersList.length / pageSize));
  const monthlySeries: any[] = dashboard?.monthlySeries || [];
  const maxMonthlyRev = Math.max(1, ...monthlySeries.map((m) => Number(m.revenuePkr || 0)));

  if (!dashboard && error) {
    return (
      <div className="rounded-2xl bg-slate-900 border border-rose-500/40 p-6 text-xs text-rose-200 flex items-center gap-3">
        <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
        <div>
          <div className="font-bold text-white">Dealership Management Access Restricted</div>
          <div className="text-rose-300 mt-0.5">{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-2xl text-slate-100">
      {/* Top Header Strip */}
      <div className="flex items-center justify-between px-4 sm:px-6 py-4 bg-slate-950 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
              BYD PAKISTAN 360 • ENTERPRISE DEALERSHIP OPERATIONS
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white">
              Dealership Management Module
            </h2>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="hidden sm:inline font-mono text-[11px] px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
            Scope: {scope?.mode || 'loading'}
          </span>
          <button
            type="button"
            onClick={() => {
              loadDashboard();
              if (section === 'dealers') loadDealers();
              if (section === 'verification') loadVerification();
            }}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            title="Refresh Hub"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row min-h-[620px]">
        {/* Responsive Sidebar Navigation */}
        <aside
          className={`${
            mobileMenuOpen ? 'block' : 'hidden'
          } lg:block w-full lg:w-64 shrink-0 bg-slate-950/95 border-b lg:border-b-0 lg:border-r border-slate-800 p-3 space-y-1`}
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold transition-colors text-left ${
                  active
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Main Workspace Content */}
        <main className="flex-1 p-4 sm:p-6 space-y-5 overflow-x-hidden">
          {error && (
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          {notice && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{notice}</span>
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION 1: DEALERSHIP OVERVIEW DASHBOARD */}
          {/* ============================================================== */}
          {section === 'dashboard' && (
            <div className="space-y-5">
              {/* 8 Enterprise Metrics from Real DB */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: 'Total Dealers', val: metrics.totalDealers ?? 0, sub: `${metrics.suspendedOrRejected ?? 0} suspended/rejected`, color: 'text-white' },
                  { label: 'Verified Dealers', val: metrics.verifiedDealers ?? 0, sub: 'Active compliance', color: 'text-emerald-400' },
                  { label: 'Pending Verification', val: metrics.pendingVerification ?? 0, sub: `${metrics.pendingDocsCount ?? 0} docs pending`, color: 'text-amber-300' },
                  { label: 'Active Showrooms', val: metrics.activeShowrooms ?? 0, sub: `of ${metrics.totalShowrooms ?? 0} registered`, color: 'text-blue-300' },
                  { label: 'Total Dealer Inventory', val: metrics.totalInventoryUnits ?? 0, sub: `${metrics.availableUnits ?? 0} available • ${metrics.soldUnits ?? 0} sold`, color: 'text-white' },
                  { label: 'Total Dealer Sales', val: fmtPkr(metrics.totalSalesRevenuePkr), sub: `${metrics.totalSalesCount ?? 0} active transactions`, color: 'text-emerald-300' },
                  { label: 'Pending Commissions', val: fmtPkr(metrics.pendingCommissionPkr), sub: `${fmtPkr(metrics.paidCommissionPkr)} paid out`, color: 'text-amber-300' },
                  { label: 'Sales Target Achievement', val: `${metrics.targetAchievementPct ?? 0}%`, sub: `${metrics.totalAchievedForTargets ?? 0}/${metrics.totalTargetUnits ?? 0} quota units`, color: 'text-amber-400' },
                ].map((k) => (
                  <div key={k.label} className="rounded-xl bg-slate-950 border border-slate-800 p-4">
                    <div className="text-[11px] text-slate-400 font-medium">{k.label}</div>
                    <div className={`text-lg sm:text-xl font-mono font-bold mt-1 ${k.color}`}>{k.val}</div>
                    <div className="text-[10px] text-slate-500 mt-1">{k.sub}</div>
                  </div>
                ))}
              </div>

              {/* Charts Row: Monthly Revenue Bar Chart + Model Stock Mix */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="rounded-xl bg-slate-950 border border-slate-800 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-white">Monthly Dealership Sales Revenue</div>
                    <span className="text-[10px] font-mono text-slate-400">Live DB Sales Series</span>
                  </div>
                  {monthlySeries.length > 0 ? (
                    <div className="space-y-2 pt-1">
                      {monthlySeries.map((m) => (
                        <div key={m.month} className="space-y-1 text-xs">
                          <div className="flex justify-between font-mono text-[11px]">
                            <span className="text-slate-300">{m.month} ({m.units} units)</span>
                            <span className="text-emerald-300">{fmtPkr(m.revenuePkr)}</span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
                            <div
                              className="h-full bg-amber-400 rounded-full"
                              style={{ width: `${Math.max(4, Math.round((Number(m.revenuePkr) / maxMonthlyRev) * 100))}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-slate-500 py-8 text-center">No active monthly sales data recorded yet.</div>
                  )}
                </div>

                <div className="rounded-xl bg-slate-950 border border-slate-800 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-bold text-white">BYD Model Inventory vs Sales Mix</div>
                    <span className="text-[10px] font-mono text-slate-400">Available / Sold</span>
                  </div>
                  <div className="space-y-2.5">
                    {(dashboard?.modelBreakdown || []).map((mb: any) => (
                      <div key={mb.model} className="flex items-center justify-between text-xs border-b border-slate-800/60 pb-2">
                        <div>
                          <div className="font-semibold text-white">{mb.model}</div>
                          <div className="text-[10px] font-mono text-slate-400">
                            {mb.availableUnits} in stock • {mb.soldUnits} sold
                          </div>
                        </div>
                        <div className="font-mono text-amber-300 font-semibold">{fmtPkr(mb.revenuePkr)}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recent Audit Logs */}
              <div className="rounded-xl bg-slate-950 border border-slate-800 p-4 space-y-2.5">
                <div className="text-xs font-bold text-white">Recent Dealership Governance &amp; Operational Audit Trail</div>
                <div className="space-y-1.5 max-h-52 overflow-y-auto text-[11px]">
                  {(dashboard?.recentAuditLogs || []).map((log: any) => (
                    <div key={log.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 py-1.5 border-b border-slate-800/60 text-slate-300">
                      <div>
                        <span className="font-mono text-amber-300 mr-2">{log.action}</span>
                        <span>{log.details}</span>
                      </div>
                      <div className="font-mono text-[10px] text-slate-500 whitespace-nowrap">
                        {log.actor_name} ({log.actor_role}) • {String(log.created_at).slice(0, 16).replace('T', ' ')}
                      </div>
                    </div>
                  ))}
                  {(!dashboard?.recentAuditLogs || dashboard.recentAuditLogs.length === 0) && (
                    <div className="text-slate-500 py-4 text-center">No recent dealership module audit entries yet.</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION 2: DEALER DIRECTORY & REGISTRATION */}
          {/* ============================================================== */}
          {section === 'dealers' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-white">Authorized Dealerships Directory</h3>
                  <p className="text-xs text-slate-400">
                    Register dealerships with sequential IDs, CNIC validation, duplicate prevention, and primary showroom setup.
                  </p>
                </div>
                {scope?.canRegisterDealers && (
                  <button
                    type="button"
                    onClick={() => setShowRegister(!showRegister)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                  >
                    <Plus className="w-3.5 h-3.5" /> Register New Dealer
                  </button>
                )}
              </div>

              {showRegister && (
                <form onSubmit={handleRegister} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="font-bold text-amber-300">Dealer &amp; Showroom Registration Application</span>
                    {nextCodes.dealerCode && (
                      <span className="font-mono text-[11px] text-slate-400">
                        Next Auto IDs: <strong className="text-white">{nextCodes.dealerCode}</strong> / <strong className="text-white">{nextCodes.showroomCode}</strong>
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input required value={rBusinessName} onChange={(e) => setRBusinessName(e.target.value)} placeholder="Dealership Business Name *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    <input required value={rOwnerName} onChange={(e) => setROwnerName(e.target.value)} placeholder="Dealer Principal / Owner *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    <input required type="email" value={rEmail} onChange={(e) => setREmail(e.target.value)} placeholder="Official Email *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <input required value={rMobile} onChange={(e) => setRMobile(e.target.value)} placeholder="Mobile Number *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    <input value={rCnic} onChange={(e) => setRCnic(e.target.value)} placeholder="CNIC (e.g. 42101-1234567-1)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
                    <input value={rRegNo} onChange={(e) => setRRegNo(e.target.value)} placeholder="SECP / Business Reg No" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
                    <input value={rTaxNtn} onChange={(e) => setRTaxNtn(e.target.value)} placeholder="Tax NTN / TRN" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <select value={rCompanyId} onChange={(e) => setRCompanyId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                      {(catalogs.companies.length ? catalogs.companies : [{ id: 'comp_byd_pk', name: 'BYD Pakistan' }]).map((c: any) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                    <input value={rCountryId} onChange={(e) => setRCountryId(e.target.value.toUpperCase())} placeholder="Country ISO (PK)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
                    <input value={rProvince} onChange={(e) => setRProvince(e.target.value)} placeholder="Province / State" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    <input required value={rCity} onChange={(e) => setRCity(e.target.value)} placeholder="City *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input required value={rAddress} onChange={(e) => setRAddress(e.target.value)} placeholder="Complete Business & Showroom Address *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white sm:col-span-2" />
                    <select value={rCategory} onChange={(e) => setRCategory(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                      <option value="3S Flagship Centre">3S Flagship Centre</option>
                      <option value="2S Service Facility">2S Service Facility</option>
                      <option value="Retail Experience Studio">Retail Experience Studio</option>
                      <option value="Authorized EV Reseller">Authorized EV Reseller</option>
                    </select>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                    <input value={rShowroomName} onChange={(e) => setRShowroomName(e.target.value)} placeholder="Primary Showroom Name (optional)" className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    {scope?.canVerifyDealers && (
                      <label className="flex items-center gap-2 text-slate-300">
                        <input type="checkbox" checked={rApproveNow} onChange={(e) => setRApproveNow(e.target.checked)} />
                        <span>Approve &amp; Verify Immediately</span>
                      </label>
                    )}
                    <div className="flex gap-2">
                      <button type="button" onClick={() => setShowRegister(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                      <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Submit Registration</button>
                    </div>
                  </div>
                </form>
              )}

              {/* Search & Filter Toolbar */}
              <div className="flex flex-wrap gap-2 text-xs">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                  <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search code, name, CNIC, email, city..." className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white" />
                </div>
                <select value={verificationFilter} onChange={(e) => setVerificationFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
                  <option value="">All Verification</option>
                  <option value="Verified">Verified</option>
                  <option value="Pending Approval">Pending Approval</option>
                  <option value="Rejected">Rejected</option>
                </select>
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
                  <option value="">All Account Status</option>
                  <option value="Active">Active</option>
                  <option value="Pending Verification">Pending Verification</option>
                  <option value="Suspended">Suspended</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="px-3 py-2.5">Dealer ID</th>
                      <th className="px-3 py-2.5">Business &amp; Owner</th>
                      <th className="px-3 py-2.5">Contact &amp; City</th>
                      <th className="px-3 py-2.5">Showrooms / Stock / Sales</th>
                      <th className="px-3 py-2.5">Verification &amp; Status</th>
                      <th className="px-3 py-2.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {pagedDealers.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-900/40">
                        <td className="px-3 py-2.5 font-mono text-amber-300 whitespace-nowrap">{d.dealer_code}</td>
                        <td className="px-3 py-2.5">
                          <div className="font-semibold text-white">{d.business_name}</div>
                          <div className="text-[11px] text-slate-400">{d.owner_contact_name} • {d.category}</div>
                        </td>
                        <td className="px-3 py-2.5">
                          <div className="text-slate-200">{d.email}</div>
                          <div className="text-[11px] text-slate-400">{d.mobile} • {d.city || 'Karachi'}</div>
                        </td>
                        <td className="px-3 py-2.5 font-mono text-[11px]">
                          <div className="text-white">{d.showroom_count} Showrooms • {d.available_stock} In Stock</div>
                          <div className="text-emerald-300">{d.sales_count} Sales ({fmtPkr(d.sales_revenue_pkr)})</div>
                        </td>
                        <td className="px-3 py-2.5">
                          <div className={d.verification_status === 'Verified' ? 'text-emerald-400 font-semibold' : d.verification_status === 'Rejected' ? 'text-rose-400' : 'text-amber-300 font-semibold'}>
                            {d.verification_status}
                          </div>
                          <div className="text-[10px] text-slate-400">Account: {d.status}</div>
                        </td>
                        <td className="px-3 py-2.5 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => openDetail(d.id)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white inline-flex items-center gap-1"
                          >
                            <Eye className="w-3 h-3" /> Profile
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Showing {pagedDealers.length} of {dealersList.length} dealerships</span>
                  <div className="flex gap-1.5">
                    <button type="button" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="px-3 py-1 rounded bg-slate-900 border border-slate-800 disabled:opacity-40">Prev</button>
                    <span className="px-3 py-1 font-mono">Page {page}/{totalPages}</span>
                    <button type="button" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="px-3 py-1 rounded bg-slate-900 border border-slate-800 disabled:opacity-40">Next</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* SECTION 3: DEALER VERIFICATION QUEUE & HISTORY */}
          {/* ============================================================== */}
          {section === 'verification' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  Dealer &amp; Compliance Verification Queue
                </h3>
                <p className="text-xs text-slate-400">
                  Authorized verification of CNIC, business registration, showrooms, and account suspension controls.
                </p>
              </div>

              {rejectTarget && (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    setError('');
                    try {
                      await api.verifyDealershipDealer(rejectTarget.id, {
                        decision: rejectTarget.action,
                        rejectionReason: rejectReason,
                      });
                      setNotice(`${rejectTarget.action.toUpperCase()} completed on ${rejectTarget.code}.`);
                      setRejectTarget(null);
                      setRejectReason('');
                      await Promise.all([loadVerification(), loadDashboard()]);
                    } catch (err: any) {
                      setError(err?.message || 'Verification action failed.');
                    }
                  }}
                  className="p-4 rounded-xl bg-slate-950 border border-rose-500/40 space-y-3 text-xs"
                >
                  <div className="font-bold text-rose-300">
                    Provide Mandatory Reason to {rejectTarget.action.toUpperCase()} ({rejectTarget.code})
                  </div>
                  <div className="flex gap-2">
                    <input required value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="Enter compliance rejection / suspension reason *" className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                    <button type="button" onClick={() => setRejectTarget(null)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                    <button type="submit" className="px-5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold">Confirm</button>
                  </div>
                </form>
              )}

              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="px-3 py-2.5">Code</th>
                      <th className="px-3 py-2.5">Dealership &amp; Registration</th>
                      <th className="px-3 py-2.5">Email / Mobile Verified</th>
                      <th className="px-3 py-2.5">Status</th>
                      <th className="px-3 py-2.5 text-right">Authorized Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {verificationData.dealers.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-900/40">
                        <td className="px-3 py-2.5 font-mono text-amber-300">{d.dealer_code}</td>
                        <td className="px-3 py-2.5">
                          <div className="font-semibold text-white">{d.business_name}</div>
                          <div className="text-[11px] text-slate-400">
                            CNIC: {d.cnic_number || 'Pending'} • NTN: {d.tax_id_ntn || 'N/A'} • Reg: {d.registration_no || 'N/A'}
                          </div>
                          {d.rejected_reason && <div className="text-[11px] text-rose-400">Reason: {d.rejected_reason}</div>}
                        </td>
                        <td className="px-3 py-2.5 text-[11px]">
                          <div className={d.email_verified ? 'text-emerald-400' : 'text-amber-300'}>
                            Email: {d.email_verified ? 'Verified' : 'Pending'}
                          </div>
                          <div className={d.mobile_verified ? 'text-emerald-400' : 'text-slate-400'}>
                            Mobile: {d.mobile_verified ? 'Verified' : 'Unverified'}
                          </div>
                        </td>
                        <td className="px-3 py-2.5">
                          <div className="font-semibold text-white">{d.verification_status}</div>
                          <div className="text-[10px] text-slate-400">{d.status}</div>
                        </td>
                        <td className="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
                          {d.verification_status !== 'Verified' && (
                            <button
                              type="button"
                              onClick={async () => {
                                await api.verifyDealershipDealer(d.id, { decision: 'approve' });
                                setNotice(`Approved and verified dealership ${d.dealer_code}.`);
                                await Promise.all([loadVerification(), loadDashboard()]);
                              }}
                              className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                            >
                              Approve
                            </button>
                          )}
                          {d.verification_status !== 'Rejected' && (
                            <button
                              type="button"
                              onClick={() => { setRejectTarget({ id: d.id, code: d.dealer_code, action: 'reject' }); setRejectReason(''); }}
                              className="px-2.5 py-1 rounded bg-rose-700/80 hover:bg-rose-600 text-white"
                            >
                              Reject
                            </button>
                          )}
                          {d.status === 'Active' ? (
                            <button
                              type="button"
                              onClick={() => { setRejectTarget({ id: d.id, code: d.dealer_code, action: 'suspend' }); setRejectReason(''); }}
                              className="px-2.5 py-1 rounded bg-amber-600/80 hover:bg-amber-500 text-white"
                            >
                              Suspend
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={async () => {
                                await api.verifyDealershipDealer(d.id, { decision: 'reactivate' });
                                setNotice(`Reactivated dealership ${d.dealer_code}.`);
                                await Promise.all([loadVerification(), loadDashboard()]);
                              }}
                              className="px-2.5 py-1 rounded bg-blue-600/80 hover:bg-blue-500 text-white"
                            >
                              Reactivate
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-2">
                <div className="text-xs font-bold text-white">Verification Audit History</div>
                <div className="space-y-1.5 max-h-52 overflow-y-auto text-[11px]">
                  {verificationData.history.map((h) => (
                    <div key={h.id} className="flex items-center justify-between gap-2 py-1 border-b border-slate-800/60 text-slate-300">
                      <div>
                        <span className="font-mono text-amber-300">{h.dealer_code}</span> [{h.target_type}]: {h.previous_status || 'New'} → <strong className="text-white">{h.new_status}</strong>
                        {h.rejection_reason ? ` — Reason: ${h.rejection_reason}` : ''}
                      </div>
                      <div className="font-mono text-[10px] text-slate-500 whitespace-nowrap">
                        {h.reviewed_by_name} ({h.reviewed_by_role}) • {String(h.created_at).slice(0, 16).replace('T', ' ')}
                      </div>
                    </div>
                  ))}
                  {verificationData.history.length === 0 && (
                    <div className="text-slate-500 py-3 text-center">No verification transitions recorded yet.</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* SUB-PANELS */}
          {section === 'showrooms' && (
            <ShowroomsPanel scope={scope} dealersCatalog={catalogs.dealers} onRefreshParent={loadDashboard} />
          )}
          {section === 'inventory' && (
            <DealerInventoryPanel scope={scope} dealersCatalog={catalogs.dealers} onRefreshParent={loadDashboard} />
          )}
          {section === 'sales' && (
            <DealerSalesPanel scope={scope} dealersCatalog={catalogs.dealers} onRefreshParent={loadDashboard} />
          )}
          {section === 'commissions' && (
            <DealerCommissionsPanel
              scope={scope}
              dealersCatalog={catalogs.dealers}
              companiesCatalog={catalogs.companies}
              onRefreshParent={loadDashboard}
            />
          )}
          {section === 'targets' && (
            <DealerTargetsPerformancePanel
              scope={scope}
              dealersCatalog={catalogs.dealers}
              ranking={dashboard?.dealerRanking || []}
              onRefreshParent={loadDashboard}
            />
          )}
          {section === 'documents' && (
            <DealerDocumentsReportsPanel scope={scope} dealersCatalog={catalogs.dealers} />
          )}
        </main>
      </div>

      {/* DEALER PROFILE SLIDE-OVER MODAL */}
      {detailData?.dealer && (
        <div className="fixed inset-0 z-50 bg-black/75 flex justify-end">
          <div className="w-full max-w-2xl bg-slate-950 border-l border-slate-800 h-full overflow-y-auto p-6 space-y-5 text-xs">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="font-mono text-amber-400 font-bold">{detailData.dealer.dealer_code}</div>
                <h3 className="text-lg font-bold text-white">{detailData.dealer.business_name}</h3>
                <div className="text-slate-400">{detailData.dealer.owner_contact_name} • {detailData.dealer.category}</div>
              </div>
              <button type="button" onClick={() => setDetailData(null)} className="p-2 rounded-lg bg-slate-900 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 bg-slate-900/70 rounded-xl p-4 border border-slate-800">
              <div><span className="text-slate-400 block">Email:</span> <span className="text-white">{detailData.dealer.email}</span></div>
              <div><span className="text-slate-400 block">Mobile:</span> <span className="text-white">{detailData.dealer.mobile}</span></div>
              <div><span className="text-slate-400 block">CNIC / National ID:</span> <span className="font-mono text-white">{detailData.dealer.cnic_number || 'Not Provided'}</span></div>
              <div><span className="text-slate-400 block">Tax NTN / Reg No:</span> <span className="font-mono text-white">{detailData.dealer.tax_id_ntn || '-'} / {detailData.dealer.registration_no || '-'}</span></div>
              <div className="col-span-2"><span className="text-slate-400 block">Address:</span> <span className="text-white">{detailData.dealer.business_address}, {detailData.dealer.city}</span></div>
            </div>

            {/* Email / Mobile Verification Dispatch */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-2">
              <div className="font-bold text-white">Email &amp; Mobile OTP Verification Control</div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    const res = await api.sendDealershipVerificationOtp(detailData.dealer.id, 'email');
                    setOtpHint(res.devOtpPreview ? `Dev OTP (email): ${res.devOtpPreview}` : res.message);
                  }}
                  className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 inline-flex items-center gap-1"
                >
                  <Mail className="w-3 h-3" /> Send Email OTP ({detailData.dealer.email_verified ? 'Verified' : 'Pending'})
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const res = await api.sendDealershipVerificationOtp(detailData.dealer.id, 'mobile');
                    setOtpHint(res.devOtpPreview ? `Dev OTP (mobile): ${res.devOtpPreview}` : res.message);
                  }}
                  className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 inline-flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Send Mobile OTP ({detailData.dealer.mobile_verified ? 'Verified' : 'Pending'})
                </button>
              </div>
              {otpHint && <div className="font-mono text-amber-300 text-[11px]">{otpHint}</div>}
              <div className="flex gap-2 pt-1">
                <input value={otpInput} onChange={(e) => setOtpInput(e.target.value)} placeholder="Enter 6-digit OTP" className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono" />
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await api.confirmDealershipVerificationOtp(detailData.dealer.id, otpHint.includes('mobile') ? 'mobile' : 'email', otpInput);
                      setNotice('OTP verification confirmed.');
                      openDetail(detailData.dealer.id);
                    } catch (err: any) {
                      setError(err?.message || 'OTP confirmation failed.');
                    }
                  }}
                  className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Verify OTP
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white">Showrooms ({detailData.showrooms?.length || 0})</div>
              {(detailData.showrooms || []).map((sh: any) => (
                <div key={sh.id} className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex justify-between">
                  <div>
                    <div className="font-semibold text-white">{sh.name} (<span className="font-mono text-amber-300">{sh.showroom_code}</span>)</div>
                    <div className="text-slate-400">{sh.address}, {sh.city} • Mgr: {sh.manager_name}</div>
                  </div>
                  <div className="text-emerald-400 font-semibold">{sh.status}</div>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white">Verification &amp; Compliance History ({detailData.verificationHistory?.length || 0})</div>
              {(detailData.verificationHistory || []).map((h: any) => (
                <div key={h.id} className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]">
                  <span className="font-mono text-amber-300">{h.new_status}</span> by {h.reviewed_by_name} ({h.reviewed_by_role})
                  {h.rejection_reason && <div className="text-rose-300 mt-0.5">Reason: {h.rejection_reason}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
