import express, { Request, Response } from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import {
  sqlite,
  hashPassword,
  generateSecureToken,
  validatePasswordStrength,
  logAdminActivity,
  logCompanyActivity,
  logEmployeeActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireSuperAdmin,
  requirePermission,
  getClientIp,
} from './auth';
import { buildSimplePdfBuffer } from './dealer';
import { getApiTelemetrySnapshot } from './telemetry';

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function maskSensitiveId(val?: string | null, showFull = false): string {
  const s = String(val || '').trim();
  if (!s) return 'Not Provided';
  if (showFull) return s;
  if (s.length <= 4) return '****';
  return `${s.slice(0, 2)}${'*'.repeat(Math.max(4, s.length - 5))}${s.slice(-3)}`;
}

function maskPhone(val?: string | null, showFull = false): string {
  const s = String(val || '').trim();
  if (!s) return '—';
  if (showFull) return s;
  if (s.length <= 6) return '***-***';
  return `${s.slice(0, 5)}••••${s.slice(-3)}`;
}

function recordSaEnterpriseAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth) return;
  logAdminActivity({
    adminId: req.auth.userId,
    adminName: req.auth.fullName,
    adminRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
    userAgent: String(req.headers['user-agent'] || ''),
    sessionId: req.auth.sessionId || null,
  });
}

function rejectPrivilegedTamper(req: Request, res: Response, reason: string, targetId?: string | null) {
  const ip = getClientIp(req);
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'FOUNDER_PROTECTION_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    details: reason,
    ipAddress: ip,
  });
  recordSaEnterpriseAction(req, 'PRIVILEGE_ESCALATION_BLOCKED', 'Security Isolation', targetId || null, reason, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Super Admins cannot inspect, modify, suspend, or escalate Founder / Owner or fellow Super Admin accounts.',
  });
}

function resolveDateRange(period: string, fromDateRaw?: string, toDateRaw?: string): { fromIso: string; toIso: string; label: string } {
  const now = new Date();
  const toEndOfDay = (d: Date) => `${d.toISOString().slice(0, 10)}T23:59:59.999Z`;
  const toStartOfDay = (d: Date) => `${d.toISOString().slice(0, 10)}T00:00:00.000Z`;

  if (period === 'custom' && fromDateRaw && toDateRaw) {
    const cleanFrom = String(fromDateRaw).slice(0, 10);
    const cleanTo = String(toDateRaw).slice(0, 10);
    return {
      fromIso: `${cleanFrom}T00:00:00.000Z`,
      toIso: `${cleanTo}T23:59:59.999Z`,
      label: `Custom (${cleanFrom} to ${cleanTo})`,
    };
  }

  const end = toEndOfDay(now);
  const startDate = new Date(now);
  let label = 'Monthly (Last 30 Days)';
  if (period === 'daily') {
    label = 'Daily (Last 24 Hours)';
  } else if (period === 'weekly') {
    startDate.setDate(now.getDate() - 7);
    label = 'Weekly (Last 7 Days)';
  } else if (period === 'yearly') {
    startDate.setFullYear(now.getFullYear() - 1);
    label = 'Yearly (Last 12 Months)';
  } else if (period === 'all') {
    return {
      fromIso: '2020-01-01T00:00:00.000Z',
      toIso: end,
      label: 'All-Time Verified Records',
    };
  } else {
    startDate.setDate(now.getDate() - 30);
  }

  return {
    fromIso: toStartOfDay(startDate),
    toIso: end,
    label,
  };
}

export function createSuperAdminEnterpriseRouter() {
  const router = express.Router();
  router.use(requireSuperAdmin);

  // =========================================================================
  // 1. UNIFIED USER MANAGEMENT DIRECTORY & FULL USER PROFILE VIEWER
  // =========================================================================
  router.get('/users/directory', requirePermission('users.view'), (req: Request, res: Response) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const roleFilter = String(req.query.role || '').trim();
    const statusFilter = String(req.query.status || '').trim();
    const countryFilter = String(req.query.country || '').trim().toUpperCase();

    const rows = sqlite
      .prepare(`
        SELECT ua.id, ua.subject_type, ua.source_table, ua.role, ua.full_name, ua.email, ua.mobile,
               ua.company_id, ua.country_id, ua.branch_id,
               COALESCE(b.city, c.city, co.headquarters_city, '') as city,
               ua.status, ua.verification_status, ua.email_verified, ua.mobile_verified,
               ua.mfa_enabled as two_factor_enabled,
               ua.last_login_at, ua.created_at,
               c.name as company_name, b.name as branch_name, co.name as country_name
        FROM user_accounts ua
        LEFT JOIN companies c ON c.id = ua.company_id
        LEFT JOIN branches b ON b.id = ua.branch_id
        LEFT JOIN countries co ON co.id = ua.country_id
        WHERE ua.subject_type NOT IN ('founder', 'super_admin')
        ORDER BY ua.created_at DESC
      `)
      .all() as any[];

    const filtered = rows.filter((u) => {
      if (roleFilter && roleFilter !== 'ALL' && u.role !== roleFilter && u.subject_type !== roleFilter) return false;
      if (statusFilter && statusFilter !== 'ALL' && u.status !== statusFilter && u.verification_status !== statusFilter) return false;
      if (countryFilter && countryFilter !== 'ALL' && String(u.country_id || '').toUpperCase() !== countryFilter) return false;
      if (search) {
        const hay = `${u.id} ${u.full_name} ${u.email} ${u.role} ${u.city || ''} ${u.company_name || ''} ${u.country_id || ''}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    const roles = Array.from(new Set(rows.map((r) => r.role))).sort();
    res.json({
      users: filtered,
      totalCount: rows.length,
      availableRoles: roles,
    });
  });

  router.get('/users/:id/profile', requirePermission('users.view'), (req: Request, res: Response) => {
    const targetId = String(req.params.id);

    const isFounder = sqlite.prepare('SELECT id FROM founder_accounts WHERE id = ?').get(targetId);
    const isSa = sqlite.prepare('SELECT id, email FROM super_admin_accounts WHERE id = ?').get(targetId) as any;
    if (isFounder || targetId === 'founder_intekhab_alam' || (isSa && req.auth!.subjectType !== 'founder')) {
      rejectPrivilegedTamper(req, res, `Attempted to inspect protected Founder/Super Admin profile (${targetId}).`, targetId);
      return;
    }

    const ua = sqlite
      .prepare(`
        SELECT ua.*,
               COALESCE(b.city, c.city, co.headquarters_city, '') as city,
               ua.mfa_enabled as two_factor_enabled,
               c.name as company_name, b.name as branch_name, co.name as country_name
        FROM user_accounts ua
        LEFT JOIN companies c ON c.id = ua.company_id
        LEFT JOIN branches b ON b.id = ua.branch_id
        LEFT JOIN countries co ON co.id = ua.country_id
        WHERE ua.id = ?
      `)
      .get(targetId) as any;

    const legacyUser = !ua ? (sqlite.prepare('SELECT * FROM users WHERE id = ?').get(targetId) as any) : null;
    if (!ua && !legacyUser) {
      res.status(404).json({ error: 'User profile not found.' });
      return;
    }

    const profile = ua || legacyUser;
    if (profile.role === 'Founder / Owner' || (profile.role === 'Super Admin' && req.auth!.subjectType !== 'founder')) {
      rejectPrivilegedTamper(req, res, `Blocked profile inspection on privileged role ${profile.role} (${targetId}).`, targetId);
      return;
    }

    const loginHistory = sqlite
      .prepare(`
        SELECT id, identifier, role, success, failure_reason, ip_address, device_name, browser_name, suspicious, created_at, logout_at
        FROM login_activity_logs
        WHERE user_id = ? OR LOWER(identifier) = LOWER(?)
        ORDER BY created_at DESC LIMIT 25
      `)
      .all(profile.id, profile.email);

    const approvalHistory = sqlite
      .prepare('SELECT * FROM account_approval_history WHERE target_user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(profile.id);

    const documents = sqlite
      .prepare('SELECT id, doc_type, title, original_filename, review_status, created_at FROM verification_documents WHERE user_id = ? ORDER BY created_at DESC')
      .all(profile.id);

    const permRow = sqlite.prepare('SELECT permissions_json FROM user_permissions WHERE user_id = ?').get(profile.id) as any;
    const assignedPermissions = permRow ? safeJsonParse<string[]>(permRow.permissions_json, []) : [];

    res.json({
      profile: {
        ...profile,
        mobile: maskPhone(profile.mobile, req.auth!.subjectType === 'founder'),
      },
      assignedPermissions,
      loginHistory,
      approvalHistory,
      documents,
    });
  });

  router.patch('/users/:id/access', (req: Request, res: Response) => {
    const targetId = String(req.params.id);
    const isFounder = sqlite.prepare('SELECT id FROM founder_accounts WHERE id = ?').get(targetId);
    const isSa = sqlite.prepare('SELECT id, email FROM super_admin_accounts WHERE id = ?').get(targetId) as any;
    if (isFounder || targetId === 'founder_intekhab_alam' || isSa) {
      rejectPrivilegedTamper(req, res, `Attempted to modify protected Founder/Super Admin access (${targetId}).`, targetId);
      return;
    }

    const ua = sqlite.prepare('SELECT * FROM user_accounts WHERE id = ?').get(targetId) as any;
    if (!ua) {
      res.status(404).json({ error: 'User account not found in directory.' });
      return;
    }
    if (ua.subject_type === 'founder' || ua.subject_type === 'super_admin') {
      rejectPrivilegedTamper(req, res, `Blocked access mutation on privileged subject ${ua.subject_type}.`, targetId);
      return;
    }

    const nextStatus = req.body.status ? String(req.body.status).trim() : ua.status;
    const nextVerStatus = req.body.verificationStatus ? String(req.body.verificationStatus).trim() : ua.verification_status;
    const isStatusMutation = nextStatus !== ua.status;

    if (isStatusMutation && req.auth!.subjectType !== 'founder' && !req.auth!.permissions.includes('users.suspend')) {
      res.status(403).json({ error: 'Permission denied: requires users.suspend permission.' });
      return;
    }
    if (!isStatusMutation && req.auth!.subjectType !== 'founder' && !req.auth!.permissions.includes('users.update')) {
      res.status(403).json({ error: 'Permission denied: requires users.update permission.' });
      return;
    }

    if (!['Active', 'Suspended', 'Pending Verification'].includes(nextStatus)) {
      res.status(400).json({ error: 'Invalid status. Must be Active, Suspended, or Pending Verification.' });
      return;
    }

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE user_accounts SET status = ?, verification_status = ?, updated_at = ? WHERE id = ?')
        .run(nextStatus, nextVerStatus, now, ua.id);

      const src = ua.source_table;
      if (src === 'users' || src === 'company_admin_accounts' || src === 'country_manager_accounts' || src === 'branch_manager_accounts' || src === 'employee_accounts') {
        sqlite.prepare(`UPDATE ${src} SET status = ?, updated_at = ? WHERE id = ?`).run(nextStatus, now, ua.id);
      } else if (src === 'dealer_accounts') {
        sqlite
          .prepare('UPDATE dealer_accounts SET status = ?, verification_status = ?, updated_at = ? WHERE id = ?')
          .run(nextStatus, nextVerStatus, now, ua.id);
      } else if (src === 'customer_accounts') {
        sqlite
          .prepare('UPDATE customer_accounts SET status = ?, verification_status = ?, updated_at = ? WHERE id = ?')
          .run(nextStatus, nextVerStatus, now, ua.id);
      }

      if (nextStatus === 'Suspended') {
        sqlite
          .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'super_admin_suspended', revoked_at = ? WHERE user_id = ?")
          .run(now, ua.id);
        if (src === 'customer_accounts') {
          sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(ua.id);
        }
      }

      if (Array.isArray(req.body.permissions)) {
        const cleanPerms = req.body.permissions
          .map((p: unknown) => String(p).trim())
          .filter((p: string) => p && !p.toLowerCase().includes('founder') && !p.toLowerCase().includes('super_admin'));
        sqlite
          .prepare(`
            INSERT INTO user_permissions (user_id, permissions_json, updated_by, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET permissions_json = excluded.permissions_json, updated_by = excluded.updated_by, updated_at = excluded.updated_at
          `)
          .run(ua.id, JSON.stringify(cleanPerms), req.auth!.fullName, now);
      }
    })();

    recordSaEnterpriseAction(
      req,
      nextStatus === 'Suspended' ? 'USER_ACCESS_SUSPENDED' : 'USER_ACCESS_UPDATED',
      'User Management',
      ua.email,
      `Role: ${ua.role}, Status: ${nextStatus}, KYC: ${nextVerStatus}`
    );

    res.json({ success: true, status: nextStatus, verificationStatus: nextVerStatus });
  });

  // =========================================================================
  // 2. COMPANY MANAGEMENT EXTENSIONS (DETAIL + BRANCHES + DOCS + CREATE)
  // =========================================================================
  router.post('/companies', requirePermission('users.create'), (req: Request, res: Response) => {
    const name = String(req.body.name || '').trim();
    const country = String(req.body.country || 'Pakistan').trim();
    const city = String(req.body.city || 'Karachi').trim();
    const officialEmail = String(req.body.officialEmail || '').trim().toLowerCase();
    const phone = String(req.body.phone || '').trim();
    const address = String(req.body.address || '').trim();
    const registrationDetails = String(req.body.registrationDetails || '').trim();
    const authorizedRep = String(req.body.authorizedRep || '').trim();
    const website = String(req.body.website || '').trim();
    const taxId = String(req.body.taxId || '').trim();

    if (!name || !officialEmail || !phone || !address || !registrationDetails || !authorizedRep) {
      res.status(400).json({ error: 'Company name, official email, phone, address, registration details, and authorized representative are required.' });
      return;
    }

    const exists = sqlite.prepare('SELECT id FROM companies WHERE LOWER(official_email) = ?').get(officialEmail);
    if (exists) {
      res.status(409).json({ error: 'A company with this official email already exists.' });
      return;
    }

    const id = `comp_${generateSecureToken(5)}`;
    const now = nowIso();
    // Founder approval rule: Super Admin submissions enter Pending Approval unless created directly by Founder
    const initialStatus = req.auth!.subjectType === 'founder' && req.body.status === 'Approved' ? 'Approved' : 'Pending Approval';

    sqlite
      .prepare(`
        INSERT INTO companies (
          id, name, country, city, official_email, phone, address, registration_details,
          authorized_rep, status, website, tax_id, approved_by, approved_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id,
        name,
        country,
        city,
        officialEmail,
        phone,
        address,
        registrationDetails,
        authorizedRep,
        initialStatus,
        website,
        taxId,
        initialStatus === 'Approved' ? req.auth!.fullName : null,
        initialStatus === 'Approved' ? now : null,
        now
      );

    logCompanyActivity({
      companyId: id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMPANY_REGISTERED',
      module: 'Company Management',
      targetId: id,
      details: `Company ${name} registered (${initialStatus}).`,
      ipAddress: getClientIp(req),
    });

    recordSaEnterpriseAction(req, 'COMPANY_REGISTERED', 'Company Management', id, `${name} (${country}) — ${initialStatus}`);
    res.status(201).json({ success: true, id, status: initialStatus });
  });

  router.get('/companies/:id/detail', requirePermission('users.view'), (req: Request, res: Response) => {
    const company = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!company) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }

    const branches = sqlite
      .prepare(`
        SELECT b.*, c.name as country_name
        FROM branches b
        LEFT JOIN countries c ON c.id = b.country_id
        WHERE b.company_id = ?
        ORDER BY b.created_at DESC
      `)
      .all(company.id);

    const dealerships = sqlite
      .prepare('SELECT id, name, code, city, country, facility_type, status, achieved_units, monthly_target_units, monthly_revenue_pkr FROM dealerships WHERE company_id = ?')
      .all(company.id);

    const employees = sqlite
      .prepare('SELECT id, employee_code, full_name, email, department, job_position, status, performance_score, branch_id, country_id FROM employee_accounts WHERE company_id = ?')
      .all(company.id);

    const dealersCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_accounts WHERE company_id = ?').get(company.id) as any).c;
    const customersCount = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts WHERE company_id = ?').get(company.id) as any).c;
    const vehiclesStats = sqlite
      .prepare("SELECT COUNT(*) as total, SUM(CASE WHEN sold_at IS NOT NULL THEN 1 ELSE 0 END) as sold FROM vehicles WHERE company_id = ?")
      .get(company.id) as any;
    const revenueRow = sqlite
      .prepare("SELECT COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidPkr, COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingPkr FROM payments_invoices WHERE company_id = ?")
      .get(company.id) as any;

    const activityLogs = sqlite
      .prepare('SELECT * FROM company_activity_logs WHERE company_id = ? ORDER BY created_at DESC LIMIT 25')
      .all(company.id);

    res.json({
      company: {
        ...company,
        departments: safeJsonParse<string[]>(company.departments_json, []),
        documents: safeJsonParse<any[]>(company.documents_json, []),
        businessInfo: safeJsonParse<Record<string, any>>(company.business_info_json, {}),
      },
      branches,
      dealerships,
      employees,
      activityLogs,
      performance: {
        branchesCount: branches.length,
        dealershipsCount: dealerships.length,
        employeesCount: employees.length,
        dealersCount,
        customersCount,
        totalVehicles: vehiclesStats?.total || 0,
        soldVehicles: vehiclesStats?.sold || 0,
        paidRevenuePkr: revenueRow?.paidPkr || 0,
        pendingRevenuePkr: revenueRow?.pendingPkr || 0,
      },
    });
  });

  router.patch('/companies/:id/documents', requirePermission('users.update'), (req: Request, res: Response) => {
    const company = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!company) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }

    if (req.body.status && req.body.status !== company.status && req.auth!.subjectType !== 'founder') {
      res.status(403).json({ error: 'Company status activation/suspension is reserved exclusively for the Founder / Owner.' });
      return;
    }

    const website = req.body.website !== undefined ? String(req.body.website).trim() : company.website;
    const taxId = req.body.taxId !== undefined ? String(req.body.taxId).trim() : company.tax_id;
    const regDetails = req.body.registrationDetails !== undefined ? String(req.body.registrationDetails).trim() : company.registration_details;
    const currentDocs = safeJsonParse<any[]>(company.documents_json, []);
    const nextDocs = Array.isArray(req.body.documents) ? req.body.documents : currentDocs;

    if (req.body.newDocument && typeof req.body.newDocument === 'object' && req.body.newDocument.title) {
      nextDocs.unshift({
        id: `cdoc_${generateSecureToken(5)}`,
        title: String(req.body.newDocument.title).trim(),
        docType: String(req.body.newDocument.docType || 'Corporate Filing').trim(),
        referenceNo: String(req.body.newDocument.referenceNo || '').trim(),
        status: String(req.body.newDocument.status || 'Submitted'),
        uploadedBy: req.auth!.fullName,
        uploadedAt: nowIso(),
      });
    }

    const currentInfo = safeJsonParse<Record<string, any>>(company.business_info_json, {});
    const nextInfo =
      req.body.businessInfo && typeof req.body.businessInfo === 'object'
        ? { ...currentInfo, ...req.body.businessInfo }
        : currentInfo;

    sqlite
      .prepare('UPDATE companies SET website = ?, tax_id = ?, registration_details = ?, documents_json = ?, business_info_json = ? WHERE id = ?')
      .run(website, taxId, regDetails, JSON.stringify(nextDocs), JSON.stringify(nextInfo), company.id);

    logCompanyActivity({
      companyId: company.id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMPANY_DOCUMENTS_UPDATED',
      module: 'Company Management',
      targetId: company.id,
      details: `Updated tax/registration/document records (${nextDocs.length} documents attached).`,
      ipAddress: getClientIp(req),
    });

    recordSaEnterpriseAction(req, 'COMPANY_DOCUMENTS_UPDATED', 'Company Management', company.id, `${company.name} documents/registration updated`);
    res.json({ success: true, documents: nextDocs });
  });

  // =========================================================================
  // 3. EMPLOYEE MANAGEMENT MODULE (employee_accounts + branches + attendance)
  // =========================================================================
  router.get('/employees', requirePermission('users.view'), (req: Request, res: Response) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const countryFilter = String(req.query.country || '').trim().toUpperCase();
    const companyFilter = String(req.query.companyId || '').trim();
    const branchFilter = String(req.query.branchId || '').trim();
    const departmentFilter = String(req.query.department || '').trim();
    const statusFilter = String(req.query.status || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT e.id, e.user_id, e.employee_code, e.company_id, e.branch_id, e.country_id,
               e.full_name, e.email, e.mobile, e.department, e.job_position, e.status,
               e.performance_score, e.performance_notes, e.permissions_json, e.reporting_manager_name,
               e.attendance_json, e.leave_requests_json, e.joined_at, e.last_login_at, e.created_at,
               c.name as company_name, b.name as branch_name, b.city as branch_city,
               COALESCE(co.name, e.country_id, 'Pakistan') as country_name
        FROM employee_accounts e
        LEFT JOIN companies c ON c.id = e.company_id
        LEFT JOIN branches b ON b.id = e.branch_id
        LEFT JOIN countries co ON co.id = e.country_id
        ORDER BY e.created_at DESC
      `)
      .all() as any[];

    const filtered = rows
      .filter((r) => {
        if (countryFilter && countryFilter !== 'ALL' && String(r.country_id || 'PK').toUpperCase() !== countryFilter) return false;
        if (companyFilter && companyFilter !== 'ALL' && r.company_id !== companyFilter) return false;
        if (branchFilter && branchFilter !== 'ALL' && r.branch_id !== branchFilter) return false;
        if (departmentFilter && departmentFilter !== 'ALL' && r.department !== departmentFilter) return false;
        if (statusFilter && statusFilter !== 'ALL' && r.status !== statusFilter) return false;
        if (search) {
          const hay = `${r.full_name} ${r.email} ${r.employee_code} ${r.department} ${r.job_position} ${r.branch_name || ''}`.toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      })
      .map((r) => {
        const attendance = safeJsonParse<any[]>(r.attendance_json, []);
        const presentDays = attendance.filter((a) => a.status === 'Present').length;
        return {
          ...r,
          permissions: safeJsonParse<string[]>(r.permissions_json, []),
          attendanceDaysRecorded: attendance.length,
          attendancePresentDays: presentDays,
        };
      });

    const countryBreakdown = sqlite
      .prepare(`
        SELECT COALESCE(e.country_id, 'PK') as countryId,
               COALESCE(co.name, e.country_id, 'Pakistan') as countryName,
               COUNT(*) as totalEmployees,
               SUM(CASE WHEN e.status = 'Active' THEN 1 ELSE 0 END) as activeEmployees,
               ROUND(AVG(e.performance_score), 1) as avgPerformanceScore
        FROM employee_accounts e
        LEFT JOIN countries co ON co.id = e.country_id
        GROUP BY COALESCE(e.country_id, 'PK')
        ORDER BY totalEmployees DESC
      `)
      .all();

    const branches = sqlite.prepare('SELECT id, company_id, country_id, name, code, city, status FROM branches ORDER BY name ASC').all();
    const countries = sqlite.prepare('SELECT id, name, code, status FROM countries ORDER BY name ASC').all();
    const departments = Array.from(new Set(rows.map((r) => r.department).filter(Boolean))).sort();

    res.json({
      employees: filtered,
      summary: {
        totalEmployees: rows.length,
        activeEmployees: rows.filter((r) => r.status === 'Active').length,
        onLeaveEmployees: rows.filter((r) => r.status === 'On Leave').length,
        suspendedEmployees: rows.filter((r) => r.status === 'Suspended').length,
      },
      countryBreakdown,
      branches,
      countries,
      departments,
    });
  });

  router.post('/employees', requirePermission('employees.manage'), (req: Request, res: Response) => {
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const companyId = String(req.body.companyId || 'comp_byd_pk').trim();
    const branchId = req.body.branchId ? String(req.body.branchId).trim() : null;
    const countryId = String(req.body.countryId || 'PK').trim().toUpperCase();
    const department = String(req.body.department || 'Operations').trim();
    const jobPosition = String(req.body.jobPosition || 'Operations Specialist').trim();
    const permissions = Array.isArray(req.body.permissions)
      ? req.body.permissions.map((p: unknown) => String(p).trim()).filter(Boolean)
      : ['tasks.view', 'vehicles.view'];

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Employee full name, email, and mobile are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const emailCollision =
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM user_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (emailCollision) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const company = sqlite.prepare('SELECT id FROM companies WHERE id = ?').get(companyId);
    if (!company) {
      res.status(404).json({ error: 'Parent company not found.' });
      return;
    }

    const id = `emp_${generateSecureToken(5)}`;
    const code = `EMP-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = nowIso();
    const pwHash = hashPassword(password);

    sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO employee_accounts (
            id, company_id, branch_id, country_id, employee_code, full_name, email, mobile,
            department, job_position, status, permissions_json, username, password_hash,
            email_verified, two_factor_enabled, joined_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, 1, 0, ?, ?, ?)
        `)
        .run(
          id,
          companyId,
          branchId,
          countryId,
          code,
          fullName,
          email,
          mobile,
          department,
          jobPosition,
          JSON.stringify(permissions),
          email.split('@')[0],
          pwHash,
          now.slice(0, 10),
          now,
          now
        );

      sqlite
        .prepare(`
          INSERT OR REPLACE INTO user_accounts (
            id, subject_type, source_table, role, full_name, email, mobile,
            company_id, country_id, branch_id, account_code, status, verification_status,
            email_verified, mobile_verified, mfa_enabled, approved_by, approved_at, created_at, updated_at
          ) VALUES (?, 'employee', 'employee_accounts', ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 'Verified', 1, 1, 0, ?, ?, ?, ?)
        `)
        .run(id, jobPosition, fullName, email, mobile, companyId, countryId, branchId, code, req.auth!.fullName, now, now, now);
    })();

    logEmployeeActivity({
      employeeId: id,
      companyId,
      branchId,
      countryId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_PROVISIONED',
      module: 'Employee Management',
      targetId: code,
      details: `${fullName} assigned to ${department} (${jobPosition})`,
      ipAddress: getClientIp(req),
    });

    recordSaEnterpriseAction(req, 'EMPLOYEE_CREATED', 'Employee Management', `${fullName} (${code})`, `Dept: ${department}, Country: ${countryId}`);
    res.status(201).json({ success: true, id, employeeCode: code });
  });

  router.patch('/employees/:id', requirePermission('employees.manage'), (req: Request, res: Response) => {
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }

    const fullName = req.body.fullName !== undefined ? String(req.body.fullName).trim() : emp.full_name;
    const mobile = req.body.mobile !== undefined ? String(req.body.mobile).trim() : emp.mobile;
    const department = req.body.department !== undefined ? String(req.body.department).trim() : emp.department;
    const jobPosition = req.body.jobPosition !== undefined ? String(req.body.jobPosition).trim() : emp.job_position;
    const branchId = req.body.branchId !== undefined ? (req.body.branchId ? String(req.body.branchId).trim() : null) : emp.branch_id;
    const countryId = req.body.countryId !== undefined ? String(req.body.countryId).trim().toUpperCase() : emp.country_id;
    const status = req.body.status && ['Active', 'Suspended', 'On Leave'].includes(String(req.body.status))
      ? String(req.body.status)
      : emp.status;
    const permissions = Array.isArray(req.body.permissions)
      ? req.body.permissions.map((p: unknown) => String(p).trim()).filter(Boolean)
      : safeJsonParse<string[]>(emp.permissions_json, []);

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare(`
          UPDATE employee_accounts
          SET full_name = ?, mobile = ?, department = ?, job_position = ?, branch_id = ?, country_id = ?,
              status = ?, permissions_json = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(fullName, mobile, department, jobPosition, branchId, countryId, status, JSON.stringify(permissions), now, emp.id);

      sqlite
        .prepare('UPDATE user_accounts SET full_name = ?, mobile = ?, role = ?, branch_id = ?, country_id = ?, status = ?, updated_at = ? WHERE id = ?')
        .run(fullName, mobile, jobPosition, branchId, countryId, status, now, emp.id);

      if (status === 'Suspended') {
        sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'employee_suspended', revoked_at = ? WHERE user_id = ?").run(now, emp.id);
      }
    })();

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId,
      countryId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_PROFILE_UPDATED',
      module: 'Employee Management',
      targetId: emp.employee_code,
      details: `Dept: ${department}, Position: ${jobPosition}, Status: ${status}`,
      ipAddress: getClientIp(req),
    });

    recordSaEnterpriseAction(req, 'EMPLOYEE_UPDATED', 'Employee Management', emp.employee_code, `Dept: ${department}, Position: ${jobPosition}, Status: ${status}`);
    res.json({ success: true });
  });

  router.get('/employees/:id/detail', requirePermission('users.view'), (req: Request, res: Response) => {
    const emp = sqlite
      .prepare(`
        SELECT e.*, c.name as company_name, b.name as branch_name, b.city as branch_city, co.name as country_name
        FROM employee_accounts e
        LEFT JOIN companies c ON c.id = e.company_id
        LEFT JOIN branches b ON b.id = e.branch_id
        LEFT JOIN countries co ON co.id = e.country_id
        WHERE e.id = ?
      `)
      .get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }

    const activityLogs = sqlite
      .prepare('SELECT * FROM employee_activity_logs WHERE employee_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(emp.id);

    const loginHistory = sqlite
      .prepare('SELECT id, ip_address, device_name, browser_name, success, failure_reason, created_at FROM login_activity_logs WHERE user_id = ? OR LOWER(identifier) = LOWER(?) ORDER BY created_at DESC LIMIT 15')
      .all(emp.id, emp.email);

    res.json({
      employee: {
        ...emp,
        password_hash: undefined,
        two_factor_secret: undefined,
        permissions: safeJsonParse<string[]>(emp.permissions_json, []),
        attendance: safeJsonParse<any[]>(emp.attendance_json, []),
        leaveRequests: safeJsonParse<any[]>(emp.leave_requests_json, []),
        leaveBalance: safeJsonParse<Record<string, number>>(emp.leave_balance_json, { annual: 18, sick: 10, casual: 8 }),
      },
      activityLogs,
      loginHistory,
    });
  });

  // =========================================================================
  // 4. DEALER MANAGEMENT ANALYTICS (COUNTRY BREAKDOWN + TRANSACTIONS)
  // =========================================================================
  router.get('/dealers/analytics', requirePermission('dealers.manage'), (_req: Request, res: Response) => {
    const countryBreakdown = sqlite
      .prepare(`
        SELECT COALESCE(da.country_id, 'PK') as countryId,
               COALESCE(co.name, da.country_id, 'Pakistan') as countryName,
               COUNT(DISTINCT da.id) as dealerAccounts,
               SUM(CASE WHEN da.verification_status = 'Verified' THEN 1 ELSE 0 END) as verifiedDealers,
               SUM(CASE WHEN da.status = 'Active' THEN 1 ELSE 0 END) as activeDealers,
               COALESCE((SELECT COUNT(*) FROM dealer_sales ds WHERE ds.country_id = da.country_id), 0) as totalSales,
               COALESCE((SELECT SUM(sale_amount_pkr) FROM dealer_sales ds WHERE ds.country_id = da.country_id), 0) as totalSalesVolumePkr,
               COALESCE((SELECT SUM(commission_amount_pkr) FROM dealer_commissions dc WHERE dc.country_id = da.country_id), 0) as totalCommissionPkr
        FROM dealer_accounts da
        LEFT JOIN countries co ON co.id = da.country_id
        GROUP BY COALESCE(da.country_id, 'PK')
        ORDER BY totalSalesVolumePkr DESC
      `)
      .all();

    const recentTransactions = sqlite
      .prepare(`
        SELECT ds.*, da.business_name as dealer_name, da.dealer_code, dc.full_name as customer_name
        FROM dealer_sales ds
        LEFT JOIN dealer_accounts da ON da.id = ds.dealer_id
        LEFT JOIN dealer_customers dc ON dc.id = ds.customer_id
        ORDER BY ds.created_at DESC
        LIMIT 40
      `)
      .all();

    const dealerPerformance = sqlite
      .prepare(`
        SELECT da.id, da.dealer_code, da.business_name, da.category, da.country_id, da.status, da.verification_status,
               c.name as company_name,
               (SELECT COUNT(*) FROM dealer_vehicle_inventory di WHERE di.dealer_id = da.id) as stockUnits,
               (SELECT COUNT(*) FROM dealer_bookings db WHERE db.dealer_id = da.id) as bookingsCount,
               (SELECT COUNT(*) FROM dealer_sales ds WHERE ds.dealer_id = da.id) as salesCount,
               COALESCE((SELECT SUM(sale_amount_pkr) FROM dealer_sales ds WHERE ds.dealer_id = da.id), 0) as salesRevenuePkr,
               COALESCE((SELECT SUM(commission_amount_pkr) FROM dealer_commissions dm WHERE dm.dealer_id = da.id), 0) as commissionPkr
        FROM dealer_accounts da
        LEFT JOIN companies c ON c.id = da.company_id
        ORDER BY salesRevenuePkr DESC
      `)
      .all();

    res.json({ countryBreakdown, recentTransactions, dealerPerformance });
  });

  // =========================================================================
  // 5. CUSTOMER MANAGEMENT PRIVACY-PROTECTED PROFILE INSPECTOR
  // =========================================================================
  router.get('/customers/:id/detail', requirePermission('customers.manage'), (req: Request, res: Response) => {
    const cust = sqlite
      .prepare(`
        SELECT c.*, comp.name as company_name, b.name as branch_name, co.name as country_name
        FROM customer_accounts c
        LEFT JOIN companies comp ON comp.id = c.company_id
        LEFT JOIN branches b ON b.id = c.branch_id
        LEFT JOIN countries co ON co.id = c.country_id
        WHERE c.id = ?
      `)
      .get(req.params.id) as any;

    if (!cust) {
      res.status(404).json({ error: 'Customer account not found.' });
      return;
    }

    const isFounder = req.auth!.subjectType === 'founder';
    const profile = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(cust.id) as any;
    const vehicles = sqlite.prepare('SELECT * FROM customer_vehicles WHERE customer_id = ?').all(cust.id);
    const inquiries = sqlite.prepare('SELECT * FROM customer_inquiries WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20').all(cust.id);
    const bookings = sqlite.prepare('SELECT * FROM customer_bookings WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20').all(cust.id);
    const payments = sqlite.prepare('SELECT id, payment_ref, amount_pkr, payment_method, payment_status, payment_date as paid_at, created_at FROM customer_payments WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20').all(cust.id);
    const serviceRequests = sqlite.prepare('SELECT * FROM customer_service_requests WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20').all(cust.id);
    const warrantyClaims = sqlite.prepare('SELECT * FROM customer_warranty_claims WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20').all(cust.id);
    const activity = sqlite.prepare('SELECT * FROM customer_activity_logs WHERE customer_id = ? ORDER BY created_at DESC LIMIT 25').all(cust.id);

    res.json({
      customer: {
        ...cust,
        password_hash: undefined,
        two_factor_secret: undefined,
        mobileMasked: maskPhone(cust.mobile, isFounder),
      },
      profile: profile
        ? {
            ...profile,
            cnic_or_id: maskSensitiveId(profile.cnic_or_id, isFounder),
            emergency_contact: maskPhone(profile.emergency_contact, isFounder),
          }
        : null,
      vehicles,
      inquiries,
      bookings,
      payments,
      serviceRequests,
      warrantyClaims,
      activity,
      privacyMode: isFounder ? 'Founder Full Access' : 'PII Protected (Sensitive IDs Masked)',
    });
  });

  // =========================================================================
  // 6. REAL SYSTEM MONITORING (API LATENCY, DB HEALTH, NODE METRICS, ALERTS)
  // =========================================================================
  router.get('/monitoring', requirePermission('audit_logs.view'), (_req: Request, res: Response) => {
    const dbStart = performance.now();
    const pingRow = sqlite.prepare('SELECT 1 as ok').get() as any;
    const dbLatencyMs = Math.round((performance.now() - dbStart) * 1000) / 1000;

    const dbPath = path.resolve(process.cwd(), 'data', 'byd360.db');
    let dbSizeBytes = 0;
    try {
      dbSizeBytes = fs.statSync(dbPath).size;
    } catch {
      dbSizeBytes = 0;
    }
    const journalModeRow = sqlite.pragma('journal_mode', { simple: true });

    const tableCounts = {
      userAccounts: (sqlite.prepare('SELECT COUNT(*) as c FROM user_accounts').get() as any).c,
      companies: (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c,
      branches: (sqlite.prepare('SELECT COUNT(*) as c FROM branches').get() as any).c,
      employees: (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c,
      dealers: (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_accounts').get() as any).c,
      customers: (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts').get() as any).c,
      vehicles: (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles').get() as any).c,
      bookings: (sqlite.prepare('SELECT COUNT(*) as c FROM bookings').get() as any).c,
      adminActivityLogs: (sqlite.prepare('SELECT COUNT(*) as c FROM admin_activity_logs').get() as any).c,
      loginActivityLogs: (sqlite.prepare('SELECT COUNT(*) as c FROM login_activity_logs').get() as any).c,
    };

    const mem = process.memoryUsage();
    const totalSysMemMb = Math.round(os.totalmem() / (1024 * 1024));
    const freeSysMemMb = Math.round(os.freemem() / (1024 * 1024));
    const usedSysMemPct = totalSysMemMb > 0 ? Math.round(((totalSysMemMb - freeSysMemMb) / totalSysMemMb) * 1000) / 10 : 0;

    const apiTelemetry = getApiTelemetrySnapshot();

    const now = nowIso();
    const last24h = new Date(Date.now() - 24 * 3600 * 1000).toISOString();

    const failedLogins24h = (
      sqlite.prepare('SELECT COUNT(*) as c FROM login_activity_logs WHERE success = 0 AND created_at >= ?').get(last24h) as any
    ).c;
    const recentFailedLogins = sqlite
      .prepare('SELECT id, identifier, subject_type, role, ip_address, device_name, browser_name, failure_reason, suspicious, created_at FROM login_activity_logs WHERE success = 0 ORDER BY created_at DESC LIMIT 20')
      .all();

    const activeSessions = sqlite
      .prepare(`
        SELECT s.id, s.user_id, s.subject_type, s.role, s.ip_address, s.device_label, s.last_activity_at, s.expires_at,
               ua.full_name, ua.email
        FROM authentication_sessions s
        LEFT JOIN user_accounts ua ON ua.id = s.user_id
        WHERE s.revoked = 0 AND s.expires_at > ? AND s.subject_type != 'founder'
        ORDER BY s.last_activity_at DESC
        LIMIT 40
      `)
      .all(now);

    const expiredUnrevokedCount = (
      sqlite.prepare('SELECT COUNT(*) as c FROM authentication_sessions WHERE revoked = 0 AND expires_at <= ?').get(now) as any
    ).c;

    const securityEvents = sqlite
      .prepare("SELECT * FROM security_events WHERE event_type NOT LIKE '%FOUNDER%' ORDER BY created_at DESC LIMIT 25")
      .all() as any[];

    const aiErrorLogs = sqlite
      .prepare("SELECT id, user_id, role, model as model_used, endpoint as feature_type, status, error_message, created_at FROM ai_usage_logs WHERE status != 'SUCCESS' ORDER BY created_at DESC LIMIT 15")
      .all() as any[];

    const alerts: Array<{ severity: 'INFO' | 'WARNING' | 'CRITICAL'; code: string; message: string }> = [];
    if (apiTelemetry.total5xxResponses > 0) {
      alerts.push({
        severity: 'CRITICAL',
        code: 'HTTP_5XX_DETECTED',
        message: `${apiTelemetry.total5xxResponses} server 5xx error response(s) observed since process boot.`,
      });
    }
    if (failedLogins24h >= 5) {
      alerts.push({
        severity: 'WARNING',
        code: 'FAILED_LOGIN_THRESHOLD',
        message: `${failedLogins24h} failed authentication attempts recorded across portals in the last 24 hours.`,
      });
    }
    if (dbLatencyMs > 50) {
      alerts.push({
        severity: 'WARNING',
        code: 'DB_LATENCY_ELEVATED',
        message: `SQLite query latency measured at ${dbLatencyMs}ms (>50ms threshold).`,
      });
    }
    if (usedSysMemPct > 90) {
      alerts.push({
        severity: 'WARNING',
        code: 'MEMORY_PRESSURE',
        message: `System host memory utilization at ${usedSysMemPct}%.`,
      });
    }
    if (alerts.length === 0) {
      alerts.push({
        severity: 'INFO',
        code: 'SYSTEM_NOMINAL',
        message: 'All API, SQLite database, session, and authentication subsystems operating normally.',
      });
    }

    res.json({
      checkedAt: now,
      server: {
        status: pingRow?.ok === 1 ? 'Healthy' : 'Degraded',
        uptimeSeconds: Math.round(process.uptime()),
        nodeVersion: process.version,
        platform: `${os.platform()} ${os.arch()}`,
        cpuCores: os.cpus().length,
        loadAvg1m: Math.round(os.loadavg()[0] * 100) / 100,
        processMemoryRssMb: Math.round((mem.rss / (1024 * 1024)) * 10) / 10,
        heapUsedMb: Math.round((mem.heapUsed / (1024 * 1024)) * 10) / 10,
        heapTotalMb: Math.round((mem.heapTotal / (1024 * 1024)) * 10) / 10,
        systemMemoryUsedPct: usedSysMemPct,
      },
      database: {
        engine: 'SQLite (better-sqlite3)',
        connected: pingRow?.ok === 1,
        journalMode: String(journalModeRow || 'wal'),
        pingLatencyMs: dbLatencyMs,
        fileSizeMb: Math.round((dbSizeBytes / (1024 * 1024)) * 100) / 100,
        tableCounts,
      },
      api: apiTelemetry,
      security: {
        failedLogins24h,
        activeSessionsCount: activeSessions.length,
        expiredSessionsPendingCleanup: expiredUnrevokedCount,
        recentFailedLogins,
        activeSessions,
        securityEvents,
        aiErrorLogs,
      },
      backgroundJobs: [
        {
          jobName: 'Session Expiry & Token Hygiene',
          status: expiredUnrevokedCount > 0 ? 'Cleanup Pending' : 'Clean',
          detail: `${expiredUnrevokedCount} expired sessions awaiting cleanup; ${activeSessions.length} active scoped sessions`,
        },
        {
          jobName: 'SQLite WAL Persistence & Integrity',
          status: pingRow?.ok === 1 ? 'Active' : 'Error',
          detail: `Mode: ${String(journalModeRow || 'wal').toUpperCase()} · DB Size ${Math.round((dbSizeBytes / (1024 * 1024)) * 100) / 100} MB`,
        },
      ],
      alerts,
    });
  });

  // =========================================================================
  // 7. ACCOUNT & COMPANY VERIFICATION HUB
  // =========================================================================
  router.get('/verification-hub', requirePermission('users.view'), (_req: Request, res: Response) => {
    const companies = sqlite
      .prepare('SELECT id, name, country, city, official_email, authorized_rep, registration_details, tax_id, status, approved_by, approved_at, rejection_reason, documents_json, created_at FROM companies ORDER BY CASE WHEN status = \'Pending Approval\' THEN 0 ELSE 1 END, created_at DESC')
      .all()
      .map((c: any) => ({
        ...c,
        documents: safeJsonParse<any[]>(c.documents_json, []),
      }));

    const companyReviewLogs = sqlite
      .prepare("SELECT * FROM company_activity_logs WHERE module = 'Verification Governance' ORDER BY created_at DESC LIMIT 30")
      .all();

    res.json({
      companies,
      companyReviewLogs,
    });
  });

  router.post('/verification-hub/companies/:id/decision', requirePermission('users.update'), (req: Request, res: Response) => {
    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }

    const decision = String(req.body.decision || '').trim();
    const remarks = String(req.body.remarks || '').trim();
    const valid = ['mark_under_review', 'request_documents', 'verify_documents', 'approve_company'];
    if (!valid.includes(decision)) {
      res.status(400).json({ error: 'Invalid company verification decision.' });
      return;
    }

    if ((decision === 'request_documents' || decision === 'verify_documents') && !remarks) {
      res.status(400).json({ error: 'Verification remarks are required when reviewing or requesting additional documents.' });
      return;
    }

    if (decision === 'approve_company' && req.auth!.subjectType !== 'founder') {
      res.status(403).json({
        error: 'Final company workspace activation belongs exclusively to the Primary Owner (Founder). Use "Verify Documents" to complete Super Admin KYC check.',
      });
      return;
    }

    const now = nowIso();
    const info = safeJsonParse<Record<string, any>>(comp.business_info_json, {});
    info.superAdminVerification = {
      status:
        decision === 'verify_documents'
          ? 'Documents Verified (Awaiting Founder Activation)'
          : decision === 'request_documents'
            ? 'Additional Documents Requested'
            : decision === 'approve_company'
              ? 'Approved & Verified'
              : 'Under Review',
      remarks: remarks || 'Reviewed by verification compliance desk',
      reviewedBy: req.auth!.fullName,
      reviewedRole: req.auth!.role,
      reviewedAt: now,
    };

    if (decision === 'approve_company' && req.auth!.subjectType === 'founder') {
      sqlite
        .prepare("UPDATE companies SET status = 'Approved', approved_by = ?, approved_at = ?, business_info_json = ? WHERE id = ?")
        .run(req.auth!.fullName, now, JSON.stringify(info), comp.id);
    } else {
      sqlite
        .prepare('UPDATE companies SET business_info_json = ? WHERE id = ?')
        .run(JSON.stringify(info), comp.id);
    }

    logCompanyActivity({
      companyId: comp.id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `COMPANY_VERIFICATION_${decision.toUpperCase()}`,
      module: 'Verification Governance',
      targetId: comp.id,
      details: remarks || info.superAdminVerification.status,
      ipAddress: getClientIp(req),
    });

    recordSaEnterpriseAction(req, `COMPANY_${decision.toUpperCase()}`, 'Verification Hub', comp.id, `${comp.name}: ${remarks || info.superAdminVerification.status}`);
    res.json({ success: true, verificationSummary: info.superAdminVerification });
  });

  // =========================================================================
  // 8. REPORTS & ANALYTICS (DAILY/WEEKLY/MONTHLY/YEARLY/CUSTOM + EXPORT)
  // =========================================================================
  function buildEnterpriseAnalytics(period: string, fromDate?: string, toDate?: string, country?: string) {
    const range = resolveDateRange(period, fromDate, toDate);
    const cleanCountry = country && country !== 'ALL' ? country.trim() : '';

    const countryList = sqlite.prepare('SELECT id, name, code FROM countries').all() as Array<{ id: string; name: string; code: string }>;
    const matchedCountry = cleanCountry
      ? countryList.find((c) => c.id.toUpperCase() === cleanCountry.toUpperCase() || c.name.toLowerCase() === cleanCountry.toLowerCase())
      : null;

    const cCode = matchedCountry ? matchedCountry.id : cleanCountry;
    const cName = matchedCountry ? matchedCountry.name : cleanCountry;

    const totalUsers = (sqlite.prepare("SELECT COUNT(*) as c FROM user_accounts WHERE subject_type != 'founder' AND created_at BETWEEN ? AND ?").get(range.fromIso, range.toIso) as any).c;
    const totalCompanies = (sqlite.prepare('SELECT COUNT(*) as c FROM companies WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;
    const totalEmployees = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;
    const totalDealers = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_accounts WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;
    const totalCustomers = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;
    const totalVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;
    const totalSalesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_sales WHERE created_at BETWEEN ? AND ?').get(range.fromIso, range.toIso) as any).c;

    // Country-wise summary across authoritative tables
    const countryBreakdown = sqlite
      .prepare(`
        SELECT co.id as countryCode, co.name as countryName,
               (SELECT COUNT(*) FROM companies comp WHERE LOWER(comp.country) = LOWER(co.name) OR UPPER(comp.country) = UPPER(co.id)) as companiesCount,
               (SELECT COUNT(*) FROM branches br WHERE br.country_id = co.id) as branchesCount,
               (SELECT COUNT(*) FROM employee_accounts ea WHERE COALESCE(ea.country_id, 'PK') = co.id) as employeesCount,
               (SELECT COUNT(*) FROM dealer_accounts da WHERE da.country_id = co.id) as dealersCount,
               (SELECT COUNT(*) FROM customer_accounts ca WHERE ca.country_id = co.id) as customersCount,
               (SELECT COUNT(*) FROM dealer_sales ds WHERE ds.country_id = co.id AND ds.created_at BETWEEN ? AND ?) as dealerSalesCount,
               COALESCE((SELECT SUM(sale_amount_pkr) FROM dealer_sales ds WHERE ds.country_id = co.id AND ds.created_at BETWEEN ? AND ?), 0) as dealerRevenuePkr
        FROM countries co
        ORDER BY dealerRevenuePkr DESC, customersCount DESC
      `)
      .all(range.fromIso, range.toIso, range.fromIso, range.toIso)
      .filter((row: any) => !cCode || row.countryCode.toUpperCase() === cCode.toUpperCase() || row.countryName.toLowerCase() === cName.toLowerCase());

    const verificationReport = sqlite
      .prepare(`
        SELECT verification_status as status, COUNT(*) as count
        FROM identity_verification_records
        WHERE updated_at BETWEEN ? AND ?
        GROUP BY verification_status
        ORDER BY count DESC
      `)
      .all(range.fromIso, range.toIso);

    const userActivityTrend = sqlite
      .prepare(`
        SELECT SUBSTR(created_at, 1, 10) as date,
               COUNT(*) as loginAttempts,
               SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successfulLogins,
               SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as failedLogins
        FROM login_activity_logs
        WHERE subject_type != 'founder' AND created_at BETWEEN ? AND ?
        GROUP BY SUBSTR(created_at, 1, 10)
        ORDER BY date ASC
        LIMIT 31
      `)
      .all(range.fromIso, range.toIso);

    const dealerPerformance = sqlite
      .prepare(`
        SELECT da.id, da.dealer_code, da.business_name, da.country_id, da.verification_status,
               COUNT(ds.id) as salesCount,
               COALESCE(SUM(ds.sale_amount_pkr), 0) as revenuePkr,
               COALESCE((SELECT COUNT(*) FROM dealer_bookings db WHERE db.dealer_id = da.id AND db.created_at BETWEEN ? AND ?), 0) as bookingsCount
        FROM dealer_accounts da
        LEFT JOIN dealer_sales ds ON ds.dealer_id = da.id AND ds.created_at BETWEEN ? AND ?
        ${cCode ? 'WHERE da.country_id = ?' : ''}
        GROUP BY da.id
        ORDER BY revenuePkr DESC
      `)
      .all(...(cCode ? [range.fromIso, range.toIso, range.fromIso, range.toIso, cCode] : [range.fromIso, range.toIso, range.fromIso, range.toIso]));

    const employeePerformance = sqlite
      .prepare(`
        SELECT department,
               COUNT(*) as headcount,
               SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as activeCount,
               ROUND(AVG(performance_score), 1) as avgScore
        FROM employee_accounts
        ${cCode ? "WHERE COALESCE(country_id, 'PK') = ?" : ''}
        GROUP BY department
        ORDER BY avgScore DESC
      `)
      .all(...(cCode ? [cCode] : []));

    const companyPerformance = sqlite
      .prepare(`
        SELECT comp.id, comp.name, comp.country, comp.status,
               (SELECT COUNT(*) FROM branches br WHERE br.company_id = comp.id) as branchesCount,
               (SELECT COUNT(*) FROM employee_accounts ea WHERE ea.company_id = comp.id) as employeesCount,
               (SELECT COUNT(*) FROM dealer_accounts da WHERE da.company_id = comp.id) as dealersCount,
               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id = comp.id) as vehiclesCount,
               COALESCE((SELECT SUM(total_amount) FROM payments_invoices pi WHERE pi.company_id = comp.id AND pi.status = 'Paid' AND pi.created_at BETWEEN ? AND ?), 0) as paidInvoicesPkr
        FROM companies comp
        ORDER BY paidInvoicesPkr DESC
      `)
      .all(range.fromIso, range.toIso);

    const systemActivity = sqlite
      .prepare(`
        SELECT module, COUNT(*) as actionsCount
        FROM admin_activity_logs
        WHERE created_at BETWEEN ? AND ?
        GROUP BY module
        ORDER BY actionsCount DESC
      `)
      .all(range.fromIso, range.toIso);

    const securityReport = sqlite
      .prepare(`
        SELECT severity, COUNT(*) as count,
               SUM(CASE WHEN acknowledged = 0 THEN 1 ELSE 0 END) as unacknowledged
        FROM security_events
        WHERE event_type NOT LIKE '%FOUNDER%' AND created_at BETWEEN ? AND ?
        GROUP BY severity
      `)
      .all(range.fromIso, range.toIso);

    return {
      generatedAt: nowIso(),
      periodLabel: range.label,
      fromIso: range.fromIso,
      toIso: range.toIso,
      countryFilter: cleanCountry || 'ALL',
      summary: {
        totalUsers,
        totalCompanies,
        totalEmployees,
        totalDealers,
        totalCustomers,
        totalVehicles,
        totalSalesCount,
        totalCountries: countryList.length,
      },
      countryBreakdown,
      verificationReport,
      userActivityTrend,
      dealerPerformance,
      employeePerformance,
      companyPerformance,
      systemActivity,
      securityReport,
      countries: countryList,
    };
  }

  router.get('/reports/analytics', requirePermission('reports.view'), (req: Request, res: Response) => {
    const period = String(req.query.period || 'all').trim().toLowerCase();
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const country = req.query.country ? String(req.query.country) : undefined;

    const analytics = buildEnterpriseAnalytics(period, fromDate, toDate, country);
    recordSaEnterpriseAction(req, 'ANALYTICS_REPORT_VIEWED', 'Reports & Analytics', analytics.periodLabel, `Country: ${analytics.countryFilter}`);
    res.json(analytics);
  });

  router.get('/reports/export', requirePermission('reports.view'), (req: Request, res: Response) => {
    const format = String(req.query.format || 'csv').toLowerCase();
    const period = String(req.query.period || 'all').trim().toLowerCase();
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const country = req.query.country ? String(req.query.country) : undefined;

    const analytics = buildEnterpriseAnalytics(period, fromDate, toDate, country);
    recordSaEnterpriseAction(req, 'ANALYTICS_REPORT_EXPORTED', 'Reports & Analytics', format.toUpperCase(), `${analytics.periodLabel} · Country ${analytics.countryFilter}`);

    if (format === 'pdf') {
      const lines = [
        `BYD PAKISTAN 360 - SUPER ADMIN ENTERPRISE REPORT`,
        `Founder & CEO: Intekhab Alam | Generated By: ${req.auth!.fullName}`,
        `Period: ${analytics.periodLabel} | Country: ${analytics.countryFilter}`,
        `Generated At: ${analytics.generatedAt}`,
        `------------------------------------------------------------`,
        `SUMMARY: Users=${analytics.summary.totalUsers}, Companies=${analytics.summary.totalCompanies}, Employees=${analytics.summary.totalEmployees}`,
        `SUMMARY: Dealers=${analytics.summary.totalDealers}, Customers=${analytics.summary.totalCustomers}, Vehicles=${analytics.summary.totalVehicles}, Sales=${analytics.summary.totalSalesCount}`,
        `------------------------------------------------------------`,
        `COUNTRY BREAKDOWN:`,
        ...(analytics.countryBreakdown as any[]).map(
          (c) => ` - ${c.countryName} (${c.countryCode}): Companies=${c.companiesCount}, Branches=${c.branchesCount}, Employees=${c.employeesCount}, Dealers=${c.dealersCount}, Customers=${c.customersCount}, Sales=${c.dealerSalesCount}`
        ),
        `------------------------------------------------------------`,
        `COMPANY PERFORMANCE:`,
        ...(analytics.companyPerformance as any[]).map(
          (c) => ` - ${c.name} [${c.status}]: Branches=${c.branchesCount}, Employees=${c.employeesCount}, Vehicles=${c.vehiclesCount}, Revenue=PKR ${c.paidInvoicesPkr}`
        ),
        `------------------------------------------------------------`,
        `DEALER PERFORMANCE:`,
        ...(analytics.dealerPerformance as any[]).slice(0, 15).map(
          (d) => ` - ${d.business_name} (${d.dealer_code}): Sales=${d.salesCount}, Bookings=${d.bookingsCount}, Revenue=PKR ${d.revenuePkr}`
        ),
      ];
      const pdf = buildSimplePdfBuffer(`BYD PAKISTAN 360 - Super Admin Report (${period})`, lines);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360_SuperAdmin_Report_${period}.pdf"`);
      res.send(pdf);
      return;
    }

    const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csvRows: string[] = [
      ['Section', 'Name / Code', 'Region / Category', 'Metric 1', 'Metric 2', 'Metric 3'].map(esc).join(','),
      ['Summary', 'Users', analytics.periodLabel, analytics.summary.totalUsers, '', ''].map(esc).join(','),
      ['Summary', 'Companies', analytics.periodLabel, analytics.summary.totalCompanies, '', ''].map(esc).join(','),
      ['Summary', 'Employees', analytics.periodLabel, analytics.summary.totalEmployees, '', ''].map(esc).join(','),
      ['Summary', 'Dealers', analytics.periodLabel, analytics.summary.totalDealers, '', ''].map(esc).join(','),
      ['Summary', 'Customers', analytics.periodLabel, analytics.summary.totalCustomers, '', ''].map(esc).join(','),
      ...(analytics.countryBreakdown as any[]).map((c) =>
        ['Country', c.countryName, c.countryCode, `Employees:${c.employeesCount}`, `Dealers:${c.dealersCount}`, `Customers:${c.customersCount}`].map(esc).join(',')
      ),
      ...(analytics.companyPerformance as any[]).map((c) =>
        ['Company', c.name, c.country, `Branches:${c.branchesCount}`, `Vehicles:${c.vehiclesCount}`, `RevenuePKR:${c.paidInvoicesPkr}`].map(esc).join(',')
      ),
      ...(analytics.dealerPerformance as any[]).map((d) =>
        ['Dealer', `${d.business_name} (${d.dealer_code})`, d.country_id, `Sales:${d.salesCount}`, `Bookings:${d.bookingsCount}`, `RevenuePKR:${d.revenuePkr}`].map(esc).join(',')
      ),
      ...(analytics.employeePerformance as any[]).map((e) =>
        ['Employee Dept', e.department, 'All', `Headcount:${e.headcount}`, `Active:${e.activeCount}`, `AvgScore:${e.avgScore}`].map(esc).join(',')
      ),
    ];

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="BYD360_SuperAdmin_Report_${period}.csv"`);
    res.send('\uFEFF' + csvRows.join('\n'));
  });

  // =========================================================================
  // 9. IMMUTABLE SUPER ADMIN ACTIVITY LOGS (SEARCH/FILTER, NO DELETE/EDIT)
  // =========================================================================
  router.get('/activity-logs/enterprise', requirePermission('audit_logs.view'), (req: Request, res: Response) => {
    const search = String(req.query.search || '').trim().toLowerCase();
    const moduleFilter = String(req.query.module || '').trim();
    const statusFilter = String(req.query.status || '').trim();
    const fromDate = String(req.query.fromDate || '').trim();
    const toDate = String(req.query.toDate || '').trim();

    const rawActivities = sqlite
      .prepare('SELECT * FROM admin_activity_logs ORDER BY created_at DESC LIMIT 300')
      .all() as any[];

    const filteredActivities = rawActivities.filter((a) => {
      if (moduleFilter && moduleFilter !== 'ALL' && a.module !== moduleFilter) return false;
      if (statusFilter && statusFilter !== 'ALL' && a.status !== statusFilter) return false;
      if (fromDate && a.created_at.slice(0, 10) < fromDate) return false;
      if (toDate && a.created_at.slice(0, 10) > toDate) return false;
      if (search) {
        const hay = `${a.admin_name} ${a.action} ${a.module} ${a.target_id || ''} ${a.details || ''} ${a.ip_address || ''} ${a.device_name || ''}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    const saLoginHistory = sqlite
      .prepare(`
        SELECT id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, device_name, browser_name, session_id, suspicious, logout_at, created_at
        FROM login_activity_logs
        WHERE subject_type = 'super_admin'
        ORDER BY created_at DESC
        LIMIT 80
      `)
      .all();

    const securityEvents = sqlite
      .prepare("SELECT * FROM security_events WHERE event_type NOT LIKE '%FOUNDER%' ORDER BY created_at DESC LIMIT 80")
      .all();

    const modules = Array.from(new Set(rawActivities.map((a) => a.module).filter(Boolean))).sort();

    res.json({
      immutable: true,
      activities: filteredActivities,
      saLoginHistory,
      securityEvents,
      modules,
    });
  });

  return router;
}
