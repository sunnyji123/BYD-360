import React, { useState, useEffect, useCallback } from 'react';
import { UserCheck, Eye, Shield, Search } from 'lucide-react';
import { api } from '../../services/api';
import { AdminCustomerGovernancePanel } from '../customer/AdminCustomerGovernancePanel';

interface Props {
  formatPrice: (n: number) => string;
}

export const SuperAdminCustomersHubPanel: React.FC<Props> = ({ formatPrice }) => {
  const [customers, setCustomers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [detail, setDetail] = useState<any>(null);
  const [error, setError] = useState('');

  const loadCustomers = useCallback(async () => {
    try {
      const res = await api.getAdminCustomersOverview('super-admin', search ? { q: search } : undefined);
      setCustomers(res.customers || []);
    } catch {
      setCustomers([]);
    }
  }, [search]);

  useEffect(() => {
    loadCustomers();
  }, [loadCustomers]);

  const inspectCustomer = async (id: string) => {
    setError('');
    try {
      const res = await api.getSuperAdminCustomerDetail(id);
      setDetail(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to inspect customer dossier.');
    }
  };

  return (
    <div className="space-y-6 text-xs">
      {/* Privacy-Protected Customer Dossier Search & Inspector */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              PII-Protected Customer Intelligence
            </div>
            <h3 className="text-base font-black text-white mt-0.5">
              Customer Profiles, Purchases, Inquiries, Orders &amp; Service Requests
            </h3>
            <p className="text-slate-400 mt-0.5">
              Sensitive personal identification (CNIC/Passport) and phone details are automatically masked unless accessed by Primary Owner.
            </p>
          </div>
          <div className="relative w-full md:w-72">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Find customer by name, code, city..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
        </div>

        {error && <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {customers.map((c) => (
            <div key={c.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="font-bold text-white truncate">{c.full_name}</div>
                <div className="font-mono text-[10px] text-cyan-300 truncate">{c.customer_code} · {c.city}, {c.country}</div>
                <div className="text-[10px] text-slate-400 font-mono">
                  Bookings: {c.booking_count ?? 0} · Inquiries: {c.inquiry_count ?? 0} · {c.verification_status}
                </div>
              </div>
              <button
                type="button"
                onClick={() => inspectCustomer(c.id)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 font-bold flex items-center gap-1 shrink-0"
              >
                <Eye className="w-3 h-3" />
                <span>Inspect</span>
              </button>
            </div>
          ))}
        </div>

        {detail?.customer && (
          <div className="p-5 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-400">
                  <Shield className="w-3.5 h-3.5" />
                  <span>{detail.privacyMode}</span>
                </div>
                <h4 className="text-sm font-black text-white mt-0.5">
                  {detail.customer.full_name} ({detail.customer.customer_code}) · {detail.customer.email}
                </h4>
                <div className="text-[11px] text-slate-400 font-mono">
                  Mobile: {detail.customer.mobileMasked} · ID: {detail.profile?.cnic_or_id || 'Masked'} · Status: {detail.customer.status} ({detail.customer.verification_status})
                </div>
              </div>
              <button type="button" onClick={() => setDetail(null)} className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300">
                Close Dossier
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5">
                <div className="font-bold text-white">Bookings &amp; Orders ({detail.bookings?.length || 0})</div>
                {(detail.bookings || []).map((b: any) => (
                  <div key={b.id} className="text-[11px] p-2 rounded bg-slate-950 border border-slate-800">
                    <div className="font-mono text-cyan-300">{b.booking_ref} · {b.vehicle_model}</div>
                    <div className="text-slate-400">{b.booking_status} · {formatPrice(b.estimated_price_pkr || 0)}</div>
                  </div>
                ))}
                {(!detail.bookings || detail.bookings.length === 0) && <div className="text-slate-500">No bookings recorded.</div>}
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5">
                <div className="font-bold text-white">Inquiries &amp; Service ({(detail.inquiries?.length || 0) + (detail.serviceRequests?.length || 0)})</div>
                {(detail.inquiries || []).slice(0, 4).map((i: any) => (
                  <div key={i.id} className="text-[11px] p-2 rounded bg-slate-950 border border-slate-800">
                    <div className="font-semibold text-white">{i.subject}</div>
                    <div className="text-slate-400">Inquiry · {i.status}</div>
                  </div>
                ))}
                {(detail.serviceRequests || []).slice(0, 4).map((s: any) => (
                  <div key={s.id} className="text-[11px] p-2 rounded bg-slate-950 border border-slate-800">
                    <div className="font-semibold text-cyan-300">{s.service_type}</div>
                    <div className="text-slate-400">Service · {s.status}</div>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5">
                <div className="font-bold text-white">Recent Customer Activity ({detail.activity?.length || 0})</div>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {(detail.activity || []).map((a: any) => (
                    <div key={a.id} className="text-[11px] p-2 rounded bg-slate-950 border border-slate-800">
                      <div className="font-mono text-emerald-300">{a.action}</div>
                      <div className="text-slate-400">{a.module} · {a.created_at?.slice(0, 16)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Existing Full Customer Governance Controls */}
      <AdminCustomerGovernancePanel scope="super-admin" />
    </div>
  );
};
