import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { initializeDatabase, sqlite, getSystemSetting } from './server/db';
import {
  attachAuthContext,
  requireCsrfProtection,
  createAuthAndOwnerRouter,
  requireFounder,
  requireSuperAdmin,
  requirePermission,
  requireCompanyAdmin,
  requireCompanyPermission,
  requireCountryManager,
  requireCountryPermission,
  requireBranchManager,
  requireBranchPermission,
} from './server/auth';
import { createOwnerDashboardRouter } from './server/ownerDashboard';
import { createVerificationSecurityRouter, createAdminVerificationRouter } from './server/verificationSecurity';
import { createAiRouter } from './server/ai';
import { createDomainRouter } from './server/domain';
import { createSuperAdminRouter } from './server/superAdmin';
import { createSuperAdminEnterpriseRouter } from './server/superAdminEnterprise';
import { apiTelemetryMiddleware } from './server/telemetry';
import { createCompanyAdminRouter } from './server/companyAdmin';
import { createCountryManagerRouter } from './server/countryManager';
import { createBranchManagerRouter } from './server/branchManager';
import { createEmployeeRouter } from './server/employee';
import { createDealerRouter } from './server/dealer';
import { createAdminDealersRouter } from './server/adminDealers';
import { createCustomerRouter } from './server/customer';
import { createAdminCustomersRouter } from './server/adminCustomers';
import { createCompanyBranchManagementRouter } from './server/companyBranchManagement';
import { createEmployeeManagementRouter } from './server/employeeManagement';
import { createDealershipManagementRouter } from './server/dealershipManagement';

dotenv.config();

// Initialize persistent relational SQLite database
initializeDatabase();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.set('trust proxy', true);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Attach real API telemetry, verified session auth context & enforce CSRF origin checks on cookie mutations
app.use('/api', apiTelemetryMiddleware);
app.use('/api', attachAuthContext);
app.use('/api', requireCsrfProtection);

// Mount real authentication, Founder/Owner portal, Super Admin portal, Company Admin portal, Country Manager portal, Branch Manager portal, Employee portal, Dealer portal, Customer portal, Verification & Account Security, BYD AI, and domain APIs
app.use('/api', createAuthAndOwnerRouter());
app.use('/api/owner', createOwnerDashboardRouter());
app.use('/api/verification', createVerificationSecurityRouter());
app.use('/api/admin/verifications', createAdminVerificationRouter());
app.use('/api/owner/dealers', createAdminDealersRouter({ scope: 'founder', middlewares: [requireFounder] }));
app.use('/api/owner/customer-governance', createAdminCustomersRouter({ scope: 'founder', middlewares: [requireFounder] }));
app.use('/api/super-admin', createSuperAdminRouter());
app.use('/api/super-admin', createSuperAdminEnterpriseRouter());
app.use('/api/super-admin/dealers', createAdminDealersRouter({ scope: 'super_admin', middlewares: [requireSuperAdmin, requirePermission('dealers.manage')] }));
app.use('/api/super-admin/customer-governance', createAdminCustomersRouter({ scope: 'super_admin', middlewares: [requireSuperAdmin, requirePermission('customers.manage')] }));
app.use('/api/company-admin', createCompanyAdminRouter());
app.use('/api/company-admin/dealers', createAdminDealersRouter({ scope: 'company_admin', middlewares: [requireCompanyAdmin, requireCompanyPermission('dealers.manage')] }));
app.use('/api/company-admin/customer-governance', createAdminCustomersRouter({ scope: 'company_admin', middlewares: [requireCompanyAdmin, requireCompanyPermission('customers.manage')] }));
app.use('/api/country-manager', createCountryManagerRouter());
app.use('/api/country-manager/dealers', createAdminDealersRouter({ scope: 'country_manager', middlewares: [requireCountryManager, requireCountryPermission('dealers.manage')] }));
app.use('/api/country-manager/customer-governance', createAdminCustomersRouter({ scope: 'country_manager', middlewares: [requireCountryManager, requireCountryPermission('customers.view')] }));
app.use('/api/branch-manager', createBranchManagerRouter());
app.use('/api/branch-manager/dealers', createAdminDealersRouter({ scope: 'branch_manager', middlewares: [requireBranchManager, requireBranchPermission('dealers.manage')] }));
app.use('/api/branch-manager/customer-governance', createAdminCustomersRouter({ scope: 'branch_manager', middlewares: [requireBranchManager, requireBranchPermission('customers.manage')] }));
app.use('/api/employee', createEmployeeRouter());
app.use('/api/dealer', createDealerRouter());
app.use('/api/customer', createCustomerRouter());
app.use('/api', createAiRouter());
app.use('/api', createDomainRouter());
app.use('/api/org-management', createCompanyBranchManagementRouter());
app.use('/api/employee-management', createEmployeeManagementRouter());
app.use('/api/dealership-management', createDealershipManagementRouter());

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  const aiConfig = getSystemSetting('ai_config', { defaultModel: 'gemini-4-hydrogen', globalEnabled: true });
  const founderCount = (sqlite.prepare('SELECT COUNT(*) as c FROM founder_accounts').get() as any).c;
  const saCount = (sqlite.prepare('SELECT COUNT(*) as c FROM super_admin_accounts').get() as any).c;
  const caCount = (sqlite.prepare('SELECT COUNT(*) as c FROM company_admin_accounts').get() as any).c;
  const cmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM country_manager_accounts').get() as any).c;
  const bmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branch_manager_accounts').get() as any).c;
  const empCount = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c;
  const dealersCount = (sqlite.prepare("SELECT COUNT(*) as c FROM dealer_accounts WHERE status = 'Active' AND verification_status = 'Verified'").get() as any).c;
  const customersCount = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_accounts WHERE status = 'Active'").get() as any).c;
  const companiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c;

  res.json({
    status: 'online',
    platform: 'BYD PAKISTAN 360 Enterprise Automotive Platform',
    founder: 'Intekhab Alam',
    version: '2.0.0-ENTERPRISE-DB',
    timestamp: new Date().toISOString(),
    aiEngine: aiConfig.defaultModel || 'gemini-4-hydrogen',
    aiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
    databaseEngine: 'sqlite-persistent-wal',
    founderProvisioned: founderCount > 0,
    superAdminProvisioned: saCount > 0,
    companyAdminProvisioned: caCount > 0,
    countryManagerProvisioned: cmCount > 0,
    branchManagerProvisioned: bmCount > 0,
    employeePortalProvisioned: empCount > 0,
    employeesCount: empCount,
    dealerPortalProvisioned: dealersCount > 0,
    dealersCount,
    customerPortalProvisioned: customersCount > 0,
    customersCount,
    companiesRegistered: companiesCount,
    securityVerificationProvisioned: true,
  });
});

// Setup Vite middleware or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    app.use('*', async (req: Request, res: Response, next) => {
      const url = req.originalUrl;
      try {
        const templatePath = path.resolve(__dirname, 'index.html');
        let template = await fs.promises.readFile(templatePath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BYD Pakistan 360 Enterprise Server running on http://localhost:${PORT}`);
  });
}

startServer();
