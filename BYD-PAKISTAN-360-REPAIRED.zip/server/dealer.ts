import express, { Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import {
  sqlite,
  PRIVATE_DEALER_DOCS_DIR,
  generateSecureToken,
  generateNumericOtp,
  logDealerActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireDealer,
  requireDealerPermission,
  CANONICAL_DEALER_PERMISSIONS,
  getClientIp,
} from './auth';

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
});

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function recordDealerAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.dealerId || !req.auth?.companyId) return;
  logDealerActivity({
    dealerId: req.auth.dealerId,
    companyId: req.auth.companyId,
    countryId: req.auth.country,
    branchId: req.auth.branchId,
    actorId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function assertNotImpersonatingDealer(req: Request, res: Response): boolean {
  const dealerId = req.auth?.dealerId;
  const dealerCode = req.auth?.dealerCode;
  const compId = req.auth?.companyId;

  const qDealerId = req.query.dealerId ? String(req.query.dealerId).trim() : null;
  const qDealerCode = req.query.dealerCode ? String(req.query.dealerCode).trim().toUpperCase() : null;
  const qCompId = req.query.companyId ? String(req.query.companyId).trim() : null;

  const bDealerId =
    req.body?.dealerId || req.body?.dealer_id
      ? String(req.body.dealerId || req.body.dealer_id).trim()
      : null;
  const bDealerCode =
    req.body?.dealerCode || req.body?.dealer_code
      ? String(req.body.dealerCode || req.body.dealer_code).trim().toUpperCase()
      : null;
  const bCompId =
    req.body?.companyId || req.body?.company_id
      ? String(req.body.companyId || req.body.company_id).trim()
      : null;

  if (
    (qDealerId && qDealerId !== dealerId) ||
    (qDealerCode && qDealerCode !== dealerCode) ||
    (bDealerId && bDealerId !== dealerId) ||
    (bDealerCode && bDealerCode !== dealerCode) ||
    (qCompId && qCompId !== compId) ||
    (bCompId && bCompId !== compId)
  ) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_IMPERSONATION_ATTEMPT_BLOCKED',
      userId: req.auth?.userId,
      identifier: req.auth?.email,
      companyId: compId,
      details: `Dealer ${dealerCode} (${dealerId}) attempted cross-dealer or cross-company parameter override on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    recordDealerAction(
      req,
      'CROSS_DEALER_ACCESS_BLOCKED',
      'Dealer Security',
      qDealerId || bDealerId || qCompId || bCompId,
      'Blocked cross-dealer / cross-company parameter spoofing attempt.',
      'ALERT'
    );
    res.status(403).json({
      error: 'Access Denied: Dealers can strictly access only their own authenticated dealer records.',
    });
    return false;
  }
  return true;
}

export function savePrivateDealerFile(params: {
  buffer: Buffer;
  originalName: string;
  mimeType: string;
  dealerId: string;
  companyId: string;
  docType: string;
  title: string;
  uploadedById: string;
  uploadedByRole: string;
  verificationStatus?: 'Pending Verification' | 'Verified' | 'Rejected';
  reviewedBy?: string | null;
}) {
  if (!ALLOWED_MIME_TYPES.has(params.mimeType)) {
    throw new Error('Unsupported document type. Allowed formats: PDF, JPEG, PNG, WEBP, TXT, CSV, DOC, DOCX.');
  }
  if (!fs.existsSync(PRIVATE_DEALER_DOCS_DIR)) {
    fs.mkdirSync(PRIVATE_DEALER_DOCS_DIR, { recursive: true });
  }

  const ext = path.extname(params.originalName || '').slice(0, 12) || '.bin';
  const docId = `ddoc_${generateSecureToken(6)}`;
  const storageKey = `${docId}_${generateSecureToken(8)}${ext.replace(/[^a-zA-Z0-9._-]/g, '')}`;
  const fullPath = path.join(PRIVATE_DEALER_DOCS_DIR, path.basename(storageKey));

  fs.writeFileSync(fullPath, params.buffer);

  const now = nowIso();
  sqlite
    .prepare(`
      INSERT INTO dealer_documents (
        id, dealer_id, company_id, doc_type, title, original_filename, mime_type,
        size_bytes, storage_key, verification_status, reviewed_by, review_notes,
        uploaded_by_id, uploaded_by_role, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
    `)
    .run(
      docId,
      params.dealerId,
      params.companyId,
      params.docType,
      params.title,
      path.basename(params.originalName || 'document.bin'),
      params.mimeType,
      params.buffer.length,
      path.basename(storageKey),
      params.verificationStatus || 'Pending Verification',
      params.reviewedBy || null,
      params.uploadedById,
      params.uploadedByRole,
      now,
      now
    );

  return {
    id: docId,
    storageKey: path.basename(storageKey),
    createdAt: now,
  };
}

function escapePdfText(input: string): string {
  return String(input || '')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

/**
 * Pure Node.js multi-page PDF 1.4 generator with Helvetica / Helvetica-Bold fonts
 * and accurate byte-offset xref table. Produces genuine downloadable `.pdf` binaries.
 */
export function buildSimplePdfBuffer(title: string, lines: string[]): Buffer {
  const safeLines = lines.map((l) => escapePdfText(l).slice(0, 108));
  const linesPerPage = 44;
  const chunks: string[][] = [];
  for (let i = 0; i < Math.max(1, safeLines.length); i += linesPerPage) {
    chunks.push(safeLines.slice(i, i + linesPerPage));
  }

  // Object allocation:
  // 1: Catalog
  // 2: Pages
  // 3: Font Helvetica
  // 4: Font Helvetica-Bold
  // Then for each page p (0..chunks.length-1):
  //   pageObj = 5 + p*2
  //   contentObj = 6 + p*2
  const objects: Array<{ id: number; body: string }> = [];
  const pageIds: number[] = [];

  chunks.forEach((pageLines, idx) => {
    const pageObjId = 5 + idx * 2;
    const contentObjId = 6 + idx * 2;
    pageIds.push(pageObjId);

    const streamOps: string[] = [];
    streamOps.push('BT');
    streamOps.push('/F2 13 Tf');
    streamOps.push('48 756 Td');
    streamOps.push(`(${escapePdfText(title)} — Page ${idx + 1} of ${chunks.length}) Tj`);
    streamOps.push('/F1 9 Tf');
    streamOps.push('0 -20 Td');
    streamOps.push('14 TL');
    for (const line of pageLines) {
      streamOps.push(`(${line}) Tj`);
      streamOps.push('T*');
    }
    streamOps.push('ET');
    const contentStr = streamOps.join('\n');
    const contentLen = Buffer.byteLength(contentStr, 'utf8');

    objects.push({
      id: pageObjId,
      body: `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentObjId} 0 R >>`,
    });
    objects.push({
      id: contentObjId,
      body: `<< /Length ${contentLen} >>\nstream\n${contentStr}\nendstream`,
    });
  });

  const allObjects: Array<{ id: number; body: string }> = [
    { id: 1, body: '<< /Type /Catalog /Pages 2 0 R >>' },
    { id: 2, body: `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pageIds.length} >>` },
    { id: 3, body: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>' },
    { id: 4, body: '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>' },
    ...objects,
  ].sort((a, b) => a.id - b.id);

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of allObjects) {
    offsets[obj.id] = Buffer.byteLength(pdf, 'utf8');
    pdf += `${obj.id} 0 obj\n${obj.body}\nendobj\n`;
  }

  const xrefOffset = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${allObjects.length + 1}\n`;
  pdf += '0000000000 65535 f \n';
  for (let i = 1; i <= allObjects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${allObjects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return Buffer.from(pdf, 'utf8');
}

function getDealerContextRow(dealerId: string) {
  return sqlite
    .prepare(`
      SELECT da.*,
             dp.business_address, dp.city as profile_city, dp.country_id as profile_country,
             dp.tax_id_ntn, dp.registration_no, dp.website, dp.bank_name, dp.bank_account_title,
             dp.bank_iban_masked, dp.pending_changes_json, dp.pending_change_status,
             dp.pending_change_submitted_at, dp.pending_change_reviewed_by, dp.notes as profile_notes,
             c.name as company_name, c.country as company_country, c.city as company_city,
             b.name as branch_name, b.code as branch_code, b.city as branch_city,
             co.name as country_name, co.currency as country_currency,
             asgn.assigned_manager_id, asgn.assigned_manager_name
      FROM dealer_accounts da
      LEFT JOIN dealer_profiles dp ON dp.dealer_id = da.id
      LEFT JOIN companies c ON c.id = da.company_id
      LEFT JOIN branches b ON b.id = da.branch_id
      LEFT JOIN countries co ON co.id = COALESCE(da.country_id, c.country)
      LEFT JOIN dealer_assignments asgn ON asgn.dealer_id = da.id AND asgn.status = 'Active'
      WHERE da.id = ?
    `)
    .get(dealerId) as any;
}

function buildDealerReportData(dealerId: string, contextRow: any) {
  const inventoryStats = sqlite
    .prepare(`
      SELECT
        COUNT(*) as totalAssigned,
        COALESCE(SUM(CASE WHEN availability_status = 'Available' THEN 1 ELSE 0 END), 0) as availableCount,
        COALESCE(SUM(CASE WHEN availability_status IN ('Booked', 'Reserved') THEN 1 ELSE 0 END), 0) as reservedOrBookedCount,
        COALESCE(SUM(CASE WHEN availability_status = 'Sold' THEN 1 ELSE 0 END), 0) as soldCount
      FROM dealer_vehicle_inventory
      WHERE dealer_id = ?
    `)
    .get(dealerId) as any;

  const bookingStats = sqlite
    .prepare(`
      SELECT
        COUNT(*) as totalBookings,
        COALESCE(SUM(CASE WHEN booking_status = 'Pending Approval' THEN 1 ELSE 0 END), 0) as pendingBookings,
        COALESCE(SUM(CASE WHEN booking_status = 'Approved' THEN 1 ELSE 0 END), 0) as approvedBookings,
        COALESCE(SUM(CASE WHEN booking_status = 'Converted to Sale' THEN 1 ELSE 0 END), 0) as convertedBookings
      FROM dealer_bookings
      WHERE dealer_id = ?
    `)
    .get(dealerId) as any;

  const salesRows = sqlite
    .prepare('SELECT * FROM dealer_sales WHERE dealer_id = ? ORDER BY created_at DESC')
    .all(dealerId) as any[];

  const inquiryStats = sqlite
    .prepare(`
      SELECT
        COUNT(*) as totalInquiries,
        COALESCE(SUM(CASE WHEN test_drive_status IN ('Requested', 'Scheduled') THEN 1 ELSE 0 END), 0) as activeTestDrives,
        COALESCE(SUM(CASE WHEN appointment_date IS NOT NULL AND appointment_date != '' THEN 1 ELSE 0 END), 0) as scheduledAppointments
      FROM dealer_customers
      WHERE dealer_id = ?
    `)
    .get(dealerId) as any;

  const commissionStats = sqlite
    .prepare(`
      SELECT
        COALESCE(SUM(CASE WHEN status = 'Approved' THEN commission_amount_pkr ELSE 0 END), 0) as approvedTotal,
        COALESCE(SUM(CASE WHEN status = 'Pending' THEN commission_amount_pkr ELSE 0 END), 0) as pendingTotal,
        COALESCE(SUM(CASE WHEN status = 'Paid' THEN commission_amount_pkr ELSE 0 END), 0) as paidTotal,
        COALESCE(SUM(commission_amount_pkr), 0) as lifetimeTotal
      FROM dealer_commissions
      WHERE dealer_id = ?
    `)
    .get(dealerId) as any;

  const commissions = sqlite
    .prepare(`
      SELECT dc.*, ds.sale_ref, ds.vehicle_model
      FROM dealer_commissions dc
      LEFT JOIN dealer_sales ds ON ds.id = dc.sale_id
      WHERE dc.dealer_id = ?
      ORDER BY dc.created_at DESC
    `)
    .all(dealerId) as any[];

  const monthlyMap = new Map<string, { month: string; salesCount: number; revenuePkr: number; deliveriesCount: number }>();
  for (const s of salesRows) {
    const month = String(s.created_at || '').slice(0, 7) || 'Unknown';
    const curr = monthlyMap.get(month) || { month, salesCount: 0, revenuePkr: 0, deliveriesCount: 0 };
    curr.salesCount += 1;
    curr.revenuePkr += Number(s.sale_amount_pkr || 0);
    if (s.delivery_status === 'Delivered') curr.deliveriesCount += 1;
    monthlyMap.set(month, curr);
  }

  return {
    dealer: {
      dealerCode: contextRow.dealer_code,
      businessName: contextRow.business_name,
      category: contextRow.category,
      companyName: contextRow.company_name,
      countryName: contextRow.country_name || contextRow.country_id,
      branchName: contextRow.branch_name || 'Unassigned',
      city: contextRow.profile_city || contextRow.branch_city || 'Karachi',
      commissionRatePct: contextRow.commission_rate_pct,
    },
    totals: {
      totalAssignedVehicles: inventoryStats.totalAssigned || 0,
      availableStock: inventoryStats.availableCount || 0,
      reservedOrBookedStock: inventoryStats.reservedOrBookedCount || 0,
      soldVehicles: inventoryStats.soldCount || 0,
      totalBookings: bookingStats.totalBookings || 0,
      pendingBookings: bookingStats.pendingBookings || 0,
      approvedBookings: bookingStats.approvedBookings || 0,
      completedSales: salesRows.filter((s) => s.payment_status === 'Payment Verified').length,
      pendingSales: salesRows.filter((s) => s.payment_status !== 'Payment Verified').length,
      completedDeliveries: salesRows.filter((s) => s.delivery_status === 'Delivered').length,
      totalSalesVolumePkr: salesRows.reduce((acc, s) => acc + Number(s.sale_amount_pkr || 0), 0),
      customerInquiries: inquiryStats.totalInquiries || 0,
      activeTestDrives: inquiryStats.activeTestDrives || 0,
      scheduledAppointments: inquiryStats.scheduledAppointments || 0,
      approvedCommissionPkr: commissionStats.approvedTotal || 0,
      pendingCommissionPkr: commissionStats.pendingTotal || 0,
      paidCommissionPkr: commissionStats.paidTotal || 0,
      lifetimeCommissionPkr: commissionStats.lifetimeTotal || 0,
    },
    monthlySummary: Array.from(monthlyMap.values()),
    sales: salesRows,
    commissions,
  };
}

export function createDealerRouter() {
  const router = express.Router();

  // Strictly enforce Dealer-only auth + prevent impersonation
  router.use(requireDealer);
  router.use((req: Request, res: Response, next) => {
    if (!assertNotImpersonatingDealer(req, res)) return;
    next();
  });

  // =========================================================================
  // 1. PRIVATE DEALER DASHBOARD SUMMARY
  // =========================================================================
  router.get('/dashboard', requireDealerPermission('dealer.dashboard.view'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const row = getDealerContextRow(dealerId);
    if (!row) {
      res.status(404).json({ error: 'Dealer account record not found.' });
      return;
    }

    const report = buildDealerReportData(dealerId, row);

    const notifications = sqlite
      .prepare(`
        SELECT * FROM dealer_notifications
        WHERE (dealer_id = ? OR dealer_id IS NULL)
          AND (company_id = ? OR company_id = 'ALL')
          AND (country_id IS NULL OR country_id = ?)
          AND (branch_id IS NULL OR branch_id = ?)
        ORDER BY created_at DESC LIMIT 20
      `)
      .all(dealerId, row.company_id, row.country_id, row.branch_id || '') as any[];

    const unreadNotifications = notifications.filter((n) => !n.is_read).length;

    const recentLogs = sqlite
      .prepare('SELECT id, action, module, target_id, details, ip_address, status, created_at FROM dealer_activity_logs WHERE dealer_id = ? ORDER BY created_at DESC LIMIT 10')
      .all(dealerId);

    const permissions = req.auth!.permissions;

    res.json({
      dealer: {
        id: row.id,
        dealerCode: row.dealer_code,
        dealershipId: row.dealership_id,
        businessName: row.business_name,
        ownerContactName: row.owner_contact_name,
        email: row.email,
        mobile: row.mobile,
        category: row.category,
        verificationStatus: row.verification_status,
        status: row.status,
        emailVerified: Boolean(row.email_verified),
        companyId: row.company_id,
        companyName: row.company_name || row.company_id,
        countryId: row.country_id,
        countryName: row.country_name || row.country_id,
        countryCurrency: row.country_currency || 'PKR',
        branchId: row.branch_id,
        branchName: row.branch_name || null,
        branchCode: row.branch_code || null,
        city: row.profile_city || row.branch_city || row.company_city || 'Karachi',
        assignedManagerName: row.assigned_manager_name || 'Regional Channel Operations',
        commissionRatePct: permissions.includes('dealer.commissions.view') ? row.commission_rate_pct : null,
        logoDocId: row.logo_doc_id || null,
        createdAt: row.created_at,
        lastLoginAt: row.last_login_at,
        lastLoginIp: row.last_login_ip,
      },
      summary: {
        ...report.totals,
        approvedCommissionPkr: permissions.includes('dealer.commissions.view') ? report.totals.approvedCommissionPkr : null,
        pendingCommissionPkr: permissions.includes('dealer.commissions.view') ? report.totals.pendingCommissionPkr : null,
        paidCommissionPkr: permissions.includes('dealer.commissions.view') ? report.totals.paidCommissionPkr : null,
        lifetimeCommissionPkr: permissions.includes('dealer.commissions.view') ? report.totals.lifetimeCommissionPkr : null,
        unreadNotifications,
      },
      notifications: notifications.slice(0, 6),
      recentActivity: recentLogs,
      permissions,
    });
  });

  // =========================================================================
  // 2. DEALER PROFILE MANAGEMENT (Sensitive updates go to Pending Admin Approval)
  // =========================================================================
  router.get('/profile', (req: Request, res: Response) => {
    const row = getDealerContextRow(req.auth!.dealerId!);
    if (!row) {
      res.status(404).json({ error: 'Dealer profile not found.' });
      return;
    }

    res.json({
      profile: {
        id: row.id,
        dealerCode: row.dealer_code,
        businessName: row.business_name,
        ownerContactName: row.owner_contact_name,
        email: row.email,
        mobile: row.mobile,
        category: row.category,
        verificationStatus: row.verification_status,
        status: row.status,
        companyId: row.company_id,
        companyName: row.company_name,
        countryId: row.country_id,
        countryName: row.country_name,
        branchId: row.branch_id,
        branchName: row.branch_name,
        assignedManagerName: row.assigned_manager_name,
        businessAddress: row.business_address || '',
        city: row.profile_city || 'Karachi',
        taxIdNtn: row.tax_id_ntn || '',
        registrationNo: row.registration_no || '',
        website: row.website || '',
        bankName: row.bank_name || '',
        bankAccountTitle: row.bank_account_title || '',
        bankIbanMasked: row.bank_iban_masked || '',
        pendingChanges: safeJsonParse<Record<string, unknown> | null>(row.pending_changes_json, null),
        pendingChangeStatus: row.pending_change_status || 'None',
        pendingChangeSubmittedAt: row.pending_change_submitted_at || null,
        notes: row.profile_notes || '',
        logoDocId: row.logo_doc_id || null,
        commissionRatePct: row.commission_rate_pct,
        createdAt: row.created_at,
      },
    });
  });

  router.put('/profile', requireDealerPermission('dealer.profile.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const body = req.body || {};

    // Strictly block self-escalation or tampering with admin-controlled governance fields
    const forbiddenFields = [
      'verificationStatus',
      'verification_status',
      'status',
      'role',
      'permissions',
      'dealerCode',
      'dealer_code',
      'branchId',
      'branch_id',
      'countryId',
      'country_id',
      'commissionRatePct',
      'commission_rate_pct',
      'authorizedBy',
      'approvedBy',
    ];
    for (const f of forbiddenFields) {
      if (body[f] !== undefined) {
        logSecurityEvent({
          severity: 'CRITICAL',
          eventType: 'DEALER_PRIVILEGE_SELF_EDIT_BLOCKED',
          userId: req.auth!.userId,
          identifier: req.auth!.email,
          companyId: req.auth!.companyId,
          details: `Dealer ${req.auth!.dealerCode} attempted to self-modify protected field "${f}".`,
          ipAddress: getClientIp(req),
        });
        recordDealerAction(
          req,
          'PROTECTED_FIELD_EDIT_BLOCKED',
          'Dealer Profile',
          f,
          `Blocked attempt to modify protected field "${f}".`,
          'ALERT'
        );
        res.status(403).json({
          error: `Forbidden: Dealers cannot modify admin-controlled field "${f}".`,
        });
        return;
      }
    }

    const row = getDealerContextRow(dealerId);
    if (!row) {
      res.status(404).json({ error: 'Dealer account not found.' });
      return;
    }

    const nextBusinessName = body.businessName ? String(body.businessName).trim() : row.business_name;
    const nextOwnerContact = body.ownerContactName ? String(body.ownerContactName).trim() : row.owner_contact_name;
    const nextMobile = body.mobile ? String(body.mobile).trim() : row.mobile;
    const nextAddress = body.businessAddress !== undefined ? String(body.businessAddress).trim() : row.business_address;
    const nextCity = body.city ? String(body.city).trim() : row.profile_city;
    const nextWebsite = body.website !== undefined ? String(body.website).trim() : row.website;
    const nextNotes = body.notes !== undefined ? String(body.notes).trim() : row.profile_notes;

    const now = nowIso();
    sqlite
      .prepare('UPDATE dealer_accounts SET business_name = ?, owner_contact_name = ?, mobile = ?, updated_at = ? WHERE id = ?')
      .run(nextBusinessName, nextOwnerContact, nextMobile, now, dealerId);

    // Sensitive updates (Bank info, Tax NTN, Registration No, Category) require Admin Approval
    const sensitiveRequest: Record<string, string> = {};
    if (body.bankName && String(body.bankName).trim() !== (row.bank_name || '')) {
      sensitiveRequest.bankName = String(body.bankName).trim();
    }
    if (body.bankAccountTitle && String(body.bankAccountTitle).trim() !== (row.bank_account_title || '')) {
      sensitiveRequest.bankAccountTitle = String(body.bankAccountTitle).trim();
    }
    if (body.bankIbanMasked && String(body.bankIbanMasked).trim() !== (row.bank_iban_masked || '')) {
      sensitiveRequest.bankIbanMasked = String(body.bankIbanMasked).trim();
    }
    if (body.taxIdNtn && String(body.taxIdNtn).trim() !== (row.tax_id_ntn || '')) {
      sensitiveRequest.taxIdNtn = String(body.taxIdNtn).trim();
    }
    if (body.registrationNo && String(body.registrationNo).trim() !== (row.registration_no || '')) {
      sensitiveRequest.registrationNo = String(body.registrationNo).trim();
    }
    if (body.requestedCategory && String(body.requestedCategory).trim() !== (row.category || '')) {
      sensitiveRequest.category = String(body.requestedCategory).trim();
    }

    const hasSensitiveChanges = Object.keys(sensitiveRequest).length > 0;
    if (hasSensitiveChanges) {
      sqlite
        .prepare(`
          UPDATE dealer_profiles
          SET business_address = ?, city = ?, website = ?, notes = ?,
              pending_changes_json = ?, pending_change_status = 'Pending Admin Approval',
              pending_change_submitted_at = ?, updated_at = ?
          WHERE dealer_id = ?
        `)
        .run(
          nextAddress,
          nextCity,
          nextWebsite,
          nextNotes,
          JSON.stringify(sensitiveRequest),
          now,
          now,
          dealerId
        );
    } else {
      sqlite
        .prepare('UPDATE dealer_profiles SET business_address = ?, city = ?, website = ?, notes = ?, updated_at = ? WHERE dealer_id = ?')
        .run(nextAddress, nextCity, nextWebsite, nextNotes, now, dealerId);
    }

    recordDealerAction(
      req,
      hasSensitiveChanges ? 'PROFILE_AND_SENSITIVE_CHANGE_REQUESTED' : 'PROFILE_UPDATED',
      'Dealer Profile',
      dealerId,
      hasSensitiveChanges
        ? `Updated permitted profile fields and queued sensitive updates (${Object.keys(sensitiveRequest).join(', ')}) for Admin Approval.`
        : 'Updated permitted dealer business profile fields.'
    );

    res.json({
      success: true,
      pendingAdminApproval: hasSensitiveChanges,
      message: hasSensitiveChanges
        ? 'Contact details saved. Bank/registration changes were queued for Admin verification before going live.'
        : 'Dealer profile updated.',
    });
  });

  router.post('/profile/logo', requireDealerPermission('dealer.profile.manage'), upload.single('logo'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    if (!req.file || !req.file.mimetype.startsWith('image/')) {
      res.status(400).json({ error: 'Please upload a valid JPEG, PNG, or WEBP business logo image.' });
      return;
    }

    try {
      const saved = savePrivateDealerFile({
        buffer: req.file.buffer,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        dealerId,
        companyId: req.auth!.companyId!,
        docType: 'Logo',
        title: `Business Logo — ${req.auth!.fullName}`,
        uploadedById: dealerId,
        uploadedByRole: req.auth!.role,
        verificationStatus: 'Verified',
        reviewedBy: 'auto_image_asset',
      });
      sqlite
        .prepare('UPDATE dealer_accounts SET logo_doc_id = ?, updated_at = ? WHERE id = ?')
        .run(saved.id, saved.createdAt, dealerId);

      recordDealerAction(req, 'DEALER_LOGO_UPDATED', 'Dealer Profile', saved.id, `Uploaded logo (${req.file.originalname})`);
      res.status(201).json({ success: true, logoDocId: saved.id });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Logo upload failed.' });
    }
  });

  // =========================================================================
  // 3. ASSIGNED VEHICLE INVENTORY MANAGEMENT (Read-Only for Dealers)
  // =========================================================================
  router.get('/inventory', requireDealerPermission('dealer.inventory.view'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const canViewVin = req.auth!.permissions.includes('dealer.vin.view');

    const vehicles = sqlite
      .prepare(`
        SELECT inv.*, c.name as company_name, b.name as branch_name
        FROM dealer_vehicle_inventory inv
        LEFT JOIN companies c ON c.id = inv.company_id
        LEFT JOIN branches b ON b.id = inv.branch_id
        WHERE inv.dealer_id = ?
        ORDER BY inv.created_at DESC
      `)
      .all(dealerId)
      .map((v: any) => ({
        ...v,
        vin: canViewVin ? v.vin : '***REDACTED***',
        vinMasked: !canViewVin,
      }));

    res.json({ vehicles, canViewVin });
  });

  // Strictly block any inventory tampering by dealers (stock, price, ownership)
  router.all('/inventory*', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_INVENTORY_TAMPER_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Dealer ${req.auth!.dealerCode} attempted ${req.method} on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    recordDealerAction(
      req,
      'INVENTORY_WRITE_BLOCKED',
      'Dealer Inventory',
      req.originalUrl,
      `Blocked ${req.method} attempt to edit official stock/pricing.`,
      'ALERT'
    );
    res.status(403).json({
      error: 'Forbidden: Dealers cannot modify official stock allocations, approved prices, or vehicle ownership.',
    });
  });

  // =========================================================================
  // 4. PRIVATE DEALER CRM (Customer Inquiries, Appointments & Test Drives)
  // =========================================================================
  router.get('/customers', requireDealerPermission('dealer.crm.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const customers = sqlite
      .prepare('SELECT * FROM dealer_customers WHERE dealer_id = ? ORDER BY updated_at DESC')
      .all(dealerId)
      .map((c: any) => ({
        ...c,
        communicationHistory: safeJsonParse<any[]>(c.communication_history_json, []),
      }));
    res.json({ customers });
  });

  router.post('/customers', requireDealerPermission('dealer.crm.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const body = req.body || {};
    const fullName = String(body.fullName || '').trim();
    const phone = String(body.phone || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const city = String(body.city || req.auth!.city || 'Karachi').trim();
    const interestedModel = String(body.interestedModel || 'BYD Sealion 6').trim();
    const requirements = String(body.requirements || '').trim();
    const followUpDate = body.followUpDate ? String(body.followUpDate).slice(0, 16) : null;
    const appointmentDate = body.appointmentDate ? String(body.appointmentDate).slice(0, 16) : null;
    const testDriveStatus = body.requestTestDrive ? 'Requested' : 'Not Requested';
    const inquiryStatus = body.requestTestDrive
      ? 'Test Drive Requested'
      : appointmentDate
      ? 'Appointment Scheduled'
      : 'New Inquiry';

    if (!fullName || !phone) {
      res.status(400).json({ error: 'Customer full name and phone number are required.' });
      return;
    }

    const custId = `dcust_${generateSecureToken(6)}`;
    const now = nowIso();
    const history = [
      {
        at: now,
        by: req.auth!.fullName,
        channel: body.channel || 'Showroom Inquiry',
        note: body.initialNote || `Inquiry created for ${interestedModel}. ${requirements}`.trim(),
      },
    ];

    sqlite
      .prepare(`
        INSERT INTO dealer_customers (
          id, dealer_id, company_id, country_id, branch_id, full_name, email, phone, city,
          interested_model, requirements, inquiry_status, follow_up_date, appointment_date,
          test_drive_status, communication_history_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        custId,
        dealerId,
        req.auth!.companyId!,
        req.auth!.country,
        req.auth!.branchId || null,
        fullName,
        email,
        phone,
        city,
        interestedModel,
        requirements,
        inquiryStatus,
        followUpDate,
        appointmentDate,
        testDriveStatus,
        JSON.stringify(history),
        now,
        now
      );

    recordDealerAction(req, 'DEALER_CUSTOMER_CREATED', 'Dealer CRM', custId, `Added inquiry for ${fullName} (${interestedModel})`);
    res.status(201).json({
      success: true,
      customer: {
        ...(sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ?').get(custId) as any),
        communicationHistory: history,
      },
    });
  });

  router.patch('/customers/:id', requireDealerPermission('dealer.crm.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const cust = sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ?').get(req.params.id) as any;
    if (!cust) {
      res.status(404).json({ error: 'Customer inquiry record not found.' });
      return;
    }
    if (cust.dealer_id !== dealerId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_DEALER_CUSTOMER_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Dealer ${req.auth!.dealerCode} attempted to access customer ${req.params.id} owned by ${cust.dealer_id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: This customer belongs to another dealer.' });
      return;
    }

    const body = req.body || {};
    const nextStatus = body.inquiryStatus ? String(body.inquiryStatus).trim() : cust.inquiry_status;
    const nextFollowUp = body.followUpDate !== undefined ? body.followUpDate : cust.follow_up_date;
    const nextAppt = body.appointmentDate !== undefined ? body.appointmentDate : cust.appointment_date;
    const nextTestDrive = body.testDriveStatus ? String(body.testDriveStatus).trim() : cust.test_drive_status;
    const nextRequirements = body.requirements !== undefined ? String(body.requirements).trim() : cust.requirements;

    const history = safeJsonParse<any[]>(cust.communication_history_json, []);
    const now = nowIso();
    if (body.communicationNote && String(body.communicationNote).trim()) {
      history.push({
        at: now,
        by: req.auth!.fullName,
        channel: String(body.channel || 'Follow-Up'),
        note: String(body.communicationNote).trim(),
      });
    } else if (body.testDriveStatus || body.appointmentDate || body.inquiryStatus) {
      history.push({
        at: now,
        by: req.auth!.fullName,
        channel: 'CRM Update',
        note: `Updated status: ${nextStatus} | Test Drive: ${nextTestDrive}${nextAppt ? ` | Appt: ${nextAppt}` : ''}`,
      });
    }

    sqlite
      .prepare(`
        UPDATE dealer_customers
        SET inquiry_status = ?, follow_up_date = ?, appointment_date = ?, test_drive_status = ?,
            requirements = ?, communication_history_json = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(
        nextStatus,
        nextFollowUp,
        nextAppt,
        nextTestDrive,
        nextRequirements,
        JSON.stringify(history),
        now,
        cust.id
      );

    recordDealerAction(req, 'DEALER_CUSTOMER_UPDATED', 'Dealer CRM', cust.id, `Status=${nextStatus}, TestDrive=${nextTestDrive}`);
    res.json({
      success: true,
      customer: {
        ...(sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ?').get(cust.id) as any),
        communicationHistory: history,
      },
    });
  });

  // =========================================================================
  // 5. BOOKINGS & SALES MANAGEMENT (No payment self-confirmation!)
  // =========================================================================
  router.get('/bookings', requireDealerPermission('dealer.bookings.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const bookings = sqlite
      .prepare(`
        SELECT b.*, c.full_name as customer_name, c.phone as customer_phone, c.email as customer_email,
               inv.stock_number, inv.exterior_color, inv.model_year
        FROM dealer_bookings b
        LEFT JOIN dealer_customers c ON c.id = b.customer_id
        LEFT JOIN dealer_vehicle_inventory inv ON inv.id = b.inventory_id
        WHERE b.dealer_id = ?
        ORDER BY b.created_at DESC
      `)
      .all(dealerId);
    res.json({ bookings });
  });

  router.post(
    '/bookings',
    requireDealerPermission('dealer.bookings.manage'),
    upload.single('file'),
    (req: Request, res: Response) => {
      const dealerId = req.auth!.dealerId!;
      const body = req.body || {};

      // Dealers cannot self-approve or self-confirm payment on creation
      if (
        body.bookingStatus &&
        body.bookingStatus !== 'Pending Approval'
      ) {
        res.status(403).json({ error: 'Dealers cannot submit pre-approved bookings.' });
        return;
      }
      if (
        body.paymentStatus &&
        body.paymentStatus !== 'Pending Verification'
      ) {
        logSecurityEvent({
          severity: 'CRITICAL',
          eventType: 'DEALER_PAYMENT_SELF_CONFIRM_BLOCKED',
          userId: req.auth!.userId,
          identifier: req.auth!.email,
          companyId: req.auth!.companyId,
          details: `Dealer ${req.auth!.dealerCode} attempted to create booking with pre-confirmed payment status "${body.paymentStatus}".`,
          ipAddress: getClientIp(req),
        });
        res.status(403).json({ error: 'Dealers are strictly forbidden from confirming customer payments directly.' });
        return;
      }

      const customerId = String(body.customerId || '').trim();
      const inventoryId = String(body.inventoryId || '').trim();
      const notes = String(body.notes || '').trim();

      if (!customerId || !inventoryId) {
        res.status(400).json({ error: 'Customer and assigned available vehicle are required to submit a booking.' });
        return;
      }

      const cust = sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ?').get(customerId) as any;
      if (!cust || cust.dealer_id !== dealerId) {
        res.status(403).json({ error: 'Selected customer does not belong to your private dealer CRM.' });
        return;
      }

      const inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(inventoryId) as any;
      if (!inv || inv.dealer_id !== dealerId) {
        res.status(403).json({ error: 'Selected vehicle does not belong to your assigned dealer inventory.' });
        return;
      }

      if (!['Available', 'Reserved'].includes(inv.availability_status)) {
        res.status(409).json({
          error: `Vehicle ${inv.stock_number} (${inv.model}) is currently "${inv.availability_status}" and cannot be booked.`,
        });
        return;
      }

      let supportingDocId: string | null = null;
      if (req.file) {
        try {
          const saved = savePrivateDealerFile({
            buffer: req.file.buffer,
            originalName: req.file.originalname,
            mimeType: req.file.mimetype,
            dealerId,
            companyId: req.auth!.companyId!,
            docType: 'Booking Proof',
            title: `Booking Proof — ${inv.stock_number} (${cust.full_name})`,
            uploadedById: dealerId,
            uploadedByRole: req.auth!.role,
          });
          supportingDocId = saved.id;
        } catch (err: any) {
          res.status(400).json({ error: err?.message || 'Booking supporting document upload failed.' });
          return;
        }
      }

      const bookingId = `dbk_${generateSecureToken(6)}`;
      const bookingRef = `BKD-${new Date().getFullYear()}-${generateNumericOtp(4)}`;
      const now = nowIso();
      const officialPricePkr = Number(inv.approved_selling_price_pkr || 0);

      sqlite
        .prepare(`
          INSERT INTO dealer_bookings (
            id, booking_ref, dealer_id, customer_id, inventory_id, company_id, country_id, branch_id,
            vehicle_model, variant, agreed_price_pkr, booking_status, payment_status, delivery_status,
            supporting_doc_id, notes, reviewed_by, reviewed_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Approval', 'Pending Verification', 'Pending PDI', ?, ?, NULL, NULL, ?, ?)
        `)
        .run(
          bookingId,
          bookingRef,
          dealerId,
          cust.id,
          inv.id,
          req.auth!.companyId!,
          req.auth!.country,
          req.auth!.branchId || null,
          inv.model,
          inv.variant,
          officialPricePkr,
          supportingDocId,
          notes,
          now,
          now
        );

      sqlite
        .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Booked', booking_status = 'Booking Requested', updated_at = ? WHERE id = ?")
        .run(now, inv.id);

      const history = safeJsonParse<any[]>(cust.communication_history_json, []);
      history.push({
        at: now,
        by: req.auth!.fullName,
        channel: 'Vehicle Booking',
        note: `Submitted booking ${bookingRef} for ${inv.model} (${inv.variant}) at official price PKR ${officialPricePkr.toLocaleString()}.`,
      });
      sqlite
        .prepare("UPDATE dealer_customers SET inquiry_status = 'Booking Submitted', communication_history_json = ?, updated_at = ? WHERE id = ?")
        .run(JSON.stringify(history), now, cust.id);

      recordDealerAction(
        req,
        'DEALER_BOOKING_CREATED',
        'Dealer Bookings',
        bookingRef,
        `Submitted booking for ${cust.full_name} on ${inv.stock_number} (${inv.model}).`
      );

      res.status(201).json({
        success: true,
        booking: sqlite.prepare('SELECT * FROM dealer_bookings WHERE id = ?').get(bookingId),
      });
    }
  );

  router.patch('/bookings/:id/cancel', requireDealerPermission('dealer.bookings.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const bk = sqlite.prepare('SELECT * FROM dealer_bookings WHERE id = ?').get(req.params.id) as any;
    if (!bk) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    if (bk.dealer_id !== dealerId) {
      res.status(403).json({ error: 'Access Denied: Booking belongs to another dealer.' });
      return;
    }
    if (bk.booking_status !== 'Pending Approval') {
      res.status(400).json({ error: `Only Pending Approval bookings can be cancelled by dealer (current: "${bk.booking_status}").` });
      return;
    }

    const now = nowIso();
    sqlite.prepare("UPDATE dealer_bookings SET booking_status = 'Cancelled', updated_at = ? WHERE id = ?").run(now, bk.id);
    sqlite
      .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Available', booking_status = 'Unbooked', updated_at = ? WHERE id = ? AND availability_status = 'Booked'")
      .run(now, bk.inventory_id);

    recordDealerAction(req, 'DEALER_BOOKING_CANCELLED', 'Dealer Bookings', bk.booking_ref, 'Cancelled pending customer booking.');
    res.json({ success: true });
  });

  // Explicitly forbid self-approval or self-payment-confirmation by dealers
  router.all('/bookings/:id/approve', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_BOOKING_SELF_APPROVE_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Dealer ${req.auth!.dealerCode} attempted self-approval on booking ${req.params.id}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Forbidden: Only authorized administrators can approve bookings.' });
  });

  router.all('/bookings/:id/payment-confirm', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_PAYMENT_CONFIRM_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Dealer ${req.auth!.dealerCode} attempted direct payment confirmation on booking ${req.params.id}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Forbidden: Dealers cannot mark customer payments verified without verified payment settlement.' });
  });

  // =========================================================================
  // 6. DEALER SALES & RECEIPTS (Read-Only for Dealers)
  // =========================================================================
  router.get('/sales', requireDealerPermission('dealer.sales.view'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const canViewVin = req.auth!.permissions.includes('dealer.vin.view');
    const sales = sqlite
      .prepare(`
        SELECT s.*, c.full_name as customer_name, c.phone as customer_phone, c.city as customer_city
        FROM dealer_sales s
        LEFT JOIN dealer_customers c ON c.id = s.customer_id
        WHERE s.dealer_id = ?
        ORDER BY s.created_at DESC
      `)
      .all(dealerId)
      .map((s: any) => ({
        ...s,
        vin: canViewVin ? s.vin : '***REDACTED***',
      }));
    res.json({ sales });
  });

  router.get('/sales/:id/receipt', requireDealerPermission('dealer.sales.view'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const sale = sqlite
      .prepare(`
        SELECT s.*, c.full_name as customer_name, c.phone as customer_phone, c.email as customer_email, c.city as customer_city,
               da.business_name as dealer_name, da.dealer_code
        FROM dealer_sales s
        LEFT JOIN dealer_customers c ON c.id = s.customer_id
        LEFT JOIN dealer_accounts da ON da.id = s.dealer_id
        WHERE s.id = ?
      `)
      .get(req.params.id) as any;

    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    if (sale.dealer_id !== dealerId) {
      res.status(403).json({ error: 'Access Denied: Sale receipt belongs to another dealer.' });
      return;
    }

    const pdfLines = [
      'BYD PAKISTAN 360 — OFFICIAL VERIFIED SALE RECEIPT',
      `Founder & CEO: Intekhab Alam | Corporate Enterprise Registry`,
      '------------------------------------------------------------------------',
      `Sale Reference: ${sale.sale_ref}`,
      `Dealer Business: ${sale.dealer_name} (${sale.dealer_code})`,
      `Customer Name: ${sale.customer_name || 'Verified Customer'}`,
      `Customer Contact: ${sale.customer_phone || 'N/A'} | ${sale.customer_city || 'Pakistan'}`,
      `Vehicle Model: ${sale.vehicle_model}`,
      `VIN: ${req.auth!.permissions.includes('dealer.vin.view') ? sale.vin : '***REDACTED***'}`,
      `Sale Amount (PKR): ${Number(sale.sale_amount_pkr || 0).toLocaleString()}`,
      `Paid Amount (PKR): ${Number(sale.paid_amount_pkr || 0).toLocaleString()}`,
      `Payment Status: ${sale.payment_status}`,
      `Payment Reference: ${sale.payment_provider_ref || 'VERIFIED-SETTLEMENT'}`,
      `Delivery Status: ${sale.delivery_status}`,
      `Verified By: ${sale.verified_by || 'BYD Finance Verification Desk'}`,
      `Issued At: ${sale.created_at}`,
    ];

    const pdfBuf = buildSimplePdfBuffer(`BYD 360 Sale Receipt - ${sale.sale_ref}`, pdfLines);
    recordDealerAction(req, 'SALE_RECEIPT_DOWNLOADED', 'Dealer Sales', sale.sale_ref, 'Generated verified PDF sale receipt.');
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="BYD360-Receipt-${sale.sale_ref}.pdf"`);
    res.send(pdfBuf);
  });

  router.all('/sales*', (req: Request, res: Response) => {
    res.status(403).json({
      error: 'Forbidden: Official dealer sales records and payment settlements can only be recorded by authorized administrators.',
    });
  });

  // =========================================================================
  // 7. DEALER COMMISSIONS & EARNINGS (Read-Only, Rate Tampering Blocked)
  // =========================================================================
  router.get('/commissions', requireDealerPermission('dealer.commissions.view'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const dealerRow = sqlite.prepare('SELECT commission_rate_pct FROM dealer_accounts WHERE id = ?').get(dealerId) as any;

    const commissions = sqlite
      .prepare(`
        SELECT dc.*, ds.sale_ref, ds.vehicle_model, ds.payment_status as sale_payment_status
        FROM dealer_commissions dc
        LEFT JOIN dealer_sales ds ON ds.id = dc.sale_id
        WHERE dc.dealer_id = ?
        ORDER BY dc.created_at DESC
      `)
      .all(dealerId) as any[];

    const summary = {
      assignedRatePct: Number(dealerRow?.commission_rate_pct || 0),
      approvedPkr: commissions.filter((c) => c.status === 'Approved').reduce((s, c) => s + Number(c.commission_amount_pkr || 0), 0),
      pendingPkr: commissions.filter((c) => c.status === 'Pending').reduce((s, c) => s + Number(c.commission_amount_pkr || 0), 0),
      paidPkr: commissions.filter((c) => c.status === 'Paid').reduce((s, c) => s + Number(c.commission_amount_pkr || 0), 0),
      lifetimePkr: commissions.reduce((s, c) => s + Number(c.commission_amount_pkr || 0), 0),
    };

    res.json({ commissions, summary });
  });

  router.all('/commissions*', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_COMMISSION_TAMPER_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Dealer ${req.auth!.dealerCode} attempted ${req.method} on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Forbidden: Commission rates, payout statuses, and calculations can only be approved by authorized administrators.',
    });
  });

  // =========================================================================
  // 8. DEALER DOCUMENTS (Private Disk Storage + Cross-Dealer 403)
  // =========================================================================
  router.get('/documents', requireDealerPermission('dealer.documents.manage'), (req: Request, res: Response) => {
    const docs = sqlite
      .prepare(`
        SELECT id, dealer_id, doc_type, title, original_filename, mime_type, size_bytes,
               verification_status, reviewed_by, review_notes, uploaded_by_role, created_at, updated_at
        FROM dealer_documents
        WHERE dealer_id = ?
        ORDER BY created_at DESC
      `)
      .all(req.auth!.dealerId!);
    res.json({ documents: docs });
  });

  router.post(
    '/documents',
    requireDealerPermission('dealer.documents.manage'),
    upload.single('file'),
    (req: Request, res: Response) => {
      const dealerId = req.auth!.dealerId!;
      if (!req.file) {
        res.status(400).json({ error: 'Please select a valid document file to upload.' });
        return;
      }

      const docType = String(req.body?.docType || 'Business Registration').trim();
      const title = String(req.body?.title || req.file.originalname).trim();

      try {
        const saved = savePrivateDealerFile({
          buffer: req.file.buffer,
          originalName: req.file.originalname,
          mimeType: req.file.mimetype,
          dealerId,
          companyId: req.auth!.companyId!,
          docType,
          title,
          uploadedById: dealerId,
          uploadedByRole: req.auth!.role,
          verificationStatus: 'Pending Verification',
        });

        recordDealerAction(
          req,
          'DEALER_DOCUMENT_UPLOADED',
          'Dealer Documents',
          saved.id,
          `Uploaded "${title}" (${docType}) awaiting administrator verification.`
        );

        res.status(201).json({
          success: true,
          document: sqlite
            .prepare('SELECT id, doc_type, title, original_filename, mime_type, size_bytes, verification_status, created_at FROM dealer_documents WHERE id = ?')
            .get(saved.id),
        });
      } catch (err: any) {
        res.status(400).json({ error: err?.message || 'Document upload failed.' });
      }
    }
  );

  router.get('/documents/:id/download', requireDealerPermission('dealer.documents.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const doc = sqlite.prepare('SELECT * FROM dealer_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Dealer document not found.' });
      return;
    }
    if (doc.dealer_id !== dealerId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_DEALER_DOCUMENT_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Dealer ${req.auth!.dealerCode} attempted to download document ${doc.id} belonging to dealer ${doc.dealer_id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: You can only download your own authorized dealer documents.' });
      return;
    }

    const diskPath = path.join(PRIVATE_DEALER_DOCS_DIR, path.basename(doc.storage_key));
    if (!fs.existsSync(diskPath)) {
      res.status(404).json({ error: 'Document binary file missing from private dealer vault.' });
      return;
    }

    recordDealerAction(req, 'DEALER_DOCUMENT_DOWNLOADED', 'Dealer Documents', doc.id, doc.original_filename);
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(doc.original_filename || 'document')}"`);
    fs.createReadStream(diskPath).pipe(res);
  });

  // =========================================================================
  // 9. NOTIFICATIONS, ANNOUNCEMENTS & MANAGER SUPPORT REQUESTS
  // =========================================================================
  router.get('/communications', (req: Request, res: Response) => {
    const row = getDealerContextRow(req.auth!.dealerId!);
    const notifications = sqlite
      .prepare(`
        SELECT * FROM dealer_notifications
        WHERE (dealer_id = ? OR dealer_id IS NULL)
          AND (company_id = ? OR company_id = 'ALL')
          AND (country_id IS NULL OR country_id = ?)
          AND (branch_id IS NULL OR branch_id = ?)
        ORDER BY created_at DESC LIMIT 40
      `)
      .all(req.auth!.dealerId!, row.company_id, row.country_id, row.branch_id || '');
    res.json({ notifications });
  });

  router.patch('/communications/:id/read', (req: Request, res: Response) => {
    const notif = sqlite.prepare('SELECT * FROM dealer_notifications WHERE id = ?').get(req.params.id) as any;
    if (!notif) {
      res.status(404).json({ error: 'Notification not found.' });
      return;
    }
    if (notif.dealer_id && notif.dealer_id !== req.auth!.dealerId) {
      res.status(403).json({ error: 'Access Denied: Notification belongs to another dealer.' });
      return;
    }
    sqlite.prepare('UPDATE dealer_notifications SET is_read = 1, read_at = ? WHERE id = ?').run(nowIso(), notif.id);
    res.json({ success: true });
  });

  router.get('/support', requireDealerPermission('dealer.support.manage'), (req: Request, res: Response) => {
    const requests = sqlite
      .prepare('SELECT * FROM dealer_support_requests WHERE dealer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.dealerId!);
    res.json({ supportRequests: requests });
  });

  router.post('/support', requireDealerPermission('dealer.support.manage'), (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const body = req.body || {};
    const category = String(body.category || 'Stock & Delivery').trim();
    const priority = ['Low', 'Medium', 'High', 'Critical'].includes(String(body.priority))
      ? String(body.priority)
      : 'Medium';
    const subject = String(body.subject || '').trim();
    const description = String(body.description || '').trim();

    if (!subject || !description) {
      res.status(400).json({ error: 'Support subject and detailed description are required.' });
      return;
    }

    const row = getDealerContextRow(dealerId);
    const ticketId = `dsr_${generateSecureToken(6)}`;
    const ticketNumber = `DLR-SUP-${generateNumericOtp(4)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO dealer_support_requests (
          id, ticket_number, dealer_id, company_id, country_id, branch_id, category,
          priority, subject, description, status, assigned_manager_name, resolution_notes,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, NULL, ?, ?)
      `)
      .run(
        ticketId,
        ticketNumber,
        dealerId,
        req.auth!.companyId!,
        req.auth!.country,
        req.auth!.branchId || null,
        category,
        priority,
        subject,
        description,
        row?.assigned_manager_name || 'Assigned Channel Manager',
        now,
        now
      );

    recordDealerAction(req, 'DEALER_SUPPORT_SUBMITTED', 'Dealer Support', ticketNumber, `${category}: ${subject}`);
    res.status(201).json({
      success: true,
      supportRequest: sqlite.prepare('SELECT * FROM dealer_support_requests WHERE id = ?').get(ticketId),
    });
  });

  // =========================================================================
  // 10. DEALER REPORTS & REAL EXPORTS (Excel .xlsx & PDF .pdf)
  // =========================================================================
  router.get('/reports', requireDealerPermission('dealer.reports.view'), (req: Request, res: Response) => {
    const row = getDealerContextRow(req.auth!.dealerId!);
    const report = buildDealerReportData(req.auth!.dealerId!, row);
    res.json({ report });
  });

  router.get('/reports/export', requireDealerPermission('dealer.reports.export'), (req: Request, res: Response) => {
    const format = String(req.query.format || 'xlsx').toLowerCase();
    const row = getDealerContextRow(req.auth!.dealerId!);
    const report = buildDealerReportData(req.auth!.dealerId!, row);

    if (format === 'pdf') {
      const pdfLines: string[] = [
        `BYD PAKISTAN 360 — OFFICIAL DEALER PERFORMANCE REPORT`,
        `Founder & CEO: Intekhab Alam | Authorized Dealer Analytics`,
        `Generated: ${nowIso()}`,
        '------------------------------------------------------------------------',
        `Dealer ID: ${report.dealer.dealerCode} | Business: ${report.dealer.businessName}`,
        `Category: ${report.dealer.category} | Partner Company: ${report.dealer.companyName}`,
        `Region / Branch: ${report.dealer.countryName} / ${report.dealer.branchName} (${report.dealer.city})`,
        '------------------------------------------------------------------------',
        '1. EXECUTIVE SUMMARY',
        `Total Assigned Vehicles: ${report.totals.totalAssignedVehicles} (Available: ${report.totals.availableStock}, Booked: ${report.totals.reservedOrBookedStock}, Sold: ${report.totals.soldVehicles})`,
        `Total Bookings: ${report.totals.totalBookings} (Pending: ${report.totals.pendingBookings}, Approved: ${report.totals.approvedBookings})`,
        `Completed Sales: ${report.totals.completedSales} | Pending Sales: ${report.totals.pendingSales} | Deliveries: ${report.totals.completedDeliveries}`,
        `Total Sales Volume: PKR ${Number(report.totals.totalSalesVolumePkr).toLocaleString()}`,
        `Customer Inquiries: ${report.totals.customerInquiries} | Active Test Drives: ${report.totals.activeTestDrives}`,
        `Commissions — Paid: PKR ${Number(report.totals.paidCommissionPkr).toLocaleString()} | Approved: PKR ${Number(report.totals.approvedCommissionPkr).toLocaleString()} | Pending: PKR ${Number(report.totals.pendingCommissionPkr).toLocaleString()}`,
        '------------------------------------------------------------------------',
        '2. MONTHLY PERFORMANCE SUMMARY',
      ];
      if (report.monthlySummary.length === 0) {
        pdfLines.push('No completed sales recorded in reporting window.');
      } else {
        for (const m of report.monthlySummary) {
          pdfLines.push(`Month ${m.month}: Sales=${m.salesCount}, Deliveries=${m.deliveriesCount}, Revenue=PKR ${Number(m.revenuePkr).toLocaleString()}`);
        }
      }
      pdfLines.push('------------------------------------------------------------------------');
      pdfLines.push('3. COMMISSION & PAYOUT LEDGER');
      for (const c of report.commissions.slice(0, 20)) {
        pdfLines.push(`${c.sale_ref || c.sale_id} | ${c.vehicle_model || 'BYD EV'} | Rate ${c.commission_rate_pct}% | PKR ${Number(c.commission_amount_pkr).toLocaleString()} | ${c.status}`);
      }

      const pdfBuffer = buildSimplePdfBuffer(`BYD 360 Dealer Report - ${report.dealer.dealerCode}`, pdfLines);
      recordDealerAction(req, 'DEALER_REPORT_EXPORTED', 'Dealer Reports', 'PDF', `Exported PDF summary (${report.dealer.dealerCode}).`);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="byd360-dealer-report-${report.dealer.dealerCode}.pdf"`);
      res.send(pdfBuffer);
      return;
    }

    if (format === 'xlsx') {
      const wb = XLSX.utils.book_new();
      const summarySheet = XLSX.utils.json_to_sheet([
        {
          DealerCode: report.dealer.dealerCode,
          BusinessName: report.dealer.businessName,
          Category: report.dealer.category,
          Company: report.dealer.companyName,
          Branch: report.dealer.branchName,
          AssignedVehicles: report.totals.totalAssignedVehicles,
          AvailableStock: report.totals.availableStock,
          TotalBookings: report.totals.totalBookings,
          CompletedSales: report.totals.completedSales,
          CompletedDeliveries: report.totals.completedDeliveries,
          CustomerInquiries: report.totals.customerInquiries,
          SalesVolumePkr: report.totals.totalSalesVolumePkr,
          PaidCommissionPkr: report.totals.paidCommissionPkr,
          ApprovedCommissionPkr: report.totals.approvedCommissionPkr,
          PendingCommissionPkr: report.totals.pendingCommissionPkr,
        },
      ]);
      XLSX.utils.book_append_sheet(wb, summarySheet, 'Dealer Summary');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(report.monthlySummary), 'Monthly Performance');
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          report.sales.map((s: any) => ({
            SaleRef: s.sale_ref,
            VehicleModel: s.vehicle_model,
            SaleAmountPkr: s.sale_amount_pkr,
            PaymentStatus: s.payment_status,
            DeliveryStatus: s.delivery_status,
            Date: s.created_at,
          }))
        ),
        'Sales'
      );
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet(
          report.commissions.map((c: any) => ({
            SaleRef: c.sale_ref || c.sale_id,
            VehicleModel: c.vehicle_model || '',
            SaleAmountPkr: c.sale_amount_pkr,
            RatePct: c.commission_rate_pct,
            CommissionAmountPkr: c.commission_amount_pkr,
            Status: c.status,
            PayoutRef: c.payout_reference || '',
            PaidAt: c.paid_at || '',
          }))
        ),
        'Commissions'
      );

      const xlsxBuf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
      recordDealerAction(req, 'DEALER_REPORT_EXPORTED', 'Dealer Reports', 'XLSX', `Exported Excel workbook (${report.dealer.dealerCode}).`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="byd360-dealer-report-${report.dealer.dealerCode}.xlsx"`);
      res.send(xlsxBuf);
      return;
    }

    res.status(400).json({ error: 'Unsupported report export format. Use "pdf" or "xlsx".' });
  });

  // =========================================================================
  // 11. DEALER AUDIT & LOGIN LOGS
  // =========================================================================
  router.get('/audit-logs', (req: Request, res: Response) => {
    const dealerId = req.auth!.dealerId!;
    const logs = sqlite
      .prepare('SELECT * FROM dealer_activity_logs WHERE dealer_id = ? ORDER BY created_at DESC LIMIT 80')
      .all(dealerId);
    const loginHistory = sqlite
      .prepare("SELECT id, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'dealer' ORDER BY created_at DESC LIMIT 40")
      .all(dealerId);
    res.json({ logs, loginHistory, canonicalPermissions: [...CANONICAL_DEALER_PERMISSIONS] });
  });

  return router;
}
