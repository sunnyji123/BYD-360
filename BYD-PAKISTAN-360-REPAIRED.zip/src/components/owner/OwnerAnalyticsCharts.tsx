import React from 'react';
import { BarChart3, TrendingUp, Award, Car } from 'lucide-react';

interface OwnerAnalyticsChartsProps {
  timeSeries: Array<{ period: string; revenue: number; expenses: number; profit: number; pending?: number }>;
  countries: Array<{ code: string; name: string; revenue: number; expenses: number; netProfit: number; performancePct: number | null; hasOperations: boolean }>;
  models: Array<{ model: string; totalUnits: number; completedUnits: number; pendingUnits: number; revenue: number }>;
  dealerships: Array<{ id: string; name: string; achievedUnits: number; monthlyTargetUnits: number; targetAttainmentPct: number; verifiedSalesRevenue: number }>;
  employeesByDept: Array<{ department: string; total: number; avgScore: number }>;
}

function formatCompact(val: number): string {
  const abs = Math.abs(val);
  if (abs >= 1_000_000) return `${(val / 1_000_000).toFixed(2)}M`;
  if (abs >= 1_000) return `${(val / 1_000).toFixed(1)}K`;
  return String(Math.round(val));
}

export const OwnerAnalyticsCharts: React.FC<OwnerAnalyticsChartsProps> = ({
  timeSeries,
  countries,
  models,
  dealerships,
  employeesByDept,
}) => {
  const activeCountries = countries.filter((c) => c.hasOperations);
  const maxSeriesVal = Math.max(
    1,
    ...timeSeries.map((t) => Math.max(Math.abs(t.revenue), Math.abs(t.expenses), Math.abs(t.profit)))
  );
  const maxModelUnits = Math.max(1, ...models.map((m) => m.totalUnits));
  const maxCountryRev = Math.max(1, ...activeCountries.map((c) => c.revenue));

  return (
    <div className="space-y-6">
      {/* Row 1: Revenue / Expense / Profit Trend & Country Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Revenue, Expenses &amp; Net Profit Trend</span>
              </h3>
              <p className="text-xs text-slate-400">Verified timeline from invoices, dealer sales &amp; operating expenses</p>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-mono">
              <span className="text-emerald-400">■ Revenue</span>
              <span className="text-rose-400">■ Expenses</span>
              <span className="text-amber-300">■ Profit</span>
            </div>
          </div>

          {timeSeries.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
              No Data Available
            </div>
          ) : (
            <div className="space-y-2.5">
              {timeSeries.map((pt) => (
                <div key={pt.period} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-white">{pt.period}</span>
                    <div className="flex items-center gap-3 font-mono tabular-nums text-[11px]">
                      <span className="text-emerald-400">+{formatCompact(pt.revenue)}</span>
                      <span className="text-rose-300">-{formatCompact(pt.expenses)}</span>
                      <span className={pt.profit >= 0 ? 'text-amber-300 font-bold' : 'text-rose-400 font-bold'}>
                        Net {formatCompact(pt.profit)}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="h-1.5 w-full rounded bg-slate-900 overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded"
                        style={{ width: `${Math.min(100, Math.round((pt.revenue / maxSeriesVal) * 100))}%` }}
                      />
                    </div>
                    <div className="h-1.5 w-full rounded bg-slate-900 overflow-hidden">
                      <div
                        className="h-full bg-rose-500 rounded"
                        style={{ width: `${Math.min(100, Math.round((pt.expenses / maxSeriesVal) * 100))}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <span>Country-Wise Revenue &amp; Target Attainment</span>
            </h3>
            <p className="text-xs text-slate-400">Verified performance across operational countries</p>
          </div>

          {activeCountries.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
              No Data Available
            </div>
          ) : (
            <div className="space-y-3">
              {activeCountries.map((c) => (
                <div key={c.code} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-white">
                      {c.name} <span className="text-slate-500 font-mono">({c.code})</span>
                    </span>
                    <span className="font-mono tabular-nums text-emerald-400 font-bold">
                      ₨ {Math.round(c.revenue).toLocaleString()}
                    </span>
                  </div>
                  <div className="h-2 w-full rounded bg-slate-900 overflow-hidden">
                    <div
                      className="h-full bg-cyan-500 rounded"
                      style={{ width: `${Math.max(4, Math.round((c.revenue / maxCountryRev) * 100))}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono tabular-nums">
                    <span>Net Profit: ₨ {Math.round(c.netProfit).toLocaleString()}</span>
                    <span className="text-amber-300">
                      Target Attainment: {c.performancePct !== null ? `${c.performancePct}%` : 'N/A'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Row 2: Vehicle Model Demand, Dealership Performance & Department Productivity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Car className="w-4 h-4 text-amber-400" />
            <span>Vehicle Model Demand</span>
          </h4>
          {models.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-2.5 text-xs">
              {models.map((m) => (
                <div key={m.model} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200 truncate">{m.model}</span>
                    <span className="font-mono tabular-nums text-amber-300 font-bold">
                      {m.totalUnits} ({m.completedUnits} sold)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded bg-slate-950 overflow-hidden">
                    <div
                      className="h-full bg-amber-500 rounded"
                      style={{ width: `${Math.round((m.totalUnits / maxModelUnits) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Dealership Quota Comparison</span>
          </h4>
          {dealerships.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-2.5 text-xs">
              {dealerships.slice(0, 5).map((d) => (
                <div key={d.id} className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-200 truncate">{d.name}</span>
                    <span className="font-mono tabular-nums text-emerald-300 shrink-0">
                      {d.achievedUnits}/{d.monthlyTargetUnits} ({d.targetAttainmentPct}%)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded bg-slate-950 overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded"
                      style={{ width: `${Math.min(100, d.targetAttainmentPct)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <span>Workforce Department KPI</span>
          </h4>
          {employeesByDept.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-2.5 text-xs">
              {employeesByDept.map((dept) => (
                <div key={dept.department} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white">{dept.department}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{dept.total} Employees</div>
                  </div>
                  <div className="text-right font-mono tabular-nums">
                    <div className="text-sm font-black text-cyan-300">{dept.avgScore}%</div>
                    <div className="text-[10px] text-slate-500">Avg KPI</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
