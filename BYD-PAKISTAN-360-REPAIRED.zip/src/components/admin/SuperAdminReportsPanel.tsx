import React, { useState, useEffect, useCallback } from 'react';
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  Calendar,
  Globe,
  ShieldAlert,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  formatPrice: (n: number) => string;
}

export const SuperAdminReportsPanel: React.FC<Props> = ({ formatPrice }) => {
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom' | 'all'>('all');
  const [fromDate, setFromDate] = useState(new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10));
  const [toDate, setToDate] = useState(new Date().toISOString().slice(0, 10));
  const [country, setCountry] = useState('ALL');

  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminEnterpriseAnalytics({
        period,
        fromDate: period === 'custom' ? fromDate : undefined,
        toDate: period === 'custom' ? toDate : undefined,
        country,
      });
      setAnalytics(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to generate enterprise analytics report.');
    } finally {
      setLoading(false);
    }
  }, [period, fromDate, toDate, country]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  const csvUrl = api.getSuperAdminReportExportUrl('csv', {
    period,
    fromDate: period === 'custom' ? fromDate : undefined,
    toDate: period === 'custom' ? toDate : undefined,
    country,
  });
  const pdfUrl = api.getSuperAdminReportExportUrl('pdf', {
    period,
    fromDate: period === 'custom' ? fromDate : undefined,
    toDate: period === 'custom' ? toDate : undefined,
    country,
  });

  const s = analytics?.summary || {};
  const countryRows = analytics?.countryBreakdown || [];
  const companyRows = analytics?.companyPerformance || [];
  const dealerRows = analytics?.dealerPerformance || [];
  const employeeRows = analytics?.employeePerformance || [];
  const verificationRows = analytics?.verificationReport || [];
  const activityTrend = analytics?.userActivityTrend || [];
  const sysActivity = analytics?.systemActivity || [];
  const secReport = analytics?.securityReport || [];

  const maxCountryCustomers = Math.max(1, ...countryRows.map((c: any) => Number(c.customersCount || 0) + Number(c.employeesCount || 0) + Number(c.dealersCount || 0)));
  const maxDealerRev = Math.max(1, ...dealerRows.map((d: any) => Number(d.revenuePkr || 0)));

  return (
    <div className="space-y-6 text-xs">
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        {/* Header & Export Buttons */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Enterprise Business Intelligence
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              Reports &amp; Analytics ({analytics?.periodLabel || 'Verified Database Records'})
            </h3>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <a
              href={csvUrl}
              download={`BYD360_SuperAdmin_Report_${period}.csv`}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export Excel (CSV)</span>
            </a>
            <a
              href={pdfUrl}
              download={`BYD360_SuperAdmin_Report_${period}.pdf`}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </a>
            <button
              type="button"
              onClick={loadAnalytics}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Period + Date Range + Country Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex flex-wrap rounded-xl bg-slate-950 border border-slate-800 p-1 gap-1">
            {[
              { id: 'all', label: 'All-Time' },
              { id: 'daily', label: 'Daily' },
              { id: 'weekly', label: 'Weekly' },
              { id: 'monthly', label: 'Monthly' },
              { id: 'yearly', label: 'Yearly' },
              { id: 'custom', label: 'Custom Range' },
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPeriod(p.id as any)}
                className={`px-3 py-1.5 rounded-lg font-bold transition ${
                  period === p.id ? 'bg-cyan-500 text-slate-950' : 'text-slate-300 hover:text-white'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {period === 'custom' && (
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono"
              />
              <span className="text-slate-500">to</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono"
              />
            </div>
          )}

          <div className="flex items-center gap-2 ml-auto">
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Operating Countries</option>
              {(analytics?.countries || []).map((c: any) => (
                <option key={c.id} value={c.id}>{c.name} ({c.id})</option>
              ))}
            </select>
          </div>
        </div>

        {error && <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>}

        {/* Summary KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
          {[
            { label: 'Users', val: s.totalUsers ?? 0 },
            { label: 'Companies', val: s.totalCompanies ?? 0 },
            { label: 'Employees', val: s.totalEmployees ?? 0 },
            { label: 'Dealers', val: s.totalDealers ?? 0 },
            { label: 'Customers', val: s.totalCustomers ?? 0 },
            { label: 'Countries', val: s.totalCountries ?? 0 },
            { label: 'Vehicles', val: s.totalVehicles ?? 0 },
            { label: 'Dealer Sales', val: s.totalSalesCount ?? 0 },
          ].map((k) => (
            <div key={k.label} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">{k.label}</div>
              <div className="text-lg font-black font-mono tabular-nums text-white mt-0.5">{k.val}</div>
            </div>
          ))}
        </div>

        {/* Charts Row: Country Distribution + Dealer Revenue Bars */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <span>Country-wise Ecosystem Footprint</span>
            </h4>
            <div className="space-y-3">
              {countryRows.map((c: any) => {
                const totalPeople = Number(c.employeesCount || 0) + Number(c.dealersCount || 0) + Number(c.customersCount || 0);
                const pct = Math.min(100, Math.round((totalPeople / maxCountryCustomers) * 100));
                return (
                  <div key={c.countryCode} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-semibold text-white">{c.countryName} ({c.countryCode})</span>
                      <span className="font-mono text-[11px] text-slate-300 tabular-nums">
                        Comp {c.companiesCount} · Br {c.branchesCount} · Emp {c.employeesCount} · Dlr {c.dealersCount} · Cust {c.customersCount}
                      </span>
                    </div>
                    <div className="h-2.5 w-full rounded-full bg-slate-900 overflow-hidden">
                      <div className="h-full bg-cyan-500 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
              {countryRows.length === 0 && <div className="text-slate-500 py-4 text-center">No Data Available</div>}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-white">Dealer Sales Revenue Performance</h4>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {dealerRows.map((d: any) => {
                const pct = d.revenuePkr > 0 ? Math.max(4, Math.round((Number(d.revenuePkr) / maxDealerRev) * 100)) : 0;
                return (
                  <div key={d.id} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-semibold text-white truncate">
                        {d.business_name} <span className="font-mono text-slate-400">({d.dealer_code})</span>
                      </span>
                      <span className="font-mono text-emerald-400 tabular-nums shrink-0">
                        {d.salesCount} sales · {formatPrice(d.revenuePkr || 0)}
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-900 overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
              {dealerRows.length === 0 && <div className="text-slate-500 py-4 text-center">No Data Available</div>}
            </div>
          </div>
        </div>

        {/* Company Performance & Verification / Security Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-white">Company Performance Summary</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] text-slate-400 uppercase">
                    <th className="py-2 px-3">Company</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Branches</th>
                    <th className="py-2 px-3">Staff</th>
                    <th className="py-2 px-3">Dealers</th>
                    <th className="py-2 px-3 text-right">Verified Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {companyRows.map((c: any) => (
                    <tr key={c.id}>
                      <td className="py-2 px-3 font-semibold text-white">{c.name}</td>
                      <td className="py-2 px-3 text-cyan-300">{c.status}</td>
                      <td className="py-2 px-3 font-mono tabular-nums">{c.branchesCount}</td>
                      <td className="py-2 px-3 font-mono tabular-nums">{c.employeesCount}</td>
                      <td className="py-2 px-3 font-mono tabular-nums">{c.dealersCount}</td>
                      <td className="py-2 px-3 font-mono text-emerald-400 text-right tabular-nums">
                        {formatPrice(c.paidInvoicesPkr || 0)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
            <div>
              <h4 className="font-bold text-white mb-2">Account Verification Status</h4>
              <div className="space-y-1.5">
                {verificationRows.map((v: any) => (
                  <div key={v.status} className="flex justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-slate-300">{v.status}</span>
                    <span className="font-mono font-bold text-cyan-300">{v.count}</span>
                  </div>
                ))}
                {verificationRows.length === 0 && <div className="text-slate-500">No verification updates in window.</div>}
              </div>
            </div>

            <div>
              <h4 className="font-bold text-white mb-2 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>Security Events &amp; Employee Depts</span>
              </h4>
              <div className="space-y-1.5">
                {secReport.map((r: any) => (
                  <div key={r.severity} className="flex justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-white font-mono">{r.severity}</span>
                    <span className="font-mono text-amber-300">{r.count} ({r.unacknowledged} open)</span>
                  </div>
                ))}
                {employeeRows.map((e: any) => (
                  <div key={e.department} className="flex justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <span className="text-slate-300">{e.department}</span>
                    <span className="font-mono text-emerald-400">{e.headcount} staff · {e.avgScore}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* User Activity Trend & System Admin Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-white">Daily User Authentication Trend</h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {activityTrend.map((t: any) => (
                <div key={t.date} className="flex justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px]">
                  <span className="text-slate-300">{t.date}</span>
                  <span className="text-emerald-400">OK {t.successfulLogins}</span>
                  <span className="text-rose-400">Fail {t.failedLogins}</span>
                </div>
              ))}
              {activityTrend.length === 0 && <div className="text-slate-500">No authentication events recorded in window.</div>}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-white">Super Admin Module Activity Breakdown</h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {sysActivity.map((m: any) => (
                <div key={m.module} className="flex justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-white font-semibold">{m.module}</span>
                  <span className="font-mono text-cyan-300 font-bold">{m.actionsCount} actions</span>
                </div>
              ))}
              {sysActivity.length === 0 && <div className="text-slate-500">No admin module actions in window.</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
