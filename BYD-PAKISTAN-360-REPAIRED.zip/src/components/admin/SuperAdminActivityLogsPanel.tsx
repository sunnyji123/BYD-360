import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  Search,
  RefreshCw,
  Lock,
  Monitor,
  ShieldAlert,
} from 'lucide-react';
import { api } from '../../services/api';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';

export const SuperAdminActivityLogsPanel: React.FC = () => {
  const [data, setData] = useState<{
    immutable: boolean;
    activities: any[];
    saLoginHistory: any[];
    securityEvents: any[];
    modules: string[];
  } | null>(null);
  const [search, setSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [loading, setLoading] = useState(false);

  const loadLogs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.getSuperAdminEnterpriseActivityLogs({
        search: search || undefined,
        module: moduleFilter,
        status: statusFilter,
        fromDate: fromDate || undefined,
        toDate: toDate || undefined,
      });
      setData(res);
    } finally {
      setLoading(false);
    }
  }, [search, moduleFilter, statusFilter, fromDate, toDate]);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  return (
    <div className="space-y-6 text-xs">
      {/* Personal Security Center (MFA, Password, Personal Session History) */}
      <AccountSecurityCenter />

      {/* Immutable Audit & Activity Log Stream */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
                Tamper-Proof Audit Trail
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono text-[10px] font-bold flex items-center gap-1">
                <Lock className="w-3 h-3" />
                <span>IMMUTABLE · READ-ONLY</span>
              </span>
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              Super Admin Activity Logs, Device &amp; Session Telemetry ({data?.activities?.length ?? 0})
            </h3>
            <p className="text-slate-400 mt-0.5">
              All Super Admin mutations, approvals, permission updates, and login events are permanently recorded with IP, browser, device, and session ID. Edit/delete operations are disabled.
            </p>
          </div>
          <button
            type="button"
            onClick={loadLogs}
            className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 self-start shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Logs</span>
          </button>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search admin, action, target, IP..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
          <select value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white">
            <option value="ALL">All Modules</option>
            {(data?.modules || []).map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white">
            <option value="ALL">All Outcomes</option>
            <option value="SUCCESS">SUCCESS</option>
            <option value="WARNING">WARNING</option>
            <option value="ALERT">ALERT</option>
          </select>
          <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono" />
          <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono" />
        </div>

        <div className="overflow-x-auto max-h-96 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] text-slate-400 uppercase tracking-wider">
                <th className="py-2.5 px-3">Date &amp; Time</th>
                <th className="py-2.5 px-3">Administrator</th>
                <th className="py-2.5 px-3">Module · Action</th>
                <th className="py-2.5 px-3">Target &amp; Details</th>
                <th className="py-2.5 px-3">Device · IP · Session</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {(data?.activities || []).map((a: any) => (
                <tr key={a.id} className="hover:bg-slate-900/50">
                  <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400 tabular-nums whitespace-nowrap">
                    {a.created_at?.slice(0, 19).replace('T', ' ')}
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white">{a.admin_name}</div>
                    <div className="text-[10px] text-slate-400">{a.admin_role}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-mono text-cyan-300 font-bold">{a.action}</div>
                    <div className="text-[10px] text-slate-400">{a.module}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-xs">
                    {a.target_id && <div className="font-mono text-white text-[11px]">{a.target_id}</div>}
                    <div className="text-slate-400 text-[11px] truncate">{a.details || '—'}</div>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[10px] text-slate-400">
                    <div>{a.device_name || 'Workstation'} · {a.browser_name || 'Web'}</div>
                    <div>IP {a.ip_address} {a.session_id ? `· ${a.session_id.slice(0, 10)}` : ''}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded font-mono text-[10px] font-bold ${
                        a.status === 'ALERT'
                          ? 'bg-rose-950 text-rose-300'
                          : a.status === 'WARNING'
                            ? 'bg-amber-950 text-amber-300'
                            : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
              {(!data?.activities || data.activities.length === 0) && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-500">
                    No Super Admin activity log entries match the active filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* SA Login/Logout Session Audit & Non-Founder Security Events */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 pt-2">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <Monitor className="w-4 h-4 text-cyan-400" />
              <span>Super Admin Login &amp; Logout History ({data?.saLoginHistory?.length ?? 0})</span>
            </h4>
            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              {(data?.saLoginHistory || []).map((l: any) => (
                <div key={l.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px]">
                  <div className="flex justify-between">
                    <span className={l.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {l.identifier} · {l.success ? 'SUCCESS' : 'FAILED'}
                    </span>
                    <span className="text-slate-500">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
                  </div>
                  <div className="text-slate-400 text-[10px]">
                    {l.device_name || 'Client'} ({l.browser_name || 'Web'}) · IP {l.ip_address} {l.logout_at ? `· Logout ${l.logout_at.slice(11, 19)}` : ''}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Security Alerts &amp; Isolation Events ({data?.securityEvents?.length ?? 0})</span>
            </h4>
            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              {(data?.securityEvents || []).map((ev: any) => (
                <div key={ev.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px]">
                  <div className="flex justify-between font-mono">
                    <span className={ev.severity === 'CRITICAL' ? 'text-rose-400 font-bold' : 'text-amber-300 font-bold'}>
                      [{ev.severity}] {ev.event_type}
                    </span>
                    <span className="text-slate-500">{ev.created_at?.slice(0, 19).replace('T', ' ')}</span>
                  </div>
                  <div className="text-slate-300 mt-0.5">{ev.details}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
