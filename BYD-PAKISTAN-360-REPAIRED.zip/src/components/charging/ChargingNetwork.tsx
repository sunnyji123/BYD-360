import React, { useState, useEffect } from 'react';
import {
  Zap,
  MapPin,
  Clock,
  DollarSign,
  Phone,
  Navigation,
  CheckCircle2,
  Filter,
  ShieldCheck,
  Search,
  ExternalLink,
  SlidersHorizontal,
  ChevronRight,
  Coffee,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { ChargingStation, ChargerPlugType } from '../../types';

export const ChargingNetwork: React.FC = () => {
  const { cityFilter, setCityFilter } = useApp();
  const [stations, setStations] = useState<ChargingStation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStation, setSelectedStation] = useState<ChargingStation | null>(null);
  const [filterPlug, setFilterPlug] = useState<string>('All');
  const [minPowerKw, setMinPowerKw] = useState<number>(0);

  // Reserve modal state
  const [reserveModalOpen, setReserveModalOpen] = useState(false);
  const [reservedSuccess, setReservedSuccess] = useState(false);
  const [navigatingTo, setNavigatingTo] = useState<string | null>(null);

  useEffect(() => {
    const load = () => {
      setStations(db.getChargingStations());
    };
    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  const filteredStations = stations.filter((st) => {
    const matchesCity =
      cityFilter === 'All' ||
      st.city.toLowerCase() === cityFilter.toLowerCase() ||
      (cityFilter === 'Motorways' && st.city === 'Motorways');

    const matchesSearch =
      st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      st.operator.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesPlug =
      filterPlug === 'All' || st.plugTypes.some((p) => p.includes(filterPlug));

    const matchesPower = st.powerKw >= minPowerKw;

    return matchesCity && matchesSearch && matchesPlug && matchesPower;
  });

  const handleReserve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStation) return;

    if (selectedStation.availablePlugs > 0) {
      selectedStation.availablePlugs -= 1;
      db.updateChargingStation(selectedStation);
    }

    setReservedSuccess(true);
    setTimeout(() => {
      setReservedSuccess(false);
      setReserveModalOpen(false);
    }, 2000);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">E-Mobility Grid</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
              PAKISTAN FAST CHARGING CORRIDOR
            </span>
          </div>
          <h2 className="text-2xl font-black text-white">Authorized BYD & Partner Charging Network</h2>
          <p className="text-xs text-slate-400">
            Hubco Green, K-Electric & Motorway M-2 DC Ultra-Fast Terminals (CCS2 & GB/T)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-emerald-400 font-bold bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-800 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            {stations.reduce((sum, s) => sum + s.availablePlugs, 0)} Plugs Available Now
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
        <div className="sm:col-span-5 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search station name, motorway, or area (e.g. Bhera, Clifton, Gulberg)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-800 pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="sm:col-span-3">
          <select
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-semibold"
          >
            <option value="All">All Pakistan Locations</option>
            <option value="Karachi">Karachi Hubs</option>
            <option value="Lahore">Lahore Hubs</option>
            <option value="Islamabad">Islamabad Hubs</option>
            <option value="Motorways">Motorways M-2 (Bhera / Sukheke)</option>
          </select>
        </div>

        <div className="sm:col-span-2">
          <select
            value={filterPlug}
            onChange={(e) => setFilterPlug(e.target.value)}
            className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
          >
            <option value="All">All Plug Standards</option>
            <option value="CCS2">CCS2 Combo DC</option>
            <option value="GB/T">GB/T DC</option>
            <option value="Type 2">Type 2 AC Wallbox</option>
          </select>
        </div>

        <div className="sm:col-span-2">
          <select
            value={minPowerKw}
            onChange={(e) => setMinPowerKw(Number(e.target.value))}
            className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
          >
            <option value={0}>Any Charging Speed</option>
            <option value={120}>≥ 120 kW Fast</option>
            <option value={180}>≥ 180 kW Ultra-Fast</option>
            <option value={240}>240 kW High Power</option>
          </select>
        </div>
      </div>

      {/* Main Grid: Interactive Map Visual + Station Directory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Pakistan Highway Grid Visual representation */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 relative overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span>Pakistan National EV Charging Corridor Map</span>
              </h4>
              <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                LIVE TELEMETRY DEMO
              </span>
            </div>

            {/* Simulated Interactive Stylized Pakistan Map SVG */}
            <div className="relative w-full h-80 sm:h-96 rounded-xl bg-slate-950 border border-slate-800/80 p-4 flex flex-col justify-between overflow-hidden">
              {/* Background Map Grid Pattern */}
              <div
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage: 'radial-gradient(circle, #38bdf8 1px, transparent 1px)',
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Highway M-2 Connector Line */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <line x1="68%" y1="28%" x2="52%" y2="48%" stroke="#06b6d4" strokeWidth="2.5" strokeDasharray="6 4" opacity="0.7" />
                <line x1="52%" y1="48%" x2="62%" y2="58%" stroke="#06b6d4" strokeWidth="2.5" strokeDasharray="6 4" opacity="0.7" />
                <line x1="62%" y1="58%" x2="28%" y2="88%" stroke="#3b82f6" strokeWidth="2" strokeDasharray="8 6" opacity="0.5" />
              </svg>

              {/* Station Hotspot Pins */}
              <div className="relative w-full h-full">
                {/* Islamabad Serena / Centaurus */}
                <div
                  onClick={() => setSelectedStation(stations.find((s) => s.city === 'Islamabad') || null)}
                  className="absolute cursor-pointer group"
                  style={{ top: '22%', left: '66%' }}
                >
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-6 h-6 rounded-full bg-cyan-400/30 animate-ping" />
                    <span className="w-4 h-4 rounded-full bg-cyan-500 border-2 border-white flex items-center justify-center shadow-lg shadow-cyan-500/50" />
                    <div className="absolute top-5 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] font-bold text-white shadow-xl">
                      Islamabad (120 kW)
                    </div>
                  </div>
                </div>

                {/* M-2 Bhera Motorway Hub */}
                <div
                  onClick={() => setSelectedStation(stations.find((s) => s.id === 'chg_m2_bhera') || null)}
                  className="absolute cursor-pointer group"
                  style={{ top: '44%', left: '50%' }}
                >
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-7 h-7 rounded-full bg-emerald-400/30 animate-pulse" />
                    <span className="w-4 h-4 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center shadow-lg shadow-emerald-500/50" />
                    <div className="absolute top-5 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded bg-slate-900/90 border border-emerald-500 text-[10px] font-bold text-emerald-400 shadow-xl">
                      M-2 Bhera (180 kW)
                    </div>
                  </div>
                </div>

                {/* Lahore Gulberg & DHA */}
                <div
                  onClick={() => setSelectedStation(stations.find((s) => s.city === 'Lahore') || null)}
                  className="absolute cursor-pointer group"
                  style={{ top: '54%', left: '60%' }}
                >
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-7 h-7 rounded-full bg-cyan-400/30 animate-ping" />
                    <span className="w-4 h-4 rounded-full bg-cyan-500 border-2 border-white flex items-center justify-center shadow-lg shadow-cyan-500/50" />
                    <div className="absolute top-5 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] font-bold text-white shadow-xl">
                      Lahore (240 kW)
                    </div>
                  </div>
                </div>

                {/* Karachi Clifton & Port Qasim */}
                <div
                  onClick={() => setSelectedStation(stations.find((s) => s.city === 'Karachi') || null)}
                  className="absolute cursor-pointer group"
                  style={{ top: '82%', left: '26%' }}
                >
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-7 h-7 rounded-full bg-cyan-400/30 animate-ping" />
                    <span className="w-4 h-4 rounded-full bg-cyan-500 border-2 border-white flex items-center justify-center shadow-lg shadow-cyan-500/50" />
                    <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-0.5 rounded bg-slate-900/90 border border-slate-700 text-[10px] font-bold text-white shadow-xl">
                      Karachi (180 kW)
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer Indicator in Map */}
              <div className="z-10 flex items-center justify-between text-[11px] text-slate-400 bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                <span>Motorway Route: Lahore ↔ Islamabad (375 km, 1 Stop at Bhera)</span>
                <span className="text-cyan-400 font-semibold">BYD Seal Range: 570 km</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Station Listings & Detail */}
        <div className="lg:col-span-6 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Verified Fast Charging Locations ({filteredStations.length})
            </h4>
            <span className="text-xs text-slate-400">Tap for details & reservation</span>
          </div>

          <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1">
            {filteredStations.map((station) => {
              const isSelected = selectedStation?.id === station.id;
              return (
                <div
                  key={station.id}
                  onClick={() => setSelectedStation(station)}
                  className={`p-4 rounded-xl cursor-pointer border transition text-left ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/70 shadow-lg shadow-cyan-500/10'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
                          {station.powerKw} kW DC
                        </span>
                        <h5 className="text-sm font-bold text-white">{station.name}</h5>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{station.address}</p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-bold text-emerald-400 block">
                        {station.availablePlugs} / {station.totalPlugs} Available
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-200">
                        ₨ {station.pricePerKwhPkr}/kWh
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 mt-3 pt-2 border-t border-slate-800/80">
                    {station.plugTypes.map((plug, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                        {plug}
                      </span>
                    ))}
                    <span className="text-[10px] text-slate-400 ml-auto">
                      Operator: <strong className="text-slate-300">{station.operator}</strong>
                    </span>
                  </div>

                  {isSelected && (
                    <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setReserveModalOpen(true);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                      >
                        Reserve Plug (15 Min Hold)
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setNavigatingTo(station.name);
                          setTimeout(() => setNavigatingTo(null), 3500);
                        }}
                        className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
                      >
                        <Navigation className="w-3.5 h-3.5" />
                        <span>Start Navigation</span>
                      </button>
                    </div>
                  )}

                  {navigatingTo === station.name && (
                    <div className="mt-2 p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-500/50 text-[11px] text-cyan-300 flex items-center justify-between animate-fadeIn">
                      <div className="flex items-center gap-2">
                        <Navigation className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
                        <span>Live Route Calculated: 18 min travel time to {station.name}.</span>
                      </div>
                      <span className="font-mono text-[10px] text-slate-400">VIA M-2 / CITY ARTERY</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Plug Reservation Modal */}
      {reserveModalOpen && selectedStation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Reserve Fast Charging Bay</h3>
            <p className="text-xs text-slate-400 mb-4">{selectedStation.name} • {selectedStation.powerKw} kW DC</p>

            {reservedSuccess ? (
              <div className="py-6 text-center space-y-2">
                <Check className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-white">Plug Bay #2 Reserved!</h4>
                <p className="text-xs text-slate-300">
                  Bay held for 15 minutes. Plug-in passcode sent via SMS to your registered BYD phone.
                </p>
              </div>
            ) : (
              <form onSubmit={handleReserve} className="space-y-4">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Rate per Unit:</span>
                    <span className="font-bold text-cyan-300">₨ {selectedStation.pricePerKwhPkr} PKR / kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Est. 10% to 80% Time:</span>
                    <span className="font-bold text-white">~28 Minutes (Blade Battery)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Selected Plug:</span>
                    <span className="font-bold text-emerald-400">CCS2 Combo DC (150kW Peak)</span>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setReserveModalOpen(false)}
                    className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-xs text-white shadow-md shadow-cyan-500/20"
                  >
                    Confirm Reservation
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
