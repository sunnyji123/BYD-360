import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserRole, UserProfile, Language, CountryCode, CurrencyCode, CountryConfig } from '../types';
import { db } from '../services/db';
import { api } from '../services/api';
import { GLOBAL_COUNTRIES } from '../data/mockData';

export type AppTab =
  | 'landing'
  | 'customer'
  | 'company'
  | 'country'
  | 'branch'
  | 'employee'
  | 'dealer'
  | 'service'
  | 'battery'
  | 'charging'
  | 'warranty'
  | 'inventory'
  | 'finance'
  | 'sales'
  | 'ai-assistant'
  | 'notifications'
  | 'analytics'
  | 'admin'
  | 'owner'
  | 'mobile-preview'
  | 'architecture'
  | 'presentation'
  | 'about';

export type AuthModalMode = 'login' | 'register-customer' | 'register-company' | 'forgot-password' | 'accept-invite' | 'sessions';

interface AppContextType {
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  isAuthenticated: boolean;
  authLoading: boolean;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  selectedCountry: CountryCode;
  setSelectedCountry: (code: CountryCode) => void;
  countryConfig: CountryConfig;
  selectedCurrency: CurrencyCode;
  setSelectedCurrency: (curr: CurrencyCode) => void;
  formatPrice: (amountInPkr: number) => string;
  cityFilter: string;
  setCityFilter: (city: string) => void;
  unreadCount: number;
  resetDemoData: () => void;
  t: (key: string) => string;
  isRTL: boolean;
  isAuthModalOpen: boolean;
  authModalMode: AuthModalMode;
  inviteTokenParam: string | null;
  saInviteTokenParam: string | null;
  openAuthModal: (mode?: AuthModalMode, inviteToken?: string | null) => void;
  closeAuthModal: () => void;
  openFounderPortal: () => void;
  openSuperAdminPortal: () => void;
  openCompanyAdminPortal: () => void;
  openCountryManagerPortal: () => void;
  openBranchManagerPortal: () => void;
  openEmployeePortal: () => void;
  openDealerPortal: () => void;
  openCustomerPortal: (mode?: 'login' | 'register') => void;
  customerAuthInitialMode: 'login' | 'register';
  loginUser: (user: UserProfile) => void;
  logoutUser: () => Promise<void>;
  refreshSession: () => Promise<void>;
}

const GUEST_USER: UserProfile = {
  id: 'guest_visitor',
  companyId: null,
  name: 'Guest Visitor',
  fullName: 'Guest Visitor',
  email: '',
  phone: '',
  role: 'Customer',
  city: 'Karachi',
  country: 'PK',
  verifiedIdentity: false,
};

const EXCHANGE_RATES_FROM_PKR: Record<CurrencyCode, number> = {
  PKR: 1,
  USD: 1 / 280,
  AED: 1 / 76.2,
  SAR: 1 / 74.5,
  GBP: 1 / 355,
  EUR: 1 / 305,
};

const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  PKR: '₨',
  USD: '$',
  AED: 'AED',
  SAR: 'SAR',
  GBP: '£',
  EUR: '€',
};

const TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: {
    platformTitle: 'BYD PAKISTAN 360',
    platformSubtitle: 'Enterprise Automotive & Electric Vehicle Management Ecosystem',
    roleLabel: 'Active Role',
    switchRole: 'Switch Role',
    landing: 'Global Fleet',
    customer: 'Customer Portal',
    company: 'Executive HQ',
    country: 'Country Manager',
    branch: 'Branch Manager',
    employee: 'Employee Portal',
    dealer: 'Dealer Management',
    service: 'Service & Workshop',
    battery: 'Blade Battery Lab',
    charging: 'Charging Network',
    warranty: 'Warranty Claims',
    inventory: 'Global Inventory',
    finance: 'Global Finance',
    aiAssistant: 'BYD AI',
    notifications: 'Notifications',
    analytics: 'Global Analytics',
    admin: 'Super Admin',
    owner: 'Founder Portal',
    mobilePreview: 'Mobile Apps (iOS/Android)',
    architecture: 'API & Architecture',
    presentation: 'Commercial Proposal',
    about: 'About & Legal',
    demoNotice: 'INDEPENDENT ENTERPRISE PROTOTYPE — REAL BACKEND AUTH & DB ISOLATION ACTIVE',
    currency: 'PKR',
    allCities: 'All Regions',
    installApp: 'Install App',
    bookService: 'Book Service',
    findCharger: 'Find Charger',
    bladeBatteryTitle: 'BYD Blade Battery Technology',
  },
  ur: {
    platformTitle: 'بی وائی ڈی پاکستان 360',
    platformSubtitle: 'عالمی انٹرپرائز آٹوموٹو اور الیکٹرک وہیکل مینجمنٹ سسٹم',
    roleLabel: 'فعال کردار',
    switchRole: 'کردار تبدیل کریں',
    landing: 'گاڑیاں اور ہوم',
    customer: 'کسٹمر پورٹل',
    company: 'کمپنی ایگزیکٹو',
    country: 'کنٹری مینیجر',
    branch: 'برانچ مینیجر',
    employee: 'ملازم پورٹل',
    dealer: 'ڈیلرشپ پورٹل',
    service: 'سروس سینٹر',
    battery: 'بلیڈ بیٹری لیب',
    charging: 'چارجنگ گرڈ',
    warranty: 'وارنٹی کلیمز',
    inventory: 'گلوبل انوینٹری',
    finance: 'فنانس اور انوائس',
    aiAssistant: 'بی وائی ڈی اے آئی',
    notifications: 'اطلاعات',
    analytics: 'رپورٹس اور تجزیات',
    admin: 'سپر ایڈمن',
    owner: 'بانی / مالک پورٹل',
    mobilePreview: 'موبائل ایپس (اینڈرائیڈ/آئی او ایس)',
    architecture: 'اے پی آئی اور آرکیٹیکچر',
    presentation: 'بزنس پریزنٹیشن',
    about: 'پروجیکٹ اور قانونی معلومات',
    demoNotice: 'آزاد ڈیموسٹریشن پروٹو ٹائپ — محفوظ بیک اینڈ تصدیق فعال',
    currency: 'روپے',
    allCities: 'تمام خطے',
    installApp: 'ایپ انسٹال کریں',
    bookService: 'سروس بک کریں',
    findCharger: 'چارجر تلاش کریں',
    bladeBatteryTitle: 'بی وائی ڈی بلیڈ بیٹری ٹیکنالوجی',
  },
  ar: {
    platformTitle: 'بي واي دي باكستان 360',
    platformSubtitle: 'النظام المؤسسي لإدارة السيارات والمركبات الكهربائية',
    roleLabel: 'الدور النشط',
    switchRole: 'تبديل الدور',
    landing: 'الأسطول العالمي',
    customer: 'بوابة العملاء',
    company: 'الإدارة التنفيذية',
    country: 'مدير الدولة',
    branch: 'مدير الفرع',
    employee: 'بوابة الموظفين',
    dealer: 'إدارة الوكلاء',
    service: 'مركز الصيانة',
    battery: 'مختبر بطارية بليد',
    charging: 'شبكة الشحن',
    warranty: 'إدارة الضمان',
    inventory: 'المستودعات وقطع الغيار',
    finance: 'المالية والفواتير',
    aiAssistant: 'BYD AI المستشار',
    notifications: 'الإشعارات',
    analytics: 'التحليلات العالمية',
    admin: 'المشرف العام',
    owner: 'بوابة المؤسس والمالك',
    mobilePreview: 'تطبيقات الجوال (iOS/Android)',
    architecture: 'المعمارية وواجهات البرمجة',
    presentation: 'العرض التجاري',
    about: 'عن المشروع والشروط',
    demoNotice: 'نموذج مؤسسي مستقل — نظام مصادقة حقيقي وعزل للبيانات',
    currency: 'ريال/درهم',
    allCities: 'جميع المدن',
    installApp: 'تثبيت التطبيق',
    bookService: 'حجز صيانة',
    findCharger: 'محطات الشحن',
    bladeBatteryTitle: 'تكنولوجيا بطارية بليد من بي واي دي',
  },
};

const AppContext = createContext<AppContextType | undefined>(undefined);

function mapServerUserToProfile(u: any): UserProfile {
  return {
    id: u.userId || u.id,
    companyId: u.companyId || null,
    branchId: u.branchId || null,
    branchName: u.branchName || null,
    name: u.fullName || u.name,
    fullName: u.fullName || u.name,
    email: u.email,
    phone: u.mobile || u.phone || '',
    role: u.role as UserRole,
    subjectType: u.subjectType || 'user',
    managerCode: u.managerCode || null,
    employeeId: u.employeeId || null,
    employeeCode: u.employeeCode || null,
    department: u.department || null,
    reportingManagerName: u.reportingManagerName || null,
    dealerId: u.dealerId || null,
    dealerCode: u.dealerCode || null,
    dealerCategory: u.dealerCategory || null,
    customerId: u.customerId || null,
    customerCode: u.customerCode || null,
    mobileVerified: Boolean(u.mobileVerified),
    address: u.address || '',
    verificationStatus: u.verificationStatus || null,
    designation: u.designation,
    accountType: u.accountType,
    accessLevel: u.accessLevel,
    permissions: u.permissions || [],
    dealershipId: u.dealershipId || null,
    city: u.city || 'Karachi',
    country: (u.country || 'PK') as CountryCode,
    verifiedIdentity: u.verifiedIdentity !== undefined ? Boolean(u.verifiedIdentity) : true,
    emailVerified: u.emailVerified !== false,
  };
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<UserProfile>(GUEST_USER);
  const [currentRole, setRoleState] = useState<UserRole>('Customer');
  const [selectedCountry, setSelectedCountryState] = useState<CountryCode>('PK');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('PKR');

  const [activeTab, setActiveTab] = useState<AppTab>('landing');
  const [language, setLanguage] = useState<Language>('en');
  const [cityFilter, setCityFilter] = useState<string>('All');
  const [unreadCount, setUnreadCount] = useState<number>(0);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('login');
  const [inviteTokenParam, setInviteTokenParam] = useState<string | null>(null);
  const [saInviteTokenParam, setSaInviteTokenParam] = useState<string | null>(null);
  const [customerAuthInitialMode, setCustomerAuthInitialMode] = useState<'login' | 'register'>('login');

  const refreshSession = useCallback(async () => {
    try {
      const me = await api.getMe();
      if (me.authenticated && me.user) {
        const mapped = mapServerUserToProfile(me.user);
        setCurrentUser(mapped);
        setRoleState(mapped.role);
        setIsAuthenticated(true);
      } else {
        setCurrentUser(GUEST_USER);
        setRoleState('Customer');
        setIsAuthenticated(false);
      }
    } catch {
      setCurrentUser(GUEST_USER);
      setIsAuthenticated(false);
    } finally {
      setAuthLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  const countryConfig =
    GLOBAL_COUNTRIES.find((c) => c.code === selectedCountry) || GLOBAL_COUNTRIES[0];

  const setSelectedCountry = (code: CountryCode) => {
    setSelectedCountryState(code);
    const cfg = GLOBAL_COUNTRIES.find((c) => c.code === code);
    if (cfg) {
      setSelectedCurrency(cfg.defaultCurrency);
    }
  };

  const formatPrice = (amountInPkr: number): string => {
    const rate = EXCHANGE_RATES_FROM_PKR[selectedCurrency] || 1;
    const converted = amountInPkr * rate;
    const symbol = CURRENCY_SYMBOLS[selectedCurrency] || '';
    if (selectedCurrency === 'PKR') {
      return `${symbol} ${Math.round(converted).toLocaleString()} PKR`;
    }
    return `${symbol} ${Math.round(converted).toLocaleString()} ${selectedCurrency}`;
  };

  const isRTL = language === 'ur' || language === 'ar';

  // Role switching must NEVER bypass server authentication — clicking role opens auth modal if unauthenticated
  const setRole = (_newRole: UserRole) => {
    setAuthModalMode('login');
    setIsAuthModalOpen(true);
  };

  useEffect(() => {
    const updateUnread = () => {
      const notifs = db.getNotifications();
      setUnreadCount(notifs.filter((n) => !n.read).length);
    };
    updateUnread();
    const unsub = db.subscribe(updateUnread);
    return () => unsub();
  }, []);

  // Check URL parameters for tab routing, /founder-login shortcut, or employee invite token
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const invite = params.get('invite');
      if (invite) {
        setInviteTokenParam(invite);
        setAuthModalMode('accept-invite');
        setIsAuthModalOpen(true);
      }
      const saInvite = params.get('sa-invite');
      if (saInvite) {
        setSaInviteTokenParam(saInvite);
        setActiveTab('admin');
        return;
      }
      if (window.location.pathname === '/customer-login' || params.get('portal') === 'customer') {
        if (params.get('mode') === 'register') {
          setCustomerAuthInitialMode('register');
        }
        setActiveTab('customer');
        return;
      }
      if (window.location.pathname === '/dealer-login' || params.get('portal') === 'dealer') {
        setActiveTab('dealer');
        return;
      }
      if (window.location.pathname === '/employee-login' || params.get('portal') === 'employee') {
        setActiveTab('employee');
        return;
      }
      if (window.location.pathname === '/branch-manager-login' || params.get('portal') === 'branch-manager') {
        setActiveTab('branch');
        return;
      }
      if (window.location.pathname === '/country-manager-login' || params.get('portal') === 'country-manager') {
        setActiveTab('country');
        return;
      }
      if (window.location.pathname === '/company-admin-login' || params.get('portal') === 'company-admin') {
        setActiveTab('company');
        return;
      }
      if (window.location.pathname === '/super-admin-login' || params.get('portal') === 'super-admin') {
        setActiveTab('admin');
        return;
      }
      if (window.location.pathname === '/founder-login' || params.get('portal') === 'founder') {
        setActiveTab('owner');
        return;
      }
      const tabParam = params.get('tab') as AppTab | null;
      const validTabs: AppTab[] = [
        'landing', 'customer', 'company', 'country', 'branch', 'employee', 'dealer', 'service', 'battery',
        'charging', 'warranty', 'inventory', 'finance', 'ai-assistant',
        'notifications', 'analytics', 'admin', 'owner', 'mobile-preview',
        'architecture', 'presentation', 'about',
      ];
      if (tabParam && validTabs.includes(tabParam)) {
        setActiveTab(tabParam);
      }
    }
  }, []);

  const openAuthModal = (mode: AuthModalMode = 'login', inviteToken: string | null = null) => {
    setAuthModalMode(mode);
    if (inviteToken !== undefined) {
      setInviteTokenParam(inviteToken);
    }
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => setIsAuthModalOpen(false);

  const openFounderPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('owner');
  };

  const openSuperAdminPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('admin');
  };

  const openCompanyAdminPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('company');
  };

  const openCountryManagerPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('country');
  };

  const openBranchManagerPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('branch');
  };

  const openEmployeePortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('employee');
  };

  const openDealerPortal = () => {
    setIsAuthModalOpen(false);
    setActiveTab('dealer');
  };

  const openCustomerPortal = (mode: 'login' | 'register' = 'login') => {
    setIsAuthModalOpen(false);
    setCustomerAuthInitialMode(mode);
    setActiveTab('customer');
  };

  const loginUser = (rawUser: any) => {
    const user = mapServerUserToProfile(rawUser);
    setCurrentUser(user);
    setRoleState(user.role);
    setIsAuthenticated(true);
    setIsAuthModalOpen(false);

    const role = user.role;
    if (user.subjectType === 'founder' || role === 'Founder / Owner') {
      setActiveTab('owner');
    } else if (user.subjectType === 'super_admin' || role === 'Super Admin' || role === 'Global Super Admin' || role === 'Country Administrator' || role === 'Auditor / Read-only User') {
      setActiveTab('admin');
    } else if (user.subjectType === 'country_manager' || role === 'Country Manager') {
      setActiveTab('country');
    } else if (user.subjectType === 'branch_manager' || role === 'Branch Manager') {
      setActiveTab('branch');
    } else if (user.subjectType === 'employee') {
      setActiveTab('employee');
    } else if (user.subjectType === 'dealer') {
      setActiveTab('dealer');
    } else if (user.subjectType === 'customer') {
      setActiveTab('customer');
    } else if (user.subjectType === 'company_admin' || role === 'Company Admin') {
      setActiveTab('company');
    } else if (role === 'Customer') {
      setActiveTab('customer');
    } else if (role === 'Head Office Staff' || role === 'Global Management' || role === 'Regional Manager' || role === 'Company Management') {
      setActiveTab('company');
    } else if (role === 'Dealership Manager' || role === 'Dealership Staff' || role === 'Dealer Owner' || role === 'Dealer Manager' || role === 'Sales Manager' || role === 'Sales Executive') {
      setActiveTab('dealer');
    } else if (role === 'Service Manager' || role === 'Service Advisor' || role === 'Workshop Technician' || role === 'Technical Support' || role === 'Technician') {
      setActiveTab('service');
    } else if (role === 'Warranty Manager') {
      setActiveTab('warranty');
    } else if (role === 'Inventory Manager') {
      setActiveTab('inventory');
    } else if (role === 'Finance Manager') {
      setActiveTab('finance');
    } else if (role === 'Customer Support Agent') {
      setActiveTab('notifications');
    }
  };

  const logoutUser = async () => {
    try {
      if (currentUser.subjectType === 'super_admin') {
        await api.superAdminLogout();
      } else if (currentUser.subjectType === 'company_admin') {
        await api.companyAdminLogout();
      } else if (currentUser.subjectType === 'country_manager') {
        await api.countryManagerLogout();
      } else if (currentUser.subjectType === 'branch_manager') {
        await api.branchManagerLogout();
      } else if (currentUser.subjectType === 'employee') {
        await api.employeeLogout();
      } else if (currentUser.subjectType === 'dealer') {
        await api.dealerLogout();
      } else if (currentUser.subjectType === 'customer') {
        await api.customerLogout();
      } else {
        await api.logout();
      }
    } catch {
      // ignore
    }
    setCurrentUser(GUEST_USER);
    setRoleState('Customer');
    setIsAuthenticated(false);
    if (activeTab === 'owner' || activeTab === 'admin' || activeTab === 'branch' || activeTab === 'employee' || activeTab === 'dealer') {
      setActiveTab('landing');
    }
  };

  const resetDemoData = () => {
    db.resetToDefaults();
  };

  const t = (key: string) => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS.en[key] || key;
  };

  return (
    <AppContext.Provider
      value={{
        currentRole,
        setRole,
        currentUser,
        setCurrentUser,
        isAuthenticated,
        authLoading,
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        selectedCountry,
        setSelectedCountry,
        countryConfig,
        selectedCurrency,
        setSelectedCurrency,
        formatPrice,
        cityFilter,
        setCityFilter,
        unreadCount,
        resetDemoData,
        t,
        isRTL,
        isAuthModalOpen,
        authModalMode,
        inviteTokenParam,
        saInviteTokenParam,
        openAuthModal,
        closeAuthModal,
        openFounderPortal,
        openSuperAdminPortal,
        openCompanyAdminPortal,
        openCountryManagerPortal,
        openBranchManagerPortal,
        openEmployeePortal,
        openDealerPortal,
        openCustomerPortal,
        customerAuthInitialMode,
        loginUser,
        logoutUser,
        refreshSession,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
