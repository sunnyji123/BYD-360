import React, { useState, useEffect } from 'react';
import {
  Shield,
  Lock,
  Mail,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  X,
  Building2,
  UserPlus,
  Car,
  Crown,
  KeyRound,
  LogOut,
  Monitor,
  History,
  Trash2,
  Globe,
  Store,
  BadgeCheck,
  Layers,
} from 'lucide-react';
import { useApp, AuthModalMode } from '../../context/AppContext';
import { api } from '../../services/api';

export const CorporateAuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    authModalMode,
    inviteTokenParam,
    openAuthModal,
    closeAuthModal,
    openFounderPortal,
    openSuperAdminPortal,
    openCompanyAdminPortal,
    openCountryManagerPortal,
    openBranchManagerPortal,
    openEmployeePortal,
    openDealerPortal,
    openCustomerPortal,
    loginUser,
    logoutUser,
    isAuthenticated,
    currentUser,
  } = useApp();

  const [mode, setMode] = useState<AuthModalMode>(authModalMode);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Login state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // 2FA state
  const [show2FA, setShow2FA] = useState(false);
  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');

  // Public approved companies list
  const [publicCompanies, setPublicCompanies] = useState<any[]>([]);

  // Customer registration + email verification state
  const [custName, setCustName] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custMobile, setCustMobile] = useState('+92 300 ');
  const [custCountry, setCustCountry] = useState('PK');
  const [custCity, setCustCity] = useState('Karachi');
  const [custCnic, setCustCnic] = useState('');
  const [custCompanyId, setCustCompanyId] = useState('comp_byd_pk');
  const [custPassword, setCustPassword] = useState('');
  const [custTermsAccepted, setCustTermsAccepted] = useState(false);
  const [custPrivacyAccepted, setCustPrivacyAccepted] = useState(false);
  const [verifyPendingEmail, setVerifyPendingEmail] = useState<string | null>(null);
  const [verifyCode, setVerifyCode] = useState('');
  const [devVerifyCodeHint, setDevVerifyCodeHint] = useState<string | null>(null);

  // Company registration state
  const [compName, setCompName] = useState('');
  const [compCountry, setCompCountry] = useState('PK');
  const [compCity, setCompCity] = useState('');
  const [compEmail, setCompEmail] = useState('');
  const [compPhone, setCompPhone] = useState('+92 ');
  const [compAddress, setCompAddress] = useState('');
  const [compRegDetails, setCompRegDetails] = useState('');
  const [compRep, setCompRep] = useState('');
  const [compAdminPassword, setCompAdminPassword] = useState('');

  // Accept Invite state
  const [inviteToken, setInviteToken] = useState(inviteTokenParam || '');
  const [inviteDetails, setInviteDetails] = useState<any>(null);
  const [invitePassword, setInvitePassword] = useState('');
  const [inviteMobile, setInviteMobile] = useState('');

  // Forgot / Reset Password state
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotMethod, setForgotMethod] = useState<'otp' | 'token'>('otp');
  const [resetToken, setResetToken] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [devResetHint, setDevResetHint] = useState<string | null>(null);
  const [resetStep, setResetStep] = useState<'request' | 'confirm'>('request');

  // Sessions & History state
  const [sessions, setSessions] = useState<any[]>([]);
  const [loginHistory, setLoginHistory] = useState<any[]>([]);

  useEffect(() => {
    setMode(authModalMode);
    setErrorMsg('');
    setSuccessMsg('');
  }, [authModalMode, isAuthModalOpen]);

  useEffect(() => {
    if (inviteTokenParam) {
      setInviteToken(inviteTokenParam);
    }
  }, [inviteTokenParam]);

  useEffect(() => {
    if (!isAuthModalOpen) return;
    api
      .getPublicCompanies()
      .then((res) => setPublicCompanies(res.companies || []))
      .catch(() => {});
  }, [isAuthModalOpen]);

  useEffect(() => {
    if (isAuthModalOpen && mode === 'sessions' && isAuthenticated) {
      Promise.all([api.getSessions(), api.getLoginHistory()])
        .then(([s, h]) => {
          setSessions(s.sessions || []);
          setLoginHistory(h.history || []);
        })
        .catch(() => {});
    }
  }, [isAuthModalOpen, mode, isAuthenticated]);

  useEffect(() => {
    if (mode === 'accept-invite' && inviteToken.trim().length > 10) {
      api
        .lookupInvite(inviteToken.trim())
        .then((res) => {
          setInviteDetails(res);
          setErrorMsg('');
        })
        .catch((err: any) => {
          setInviteDetails(null);
          setErrorMsg(err.message || 'Invalid or expired invitation token.');
        });
    }
  }, [mode, inviteToken]);

  if (!isAuthModalOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSubmitting(true);
    try {
      const res = await api.login({ identifier: identifier.trim(), password });
      setPassword('');
      if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setShow2FA(true);
        setSuccessMsg(res.message || 'Password verified. Complete 2FA to sign in.');
      } else if (res.user) {
        loginUser(res.user);
      } else if (res.success) {
        loginUser(res.user || { id: 'founder', name: res.founderName || 'Founder', email: identifier, role: res.role || 'Founder / Owner' });
      } else {
        setErrorMsg(res.message || 'Authentication completed but no user data received.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitting(true);
    try {
      const res = await api.founderVerify2FA({ challengeToken, code: twoFactorCode.trim() });
      if (res.success && res.user) {
        loginUser(res.user);
        setShow2FA(false);
        setTwoFactorCode('');
        setChallengeToken('');
      } else {
        setErrorMsg(res.message || '2FA verification failed.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || '2FA verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegisterCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    if (!custTermsAccepted || !custPrivacyAccepted) {
      setErrorMsg('You must accept both the Terms of Service and Privacy Policy to register.');
      return;
    }
    setSubmitting(true);
    try {
      const res = await api.registerCustomer({
        fullName: custName,
        email: custEmail,
        mobile: custMobile,
        password: custPassword,
        country: custCountry,
        city: custCity,
        cnicOrId: custCnic,
        companyId: custCompanyId,
        termsAccepted: custTermsAccepted,
        privacyAccepted: custPrivacyAccepted,
      });
      setVerifyPendingEmail(res.email);
      setDevVerifyCodeHint(res.verificationOutbox?.code || null);
      setSuccessMsg(res.message);
    } catch (err: any) {
      setErrorMsg(err.message || 'Customer registration failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyPendingEmail) return;
    setErrorMsg('');
    setSubmitting(true);
    try {
      const res = await api.verifyEmail({ email: verifyPendingEmail, code: verifyCode.trim() });
      setSuccessMsg(res.message);
      setIdentifier(verifyPendingEmail);
      setVerifyPendingEmail(null);
      setVerifyCode('');
      setMode('login');
    } catch (err: any) {
      setErrorMsg(err.message || 'Verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegisterCompany = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setSubmitting(true);
    try {
      const res = await api.registerCompany({
        companyName: compName,
        country: compCountry,
        city: compCity,
        officialEmail: compEmail,
        phone: compPhone,
        address: compAddress,
        registrationDetails: compRegDetails,
        authorizedRep: compRep,
        adminPassword: compAdminPassword,
      });
      const outboxMsg = res.verificationOutbox?.code
        ? ` Verification OTP (${compEmail}): ${res.verificationOutbox.code}.`
        : '';
      const totpMsg = res.twoFactorSetup?.secret
        ? ` 2FA TOTP Secret: ${res.twoFactorSetup.secret}.`
        : '';
      setSuccessMsg(`${res.message}${outboxMsg}${totpMsg}`);
      setCompName('');
      setCompEmail('');
      setCompAdminPassword('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Company registration failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAcceptInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitting(true);
    try {
      const res = await api.acceptInvite({
        token: inviteToken.trim(),
        password: invitePassword,
        mobile: inviteMobile || undefined,
      });
      setSuccessMsg(res.message);
      if (inviteDetails?.email) setIdentifier(inviteDetails.email);
      setInviteDetails(null);
      setInvitePassword('');
      setMode('login');
    } catch (err: any) {
      setErrorMsg(err.message || 'Could not activate invitation.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitting(true);
    try {
      if (forgotMethod === 'otp') {
        const res = await api.unifiedForgotPasswordOtp(forgotEmail.trim(), 'email');
        setSuccessMsg(res.message);
        setDevResetHint(res.resetOutbox?.otpCode || null);
        setResetToken('');
      } else {
        const res = await api.unifiedForgotPassword(forgotEmail.trim());
        setSuccessMsg(res.message);
        setDevResetHint(res.resetOutbox?.resetToken || null);
        if (res.resetOutbox?.resetToken) {
          setResetToken(res.resetOutbox.resetToken);
        }
      }
      setResetStep('confirm');
    } catch (err: any) {
      setErrorMsg(err.message || 'Password reset request failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (resetConfirmPassword && resetConfirmPassword !== resetNewPassword) {
      setErrorMsg('New password and confirm password do not match.');
      return;
    }
    setSubmitting(true);
    try {
      const res =
        forgotMethod === 'otp'
          ? await api.unifiedResetPasswordOtp({
              email: forgotEmail.trim(),
              otpCode: resetToken.trim(),
              newPassword: resetNewPassword,
              confirmPassword: resetConfirmPassword || resetNewPassword,
            })
          : await api.unifiedResetPassword({
              token: resetToken.trim(),
              newPassword: resetNewPassword,
              confirmPassword: resetConfirmPassword || resetNewPassword,
            });
      setSuccessMsg(res.message);
      setResetStep('request');
      setResetToken('');
      setResetNewPassword('');
      setResetConfirmPassword('');
      setMode('login');
    } catch (err: any) {
      setErrorMsg(err.message || 'Password reset failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 p-5 sm:p-6 border-b border-slate-800 relative">
          <button
            onClick={closeAuthModal}
            className="absolute top-5 right-5 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-cyan-400">
                BYD PAKISTAN 360 • Identity &amp; Access
              </span>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {isAuthenticated ? `Signed In: ${currentUser.name}` : 'Enterprise & Customer Portal Authentication'}
              </h2>
            </div>
          </div>

          {/* Mode Tabs */}
          <div className="mt-4 flex flex-wrap gap-1.5">
            {[
              { id: 'login', label: 'Sign In' },
              { id: 'register-customer', label: 'Customer Portal' },
              { id: 'register-company', label: 'Register Company' },
              { id: 'accept-invite', label: 'Staff Invite' },
              { id: 'forgot-password', label: 'Reset Password' },
              ...(isAuthenticated ? [{ id: 'sessions', label: 'Sessions & Security' }] : []),
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  if (t.id === 'register-customer') {
                    openCustomerPortal('register');
                    return;
                  }
                  setMode(t.id as AuthModalMode);
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  mode === t.id
                    ? 'bg-cyan-500 text-slate-950'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* MODE 1: STANDARD LOGIN */}
          {mode === 'login' && (
            <div className="space-y-4">
              {isAuthenticated && (
                <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="text-white font-bold">{currentUser.name}</div>
                    <div className="text-cyan-300">{currentUser.role} • {currentUser.email}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setMode('sessions')}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 font-semibold"
                    >
                      Sessions
                    </button>
                    <button
                      type="button"
                      onClick={logoutUser}
                      className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900 font-semibold flex items-center gap-1"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Logout
                    </button>
                  </div>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Email, Username, or Registered Mobile
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      placeholder="name@company.com or +92 300 ..."
                      className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-300">Password</label>
                    <button
                      type="button"
                      onClick={() => setMode('forgot-password')}
                      className="text-xs text-cyan-400 hover:text-cyan-300"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-cyan-600/20 disabled:opacity-50"
                >
                  {submitting ? 'Authenticating...' : 'Sign In to Workspace'}
                </button>
              </form>

              {/* 2FA VERIFICATION (shown after password verified) */}
              {show2FA && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 space-y-2">
                    <div className="flex items-start gap-2">
                      <KeyRound className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-cyan-300 text-sm">Two-Factor Authentication</div>
                        <div className="text-xs text-cyan-200/80">
                          Enter your 6-digit Authenticator TOTP code or a backup recovery code to complete sign-in.
                        </div>
                      </div>
                    </div>
                  </div>
                  <form onSubmit={handleVerify2FA} className="space-y-3">
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        required
                        maxLength={8}
                        value={twoFactorCode}
                        onChange={(e) => setTwoFactorCode(e.target.value)}
                        placeholder="6-digit TOTP or recovery code"
                        className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-cyan-500/50 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-none"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => setShow2FA(false)}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        ← Back to password
                      </button>
                    </div>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/20 disabled:opacity-50"
                    >
                      {submitting ? 'Verifying 2FA...' : 'Complete 2FA & Sign In'}
                    </button>
                  </form>
                </div>
              )}

              {/* Dedicated Portal Separation Notice */}
              <div className="pt-3 border-t border-slate-800 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                  <div>
                    <div className="text-[11px] font-bold text-emerald-300">Looking for Customer Login or Registration?</div>
                    <div className="text-[11px] text-slate-400">Customer accounts authenticate exclusively in the Dedicated Customer Portal.</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => openCustomerPortal('login')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px]"
                    >
                      Customer Login
                    </button>
                    <button
                      type="button"
                      onClick={() => openCustomerPortal('register')}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/40 font-bold text-[11px]"
                    >
                      Register
                    </button>
                  </div>
                </div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Seeded Corporate Account (Server Auth Required)
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { label: 'Dealership Manager', email: 'farhan.zaidi@megamotor.demo' },
                  ].map((acct) => (
                    <button
                      key={acct.email}
                      type="button"
                      onClick={() => setIdentifier(acct.email)}
                      className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left text-[11px]"
                    >
                      <div className="font-bold text-cyan-300">{acct.label}</div>
                      <div className="text-[10px] text-slate-400 truncate">{acct.email}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* MODE 2: CUSTOMER SELF-REGISTRATION & EMAIL VERIFICATION */}
          {mode === 'register-customer' && (
            verifyPendingEmail ? (
              <form onSubmit={handleVerifyEmail} className="space-y-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-1 text-xs">
                  <div className="font-bold text-cyan-300">Email Verification Required</div>
                  <p className="text-slate-300">
                    Enter the 6-digit verification code sent to <strong>{verifyPendingEmail}</strong> to activate your customer account.
                  </p>
                  {devVerifyCodeHint && (
                    <p className="text-amber-300 font-mono pt-1">
                      Simulated Mailer Outbox (SMTP not configured): <strong>{devVerifyCodeHint}</strong>
                    </p>
                  )}
                </div>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={verifyCode}
                  onChange={(e) => setVerifyCode(e.target.value)}
                  placeholder="Enter 6-digit code"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
                />
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                >
                  {submitting ? 'Verifying...' : 'Verify Email & Activate Customer Account'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleRegisterCustomer} className="space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Full Legal Name"
                    value={custName}
                    onChange={(e) => setCustName(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email Address"
                    value={custEmail}
                    onChange={(e) => setCustEmail(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="tel"
                    required
                    placeholder="Mobile Number"
                    value={custMobile}
                    onChange={(e) => setCustMobile(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    required
                    placeholder="City"
                    value={custCity}
                    onChange={(e) => setCustCity(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <select
                    value={custCountry}
                    onChange={(e) => setCustCountry(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  >
                    <option value="PK">Pakistan (PK)</option>
                    <option value="AE">UAE (AE)</option>
                    <option value="SA">Saudi Arabia (SA)</option>
                    <option value="GB">United Kingdom (GB)</option>
                    <option value="DE">Germany (DE)</option>
                  </select>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="CNIC / National ID (Optional)"
                    value={custCnic}
                    onChange={(e) => setCustCnic(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <select
                    value={custCompanyId}
                    onChange={(e) => setCustCompanyId(e.target.value)}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  >
                    {publicCompanies.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <input
                  type="password"
                  required
                  placeholder="Create Strong Password (10+ chars, Upper, Lower, Digit, Symbol)"
                  value={custPassword}
                  onChange={(e) => setCustPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="space-y-1.5 rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-slate-300">
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={custTermsAccepted}
                      onChange={(e) => setCustTermsAccepted(e.target.checked)}
                      className="mt-0.5"
                    />
                    <span>I accept the BYD PAKISTAN 360 Terms of Service.</span>
                  </label>
                  <label className="flex items-start gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={custPrivacyAccepted}
                      onChange={(e) => setCustPrivacyAccepted(e.target.checked)}
                      className="mt-0.5"
                    />
                    <span>I consent to the Privacy Policy for verification &amp; account security.</span>
                  </label>
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-xs flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{submitting ? 'Creating Account...' : 'Create Independent Customer Account'}</span>
                </button>
              </form>
            )
          )}

          {/* MODE 3: INDEPENDENT COMPANY REGISTRATION */}
          {mode === 'register-company' && (
            <form onSubmit={handleRegisterCompany} className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                Register an independent dealership group or automotive company. Workspaces remain strictly data-isolated and activate after Primary Owner approval.
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Company Legal Name"
                  value={compName}
                  onChange={(e) => setCompName(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  required
                  placeholder="Company Registration / Tax No."
                  value={compRegDetails}
                  onChange={(e) => setCompRegDetails(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select
                  value={compCountry}
                  onChange={(e) => setCompCountry(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="PK">Pakistan</option>
                  <option value="AE">UAE</option>
                  <option value="SA">Saudi Arabia</option>
                  <option value="GB">UK</option>
                  <option value="DE">Germany</option>
                </select>
                <input
                  type="text"
                  required
                  placeholder="Headquarters City"
                  value={compCity}
                  onChange={(e) => setCompCity(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="tel"
                  required
                  placeholder="Official Phone"
                  value={compPhone}
                  onChange={(e) => setCompPhone(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="text"
                required
                placeholder="Official Street Address"
                value={compAddress}
                onChange={(e) => setCompAddress(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Authorized Representative Full Name"
                  value={compRep}
                  onChange={(e) => setCompRep(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="email"
                  required
                  placeholder="Official Company Admin Email"
                  value={compEmail}
                  onChange={(e) => setCompEmail(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="password"
                required
                placeholder="Company Admin Strong Password (10+ chars, Upper/Lower/Digit/Symbol)"
                value={compAdminPassword}
                onChange={(e) => setCompAdminPassword(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-xs flex items-center justify-center gap-2"
              >
                <Building2 className="w-4 h-4" />
                <span>{submitting ? 'Submitting Registration...' : 'Submit Company Registration for Owner Approval'}</span>
              </button>
            </form>
          )}

          {/* MODE 4: ACCEPT EMPLOYEE INVITE */}
          {mode === 'accept-invite' && (
            <form onSubmit={handleAcceptInvite} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Single-Use Invitation Token</label>
                <input
                  type="text"
                  required
                  value={inviteToken}
                  onChange={(e) => setInviteToken(e.target.value)}
                  placeholder="Paste invitation token from your company invite link"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                />
              </div>

              {inviteDetails && (
                <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-1">
                  <div className="font-bold text-white">{inviteDetails.fullName} ({inviteDetails.email})</div>
                  <div className="text-cyan-300">Assigned Role: {inviteDetails.role} • {inviteDetails.companyName}</div>
                </div>
              )}

              <input
                type="tel"
                placeholder="Mobile Number (Optional)"
                value={inviteMobile}
                onChange={(e) => setInviteMobile(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="password"
                required
                placeholder="Set Your Private Password (10+ chars, Upper/Lower/Digit/Symbol)"
                value={invitePassword}
                onChange={(e) => setInvitePassword(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button
                type="submit"
                disabled={submitting || !inviteToken}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                {submitting ? 'Activating Account...' : 'Create Password & Activate Employee Account'}
              </button>
            </form>
          )}

          {/* MODE 5: FORGOT / RESET PASSWORD */}
          {mode === 'forgot-password' && (
            <div className="space-y-3 text-xs">
              <div className="flex gap-2 border-b border-slate-800 pb-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setForgotMethod('otp');
                    setResetStep('request');
                    setDevResetHint(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-semibold ${
                    forgotMethod === 'otp' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 border border-slate-700 text-slate-300'
                  }`}
                >
                  6-Digit Email OTP Recovery
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setForgotMethod('token');
                    setResetStep('request');
                    setDevResetHint(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-semibold ${
                    forgotMethod === 'token' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 border border-slate-700 text-slate-300'
                  }`}
                >
                  Single-Use Reset Token
                </button>
              </div>

              {resetStep === 'request' ? (
                <form onSubmit={handleForgotRequest} className="space-y-4">
                  <p className="text-slate-300">
                    Enter your account email to receive {forgotMethod === 'otp' ? 'an expiring 6-digit recovery OTP' : 'a single-use password reset token'}. (Primary Owner password recovery is isolated.)
                  </p>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="Registered Email Address"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                  />
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                  >
                    {submitting ? 'Processing...' : forgotMethod === 'otp' ? 'Send 6-Digit Recovery OTP' : 'Request Password Reset Token'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetConfirm} className="space-y-3">
                  {devResetHint && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 font-mono break-all">
                      Dev Outbox (SMTP unconfigured) {forgotMethod === 'otp' ? 'OTP' : 'Token'}: {devResetHint}
                    </div>
                  )}
                  <input
                    type="text"
                    required
                    maxLength={forgotMethod === 'otp' ? 6 : 128}
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder={forgotMethod === 'otp' ? 'Enter 6-Digit Recovery OTP' : 'Paste Reset Token'}
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                  <input
                    type="password"
                    required
                    value={resetNewPassword}
                    onChange={(e) => setResetNewPassword(e.target.value)}
                    placeholder="New Strong Password (min 10 chars, upper/lower/num/symbol)"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="password"
                    required
                    value={resetConfirmPassword}
                    onChange={(e) => setResetConfirmPassword(e.target.value)}
                    placeholder="Confirm New Password"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setResetStep('request')}
                      className="px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-semibold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                    >
                      {submitting ? 'Resetting...' : 'Verify & Reset Password'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* MODE 6: ACTIVE SESSIONS & LOGIN HISTORY */}
          {mode === 'sessions' && isAuthenticated && (
            <div className="space-y-4 text-xs">
              <div className="space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <Monitor className="w-4 h-4 text-cyan-400" />
                  <span>Active Authenticated Sessions ({sessions.length})</span>
                </div>
                {sessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-white">
                        {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        IP: {s.ip_address} • Expires: {s.expires_at?.slice(0, 19).replace('T', ' ')}
                      </div>
                    </div>
                    {!s.is_current && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.revokeSession(s.id);
                          setSessions((prev) => prev.filter((x) => x.id !== s.id));
                        }}
                        className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <History className="w-4 h-4 text-amber-400" />
                  <span>Recent Login Activity</span>
                </div>
                <div className="max-h-40 overflow-y-auto space-y-1.5">
                  {loginHistory.map((h) => (
                    <div key={h.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <span className="font-mono text-slate-300">{h.ip_address}</span>
                      <span className="text-slate-400">{h.created_at?.slice(0, 19).replace('T', ' ')}</span>
                      <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                        {h.success ? 'SUCCESS' : 'FAILED'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Segregated Privileged Portals */}
          <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-slate-500">Isolated Governance Portals</span>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => openCustomerPortal('login')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/40 text-emerald-300 hover:text-emerald-200 font-bold"
              >
                <Car className="w-3.5 h-3.5" />
                <span>Customer Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openDealerPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-blue-500/40 bg-blue-950/40 text-blue-300 hover:text-blue-200 font-bold"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Dealer Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openEmployeePortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-teal-500/40 bg-teal-950/40 text-teal-300 hover:text-teal-200 font-bold"
              >
                <BadgeCheck className="w-3.5 h-3.5" />
                <span>Employee Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openBranchManagerPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-sky-500/40 bg-sky-950/40 text-sky-300 hover:text-sky-200 font-bold"
              >
                <Store className="w-3.5 h-3.5" />
                <span>Branch Manager Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openCountryManagerPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/40 text-emerald-300 hover:text-emerald-200 font-bold"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Country Manager Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openCompanyAdminPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 hover:text-cyan-200 font-bold"
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Company Admin Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openSuperAdminPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-500/40 bg-indigo-950/40 text-indigo-300 hover:text-indigo-200 font-bold"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Super Admin Portal &rarr;</span>
              </button>
              <button
                type="button"
                onClick={openFounderPortal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-500/40 bg-amber-950/30 text-amber-300 hover:text-amber-200 font-bold"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Private Founder Portal &rarr;</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
