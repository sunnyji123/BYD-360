import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { initializeDatabase, sqlite, getSystemSetting, generateTotpSecret, generateNumericOtp, sha256, hashPassword, nowIso } from './server/db';

// ESM __dirname polyfill (required for static file serving in production)
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

import {
  attachAuthContext,
  requireCsrfProtection,
  createAuthAndOwnerRouter,
  requireFounder,
  requireSuperAdmin,
  requirePermission,
  requireCompanyAdmin,
  requireCompanyPermission,
  requireCountryManager,
  requireCountryPermission,
  requireBranchManager,
  requireBranchPermission,
} from './server/auth';
import { createOwnerDashboardRouter } from './server/ownerDashboard';
import { createVerificationSecurityRouter, createAdminVerificationRouter } from './server/verificationSecurity';
import { createAiRouter } from './server/ai';
import { createDomainRouter } from './server/domain';
import { createSuperAdminRouter } from './server/superAdmin';
import { createSuperAdminEnterpriseRouter } from './server/superAdminEnterprise';
import { apiTelemetryMiddleware } from './server/telemetry';
import { createCompanyAdminRouter } from './server/companyAdmin';
import { createCountryManagerRouter } from './server/countryManager';
import { createBranchManagerRouter } from './server/branchManager';
import { createEmployeeRouter } from './server/employee';
import { createDealerRouter } from './server/dealer';
import { createAdminDealersRouter } from './server/adminDealers';
import { createCustomerRouter } from './server/customer';
import { createAdminCustomersRouter } from './server/adminCustomers';
import { createCompanyBranchManagementRouter } from './server/companyBranchManagement';
import { createEmployeeManagementRouter } from './server/employeeManagement';
import { createDealershipManagementRouter } from './server/dealershipManagement';

dotenv.config();

// Initialize persistent relational SQLite database
initializeDatabase();

// Auto-provision Founder & CEO Primary Owner account from environment variables
// This bypasses the First-Time Setup screen on fresh installations
// Uses UPSERT: updates existing founder if present, otherwise inserts new one
if (process.env.FOUNDER_INIT_EMAIL && process.env.FOUNDER_INIT_PASSWORD && process.env.FOUNDER_INIT_MOBILE) {
  const totpSecret = generateTotpSecret();
  const recoveryCodes = Array.from({ length: 6 }, () =>
    `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
  );
  const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
  const founderId = 'founder_intekhab_alam';
  const existingFounder = sqlite
    .prepare("SELECT id FROM founder_accounts LIMIT 1")
    .get() as any;

  const targetFounderId = existingFounder?.id || founderId;

  if (existingFounder) {
    // Update existing founder account with latest .env credentials
    sqlite
      .prepare(`
        UPDATE founder_accounts SET
          founder_name = 'Intekhab Alam',
          role = 'Founder & CEO',
          account_type = 'Primary Owner',
          access_level = 'Global Owner',
          email = ?,
          mobile = ?,
          password_hash = ?,
          two_factor_enabled = 0,
          two_factor_secret = '',
          recovery_codes_json = '',
          is_verified = 1
        WHERE id = ?
      `)
      .run(
        process.env.FOUNDER_INIT_EMAIL.toLowerCase(),
        process.env.FOUNDER_INIT_MOBILE,
        hashPassword(process.env.FOUNDER_INIT_PASSWORD),
        targetFounderId
      );
    console.log(`[FOUNDER] Primary Owner account UPDATED for Intekhab Alam (Founder & CEO)`);
  } else {
    // Insert new founder account
    sqlite
      .prepare(`
        INSERT INTO founder_accounts (
          id, founder_name, role, account_type, access_level, email, mobile,
          password_hash, two_factor_enabled, two_factor_secret, recovery_codes_json,
          is_verified, created_at
        ) VALUES (?, 'Intekhab Alam', 'Founder & CEO', 'Primary Owner', 'Global Owner', ?, ?, ?, 0, '', '', 1, ?)
      `)
      .run(
        founderId,
        process.env.FOUNDER_INIT_EMAIL.toLowerCase(),
        process.env.FOUNDER_INIT_MOBILE,
        hashPassword(process.env.FOUNDER_INIT_PASSWORD),
        nowIso()
      );
    console.log(`[FOUNDER] Primary Owner account auto-provisioned for Intekhab Alam (Founder & CEO)`);
  }

  // Generate a 6-digit share code for founder to share with others
  const shareCode = Math.floor(100000 + Math.random() * 900000).toString();
  console.log(`\n╔═════════════════════════════════════════════════════════╗`);
  console.log(`║  FOUNDER SHARE CODE — GIVE THIS TO OTHERS                ║`);
  console.log(`╠═════════════════════════════════════════════════════════╣`);
  console.log(`║  Share Code: ${shareCode.padEnd(38)}║`);
  console.log(`╚═════════════════════════════════════════════════════════╝\n`);

  // Seed Real BYD Company Data (from verified corporate profile — no fake data)
  const now = new Date().toISOString();

  // BYD Company Limited — Global HQ (China) — UPSERT real data
  sqlite.prepare(`
    INSERT INTO companies (id, name, country, city, official_email, phone, address, registration_details, authorized_rep, status, ai_enabled, ai_daily_limit, approved_by, approved_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      country = excluded.country,
      city = excluded.city,
      official_email = excluded.official_email,
      phone = excluded.phone,
      address = excluded.address,
      registration_details = excluded.registration_details,
      authorized_rep = excluded.authorized_rep,
      status = excluded.status,
      approved_by = excluded.approved_by,
      approved_at = excluded.approved_at
  `).run('comp_byd_global', 'BYD Company Limited', 'CN', 'Shenzhen', 'socialmediaglobal@byd.com', '+86-755-89888888', 'No. 3009, BYD Road, Pingshan District, Shenzhen, Guangdong 518118, China', 'Hong Kong: 01211.HK • Shenzhen: 002594.SZ • Founded: 1994', 'Wang Chuanfu — Founder & Chairman', 'Active', 1, 250, 'system_seed', now, now);
  console.log('[COMPANY] BYD Company Limited — Global HQ upserted');

  // BYD Pakistan — Mega Motor Company (Private) Limited — UPSERT real data
  sqlite.prepare(`
    INSERT INTO companies (id, name, country, city, official_email, phone, address, registration_details, authorized_rep, status, ai_enabled, ai_daily_limit, approved_by, approved_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      country = excluded.country,
      city = excluded.city,
      official_email = excluded.official_email,
      phone = excluded.phone,
      address = excluded.address,
      registration_details = excluded.registration_details,
      authorized_rep = excluded.authorized_rep,
      status = excluded.status,
      approved_by = excluded.approved_by,
      approved_at = excluded.approved_at
  `).run('comp_byd_pk', 'Mega Motor Company (Private) Limited', 'PK', 'Karachi', 'contact@byd-mega.com', '+92 111 111 293', '9th Floor, Ocean Tower, Block 9, Main Clifton Road, Karachi, Pakistan', 'PACRA Registered: 6 May 2024 • Sole Authorized Distributor — BYD Auto Industry Company Limited, China', 'Aly Khan — CEO & Chairman', 'Active', 1, 250, 'system_seed', now, now);
  console.log('[COMPANY] Mega Motor Company (Private) Limited — BYD Pakistan upserted');

  // Seed Real BYD Vehicles (Pakistan Portfolio — from official Pakistan website)
  const vehCount = sqlite.prepare('SELECT COUNT(*) as cnt FROM vehicles WHERE company_id = ?').get('comp_byd_pk') as { cnt: number };
  if (vehCount.cnt === 0) {
    const insVeh = sqlite.prepare(`
      INSERT INTO vehicles (id, company_id, dealership_id, vin, chassis_number, model, variant, color, year, license_plate, owner_id, owner_name, owner_phone, owner_city, registration_date, odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc, battery_warranty_years, vehicle_warranty_years, warranty_expiry_date, last_service_date, next_service_due_km, status, dealership_purchased, sale_price_pkr, sold_at, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const pkVehicles = [
      { id: 'veh_pk_01', dlr: 'dlr_khi_clifton', model: 'BYD ATTO 3', variant: 'Electric SUV', color: 'Surf Blue', year: 2026, plate: 'KHI-EV-001', price: 8990000, battery: 60.48 },
      { id: 'veh_pk_02', dlr: 'dlr_khi_clifton', model: 'BYD ATTO 2', variant: 'Electric SUV', color: 'Atlantis Grey', year: 2026, plate: 'KHI-EV-002', price: 7490000, battery: 45.1 },
      { id: 'veh_pk_03', dlr: 'dlr_lhr_gulberg', model: 'BYD SEAL', variant: 'Electric Sedan', color: 'Shark Grey', year: 2026, plate: 'LHR-EV-001', price: 16990000, battery: 82.5 },
      { id: 'veh_pk_04', dlr: 'dlr_isb_bluearea', model: 'BYD SEALION 6', variant: 'Plug-in Hybrid SUV', color: 'Harbour Blue', year: 2026, plate: 'ISB-EV-001', price: 12490000, battery: 18.3 },
      { id: 'veh_pk_05', dlr: 'dlr_isb_bluearea', model: 'BYD SEALION 7', variant: 'Electric SUV', color: 'Aurora White', year: 2026, plate: 'ISB-EV-002', price: 18750000, battery: 82.5 },
      { id: 'veh_pk_06', dlr: 'dlr_khi_clifton', model: 'BYD SHARK 6', variant: 'Plug-in Hybrid Pickup', color: 'Ski Grey', year: 2026, plate: 'KHI-EV-003', price: 15250000, battery: 18.3 },
    ];

    for (const v of pkVehicles) {
      insVeh.run(
        v.id, 'comp_byd_pk', v.dlr,
        'BYD-PK-2026-' + String(100000 + parseInt(v.id.slice(-2))).padStart(6, '0'),
        'CH-PK-' + String(100000 + parseInt(v.id.slice(-2))).padStart(6, '0'),
        v.model, v.variant, v.color, v.year, v.plate,
        null, 'Mega Motor Fleet Inventory', '+92 111 111 293', v.plate.includes('KHI') ? 'Karachi' : v.plate.includes('LHR') ? 'Lahore' : 'Islamabad',
        now, 0, v.battery, 98.5, 85, 8, 6,
        new Date(v.year + 8, 0, 1).toISOString().split('T')[0], now, 10000,
        'Active', 'Mega Motor Authorized 3S Centre', v.price, null, now
      );
    }
    console.log(`[VEHICLES] ${pkVehicles.length} real BYD Pakistan vehicles seeded`);
  }
}

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.set('trust proxy', true);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Attach real API telemetry, verified session auth context & enforce CSRF origin checks on cookie mutations
app.use('/api', apiTelemetryMiddleware);
app.use('/api', attachAuthContext);
app.use('/api', requireCsrfProtection);

// Mount real authentication, Founder/Owner portal, Super Admin portal, Company Admin portal, Country Manager portal, Branch Manager portal, Employee portal, Dealer portal, Customer portal, Verification & Account Security, BYD AI, and domain APIs
app.use('/api', createAuthAndOwnerRouter());
app.use('/api/owner', createOwnerDashboardRouter());
app.use('/api/verification', createVerificationSecurityRouter());
app.use('/api/admin/verifications', createAdminVerificationRouter());
app.use('/api/owner/dealers', createAdminDealersRouter({ scope: 'founder', middlewares: [requireFounder] }));
app.use('/api/owner/customer-governance', createAdminCustomersRouter({ scope: 'founder', middlewares: [requireFounder] }));
app.use('/api/super-admin', createSuperAdminRouter());
app.use('/api/super-admin', createSuperAdminEnterpriseRouter());
app.use('/api/super-admin/dealers', createAdminDealersRouter({ scope: 'super_admin', middlewares: [requireSuperAdmin, requirePermission('dealers.manage')] }));
app.use('/api/super-admin/customer-governance', createAdminCustomersRouter({ scope: 'super_admin', middlewares: [requireSuperAdmin, requirePermission('customers.manage')] }));
app.use('/api/company-admin', createCompanyAdminRouter());
app.use('/api/company-admin/dealers', createAdminDealersRouter({ scope: 'company_admin', middlewares: [requireCompanyAdmin, requireCompanyPermission('dealers.manage')] }));
app.use('/api/company-admin/customer-governance', createAdminCustomersRouter({ scope: 'company_admin', middlewares: [requireCompanyAdmin, requireCompanyPermission('customers.manage')] }));
app.use('/api/country-manager', createCountryManagerRouter());
app.use('/api/country-manager/dealers', createAdminDealersRouter({ scope: 'country_manager', middlewares: [requireCountryManager, requireCountryPermission('dealers.manage')] }));
app.use('/api/country-manager/customer-governance', createAdminCustomersRouter({ scope: 'country_manager', middlewares: [requireCountryManager, requireCountryPermission('customers.view')] }));
app.use('/api/branch-manager', createBranchManagerRouter());
app.use('/api/branch-manager/dealers', createAdminDealersRouter({ scope: 'branch_manager', middlewares: [requireBranchManager, requireBranchPermission('dealers.manage')] }));
app.use('/api/branch-manager/customer-governance', createAdminCustomersRouter({ scope: 'branch_manager', middlewares: [requireBranchManager, requireBranchPermission('customers.manage')] }));
app.use('/api/employee', createEmployeeRouter());
app.use('/api/dealer', createDealerRouter());
app.use('/api/customer', createCustomerRouter());
app.use('/api', createAiRouter());
app.use('/api', createDomainRouter());
app.use('/api/org-management', createCompanyBranchManagementRouter());
app.use('/api/employee-management', createEmployeeManagementRouter());
app.use('/api/dealership-management', createDealershipManagementRouter());

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  const aiConfig = getSystemSetting('ai_config', { defaultModel: 'gemini-4-hydrogen', globalEnabled: true });
  const founderCount = (sqlite.prepare('SELECT COUNT(*) as c FROM founder_accounts').get() as any).c;
  const saCount = (sqlite.prepare('SELECT COUNT(*) as c FROM super_admin_accounts').get() as any).c;
  const caCount = (sqlite.prepare('SELECT COUNT(*) as c FROM company_admin_accounts').get() as any).c;
  const cmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM country_manager_accounts').get() as any).c;
  const bmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branch_manager_accounts').get() as any).c;
  const empCount = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c;
  const dealersCount = (sqlite.prepare("SELECT COUNT(*) as c FROM dealer_accounts WHERE status = 'Active' AND verification_status = 'Verified'").get() as any).c;
  const customersCount = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_accounts WHERE status = 'Active'").get() as any).c;
  const companiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c;

  res.json({
    status: 'online',
    platform: 'BYD PAKISTAN 360 Enterprise Automotive Platform',
    founder: (sqlite.prepare("SELECT founder_name FROM founder_accounts LIMIT 1").get() as any)?.founder_name || 'Not Provisioned',
    version: '2.0.0-ENTERPRISE-DB',
    timestamp: new Date().toISOString(),
    aiEngine: aiConfig.defaultModel || 'gemini-4-hydrogen',
    aiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
    databaseEngine: 'sqlite-persistent-wal',
    founderProvisioned: founderCount > 0,
    superAdminProvisioned: saCount > 0,
    companyAdminProvisioned: caCount > 0,
    countryManagerProvisioned: cmCount > 0,
    branchManagerProvisioned: bmCount > 0,
    employeePortalProvisioned: empCount > 0,
    employeesCount: empCount,
    dealerPortalProvisioned: dealersCount > 0,
    dealersCount,
    customerPortalProvisioned: customersCount > 0,
    customersCount,
    companiesRegistered: companiesCount,
    securityVerificationProvisioned: true,
  });
});

// Setup Vite middleware or static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    app.use('*', async (req: Request, res: Response, next) => {
      const url = req.originalUrl;
      try {
        const templatePath = path.resolve(__dirname, 'index.html');
        let template = await fs.promises.readFile(templatePath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BYD Pakistan 360 Enterprise Server running on http://localhost:${PORT}`);
  });
}

startServer();
