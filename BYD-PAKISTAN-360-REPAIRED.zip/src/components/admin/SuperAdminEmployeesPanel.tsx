import React, { useState, useEffect, useCallback } from 'react';
import {
  Briefcase,
  Search,
  Plus,
  RefreshCw,
  Eye,
  Edit3,
  CheckCircle2,
  XCircle,
  Clock,
  Globe,
  Shield,
  Calendar,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  companies: any[];
  onNotify: (msg: string) => void;
}

const EMPLOYEE_PERMISSIONS_POOL = [
  'tasks.view',
  'tasks.update',
  'vehicles.view',
  'vehicles.manage',
  'service.manage',
  'bookings.view',
  'bookings.manage',
  'customers.view',
  'reports.view',
];

export const SuperAdminEmployeesPanel: React.FC<Props> = ({ companies, onNotify }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [search, setSearch] = useState('');
  const [countryFilter, setCountryFilter] = useState('ALL');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const [showAddForm, setShowAddForm] = useState(false);
  const [newEmp, setNewEmp] = useState({
    fullName: '',
    email: '',
    mobile: '+92 ',
    password: '',
    companyId: 'comp_byd_pk',
    branchId: '',
    countryId: 'PK',
    department: 'Operations',
    jobPosition: 'EV Operations Specialist',
    permissions: ['tasks.view', 'vehicles.view'],
  });

  const [editingEmp, setEditingEmp] = useState<any>(null);
  const [detailData, setDetailData] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const loadEmployees = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminEmployees({
        search: search || undefined,
        country: countryFilter,
        department: deptFilter,
        status: statusFilter,
      });
      setData(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to load employee records.');
    } finally {
      setLoading(false);
    }
  }, [search, countryFilter, deptFilter, statusFilter]);

  useEffect(() => {
    loadEmployees();
  }, [loadEmployees]);

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.createSuperAdminEmployee({
        ...newEmp,
        branchId: newEmp.branchId || undefined,
      });
      onNotify(`Employee provisioned with code ${res.employeeCode}.`);
      setShowAddForm(false);
      setNewEmp({
        fullName: '',
        email: '',
        mobile: '+92 ',
        password: '',
        companyId: 'comp_byd_pk',
        branchId: '',
        countryId: 'PK',
        department: 'Operations',
        jobPosition: 'EV Operations Specialist',
        permissions: ['tasks.view', 'vehicles.view'],
      });
      await loadEmployees();
    } catch (err: any) {
      setError(err?.message || 'Unable to create employee.');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmp) return;
    setError('');
    try {
      await api.updateSuperAdminEmployee(editingEmp.id, {
        fullName: editingEmp.full_name,
        mobile: editingEmp.mobile,
        department: editingEmp.department,
        jobPosition: editingEmp.job_position,
        branchId: editingEmp.branch_id || null,
        countryId: editingEmp.country_id,
        status: editingEmp.status,
        permissions: editingEmp.permissions,
      });
      onNotify(`Employee ${editingEmp.employee_code} updated cleanly.`);
      setEditingEmp(null);
      await loadEmployees();
    } catch (err: any) {
      setError(err?.message || 'Failed to update employee profile.');
    }
  };

  const inspectEmployee = async (id: string) => {
    setDetailLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminEmployeeDetail(id);
      setDetailData(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to load employee profile details.');
    } finally {
      setDetailLoading(false);
    }
  };

  const toggleEditPerm = (perm: string) => {
    if (!editingEmp) return;
    const current: string[] = Array.isArray(editingEmp.permissions) ? editingEmp.permissions : [];
    const next = current.includes(perm) ? current.filter((p) => p !== perm) : [...current, perm];
    setEditingEmp({ ...editingEmp, permissions: next });
  };

  const employees = data?.employees || [];
  const summary = data?.summary || {};
  const countryBreakdown = data?.countryBreakdown || [];
  const branches = data?.branches || [];
  const countries = data?.countries || [];
  const departments = data?.departments || ['Executive', 'Sales & Retail', 'Aftersales & Workshop', 'Finance', 'Operations'];

  return (
    <div className="space-y-6 text-xs">
      {/* Header & Summary */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Enterprise Human Capital &amp; Operations
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              Employee Management, Departments, Attendance &amp; Country Records
            </h3>
            <p className="text-slate-400 mt-0.5">
              Manage staff profiles, departments, job titles, branch assignments, permissions, and attendance records across active markets.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={loadEmployees}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Employee</span>
            </button>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Total Employees', val: summary.totalEmployees ?? 0, cls: 'text-white' },
            { label: 'Active Staff', val: summary.activeEmployees ?? 0, cls: 'text-emerald-400' },
            { label: 'On Leave', val: summary.onLeaveEmployees ?? 0, cls: 'text-amber-300' },
            { label: 'Suspended', val: summary.suspendedEmployees ?? 0, cls: 'text-rose-400' },
          ].map((k) => (
            <div key={k.label} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">{k.label}</div>
              <div className={`text-xl font-black font-mono tabular-nums mt-1 ${k.cls}`}>{k.val}</div>
            </div>
          ))}
        </div>

        {/* Country-wise Employee Breakdown */}
        {countryBreakdown.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {countryBreakdown.map((c: any) => (
              <div key={c.countryId} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Globe className="w-4 h-4 text-cyan-400 shrink-0" />
                  <div>
                    <div className="font-bold text-white">{c.countryName} ({c.countryId})</div>
                    <div className="text-[11px] text-slate-400">
                      Active: <span className="font-mono text-emerald-400">{c.activeEmployees}</span> / {c.totalEmployees} · Avg Perf{' '}
                      <span className="font-mono text-cyan-300">{c.avgPerformanceScore}%</span>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setCountryFilter(countryFilter === c.countryId ? 'ALL' : c.countryId)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border ${
                    countryFilter === c.countryId
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                      : 'bg-slate-900 text-slate-300 border-slate-700'
                  }`}
                >
                  {countryFilter === c.countryId ? 'Filtered' : 'Filter'}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Create Employee Form */}
        {showAddForm && (
          <form onSubmit={handleCreateEmployee} className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/40 space-y-4">
            <h4 className="text-sm font-bold text-white">Provision Authorized Employee Account</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                required
                placeholder="Full Name"
                value={newEmp.fullName}
                onChange={(e) => setNewEmp({ ...newEmp, fullName: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                required
                type="email"
                placeholder="Work Email Address"
                value={newEmp.email}
                onChange={(e) => setNewEmp({ ...newEmp, email: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                required
                placeholder="Mobile (+92...)"
                value={newEmp.mobile}
                onChange={(e) => setNewEmp({ ...newEmp, mobile: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                required
                type="password"
                placeholder="Strong Password (12+ chars)"
                value={newEmp.password}
                onChange={(e) => setNewEmp({ ...newEmp, password: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
              <select
                value={newEmp.companyId}
                onChange={(e) => setNewEmp({ ...newEmp, companyId: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              >
                {(companies.length ? companies : [{ id: 'comp_byd_pk', name: 'Mega Motor Company' }]).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <select
                value={newEmp.countryId}
                onChange={(e) => setNewEmp({ ...newEmp, countryId: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              >
                {(countries.length ? countries : [{ id: 'PK', name: 'Pakistan' }, { id: 'AE', name: 'UAE' }]).map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.id})</option>
                ))}
              </select>
              <select
                value={newEmp.branchId}
                onChange={(e) => setNewEmp({ ...newEmp, branchId: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="">Head Office / Unassigned Branch</option>
                {branches.map((b: any) => (
                  <option key={b.id} value={b.id}>{b.name} ({b.city})</option>
                ))}
              </select>
              <input
                required
                placeholder="Department"
                value={newEmp.department}
                onChange={(e) => setNewEmp({ ...newEmp, department: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                required
                placeholder="Job Position"
                value={newEmp.jobPosition}
                onChange={(e) => setNewEmp({ ...newEmp, jobPosition: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold">
                Create Employee Account
              </button>
            </div>
          </form>
        )}

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, email..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
          <select
            value={countryFilter}
            onChange={(e) => setCountryFilter(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          >
            <option value="ALL">All Countries</option>
            {countries.map((c: any) => (
              <option key={c.id} value={c.id}>{c.name} ({c.id})</option>
            ))}
          </select>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          >
            <option value="ALL">All Departments</option>
            {departments.map((d: string) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="Active">Active</option>
            <option value="On Leave">On Leave</option>
            <option value="Suspended">Suspended</option>
          </select>
        </div>

        {/* Employee Roster Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Dept · Position</th>
                <th className="py-3 px-4">Company · Branch · Country</th>
                <th className="py-3 px-4">Attendance · Perf</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {employees.map((emp: any) => (
                <tr key={emp.id} className="hover:bg-slate-900/60">
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{emp.full_name}</div>
                    <div className="font-mono text-[11px] text-cyan-300">
                      {emp.employee_code} · {emp.email}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-white">{emp.department}</div>
                    <div className="text-slate-400">{emp.job_position}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    <div>{emp.company_name || emp.company_id}</div>
                    <div className="text-[11px] text-slate-500">
                      {emp.branch_name || 'HQ'} · {emp.country_name}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums">
                    <div className="text-emerald-400">
                      {emp.attendancePresentDays}/{emp.attendanceDaysRecorded} days
                    </div>
                    <div className="text-[11px] text-cyan-300">Perf: {emp.performance_score}%</div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        emp.status === 'Active'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : emp.status === 'On Leave'
                            ? 'bg-amber-950 text-amber-300 border-amber-800'
                            : 'bg-rose-950 text-rose-300 border-rose-800'
                      }`}
                    >
                      {emp.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => inspectEmployee(emp.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 font-semibold inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Profile</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingEmp({ ...emp })}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 font-semibold inline-flex items-center gap-1"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {employees.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-500">
                    No Data Available for the selected employee filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Employee Drawer/Card */}
      {editingEmp && (
        <form onSubmit={handleSaveEdit} className="rounded-2xl bg-slate-900 border border-cyan-500/40 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="text-[11px] font-mono text-cyan-400">{editingEmp.employee_code}</div>
              <h4 className="text-sm font-bold text-white">Edit Employee Profile, Department &amp; Permissions</h4>
            </div>
            <button type="button" onClick={() => setEditingEmp(null)} className="text-slate-400 hover:text-white">
              Close
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <label className="space-y-1">
              <span className="text-slate-400 block">Full Name</span>
              <input
                value={editingEmp.full_name}
                onChange={(e) => setEditingEmp({ ...editingEmp, full_name: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-400 block">Department</span>
              <input
                value={editingEmp.department}
                onChange={(e) => setEditingEmp({ ...editingEmp, department: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-400 block">Job Position</span>
              <input
                value={editingEmp.job_position}
                onChange={(e) => setEditingEmp({ ...editingEmp, job_position: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-400 block">Assigned Branch</span>
              <select
                value={editingEmp.branch_id || ''}
                onChange={(e) => setEditingEmp({ ...editingEmp, branch_id: e.target.value || null })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="">Head Office</option>
                {branches.map((b: any) => (
                  <option key={b.id} value={b.id}>{b.name} ({b.city})</option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-slate-400 block">Country</span>
              <select
                value={editingEmp.country_id || 'PK'}
                onChange={(e) => setEditingEmp({ ...editingEmp, country_id: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                {countries.map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name} ({c.id})</option>
                ))}
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-slate-400 block">Account Status</span>
              <select
                value={editingEmp.status}
                onChange={(e) => setEditingEmp({ ...editingEmp, status: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="Active">Active</option>
                <option value="On Leave">On Leave</option>
                <option value="Suspended">Suspended (Revoke Sessions)</option>
              </select>
            </label>
          </div>
          <div className="space-y-2">
            <span className="text-slate-400 font-semibold block">Assigned Employee Operational Permissions</span>
            <div className="flex flex-wrap gap-2">
              {EMPLOYEE_PERMISSIONS_POOL.map((perm) => {
                const active = (editingEmp.permissions || []).includes(perm);
                return (
                  <button
                    key={perm}
                    type="button"
                    onClick={() => toggleEditPerm(perm)}
                    className={`px-2.5 py-1 rounded-lg font-mono text-[11px] border ${
                      active
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    {perm}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setEditingEmp(null)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold">
              Cancel
            </button>
            <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold">
              Save Employee Updates
            </button>
          </div>
        </form>
      )}

      {/* Employee Profile, Attendance & Activity Inspector */}
      {detailData?.employee && (
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="text-[11px] font-mono text-cyan-400">
                {detailData.employee.employee_code} · Joined {detailData.employee.joined_at} · {detailData.employee.country_name}
              </div>
              <h4 className="text-base font-bold text-white">
                {detailData.employee.full_name} — {detailData.employee.job_position} ({detailData.employee.department})
              </h4>
            </div>
            <button
              type="button"
              onClick={() => setDetailData(null)}
              className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-300 hover:text-white"
            >
              Close Inspector
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Attendance & Leave Balance */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-cyan-400" />
                  <span>Attendance Records ({detailData.employee.attendance?.length || 0})</span>
                </span>
                <span className="font-mono text-[11px] text-slate-400">
                  Leave Balance: Annual {detailData.employee.leaveBalance?.annual ?? 0}d · Sick {detailData.employee.leaveBalance?.sick ?? 0}d
                </span>
              </div>
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {(detailData.employee.attendance || []).map((a: any, idx: number) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-slate-300">{a.date}</span>
                    <span className="text-slate-400">In {a.checkIn || '—'} · Out {a.checkOut || '—'}</span>
                    <span className={`font-bold ${a.status === 'Present' ? 'text-emerald-400' : 'text-amber-300'}`}>
                      {a.status}
                    </span>
                  </div>
                ))}
                {(!detailData.employee.attendance || detailData.employee.attendance.length === 0) && (
                  <div className="p-4 text-center text-slate-500 bg-slate-950 rounded-lg border border-slate-800">
                    No attendance logs recorded yet.
                  </div>
                )}
              </div>
            </div>

            {/* Employee Activity Log */}
            <div className="space-y-3">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Employee Activity History ({detailData.activityLogs?.length || 0})</span>
              </span>
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {(detailData.activityLogs || []).map((l: any) => (
                  <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="flex justify-between font-mono text-[11px]">
                      <span className="text-cyan-300 font-bold">{l.action}</span>
                      <span className="text-slate-500">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
                    </div>
                    <div className="text-slate-300 mt-0.5">{l.details || l.module}</div>
                  </div>
                ))}
                {(!detailData.activityLogs || detailData.activityLogs.length === 0) && (
                  <div className="p-4 text-center text-slate-500 bg-slate-950 rounded-lg border border-slate-800">
                    No employee activity entries recorded yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {detailLoading && <div className="text-center text-slate-400 py-2">Loading employee inspector...</div>}
    </div>
  );
};
