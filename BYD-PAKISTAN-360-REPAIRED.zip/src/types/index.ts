export type UserRole =
  | 'Founder / Owner'
  | 'Global Super Admin'
  | 'Super Admin'
  | 'Company Admin'
  | 'Country Manager'
  | 'Branch Manager'
  | 'Head Office Staff'
  | 'Dealership Manager'
  | 'Dealership Staff'
  | 'Global Management'
  | 'Country Administrator'
  | 'Regional Manager'
  | 'Dealer Owner'
  | 'Dealer Manager'
  | 'Sales Manager'
  | 'Sales Executive'
  | 'Service Manager'
  | 'Service Advisor'
  | 'Workshop Technician'
  | 'Technical Support'
  | 'Warranty Manager'
  | 'Inventory Manager'
  | 'Finance Manager'
  | 'Customer Support Agent'
  | 'Customer'
  | 'Auditor / Read-only User'
  | 'Company Management'
  | 'Technician';

export type Language = 'en' | 'ur' | 'ar';

export type CountryCode = 'PK' | 'AE' | 'SA' | 'GB' | 'DE' | 'GLOBAL';
export type CurrencyCode = 'PKR' | 'AED' | 'SAR' | 'USD' | 'GBP' | 'EUR';

export interface CountryConfig {
  code: CountryCode;
  name: string;
  legalEntity: string;
  defaultCurrency: CurrencyCode;
  taxRatePercentage: number;
  timeZone: string;
  flagEmoji: string;
  cities: string[];
}

export interface UserProfile {
  id: string;
  companyId?: string | null;
  branchId?: string | null;
  branchName?: string | null;
  name: string;
  fullName?: string;
  email: string;
  phone: string;
  role: UserRole;
  subjectType?: 'founder' | 'super_admin' | 'company_admin' | 'country_manager' | 'branch_manager' | 'employee' | 'dealer' | 'customer' | 'user';
  managerCode?: string | null;
  employeeId?: string | null;
  employeeCode?: string | null;
  department?: string | null;
  reportingManagerName?: string | null;
  dealerId?: string | null;
  dealerCode?: string | null;
  dealerCategory?: string | null;
  customerId?: string | null;
  customerCode?: string | null;
  mobileVerified?: boolean;
  address?: string;
  verificationStatus?: string | null;
  designation?: string;
  accountType?: string;
  accessLevel?: string;
  permissions?: string[];
  dealershipId?: string | null;
  city: string;
  country?: CountryCode;
  avatarUrl?: string;
  status?: 'Active' | 'Suspended' | 'Pending Verification';
  verifiedIdentity?: boolean;
  emailVerified?: boolean;
  provisionedAt?: string;
  provisionedBy?: string;
}

export type OwnershipTransferStatus =
  | 'Transfer Requested'
  | 'Documents Pending'
  | 'Under Verification'
  | 'Approved'
  | 'Rejected'
  | 'Completed';

export interface OwnershipTransferRequest {
  id: string;
  transferRef: string;
  vin: string;
  vehicleModel: string;
  licensePlate: string;
  dealershipId: string;
  dealershipName: string;
  previousOwnerId: string;
  previousOwnerName: string;
  previousOwnerPhone: string;
  previousOwnerCnicOrId: string;
  newOwnerName: string;
  newOwnerEmail: string;
  newOwnerPhone: string;
  newOwnerCnicOrId: string;
  newOwnerCity: string;
  transferReason: string;
  saleAmountPkr: number;
  odometerAtTransferKm: number;
  documentsSubmitted: Array<{
    docType: 'Invoice / Sale Deed' | 'NOC from Previous Owner' | 'Govt Registration Book' | 'Blade Battery Inspection Certificate';
    documentName: string;
    verified: boolean;
  }>;
  status: OwnershipTransferStatus;
  requestedAt: string;
  requestedBy: string;
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  notes?: string;
}

export type VehicleModelType = 'BYD Seal' | 'BYD Atto 3' | 'BYD Sealion 6' | 'BYD Shark 6' | 'BYD Tang' | 'BYD Han' | 'BYD Dolphin';

export interface Vehicle {
  id: string;
  vin: string;
  chassisNumber: string;
  model: VehicleModelType;
  variant: string;
  color: string;
  year: number;
  licensePlate: string;
  ownerId: string;
  ownerName: string;
  ownerPhone: string;
  ownerCity: string;
  registrationDate: string;
  odometerKm: number;
  batteryCapacityKwh: number;
  batteryHealthSoH: number; // e.g. 98.4
  batteryHealthSoC: number; // e.g. 82
  batteryWarrantyYears: number; // 8 years
  vehicleWarrantyYears: number; // 6 years
  warrantyExpiryDate: string;
  lastServiceDate: string;
  nextServiceDueKm: number;
  status: 'Active' | 'In Service' | 'Inspection Required' | 'Pending Delivery';
  dealershipPurchased: string;
  imageUrl: string;
}

export type ServiceStatus =
  | 'Pending Approval'
  | 'Confirmed'
  | 'Vehicle Received'
  | 'In Progress'
  | 'Quality Check'
  | 'Ready for Pickup'
  | 'Completed'
  | 'Cancelled';

export type ServiceType =
  | 'Routine Maintenance (10,000 km)'
  | 'Blade Battery Health Diagnostic'
  | 'High-Voltage Electrical Inspection'
  | 'Brake & Suspension Calibration'
  | 'Software / OTA Firmware Update'
  | 'Air Conditioning & Coolant Service'
  | 'Accident Body Repair & Paint';

export interface ServiceJob {
  id: string;
  ticketNumber: string;
  vehicleId: string;
  vin: string;
  model: string;
  licensePlate: string;
  customerName: string;
  customerPhone: string;
  dealershipId: string;
  dealershipName: string;
  serviceType: ServiceType;
  scheduledDate: string;
  scheduledTime: string;
  status: ServiceStatus;
  technicianAssigned?: string;
  estimatedCostPkr: number;
  actualCostPkr?: number;
  customerNotes?: string;
  technicianNotes?: string;
  checklist: {
    hvLockChecked: boolean;
    bladeBatteryScanned: boolean;
    coolantLevelInspected: boolean;
    brakePadThicknessMm: number;
    tirePressurePsi: number;
    firmwareVersion: string;
    roadTestCompleted: boolean;
  };
  partsUsed: Array<{
    partId: string;
    partName: string;
    quantity: number;
    unitPricePkr: number;
  }>;
  createdAt: string;
  completedAt?: string;
}

export interface BatteryInspectionRecord {
  id: string;
  vehicleId: string;
  vin: string;
  model: string;
  inspectionDate: string;
  inspectorName: string;
  dealershipName: string;
  sohPercentage: number; // State of Health
  socPercentage: number; // State of Charge
  cellVoltageMin: number; // e.g. 3.28V
  cellVoltageMax: number; // e.g. 3.29V
  cellVoltageDelta: number; // e.g. 0.012V
  packTemperatureCelsius: number; // e.g. 29.4°C
  internalResistanceMilliOhm: number; // e.g. 0.42 mOhm
  cycleCount: number; // e.g. 84
  insulationResistanceMOhm: number; // e.g. 500 MOhm
  overallRating: 'Optimal' | 'Good' | 'Attention Advised' | 'Degraded';
  firmwareBmsVersion: string;
  notes: string;
  aiDiagnosticSummary?: string;
  isDemo: boolean;
}

export type ChargerPlugType = 'GB/T DC' | 'CCS2 Combo DC' | 'Type 2 AC (7kW - 22kW)';

export interface ChargingStation {
  id: string;
  name: string;
  operator: string;
  city: 'Karachi' | 'Lahore' | 'Islamabad' | 'Rawalpindi' | 'Faisalabad' | 'Multan' | 'Peshawar' | 'Motorways';
  address: string;
  locationDetails: string;
  latitude: number;
  longitude: number;
  powerKw: number; // 60, 120, 180, 240
  plugTypes: ChargerPlugType[];
  totalPlugs: number;
  availablePlugs: number;
  pricePerKwhPkr: number;
  status: 'Online & Available' | 'Busy' | 'Maintenance' | 'Offline';
  operatingHours: string;
  amenities: string[];
  contactNumber: string;
}

export type WarrantyClaimStatus =
  | 'Submitted'
  | 'Technical Review'
  | 'Parts Inspection'
  | 'Approved'
  | 'Rejected'
  | 'Reimbursed & Closed';

export interface WarrantyClaim {
  id: string;
  claimNumber: string;
  vin: string;
  vehicleModel: string;
  customerName: string;
  customerPhone: string;
  dealershipName: string;
  componentCategory: 'Blade Battery Pack' | 'Drive Motor / Inverter' | 'BMS Controller' | 'On-Board Charger' | 'Chassis / Airbag' | 'Infotainment System';
  issueDescription: string;
  faultCode?: string;
  submissionDate: string;
  status: WarrantyClaimStatus;
  claimAmountPkr: number;
  approvedAmountPkr?: number;
  reviewNotes?: string;
  attachments: string[];
}

export interface Dealership {
  id: string;
  name: string;
  code: string;
  city: string;
  address: string;
  managerName: string;
  phone: string;
  email: string;
  facilityType: '3S Flagship Centre' | '2S Service Facility' | 'Retail Experience Studio';
  activeTechs: number;
  serviceBays: number;
  monthlyTargetUnits: number;
  achievedUnits: number;
  monthlyRevenuePkr: number;
  rating: number;
}

export interface SalesLead {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  city: string;
  interestedModel: VehicleModelType;
  budgetPkr: number;
  dealershipId: string;
  source: 'Online Inquiry' | 'Walk-in' | 'Social Media' | 'EV Expo 2026';
  stage: 'New Inquiry' | 'Contacted' | 'Test Drive Scheduled' | 'Deposit Paid' | 'Delivered' | 'Lost';
  testDriveDate?: string;
  assignedSalesExec: string;
  notes: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  category: 'Service' | 'Warranty' | 'Delivery' | 'Security' | 'Announcement';
  read: boolean;
  actionUrl?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  role: string;
  action: string;
  module: string;
  targetId: string;
  ipAddress: string;
  status: 'SUCCESS' | 'WARNING' | 'ALERT';
}

export interface SparePart {
  id: string;
  sku: string;
  name: string;
  category: 'Battery & High Voltage' | 'Powertrain' | 'Braking & Tires' | 'Thermal Management' | 'Body & Glass';
  compatibleModels: string[];
  stockQuantity: number;
  reorderLevel: number;
  unitCostPkr: number;
  locationBin: string;
  warehouseId?: string;
}

export interface Warehouse {
  id: string;
  name: string;
  code: string;
  country: CountryCode;
  city: string;
  address: string;
  type: 'Global Central Hub' | 'Regional Distribution Depot' | 'Dealer Transit Store';
  capacityUnits: number;
  utilizedPercentage: number;
  managerName: string;
  contactEmail: string;
  contactPhone: string;
}

export interface InventoryTransaction {
  id: string;
  sku: string;
  partName: string;
  sourceLocation: string;
  destinationLocation: string;
  quantity: number;
  type: 'RECEIVE_FACTORY' | 'TRANSFER_INTER_WAREHOUSE' | 'DISPATCH_WORKSHOP' | 'RETURN_STOCK' | 'ADJUSTMENT';
  status: 'Completed' | 'In Transit' | 'Pending Approval';
  initiatedBy: string;
  timestamp: string;
  referencePo: string;
}

export interface GlobalInvoice {
  id: string;
  invoiceNumber: string;
  customerName: string;
  country: CountryCode;
  currency: CurrencyCode;
  dealershipName: string;
  itemCategory: 'Vehicle Purchase' | 'Service & Maintenance' | 'Spare Parts' | 'Charging Subscription' | 'Extended Warranty';
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  status: 'Paid' | 'Pending Payment' | 'Refunded' | 'Overdue';
  paymentGateway: 'Mastercard / Visa Gateway' | '1LINK PayPak' | 'SAMA SARIE' | 'FAB UAE Direct' | 'Wire Transfer';
  transactionRef: string;
  issuedDate: string;
  dueDate: string;
}

// ============================================================================
// SALES & BOOKING MANAGEMENT TYPES (Phase 1)
// ============================================================================

export type BookingType = 'Test Drive' | 'Vehicle Reservation' | 'Service Appointment';

export type BookingStatus =
  | 'Pending Review'
  | 'Approved'
  | 'Rejected'
  | 'Cancelled'
  | 'Completed';

export type PaymentStatus =
  | 'Awaiting Payment Verification'
  | 'Deposit Verified'
  | 'Fully Paid'
  | 'Paid'
  | 'Refunded';

export type DeliveryStatus =
  | 'Awaiting Booking Approval'
  | 'In Allocation'
  | 'Pre-Delivery Inspection'
  | 'Ready for Delivery'
  | 'Delivered';

export type InstallmentStatus = 'Pending' | 'Paid' | 'Overdue' | 'Completed';

export type RefundStatus = 'Pending' | 'Approved' | 'Processed' | 'Rejected';

export interface Booking {
  id: string;
  bookingRef: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  dealerId?: string | null;
  dealershipName: string;
  inventoryId?: string | null;
  vehicleModel: string;
  variant: string;
  exteriorColor: string;
  interiorColor: string;
  quotedPricePkr: number;
  bookingDepositPkr: number;
  bookingType: BookingType;
  bookingStatus: BookingStatus;
  paymentStatus: PaymentStatus;
  deliveryStatus: DeliveryStatus;
  preferredDate: string;
  preferredTime: string;
  city: string;
  notes?: string;
  customerNotes?: string;
  adminNotes?: string | null;
  paymentInstructions?: string;
  reviewedBy?: string | null;
  reviewedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface SalesOrder {
  id: string;
  saleRef: string;
  bookingId?: string | null;
  customerId: string;
  customerName: string;
  customerPhone: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  dealerId?: string | null;
  dealershipName: string;
  inventoryId?: string | null;
  vin?: string | null;
  vehicleModel: string;
  saleAmountPkr: number;
  paidAmountPkr: number;
  paymentStatus: PaymentStatus;
  paymentProviderRef?: string | null;
  deliveryStatus: DeliveryStatus;
  deliveredAt?: string | null;
  receiptDocId?: string | null;
  verifiedBy?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  paymentRef: string;
  customerId: string;
  bookingId?: string | null;
  invoiceId?: string | null;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  currency: CurrencyCode;
  amountPkr: number;
  amountLocal: number;
  paymentMethod: string;
  gatewayName: string;
  transactionRef: string;
  paymentStatus: PaymentStatus;
  paymentDate: string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  notes?: string;
  createdAt: string;
}

export interface Installment {
  id: string;
  installmentRef: string;
  saleId?: string | null;
  customerId: string;
  customerName: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  dueDate: string;
  amountPkr: number;
  paidAmountPkr: number;
  status: InstallmentStatus;
  paymentDate?: string | null;
  transactionRef?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Refund {
  id: string;
  refundRef: string;
  saleId?: string | null;
  customerId: string;
  customerName: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  amountPkr: number;
  reason: string;
  status: RefundStatus;
  approvedBy?: string | null;
  approvedAt?: string | null;
  processedAt?: string | null;
  payoutReference?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SalesCommission {
  id: string;
  commissionRef: string;
  dealerId?: string | null;
  saleId?: string | null;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  saleAmountPkr: number;
  commissionRatePct: number;
  commissionAmountPkr: number;
  status: 'Pending' | 'Approved' | 'Paid';
  approvedBy?: string | null;
  approvedAt?: string | null;
  paidAt?: string | null;
  payoutReference?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DeliveryRecord {
  id: string;
  deliveryRef: string;
  saleId?: string | null;
  customerId: string;
  customerName: string;
  customerPhone: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  dealerId?: string | null;
  dealershipName: string;
  vin?: string | null;
  vehicleModel: string;
  deliveryDate: string;
  deliveryLocation: string;
  deliveredBy: string;
  deliveryStatus: DeliveryStatus;
  pdiCompleted: boolean;
  pdiNotes?: string | null;
  handoverNotes?: string | null;
  documentsHandedOver: string[];
  createdAt: string;
  updatedAt: string;
}

// ============================================================================
// FINANCE & ACCOUNTING TYPES (Phase 2)
// ============================================================================

export type FinanceTransactionType = 'INCOME' | 'EXPENSE';

export type FinanceCategory =
  | 'Vehicle Sales'
  | 'Service Revenue'
  | 'Spare Parts Revenue'
  | 'Warranty Revenue'
  | 'Charging Revenue'
  | 'Dealer Commission Payout'
  | 'Branch Expense'
  | 'Company Expense'
  | 'Employee Salary'
  | 'Marketing Expense'
  | 'Facility Expense'
  | 'Tax Payment'
  | 'Bank Charge'
  | 'Other';

export type PaymentMethod = 'Cash' | 'Bank Transfer' | '1LINK PayPak' | 'FAB UAE Direct' | 'Cheque' | 'Card';

export type TransactionStatus = 'Pending' | 'Verified' | 'Rejected' | 'Cleared';

export interface FinanceTransaction {
  id: string;
  transactionRef: string;
  type: FinanceTransactionType;
  category: FinanceCategory;
  amountPkr: number;
  amountLocal: number;
  currency: CurrencyCode;
  paymentMethod: PaymentMethod;
  gatewayName: string;
  transactionRefExternal: string;
  status: TransactionStatus;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  dealerId?: string | null;
  customerId?: string | null;
  relatedSaleId?: string | null;
  relatedInvoiceId?: string | null;
  description: string;
  recordedBy: string;
  recordedByRole: string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  transactionDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankTransaction {
  id: string;
  bankRef: string;
  bankName: string;
  accountNumberMasked: string;
  transactionType: 'DEBIT' | 'CREDIT';
  amountPkr: number;
  currency: CurrencyCode;
  referenceNumber: string;
  description: string;
  status: TransactionStatus;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  transactionDate: string;
  createdAt: string;
}

export interface TaxRecord {
  id: string;
  taxRef: string;
  taxType: 'Sales Tax' | 'Income Tax' | 'Withholding Tax' | 'Custom Duty' | 'Other';
  taxRate: number;
  taxableAmountPkr: number;
  taxAmountPkr: number;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  filingPeriod: string;
  filingDate?: string | null;
  status: 'Pending' | 'Filed' | 'Paid' | 'Overdue';
  filedBy?: string | null;
  filedAt?: string | null;
  referenceNumber?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DealerPayment {
  id: string;
  paymentRef: string;
  dealerId: string;
  dealerName: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  saleId?: string | null;
  commissionId?: string | null;
  amountPkr: number;
  paymentMethod: PaymentMethod;
  gatewayName: string;
  transactionRef: string;
  status: TransactionStatus;
  paymentDate: string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerPayment {
  id: string;
  paymentRef: string;
  customerId: string;
  customerName: string;
  companyId: string;
  countryId: CountryCode;
  branchId?: string | null;
  bookingId?: string | null;
  invoiceId?: string | null;
  amountPkr: number;
  currency: CurrencyCode;
  paymentMethod: PaymentMethod;
  gatewayName: string;
  transactionRef: string;
  status: TransactionStatus;
  paymentDate: string;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProfitLossSummary {
  period: string;
  totalIncomePkr: number;
  totalExpensePkr: number;
  netProfitPkr: number;
  profitMarginPercent: number;
  incomeByCategory: Array<{ category: string; amount: number }>;
  expenseByCategory: Array<{ category: string; amount: number }>;
  generatedAt: string;
}

export interface FinancialStatement {
  id: string;
  statementRef: string;
  statementType: 'Balance Sheet' | 'Income Statement' | 'Cash Flow';
  companyId: string;
  countryId: CountryCode;
  periodStart: string;
  periodEnd: string;
  totalAssetsPkr: number;
  totalLiabilitiesPkr: number;
  totalEquityPkr: number;
  totalRevenuePkr: number;
  totalExpensePkr: number;
  netProfitPkr: number;
  generatedBy: string;
  generatedAt: string;
  pdfUrl?: string | null;
}

export type MaintenanceReminderStatus = 'Pending' | 'Sent' | 'Acknowledged' | 'Overdue';

export interface MaintenanceReminder {
  id: string;
  reminderRef: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  vin: string;
  vehicleModel: string;
  reminderType: 'Oil Change' | 'Battery Check' | 'Tire Rotation' | 'Brake Service' | 'Software Update' | 'Annual Inspection';
  dueDate: string;
  status: MaintenanceReminderStatus;
  sentAt?: string | null;
  acknowledgedAt?: string | null;
  serviceCenterId?: string | null;
  serviceCenterName?: string | null;
  notes?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Technician {
  id: string;
  technicianRef: string;
  name: string;
  email: string;
  phone: string;
  employeeId: string;
  serviceCenterId: string;
  serviceCenterName: string;
  specialization: 'Battery' | 'Motor' | 'Electrical' | 'Body' | 'General' | 'Master';
  certificationLevel: 'Junior' | 'Intermediate' | 'Senior' | 'Master';
  isActive: boolean;
  totalJobsCompleted: number;
  currentWorkload: number;
  createdAt: string;
  updatedAt: string;
}

