# BYD GLOBAL MOBILITY & OPERATIONS PLATFORM — API SPECIFICATION

## Version: v1.0.0-ENTERPRISE
**Base URL:** `https://api.bydglobal.internal/v1`  
**Authentication:** `Authorization: Bearer <JWT_TOKEN>`  
**Headers Required:**
* `X-Country-Code`: `PK | AE | SA | GB | DE | GLOBAL`
* `X-Client-Platform`: `Web-SPA | Flutter-Android | Flutter-iOS`

---

### Core Endpoint Categories

#### 1. Vehicle & Telemetry API
* `GET /vehicles`: List registered vehicles for the authenticated user/dealer.
* `GET /vehicles/{vin}/telemetry`: Retrieve live SoH, SoC, odometer, and coolant temperatures.
* `POST /vehicles/{vin}/commands/climate`: Send signed challenge to pre-condition cabin temperature.
* `POST /vehicles/{vin}/commands/lock`: Remote vehicle lock/unlock execution.

#### 2. Aftersales & Workshop Service API
* `GET /service/job-cards`: Query workshop queue filtered by dealership, technician, or status.
* `POST /service/job-cards`: Create new service appointment and generate 7-stage digital job card.
* `PATCH /service/job-cards/{id}/status`: Advance workflow (`Pending Approval` $\to$ `Quality Check` $\to$ `Completed`).
* `POST /service/job-cards/{id}/checklist`: Record High-Voltage safety checks and BMS firmware versions.

#### 3. Blade Battery Laboratory API
* `GET /battery/inspections/{vin}`: Query historical battery health degradation records.
* `POST /battery/inspections/upload`: Upload battery scanner logs (`.csv`, `.pdf`, `.log`).
* `POST /battery/inspections/analyze`: Trigger server-side Gemini 3.8 Flash diagnostic synthesis.

#### 4. Global Warehousing & Inventory API
* `GET /inventory/parts`: Search spare parts catalogue by SKU, category, or model compatibility.
* `POST /inventory/transfers`: Initiate audited stock transfer between distribution depot and 3S center.
* `GET /inventory/warehouses`: Query warehouse capacity and utilization metrics.

#### 5. Global Finance & Tax Invoicing API
* `GET /finance/invoices`: Retrieve audited tax invoices across multi-currency ledger.
* `POST /finance/invoices`: Issue new invoice applying jurisdiction-specific tax rate (18% PK, 5% AE, 15% SA, etc.).
* `POST /finance/invoices/{id}/reconcile`: Webhook callback for payment gateway confirmations (1LINK, Visa, FAB, SARIE).

#### 6. Webhooks
* `EVENT: vehicle.battery.fault`: Triggered when cell voltage delta exceeds 0.05V.
* `EVENT: service.job.completed`: Dispatches SMS/WhatsApp message to customer phone.
* `EVENT: inventory.stock.low`: Generates purchase order recommendation for inventory manager.
