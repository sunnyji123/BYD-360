import React, { useState, useEffect } from 'react';
import {
  Activity,
  Battery,
  ShieldCheck,
  Thermometer,
  Zap,
  Sparkles,
  Upload,
  FileText,
  AlertCircle,
  CheckCircle2,
  Cpu,
  BarChart2,
  Clock,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { api } from '../../services/api';
import { BatteryInspectionRecord, Vehicle } from '../../types';

export const BatteryManagement: React.FC = () => {
  const { currentUser } = useApp();
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVin, setSelectedVin] = useState<string>('');
  const [records, setRecords] = useState<BatteryInspectionRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<BatteryInspectionRecord | null>(null);

  // AI Interpretation State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);

  // Upload Simulation Modal
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const load = () => {
      const allVehicles = db.getVehicles();
      setVehicles(allVehicles);
      if (allVehicles.length > 0 && !selectedVin) {
        setSelectedVin(allVehicles[0].vin);
      }

      const allRecords = db.getBatteryRecords();
      setRecords(allRecords);
      if (allRecords.length > 0 && !selectedRecord) {
        setSelectedRecord(allRecords[0]);
        setAiReport(allRecords[0].aiDiagnosticSummary || null);
      }
    };

    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  const activeVehicle = vehicles.find((v) => v.vin === selectedVin) || vehicles[0];
  const activeRecord = records.find((r) => r.vin === selectedVin) || selectedRecord || records[0];

  const handleRunAIAnalysis = async () => {
    if (!activeRecord) return;
    setAiLoading(true);
    try {
      const res = await api.analyzeBattery(
        {
          sohPercentage: activeRecord.sohPercentage,
          socPercentage: activeRecord.socPercentage,
          cellVoltageMin: activeRecord.cellVoltageMin,
          cellVoltageMax: activeRecord.cellVoltageMax,
          cellVoltageDelta: activeRecord.cellVoltageDelta,
          packTemperatureCelsius: activeRecord.packTemperatureCelsius,
          internalResistanceMilliOhm: activeRecord.internalResistanceMilliOhm,
          cycleCount: activeRecord.cycleCount,
          insulationResistanceMOhm: activeRecord.insulationResistanceMOhm,
          bmsVersion: activeRecord.firmwareBmsVersion,
        },
        activeRecord.vin,
        activeRecord.model
      );
      setAiReport(res.analysis);
    } catch (e: any) {
      setAiReport(`BYD AI Diagnostic Error: ${e?.message || 'Server Gemini API unavailable.'}`);
    } finally {
      setAiLoading(false);
    }
  };

  const handleSimulateUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadedFileName) return;
    setUploading(true);

    setTimeout(() => {
      const newRec: BatteryInspectionRecord = {
        id: `bat_rec_${Date.now()}`,
        vehicleId: activeVehicle?.id || 'veh_01',
        vin: activeVehicle?.vin || 'LGXCE43C5R0108924',
        model: activeVehicle?.model || 'BYD Seal AWD',
        inspectionDate: new Date().toISOString().split('T')[0],
        inspectorName: 'Mega Motor Clifton Certified Lab',
        dealershipName: 'Mega Motor Flagship 3S — Clifton',
        sohPercentage: 99.1,
        socPercentage: 84.0,
        cellVoltageMin: 3.285,
        cellVoltageMax: 3.295,
        cellVoltageDelta: 0.010,
        packTemperatureCelsius: 28.8,
        internalResistanceMilliOhm: 0.40,
        cycleCount: 65,
        insulationResistanceMOhm: 540,
        overallRating: 'Optimal',
        firmwareBmsVersion: 'BMS-V82.5-PK-REV4',
        notes: `Uploaded log file [${uploadedFileName}] successfully interpreted. Zero abnormal thermal signatures.`,
        isDemo: true,
      };

      db.addBatteryRecord(newRec);
      setSelectedRecord(newRec);
      setUploading(false);
      setUploadModalOpen(false);
      setUploadedFileName('');
    }, 1500);
  };

  // Generate simulated 138-cell matrix voltages around nominal
  const cellVoltages = Array.from({ length: 48 }, (_, i) => {
    const base = activeRecord ? activeRecord.cellVoltageMin : 3.284;
    const delta = (Math.sin(i * 0.4) * 0.005 + 0.004).toFixed(3);
    return (base + parseFloat(delta)).toFixed(3);
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner with prominent DEMO badge */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Battery Intelligence Hub</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-950/80 text-amber-400 border border-amber-800">
              DEMO DATA LABELED
            </span>
          </div>
          <h2 className="text-2xl font-black text-white">BYD Blade Battery Health & Diagnostic Telemetry</h2>
          <p className="text-xs text-slate-400">
            Certified Lithium Iron Phosphate (LFP) diagnostics, cell impedance & thermal balance monitoring
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <label className="text-xs text-slate-400 font-medium">Select Vehicle VIN:</label>
          <select
            value={selectedVin}
            onChange={(e) => setSelectedVin(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
          >
            {vehicles.map((v) => (
              <option key={v.id} value={v.vin}>
                {v.model} ({v.licensePlate}) — {v.vin.slice(0, 10)}...
              </option>
            ))}
          </select>

          <button
            onClick={() => setUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-slate-700 bg-slate-950 text-slate-300 hover:text-white text-xs font-semibold"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Upload Inspection File</span>
          </button>
        </div>
      </div>

      {/* Primary Battery Metrics Grid */}
      {activeRecord && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">State of Health (SoH)</span>
              <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-emerald-400 mt-2">{activeRecord.sohPercentage}%</p>
            <p className="text-[11px] text-slate-400 mt-1">Status: <strong>{activeRecord.overallRating}</strong></p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Cell Voltage Balance</span>
              <div className="p-2 rounded-xl bg-cyan-950 text-cyan-400">
                <Zap className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-cyan-300 mt-2">±{activeRecord.cellVoltageDelta} V</p>
            <p className="text-[11px] text-emerald-400 mt-1">Variance nominal (&lt;0.025V standard)</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Pack Core Temperature</span>
              <div className="p-2 rounded-xl bg-blue-950 text-blue-400">
                <Thermometer className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-white mt-2">{activeRecord.packTemperatureCelsius}°C</p>
            <p className="text-[11px] text-slate-400 mt-1">Liquid cooling active (Target 28-32°C)</p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Full Equivalent Cycles</span>
              <div className="p-2 rounded-xl bg-purple-950 text-purple-400">
                <RefreshCw className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl sm:text-3xl font-black text-white mt-2">{activeRecord.cycleCount} Cycles</p>
            <p className="text-[11px] text-slate-400 mt-1">Est. 3,000+ cycle Blade design life</p>
          </div>
        </div>
      )}

      {/* AI Interpretation Panel */}
      <div className="rounded-2xl bg-slate-900/80 border border-cyan-500/30 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">AI Blade Diagnostic Interpreter (Gemini 3.8 Flash)</h3>
              <p className="text-xs text-slate-400">Automated engineering interpretation of cell impedance, thermal safety & warranty status</p>
            </div>
          </div>

          <button
            onClick={handleRunAIAnalysis}
            disabled={aiLoading}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-xs text-white hover:from-cyan-400 hover:to-blue-500 transition shadow-md shadow-cyan-500/20 disabled:opacity-50"
          >
            {aiLoading ? 'Analyzing Telemetry...' : 'Re-Run Diagnostic Scan'}
          </button>
        </div>

        {aiReport && (
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-200 whitespace-pre-line leading-relaxed">
            {aiReport}
          </div>
        )}
      </div>

      {/* Interactive Blade Cell Voltage Uniformity Matrix */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Blade Cell Voltage Uniformity Scan (Sample 48 of 138 Cells)</span>
            </h4>
            <p className="text-xs text-slate-400">
              Real-time BMS sensor readings. LFP standard cell float range: 3.25V to 3.32V
            </p>
          </div>
          <span className="text-xs font-mono text-cyan-300">Delta: ±0.012V (Optimal)</span>
        </div>

        {/* 48-Cell Visual Grid */}
        <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5 text-center">
          {cellVoltages.map((volt, idx) => (
            <div
              key={idx}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 hover:border-cyan-500/50 transition group"
            >
              <span className="text-[9px] text-slate-500 block">C-{idx + 1}</span>
              <span className="text-[11px] font-mono font-bold text-cyan-300 group-hover:text-white">
                {volt}V
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Warranty Countdown & Pakistan Climate Policy */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
            <ShieldCheck className="w-4 h-4" />
            <span>BYD Pakistan 8-Year / 160,000 km Warranty</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Every BYD Blade Battery sold via authorized Mega Motor dealerships is covered under an unconditional 8-Year or 160,000 km capacity warranty guaranteeing over 70% retention.
          </p>
          <div className="pt-2 text-xs text-slate-400 space-y-1">
            <p>• Coverage includes: Blade cell replacement, BMS logic boards, coolant circuits, and labor.</p>
            <p>• Inspection requirement: Routine certified scan every 10,000 km or 12 months.</p>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
            <Thermometer className="w-4 h-4" />
            <span>Pakistan Ambient Heat Protection</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Engineered with high-flow liquid cooling channels sandwiched between each blade cell. Even during peak 48°C temperatures in Jacobabad, Sibi, or Multan, battery internal core temperature is held below 35°C.
          </p>
          <div className="pt-2 text-xs text-slate-400 space-y-1">
            <p>• Automatic thermal pre-conditioning before DC ultra-fast charging.</p>
            <p>• Zero thermal runaway risk under mechanical puncture or impact.</p>
          </div>
        </div>
      </div>

      {/* Upload Simulation Modal */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Upload Battery Diagnostic File</h3>
            <p className="text-xs text-slate-400 mb-4">
              Import OBD-II diagnostic dump, CAN-bus trace, or Mega Motor laboratory log (.csv / .json / .bin).
            </p>

            <form onSubmit={handleSimulateUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Select Diagnostic File</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. BYD_BLADE_LOG_2026_VIN924.csv"
                  value={uploadedFileName}
                  onChange={(e) => setUploadedFileName(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white"
                />
              </div>

              <div className="p-4 rounded-xl border border-dashed border-slate-700 bg-slate-950/60 text-center text-xs text-slate-400">
                <Upload className="w-6 h-6 text-cyan-400 mx-auto mb-1" />
                <p>Drag and drop diagnostic files here</p>
                <span className="text-[10px] text-slate-500">Supports CAN log, BMS XML, or diagnostic text dumps</span>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading}
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 font-bold text-xs text-slate-950 disabled:opacity-50"
                >
                  {uploading ? 'Processing File...' : 'Upload & Analyze'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
