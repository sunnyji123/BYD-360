import express, { Request, Response } from 'express';
import * as XLSX from 'xlsx';
import {
  sqlite,
  generateSecureToken,
  logCountryActivity,
  logOwnerAudit,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireCountryManager,
  requireCountryPermission,
  CANONICAL_COUNTRY_MANAGER_PERMISSIONS,
  getClientIp,
} from './auth';

const FORBIDDEN_PRIVILEGED_ROLES = ['Founder / Owner', 'Super Admin', 'Company Admin', 'Country Manager'];

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function maskNationalId(raw?: string | null): string {
  if (!raw) return 'Not Provided';
  const clean = String(raw).trim();
  if (clean.length <= 6) return '******';
  return `${clean.slice(0, 3)}••••••${clean.slice(-3)}`;
}

function maskPhone(raw?: string | null): string {
  if (!raw) return 'Not Provided';
  const clean = String(raw).trim();
  if (clean.length <= 6) return '******';
  return `${clean.slice(0, 5)}••••${clean.slice(-3)}`;
}

function recordCountryAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.country) return;
  logCountryActivity({
    countryId: req.auth.country,
    managerId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function rejectCrossCountryAccess(req: Request, res: Response, attemptedTarget: string, targetCountry?: string | null) {
  const ip = getClientIp(req);
  const msg = `Country Manager (${req.auth?.email}, assignedCountry=${req.auth?.country}) attempted cross-country access on "${attemptedTarget}" (targetCountry=${targetCountry || 'unknown'}).`;
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'CROSS_COUNTRY_ACCESS_ATTEMPT',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    details: msg,
    ipAddress: ip,
  });
  recordCountryAction(req, 'CROSS_COUNTRY_ACCESS_BLOCKED', 'Security Isolation', attemptedTarget, msg, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Cross-country data access or modification is strictly prohibited.',
  });
}

function rejectGovernanceOrPrivilegeViolation(req: Request, res: Response, reason: string, targetId?: string) {
  const ip = getClientIp(req);
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'COUNTRY_MANAGER_PRIVILEGE_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    details: reason,
    ipAddress: ip,
  });
  recordCountryAction(req, 'PRIVILEGE_ESCALATION_BLOCKED', 'Security Isolation', targetId || null, reason, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Country Managers cannot modify Founder/Super Admin accounts, change their assigned country, or alter global system settings.',
  });
}

function assertCountryQueryNotSpoofed(req: Request, res: Response): boolean {
  const assignedCountry = req.auth!.country.toUpperCase();
  const qCountry = req.query.country ? String(req.query.country).trim().toUpperCase() : null;
  const qCountryId = req.query.countryId ? String(req.query.countryId).trim().toUpperCase() : null;
  const bCountry = req.body && req.body.country ? String(req.body.country).trim().toUpperCase() : null;
  const bCountryId = req.body && req.body.countryId ? String(req.body.countryId).trim().toUpperCase() : null;

  const requested = qCountry || qCountryId || bCountry || bCountryId;
  if (requested && requested !== assignedCountry) {
    rejectCrossCountryAccess(req, res, req.originalUrl, requested);
    return false;
  }
  return true;
}

export function createCountryManagerRouter() {
  const router = express.Router();

  // Strictly enforce verified Country Manager authentication across every route
  router.use(requireCountryManager);

  // =========================================================================
  // 1. REAL-TIME COUNTRY MANAGER DASHBOARD (STRICTLY COUNTRY-ISOLATED)
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const country = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(countryId) as any;
    if (!country) {
      res.status(404).json({ error: 'Assigned country profile not found.' });
      return;
    }

    const assignment = sqlite
      .prepare("SELECT * FROM country_assignments WHERE manager_id = ? AND country_id = ? AND status = 'Active' ORDER BY created_at DESC LIMIT 1")
      .get(req.auth!.userId, countryId) as any;

    const totalCompanies = (sqlite.prepare('SELECT COUNT(*) as c FROM companies WHERE country = ?').get(countryId) as any).c;
    const approvedCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE country = ? AND status = 'Approved'").get(countryId) as any).c;
    const totalBranches = (sqlite.prepare("SELECT COUNT(*) as c FROM country_branches WHERE country_id = ? AND approval_status = 'Approved'").get(countryId) as any).c;
    const pendingBranchApprovals = (sqlite.prepare("SELECT COUNT(*) as c FROM country_branches WHERE country_id = ? AND approval_status = 'Pending Approval'").get(countryId) as any).c;
    const totalDealerships = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE country = ? AND status = 'Approved'").get(countryId) as any).c;
    const pendingDealers = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE country = ? AND status = 'Pending Approval'").get(countryId) as any).c;

    const totalEmployees = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        WHERE c.country = ?
      `)
      .get(countryId) as any).c;

    const totalCustomers = (sqlite
      .prepare("SELECT COUNT(*) as c FROM users WHERE country = ? AND role = 'Customer'")
      .get(countryId) as any).c;

    const totalVehicles = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        WHERE c.country = ?
      `)
      .get(countryId) as any).c;

    const availableVehicles = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        WHERE c.country = ? AND v.sold_at IS NULL AND v.status != 'Sold' AND v.delivery_status != 'Delivered'
      `)
      .get(countryId) as any).c;

    const totalBookings = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM bookings b
        JOIN companies c ON c.id = b.company_id
        WHERE c.country = ?
      `)
      .get(countryId) as any).c;

    const pendingBookings = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM bookings b
        JOIN companies c ON c.id = b.company_id
        WHERE c.country = ? AND b.status = 'Pending'
      `)
      .get(countryId) as any).c;

    const totalVehicleSales = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        WHERE c.country = ? AND v.sold_at IS NOT NULL
      `)
      .get(countryId) as any).c;

    const revRow = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN p.status = 'Paid' THEN p.total_amount ELSE 0 END), 0) as paidTotal,
          COALESCE(SUM(CASE WHEN p.status = 'Pending Payment' THEN p.total_amount ELSE 0 END), 0) as pendingTotal,
          COALESCE(SUM(CASE WHEN p.status = 'Refunded' THEN p.total_amount ELSE 0 END), 0) as refundedTotal
        FROM payments_invoices p
        LEFT JOIN companies c ON c.id = p.company_id
        WHERE p.country = ? OR c.country = ?
      `)
      .get(countryId, countryId) as any;

    const pendingEscalations = (sqlite
      .prepare("SELECT COUNT(*) as c FROM country_escalation_requests WHERE country_id = ? AND status = 'Pending Founder Approval'")
      .get(countryId) as any).c;

    const openCrm = (sqlite
      .prepare(`
        SELECT COUNT(*) as c
        FROM customer_crm_records cr
        JOIN companies c ON c.id = cr.company_id
        WHERE c.country = ? AND cr.status IN ('Open', 'In Progress')
      `)
      .get(countryId) as any).c;

    const pendingApprovals = pendingDealers + pendingBranchApprovals + pendingBookings + pendingEscalations;

    const recentActivities = sqlite
      .prepare('SELECT * FROM country_activity_logs WHERE country_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(countryId);

    const countryNotifications = sqlite
      .prepare(`
        SELECT n.*
        FROM notifications n
        LEFT JOIN companies c ON c.id = n.company_id
        WHERE c.country = ? OR n.company_id IS NULL
        ORDER BY n.created_at DESC
        LIMIT 15
      `)
      .all(countryId);

    const companyOverview = sqlite
      .prepare(`
        SELECT c.id, c.name, c.city, c.status, c.authorized_rep, c.official_email,
               ccr.relationship_type, ccr.operational_status, ccr.performance_rating,
               (SELECT COUNT(*) FROM country_branches cb WHERE cb.company_id = c.id AND cb.country_id = c.country) as branch_count,
               (SELECT COUNT(*) FROM employee_accounts e WHERE e.company_id = c.id) as employee_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id = c.id) as vehicle_count,
               (SELECT COALESCE(SUM(CASE WHEN p.status = 'Paid' THEN p.total_amount ELSE 0 END), 0) FROM payments_invoices p WHERE p.company_id = c.id) as revenue_total
        FROM companies c
        LEFT JOIN country_company_relationships ccr ON ccr.company_id = c.id AND ccr.country_id = c.country
        WHERE c.country = ?
        ORDER BY revenue_total DESC
      `)
      .all(countryId);

    const pendingDealershipList = sqlite
      .prepare(`
        SELECT d.*, c.name as company_name
        FROM dealerships d
        LEFT JOIN companies c ON c.id = d.company_id
        WHERE d.country = ? AND d.status = 'Pending Approval'
        ORDER BY d.created_at DESC
      `)
      .all(countryId);

    const branchPerformance = sqlite
      .prepare(`
        SELECT cb.*, c.name as company_name
        FROM country_branches cb
        LEFT JOIN companies c ON c.id = cb.company_id
        WHERE cb.country_id = ?
        ORDER BY cb.monthly_revenue_pkr DESC
      `)
      .all(countryId);

    res.json({
      actor: {
        id: req.auth!.userId,
        managerCode: req.auth!.managerCode,
        fullName: req.auth!.fullName,
        email: req.auth!.email,
        role: req.auth!.role,
        countryId,
        permissions: req.auth!.permissions,
      },
      countryProfile: {
        id: country.id,
        code: country.code,
        name: country.name,
        flagEmoji: country.flag_emoji,
        currency: country.currency,
        legalEntity: country.legal_entity,
        timezone: country.timezone,
        headquartersCity: country.headquarters_city,
        profile: safeJsonParse(country.profile_json, {}),
        offices: safeJsonParse(country.offices_json, []),
        departments: safeJsonParse(country.departments_json, []),
        authorizedOperations: safeJsonParse(country.authorized_operations_json, []),
        documents: safeJsonParse(country.documents_json, []),
        contacts: safeJsonParse(country.contacts_json, []),
      },
      assignment,
      metrics: {
        totalCompanies,
        approvedCompanies,
        totalBranches,
        pendingBranchApprovals,
        totalDealerships,
        pendingDealers,
        totalEmployees,
        totalCustomers,
        totalVehicles,
        availableVehicles,
        totalBookings,
        pendingBookings,
        totalVehicleSales,
        countryRevenue: revRow.paidTotal,
        pendingRevenue: revRow.pendingTotal,
        refundedRevenue: revRow.refundedTotal,
        pendingApprovals,
        pendingEscalations,
        openCrm,
        recentActivitiesCount: recentActivities.length,
        notificationsCount: countryNotifications.length,
      },
      companyOverview,
      branchPerformance,
      pendingDealerships: pendingDealershipList,
      recentActivities,
      notifications: countryNotifications,
    });
  });

  // =========================================================================
  // 2. COUNTRY MANAGEMENT (PROFILE, OFFICES, DEPARTMENTS, DOCS, CONTACTS)
  // =========================================================================
  router.get('/country', requireCountryPermission('country.profile.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const country = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(countryId) as any;
    if (!country) {
      res.status(404).json({ error: 'Country profile not found.' });
      return;
    }

    const branchesOverview = sqlite
      .prepare(`
        SELECT cb.id, cb.name, cb.code, cb.city, cb.status, cb.approval_status, c.name as company_name
        FROM country_branches cb
        LEFT JOIN companies c ON c.id = cb.company_id
        WHERE cb.country_id = ?
        ORDER BY cb.city ASC
      `)
      .all(countryId);

    res.json({
      country: {
        ...country,
        profile: safeJsonParse(country.profile_json, {}),
        offices: safeJsonParse(country.offices_json, []),
        departments: safeJsonParse(country.departments_json, []),
        authorizedOperations: safeJsonParse(country.authorized_operations_json, []),
        documents: safeJsonParse(country.documents_json, []),
        contacts: safeJsonParse(country.contacts_json, []),
      },
      branchesOverview,
    });
  });

  router.put('/country', requireCountryPermission('country.profile.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const country = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(countryId) as any;
    if (!country) {
      res.status(404).json({ error: 'Country record not found.' });
      return;
    }

    // Never allow changing country ISO code / ID or global Founder ownership settings
    if (req.body.code && String(req.body.code).trim().toUpperCase() !== country.code) {
      rejectGovernanceOrPrivilegeViolation(req, res, `Country Manager attempted to alter country code from ${country.code} to ${req.body.code}`);
      return;
    }

    const headquartersCity = req.body.headquartersCity ? String(req.body.headquartersCity).trim() : country.headquarters_city;
    const legalEntity = req.body.legalEntity ? String(req.body.legalEntity).trim() : country.legal_entity;
    const profileJson = req.body.profile ? JSON.stringify(req.body.profile) : country.profile_json;
    const officesJson = Array.isArray(req.body.offices) ? JSON.stringify(req.body.offices) : country.offices_json;
    const departmentsJson = Array.isArray(req.body.departments) ? JSON.stringify(req.body.departments) : country.departments_json;
    const opsJson = Array.isArray(req.body.authorizedOperations) ? JSON.stringify(req.body.authorizedOperations) : country.authorized_operations_json;
    const docsJson = Array.isArray(req.body.documents) ? JSON.stringify(req.body.documents) : country.documents_json;
    const contactsJson = Array.isArray(req.body.contacts) ? JSON.stringify(req.body.contacts) : country.contacts_json;

    sqlite
      .prepare(`
        UPDATE countries
        SET headquarters_city = ?, legal_entity = ?, profile_json = ?, offices_json = ?,
            departments_json = ?, authorized_operations_json = ?, documents_json = ?, contacts_json = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(headquartersCity, legalEntity, profileJson, officesJson, departmentsJson, opsJson, docsJson, contactsJson, nowIso(), countryId);

    recordCountryAction(req, 'COUNTRY_PROFILE_UPDATED', 'Country Management', country.name, `Updated offices/departments/docs/contacts for ${country.name}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 3. COMPANY MANAGEMENT (ASSIGNED TO COUNTRY + ESCALATION REQUESTS)
  // =========================================================================
  router.get('/companies', requireCountryPermission('companies.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const companies = sqlite
      .prepare(`
        SELECT c.*,
               ccr.relationship_type, ccr.operational_status, ccr.performance_rating, ccr.notes as relationship_notes,
               (SELECT COUNT(*) FROM country_branches cb WHERE cb.company_id = c.id AND cb.country_id = ?) as branch_count,
               (SELECT COUNT(*) FROM dealerships d WHERE d.company_id = c.id AND d.country = ?) as dealership_count,
               (SELECT COUNT(*) FROM employee_accounts e WHERE e.company_id = c.id) as employee_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id = c.id) as vehicle_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id = c.id AND v.sold_at IS NOT NULL) as sales_count,
               (SELECT COALESCE(SUM(CASE WHEN p.status = 'Paid' THEN p.total_amount ELSE 0 END), 0) FROM payments_invoices p WHERE p.company_id = c.id) as paid_revenue
        FROM companies c
        LEFT JOIN country_company_relationships ccr ON ccr.company_id = c.id AND ccr.country_id = ?
        WHERE c.country = ?
        ORDER BY c.created_at DESC
      `)
      .all(countryId, countryId, countryId, countryId);

    const escalations = sqlite
      .prepare("SELECT * FROM country_escalation_requests WHERE country_id = ? AND request_type = 'Company Operation Request' ORDER BY created_at DESC LIMIT 30")
      .all(countryId);

    res.json({ companies, escalations });
  });

  router.patch('/companies/:id/operations', requireCountryPermission('companies.operations.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }
    if (comp.country !== countryId) {
      rejectCrossCountryAccess(req, res, `company:${comp.id}`, comp.country);
      return;
    }

    // Company workspace approval/suspension status requires higher (Primary Owner) approval
    if (req.body.status && req.body.status !== comp.status) {
      res.status(403).json({
        error: 'Changing company approval or suspension status requires higher Primary Owner approval. Submit an escalation request instead.',
      });
      return;
    }

    const phone = req.body.phone ? String(req.body.phone).trim() : comp.phone;
    const city = req.body.city ? String(req.body.city).trim() : comp.city;
    const authorizedRep = req.body.authorizedRep ? String(req.body.authorizedRep).trim() : comp.authorized_rep;
    const operationalStatus = req.body.operationalStatus ? String(req.body.operationalStatus).trim() : 'Active';
    const relationshipNotes = req.body.notes ? String(req.body.notes).trim() : null;
    const performanceRating = req.body.performanceRating !== undefined ? Number(req.body.performanceRating) : 95.0;
    const now = nowIso();

    sqlite
      .prepare('UPDATE companies SET phone = ?, city = ?, authorized_rep = ? WHERE id = ?')
      .run(phone, city, authorizedRep, comp.id);

    sqlite
      .prepare(`
        INSERT INTO country_company_relationships (
          id, country_id, company_id, relationship_type, operational_status, performance_rating, notes, updated_at
        ) VALUES (?, ?, ?, 'Authorized National Partner', ?, ?, ?, ?)
        ON CONFLICT(country_id, company_id) DO UPDATE SET
          operational_status = excluded.operational_status,
          performance_rating = excluded.performance_rating,
          notes = COALESCE(excluded.notes, country_company_relationships.notes),
          updated_at = excluded.updated_at
      `)
      .run(`ccr_${countryId}_${comp.id}`, countryId, comp.id, operationalStatus, performanceRating, relationshipNotes, now);

    recordCountryAction(req, 'COUNTRY_COMPANY_OPS_UPDATED', 'Company Management', comp.name, `Updated permitted ops & rating (${performanceRating}) in ${countryId}`);
    res.json({ success: true });
  });

  router.post('/companies/:id/escalation', requireCountryPermission('companies.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }
    if (comp.country !== countryId) {
      rejectCrossCountryAccess(req, res, `company_escalation:${comp.id}`, comp.country);
      return;
    }

    const title = String(req.body.title || '').trim();
    const details = String(req.body.details || '').trim();
    if (!title || !details) {
      res.status(400).json({ error: 'Request title and details are required for higher-level approval.' });
      return;
    }

    const escId = `cesc_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO country_escalation_requests (
          id, country_id, company_id, manager_id, manager_name, request_type,
          target_id, title, details, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 'Company Operation Request', ?, ?, ?, 'Pending Founder Approval', ?, ?)
      `)
      .run(escId, countryId, comp.id, req.auth!.userId, req.auth!.fullName, comp.id, title, details, now, now);

    recordCountryAction(req, 'COMPANY_ESCALATION_SUBMITTED', 'Company Management', comp.name, `Submitted escalation: ${title}`);
    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_COMPANY_ESCALATION_CREATED',
      module: 'Global Country Oversight',
      targetId: `${comp.name} (${countryId})`,
      companyId: comp.id,
      details: title,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, id: escId, status: 'Pending Founder Approval' });
  });

  // =========================================================================
  // 4. BRANCH MANAGEMENT (COUNTRY BRANCHES, PENDING APPROVALS & REPORTS)
  // =========================================================================
  router.get('/branches', requireCountryPermission('branches.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const branches = sqlite
      .prepare(`
        SELECT cb.*, c.name as company_name,
               (SELECT COUNT(*) FROM employee_accounts e WHERE e.branch_id = cb.company_branch_id OR e.branch_id = cb.id) as staff_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.branch_id = cb.company_branch_id OR v.branch_id = cb.id) as vehicle_count
        FROM country_branches cb
        LEFT JOIN companies c ON c.id = cb.company_id
        WHERE cb.country_id = ?
        ORDER BY CASE WHEN cb.approval_status = 'Pending Approval' THEN 0 ELSE 1 END, cb.created_at DESC
      `)
      .all(countryId);

    const companies = sqlite
      .prepare("SELECT id, name, city FROM companies WHERE country = ? AND status = 'Approved'")
      .all(countryId);

    const employees = sqlite
      .prepare(`
        SELECT e.id, e.user_id, e.full_name, e.employee_code, e.job_position, e.company_id
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        WHERE c.country = ? AND e.status = 'Active'
        ORDER BY e.full_name ASC
      `)
      .all(countryId);

    res.json({ branches, companies, employees });
  });

  // Country Manager submits a new branch registration subject to Primary Owner approval
  router.post('/branches', requireCountryPermission('branches.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const companyId = String(req.body.companyId || '').trim();
    const name = String(req.body.name || '').trim();
    const code = String(req.body.code || '').trim().toUpperCase();
    const city = String(req.body.city || '').trim();
    const address = String(req.body.address || '').trim();
    const managerId = req.body.managerId ? String(req.body.managerId).trim() : null;
    const managerName = String(req.body.managerName || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const monthlyTargetUnits = Number(req.body.monthlyTargetUnits || 25);

    if (!companyId || !name || !code || !city || !address || !managerName || !phone || !email) {
      res.status(400).json({ error: 'Company, branch name, code, city, address, manager name, phone, and email are required.' });
      return;
    }

    const comp = sqlite.prepare('SELECT id, country, name FROM companies WHERE id = ?').get(companyId) as any;
    if (!comp) {
      res.status(404).json({ error: 'Selected company not found.' });
      return;
    }
    if (comp.country !== countryId) {
      rejectCrossCountryAccess(req, res, `create_branch_company:${comp.id}`, comp.country);
      return;
    }

    const dup = sqlite.prepare('SELECT id FROM country_branches WHERE country_id = ? AND UPPER(code) = ?').get(countryId, code);
    if (dup) {
      res.status(409).json({ error: `Branch code "${code}" already exists in ${countryId}.` });
      return;
    }

    const cbrId = `cbr_${generateSecureToken(6)}`;
    const escId = `cesc_${generateSecureToken(6)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO country_branches (
          id, country_id, company_id, company_branch_id, name, code, city, address,
          manager_id, manager_name, phone, email, monthly_target_units, achieved_units,
          monthly_revenue_pkr, approval_status, status, submitted_by, created_at, updated_at
        ) VALUES (?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'Pending Approval', 'Inactive', ?, ?, ?)
      `)
      .run(cbrId, countryId, companyId, name, code, city, address, managerId, managerName, phone, email, monthlyTargetUnits, req.auth!.fullName, now, now);

    sqlite
      .prepare(`
        INSERT INTO country_escalation_requests (
          id, country_id, company_id, manager_id, manager_name, request_type,
          target_id, title, details, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 'New Branch Approval', ?, ?, ?, 'Pending Founder Approval', ?, ?)
      `)
      .run(
        escId,
        countryId,
        companyId,
        req.auth!.userId,
        req.auth!.fullName,
        cbrId,
        `Approve New Branch: ${name} (${code})`,
        `Company: ${comp.name} | City: ${city} | Proposed Manager: ${managerName} | Target: ${monthlyTargetUnits} units/mo`,
        now,
        now
      );

    recordCountryAction(req, 'BRANCH_SUBMITTED_FOR_APPROVAL', 'Branch Management', `${name} (${code})`, `Submitted pending Primary Owner approval`);
    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_BRANCH_APPROVAL_REQUESTED',
      module: 'Branch Expansion',
      targetId: `${name} (${code})`,
      companyId,
      details: `Country: ${countryId}, City: ${city}`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      id: cbrId,
      escalationId: escId,
      approvalStatus: 'Pending Approval',
      message: 'Branch proposal created and queued for Primary Owner approval.',
    });
  });

  router.patch('/branches/:id', requireCountryPermission('branches.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const cbr = sqlite.prepare('SELECT * FROM country_branches WHERE id = ?').get(req.params.id) as any;
    if (!cbr) {
      res.status(404).json({ error: 'Country branch not found.' });
      return;
    }
    if (cbr.country_id !== countryId) {
      rejectCrossCountryAccess(req, res, `branch:${cbr.id}`, cbr.country_id);
      return;
    }

    const managerId = req.body.managerId !== undefined ? req.body.managerId : cbr.manager_id;
    let managerName = req.body.managerName ? String(req.body.managerName).trim() : cbr.manager_name;
    if (managerId) {
      const emp = sqlite
        .prepare(`
          SELECT e.id, e.user_id, e.full_name, c.country
          FROM employee_accounts e
          JOIN companies c ON c.id = e.company_id
          WHERE e.id = ? OR e.user_id = ?
        `)
        .get(managerId, managerId) as any;
      if (!emp) {
        res.status(404).json({ error: 'Assigned branch manager employee record not found.' });
        return;
      }
      if (emp.country !== countryId) {
        rejectCrossCountryAccess(req, res, `assign_branch_mgr:${emp.id}`, emp.country);
        return;
      }
      managerName = emp.full_name;
    }

    const monthlyTargetUnits = req.body.monthlyTargetUnits !== undefined ? Number(req.body.monthlyTargetUnits) : cbr.monthly_target_units;
    const phone = req.body.phone ? String(req.body.phone).trim() : cbr.phone;
    const address = req.body.address ? String(req.body.address).trim() : cbr.address;
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) && cbr.approval_status === 'Approved'
      ? String(req.body.status)
      : cbr.status;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE country_branches
        SET manager_id = ?, manager_name = ?, monthly_target_units = ?, phone = ?, address = ?, status = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(managerId || null, managerName, monthlyTargetUnits, phone, address, status, now, cbr.id);

    if (cbr.company_branch_id) {
      sqlite
        .prepare(`
          UPDATE company_branches
          SET manager_id = ?, manager_name = ?, monthly_target_units = ?, phone = ?, address = ?, status = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(managerId || null, managerName, monthlyTargetUnits, phone, address, status, now, cbr.company_branch_id);
    }

    recordCountryAction(req, 'COUNTRY_BRANCH_UPDATED', 'Branch Management', `${cbr.name} (${cbr.code})`, `Manager: ${managerName}, Target: ${monthlyTargetUnits}`);
    res.json({ success: true });
  });

  router.get('/branches/:id/report', requireCountryPermission('branches.view'), (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const cbr = sqlite
      .prepare('SELECT cb.*, c.name as company_name FROM country_branches cb LEFT JOIN companies c ON c.id = cb.company_id WHERE cb.id = ?')
      .get(req.params.id) as any;
    if (!cbr) {
      res.status(404).json({ error: 'Country branch not found.' });
      return;
    }
    if (cbr.country_id !== countryId) {
      rejectCrossCountryAccess(req, res, `branch_report:${cbr.id}`, cbr.country_id);
      return;
    }

    const branchMatchId = cbr.company_branch_id || cbr.id;
    const staff = sqlite
      .prepare('SELECT id, employee_code, full_name, job_position, department, status, performance_score FROM employee_accounts WHERE branch_id = ?')
      .all(branchMatchId);
    const inventory = sqlite
      .prepare('SELECT id, vin, model, variant, color, status, delivery_status, sale_price_pkr, sold_at FROM vehicles WHERE branch_id = ?')
      .all(branchMatchId);
    const cityBookings = sqlite
      .prepare(`
        SELECT b.id, b.booking_type, b.vehicle_model, b.customer_name, b.preferred_date, b.status
        FROM bookings b
        JOIN companies c ON c.id = b.company_id
        WHERE c.country = ? AND b.city = ?
        ORDER BY b.created_at DESC LIMIT 20
      `)
      .all(countryId, cbr.city);

    res.json({
      branch: cbr,
      summary: {
        staffCount: staff.length,
        vehicleCount: inventory.length,
        soldCount: inventory.filter((v: any) => Boolean(v.sold_at)).length,
        targetAchievementPct: cbr.monthly_target_units > 0 ? Math.round((cbr.achieved_units / cbr.monthly_target_units) * 100) : 0,
      },
      staff,
      inventory,
      cityBookings,
    });
  });

  // =========================================================================
  // 5. DEALERSHIP MANAGEMENT (COUNTRY-ISOLATED)
  // =========================================================================
  router.get('/dealerships', requireCountryPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const dealerships = sqlite
      .prepare(`
        SELECT d.*, c.name as company_name
        FROM dealerships d
        LEFT JOIN companies c ON c.id = d.company_id
        WHERE d.country = ?
        ORDER BY CASE WHEN d.status = 'Pending Approval' THEN 0 ELSE 1 END, d.monthly_revenue_pkr DESC
      `)
      .all(countryId);
    res.json({ dealerships });
  });

  router.patch('/dealerships/:id', requireCountryPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.country !== countryId) {
      rejectCrossCountryAccess(req, res, `dealership:${dlr.id}`, dlr.country);
      return;
    }

    const managerName = req.body.managerName ? String(req.body.managerName).trim() : dlr.manager_name;
    const phone = req.body.phone ? String(req.body.phone).trim() : dlr.phone;
    const monthlyTargetUnits = req.body.monthlyTargetUnits !== undefined ? Number(req.body.monthlyTargetUnits) : dlr.monthly_target_units;
    const serviceBays = req.body.serviceBays !== undefined ? Number(req.body.serviceBays) : dlr.service_bays;
    const activeTechs = req.body.activeTechs !== undefined ? Number(req.body.activeTechs) : dlr.active_techs;

    sqlite
      .prepare('UPDATE dealerships SET manager_name = ?, phone = ?, monthly_target_units = ?, service_bays = ?, active_techs = ? WHERE id = ?')
      .run(managerName, phone, monthlyTargetUnits, serviceBays, activeTechs, dlr.id);

    recordCountryAction(req, 'COUNTRY_DEALERSHIP_UPDATED', 'Dealership Management', `${dlr.name} (${dlr.code})`, `Target=${monthlyTargetUnits}, Mgr=${managerName}`);
    res.json({ success: true });
  });

  router.patch('/dealerships/:id/decision', requireCountryPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.country !== countryId) {
      rejectCrossCountryAccess(req, res, `dealership_decision:${dlr.id}`, dlr.country);
      return;
    }

    const status = String(req.body.status || '');
    if (!['Approved', 'Rejected', 'Suspended', 'Pending Approval'].includes(status)) {
      res.status(400).json({ error: 'Invalid dealership decision status.' });
      return;
    }

    sqlite.prepare('UPDATE dealerships SET status = ? WHERE id = ?').run(status, dlr.id);
    recordCountryAction(req, `COUNTRY_DEALER_${status.toUpperCase().replace(/\s+/g, '_')}`, 'Dealership Management', `${dlr.name} (${dlr.code})`, `Changed dealership status from ${dlr.status} to ${status}`);
    res.json({ success: true, status });
  });

  router.post('/dealerships/:id/communicate', requireCountryPermission('dealers.manage'), (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.country !== countryId) {
      rejectCrossCountryAccess(req, res, `dealership_comm:${dlr.id}`, dlr.country);
      return;
    }

    const subject = String(req.body.subject || '').trim();
    const message = String(req.body.message || '').trim();
    if (!subject || !message) {
      res.status(400).json({ error: 'Subject and message are required.' });
      return;
    }

    const notifId = `ntf_${generateSecureToken(6)}`;
    sqlite
      .prepare('INSERT INTO notifications (id, company_id, user_id, title, message, category, is_read, created_at) VALUES (?, ?, NULL, ?, ?, ?, 0, ?)')
      .run(notifId, dlr.company_id, `[Country Desk • ${dlr.code}] ${subject}`, message, 'Country Directive', nowIso());

    recordCountryAction(req, 'DEALER_COMMUNICATION_SENT', 'Dealership Management', `${dlr.name} (${dlr.code})`, subject);
    res.status(201).json({ success: true, notificationId: notifId });
  });

  // =========================================================================
  // 6. EMPLOYEE MANAGEMENT (COUNTRY WORKFORCE & DEPARTMENTS)
  // =========================================================================
  router.get('/employees', requireCountryPermission('employees.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const employees = sqlite
      .prepare(`
        SELECT e.*, c.name as company_name, cb.name as branch_name, u.last_login_at
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        LEFT JOIN company_branches cb ON cb.id = e.branch_id
        LEFT JOIN users u ON u.id = e.user_id
        WHERE c.country = ?
        ORDER BY e.created_at DESC
      `)
      .all(countryId)
      .map((e: any) => ({
        ...e,
        attendance: safeJsonParse(e.attendance_json, []),
        leaveRequests: safeJsonParse(e.leave_requests_json, []),
        permissions: safeJsonParse(e.permissions_json, []),
      }));

    const deptBreakdown = sqlite
      .prepare(`
        SELECT e.department, COUNT(*) as headcount, ROUND(AVG(e.performance_score), 1) as avg_score
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        WHERE c.country = ?
        GROUP BY e.department
        ORDER BY headcount DESC
      `)
      .all(countryId);

    res.json({ employees, deptBreakdown });
  });

  router.patch('/employees/:id', requireCountryPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const emp = sqlite
      .prepare(`
        SELECT e.*, c.country as company_country
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        WHERE e.id = ?
      `)
      .get(req.params.id) as any;

    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_country !== countryId) {
      rejectCrossCountryAccess(req, res, `employee:${emp.id}`, emp.company_country);
      return;
    }

    if (req.body.jobPosition && FORBIDDEN_PRIVILEGED_ROLES.includes(String(req.body.jobPosition).trim())) {
      rejectGovernanceOrPrivilegeViolation(req, res, `Country Manager attempted to assign privileged role "${req.body.jobPosition}" to ${emp.email}`, emp.id);
      return;
    }

    const department = req.body.department ? String(req.body.department).trim() : emp.department;
    const jobPosition = req.body.jobPosition ? String(req.body.jobPosition).trim() : emp.job_position;
    const performanceScore = req.body.performanceScore !== undefined ? Number(req.body.performanceScore) : emp.performance_score;
    const performanceNotes = req.body.performanceNotes !== undefined ? String(req.body.performanceNotes) : emp.performance_notes;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE employee_accounts
        SET department = ?, job_position = ?, performance_score = ?, performance_notes = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(department, jobPosition, performanceScore, performanceNotes, now, emp.id);

    if (emp.user_id && req.body.jobPosition) {
      sqlite.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?').run(jobPosition, now, emp.user_id);
    }

    recordCountryAction(req, 'COUNTRY_EMPLOYEE_RESPONSIBILITY_UPDATED', 'Employee Management', `${emp.full_name} (${emp.employee_code})`, `Dept: ${department}, Position: ${jobPosition}, Score: ${performanceScore}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 7. VEHICLE & INVENTORY MANAGEMENT (INTRA-COUNTRY TRANSFERS)
  // =========================================================================
  router.get('/vehicles', requireCountryPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const vehicles = sqlite
      .prepare(`
        SELECT v.*, c.name as company_name, cb.name as branch_name, d.name as dealership_name
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        LEFT JOIN company_branches cb ON cb.id = v.branch_id
        LEFT JOIN dealerships d ON d.id = v.dealership_id
        WHERE c.country = ?
        ORDER BY v.created_at DESC
      `)
      .all(countryId);

    const branches = sqlite
      .prepare("SELECT id, company_branch_id, company_id, name, code, city FROM country_branches WHERE country_id = ? AND approval_status = 'Approved'")
      .all(countryId);

    res.json({ vehicles, branches });
  });

  router.post('/vehicles/:id/transfer', requireCountryPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const veh = sqlite
      .prepare(`
        SELECT v.*, c.country as company_country
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        WHERE v.id = ?
      `)
      .get(req.params.id) as any;

    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.company_country !== countryId) {
      rejectCrossCountryAccess(req, res, `vehicle_transfer:${veh.vin}`, veh.company_country);
      return;
    }

    const targetBranchInput = String(req.body.targetBranchId || '').trim();
    const deliveryStatus = String(req.body.deliveryStatus || 'In Transit').trim();
    const targetBranch = sqlite
      .prepare('SELECT * FROM country_branches WHERE id = ? OR company_branch_id = ?')
      .get(targetBranchInput, targetBranchInput) as any;

    if (!targetBranch) {
      res.status(404).json({ error: 'Target branch not found.' });
      return;
    }
    if (targetBranch.country_id !== countryId) {
      rejectCrossCountryAccess(req, res, `cross_country_stock_transfer:${targetBranch.id}`, targetBranch.country_id);
      return;
    }

    const storedBranchId = targetBranch.company_branch_id || targetBranch.id;
    sqlite
      .prepare('UPDATE vehicles SET branch_id = ?, delivery_status = ? WHERE id = ?')
      .run(storedBranchId, deliveryStatus, veh.id);

    recordCountryAction(req, 'INTRA_COUNTRY_STOCK_TRANSFER', 'Vehicle & Inventory', veh.vin, `Transferred to ${targetBranch.name} (${targetBranch.city}) — ${deliveryStatus}`);
    res.json({ success: true, branchId: storedBranchId, branchName: targetBranch.name, deliveryStatus });
  });

  // =========================================================================
  // 8. CUSTOMER & CRM MANAGEMENT (PII MASKED UNLESS PERMITTED & LOGGED)
  // =========================================================================
  router.get('/customers', requireCountryPermission('customers.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;
    const wantsReveal = req.query.reveal === '1' || req.query.reveal === 'true';

    if (wantsReveal && !req.auth!.permissions.includes('customers.pii.reveal')) {
      res.status(403).json({ error: 'Permission denied: requires "customers.pii.reveal" permission to unmask customer PII.' });
      return;
    }

    if (wantsReveal) {
      recordCountryAction(req, 'CUSTOMER_PII_REVEALED', 'Customer & CRM', countryId, 'Unmasked customer CNIC and mobile records for compliance review', 'WARNING');
    }

    const customers = sqlite
      .prepare(`
        SELECT u.id, u.company_id, u.full_name, u.email, u.mobile, u.city, u.country, u.cnic_or_id,
               u.status, u.email_verified, u.created_at, c.name as company_name,
               (SELECT COUNT(*) FROM bookings b WHERE b.customer_id = u.id) as booking_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.owner_id = u.id) as vehicle_count
        FROM users u
        LEFT JOIN companies c ON c.id = u.company_id
        WHERE u.country = ? AND u.role = 'Customer'
        ORDER BY u.created_at DESC
      `)
      .all(countryId)
      .map((row: any) => ({
        ...row,
        mobileDisplay: wantsReveal ? row.mobile : maskPhone(row.mobile),
        cnicMasked: wantsReveal ? row.cnic_or_id || 'Not Provided' : maskNationalId(row.cnic_or_id),
        cnic_or_id: undefined,
      }));

    const crmRecords = sqlite
      .prepare(`
        SELECT cr.*, c.name as company_name
        FROM customer_crm_records cr
        JOIN companies c ON c.id = cr.company_id
        WHERE c.country = ?
        ORDER BY cr.created_at DESC
      `)
      .all(countryId)
      .map((cr: any) => ({
        ...cr,
        customerPhoneDisplay: wantsReveal ? cr.customer_phone : maskPhone(cr.customer_phone),
      }));

    const bookings = sqlite
      .prepare(`
        SELECT b.*, c.name as company_name
        FROM bookings b
        JOIN companies c ON c.id = b.company_id
        WHERE c.country = ?
        ORDER BY b.created_at DESC
        LIMIT 50
      `)
      .all(countryId);

    const feedbackCount = crmRecords.filter((r: any) => r.record_type === 'Feedback').length;
    const openComplaints = crmRecords.filter((r: any) => r.record_type === 'Complaint' && r.status !== 'Closed' && r.status !== 'Resolved').length;

    res.json({
      piiRevealed: wantsReveal,
      customers,
      crmRecords,
      bookings,
      csiSummary: {
        totalCustomers: customers.length,
        totalFeedback: feedbackCount,
        openComplaints,
        satisfactionScore: 96.2,
      },
    });
  });

  router.patch('/customers/crm/:id', requireCountryPermission('customers.view'), (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const crm = sqlite
      .prepare(`
        SELECT cr.*, c.country as company_country
        FROM customer_crm_records cr
        JOIN companies c ON c.id = cr.company_id
        WHERE cr.id = ?
      `)
      .get(req.params.id) as any;
    if (!crm) {
      res.status(404).json({ error: 'CRM record not found.' });
      return;
    }
    if (crm.company_country !== countryId) {
      rejectCrossCountryAccess(req, res, `crm:${crm.id}`, crm.company_country);
      return;
    }

    const status = req.body.status ? String(req.body.status).trim() : crm.status;
    const resolutionNotes = req.body.resolutionNotes !== undefined ? String(req.body.resolutionNotes) : crm.resolution_notes;
    sqlite
      .prepare('UPDATE customer_crm_records SET status = ?, resolution_notes = ?, updated_at = ? WHERE id = ?')
      .run(status, resolutionNotes, nowIso(), crm.id);

    recordCountryAction(req, 'COUNTRY_CRM_UPDATED', 'Customer & CRM', crm.subject, `Status: ${status}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 9. SALES & FINANCE MANAGEMENT (WITH HIGHER-APPROVAL REFUND WORKFLOW)
  // =========================================================================
  router.get('/sales-finance', requireCountryPermission('sales.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const countryId = req.auth!.country;

    const invoices = sqlite
      .prepare(`
        SELECT p.*, c.name as company_name
        FROM payments_invoices p
        LEFT JOIN companies c ON c.id = p.company_id
        WHERE p.country = ? OR c.country = ?
        ORDER BY p.created_at DESC
      `)
      .all(countryId, countryId);

    const bookings = sqlite
      .prepare(`
        SELECT b.*, c.name as company_name
        FROM bookings b
        JOIN companies c ON c.id = b.company_id
        WHERE c.country = ?
        ORDER BY b.created_at DESC
      `)
      .all(countryId);

    const soldVehicles = sqlite
      .prepare(`
        SELECT v.id, v.vin, v.model, v.variant, v.sale_price_pkr, v.sold_at, v.owner_name, c.name as company_name, cb.name as branch_name
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        LEFT JOIN company_branches cb ON cb.id = v.branch_id
        WHERE c.country = ? AND v.sold_at IS NOT NULL
        ORDER BY v.sold_at DESC
      `)
      .all(countryId);

    const companyRevenueBreakdown = sqlite
      .prepare(`
        SELECT c.id, c.name as company_name,
               COALESCE(SUM(CASE WHEN p.status = 'Paid' THEN p.total_amount ELSE 0 END), 0) as paid_revenue,
               COALESCE(SUM(CASE WHEN p.status = 'Pending Payment' THEN p.total_amount ELSE 0 END), 0) as pending_revenue,
               COUNT(p.id) as invoice_count
        FROM companies c
        LEFT JOIN payments_invoices p ON p.company_id = c.id
        WHERE c.country = ?
        GROUP BY c.id
      `)
      .all(countryId);

    const dealershipRevenueBreakdown = sqlite
      .prepare(`
        SELECT id, name, code, city, monthly_target_units, achieved_units, monthly_revenue_pkr
        FROM dealerships
        WHERE country = ?
        ORDER BY monthly_revenue_pkr DESC
      `)
      .all(countryId);

    const branchRevenueBreakdown = sqlite
      .prepare(`
        SELECT id, name, code, city, monthly_target_units, achieved_units, monthly_revenue_pkr
        FROM country_branches
        WHERE country_id = ?
        ORDER BY monthly_revenue_pkr DESC
      `)
      .all(countryId);

    const refundRequests = sqlite
      .prepare("SELECT * FROM country_escalation_requests WHERE country_id = ? AND request_type = 'Financial Refund Approval' ORDER BY created_at DESC LIMIT 20")
      .all(countryId);

    const paidRevenue = invoices.filter((i: any) => i.status === 'Paid').reduce((s: number, i: any) => s + Number(i.total_amount || 0), 0);
    const pendingRevenue = invoices.filter((i: any) => i.status === 'Pending Payment').reduce((s: number, i: any) => s + Number(i.total_amount || 0), 0);
    const refundedTotal = invoices.filter((i: any) => i.status === 'Refunded').reduce((s: number, i: any) => s + Number(i.total_amount || 0), 0);

    res.json({
      invoices,
      bookings,
      soldVehicles,
      companyRevenueBreakdown,
      dealershipRevenueBreakdown,
      branchRevenueBreakdown,
      refundRequests,
      totals: {
        paidRevenue,
        pendingRevenue,
        refundedTotal,
        soldCount: soldVehicles.length,
      },
    });
  });

  // Sensitive financial operation: submit escalation request for higher approval
  router.post('/invoices/:id/refund-request', requireCountryPermission('sales.view'), (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const inv = sqlite
      .prepare('SELECT p.*, c.country as company_country FROM payments_invoices p LEFT JOIN companies c ON c.id = p.company_id WHERE p.id = ?')
      .get(req.params.id) as any;

    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    const invCountry = inv.country || inv.company_country;
    if (invCountry !== countryId) {
      rejectCrossCountryAccess(req, res, `invoice_refund_req:${inv.invoice_number}`, invCountry);
      return;
    }

    const reason = String(req.body.reason || '').trim();
    if (!reason) {
      res.status(400).json({ error: 'Justification reason is required to request a financial refund.' });
      return;
    }

    const escId = `cesc_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO country_escalation_requests (
          id, country_id, company_id, manager_id, manager_name, request_type,
          target_id, title, details, amount, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, 'Financial Refund Approval', ?, ?, ?, ?, 'Pending Founder Approval', ?, ?)
      `)
      .run(
        escId,
        countryId,
        inv.company_id,
        req.auth!.userId,
        req.auth!.fullName,
        inv.id,
        `Refund Approval: ${inv.invoice_number} (${inv.customer_name})`,
        reason,
        inv.total_amount,
        now,
        now
      );

    recordCountryAction(req, 'SENSITIVE_REFUND_REQUESTED', 'Sales & Finance', inv.invoice_number, `Requested Owner approval for ${inv.currency} ${inv.total_amount}: ${reason}`, 'WARNING');
    res.status(201).json({ success: true, id: escId, status: 'Pending Founder Approval' });
  });

  // Direct sensitive refund — strictly requires explicit 'finance.sensitive.manage' permission
  router.patch('/invoices/:id/refund', requireCountryPermission('finance.sensitive.manage'), (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const inv = sqlite
      .prepare('SELECT p.*, c.country as company_country FROM payments_invoices p LEFT JOIN companies c ON c.id = p.company_id WHERE p.id = ?')
      .get(req.params.id) as any;

    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    const invCountry = inv.country || inv.company_country;
    if (invCountry !== countryId) {
      rejectCrossCountryAccess(req, res, `invoice_refund:${inv.invoice_number}`, invCountry);
      return;
    }

    const reason = String(req.body.reason || 'Authorized Country Finance Refund').trim();
    sqlite.prepare("UPDATE payments_invoices SET status = 'Refunded' WHERE id = ?").run(inv.id);

    recordCountryAction(req, 'COUNTRY_INVOICE_REFUNDED', 'Sales & Finance', inv.invoice_number, `Direct refund authorized (${inv.total_amount}): ${reason}`, 'WARNING');
    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_SENSITIVE_REFUND_EXECUTED',
      module: 'Country Finance',
      targetId: inv.invoice_number,
      companyId: inv.company_id,
      details: reason,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, invoiceNumber: inv.invoice_number, status: 'Refunded' });
  });

  // =========================================================================
  // 10. COUNTRY REPORTS & ANALYTICS + REAL EXCEL (.xlsx) / CSV EXPORT
  // =========================================================================
  function buildCountryReportData(countryId: string, period: string) {
    const country = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(countryId) as any;
    const days = period === 'daily' ? 1 : period === 'weekly' ? 7 : period === 'yearly' ? 365 : 30;
    const sinceIso = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

    const branches = sqlite
      .prepare('SELECT name, code, city, approval_status, status, monthly_target_units, achieved_units, monthly_revenue_pkr FROM country_branches WHERE country_id = ?')
      .all(countryId) as any[];
    const dealerships = sqlite
      .prepare('SELECT name, code, city, status, facility_type, monthly_target_units, achieved_units, monthly_revenue_pkr, rating FROM dealerships WHERE country = ?')
      .all(countryId) as any[];
    const vehiclesByModel = sqlite
      .prepare(`
        SELECT v.model, COUNT(*) as total_units,
               SUM(CASE WHEN v.sold_at IS NOT NULL THEN 1 ELSE 0 END) as sold_units,
               ROUND(AVG(v.battery_health_soh), 1) as avg_soh
        FROM vehicles v
        JOIN companies c ON c.id = v.company_id
        WHERE c.country = ?
        GROUP BY v.model
      `)
      .all(countryId) as any[];
    const invoices = sqlite
      .prepare(`
        SELECT p.invoice_number, p.customer_name, p.item_category, p.total_amount, p.currency, p.status, p.payment_gateway, p.issued_date, p.created_at
        FROM payments_invoices p
        LEFT JOIN companies c ON c.id = p.company_id
        WHERE (p.country = ? OR c.country = ?) AND p.created_at >= ?
        ORDER BY p.created_at DESC
      `)
      .all(countryId, countryId, sinceIso) as any[];

    const periodPaidRevenue = invoices.filter((i) => i.status === 'Paid').reduce((s, i) => s + Number(i.total_amount || 0), 0);
    const employeesSummary = sqlite
      .prepare(`
        SELECT e.department, COUNT(*) as count, ROUND(AVG(e.performance_score), 1) as avg_performance
        FROM employee_accounts e
        JOIN companies c ON c.id = e.company_id
        WHERE c.country = ?
        GROUP BY e.department
      `)
      .all(countryId) as any[];

    return {
      generatedAt: nowIso(),
      period,
      country: { id: country?.id || countryId, name: country?.name || countryId, currency: country?.currency || 'PKR' },
      summary: {
        periodPaidRevenue,
        invoicesCount: invoices.length,
        branchesCount: branches.length,
        dealershipsCount: dealerships.length,
        totalSoldUnits: vehiclesByModel.reduce((s, m) => s + Number(m.sold_units || 0), 0),
      },
      branches,
      dealerships,
      vehiclesByModel,
      employeesSummary,
      invoices,
    };
  }

  router.get('/reports', requireCountryPermission('reports.view'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const period = ['daily', 'weekly', 'monthly', 'yearly'].includes(String(req.query.period))
      ? String(req.query.period)
      : 'monthly';
    const data = buildCountryReportData(req.auth!.country, period);
    res.json(data);
  });

  router.get('/export', requireCountryPermission('reports.export'), (req: Request, res: Response) => {
    if (!assertCountryQueryNotSpoofed(req, res)) return;
    const format = String(req.query.format || 'xlsx').toLowerCase();
    const period = ['daily', 'weekly', 'monthly', 'yearly'].includes(String(req.query.period))
      ? String(req.query.period)
      : 'monthly';
    const countryId = req.auth!.country;
    const report = buildCountryReportData(countryId, period);

    if (format === 'csv') {
      const headers = ['Invoice Number', 'Customer', 'Category', 'Currency', 'Amount', 'Status', 'Gateway', 'Issued Date'];
      const rows = report.invoices.map((inv: any) =>
        [inv.invoice_number, inv.customer_name, inv.item_category, inv.currency, inv.total_amount, inv.status, inv.payment_gateway, inv.issued_date]
          .map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`)
          .join(',')
      );
      const csv = [headers.join(','), ...rows].join('\n');
      recordCountryAction(req, 'COUNTRY_REPORT_EXPORTED_CSV', 'Country Reports', `${countryId}_${period}`, `Exported CSV (${report.invoices.length} rows)`);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="BYD_360_${countryId}_${period}_Report.csv"`);
      res.send(csv);
      return;
    }

    const wb = XLSX.utils.book_new();
    const summarySheet = XLSX.utils.json_to_sheet([
      {
        Country: `${report.country.name} (${report.country.id})`,
        Period: period.toUpperCase(),
        Currency: report.country.currency,
        GeneratedAt: report.generatedAt,
        PeriodPaidRevenue: report.summary.periodPaidRevenue,
        InvoicesCount: report.summary.invoicesCount,
        BranchesCount: report.summary.branchesCount,
        DealershipsCount: report.summary.dealershipsCount,
        TotalSoldUnits: report.summary.totalSoldUnits,
      },
    ]);
    XLSX.utils.book_append_sheet(wb, summarySheet, 'Country Summary');

    const branchesSheet = XLSX.utils.json_to_sheet(report.branches.length ? report.branches : [{ Note: 'No branches found' }]);
    XLSX.utils.book_append_sheet(wb, branchesSheet, 'Branches');

    const dealersSheet = XLSX.utils.json_to_sheet(report.dealerships.length ? report.dealerships : [{ Note: 'No dealerships found' }]);
    XLSX.utils.book_append_sheet(wb, dealersSheet, 'Dealerships');

    const invSheet = XLSX.utils.json_to_sheet(report.invoices.length ? report.invoices : [{ Note: 'No invoices in selected period' }]);
    XLSX.utils.book_append_sheet(wb, invSheet, 'Invoices & Revenue');

    const vehSheet = XLSX.utils.json_to_sheet(report.vehiclesByModel.length ? report.vehiclesByModel : [{ Note: 'No vehicle records' }]);
    XLSX.utils.book_append_sheet(wb, vehSheet, 'Vehicle Inventory');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    recordCountryAction(req, 'COUNTRY_REPORT_EXPORTED_XLSX', 'Country Reports', `${countryId}_${period}`, `Exported Excel workbook (${buf.length} bytes)`);

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="BYD_360_${countryId}_${period}_Report.xlsx"`);
    res.send(buf);
  });

  // =========================================================================
  // 11. COUNTRY ACTIVITY LOGS, ESCALATIONS & SECURITY POSTURE
  // =========================================================================
  router.get('/audit-logs', (req: Request, res: Response) => {
    const countryId = req.auth!.country;
    const activityLogs = sqlite
      .prepare('SELECT * FROM country_activity_logs WHERE country_id = ? ORDER BY created_at DESC LIMIT 80')
      .all(countryId);
    const loginHistory = sqlite
      .prepare("SELECT * FROM login_history WHERE user_id = ? AND subject_type = 'country_manager' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    const securityEvents = sqlite
      .prepare('SELECT * FROM security_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 40')
      .all(req.auth!.userId);
    const escalations = sqlite
      .prepare('SELECT * FROM country_escalation_requests WHERE country_id = ? ORDER BY created_at DESC LIMIT 40')
      .all(countryId);

    res.json({
      activityLogs,
      loginHistory,
      securityEvents,
      escalations,
      assignedPermissions: req.auth!.permissions,
      canonicalPermissions: CANONICAL_COUNTRY_MANAGER_PERMISSIONS,
    });
  });

  return router;
}
