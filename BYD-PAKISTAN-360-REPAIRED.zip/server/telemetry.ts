import { Request, Response, NextFunction } from 'express';

export interface RecordedApiError {
  timestamp: string;
  method: string;
  path: string;
  statusCode: number;
  durationMs: number;
}

const MAX_LATENCY_SAMPLES = 200;
const MAX_ERROR_SAMPLES = 50;

const telemetryState = {
  startedAt: new Date().toISOString(),
  totalApiRequests: 0,
  total4xxResponses: 0,
  total5xxResponses: 0,
  latencySamplesMs: [] as number[],
  recentErrors: [] as RecordedApiError[],
};

export function apiTelemetryMiddleware(req: Request, res: Response, next: NextFunction) {
  const startNs = process.hrtime.bigint();

  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - startNs) / 1_000_000;
    const roundedMs = Math.round(durationMs * 100) / 100;

    telemetryState.totalApiRequests += 1;
    telemetryState.latencySamplesMs.push(roundedMs);
    if (telemetryState.latencySamplesMs.length > MAX_LATENCY_SAMPLES) {
      telemetryState.latencySamplesMs.shift();
    }

    if (res.statusCode >= 500) {
      telemetryState.total5xxResponses += 1;
    } else if (res.statusCode >= 400) {
      telemetryState.total4xxResponses += 1;
    }

    if (res.statusCode >= 500 || (res.statusCode >= 400 && !req.path.includes('/auth/'))) {
      telemetryState.recentErrors.unshift({
        timestamp: new Date().toISOString(),
        method: req.method,
        path: req.originalUrl.split('?')[0],
        statusCode: res.statusCode,
        durationMs: roundedMs,
      });
      if (telemetryState.recentErrors.length > MAX_ERROR_SAMPLES) {
        telemetryState.recentErrors.pop();
      }
    }
  });

  next();
}

export function getApiTelemetrySnapshot() {
  const samples = [...telemetryState.latencySamplesMs].sort((a, b) => a - b);
  const avgLatencyMs =
    samples.length > 0
      ? Math.round((samples.reduce((sum, v) => sum + v, 0) / samples.length) * 100) / 100
      : 0;
  const p95Index = samples.length > 0 ? Math.min(samples.length - 1, Math.floor(samples.length * 0.95)) : 0;
  const p95LatencyMs = samples.length > 0 ? samples[p95Index] : 0;

  return {
    startedAt: telemetryState.startedAt,
    totalApiRequests: telemetryState.totalApiRequests,
    total4xxResponses: telemetryState.total4xxResponses,
    total5xxResponses: telemetryState.total5xxResponses,
    avgLatencyMs,
    p95LatencyMs,
    sampleSize: samples.length,
    recentErrors: telemetryState.recentErrors,
  };
}
