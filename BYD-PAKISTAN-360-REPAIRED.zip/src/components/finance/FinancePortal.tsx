import React, { useState, useEffect } from 'react';
import {
  FinanceTransaction,
  BankTransaction,
  TaxRecord,
  DealerPayment,
  CustomerPayment,
  FinancialStatement,
  FinanceTransactionType,
  FinanceCategory,
  PaymentMethod,
  TransactionStatus,
  CurrencyCode,
} from '../../types';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';

export const FinancePortal: React.FC = () => {
  const { currentUser, currentRole, formatPrice } = useApp();
  const [transactions, setTransactions] = useState<FinanceTransaction[]>([]);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>([]);
  const [dealerPayments, setDealerPayments] = useState<DealerPayment[]>([]);
  const [customerPayments, setCustomerPayments] = useState<CustomerPayment[]>([]);
  const [taxRecords, setTaxRecords] = useState<TaxRecord[]>([]);
  const [statements, setStatements] = useState<FinancialStatement[]>([]);
  const [activeSection, setActiveSection] = useState<string>('dashboard');

  useEffect(() => {
    setTransactions(db.getFinanceTransactions());
    setBankTransactions(db.getBankTransactions());
    setDealerPayments(db.getDealerPayments());
    setCustomerPayments(db.getCustomerPayments());
    setTaxRecords(db.getTaxRecords());
    setStatements(db.getFinancialStatements());
  }, []);

  const totalIncome = transactions.filter((t) => t.type === 'INCOME').reduce((sum, t) => sum + t.amountPkr, 0);
  const totalExpense = transactions.filter((t) => t.type === 'EXPENSE').reduce((sum, t) => sum + t.amountPkr, 0);
  const netProfit = totalIncome - totalExpense;

  const StatCard = ({ title, value, icon, color, change }: { title: string; value: string; icon: React.ReactNode; color: string; change?: string }) => (
    <div className={`bg-white p-6 rounded-xl shadow-sm border border-gray-100`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
          {change && <p className={`text-xs font-medium ${change.startsWith('-') ? 'text-red-500' : 'text-green-500'}`}>{change}</p>}
        </div>
        <div className={`w-12 h-12 rounded-lg ${color} flex items-center justify-center`}>{icon}</div>
      </div>
    </div>
  );

  const DashboardView = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Total Income" value={formatPrice(totalIncome)} icon={<span className="text-green-600">▲</span>} color="bg-green-50" change={`+${formatPrice(totalIncome)}`} />
        <StatCard title="Total Expenses" value={formatPrice(totalExpense)} icon={<span className="text-red-600">▼</span>} color="bg-red-50" change={`-${formatPrice(totalExpense)}`} />
        <StatCard title="Net Profit" value={formatPrice(netProfit)} icon={<span className="text-blue-600">$</span>} color="bg-blue-50" change={netProfit >= 0 ? '+Profit' : '-Loss'} />
      </div>
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Transactions</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Description</th>
                <th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.slice(0, 10).map((tx) => (
                <tr key={tx.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{tx.transactionDate}</td>
                  <td className="py-3">{tx.description}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${tx.type === 'INCOME' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{tx.type}</span></td>
                  <td className="py-3 font-medium">{formatPrice(tx.amountPkr)}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${tx.status === 'Verified' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{tx.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const IncomeExpenseView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Income & Expense Tracking</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Income Transactions</h4>
            <div className="space-y-3">
              {transactions.filter((t) => t.type === 'INCOME').map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{tx.description}</p>
                    <p className="text-xs text-gray-500">{tx.category} • {tx.transactionDate}</p>
                  </div>
                  <span className="font-semibold text-green-700">+{formatPrice(tx.amountPkr)}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-gray-700 mb-3">Expense Transactions</h4>
            <div className="space-y-3">
              {transactions.filter((t) => t.type === 'EXPENSE').map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{tx.description}</p>
                    <p className="text-xs text-gray-500">{tx.category} • {tx.transactionDate}</p>
                  </div>
                  <span className="font-semibold text-red-700">-{formatPrice(tx.amountPkr)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const BranchExpensesView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Branch Expenses</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Branch</th>
                <th className="pb-3 font-medium">Category</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.filter((t) => t.type === 'EXPENSE').map((tx) => (
                <tr key={tx.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{tx.branchId || 'Head Office'}</td>
                  <td className="py-3">{tx.category}</td>
                  <td className="py-3 font-medium text-red-600">-{formatPrice(tx.amountPkr)}</td>
                  <td className="py-3">{tx.transactionDate}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${tx.status === 'Verified' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{tx.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const DealerPaymentsView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Dealer Payments</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Dealer</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Method</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {dealerPayments.map((dp) => (
                <tr key={dp.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{dp.dealerName}</td>
                  <td className="py-3 font-medium">{formatPrice(dp.amountPkr)}</td>
                  <td className="py-3">{dp.paymentMethod}</td>
                  <td className="py-3">{dp.paymentDate}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${dp.status === 'Verified' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{dp.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const CustomerPaymentsView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Customer Payments</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Customer</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Method</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {customerPayments.map((cp) => (
                <tr key={cp.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{cp.customerName}</td>
                  <td className="py-3 font-medium">{formatPrice(cp.amountPkr)}</td>
                  <td className="py-3">{cp.paymentMethod}</td>
                  <td className="py-3">{cp.paymentDate}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${cp.status === 'Verified' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{cp.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const BankTransactionsView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Bank Transactions</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Bank</th>
                <th className="pb-3 font-medium">Account</th>
                <th className="pb-3 font-medium">Type</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Reference</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {bankTransactions.map((bt) => (
                <tr key={bt.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{bt.bankName}</td>
                  <td className="py-3">{bt.accountNumberMasked}</td>
                  <td className="py-3">{bt.transactionType}</td>
                  <td className="py-3 font-medium">{formatPrice(bt.amountPkr)}</td>
                  <td className="py-3">{bt.referenceNumber}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${bt.status === 'Cleared' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{bt.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const TaxRecordsView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Tax Records</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Tax Type</th>
                <th className="pb-3 font-medium">Amount</th>
                <th className="pb-3 font-medium">Period</th>
                <th className="pb-3 font-medium">Filing Date</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {taxRecords.map((tr) => (
                <tr key={tr.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{tr.taxType}</td>
                  <td className="py-3 font-medium">{formatPrice(tr.taxAmountPkr)}</td>
                  <td className="py-3">{tr.filingPeriod}</td>
                  <td className="py-3">{tr.filingDate || '-'}</td>
                  <td className="py-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${tr.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{tr.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const ProfitLossView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Profit & Loss Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-green-50 rounded-xl">
            <p className="text-sm text-green-700 font-medium">Total Income</p>
            <h3 className="text-2xl font-bold text-green-900">{formatPrice(totalIncome)}</h3>
          </div>
          <div className="p-4 bg-red-50 rounded-xl">
            <p className="text-sm text-red-700 font-medium">Total Expenses</p>
            <h3 className="text-2xl font-bold text-red-900">{formatPrice(totalExpense)}</h3>
          </div>
          <div className="p-4 bg-blue-50 rounded-xl">
            <p className={`text-sm font-medium ${netProfit >= 0 ? 'text-green-700' : 'text-red-700'}`}>Net Profit / Loss</p>
            <h3 className={`text-2xl font-bold ${netProfit >= 0 ? 'text-green-900' : 'text-red-900'}`}>{formatPrice(Math.abs(netProfit))}</h3>
          </div>
        </div>
      </div>
    </div>
  );

  const FinancialStatementsView = () => (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Financial Statements</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500">
                <th className="pb-3 font-medium">Statement Type</th>
                <th className="pb-3 font-medium">Period</th>
                <th className="pb-3 font-medium">Generated Date</th>
                <th className="pb-3 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {statements.map((st) => (
                <tr key={st.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-3">{st.statementType}</td>
                  <td className="py-3">{st.periodStart} to {st.periodEnd}</td>
                  <td className="py-3">{st.generatedAt}</td>
                  <td className="py-3">
                    <button className="text-cyan-600 hover:text-cyan-800 text-sm font-medium">Download PDF</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'income-expense', label: 'Income & Expense', icon: '💰' },
    { id: 'branch-expenses', label: 'Branch Expenses', icon: '🏢' },
    { id: 'dealer-payments', label: 'Dealer Payments', icon: '🤝' },
    { id: 'customer-payments', label: 'Customer Payments', icon: '👥' },
    { id: 'bank-transactions', label: 'Bank Transactions', icon: '🏦' },
    { id: 'tax-records', label: 'Tax Records', icon: '🧾' },
    { id: 'profit-loss', label: 'Profit & Loss', icon: '📈' },
    { id: 'financial-statements', label: 'Financial Statements', icon: '📄' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Finance & Accounting</h1>
          <p className="text-gray-500">Manage company income, expenses, payments, taxes, and financial reports.</p>
        </div>
        <div className="flex gap-2">
          <button className="bg-cyan-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-cyan-700 transition">
            Add Transaction
          </button>
          <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-300 transition">
            Export Excel
          </button>
        </div>
      </div>

      <div className="flex gap-4">
        <nav className="w-64 flex-shrink-0 bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${activeSection === item.id ? 'bg-cyan-100 text-cyan-700' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                <span>{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>
        </nav>

        <main className="flex-1">
          {activeSection === 'dashboard' && <DashboardView />}
          {activeSection === 'income-expense' && <IncomeExpenseView />}
          {activeSection === 'branch-expenses' && <BranchExpensesView />}
          {activeSection === 'dealer-payments' && <DealerPaymentsView />}
          {activeSection === 'customer-payments' && <CustomerPaymentsView />}
          {activeSection === 'bank-transactions' && <BankTransactionsView />}
          {activeSection === 'tax-records' && <TaxRecordsView />}
          {activeSection === 'profit-loss' && <ProfitLossView />}
          {activeSection === 'financial-statements' && <FinancialStatementsView />}
        </main>
      </div>
    </div>
  );
};

export default FinancePortal;