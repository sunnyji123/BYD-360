import React, { useState, useEffect, useCallback } from 'react';
import { Lock, Shield, Save, CheckCircle2, AlertTriangle } from 'lucide-react';
import { api } from '../../services/api';

interface RbacCell {
  role_key: string;
  module_key: string;
  can_view: number;
  can_create: number;
  can_edit: number;
  can_delete: number;
  can_approve: number;
  is_locked: number;
  updated_by?: string;
  updated_at?: string;
}

export const OwnerPermissionsMatrix: React.FC<{ onSaved?: () => void }> = ({ onSaved }) => {
  const [roles, setRoles] = useState<string[]>([]);
  const [modules, setModules] = useState<string[]>([]);
  const [matrix, setMatrix] = useState<RbacCell[]>([]);
  const [roleSummaries, setRoleSummaries] = useState<any[]>([]);
  const [selectedRole, setSelectedRole] = useState<string>('Super Admin');
  const [dirtyMap, setDirtyMap] = useState<Record<string, RbacCell>>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [banner, setBanner] = useState('');
  const [error, setError] = useState('');

  const loadRbac = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getOwnerRbacOverview();
      setRoles(res.roles);
      setModules(res.modules);
      setMatrix(res.matrix);
      setRoleSummaries(res.roleSummaries);
      setDirtyMap({});
    } catch (err: any) {
      setError(err.message || 'Unable to load system-wide permissions.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRbac();
  }, [loadRbac]);

  const toggleFlag = (cell: RbacCell, field: 'can_view' | 'can_create' | 'can_edit' | 'can_delete' | 'can_approve') => {
    if (cell.role_key === 'Founder / CEO' || cell.is_locked === 1) return;
    const key = `${cell.role_key}::${cell.module_key}`;
    const current = dirtyMap[key] || cell;
    const updated: RbacCell = {
      ...current,
      [field]: current[field] === 1 ? 0 : 1,
    };
    setDirtyMap((prev) => ({ ...prev, [key]: updated }));
  };

  const handleSave = async () => {
    const entries = Object.values(dirtyMap);
    if (entries.length === 0) return;
    setSaving(true);
    setError('');
    setBanner('');
    try {
      const res = await api.updateOwnerRbacOverview(
        entries.map((c) => ({
          roleKey: c.role_key,
          moduleKey: c.module_key,
          canView: c.can_view === 1,
          canCreate: c.can_create === 1,
          canEdit: c.can_edit === 1,
          canDelete: c.can_delete === 1,
          canApprove: c.can_approve === 1,
        }))
      );
      setBanner(`Saved ${res.updatedCount} verified role-module permission rules to database.`);
      await loadRbac();
      onSaved?.();
    } catch (err: any) {
      setError(err.message || 'Failed to update permissions.');
    } finally {
      setSaving(false);
    }
  };

  const roleCells = modules.map((mod) => {
    const base = matrix.find((m) => m.role_key === selectedRole && m.module_key === mod);
    if (!base) return null;
    const key = `${selectedRole}::${mod}`;
    return dirtyMap[key] || base;
  }).filter(Boolean) as RbacCell[];

  const dirtyCount = Object.keys(dirtyMap).length;

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>Centralized System-Wide Permissions Matrix (6 Enterprise Roles)</span>
            </h3>
            <p className="text-xs text-slate-400">
              Backend-enforced RBAC across Modules, Financial Access, Reports Access &amp; Administrative Operations. Founder / CEO privileges are cryptographically locked against downgrade.
            </p>
          </div>
          {dirtyCount > 0 && (
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : `Commit ${dirtyCount} RBAC Updates`}</span>
            </button>
          )}
        </div>

        {banner && (
          <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-700 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{banner}</span>
          </div>
        )}
        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-xs text-rose-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Role Capability Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {roleSummaries.map((rs) => {
            const active = selectedRole === rs.roleKey;
            return (
              <button
                key={rs.roleKey}
                type="button"
                onClick={() => setSelectedRole(rs.roleKey)}
                className={`p-4 rounded-xl border text-left transition space-y-2 ${
                  active
                    ? 'bg-amber-500/10 border-amber-500/50'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-bold text-white flex items-center gap-1.5">
                    {rs.immutable && <Lock className="w-3.5 h-3.5 text-amber-400" />}
                    {rs.roleKey}
                  </span>
                  <span className="text-[11px] font-mono text-cyan-300">
                    {rs.moduleAccessCount}/{rs.totalModules} Modules
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
                  <span className={`px-2 py-0.5 rounded ${rs.financialAccess ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-900 text-slate-500'}`}>
                    Finance: {rs.financialAccess ? 'YES' : 'NO'}
                  </span>
                  <span className={`px-2 py-0.5 rounded ${rs.reportsAccess ? 'bg-cyan-950 text-cyan-300' : 'bg-slate-900 text-slate-500'}`}>
                    Reports: {rs.reportsAccess ? 'YES' : 'NO'}
                  </span>
                  <span className={`px-2 py-0.5 rounded ${rs.administrativeAccess ? 'bg-amber-950 text-amber-300' : 'bg-slate-900 text-slate-500'}`}>
                    Admin: {rs.administrativeAccess ? 'YES' : 'NO'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Role Detailed Module Matrix */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-white">
            Permissions for Role: <span className="text-amber-300">{selectedRole}</span>
          </h4>
          {selectedRole === 'Founder / CEO' && (
            <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
              <Lock className="w-3.5 h-3.5" /> Immutable Root Protection Active
            </span>
          )}
        </div>

        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400">Loading database RBAC matrix...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Enterprise Module</th>
                  <th className="py-2.5 px-3 text-center">View</th>
                  <th className="py-2.5 px-3 text-center">Create</th>
                  <th className="py-2.5 px-3 text-center">Edit</th>
                  <th className="py-2.5 px-3 text-center">Delete</th>
                  <th className="py-2.5 px-3 text-center">Approve</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {roleCells.map((cell) => {
                  const locked = cell.role_key === 'Founder / CEO' || cell.is_locked === 1;
                  return (
                    <tr key={cell.module_key} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-3 font-semibold text-white">{cell.module_key}</td>
                      {(['can_view', 'can_create', 'can_edit', 'can_delete', 'can_approve'] as const).map((field) => {
                        const checked = cell[field] === 1;
                        return (
                          <td key={field} className="py-2.5 px-3 text-center">
                            <button
                              type="button"
                              disabled={locked}
                              onClick={() => toggleFlag(cell, field)}
                              className={`w-8 h-6 rounded-md text-[10px] font-mono font-bold border transition ${
                                checked
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                                  : 'bg-slate-950 text-slate-500 border-slate-800'
                              } ${locked ? 'opacity-70 cursor-not-allowed' : 'hover:border-amber-400'}`}
                            >
                              {checked ? '✓' : '—'}
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
