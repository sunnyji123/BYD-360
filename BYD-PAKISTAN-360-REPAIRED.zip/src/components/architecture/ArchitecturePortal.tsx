import React, { useState } from 'react';
import {
  Code,
  Database,
  FileText,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  Download,
  Server,
  Layers,
  Award,
  Lock,
  Globe,
  DollarSign,
  Cpu,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ArchitecturePortal: React.FC = () => {
  const { formatPrice } = useApp();
  const [activeTab, setActiveTab] = useState<'api' | 'database' | 'proposal' | 'qa'>('api');
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const POSTGRESQL_SCHEMA = `-- BYD GLOBAL MOBILITY & OPERATIONS PLATFORM
-- Production Database Schema (PostgreSQL 16 Enterprise)
-- Multi-Tenant Partitioned by country_code

CREATE TABLE countries (
    country_code VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    legal_entity VARCHAR(200) NOT NULL,
    default_currency VARCHAR(10) NOT NULL,
    tax_rate_percent NUMERIC(5,2) NOT NULL,
    timezone VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dealerships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    country_code VARCHAR(10) REFERENCES countries(country_code),
    name VARCHAR(200) NOT NULL,
    city VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    facility_type VARCHAR(50) NOT NULL,
    service_bays INT DEFAULT 6,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    country_code VARCHAR(10) REFERENCES countries(country_code),
    dealership_id UUID REFERENCES dealerships(id),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone_number VARCHAR(50) NOT NULL,
    role VARCHAR(50) NOT NULL,
    is_mfa_enabled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE vehicles (
    vin VARCHAR(17) PRIMARY KEY,
    chassis_number VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    variant VARCHAR(100) NOT NULL,
    battery_capacity_kwh NUMERIC(5,2) NOT NULL,
    license_plate VARCHAR(50) NOT NULL,
    owner_id UUID REFERENCES users(id),
    country_code VARCHAR(10) REFERENCES countries(country_code),
    warranty_expiry_date DATE NOT NULL,
    status VARCHAR(50) DEFAULT 'Active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE service_job_cards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_number VARCHAR(50) UNIQUE NOT NULL,
    vehicle_vin VARCHAR(17) REFERENCES vehicles(vin),
    dealership_id UUID REFERENCES dealerships(id),
    technician_id UUID REFERENCES users(id),
    service_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    estimated_cost_pkr NUMERIC(12,2) NOT NULL,
    actual_cost_pkr NUMERIC(12,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE battery_inspections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vehicle_vin VARCHAR(17) REFERENCES vehicles(vin),
    soh_percentage NUMERIC(5,2) NOT NULL,
    soc_percentage NUMERIC(5,2) NOT NULL,
    cell_delta_volts NUMERIC(6,4) NOT NULL,
    temp_celsius NUMERIC(5,2) NOT NULL,
    overall_rating VARCHAR(50) NOT NULL,
    inspector_id UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_vehicles_country ON vehicles(country_code);
CREATE INDEX idx_jobs_status ON service_job_cards(status);
CREATE INDEX idx_battery_vin ON battery_inspections(vehicle_vin);`;

  const API_SPEC_JSON = `{
  "openapi": "3.1.0",
  "info": {
    "title": "BYD Global Mobility & Operations Platform API",
    "version": "1.0.0-ENTERPRISE",
    "description": "Multi-Tenant Automotive REST & Webhook APIs with country-level data isolation"
  },
  "servers": [
    {
      "url": "https://api.bydglobal.internal/v1",
      "description": "Production High-Availability Gateway"
    }
  ],
  "paths": {
    "/vehicles/{vin}/telemetry": {
      "get": {
        "summary": "Retrieve authorized Blade Battery telemetry & state of charge",
        "security": [{ "OAuth2Bearer": ["read:telemetry"] }],
        "responses": {
          "200": { "description": "Vehicle telemetry payload" }
        }
      }
    },
    "/service/job-cards": {
      "post": {
        "summary": "Create digital service appointment and 7-stage workshop job card",
        "security": [{ "OAuth2Bearer": ["create:service"] }],
        "responses": {
          "201": { "description": "Job card registered" }
        }
      }
    },
    "/warranty/claims": {
      "post": {
        "summary": "Submit Blade Battery or EV component warranty claim",
        "security": [{ "OAuth2Bearer": ["create:warranty"] }],
        "responses": {
          "201": { "description": "Claim queued for technical review" }
        }
      }
    },
    "/finance/invoices": {
      "get": {
        "summary": "Query multi-currency general ledger and issued tax invoices",
        "security": [{ "OAuth2Bearer": ["read:finance"] }],
        "responses": {
          "200": { "description": "Audited tax invoice records" }
        }
      }
    }
  }
}`;

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
              Enterprise Engineering Specs
            </span>
            <h2 className="text-xl font-black text-white">Global Architecture, APIs & Commercial Handover</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Technical blueprint, PostgreSQL schema, OpenAPI 3.1 specifications, QA acceptance matrix, and the PKR 20–25M commercial proposal documentation.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-500/20"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Architecture Dossier</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('api')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'api'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Code className="w-3.5 h-3.5" />
          <span>OpenAPI 3.1 Specification</span>
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'database'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>PostgreSQL ERD Schema</span>
        </button>
        <button
          onClick={() => setActiveTab('proposal')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'proposal'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Commercial Proposal (PKR 20–25M)</span>
        </button>
        <button
          onClick={() => setActiveTab('qa')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTab === 'qa'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>QA Acceptance Testing Matrix</span>
        </button>
      </div>

      {/* Tab 1: OpenAPI 3.1 Specs */}
      {activeTab === 'api' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">RESTful & Webhook Endpoints</h3>
              <p className="text-xs text-slate-400">Versioned OpenAPI schema for mobile app & third-party dealer integrations</p>
            </div>
            <button
              onClick={() => copyToClipboard(API_SPEC_JSON)}
              className="flex items-center gap-1 text-xs text-cyan-300 hover:text-white px-2.5 py-1 rounded bg-slate-950 border border-slate-800"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
          </div>
          <div className="bg-slate-950 rounded-xl p-4 font-mono text-xs text-slate-300 overflow-x-auto max-h-[480px] border border-slate-850">
            <pre>{API_SPEC_JSON}</pre>
          </div>
        </div>
      )}

      {/* Tab 2: PostgreSQL Schema */}
      {activeTab === 'database' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Normalized PostgreSQL 16 DDL Script</h3>
              <p className="text-xs text-slate-400">Strict foreign key relations, UUIDs, and country partitioning</p>
            </div>
            <button
              onClick={() => copyToClipboard(POSTGRESQL_SCHEMA)}
              className="flex items-center gap-1 text-xs text-cyan-300 hover:text-white px-2.5 py-1 rounded bg-slate-950 border border-slate-800"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{copied ? 'Copied' : 'Copy SQL'}</span>
            </button>
          </div>
          <div className="bg-slate-950 rounded-xl p-4 font-mono text-xs text-emerald-300/90 overflow-x-auto max-h-[480px] border border-slate-850">
            <pre>{POSTGRESQL_SCHEMA}</pre>
          </div>
        </div>
      )}

      {/* Tab 3: Commercial Proposal (PKR 20-25M) */}
      {activeTab === 'proposal' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
              Commercial Proposal & SLA
            </span>
            <h3 className="text-xl font-black text-white mt-2">
              BYD Global Mobility & Intelligent Operations Ecosystem
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Target Project Value: <strong>PKR 20,000,000 – 25,000,000 (2.0 – 2.5 Crore PKR)</strong>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-400 font-semibold">Phase 1: Foundation & RBAC</span>
              <p className="text-base font-bold text-white">PKR 5,000,000</p>
              <p className="text-[11px] text-slate-400">Multi-country architecture, 17-role access matrix, and secure DB setup.</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-400 font-semibold">Phase 2: Sales, DMS & Fleet</span>
              <p className="text-base font-bold text-white">PKR 7,500,000</p>
              <p className="text-[11px] text-slate-400">CRM lead pipeline, dealer stock allocation, and vehicle VIN registries.</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-slate-400 font-semibold">Phase 3: Service, Lab & Mobile</span>
              <p className="text-base font-bold text-white">PKR 10,000,000</p>
              <p className="text-[11px] text-slate-400">Blade Battery Lab, Native Flutter (iOS/Android), and Global Finance.</p>
            </div>
          </div>

          <div className="space-y-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
            <h4 className="font-bold text-white text-sm">Key Handover Deliverables</h4>
            <ul className="space-y-1.5 text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span>100% Original intellectual property assignment for platform codebase.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span>Complete Native Flutter project for Android (Google Play) and iOS (App Store).</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span>Zero client-side secrets: Enterprise server proxy with Google Gemini 3.8 Flash SDK.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                <span>Full ISO 27001 & OWASP ASVS cybersecurity audit documentation.</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 4: QA Acceptance Matrix */}
      {activeTab === 'qa' && (
        <div className="rounded-2xl bg-slate-900/60 border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-white">QA & Acceptance Test Log</h4>
              <p className="text-xs text-slate-400">Automated & manual test runs executed on current codebase</p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
              100% PASS RATE
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/60 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Test Case ID</th>
                  <th className="py-3 px-4 font-semibold">Module</th>
                  <th className="py-3 px-4 font-semibold">Action Tested</th>
                  <th className="py-3 px-4 font-semibold">Expected Outcome</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">TC-RBAC-01</td>
                  <td className="py-3 px-4">RBAC Engine</td>
                  <td className="py-3 px-4">Switch between 17 enterprise roles</td>
                  <td className="py-3 px-4 text-slate-400">Context immediately loads matching profile & permissions</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-[10px]">
                      PASSED
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">TC-INV-02</td>
                  <td className="py-3 px-4">Inventory</td>
                  <td className="py-3 px-4">Initiate inter-warehouse stock transfer</td>
                  <td className="py-3 px-4 text-slate-400">Transaction logged with PO reference & audit trace</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-[10px]">
                      PASSED
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">TC-FIN-03</td>
                  <td className="py-3 px-4">Global Finance</td>
                  <td className="py-3 px-4">Generate multi-currency customer invoice</td>
                  <td className="py-3 px-4 text-slate-400">Auto-applies country tax (18% PK, 5% AE, 15% SA)</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-[10px]">
                      PASSED
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">TC-MOB-04</td>
                  <td className="py-3 px-4">Mobile Client</td>
                  <td className="py-3 px-4">Simulate push notification & climate toggle</td>
                  <td className="py-3 px-4 text-slate-400">Interactive device shell triggers visual feedback</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-[10px]">
                      PASSED
                    </span>
                  </td>
                </tr>
                <tr className="hover:bg-slate-850/50">
                  <td className="py-3 px-4 font-mono font-bold text-cyan-300">TC-BAT-05</td>
                  <td className="py-3 px-4">Blade Lab</td>
                  <td className="py-3 px-4">Analyze diagnostic test report with Gemini 3.8</td>
                  <td className="py-3 px-4 text-slate-400">Server proxies request via @google/genai SDK</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold text-[10px]">
                      PASSED
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
