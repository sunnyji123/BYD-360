import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  RotateCcw,
  Plus,
  Trash2,
  Copy,
  Check,
  Paperclip,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  AlertCircle,
  MessageSquare,
  FileText,
  X,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  attachmentName?: string;
  isError?: boolean;
}

const SUGGESTED_PROMPTS = [
  { label: 'Live Business Intelligence', text: 'Summarize my currently authorized BYD operations, fleet inventory, service jobs, and revenue metrics.' },
  { label: 'Blade Battery Safety', text: 'Explain BYD Blade Battery safety and why it passes the nail penetration test without thermal runaway.' },
  { label: 'M-2 Highway Corridor', text: 'Can a BYD Seal complete Lahore to Islamabad via the M-2 motorway on one charge? What charging options exist?' },
  { label: 'Urdu EV Advisory (اردو)', text: 'اردو میں بتائیں: بی وائی ڈی بلیڈ بیٹری شدید گرمی میں کیسے محفوظ رہتی ہے اور وارنٹی کیا ہے؟' },
  { label: 'Roman Urdu Quick Help', text: 'Roman Urdu mein batayein ke BYD Atto 3 ki range aur charging time kya hai?' },
];

export const AIAssistant: React.FC = () => {
  const { currentRole, currentUser, isAuthenticated, openAuthModal } = useApp();

  const [aiStatus, setAiStatus] = useState<{
    configured: boolean;
    enabled: boolean;
    model: string;
    allowDocumentAnalysis: boolean;
    allowVoiceAssistant: boolean;
    statusReason: string;
  } | null>(null);

  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      text: `Welcome to **BYD AI**! I am your official enterprise automotive and operations intelligence assistant.\n\nSign in to enable persistent conversation history, authorized Business Intelligence queries over live database records, and Document Analysis (PDF, DOCX, XLSX, CSV, Images). Available in **English, اردو, and Roman Urdu**.`,
      timestamp: 'Ready',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [voiceLang, setVoiceLang] = useState<'en-US' | 'ur-PK'>('en-US');
  const [listening, setListening] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadAiStatus = useCallback(async () => {
    try {
      const st = await api.getAiStatus();
      setAiStatus(st);
    } catch {
      // ignore
    }
  }, []);

  const loadConversations = useCallback(async () => {
    if (!isAuthenticated) {
      setConversations([]);
      return;
    }
    try {
      const res = await api.getAiConversations();
      setConversations(res.conversations || []);
    } catch {
      // ignore
    }
  }, [isAuthenticated]);

  useEffect(() => {
    loadAiStatus();
    loadConversations();
  }, [loadAiStatus, loadConversations, currentUser.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSelectConversation = async (convId: string) => {
    try {
      const res = await api.getAiConversationMessages(convId);
      setActiveConvId(convId);
      setMessages(
        (res.messages || []).map((m: any) => ({
          id: m.id,
          sender: m.sender,
          text: m.content,
          attachmentName: m.attachment_name,
          timestamp: m.created_at?.slice(11, 16) || '',
        }))
      );
    } catch (err: any) {
      setMessages([
        {
          id: `err_${Date.now()}`,
          sender: 'assistant',
          text: err.message || 'Unable to load conversation.',
          timestamp: 'Error',
          isError: true,
        },
      ]);
    }
  };

  const handleNewConversation = () => {
    setActiveConvId(null);
    setSelectedFile(null);
    setMessages([
      {
        id: `msg_new_${Date.now()}`,
        sender: 'assistant',
        text: `New **BYD AI** conversation started${isAuthenticated ? ` for **${currentUser.name}** (${currentRole})` : ''}. Ask a technical, charging, or authorized business intelligence question below.`,
        timestamp: 'Now',
      },
    ]);
  };

  const handleDeleteConversation = async (convId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await api.deleteAiConversation(convId);
      setConversations((prev) => prev.filter((c) => c.id !== convId));
      if (activeConvId === convId) {
        handleNewConversation();
      }
    } catch {
      // ignore
    }
  };

  const handleClearCurrentChat = async () => {
    if (activeConvId && isAuthenticated) {
      await api.clearAiConversation(activeConvId).catch(() => {});
    }
    setMessages([
      {
        id: `clr_${Date.now()}`,
        sender: 'assistant',
        text: 'Chat cleared. How can BYD AI assist you next?',
        timestamp: 'Just now',
      },
    ]);
  };

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputPrompt).trim();
    if ((!text && !selectedFile) || loading) return;

    const promptText = text || `Analyze uploaded document "${selectedFile?.name}"`;
    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: promptText,
      attachmentName: selectedFile?.name,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    const fileToSend = selectedFile;
    setSelectedFile(null);
    setLoading(true);

    try {
      if (fileToSend) {
        const res = await api.uploadAndAnalyzeDocument(fileToSend, promptText, activeConvId);
        if (res.conversationId) {
          setActiveConvId(res.conversationId);
          loadConversations();
        }
        setMessages((prev) => [
          ...prev,
          {
            id: `ast_${Date.now()}`,
            sender: 'assistant',
            text: res.analysis,
            attachmentName: res.fileName,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        const res = await api.sendChatMessage(promptText, currentRole, {
          conversationId: activeConvId,
          language: voiceLang === 'ur-PK' ? 'Urdu / Roman Urdu' : 'auto',
        });
        if (res.conversationId) {
          setActiveConvId(res.conversationId);
          loadConversations();
        }
        setMessages((prev) => [
          ...prev,
          {
            id: `ast_${Date.now()}`,
            sender: 'assistant',
            text: res.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          sender: 'assistant',
          text: `**BYD AI Error:** ${err.message || 'Failed to reach Gemini API on the server.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isError: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const toggleVoiceInput = () => {
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      setMessages((prev) => [
        ...prev,
        {
          id: `voice_err_${Date.now()}`,
          sender: 'assistant',
          text: 'Voice input (Web Speech API) is not supported in this browser.',
          timestamp: 'Notice',
          isError: true,
        },
      ]);
      return;
    }
    const rec = new SpeechRec();
    rec.lang = voiceLang;
    rec.interimResults = false;
    rec.onresult = (ev: any) => {
      const transcript = ev.results?.[0]?.[0]?.transcript || '';
      setInputPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
    };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    setListening(true);
    rec.start();
  };

  const toggleSpeak = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_]/g, '');
    const utter = new SpeechSynthesisUtterance(cleanText);
    utter.lang = /[\u0600-\u06FF]/.test(cleanText) ? 'ur-PK' : voiceLang;
    utter.onend = () => setSpeakingId(null);
    utter.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="space-y-5 pb-12 max-w-6xl mx-auto">
      {/* Header Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              Enterprise Intelligence Engine
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                aiStatus?.configured && aiStatus?.enabled
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                  : 'bg-rose-950 text-rose-300 border-rose-800'
              }`}
            >
              {aiStatus?.configured && aiStatus?.enabled
                ? `LIVE GEMINI (${aiStatus.model})`
                : aiStatus?.configured === false
                ? 'SERVER GEMINI_API_KEY NOT CONFIGURED'
                : 'BYD AI DISABLED BY OWNER'}
            </span>
          </div>
          <h2 className="text-2xl font-black text-white mt-1">BYD AI — Automotive &amp; Business Intelligence</h2>
          <p className="text-xs text-slate-400">
            Role-scoped Business Intelligence, Document Analysis (PDF/DOCX/XLSX/CSV/Image) &amp; English/Urdu Voice Assistant
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setVoiceLang((l) => (l === 'en-US' ? 'ur-PK' : 'en-US'))}
            className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-950 text-xs font-semibold text-cyan-300"
          >
            Voice Lang: {voiceLang === 'en-US' ? 'English' : 'اردو (Urdu)'}
          </button>
          <button
            onClick={handleNewConversation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Chat</span>
          </button>
          <button
            onClick={handleClearCurrentChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-800 bg-slate-950 text-slate-300 hover:text-white text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Honest Server Configuration Warning */}
      {aiStatus && (!aiStatus.configured || !aiStatus.enabled) && (
        <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-3">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong>BYD AI Connectivity Status:</strong> {aiStatus.statusReason} Live responses require a valid server-side <code className="px-1 py-0.5 bg-slate-900 rounded">GEMINI_API_KEY</code> and Owner activation.
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Conversation History Sidebar */}
        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-3 h-fit">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
              <span>Conversations</span>
            </span>
            {isAuthenticated && (
              <span className="text-[10px] text-slate-500">{conversations.length} Saved</span>
            )}
          </div>

          {!isAuthenticated ? (
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-2">
              <p>Sign in to save conversation history, analyze documents, and query live BI metrics.</p>
              <button
                onClick={() => openAuthModal('login')}
                className="w-full py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold"
              >
                Sign In Now
              </button>
            </div>
          ) : conversations.length === 0 ? (
            <div className="text-xs text-slate-500 py-4 text-center">No saved chats yet.</div>
          ) : (
            <div className="space-y-1.5 max-h-[420px] overflow-y-auto">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => handleSelectConversation(conv.id)}
                  className={`p-2.5 rounded-xl border text-xs cursor-pointer flex items-center justify-between gap-2 transition ${
                    activeConvId === conv.id
                      ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200 font-semibold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <span className="truncate">{conv.title}</span>
                  <button
                    onClick={(e) => handleDeleteConversation(conv.id, e)}
                    className="text-slate-500 hover:text-rose-400 shrink-0"
                    title="Delete conversation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Main Chat Area */}
        <div className="lg:col-span-3 space-y-4">
          {/* Prompt Chips */}
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_PROMPTS.map((sp, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(sp.text)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-xs text-slate-300 hover:text-white flex items-center gap-1.5"
              >
                <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                <span>{sp.label}</span>
              </button>
            ))}
          </div>

          {/* Messages Box */}
          <div className="rounded-2xl bg-slate-950 border border-slate-800 p-4 sm:p-5 min-h-[420px] max-h-[520px] overflow-y-auto space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-white ${msg.isError ? 'bg-rose-600' : 'bg-gradient-to-br from-cyan-500 to-blue-600'}`}>
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-none'
                      : msg.isError
                      ? 'bg-rose-950/50 border border-rose-500/40 text-rose-200 rounded-tl-none whitespace-pre-line'
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none whitespace-pre-line'
                  }`}
                >
                  {msg.attachmentName && (
                    <div className="mb-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/30 text-[11px] font-mono text-cyan-200">
                      <FileText className="w-3 h-3" /> {msg.attachmentName}
                    </div>
                  )}
                  <div>{msg.text}</div>

                  <div className="flex items-center justify-between gap-3 mt-2 pt-1.5 border-t border-white/10 text-[10px] text-slate-400">
                    <span>{msg.timestamp}</span>
                    {msg.sender === 'assistant' && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => toggleSpeak(msg.id, msg.text)}
                          className="hover:text-cyan-300 flex items-center gap-1"
                          title="Read aloud"
                        >
                          {speakingId === msg.id ? <VolumeX className="w-3.5 h-3.5 text-amber-400" /> : <Volume2 className="w-3.5 h-3.5" />}
                          <span>{speakingId === msg.id ? 'Stop' : 'Listen'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="hover:text-cyan-300 flex items-center gap-1"
                          title="Copy response"
                        >
                          {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedId === msg.id ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center shrink-0 text-slate-300">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shrink-0 text-white animate-pulse">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-cyan-300 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>BYD AI is querying Gemini &amp; authorized company intelligence...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Selected Attachment Chip */}
          {selectedFile && (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-xs text-cyan-200">
              <FileText className="w-3.5 h-3.5" />
              <span>{selectedFile.name} ({Math.round(selectedFile.size / 1024)} KB)</span>
              <button onClick={() => setSelectedFile(null)} className="text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.xlsx,.xls,.csv,.txt,.json,.png,.jpg,.jpeg,.webp"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) setSelectedFile(f);
              }}
            />

            <button
              type="button"
              disabled={!isAuthenticated}
              onClick={() => fileInputRef.current?.click()}
              title={isAuthenticated ? 'Upload Document (PDF, DOCX, XLSX, CSV, Image)' : 'Sign in to analyze documents'}
              className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 disabled:opacity-40"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={toggleVoiceInput}
              title="Voice Input (English / Urdu)"
              className={`p-3 rounded-2xl border transition ${
                listening
                  ? 'bg-rose-600 border-rose-400 text-white animate-pulse'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-cyan-300'
              }`}
            >
              {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Ask BYD AI in English, Urdu, or Roman Urdu..."
              className="flex-1 rounded-2xl bg-slate-900 border border-slate-800 px-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />

            <button
              type="submit"
              disabled={(!inputPrompt.trim() && !selectedFile) || loading}
              className="p-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold hover:from-cyan-400 hover:to-blue-500 transition shadow-lg shadow-cyan-500/20 disabled:opacity-40"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>

          <p className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>
              BYD AI executes strictly via server-side Gemini calls scoped to your verified database permissions. Sensitive operations always require explicit confirmation.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};
