import express, { Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import {
  sqlite,
  PRIVATE_DEALER_DOCS_DIR,
  generateSecureToken,
  generateNumericOtp,
  hashPassword,
  sha256,
  validatePasswordStrength,
  generateTotpSecret,
  generateNextDealerCode,
  generateNextShowroomCode,
  logDealerModuleAudit,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  getClientIp,
  requireAuth,
  CANONICAL_DEALER_PERMISSIONS,
} from './auth';
import { buildSimplePdfBuffer, savePrivateDealerFile } from './dealer';

const ALLOWED_DOC_MIMES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
});

export interface DealershipScope {
  mode:
    | 'founder'
    | 'super_admin'
    | 'company_admin'
    | 'country_manager'
    | 'branch_manager'
    | 'employee'
    | 'dealer';
  selfOnly: boolean;
  selfDealerId: string | null;
  restrictedCompanyId: string | null;
  restrictedCountryId: string | null;
  restrictedBranchId: string | null;
  canRegisterDealers: boolean;
  canVerifyDealers: boolean;
  canManageShowrooms: boolean;
  canManageInventory: boolean;
  canTransferInventory: boolean;
  canRecordSales: boolean;
  canApproveDiscounts: boolean;
  canVerifyPayments: boolean;
  canCancelRefund: boolean;
  canManageCommissionRules: boolean;
  canApprovePayCommissions: boolean;
  canManageTargets: boolean;
  canUploadDocuments: boolean;
  canVerifyDocuments: boolean;
  canExportReports: boolean;
}

function safeJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function resolveDealershipScope(req: Request): DealershipScope | null {
  const auth = req.auth;
  if (!auth) return null;

  if (auth.subjectType === 'founder') {
    return {
      mode: 'founder',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canRegisterDealers: true,
      canVerifyDealers: true,
      canManageShowrooms: true,
      canManageInventory: true,
      canTransferInventory: true,
      canRecordSales: true,
      canApproveDiscounts: true,
      canVerifyPayments: true,
      canCancelRefund: true,
      canManageCommissionRules: true,
      canApprovePayCommissions: true,
      canManageTargets: true,
      canUploadDocuments: true,
      canVerifyDocuments: true,
      canExportReports: true,
    };
  }

  const perms = new Set(auth.permissions || []);

  if (auth.subjectType === 'super_admin') {
    const hasDealers = perms.has('dealers.manage');
    const hasReports = perms.has('reports.view') || hasDealers;
    if (!hasDealers && !perms.has('sales.view') && !perms.has('vehicles.manage') && !hasReports) {
      return null;
    }
    return {
      mode: 'super_admin',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canRegisterDealers: hasDealers,
      canVerifyDealers: hasDealers,
      canManageShowrooms: hasDealers,
      canManageInventory: hasDealers || perms.has('vehicles.manage'),
      canTransferInventory: hasDealers || perms.has('vehicles.manage'),
      canRecordSales: hasDealers,
      canApproveDiscounts: hasDealers,
      canVerifyPayments: hasDealers,
      canCancelRefund: hasDealers,
      canManageCommissionRules: hasDealers,
      canApprovePayCommissions: hasDealers,
      canManageTargets: hasDealers,
      canUploadDocuments: hasDealers,
      canVerifyDocuments: hasDealers,
      canExportReports: hasReports,
    };
  }

  if (auth.subjectType === 'company_admin' && auth.companyId) {
    const hasDealers = perms.has('dealers.manage');
    if (!hasDealers && !perms.has('sales.manage') && !perms.has('vehicles.manage') && !perms.has('reports.view')) {
      return null;
    }
    return {
      mode: 'company_admin',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canRegisterDealers: hasDealers,
      canVerifyDealers: hasDealers,
      canManageShowrooms: hasDealers,
      canManageInventory: hasDealers || perms.has('vehicles.manage'),
      canTransferInventory: hasDealers || perms.has('vehicles.manage'),
      canRecordSales: hasDealers || perms.has('sales.manage'),
      canApproveDiscounts: hasDealers || perms.has('sales.manage') || perms.has('finance.manage'),
      canVerifyPayments: hasDealers || perms.has('finance.manage'),
      canCancelRefund: hasDealers || perms.has('finance.manage'),
      canManageCommissionRules: hasDealers || perms.has('finance.manage'),
      canApprovePayCommissions: hasDealers || perms.has('finance.manage'),
      canManageTargets: hasDealers || perms.has('sales.manage'),
      canUploadDocuments: hasDealers,
      canVerifyDocuments: hasDealers,
      canExportReports: hasDealers || perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'country_manager' && auth.country) {
    const hasDealers = perms.has('dealers.manage');
    if (!hasDealers && !perms.has('vehicles.manage') && !perms.has('sales.view') && !perms.has('reports.view')) {
      return null;
    }
    return {
      mode: 'country_manager',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: null,
      restrictedCountryId: auth.country,
      restrictedBranchId: null,
      canRegisterDealers: hasDealers,
      canVerifyDealers: hasDealers,
      canManageShowrooms: hasDealers,
      canManageInventory: hasDealers || perms.has('vehicles.manage'),
      canTransferInventory: hasDealers || perms.has('vehicles.manage'),
      canRecordSales: hasDealers,
      canApproveDiscounts: hasDealers || perms.has('finance.sensitive.manage'),
      canVerifyPayments: hasDealers || perms.has('finance.sensitive.manage'),
      canCancelRefund: hasDealers || perms.has('finance.sensitive.manage'),
      canManageCommissionRules: hasDealers,
      canApprovePayCommissions: hasDealers && perms.has('finance.sensitive.manage'),
      canManageTargets: hasDealers,
      canUploadDocuments: hasDealers,
      canVerifyDocuments: hasDealers,
      canExportReports: hasDealers || perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'branch_manager' && auth.branchId && auth.companyId) {
    const hasDealers = perms.has('dealers.manage');
    if (!hasDealers && !perms.has('sales.manage') && !perms.has('vehicles.manage') && !perms.has('reports.view')) {
      return null;
    }
    return {
      mode: 'branch_manager',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: auth.country || null,
      restrictedBranchId: auth.branchId,
      canRegisterDealers: hasDealers,
      canVerifyDealers: hasDealers,
      canManageShowrooms: hasDealers,
      canManageInventory: hasDealers || perms.has('vehicles.manage'),
      canTransferInventory: hasDealers || perms.has('vehicles.manage'),
      canRecordSales: hasDealers || perms.has('sales.manage'),
      canApproveDiscounts: hasDealers,
      canVerifyPayments: hasDealers || perms.has('finance.refund.manage'),
      canCancelRefund: hasDealers && perms.has('finance.refund.manage'),
      canManageCommissionRules: false,
      canApprovePayCommissions: false,
      canManageTargets: hasDealers,
      canUploadDocuments: hasDealers,
      canVerifyDocuments: hasDealers,
      canExportReports: hasDealers || perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'employee' && auth.companyId) {
    // Only employees explicitly assigned to Dealer Operations / Sales Management may access Dealership Management
    const roleLower = `${auth.role} ${auth.department || ''}`.toLowerCase();
    const isDealerOpsEmp =
      perms.has('dealers.manage') ||
      roleLower.includes('dealer') ||
      roleLower.includes('dealership') ||
      roleLower.includes('network');
    if (!isDealerOpsEmp) return null;
    const isLead = roleLower.includes('manager') || roleLower.includes('head') || roleLower.includes('lead');
    return {
      mode: 'employee',
      selfOnly: false,
      selfDealerId: null,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: auth.country || null,
      restrictedBranchId: auth.branchId || null,
      canRegisterDealers: isLead,
      canVerifyDealers: false,
      canManageShowrooms: isLead,
      canManageInventory: true,
      canTransferInventory: isLead,
      canRecordSales: true,
      canApproveDiscounts: false,
      canVerifyPayments: false,
      canCancelRefund: false,
      canManageCommissionRules: false,
      canApprovePayCommissions: false,
      canManageTargets: isLead,
      canUploadDocuments: true,
      canVerifyDocuments: false,
      canExportReports: isLead,
    };
  }

  if (auth.subjectType === 'dealer' && auth.dealerId) {
    return {
      mode: 'dealer',
      selfOnly: true,
      selfDealerId: auth.dealerId,
      restrictedCompanyId: auth.companyId || null,
      restrictedCountryId: auth.country || null,
      restrictedBranchId: auth.branchId || null,
      canRegisterDealers: false,
      canVerifyDealers: false,
      canManageShowrooms: true,
      canManageInventory: perms.has('dealer.inventory.view') || true,
      canTransferInventory: false,
      canRecordSales: true,
      canApproveDiscounts: false,
      canVerifyPayments: false,
      canCancelRefund: false,
      canManageCommissionRules: false,
      canApprovePayCommissions: false,
      canManageTargets: false,
      canUploadDocuments: perms.has('dealer.documents.manage') || true,
      canVerifyDocuments: false,
      canExportReports: perms.has('dealer.reports.export') || true,
    };
  }

  // Customers & unmapped accounts are strictly denied (403)
  return null;
}

function buildScopeWhere(
  scope: DealershipScope,
  alias = 'd'
): { sql: string; params: any[] } {
  const clauses: string[] = ['1=1'];
  const params: any[] = [];
  if (scope.selfOnly && scope.selfDealerId) {
    clauses.push(`${alias}.id = ?`);
    params.push(scope.selfDealerId);
  }
  if (scope.restrictedCompanyId) {
    clauses.push(`${alias}.company_id = ?`);
    params.push(scope.restrictedCompanyId);
  }
  if (scope.restrictedCountryId) {
    clauses.push(`${alias}.country_id = ?`);
    params.push(scope.restrictedCountryId);
  }
  if (scope.restrictedBranchId) {
    clauses.push(`${alias}.branch_id = ?`);
    params.push(scope.restrictedBranchId);
  }
  return { sql: clauses.join(' AND '), params };
}

function assertDealerAccessible(
  req: Request,
  res: Response,
  scope: DealershipScope,
  dealerRow: any
): boolean {
  if (!dealerRow) {
    res.status(404).json({ error: 'Dealer record not found.' });
    return false;
  }
  if (scope.selfOnly && dealerRow.id !== scope.selfDealerId) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_CROSS_TENANT_ACCESS_BLOCKED',
      userId: req.auth?.userId,
      identifier: req.auth?.email,
      companyId: req.auth?.companyId,
      details: `Dealer ${req.auth?.dealerCode} attempted unauthorized access to dealer ${dealerRow.dealer_code || dealerRow.id} on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied: Dealers may only view and manage their own dealership records.',
    });
    return false;
  }
  if (scope.restrictedCompanyId && dealerRow.company_id !== scope.restrictedCompanyId) {
    res.status(403).json({ error: 'Access Denied: Dealer belongs to another company entity.' });
    return false;
  }
  if (scope.restrictedCountryId && dealerRow.country_id !== scope.restrictedCountryId) {
    res.status(403).json({ error: 'Access Denied: Dealer belongs to another country region.' });
    return false;
  }
  if (scope.restrictedBranchId && dealerRow.branch_id !== scope.restrictedBranchId) {
    res.status(403).json({ error: 'Access Denied: Dealer belongs to another branch office.' });
    return false;
  }
  return true;
}

function isTargetPeriodMatch(saleDateStr: string, periodType: string, periodKey: string): boolean {
  const sDate = String(saleDateStr || '').slice(0, 10);
  if (!sDate) return false;
  if (periodType === 'Monthly') {
    return sDate.slice(0, 7) === periodKey;
  }
  if (periodType === 'Yearly') {
    return sDate.slice(0, 4) === periodKey;
  }
  if (periodType === 'Quarterly') {
    const m = periodKey.match(/^(\d{4})-Q([1-4])$/i);
    if (!m) return false;
    const yr = m[1];
    const q = parseInt(m[2], 10);
    if (sDate.slice(0, 4) !== yr) return false;
    const mo = parseInt(sDate.slice(5, 7), 10);
    const saleQ = Math.ceil(mo / 3);
    return saleQ === q;
  }
  return false;
}

function resolveCommissionForSale(params: {
  companyId: string;
  dealerId: string;
  vehicleModel: string;
  saleAmountPkr: number;
  fallbackRatePct: number;
}): {
  ruleId: string | null;
  ruleType: 'Percentage' | 'Fixed';
  ratePct: number;
  fixedAmountPkr: number;
  commissionAmountPkr: number;
} {
  const rules = sqlite
    .prepare(
      `SELECT * FROM dealer_commission_rules
       WHERE company_id = ? AND is_active = 1 AND min_sale_pkr <= ?
       ORDER BY
         CASE WHEN dealer_id = ? THEN 0 ELSE 1 END,
         CASE WHEN LOWER(vehicle_model) != 'all' AND LOWER(?) LIKE '%' || LOWER(vehicle_model) || '%' THEN 0 ELSE 1 END,
         created_at DESC`
    )
    .all(params.companyId, params.saleAmountPkr, params.dealerId, params.vehicleModel) as any[];

  const matched = rules.find((r) => {
    const dealerOk = !r.dealer_id || r.dealer_id === params.dealerId;
    const modelOk =
      String(r.vehicle_model || 'ALL').toUpperCase() === 'ALL' ||
      String(params.vehicleModel || '').toLowerCase().includes(String(r.vehicle_model || '').toLowerCase());
    return dealerOk && modelOk;
  });

  if (matched) {
    const ruleType = matched.rule_type === 'Fixed' ? 'Fixed' : 'Percentage';
    const ratePct = Number(matched.rate_pct || 0);
    const fixedAmt = Number(matched.fixed_amount_pkr || 0);
    const commissionAmountPkr =
      ruleType === 'Fixed' ? Math.round(fixedAmt) : Math.round((params.saleAmountPkr * ratePct) / 100);
    return {
      ruleId: matched.id,
      ruleType,
      ratePct,
      fixedAmountPkr: fixedAmt,
      commissionAmountPkr,
    };
  }

  const ratePct = Number(params.fallbackRatePct || 4.5);
  return {
    ruleId: null,
    ruleType: 'Percentage',
    ratePct,
    fixedAmountPkr: 0,
    commissionAmountPkr: Math.round((params.saleAmountPkr * ratePct) / 100),
  };
}

export function createDealershipManagementRouter() {
  const router = express.Router();

  router.use(requireAuth, (req, res, next) => {
    const scope = resolveDealershipScope(req);
    if (!scope) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'DEALERSHIP_MODULE_FORBIDDEN',
        userId: req.auth?.userId,
        identifier: req.auth?.email,
        companyId: req.auth?.companyId,
        details: `Denied access to Dealership Management API for ${req.auth?.role} (${req.auth?.subjectType}) on ${req.originalUrl}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({
        error: 'Access Denied: Your role or permission profile does not authorize Dealership Management access.',
      });
      return;
    }
    (req as any).dealershipScope = scope;
    next();
  });

  // =========================================================================
  // 1. DASHBOARD OVERVIEW & LIVE METRICS
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const dealers = sqlite
      .prepare(
        `SELECT d.*, p.city, p.business_address, p.tax_id_ntn, p.registration_no,
                c.name as company_name, b.name as branch_name
         FROM dealer_accounts d
         LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
         LEFT JOIN companies c ON c.id = d.company_id
         LEFT JOIN branches b ON b.id = d.branch_id
         WHERE ${scopeSql}
         ORDER BY d.created_at DESC`
      )
      .all(...scopeParams) as any[];

    const dealerIds = dealers.map((d) => d.id);
    const idListSql = dealerIds.length ? dealerIds.map(() => '?').join(',') : "'__none__'";
    const idParams = dealerIds.length ? dealerIds : [];

    const showrooms = sqlite
      .prepare(`SELECT * FROM dealer_showrooms WHERE dealer_id IN (${idListSql})`)
      .all(...idParams) as any[];

    const inventory = sqlite
      .prepare(`SELECT * FROM dealer_vehicle_inventory WHERE dealer_id IN (${idListSql})`)
      .all(...idParams) as any[];

    const sales = sqlite
      .prepare(`SELECT * FROM dealer_sales WHERE dealer_id IN (${idListSql})`)
      .all(...idParams) as any[];

    const commissions = sqlite
      .prepare(`SELECT * FROM dealer_commissions WHERE dealer_id IN (${idListSql})`)
      .all(...idParams) as any[];

    const targets = sqlite
      .prepare(`SELECT * FROM dealer_targets WHERE dealer_id IN (${idListSql}) AND status = 'Active'`)
      .all(...idParams) as any[];

    const docs = sqlite
      .prepare(`SELECT id, dealer_id, doc_type, verification_status FROM dealer_documents WHERE dealer_id IN (${idListSql})`)
      .all(...idParams) as any[];

    const activeSales = sales.filter((s) => s.delivery_status !== 'Cancelled' && s.payment_status !== 'Refunded');
    const totalSalesRevenuePkr = activeSales.reduce((acc, s) => acc + Number(s.sale_amount_pkr || 0), 0);
    const verifiedRevenuePkr = activeSales
      .filter((s) => s.payment_status === 'Payment Verified')
      .reduce((acc, s) => acc + Number(s.paid_amount_pkr || s.sale_amount_pkr || 0), 0);

    const pendingCommissionPkr = commissions
      .filter((c) => c.status === 'Pending' || c.status === 'Approved')
      .reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0);
    const paidCommissionPkr = commissions
      .filter((c) => c.status === 'Paid')
      .reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0);

    // Target Achievement
    let totalTargetUnits = 0;
    let totalAchievedForTargets = 0;
    for (const t of targets) {
      totalTargetUnits += Number(t.target_units || 0);
      const matching = activeSales.filter((s) => {
        if (s.dealer_id !== t.dealer_id) return false;
        const modelMatch =
          String(t.vehicle_model || 'ALL').toUpperCase() === 'ALL' ||
          String(s.vehicle_model || '').toLowerCase().includes(String(t.vehicle_model || '').toLowerCase());
        const dStr = s.sales_date || String(s.created_at || '').slice(0, 10);
        return modelMatch && isTargetPeriodMatch(dStr, t.period_type, t.period_key);
      });
      totalAchievedForTargets += matching.length;
    }
    const targetAchievementPct =
      totalTargetUnits > 0 ? Math.round((totalAchievedForTargets / totalTargetUnits) * 1000) / 10 : 0;

    // Monthly Sales Chart Series
    const monthBuckets = new Map<string, { month: string; units: number; revenuePkr: number }>();
    for (const s of activeSales) {
      const m = String(s.sales_date || s.created_at || '').slice(0, 7) || 'Unknown';
      const prev = monthBuckets.get(m) || { month: m, units: 0, revenuePkr: 0 };
      prev.units += 1;
      prev.revenuePkr += Number(s.sale_amount_pkr || 0);
      monthBuckets.set(m, prev);
    }
    const monthlySeries = Array.from(monthBuckets.values()).sort((a, b) => a.month.localeCompare(b.month));

    // Model Breakdown
    const modelMap = new Map<string, { model: string; soldUnits: number; availableUnits: number; revenuePkr: number }>();
    for (const inv of inventory) {
      const mName = String(inv.model || 'Other');
      const prev = modelMap.get(mName) || { model: mName, soldUnits: 0, availableUnits: 0, revenuePkr: 0 };
      if (inv.availability_status === 'Available' || inv.availability_status === 'Reserved' || inv.availability_status === 'In Transit') {
        prev.availableUnits += Number(inv.stock_qty || 1);
      }
      modelMap.set(mName, prev);
    }
    for (const s of activeSales) {
      const mName = String(s.vehicle_model || 'Other').split(' ').slice(0, 2).join(' ');
      const prev = modelMap.get(mName) || { model: mName, soldUnits: 0, availableUnits: 0, revenuePkr: 0 };
      prev.soldUnits += 1;
      prev.revenuePkr += Number(s.sale_amount_pkr || 0);
      modelMap.set(mName, prev);
    }

    // Dealer Leaderboard
    const ranking = dealers
      .map((d) => {
        const dSales = activeSales.filter((s) => s.dealer_id === d.id);
        const dInv = inventory.filter((i) => i.dealer_id === d.id);
        const dShowrooms = showrooms.filter((sh) => sh.dealer_id === d.id && sh.status === 'Active');
        const dComm = commissions.filter((c) => c.dealer_id === d.id && c.status !== 'Voided');
        const rev = dSales.reduce((acc, s) => acc + Number(s.sale_amount_pkr || 0), 0);
        return {
          dealerId: d.id,
          dealerCode: d.dealer_code,
          businessName: d.business_name,
          city: d.city || 'Karachi',
          verificationStatus: d.verification_status,
          status: d.status,
          activeShowrooms: dShowrooms.length,
          availableStock: dInv.filter((i) => i.availability_status === 'Available').length,
          unitsSold: dSales.length,
          revenuePkr: rev,
          commissionTotalPkr: dComm.reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0),
        };
      })
      .sort((a, b) => b.revenuePkr - a.revenuePkr || b.unitsSold - a.unitsSold);

    // Audit Logs
    const auditLogs = sqlite
      .prepare(
        `SELECT * FROM dealer_audit_logs
         WHERE (${scope.selfOnly && scope.selfDealerId ? 'dealer_id = ?' : '1=1'})
         ORDER BY created_at DESC LIMIT 30`
      )
      .all(...(scope.selfOnly && scope.selfDealerId ? [scope.selfDealerId] : [])) as any[];

    // Reference Catalogs
    const companies = sqlite
      .prepare(
        `SELECT id, name, country, city FROM companies
         WHERE status = 'Approved' ${scope.restrictedCompanyId ? 'AND id = ?' : ''}`
      )
      .all(...(scope.restrictedCompanyId ? [scope.restrictedCompanyId] : []));

    const countries = sqlite
      .prepare(`SELECT id, name, code, currency FROM countries ${scope.restrictedCountryId ? 'WHERE id = ?' : ''}`)
      .all(...(scope.restrictedCountryId ? [scope.restrictedCountryId] : []));

    const branches = sqlite
      .prepare(
        `SELECT id, company_id, country_id, name, city FROM branches
         WHERE status = 'Active' ${scope.restrictedBranchId ? 'AND id = ?' : scope.restrictedCompanyId ? 'AND company_id = ?' : ''}`
      )
      .all(
        ...(scope.restrictedBranchId
          ? [scope.restrictedBranchId]
          : scope.restrictedCompanyId
            ? [scope.restrictedCompanyId]
            : [])
      );

    res.json({
      scope,
      metrics: {
        totalDealers: dealers.length,
        verifiedDealers: dealers.filter((d) => d.verification_status === 'Verified').length,
        pendingVerification: dealers.filter((d) => d.verification_status === 'Pending Approval').length,
        suspendedOrRejected: dealers.filter((d) => d.status === 'Suspended' || d.verification_status === 'Rejected').length,
        activeShowrooms: showrooms.filter((s) => s.status === 'Active').length,
        totalShowrooms: showrooms.length,
        totalInventoryUnits: inventory.reduce((acc, i) => acc + Number(i.stock_qty || 1), 0),
        availableUnits: inventory.filter((i) => i.availability_status === 'Available').length,
        reservedOrBookedUnits: inventory.filter((i) => ['Reserved', 'Booked'].includes(i.availability_status)).length,
        soldUnits: inventory.filter((i) => i.availability_status === 'Sold').length,
        inTransitUnits: inventory.filter((i) => i.availability_status === 'In Transit' || i.availability_status === 'In-Transit').length,
        totalSalesCount: activeSales.length,
        totalSalesRevenuePkr,
        verifiedRevenuePkr,
        pendingCommissionPkr,
        paidCommissionPkr,
        pendingDocsCount: docs.filter((d) => d.verification_status === 'Pending Verification').length,
        targetAchievementPct,
        totalTargetUnits,
        totalAchievedForTargets,
      },
      monthlySeries,
      modelBreakdown: Array.from(modelMap.values()),
      dealerRanking: ranking,
      recentAuditLogs: auditLogs,
      catalogs: {
        companies,
        countries,
        branches,
        dealers: dealers.map((d) => ({
          id: d.id,
          dealerCode: d.dealer_code,
          businessName: d.business_name,
          city: d.city || 'Karachi',
          companyId: d.company_id,
          countryId: d.country_id,
          branchId: d.branch_id,
          status: d.status,
          verificationStatus: d.verification_status,
        })),
      },
    });
  });

  // =========================================================================
  // 2. DEALER REGISTRATION, DIRECTORY & PROFILE MANAGEMENT
  // =========================================================================
  router.get('/dealers/next-code', (req: Request, res: Response) => {
    const countryId = String(req.query.countryId || 'PK').toUpperCase();
    const city = String(req.query.city || 'Karachi');
    res.json({
      dealerCode: generateNextDealerCode(countryId, city),
      showroomCode: generateNextShowroomCode(countryId, city),
    });
  });

  router.get('/dealers', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const q = String(req.query.q || '').trim().toLowerCase();
    const statusFilter = String(req.query.status || '').trim();
    const verificationFilter = String(req.query.verification || '').trim();
    const cityFilter = String(req.query.city || '').trim().toLowerCase();
    const companyFilter = String(req.query.companyId || '').trim();

    let rows = sqlite
      .prepare(
        `SELECT d.id, d.dealer_code, d.dealership_id, d.company_id, d.country_id, d.branch_id,
                d.business_name, d.owner_contact_name, d.email, d.mobile, d.category,
                d.verification_status, d.status, d.email_verified, d.mobile_verified,
                d.cnic_number, d.province, d.commission_rate_pct, d.approved_by, d.approved_at,
                d.rejected_reason, d.verification_notes, d.created_at, d.updated_at,
                p.business_address, p.city, p.tax_id_ntn, p.registration_no, p.website,
                p.bank_name, p.bank_account_title, p.bank_iban_masked,
                c.name as company_name, b.name as branch_name,
                (SELECT COUNT(*) FROM dealer_showrooms s WHERE s.dealer_id = d.id) as showroom_count,
                (SELECT COUNT(*) FROM dealer_vehicle_inventory v WHERE v.dealer_id = d.id AND v.availability_status = 'Available') as available_stock,
                (SELECT COUNT(*) FROM dealer_sales sl WHERE sl.dealer_id = d.id AND sl.delivery_status != 'Cancelled') as sales_count,
                (SELECT COALESCE(SUM(sl.sale_amount_pkr), 0) FROM dealer_sales sl WHERE sl.dealer_id = d.id AND sl.delivery_status != 'Cancelled') as sales_revenue_pkr
         FROM dealer_accounts d
         LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
         LEFT JOIN companies c ON c.id = d.company_id
         LEFT JOIN branches b ON b.id = d.branch_id
         WHERE ${scopeSql}
         ORDER BY d.created_at DESC`
      )
      .all(...scopeParams) as any[];

    if (q) {
      rows = rows.filter((r) =>
        `${r.dealer_code} ${r.business_name} ${r.owner_contact_name} ${r.email} ${r.mobile} ${r.city || ''} ${r.cnic_number || ''} ${r.registration_no || ''}`
          .toLowerCase()
          .includes(q)
      );
    }
    if (statusFilter) rows = rows.filter((r) => r.status === statusFilter);
    if (verificationFilter) rows = rows.filter((r) => r.verification_status === verificationFilter);
    if (cityFilter) rows = rows.filter((r) => String(r.city || '').toLowerCase() === cityFilter);
    if (companyFilter) rows = rows.filter((r) => r.company_id === companyFilter);

    res.json({ dealers: rows, total: rows.length });
  });

  router.get('/dealers/:id', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const dealer = sqlite
      .prepare(
        `SELECT d.id, d.dealer_code, d.dealership_id, d.company_id, d.country_id, d.branch_id,
                d.business_name, d.owner_contact_name, d.email, d.mobile, d.category,
                d.verification_status, d.status, d.email_verified, d.mobile_verified,
                d.cnic_number, d.province, d.commission_rate_pct, d.approved_by, d.approved_at,
                d.rejected_reason, d.verification_notes, d.created_at, d.updated_at,
                p.business_address, p.city, p.tax_id_ntn, p.registration_no, p.website,
                p.bank_name, p.bank_account_title, p.bank_iban_masked, p.notes as profile_notes,
                c.name as company_name, b.name as branch_name
         FROM dealer_accounts d
         LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
         LEFT JOIN companies c ON c.id = d.company_id
         LEFT JOIN branches b ON b.id = d.branch_id
         WHERE d.id = ?`
      )
      .get(req.params.id) as any;

    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const showrooms = sqlite
      .prepare('SELECT * FROM dealer_showrooms WHERE dealer_id = ? ORDER BY created_at DESC')
      .all(dealer.id);
    const documents = sqlite
      .prepare('SELECT id, dealer_id, showroom_id, doc_type, title, original_filename, mime_type, size_bytes, verification_status, reviewed_by, review_notes, issue_date, expiry_date, created_at FROM dealer_documents WHERE dealer_id = ? ORDER BY created_at DESC')
      .all(dealer.id);
    const verificationHistory = sqlite
      .prepare('SELECT * FROM dealer_verification_history WHERE dealer_id = ? ORDER BY created_at DESC')
      .all(dealer.id);
    const inventory = sqlite
      .prepare('SELECT * FROM dealer_vehicle_inventory WHERE dealer_id = ? ORDER BY created_at DESC')
      .all(dealer.id);
    const sales = sqlite
      .prepare(
        `SELECT s.*, c.full_name as customer_name, c.phone as customer_phone
         FROM dealer_sales s LEFT JOIN dealer_customers c ON c.id = s.customer_id
         WHERE s.dealer_id = ? ORDER BY s.created_at DESC`
      )
      .all(dealer.id);
    const targets = sqlite
      .prepare('SELECT * FROM dealer_targets WHERE dealer_id = ? ORDER BY period_key DESC')
      .all(dealer.id);

    res.json({
      dealer,
      showrooms,
      documents,
      verificationHistory,
      inventory,
      sales,
      targets,
    });
  });

  router.post('/dealers', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canRegisterDealers) {
      res.status(403).json({ error: 'Access Denied: Insufficient permission to register new dealers.' });
      return;
    }
    const actor = req.auth!;
    const body = req.body || {};

    const businessName = String(body.businessName || '').trim();
    const ownerContactName = String(body.ownerContactName || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const mobile = String(body.mobile || '').trim();
    const cnicNumber = String(body.cnicNumber || '').trim();
    const city = String(body.city || 'Karachi').trim();
    const province = String(body.province || '').trim();
    const address = String(body.address || body.businessAddress || '').trim();
    const category = String(body.category || '3S Flagship Centre').trim();
    const registrationNo = String(body.registrationNo || '').trim();
    const taxIdNtn = String(body.taxIdNtn || '').trim();
    const countryId = scope.restrictedCountryId || String(body.countryId || 'PK').trim().toUpperCase();
    const companyId = scope.restrictedCompanyId || String(body.companyId || 'comp_byd_pk').trim();
    const branchId = scope.restrictedBranchId || (body.branchId ? String(body.branchId).trim() : null);

    if (!businessName || !ownerContactName || !email || !mobile || !address) {
      res.status(400).json({
        error: 'Business name, owner/contact name, email, mobile number, and address are required.',
      });
      return;
    }

    // Validate Company exists
    const compRow = sqlite.prepare("SELECT id, name FROM companies WHERE id = ? AND status = 'Approved'").get(companyId) as any;
    if (!compRow) {
      res.status(404).json({ error: 'Selected approved company was not found.' });
      return;
    }

    // Duplicate Prevention: Email, CNIC, Registration No, or custom Dealer Code
    const dupEmail = sqlite.prepare('SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (dupEmail) {
      res.status(409).json({
        error: `Duplicate dealer registration blocked: email "${email}" is already registered (${dupEmail.dealer_code}).`,
      });
      return;
    }

    if (cnicNumber) {
      const normalizedCnic = cnicNumber.replace(/[^0-9A-Za-z]/g, '');
      if (normalizedCnic.length < 7) {
        res.status(400).json({ error: 'CNIC / National ID must be at least 7 characters.' });
        return;
      }
      const dupCnic = sqlite
        .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE REPLACE(REPLACE(cnic_number, '-', ''), ' ', '') = ? AND cnic_number != ''")
        .get(normalizedCnic) as any;
      if (dupCnic) {
        res.status(409).json({
          error: `Duplicate dealer registration blocked: CNIC/ID matches existing dealer (${dupCnic.dealer_code}).`,
        });
        return;
      }
    }

    const customCode = body.dealerCode ? String(body.dealerCode).trim().toUpperCase() : '';
    const dealerCode = customCode || generateNextDealerCode(countryId, city);
    const dupCode = sqlite.prepare('SELECT id FROM dealer_accounts WHERE UPPER(dealer_code) = ?').get(dealerCode);
    if (dupCode) {
      res.status(409).json({ error: `Dealer Code "${dealerCode}" already exists.` });
      return;
    }

    const rawPassword = String(body.password || `BydDlr!${generateSecureToken(4)}9`);
    if (body.password) {
      const pwCheck = validatePasswordStrength(rawPassword);
      if (!pwCheck.valid) {
        res.status(400).json({ error: pwCheck.reason || 'Password does not meet complexity requirements.' });
        return;
      }
    }

    const approveImmediately = Boolean(body.approveImmediately) && scope.canVerifyDealers;
    const now = nowIso();
    const dealerId = `dlr_acc_${generateSecureToken(6)}`;
    const showroomId = `shw_${generateSecureToken(6)}`;
    const showroomName = String(body.showroomName || `${businessName} Flagship Showroom`).trim();
    const showroomCode = generateNextShowroomCode(countryId, city);
    const totpSecret = generateTotpSecret();
    const commissionRate = Math.min(25, Math.max(0.5, Number(body.commissionRatePct || 4.5)));
    const username = `dlr_${dealerCode.toLowerCase().replace(/[^a-z0-9]/g, '_')}`;

    let dealershipId: string | null = null;
    if (approveImmediately) {
      dealershipId = `dl_${generateSecureToken(6)}`;
    }

    const tx = sqlite.transaction(() => {
      if (dealershipId) {
        sqlite
          .prepare(
            `INSERT INTO dealerships (
              id, company_id, branch_id, name, code, country, city, address, manager_name,
              phone, email, facility_type, status, active_techs, service_bays,
              monthly_target_units, achieved_units, monthly_revenue_pkr, rating, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', 6, 4, 20, 0, 0, 4.8, ?)`
          )
          .run(
            dealershipId,
            companyId,
            branchId,
            businessName,
            dealerCode,
            countryId,
            city,
            address,
            ownerContactName,
            mobile,
            email,
            category === '2S Service Facility' || category === 'Retail Experience Studio' ? category : '3S Flagship Centre',
            now
          );
      }

      sqlite
        .prepare(
          `INSERT INTO dealer_accounts (
            id, dealer_code, dealership_id, company_id, country_id, branch_id,
            business_name, owner_contact_name, username, email, mobile, cnic_number, province,
            password_hash, category, verification_status, status, email_verified, mobile_verified,
            two_factor_enabled, two_factor_secret, recovery_codes_json, commission_rate_pct,
            authorized_by, approved_by, approved_at, verification_notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?, '[]', ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          dealerId,
          dealerCode,
          dealershipId,
          companyId,
          countryId,
          branchId,
          businessName,
          ownerContactName,
          username,
          email,
          mobile,
          cnicNumber,
          province,
          hashPassword(rawPassword),
          category,
          approveImmediately ? 'Verified' : 'Pending Approval',
          approveImmediately ? 'Active' : 'Pending Verification',
          approveImmediately ? 1 : 0,
          totpSecret,
          commissionRate,
          actor.fullName,
          approveImmediately ? actor.fullName : null,
          approveImmediately ? now : null,
          approveImmediately ? 'Immediate administrative verification on registration.' : 'Submitted for verification.',
          now,
          now
        );

      sqlite
        .prepare(
          `INSERT INTO dealer_profiles (
            id, dealer_id, business_address, city, country_id, tax_id_ntn, registration_no,
            website, bank_name, bank_account_title, bank_iban_masked,
            pending_change_status, notes, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'None', ?, ?)`
        )
        .run(
          `dpf_${generateSecureToken(6)}`,
          dealerId,
          address,
          city,
          countryId,
          taxIdNtn,
          registrationNo,
          String(body.website || ''),
          String(body.bankName || ''),
          String(body.bankAccountTitle || ''),
          String(body.bankIbanMasked || ''),
          `Registered via Dealership Management Module by ${actor.fullName}.`,
          now
        );

      sqlite
        .prepare('INSERT INTO dealer_permissions (id, dealer_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?, ?)')
        .run(`dpm_${generateSecureToken(6)}`, dealerId, JSON.stringify([...CANONICAL_DEALER_PERMISSIONS]), actor.fullName, now);

      sqlite
        .prepare(
          `INSERT INTO dealer_assignments (
            id, dealer_id, company_id, country_id, branch_id, assigned_manager_id,
            assigned_manager_name, status, assigned_by, effective_from, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)`
        )
        .run(
          `dasg_${generateSecureToken(6)}`,
          dealerId,
          companyId,
          countryId,
          branchId,
          actor.userId,
          actor.fullName,
          actor.fullName,
          now.slice(0, 10),
          'Initial dealership network registration assignment.',
          now,
          now
        );

      sqlite
        .prepare(
          `INSERT INTO dealer_showrooms (
            id, showroom_code, dealer_id, company_id, country_id, branch_id,
            name, address, country, province, city, phone, email,
            opening_hours, closing_hours, manager_name, manager_phone, manager_email,
            status, verification_status, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          showroomId,
          showroomCode,
          dealerId,
          companyId,
          countryId,
          branchId,
          showroomName,
          String(body.showroomAddress || address),
          countryId,
          province,
          city,
          String(body.showroomPhone || mobile),
          String(body.showroomEmail || email),
          String(body.openingHours || '09:00'),
          String(body.closingHours || '20:00'),
          String(body.managerName || ownerContactName),
          String(body.managerPhone || mobile),
          String(body.managerEmail || email),
          approveImmediately ? 'Active' : 'Inactive',
          approveImmediately ? 'Verified' : 'Pending Approval',
          'Primary registered dealership showroom.',
          now,
          now
        );

      sqlite
        .prepare(
          `INSERT INTO dealer_verification_history (
            id, dealer_id, showroom_id, target_type, target_id, previous_status,
            new_status, rejection_reason, notes, reviewed_by_id, reviewed_by_name, reviewed_by_role, created_at
          ) VALUES (?, ?, ?, 'Dealer', ?, NULL, ?, NULL, ?, ?, ?, ?, ?)`
        )
        .run(
          `dvh_${generateSecureToken(6)}`,
          dealerId,
          showroomId,
          dealerCode,
          approveImmediately ? 'Verified' : 'Pending Approval',
          approveImmediately ? 'Registered and pre-verified by authorized admin.' : 'New dealer registration awaiting document & showroom verification.',
          actor.userId,
          actor.fullName,
          actor.role,
          now
        );
    });
    tx();

    logDealerModuleAudit({
      dealerId,
      companyId,
      countryId,
      branchId,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'DEALER_REGISTERED',
      module: 'Dealer Registration',
      targetId: dealerCode,
      details: `Registered ${businessName} (${dealerCode}) with primary showroom ${showroomCode}.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      dealer: sqlite
        .prepare('SELECT id, dealer_code, business_name, email, mobile, verification_status, status FROM dealer_accounts WHERE id = ?')
        .get(dealerId),
      showroom: sqlite.prepare('SELECT * FROM dealer_showrooms WHERE id = ?').get(showroomId),
    });
  });

  router.patch('/dealers/:id', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const actor = req.auth!;
    const body = req.body || {};
    const now = nowIso();

    const businessName = body.businessName !== undefined ? String(body.businessName).trim() : dealer.business_name;
    const ownerContactName = body.ownerContactName !== undefined ? String(body.ownerContactName).trim() : dealer.owner_contact_name;
    const mobile = body.mobile !== undefined ? String(body.mobile).trim() : dealer.mobile;
    const cnicNumber = body.cnicNumber !== undefined ? String(body.cnicNumber).trim() : dealer.cnic_number;
    const province = body.province !== undefined ? String(body.province).trim() : dealer.province;
    const category = body.category !== undefined ? String(body.category).trim() : dealer.category;
    const commissionRate =
      body.commissionRatePct !== undefined && !scope.selfOnly
        ? Math.min(25, Math.max(0.5, Number(body.commissionRatePct)))
        : dealer.commission_rate_pct;

    sqlite
      .prepare(
        `UPDATE dealer_accounts
         SET business_name = ?, owner_contact_name = ?, mobile = ?, cnic_number = ?,
             province = ?, category = ?, commission_rate_pct = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(businessName, ownerContactName, mobile, cnicNumber, province, category, commissionRate, now, dealer.id);

    if (
      body.businessAddress !== undefined ||
      body.city !== undefined ||
      body.taxIdNtn !== undefined ||
      body.registrationNo !== undefined ||
      body.website !== undefined
    ) {
      const prof = sqlite.prepare('SELECT * FROM dealer_profiles WHERE dealer_id = ?').get(dealer.id) as any;
      sqlite
        .prepare(
          `UPDATE dealer_profiles
           SET business_address = ?, city = ?, tax_id_ntn = ?, registration_no = ?, website = ?, updated_at = ?
           WHERE dealer_id = ?`
        )
        .run(
          body.businessAddress !== undefined ? String(body.businessAddress).trim() : prof?.business_address || '',
          body.city !== undefined ? String(body.city).trim() : prof?.city || 'Karachi',
          body.taxIdNtn !== undefined ? String(body.taxIdNtn).trim() : prof?.tax_id_ntn || '',
          body.registrationNo !== undefined ? String(body.registrationNo).trim() : prof?.registration_no || '',
          body.website !== undefined ? String(body.website).trim() : prof?.website || '',
          now,
          dealer.id
        );
    }

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: 'DEALER_PROFILE_UPDATED',
      module: 'Dealer Directory',
      targetId: dealer.dealer_code,
      details: `Updated dealership profile details for ${businessName}.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      dealer: sqlite.prepare('SELECT id, dealer_code, business_name, owner_contact_name, mobile, cnic_number, province, category, commission_rate_pct, verification_status, status FROM dealer_accounts WHERE id = ?').get(dealer.id),
    });
  });

  router.post('/dealers/:id/send-verification', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const channel = req.body?.channel === 'mobile' ? 'mobile' : 'email';
    const otp = generateNumericOtp(6);
    const col = channel === 'mobile' ? 'mobile_otp_hash' : 'email_otp_hash';
    sqlite.prepare(`UPDATE dealer_accounts SET ${col} = ?, updated_at = ? WHERE id = ?`).run(sha256(otp), nowIso(), dealer.id);

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `DEALER_${channel.toUpperCase()}_OTP_DISPATCHED`,
      module: 'Dealer Verification',
      targetId: dealer.dealer_code,
      details: `Dispatched 6-digit ${channel} verification code.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      channel,
      message: `6-digit ${channel} verification OTP generated.`,
      devOtpPreview: process.env.NODE_ENV !== 'production' ? otp : undefined,
    });
  });

  router.post('/dealers/:id/confirm-verification', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const channel = req.body?.channel === 'mobile' ? 'mobile' : 'email';
    const otp = String(req.body?.otpCode || '').trim();
    const expectedHash = channel === 'mobile' ? dealer.mobile_otp_hash : dealer.email_otp_hash;
    if (!otp || !expectedHash || sha256(otp) !== expectedHash) {
      res.status(400).json({ error: 'Invalid or expired verification code.' });
      return;
    }

    const now = nowIso();
    if (channel === 'mobile') {
      sqlite.prepare('UPDATE dealer_accounts SET mobile_verified = 1, mobile_otp_hash = NULL, updated_at = ? WHERE id = ?').run(now, dealer.id);
    } else {
      const nextStatus = dealer.verification_status === 'Verified' ? 'Active' : dealer.status;
      sqlite.prepare('UPDATE dealer_accounts SET email_verified = 1, email_otp_hash = NULL, status = ?, updated_at = ? WHERE id = ?').run(nextStatus, now, dealer.id);
    }

    res.json({
      success: true,
      channel,
      dealer: sqlite.prepare('SELECT id, email_verified, mobile_verified, status FROM dealer_accounts WHERE id = ?').get(dealer.id),
    });
  });

  // =========================================================================
  // 3. DEALER VERIFICATION WORKFLOW & HISTORY
  // =========================================================================
  router.get('/verification-queue', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const dealers = sqlite
      .prepare(
        `SELECT d.id, d.dealer_code, d.business_name, d.owner_contact_name, d.email, d.mobile,
                d.cnic_number, d.email_verified, d.mobile_verified, d.verification_status,
                d.status, d.rejected_reason, d.verification_notes, d.created_at,
                p.city, p.business_address, p.tax_id_ntn, p.registration_no
         FROM dealer_accounts d
         LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
         WHERE ${scopeSql}
         ORDER BY CASE WHEN d.verification_status = 'Pending Approval' THEN 0 ELSE 1 END, d.created_at DESC`
      )
      .all(...scopeParams) as any[];

    const dealerIds = dealers.map((d) => d.id);
    const idListSql = dealerIds.length ? dealerIds.map(() => '?').join(',') : "'__none__'";

    const documents = sqlite
      .prepare(
        `SELECT doc.id, doc.dealer_id, doc.showroom_id, doc.doc_type, doc.title, doc.original_filename,
                doc.mime_type, doc.size_bytes, doc.verification_status, doc.reviewed_by, doc.review_notes, doc.created_at,
                d.business_name as dealer_name, d.dealer_code
         FROM dealer_documents doc
         JOIN dealer_accounts d ON d.id = doc.dealer_id
         WHERE doc.dealer_id IN (${idListSql})
         ORDER BY CASE WHEN doc.verification_status = 'Pending Verification' THEN 0 ELSE 1 END, doc.created_at DESC`
      )
      .all(...(dealerIds.length ? dealerIds : []));

    const history = sqlite
      .prepare(
        `SELECT h.*, d.business_name as dealer_name, d.dealer_code
         FROM dealer_verification_history h
         JOIN dealer_accounts d ON d.id = h.dealer_id
         WHERE h.dealer_id IN (${idListSql})
         ORDER BY h.created_at DESC LIMIT 80`
      )
      .all(...(dealerIds.length ? dealerIds : []));

    res.json({ dealers, documents, history });
  });

  router.patch('/dealers/:id/verify', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canVerifyDealers) {
      res.status(403).json({
        error: 'Access Denied: Only authorized Founder, Super Admin, or assigned Administrators can verify or reject dealers.',
      });
      return;
    }

    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(req.params.id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const actor = req.auth!;
    const decision = String(req.body?.decision || '').trim().toLowerCase();
    const rejectionReason = String(req.body?.rejectionReason || req.body?.reason || '').trim();
    const notes = String(req.body?.notes || '').trim();
    const now = nowIso();

    if (!['approve', 'reject', 'suspend', 'reactivate'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be "approve", "reject", "suspend", or "reactivate".' });
      return;
    }
    if ((decision === 'reject' || decision === 'suspend') && !rejectionReason) {
      res.status(400).json({ error: 'A formal reason is required when rejecting or suspending a dealership.' });
      return;
    }

    const prevVerStatus = dealer.verification_status;
    let nextVerStatus = prevVerStatus;
    let nextAccStatus = dealer.status;

    const tx = sqlite.transaction(() => {
      if (decision === 'approve') {
        nextVerStatus = 'Verified';
        nextAccStatus = 'Active';

        let dealershipId = dealer.dealership_id;
        if (!dealershipId) {
          dealershipId = `dl_${generateSecureToken(6)}`;
          const prof = sqlite.prepare('SELECT city, business_address FROM dealer_profiles WHERE dealer_id = ?').get(dealer.id) as any;
          sqlite
            .prepare(
              `INSERT INTO dealerships (
                id, company_id, branch_id, name, code, country, city, address, manager_name,
                phone, email, facility_type, status, active_techs, service_bays,
                monthly_target_units, achieved_units, monthly_revenue_pkr, rating, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', 6, 4, 20, 0, 0, 4.8, ?)`
            )
            .run(
              dealershipId,
              dealer.company_id,
              dealer.branch_id,
              dealer.business_name,
              dealer.dealer_code,
              dealer.country_id,
              prof?.city || 'Karachi',
              prof?.business_address || 'Authorized Showroom',
              dealer.owner_contact_name,
              dealer.mobile,
              dealer.email,
              dealer.category || '3S Flagship Centre',
              now
            );
        } else {
          sqlite.prepare("UPDATE dealerships SET status = 'Approved' WHERE id = ?").run(dealershipId);
        }

        sqlite
          .prepare(
            `UPDATE dealer_accounts
             SET verification_status = 'Verified', status = 'Active', email_verified = 1,
                 dealership_id = ?, approved_by = ?, approved_at = ?, authorized_by = ?,
                 rejected_reason = NULL, verification_notes = ?, updated_at = ?
             WHERE id = ?`
          )
          .run(dealershipId, actor.fullName, now, actor.fullName, notes || 'Verified & Approved.', now, dealer.id);

        sqlite
          .prepare("UPDATE dealer_showrooms SET verification_status = 'Verified', status = 'Active', updated_at = ? WHERE dealer_id = ?")
          .run(now, dealer.id);
      } else if (decision === 'reject') {
        nextVerStatus = 'Rejected';
        nextAccStatus = 'Rejected';
        sqlite
          .prepare(
            "UPDATE dealer_accounts SET verification_status = 'Rejected', status = 'Rejected', rejected_reason = ?, verification_notes = ?, updated_at = ? WHERE id = ?"
          )
          .run(rejectionReason, notes || rejectionReason, now, dealer.id);
        sqlite.prepare("UPDATE dealer_showrooms SET verification_status = 'Rejected', status = 'Inactive', updated_at = ? WHERE dealer_id = ?").run(now, dealer.id);
        sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'dealer'").run(dealer.id);
        if (dealer.dealership_id) {
          sqlite.prepare("UPDATE dealerships SET status = 'Rejected' WHERE id = ?").run(dealer.dealership_id);
        }
      } else if (decision === 'suspend') {
        nextAccStatus = 'Suspended';
        sqlite
          .prepare("UPDATE dealer_accounts SET status = 'Suspended', rejected_reason = ?, verification_notes = ?, updated_at = ? WHERE id = ?")
          .run(rejectionReason, notes || rejectionReason, now, dealer.id);
        sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'dealer'").run(dealer.id);
        if (dealer.dealership_id) {
          sqlite.prepare("UPDATE dealerships SET status = 'Suspended' WHERE id = ?").run(dealer.dealership_id);
        }
      } else if (decision === 'reactivate') {
        nextVerStatus = 'Verified';
        nextAccStatus = 'Active';
        sqlite
          .prepare("UPDATE dealer_accounts SET verification_status = 'Verified', status = 'Active', rejected_reason = NULL, verification_notes = ?, updated_at = ? WHERE id = ?")
          .run(notes || 'Reactivated by administrator.', now, dealer.id);
        if (dealer.dealership_id) {
          sqlite.prepare("UPDATE dealerships SET status = 'Approved' WHERE id = ?").run(dealer.dealership_id);
        }
      }

      sqlite
        .prepare(
          `INSERT INTO dealer_verification_history (
            id, dealer_id, showroom_id, target_type, target_id, previous_status, new_status,
            rejection_reason, notes, reviewed_by_id, reviewed_by_name, reviewed_by_role, created_at
          ) VALUES (?, ?, NULL, 'Dealer', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          `dvh_${generateSecureToken(6)}`,
          dealer.id,
          dealer.dealer_code,
          `${prevVerStatus} / ${dealer.status}`,
          `${nextVerStatus} / ${nextAccStatus}`,
          rejectionReason || null,
          notes || null,
          actor.userId,
          actor.fullName,
          actor.role,
          now
        );
    });
    tx();

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: actor.userId,
      actorName: actor.fullName,
      actorRole: actor.role,
      action: `DEALER_VERIFICATION_${decision.toUpperCase()}`,
      module: 'Dealer Verification',
      targetId: dealer.dealer_code,
      details: `${decision.toUpperCase()} executed${rejectionReason ? `: ${rejectionReason}` : ''}.`,
      ipAddress: getClientIp(req),
      status: decision === 'reject' || decision === 'suspend' ? 'WARNING' : 'SUCCESS',
    });

    res.json({
      success: true,
      dealer: sqlite.prepare('SELECT id, dealer_code, business_name, verification_status, status, rejected_reason, approved_by, approved_at FROM dealer_accounts WHERE id = ?').get(dealer.id),
    });
  });

  // =========================================================================
  // 4. SHOWROOM INFORMATION (MULTI-SHOWROOM SUPPORT)
  // =========================================================================
  router.get('/showrooms', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');
    const dealerFilter = req.query.dealerId ? String(req.query.dealerId).trim() : '';
    const statusFilter = req.query.status ? String(req.query.status).trim() : '';

    let rows = sqlite
      .prepare(
        `SELECT s.*, d.business_name as dealer_name, d.dealer_code, d.verification_status as dealer_verification_status
         FROM dealer_showrooms s
         JOIN dealer_accounts d ON d.id = s.dealer_id
         WHERE ${scopeSql}
         ORDER BY s.created_at DESC`
      )
      .all(...scopeParams) as any[];

    if (dealerFilter) rows = rows.filter((r) => r.dealer_id === dealerFilter);
    if (statusFilter) rows = rows.filter((r) => r.status === statusFilter);

    res.json({ showrooms: rows });
  });

  router.post('/showrooms', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageShowrooms) {
      res.status(403).json({ error: 'Access Denied: Insufficient permission to add showrooms.' });
      return;
    }

    const body = req.body || {};
    const targetDealerId = scope.selfOnly ? scope.selfDealerId! : String(body.dealerId || '').trim();
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(targetDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const name = String(body.name || '').trim();
    const address = String(body.address || '').trim();
    const city = String(body.city || 'Karachi').trim();
    const country = String(body.country || dealer.country_id || 'PK').trim().toUpperCase();
    const province = String(body.province || dealer.province || '').trim();

    if (!name || !address) {
      res.status(400).json({ error: 'Showroom name and address are required.' });
      return;
    }

    const showroomCode = body.showroomCode
      ? String(body.showroomCode).trim().toUpperCase()
      : generateNextShowroomCode(country, city);
    const dup = sqlite.prepare('SELECT id FROM dealer_showrooms WHERE UPPER(showroom_code) = ?').get(showroomCode);
    if (dup) {
      res.status(409).json({ error: `Showroom code "${showroomCode}" already exists.` });
      return;
    }

    const showroomId = `shw_${generateSecureToken(6)}`;
    const now = nowIso();
    const verificationStatus = scope.canVerifyDealers && body.verified ? 'Verified' : scope.selfOnly ? 'Pending Approval' : 'Verified';

    sqlite
      .prepare(
        `INSERT INTO dealer_showrooms (
          id, showroom_code, dealer_id, company_id, country_id, branch_id,
          name, address, country, province, city, phone, email,
          opening_hours, closing_hours, manager_name, manager_phone, manager_email,
          status, verification_status, photo_doc_ids_json, doc_ids_json, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        showroomId,
        showroomCode,
        dealer.id,
        dealer.company_id,
        dealer.country_id,
        dealer.branch_id || null,
        name,
        address,
        country,
        province,
        city,
        String(body.phone || dealer.mobile || ''),
        String(body.email || dealer.email || ''),
        String(body.openingHours || '09:00'),
        String(body.closingHours || '20:00'),
        String(body.managerName || dealer.owner_contact_name || ''),
        String(body.managerPhone || dealer.mobile || ''),
        String(body.managerEmail || dealer.email || ''),
        body.status === 'Inactive' ? 'Inactive' : 'Active',
        verificationStatus,
        JSON.stringify(Array.isArray(body.photoDocIds) ? body.photoDocIds : []),
        JSON.stringify(Array.isArray(body.docIds) ? body.docIds : []),
        String(body.notes || ''),
        now,
        now
      );

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SHOWROOM_CREATED',
      module: 'Showrooms',
      targetId: showroomCode,
      details: `Added showroom "${name}" (${city}) under ${dealer.dealer_code}.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      showroom: sqlite.prepare('SELECT * FROM dealer_showrooms WHERE id = ?').get(showroomId),
    });
  });

  router.patch('/showrooms/:id', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageShowrooms) {
      res.status(403).json({ error: 'Access Denied: Insufficient permission to update showroom.' });
      return;
    }

    const showroom = sqlite.prepare('SELECT * FROM dealer_showrooms WHERE id = ?').get(req.params.id) as any;
    if (!showroom) {
      res.status(404).json({ error: 'Showroom not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(showroom.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const body = req.body || {};
    const now = nowIso();
    const nextVerStatus =
      body.verificationStatus && scope.canVerifyDealers
        ? String(body.verificationStatus)
        : showroom.verification_status;

    sqlite
      .prepare(
        `UPDATE dealer_showrooms
         SET name = ?, address = ?, country = ?, province = ?, city = ?, phone = ?, email = ?,
             opening_hours = ?, closing_hours = ?, manager_name = ?, manager_phone = ?, manager_email = ?,
             status = ?, verification_status = ?, notes = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(
        body.name !== undefined ? String(body.name).trim() : showroom.name,
        body.address !== undefined ? String(body.address).trim() : showroom.address,
        body.country !== undefined ? String(body.country).trim().toUpperCase() : showroom.country,
        body.province !== undefined ? String(body.province).trim() : showroom.province,
        body.city !== undefined ? String(body.city).trim() : showroom.city,
        body.phone !== undefined ? String(body.phone).trim() : showroom.phone,
        body.email !== undefined ? String(body.email).trim() : showroom.email,
        body.openingHours !== undefined ? String(body.openingHours).trim() : showroom.opening_hours,
        body.closingHours !== undefined ? String(body.closingHours).trim() : showroom.closing_hours,
        body.managerName !== undefined ? String(body.managerName).trim() : showroom.manager_name,
        body.managerPhone !== undefined ? String(body.managerPhone).trim() : showroom.manager_phone,
        body.managerEmail !== undefined ? String(body.managerEmail).trim() : showroom.manager_email,
        body.status !== undefined ? (body.status === 'Inactive' ? 'Inactive' : 'Active') : showroom.status,
        nextVerStatus,
        body.notes !== undefined ? String(body.notes) : showroom.notes,
        now,
        showroom.id
      );

    if (body.verificationStatus && scope.canVerifyDealers) {
      sqlite
        .prepare(
          `INSERT INTO dealer_verification_history (
            id, dealer_id, showroom_id, target_type, target_id, previous_status, new_status,
            rejection_reason, notes, reviewed_by_id, reviewed_by_name, reviewed_by_role, created_at
          ) VALUES (?, ?, ?, 'Showroom', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          `dvh_${generateSecureToken(6)}`,
          dealer.id,
          showroom.id,
          showroom.showroom_code,
          showroom.verification_status,
          nextVerStatus,
          body.rejectionReason ? String(body.rejectionReason) : null,
          String(body.notes || ''),
          req.auth!.userId,
          req.auth!.fullName,
          req.auth!.role,
          now
        );
    }

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SHOWROOM_UPDATED',
      module: 'Showrooms',
      targetId: showroom.showroom_code,
      details: `Updated showroom "${showroom.name}".`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, showroom: sqlite.prepare('SELECT * FROM dealer_showrooms WHERE id = ?').get(showroom.id) });
  });

  // =========================================================================
  // 5. DEALER VEHICLE INVENTORY & TRANSFERS
  // =========================================================================
  router.get('/inventory', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');
    const dealerFilter = req.query.dealerId ? String(req.query.dealerId).trim() : '';
    const statusFilter = req.query.status ? String(req.query.status).trim() : '';
    const q = String(req.query.q || '').trim().toLowerCase();

    let items = sqlite
      .prepare(
        `SELECT i.*, d.business_name as dealer_name, d.dealer_code, s.name as showroom_name, s.showroom_code
         FROM dealer_vehicle_inventory i
         JOIN dealer_accounts d ON d.id = i.dealer_id
         LEFT JOIN dealer_showrooms s ON s.id = i.showroom_id
         WHERE ${scopeSql}
         ORDER BY i.created_at DESC`
      )
      .all(...scopeParams) as any[];

    if (dealerFilter) items = items.filter((r) => r.dealer_id === dealerFilter);
    if (statusFilter) items = items.filter((r) => r.availability_status === statusFilter);
    if (q) {
      items = items.filter((r) =>
        `${r.stock_number} ${r.model} ${r.variant} ${r.vin} ${r.chassis_number || ''} ${r.exterior_color} ${r.dealer_name}`
          .toLowerCase()
          .includes(q)
      );
    }

    const invIds = items.map((i) => i.id);
    const idSql = invIds.length ? invIds.map(() => '?').join(',') : "'__none__'";
    const history = sqlite
      .prepare(
        `SELECT h.*, i.stock_number, i.vin, i.model
         FROM dealer_inventory_history h
         JOIN dealer_vehicle_inventory i ON i.id = h.inventory_id
         WHERE h.inventory_id IN (${idSql})
         ORDER BY h.created_at DESC LIMIT 80`
      )
      .all(...(invIds.length ? invIds : []));

    res.json({ inventory: items, history });
  });

  router.post('/inventory', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageInventory) {
      res.status(403).json({ error: 'Access Denied: Insufficient permission to add dealer vehicle inventory.' });
      return;
    }

    const body = req.body || {};
    const targetDealerId = scope.selfOnly ? scope.selfDealerId! : String(body.dealerId || '').trim();
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(targetDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const model = String(body.model || '').trim();
    const variant = String(body.variant || '').trim();
    const vin = String(body.vin || '').trim().toUpperCase();
    const chassisNumber = String(body.chassisNumber || '').trim().toUpperCase();
    const exteriorColor = String(body.exteriorColor || 'Arctic White').trim();
    const interiorColor = String(body.interiorColor || 'Eclipse Black Vegan Leather').trim();
    const pricePkr = Number(body.approvedSellingPricePkr || 0);

    if (!model || !variant || !vin || pricePkr <= 0) {
      res.status(400).json({ error: 'Model, variant, unique VIN, and valid selling price (PKR > 0) are required.' });
      return;
    }

    const dupVin = sqlite.prepare('SELECT id, stock_number FROM dealer_vehicle_inventory WHERE UPPER(vin) = ?').get(vin) as any;
    if (dupVin) {
      res.status(409).json({ error: `Duplicate VIN blocked: VIN "${vin}" already exists on stock ${dupVin.stock_number}.` });
      return;
    }

    if (chassisNumber) {
      const dupChassis = sqlite
        .prepare("SELECT id, stock_number FROM dealer_vehicle_inventory WHERE UPPER(chassis_number) = ? AND chassis_number != ''")
        .get(chassisNumber) as any;
      if (dupChassis) {
        res.status(409).json({
          error: `Duplicate Chassis Number blocked: "${chassisNumber}" already exists on stock ${dupChassis.stock_number}.`,
        });
        return;
      }
    }

    const stockNumber = body.stockNumber
      ? String(body.stockNumber).trim().toUpperCase()
      : `STK-${dealer.country_id}-${generateNumericOtp(5)}`;
    const dupStock = sqlite.prepare('SELECT id FROM dealer_vehicle_inventory WHERE UPPER(stock_number) = ?').get(stockNumber);
    if (dupStock) {
      res.status(409).json({ error: `Stock number "${stockNumber}" already exists.` });
      return;
    }

    const availability = ['Available', 'Reserved', 'In-Transit', 'In Transit', 'Sold'].includes(String(body.availabilityStatus))
      ? String(body.availabilityStatus)
      : 'Available';
    const now = nowIso();
    const invId = `dinv_${generateSecureToken(6)}`;

    const tx = sqlite.transaction(() => {
      sqlite
        .prepare(
          `INSERT INTO dealer_vehicle_inventory (
            id, dealer_id, company_id, country_id, branch_id, showroom_id, vehicle_id, stock_number,
            model, variant, model_year, exterior_color, interior_color, vin, chassis_number,
            motor_power_kw, battery_kwh, range_km, stock_qty, arrival_date, image_url,
            availability_status, approved_selling_price_pkr, booking_status, delivery_status,
            assigned_by, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Unbooked', ?, ?, ?, ?)`
        )
        .run(
          invId,
          dealer.id,
          dealer.company_id,
          dealer.country_id,
          dealer.branch_id || null,
          body.showroomId || null,
          body.vehicleId || null,
          stockNumber,
          model,
          variant,
          Number(body.modelYear || 2026),
          exteriorColor,
          interiorColor,
          vin,
          chassisNumber,
          Number(body.motorPowerKw || 0),
          Number(body.batteryKwh || 0),
          Number(body.rangeKm || 0),
          Math.max(1, Number(body.stockQty || 1)),
          body.arrivalDate ? String(body.arrivalDate).slice(0, 10) : now.slice(0, 10),
          String(body.imageUrl || ''),
          availability,
          pricePkr,
          availability.includes('Transit') ? 'In Transit' : 'At Showroom',
          req.auth!.fullName,
          now,
          now
        );

      sqlite
        .prepare(
          `INSERT INTO dealer_inventory_history (
            id, inventory_id, dealer_id, company_id, action_type, to_dealer_id, to_branch_id,
            previous_status, new_status, notes, actor_id, actor_name, created_at
          ) VALUES (?, ?, ?, ?, 'Added', ?, ?, NULL, ?, ?, ?, ?, ?)`
        )
        .run(
          `dih_${generateSecureToken(6)}`,
          invId,
          dealer.id,
          dealer.company_id,
          dealer.id,
          dealer.branch_id || null,
          availability,
          `Added ${model} ${variant} (VIN: ${vin}).`,
          req.auth!.userId,
          req.auth!.fullName,
          now
        );
    });
    tx();

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_INVENTORY_ADDED',
      module: 'Dealer Inventory',
      targetId: stockNumber,
      details: `Added ${model} ${variant} (${vin}) at PKR ${pricePkr.toLocaleString()}.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      vehicle: sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(invId),
    });
  });

  router.patch('/inventory/:id', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageInventory) {
      res.status(403).json({ error: 'Access Denied.' });
      return;
    }

    const inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(req.params.id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Inventory vehicle not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(inv.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const body = req.body || {};
    const nextStatus = body.availabilityStatus ? String(body.availabilityStatus) : inv.availability_status;
    const now = nowIso();

    sqlite
      .prepare(
        `UPDATE dealer_vehicle_inventory
         SET availability_status = ?, showroom_id = ?, approved_selling_price_pkr = ?,
             delivery_status = ?, delivery_date = ?, exterior_color = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(
        nextStatus,
        body.showroomId !== undefined ? body.showroomId : inv.showroom_id,
        body.approvedSellingPricePkr !== undefined ? Number(body.approvedSellingPricePkr) : inv.approved_selling_price_pkr,
        body.deliveryStatus !== undefined ? String(body.deliveryStatus) : inv.delivery_status,
        body.deliveryDate !== undefined ? String(body.deliveryDate) : inv.delivery_date,
        body.exteriorColor !== undefined ? String(body.exteriorColor) : inv.exterior_color,
        now,
        inv.id
      );

    if (nextStatus !== inv.availability_status) {
      sqlite
        .prepare(
          `INSERT INTO dealer_inventory_history (
            id, inventory_id, dealer_id, company_id, action_type, previous_status, new_status,
            notes, actor_id, actor_name, created_at
          ) VALUES (?, ?, ?, ?, 'StatusChange', ?, ?, ?, ?, ?, ?)`
        )
        .run(
          `dih_${generateSecureToken(6)}`,
          inv.id,
          dealer.id,
          dealer.company_id,
          inv.availability_status,
          nextStatus,
          String(body.notes || `Status changed from ${inv.availability_status} to ${nextStatus}.`),
          req.auth!.userId,
          req.auth!.fullName,
          now
        );
    }

    res.json({ success: true, vehicle: sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(inv.id) });
  });

  router.post('/inventory/:id/transfer', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canTransferInventory) {
      res.status(403).json({ error: 'Access Denied: Only authorized administrators may execute cross-dealer stock transfers.' });
      return;
    }

    const inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(req.params.id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Inventory vehicle not found.' });
      return;
    }
    const sourceDealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(inv.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, sourceDealer)) return;

    if (inv.availability_status === 'Sold') {
      res.status(400).json({ error: 'Sold vehicles cannot be transferred to another dealership.' });
      return;
    }

    const toDealerId = String(req.body?.toDealerId || '').trim();
    const toShowroomId = req.body?.toShowroomId ? String(req.body.toShowroomId).trim() : null;
    const notes = String(req.body?.notes || 'Authorized stock transfer between dealerships.').trim();
    const targetDealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(toDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, targetDealer)) return;

    const now = nowIso();
    const tx = sqlite.transaction(() => {
      sqlite
        .prepare(
          `UPDATE dealer_vehicle_inventory
           SET dealer_id = ?, company_id = ?, country_id = ?, branch_id = ?, showroom_id = ?, updated_at = ?
           WHERE id = ?`
        )
        .run(
          targetDealer.id,
          targetDealer.company_id,
          targetDealer.country_id,
          targetDealer.branch_id || null,
          toShowroomId,
          now,
          inv.id
        );

      sqlite
        .prepare(
          `INSERT INTO dealer_inventory_history (
            id, inventory_id, dealer_id, company_id, action_type,
            from_dealer_id, to_dealer_id, from_branch_id, to_branch_id,
            previous_status, new_status, notes, actor_id, actor_name, created_at
          ) VALUES (?, ?, ?, ?, 'Transfer', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          `dih_${generateSecureToken(6)}`,
          inv.id,
          targetDealer.id,
          targetDealer.company_id,
          sourceDealer.id,
          targetDealer.id,
          sourceDealer.branch_id || null,
          targetDealer.branch_id || null,
          inv.availability_status,
          inv.availability_status,
          `${sourceDealer.dealer_code} -> ${targetDealer.dealer_code}: ${notes}`,
          req.auth!.userId,
          req.auth!.fullName,
          now
        );
    });
    tx();

    logDealerModuleAudit({
      dealerId: targetDealer.id,
      companyId: targetDealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_INVENTORY_TRANSFERRED',
      module: 'Dealer Inventory',
      targetId: inv.stock_number,
      details: `Transferred VIN ${inv.vin} from ${sourceDealer.dealer_code} to ${targetDealer.dealer_code}.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, vehicle: sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(inv.id) });
  });

  // =========================================================================
  // 6. DEALER SALES, DISCOUNTS, PAYMENTS, INVOICE PDF, CANCELLATION & REFUNDS
  // =========================================================================
  router.get('/sales', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');
    const dealerFilter = req.query.dealerId ? String(req.query.dealerId).trim() : '';
    const paymentFilter = req.query.paymentStatus ? String(req.query.paymentStatus).trim() : '';

    let rows = sqlite
      .prepare(
        `SELECT s.*, d.business_name as dealer_name, d.dealer_code,
                c.full_name as customer_name, c.phone as customer_phone, c.email as customer_email,
                sh.name as showroom_name
         FROM dealer_sales s
         JOIN dealer_accounts d ON d.id = s.dealer_id
         LEFT JOIN dealer_customers c ON c.id = s.customer_id
         LEFT JOIN dealer_showrooms sh ON sh.id = s.showroom_id
         WHERE ${scopeSql}
         ORDER BY s.created_at DESC`
      )
      .all(...scopeParams) as any[];

    if (dealerFilter) rows = rows.filter((r) => r.dealer_id === dealerFilter);
    if (paymentFilter) rows = rows.filter((r) => r.payment_status === paymentFilter);

    const dealerIds = Array.from(new Set(rows.map((r) => r.dealer_id)));
    const idSql = dealerIds.length ? dealerIds.map(() => '?').join(',') : "'__none__'";
    const customers = sqlite
      .prepare(`SELECT id, dealer_id, full_name, phone, email, city, interested_model FROM dealer_customers WHERE dealer_id IN (${idSql}) ORDER BY full_name ASC`)
      .all(...(dealerIds.length ? dealerIds : []));

    res.json({ sales: rows, customers });
  });

  router.post('/sales', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canRecordSales) {
      res.status(403).json({ error: 'Access Denied: Insufficient permission to record dealership sales.' });
      return;
    }

    const body = req.body || {};
    const targetDealerId = scope.selfOnly ? scope.selfDealerId! : String(body.dealerId || '').trim();
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(targetDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const inventoryId = String(body.inventoryId || '').trim();
    const inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ? AND dealer_id = ?').get(inventoryId, dealer.id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Selected vehicle inventory unit not found under this dealer.' });
      return;
    }
    if (inv.availability_status === 'Sold') {
      res.status(409).json({ error: `Vehicle ${inv.stock_number} (${inv.vin}) is already marked as Sold.` });
      return;
    }

    const listPricePkr = Number(body.listPricePkr || inv.approved_selling_price_pkr || 0);
    const discountPkr = Math.max(0, Number(body.discountPkr || 0));
    if (listPricePkr <= 0 || discountPkr >= listPricePkr) {
      res.status(400).json({ error: 'Invalid selling price or discount amount.' });
      return;
    }

    const netSaleAmount = Math.round(listPricePkr - discountPkr);
    const discountApprovedImmediately = discountPkr > 0 && scope.canApproveDiscounts && Boolean(body.approveDiscount);
    const discountStatus = discountPkr === 0 ? 'None' : discountApprovedImmediately ? 'Approved' : 'Pending Approval';
    const effectiveSaleAmount = discountPkr > 0 && !discountApprovedImmediately ? listPricePkr : netSaleAmount;

    // Verified payment handling: strictly NO fake paid status without verified bank/provider ref
    const paymentRef = body.paymentProviderRef ? String(body.paymentProviderRef).trim() : '';
    const paidAmountPkr = paymentRef && scope.canVerifyPayments ? Number(body.paidAmountPkr || effectiveSaleAmount) : 0;
    const paymentStatus =
      paymentRef && scope.canVerifyPayments
        ? paidAmountPkr >= effectiveSaleAmount
          ? 'Payment Verified'
          : 'Partial Payment'
        : 'Pending Verification';

    const salesDate = body.salesDate ? String(body.salesDate).slice(0, 10) : nowIso().slice(0, 10);
    const showroomId = body.showroomId ? String(body.showroomId) : inv.showroom_id || null;
    const now = nowIso();
    const saleId = `dsale_${generateSecureToken(6)}`;
    const saleRef = `SLS-${new Date().getFullYear()}-${generateNumericOtp(5)}`;
    const invoiceNumber = `INV-${saleRef}`;

    let customerId = body.customerId ? String(body.customerId).trim() : '';
    let customerName = String(body.customerName || '').trim();
    let customerPhone = String(body.customerPhone || '').trim();
    let customerEmail = String(body.customerEmail || '').trim();

    if (!customerId && (!customerName || !customerPhone)) {
      res.status(400).json({ error: 'Select an existing dealer customer or enter customer full name and phone.' });
      return;
    }

    const tx = sqlite.transaction(() => {
      if (!customerId) {
        customerId = `dcust_${generateSecureToken(6)}`;
        sqlite
          .prepare(
            `INSERT INTO dealer_customers (
              id, dealer_id, company_id, country_id, branch_id, full_name, email, phone,
              city, interested_model, requirements, inquiry_status, test_drive_status,
              communication_history_json, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Vehicle Sale Purchase', 'Closed', 'Completed', '[]', ?, ?)`
          )
          .run(
            customerId,
            dealer.id,
            dealer.company_id,
            dealer.country_id,
            dealer.branch_id || null,
            customerName,
            customerEmail,
            customerPhone,
            String(body.customerCity || 'Karachi'),
            `${inv.model} ${inv.variant}`,
            now,
            now
          );
      } else {
        const cRow = sqlite.prepare('SELECT * FROM dealer_customers WHERE id = ? AND dealer_id = ?').get(customerId, dealer.id) as any;
        if (!cRow) {
          throw new Error('Selected customer does not belong to this dealer.');
        }
        customerName = cRow.full_name;
        customerPhone = cRow.phone;
        customerEmail = cRow.email;
      }

      const invoicePdf = buildSimplePdfBuffer(`BYD 360 Official Vehicle Sales Invoice - ${invoiceNumber}`, [
        'BYD PAKISTAN 360 — OFFICIAL DEALERSHIP VEHICLE INVOICE',
        'Founder & CEO: Intekhab Alam',
        `Invoice No: ${invoiceNumber} | Sale Ref: ${saleRef}`,
        `Date of Sale: ${salesDate}`,
        `Authorized Dealer: ${dealer.business_name} (${dealer.dealer_code})`,
        `Customer: ${customerName} (${customerPhone}) ${customerEmail ? '| ' + customerEmail : ''}`,
        `Vehicle: ${inv.model} ${inv.variant} (${inv.exterior_color})`,
        `VIN: ${inv.vin} | Stock No: ${inv.stock_number}`,
        `List Price (PKR): ${listPricePkr.toLocaleString()}`,
        `Discount (PKR): ${discountPkr.toLocaleString()} (${discountStatus})`,
        `Net Invoice Total (PKR): ${effectiveSaleAmount.toLocaleString()}`,
        `Payment Status: ${paymentStatus}${paymentRef ? ' | Ref: ' + paymentRef : ' (Awaiting Verified Settlement)'}`,
      ]);

      const receiptDoc = savePrivateDealerFile({
        buffer: invoicePdf,
        originalName: `${invoiceNumber}.pdf`,
        mimeType: 'application/pdf',
        dealerId: dealer.id,
        companyId: dealer.company_id,
        docType: 'Sale Receipt',
        title: `Vehicle Invoice — ${invoiceNumber}`,
        uploadedById: req.auth!.userId,
        uploadedByRole: req.auth!.role,
        verificationStatus: 'Verified',
        reviewedBy: req.auth!.fullName,
      });

      sqlite
        .prepare(
          `INSERT INTO dealer_sales (
            id, sale_ref, booking_id, dealer_id, customer_id, inventory_id,
            company_id, country_id, branch_id, showroom_id, vehicle_model, vin,
            sales_date, list_price_pkr, discount_pkr, discount_status, discount_approved_by,
            sale_amount_pkr, paid_amount_pkr, payment_status, payment_provider_ref,
            delivery_status, invoice_number, receipt_doc_id, verified_by, notes, created_at, updated_at
          ) VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Handover', ?, ?, ?, ?, ?, ?)`
        )
        .run(
          saleId,
          saleRef,
          dealer.id,
          customerId,
          inv.id,
          dealer.company_id,
          dealer.country_id,
          dealer.branch_id || null,
          showroomId,
          `${inv.model} ${inv.variant}`,
          inv.vin,
          salesDate,
          listPricePkr,
          discountPkr,
          discountStatus,
          discountApprovedImmediately ? req.auth!.fullName : null,
          effectiveSaleAmount,
          paidAmountPkr,
          paymentStatus,
          paymentRef || null,
          invoiceNumber,
          receiptDoc.id,
          paymentRef && scope.canVerifyPayments ? req.auth!.fullName : null,
          String(body.notes || ''),
          now,
          now
        );

      sqlite
        .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Sold', booking_status = 'Completed', updated_at = ? WHERE id = ?")
        .run(now, inv.id);

      sqlite
        .prepare(
          `INSERT INTO dealer_inventory_history (
            id, inventory_id, dealer_id, company_id, action_type, previous_status, new_status,
            notes, actor_id, actor_name, created_at
          ) VALUES (?, ?, ?, ?, 'Delivery', ?, 'Sold', ?, ?, ?, ?)`
        )
        .run(
          `dih_${generateSecureToken(6)}`,
          inv.id,
          dealer.id,
          dealer.company_id,
          inv.availability_status,
          `Allocated to Sale ${saleRef} (${customerName}).`,
          req.auth!.userId,
          req.auth!.fullName,
          now
        );

      // Calculate commission from configurable rules
      const calc = resolveCommissionForSale({
        companyId: dealer.company_id,
        dealerId: dealer.id,
        vehicleModel: `${inv.model} ${inv.variant}`,
        saleAmountPkr: effectiveSaleAmount,
        fallbackRatePct: Number(dealer.commission_rate_pct || 4.5),
      });

      sqlite
        .prepare(
          `INSERT INTO dealer_commissions (
            id, dealer_id, sale_id, company_id, country_id, branch_id, rule_id, rule_type,
            fixed_amount_pkr, sale_amount_pkr, commission_rate_pct, commission_amount_pkr,
            status, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?)`
        )
        .run(
          `dcom_${generateSecureToken(6)}`,
          dealer.id,
          saleId,
          dealer.company_id,
          dealer.country_id,
          dealer.branch_id || null,
          calc.ruleId,
          calc.ruleType,
          calc.fixedAmountPkr,
          effectiveSaleAmount,
          calc.ratePct,
          calc.commissionAmountPkr,
          `Auto-calculated (${calc.ruleType}) upon Sale ${saleRef}.`,
          now,
          now
        );
    });

    try {
      tx();
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Unable to record sale.' });
      return;
    }

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_SALE_RECORDED',
      module: 'Dealer Sales',
      targetId: saleRef,
      details: `Recorded sale ${saleRef} (${inv.model} / VIN ${inv.vin}) for PKR ${effectiveSaleAmount.toLocaleString()}.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(saleId),
    });
  });

  router.patch('/sales/:id/discount', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canApproveDiscounts) {
      res.status(403).json({ error: 'Access Denied: Only authorized approvers can approve or reject sales discounts.' });
      return;
    }

    const sale = sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(req.params.id) as any;
    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(sale.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const decision = String(req.body?.decision || '').toLowerCase();
    if (!['approve', 'reject'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be "approve" or "reject".' });
      return;
    }

    const now = nowIso();
    const listPrice = Number(sale.list_price_pkr || sale.sale_amount_pkr);
    const discount = Number(sale.discount_pkr || 0);
    const nextSaleAmount = decision === 'approve' ? Math.max(0, listPrice - discount) : listPrice;

    const tx = sqlite.transaction(() => {
      sqlite
        .prepare(
          `UPDATE dealer_sales
           SET discount_status = ?, discount_approved_by = ?, sale_amount_pkr = ?, updated_at = ?
           WHERE id = ?`
        )
        .run(
          decision === 'approve' ? 'Approved' : 'Rejected',
          req.auth!.fullName,
          nextSaleAmount,
          now,
          sale.id
        );

      // Update unpaid commission amount if not yet paid
      const comm = sqlite.prepare("SELECT * FROM dealer_commissions WHERE sale_id = ? AND status != 'Paid' AND status != 'Voided'").get(sale.id) as any;
      if (comm) {
        const nextCommAmt =
          comm.rule_type === 'Fixed'
            ? Number(comm.fixed_amount_pkr || comm.commission_amount_pkr)
            : Math.round((nextSaleAmount * Number(comm.commission_rate_pct || 4.5)) / 100);
        sqlite
          .prepare('UPDATE dealer_commissions SET sale_amount_pkr = ?, commission_amount_pkr = ?, updated_at = ? WHERE id = ?')
          .run(nextSaleAmount, nextCommAmt, now, comm.id);
      }
    });
    tx();

    res.json({ success: true, sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(sale.id) });
  });

  router.patch('/sales/:id/payment', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canVerifyPayments) {
      res.status(403).json({ error: 'Access Denied: Only authorized governance/finance officers may verify payments.' });
      return;
    }

    const sale = sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(req.params.id) as any;
    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(sale.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    if (sale.delivery_status === 'Cancelled' || sale.payment_status === 'Refunded') {
      res.status(409).json({ error: 'Cannot verify payment on a cancelled/refunded sale.' });
      return;
    }

    const paymentRef = String(req.body?.paymentProviderRef || '').trim();
    const paidAmount = Number(req.body?.paidAmountPkr || 0);
    if (!paymentRef || paymentRef.length < 4 || paidAmount <= 0) {
      res.status(400).json({ error: 'A verified bank/settlement reference (min 4 chars) and positive paid amount are required.' });
      return;
    }

    const nextStatus = paidAmount >= Number(sale.sale_amount_pkr) ? 'Payment Verified' : 'Partial Payment';
    const now = nowIso();
    sqlite
      .prepare(
        `UPDATE dealer_sales
         SET paid_amount_pkr = ?, payment_status = ?, payment_provider_ref = ?, verified_by = ?, updated_at = ?
         WHERE id = ?`
      )
      .run(paidAmount, nextStatus, paymentRef, req.auth!.fullName, now, sale.id);

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_SALE_PAYMENT_VERIFIED',
      module: 'Dealer Sales',
      targetId: sale.sale_ref,
      details: `Verified PKR ${paidAmount.toLocaleString()} settlement (${paymentRef}).`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(sale.id) });
  });

  router.patch('/sales/:id/delivery', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const sale = sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(req.params.id) as any;
    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(sale.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const nextDelivery = String(req.body?.deliveryStatus || 'Delivered').trim();
    if (!['Pending Handover', 'In Transit', 'Ready for Handover', 'Delivered'].includes(nextDelivery)) {
      res.status(400).json({ error: 'Invalid delivery status.' });
      return;
    }
    const now = nowIso();
    sqlite
      .prepare('UPDATE dealer_sales SET delivery_status = ?, delivered_at = ?, updated_at = ? WHERE id = ?')
      .run(nextDelivery, nextDelivery === 'Delivered' ? now : sale.delivered_at, now, sale.id);

    if (sale.inventory_id) {
      sqlite
        .prepare('UPDATE dealer_vehicle_inventory SET delivery_status = ?, delivery_date = ?, updated_at = ? WHERE id = ?')
        .run(nextDelivery, nextDelivery === 'Delivered' ? now.slice(0, 10) : null, now, sale.inventory_id);
    }

    res.json({ success: true, sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(sale.id) });
  });

  router.post('/sales/:id/cancel-refund', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canCancelRefund) {
      res.status(403).json({ error: 'Access Denied: Insufficient authority to cancel sales or issue refunds.' });
      return;
    }

    const sale = sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(req.params.id) as any;
    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(sale.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    if (sale.delivery_status === 'Cancelled' || sale.refund_status === 'Refund Processed') {
      res.status(409).json({ error: 'Sale is already cancelled/refunded.' });
      return;
    }

    const reason = String(req.body?.reason || '').trim();
    if (!reason) {
      res.status(400).json({ error: 'Cancellation / refund reason is required.' });
      return;
    }
    const refundAmount = Math.max(0, Math.min(Number(sale.paid_amount_pkr || 0), Number(req.body?.refundAmountPkr ?? sale.paid_amount_pkr ?? 0)));
    const now = nowIso();

    const tx = sqlite.transaction(() => {
      sqlite
        .prepare(
          `UPDATE dealer_sales
           SET delivery_status = 'Cancelled',
               payment_status = ?,
               refund_amount_pkr = ?,
               refund_status = ?,
               cancellation_reason = ?,
               cancelled_by = ?,
               cancelled_at = ?,
               updated_at = ?
           WHERE id = ?`
        )
        .run(
          refundAmount > 0 ? 'Refunded' : 'Cancelled',
          refundAmount,
          refundAmount > 0 ? 'Refund Processed' : 'Cancelled - No Refund',
          reason,
          req.auth!.fullName,
          now,
          now,
          sale.id
        );

      if (sale.inventory_id) {
        sqlite
          .prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Available', booking_status = 'Unbooked', delivery_status = 'At Showroom', updated_at = ? WHERE id = ?")
          .run(now, sale.inventory_id);

        sqlite
          .prepare(
            `INSERT INTO dealer_inventory_history (
              id, inventory_id, dealer_id, company_id, action_type, previous_status, new_status,
              notes, actor_id, actor_name, created_at
            ) VALUES (?, ?, ?, ?, 'Cancelled', 'Sold', 'Available', ?, ?, ?, ?)`
          )
          .run(
            `dih_${generateSecureToken(6)}`,
            sale.inventory_id,
            dealer.id,
            dealer.company_id,
            `Sale ${sale.sale_ref} cancelled (${reason}); vehicle restored to Available.`,
            req.auth!.userId,
            req.auth!.fullName,
            now
          );
      }

      sqlite
        .prepare("UPDATE dealer_commissions SET status = 'Voided', notes = COALESCE(notes, '') || ' | Voided due to sale cancellation.', updated_at = ? WHERE sale_id = ? AND status != 'Paid'")
        .run(now, sale.id);
    });
    tx();

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_SALE_CANCELLED_REFUNDED',
      module: 'Dealer Sales',
      targetId: sale.sale_ref,
      details: `Cancelled sale ${sale.sale_ref}; refund PKR ${refundAmount.toLocaleString()}; reason: ${reason}.`,
      ipAddress: getClientIp(req),
      status: 'WARNING',
    });

    res.json({ success: true, sale: sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(sale.id) });
  });

  router.get('/sales/:id/invoice.pdf', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const sale = sqlite
      .prepare(
        `SELECT s.*, c.full_name as customer_name, c.phone as customer_phone, c.email as customer_email
         FROM dealer_sales s
         LEFT JOIN dealer_customers c ON c.id = s.customer_id
         WHERE s.id = ?`
      )
      .get(req.params.id) as any;
    if (!sale) {
      res.status(404).json({ error: 'Sale record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(sale.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const invNo = sale.invoice_number || `INV-${sale.sale_ref}`;
    const pdfBuf = buildSimplePdfBuffer(`BYD 360 Official Tax & Sales Invoice - ${invNo}`, [
      'BYD PAKISTAN 360 — AUTHORIZED DEALERSHIP TAX INVOICE',
      'Founder & CEO: Intekhab Alam',
      `Invoice Number: ${invNo} | Sale Ref: ${sale.sale_ref}`,
      `Sales Date: ${sale.sales_date || String(sale.created_at).slice(0, 10)}`,
      `Dealer: ${dealer.business_name} (${dealer.dealer_code})`,
      `Customer: ${sale.customer_name || 'Verified Buyer'} | ${sale.customer_phone || ''}`,
      `Vehicle Model: ${sale.vehicle_model}`,
      `VIN: ${sale.vin}`,
      `List Price: PKR ${Number(sale.list_price_pkr || sale.sale_amount_pkr).toLocaleString()}`,
      `Discount: PKR ${Number(sale.discount_pkr || 0).toLocaleString()} (${sale.discount_status || 'None'})`,
      `Total Payable: PKR ${Number(sale.sale_amount_pkr || 0).toLocaleString()}`,
      `Paid Amount: PKR ${Number(sale.paid_amount_pkr || 0).toLocaleString()} (${sale.payment_status})`,
      `Settlement Reference: ${sale.payment_provider_ref || 'Pending Verification'}`,
      `Delivery Status: ${sale.delivery_status}`,
    ]);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${invNo}.pdf"`);
    res.send(pdfBuf);
  });

  // =========================================================================
  // 7. DEALER COMMISSIONS & CONFIGURABLE COMMISSION RULES
  // =========================================================================
  router.get('/commissions', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const commissions = sqlite
      .prepare(
        `SELECT cm.*, d.business_name as dealer_name, d.dealer_code, s.sale_ref, s.vehicle_model, s.vin, s.payment_status as sale_payment_status
         FROM dealer_commissions cm
         JOIN dealer_accounts d ON d.id = cm.dealer_id
         LEFT JOIN dealer_sales s ON s.id = cm.sale_id
         WHERE ${scopeSql}
         ORDER BY cm.created_at DESC`
      )
      .all(...scopeParams) as any[];

    const rules = sqlite
      .prepare(
        `SELECT r.*, c.name as company_name, d.business_name as dealer_name, d.dealer_code
         FROM dealer_commission_rules r
         LEFT JOIN companies c ON c.id = r.company_id
         LEFT JOIN dealer_accounts d ON d.id = r.dealer_id
         WHERE (${scope.restrictedCompanyId ? 'r.company_id = ?' : '1=1'})
           AND (${scope.selfOnly && scope.selfDealerId ? '(r.dealer_id IS NULL OR r.dealer_id = ?)' : '1=1'})
         ORDER BY r.created_at DESC`
      )
      .all(
        ...(scope.restrictedCompanyId ? [scope.restrictedCompanyId] : []),
        ...(scope.selfOnly && scope.selfDealerId ? [scope.selfDealerId] : [])
      );

    res.json({
      commissions,
      rules,
      summary: {
        pendingPkr: commissions.filter((c) => c.status === 'Pending').reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0),
        approvedPkr: commissions.filter((c) => c.status === 'Approved').reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0),
        paidPkr: commissions.filter((c) => c.status === 'Paid').reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0),
        voidedPkr: commissions.filter((c) => c.status === 'Voided').reduce((acc, c) => acc + Number(c.commission_amount_pkr || 0), 0),
      },
    });
  });

  router.post('/commissions/rules', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageCommissionRules) {
      res.status(403).json({ error: 'Access Denied: Insufficient authority to configure commission rules.' });
      return;
    }

    const body = req.body || {};
    const companyId = scope.restrictedCompanyId || String(body.companyId || 'comp_byd_pk').trim();
    const ruleName = String(body.ruleName || '').trim();
    const ruleType = body.ruleType === 'Fixed' ? 'Fixed' : 'Percentage';
    const ratePct = ruleType === 'Percentage' ? Math.min(25, Math.max(0.1, Number(body.ratePct || 4.5))) : 0;
    const fixedAmountPkr = ruleType === 'Fixed' ? Math.max(1000, Number(body.fixedAmountPkr || 0)) : 0;

    if (!ruleName) {
      res.status(400).json({ error: 'Commission rule name is required.' });
      return;
    }

    const ruleId = `dcr_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(
        `INSERT INTO dealer_commission_rules (
          id, company_id, dealer_id, vehicle_model, rule_name, rule_type,
          rate_pct, fixed_amount_pkr, min_sale_pkr, is_active, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`
      )
      .run(
        ruleId,
        companyId,
        body.dealerId ? String(body.dealerId).trim() : null,
        String(body.vehicleModel || 'ALL').trim() || 'ALL',
        ruleName,
        ruleType,
        ratePct,
        fixedAmountPkr,
        Math.max(0, Number(body.minSalePkr || 0)),
        req.auth!.fullName,
        now,
        now
      );

    logDealerModuleAudit({
      dealerId: body.dealerId || null,
      companyId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMMISSION_RULE_CREATED',
      module: 'Dealer Commissions',
      targetId: ruleId,
      details: `Created rule "${ruleName}" (${ruleType}: ${ruleType === 'Fixed' ? fixedAmountPkr : ratePct + '%'}).`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, rule: sqlite.prepare('SELECT * FROM dealer_commission_rules WHERE id = ?').get(ruleId) });
  });

  router.patch('/commissions/:id/approve', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canApprovePayCommissions) {
      res.status(403).json({ error: 'Access Denied: Insufficient authority to approve commissions.' });
      return;
    }

    const comm = sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(req.params.id) as any;
    if (!comm) {
      res.status(404).json({ error: 'Commission record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(comm.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    if (comm.status === 'Paid' || comm.status === 'Voided') {
      res.status(409).json({ error: `Cannot approve commission in "${comm.status}" state.` });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare("UPDATE dealer_commissions SET status = 'Approved', approved_by = ?, approved_at = ?, updated_at = ? WHERE id = ?")
      .run(req.auth!.fullName, now, now, comm.id);

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_COMMISSION_APPROVED',
      module: 'Dealer Commissions',
      targetId: comm.id,
      details: `Approved commission PKR ${Number(comm.commission_amount_pkr).toLocaleString()}.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, commission: sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(comm.id) });
  });

  router.patch('/commissions/:id/pay', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canApprovePayCommissions) {
      res.status(403).json({ error: 'Access Denied: Insufficient authority to record commission payouts.' });
      return;
    }

    const comm = sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(req.params.id) as any;
    if (!comm) {
      res.status(404).json({ error: 'Commission record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(comm.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    if (comm.status === 'Paid') {
      res.status(409).json({ error: `Duplicate payout prevented: commission ${comm.id} was already paid (${comm.payout_reference}).` });
      return;
    }
    if (comm.status !== 'Approved') {
      res.status(400).json({ error: 'Commission must be Approved before payout settlement.' });
      return;
    }

    const payoutRef = String(req.body?.payoutReference || '').trim();
    if (!payoutRef || payoutRef.length < 4) {
      res.status(400).json({ error: 'Verified bank transfer / payout reference (min 4 chars) is required.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare("UPDATE dealer_commissions SET status = 'Paid', paid_at = ?, payout_reference = ?, updated_at = ? WHERE id = ?")
      .run(now, payoutRef, now, comm.id);

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_COMMISSION_PAID',
      module: 'Dealer Commissions',
      targetId: comm.id,
      details: `Paid PKR ${Number(comm.commission_amount_pkr).toLocaleString()} (Ref: ${payoutRef}).`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, commission: sqlite.prepare('SELECT * FROM dealer_commissions WHERE id = ?').get(comm.id) });
  });

  // =========================================================================
  // 8. DEALER TARGETS & PERFORMANCE ANALYTICS
  // =========================================================================
  router.get('/targets', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const targets = sqlite
      .prepare(
        `SELECT t.*, d.business_name as dealer_name, d.dealer_code
         FROM dealer_targets t
         JOIN dealer_accounts d ON d.id = t.dealer_id
         WHERE ${scopeSql}
         ORDER BY t.period_key DESC, t.created_at DESC`
      )
      .all(...scopeParams) as any[];

    const dealerIds = Array.from(new Set(targets.map((t) => t.dealer_id)));
    const idSql = dealerIds.length ? dealerIds.map(() => '?').join(',') : "'__none__'";
    const sales = sqlite
      .prepare(`SELECT dealer_id, vehicle_model, sale_amount_pkr, sales_date, created_at, delivery_status, payment_status FROM dealer_sales WHERE dealer_id IN (${idSql})`)
      .all(...(dealerIds.length ? dealerIds : [])) as any[];

    const activeSales = sales.filter((s) => s.delivery_status !== 'Cancelled' && s.payment_status !== 'Refunded');
    const enriched = targets.map((t) => {
      const matching = activeSales.filter((s) => {
        if (s.dealer_id !== t.dealer_id) return false;
        const modelOk =
          String(t.vehicle_model || 'ALL').toUpperCase() === 'ALL' ||
          String(s.vehicle_model || '').toLowerCase().includes(String(t.vehicle_model || '').toLowerCase());
        const dStr = s.sales_date || String(s.created_at || '').slice(0, 10);
        return modelOk && isTargetPeriodMatch(dStr, t.period_type, t.period_key);
      });
      const achievedUnits = matching.length;
      const achievedRevenuePkr = matching.reduce((acc, s) => acc + Number(s.sale_amount_pkr || 0), 0);
      const targetUnits = Number(t.target_units || 0);
      const achievementPct = targetUnits > 0 ? Math.round((achievedUnits / targetUnits) * 1000) / 10 : 0;
      return {
        ...t,
        achievedUnits,
        achievedRevenuePkr,
        remainingUnits: Math.max(0, targetUnits - achievedUnits),
        achievementPct,
      };
    });

    res.json({ targets: enriched });
  });

  router.post('/targets', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageTargets) {
      res.status(403).json({ error: 'Access Denied: Insufficient authority to assign dealer sales targets.' });
      return;
    }

    const body = req.body || {};
    const targetDealerId = String(body.dealerId || '').trim();
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(targetDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const periodType = ['Monthly', 'Quarterly', 'Yearly'].includes(String(body.periodType))
      ? String(body.periodType)
      : 'Monthly';
    const periodKey = String(body.periodKey || new Date().toISOString().slice(0, 7)).trim();
    const targetUnits = Math.max(1, Number(body.targetUnits || 10));
    const targetRevenuePkr = Math.max(0, Number(body.targetRevenuePkr || 0));
    const vehicleModel = String(body.vehicleModel || 'ALL').trim() || 'ALL';

    const targetId = `dtgt_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(
        `INSERT INTO dealer_targets (
          id, dealer_id, company_id, period_type, period_key, vehicle_model,
          target_units, target_revenue_pkr, assigned_by, notes, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)`
      )
      .run(
        targetId,
        dealer.id,
        dealer.company_id,
        periodType,
        periodKey,
        vehicleModel,
        targetUnits,
        targetRevenuePkr,
        req.auth!.fullName,
        String(body.notes || ''),
        now,
        now
      );

    logDealerModuleAudit({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'DEALER_TARGET_ASSIGNED',
      module: 'Dealer Targets',
      targetId,
      details: `Assigned ${periodType} target (${periodKey}, ${vehicleModel}): ${targetUnits} units.`,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({ success: true, target: sqlite.prepare('SELECT * FROM dealer_targets WHERE id = ?').get(targetId) });
  });

  router.patch('/targets/:id', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canManageTargets) {
      res.status(403).json({ error: 'Access Denied.' });
      return;
    }

    const tgt = sqlite.prepare('SELECT * FROM dealer_targets WHERE id = ?').get(req.params.id) as any;
    if (!tgt) {
      res.status(404).json({ error: 'Target record not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(tgt.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const body = req.body || {};
    sqlite
      .prepare('UPDATE dealer_targets SET target_units = ?, target_revenue_pkr = ?, status = ?, notes = ?, updated_at = ? WHERE id = ?')
      .run(
        body.targetUnits !== undefined ? Math.max(1, Number(body.targetUnits)) : tgt.target_units,
        body.targetRevenuePkr !== undefined ? Math.max(0, Number(body.targetRevenuePkr)) : tgt.target_revenue_pkr,
        body.status !== undefined ? String(body.status) : tgt.status,
        body.notes !== undefined ? String(body.notes) : tgt.notes,
        nowIso(),
        tgt.id
      );

    res.json({ success: true, target: sqlite.prepare('SELECT * FROM dealer_targets WHERE id = ?').get(tgt.id) });
  });

  // =========================================================================
  // 9. DEALER DOCUMENTS VAULT (PRIVATE STORAGE + RBAC + PREVIEW/DOWNLOAD)
  // =========================================================================
  router.get('/documents', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const docs = sqlite
      .prepare(
        `SELECT doc.id, doc.dealer_id, doc.showroom_id, doc.doc_type, doc.title, doc.original_filename,
                doc.mime_type, doc.size_bytes, doc.verification_status, doc.reviewed_by, doc.review_notes,
                doc.issue_date, doc.expiry_date, doc.uploaded_by_role, doc.created_at,
                d.business_name as dealer_name, d.dealer_code
         FROM dealer_documents doc
         JOIN dealer_accounts d ON d.id = doc.dealer_id
         WHERE ${scopeSql}
         ORDER BY doc.created_at DESC`
      )
      .all(...scopeParams);

    res.json({ documents: docs });
  });

  router.post('/documents', upload.single('file'), (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canUploadDocuments) {
      res.status(403).json({ error: 'Access Denied.' });
      return;
    }

    const file = req.file;
    if (!file) {
      res.status(400).json({ error: 'Document file is required.' });
      return;
    }
    if (!ALLOWED_DOC_MIMES.has(file.mimetype)) {
      res.status(400).json({ error: 'Unsupported document type. Allowed: PDF, PNG, JPEG, WEBP, TXT, CSV, DOC, DOCX.' });
      return;
    }

    const targetDealerId = scope.selfOnly ? scope.selfDealerId! : String(req.body?.dealerId || '').trim();
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(targetDealerId) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    try {
      const saved = savePrivateDealerFile({
        buffer: file.buffer,
        originalName: file.originalname,
        mimeType: file.mimetype,
        dealerId: dealer.id,
        companyId: dealer.company_id,
        docType: String(req.body?.docType || 'Business Registration'),
        title: String(req.body?.title || file.originalname),
        uploadedById: req.auth!.userId,
        uploadedByRole: req.auth!.role,
        verificationStatus: scope.canVerifyDocuments && req.body?.autoVerify === 'true' ? 'Verified' : 'Pending Verification',
        reviewedBy: scope.canVerifyDocuments && req.body?.autoVerify === 'true' ? req.auth!.fullName : null,
      });

      if (req.body?.showroomId || req.body?.issueDate || req.body?.expiryDate) {
        sqlite
          .prepare('UPDATE dealer_documents SET showroom_id = ?, issue_date = ?, expiry_date = ? WHERE id = ?')
          .run(
            req.body?.showroomId ? String(req.body.showroomId) : null,
            req.body?.issueDate ? String(req.body.issueDate) : null,
            req.body?.expiryDate ? String(req.body.expiryDate) : null,
            saved.id
          );
      }

      logDealerModuleAudit({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'DEALER_DOCUMENT_UPLOADED',
        module: 'Dealer Documents',
        targetId: saved.id,
        details: `Uploaded "${req.body?.title || file.originalname}" (${req.body?.docType || 'Document'}).`,
        ipAddress: getClientIp(req),
      });

      res.status(201).json({
        success: true,
        document: sqlite.prepare('SELECT id, dealer_id, showroom_id, doc_type, title, original_filename, mime_type, size_bytes, verification_status, created_at FROM dealer_documents WHERE id = ?').get(saved.id),
      });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Document upload failed.' });
    }
  });

  router.patch('/documents/:id/verify', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canVerifyDocuments) {
      res.status(403).json({ error: 'Access Denied: Only authorized governance officers can verify dealer documents.' });
      return;
    }

    const doc = sqlite.prepare('SELECT * FROM dealer_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(doc.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const status = req.body?.status === 'Rejected' ? 'Rejected' : 'Verified';
    const notes = String(req.body?.notes || '').trim();
    const now = nowIso();

    sqlite
      .prepare('UPDATE dealer_documents SET verification_status = ?, reviewed_by = ?, review_notes = ?, updated_at = ? WHERE id = ?')
      .run(status, req.auth!.fullName, notes || null, now, doc.id);

    sqlite
      .prepare(
        `INSERT INTO dealer_verification_history (
          id, dealer_id, showroom_id, target_type, target_id, previous_status, new_status,
          rejection_reason, notes, reviewed_by_id, reviewed_by_name, reviewed_by_role, created_at
        ) VALUES (?, ?, ?, 'Document', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        `dvh_${generateSecureToken(6)}`,
        dealer.id,
        doc.showroom_id || null,
        doc.id,
        doc.verification_status,
        status,
        status === 'Rejected' ? notes || 'Document rejected' : null,
        `${doc.doc_type}: ${doc.title}`,
        req.auth!.userId,
        req.auth!.fullName,
        req.auth!.role,
        now
      );

    res.json({ success: true, verificationStatus: status });
  });

  router.get('/documents/:id/download', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    const doc = sqlite.prepare('SELECT * FROM dealer_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(doc.dealer_id) as any;
    if (!assertDealerAccessible(req, res, scope, dealer)) return;

    const diskPath = path.join(PRIVATE_DEALER_DOCS_DIR, path.basename(doc.storage_key));
    if (!fs.existsSync(diskPath)) {
      res.status(404).json({ error: 'Document file not found on private storage.' });
      return;
    }
    const disposition = req.query.inline === '1' ? 'inline' : 'attachment';
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `${disposition}; filename="${path.basename(doc.original_filename || 'document')}"`);
    fs.createReadStream(diskPath).pipe(res);
  });

  // =========================================================================
  // 10. REPORTS & EXCEL / PDF / CSV EXPORTS
  // =========================================================================
  router.get('/reports/export', (req: Request, res: Response) => {
    const scope = (req as any).dealershipScope as DealershipScope;
    if (!scope.canExportReports) {
      res.status(403).json({ error: 'Access Denied: Your role lacks report export permission.' });
      return;
    }

    const format = String(req.query.format || 'xlsx').toLowerCase();
    const section = String(req.query.section || 'all').toLowerCase();
    const { sql: scopeSql, params: scopeParams } = buildScopeWhere(scope, 'd');

    const dealers = sqlite
      .prepare(
        `SELECT d.dealer_code, d.business_name, d.owner_contact_name, d.email, d.mobile, d.category,
                d.verification_status, d.status, d.commission_rate_pct, p.city, p.tax_id_ntn, p.registration_no
         FROM dealer_accounts d LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
         WHERE ${scopeSql}`
      )
      .all(...scopeParams) as any[];

    const dealerIds = sqlite
      .prepare(`SELECT d.id FROM dealer_accounts d WHERE ${scopeSql}`)
      .all(...scopeParams)
      .map((x: any) => x.id);
    const idSql = dealerIds.length ? dealerIds.map(() => '?').join(',') : "'__none__'";

    const showrooms = sqlite
      .prepare(`SELECT showroom_code, name, city, country, status, verification_status, manager_name, phone FROM dealer_showrooms WHERE dealer_id IN (${idSql})`)
      .all(...dealerIds) as any[];

    const inventory = sqlite
      .prepare(`SELECT stock_number, model, variant, exterior_color, vin, chassis_number, availability_status, approved_selling_price_pkr FROM dealer_vehicle_inventory WHERE dealer_id IN (${idSql})`)
      .all(...dealerIds) as any[];

    const sales = sqlite
      .prepare(`SELECT sale_ref, invoice_number, sales_date, vehicle_model, vin, list_price_pkr, discount_pkr, sale_amount_pkr, paid_amount_pkr, payment_status, delivery_status FROM dealer_sales WHERE dealer_id IN (${idSql})`)
      .all(...dealerIds) as any[];

    const commissions = sqlite
      .prepare(`SELECT id, sale_id, rule_type, commission_rate_pct, sale_amount_pkr, commission_amount_pkr, status, payout_reference, paid_at FROM dealer_commissions WHERE dealer_id IN (${idSql})`)
      .all(...dealerIds) as any[];

    if (format === 'pdf') {
      const lines = [
        `BYD PAKISTAN 360 — DEALERSHIP MANAGEMENT REPORT (${section.toUpperCase()})`,
        `Generated By: ${req.auth!.fullName} (${req.auth!.role}) | ${nowIso()}`,
        `Dealers: ${dealers.length} | Showrooms: ${showrooms.length} | Inventory: ${inventory.length} | Sales: ${sales.length} | Commissions: ${commissions.length}`,
        '--- DEALERS ---',
        ...dealers.slice(0, 20).map((d) => `${d.dealer_code} | ${d.business_name} | ${d.city} | ${d.verification_status} / ${d.status}`),
        '--- SALES ---',
        ...sales.slice(0, 20).map((s) => `${s.sale_ref} | ${s.vehicle_model} | PKR ${Number(s.sale_amount_pkr).toLocaleString()} | ${s.payment_status}`),
        '--- COMMISSIONS ---',
        ...commissions.slice(0, 20).map((c) => `${c.id} | PKR ${Number(c.commission_amount_pkr).toLocaleString()} | ${c.status} ${c.payout_reference || ''}`),
      ];
      const pdfBuf = buildSimplePdfBuffer('BYD 360 Dealership Network Report', lines);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="byd360-dealership-report.pdf"');
      res.send(pdfBuf);
      return;
    }

    if (format === 'csv') {
      const targetRows =
        section === 'sales'
          ? sales
          : section === 'inventory'
            ? inventory
            : section === 'commissions'
              ? commissions
              : section === 'showrooms'
                ? showrooms
                : dealers;
      const ws = XLSX.utils.json_to_sheet(targetRows.length ? targetRows : [{ note: 'No records' }]);
      const csv = XLSX.utils.sheet_to_csv(ws);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="byd360-dealership-${section}.csv"`);
      res.send(csv);
      return;
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dealers.length ? dealers : [{ empty: true }]), 'Dealers');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(showrooms.length ? showrooms : [{ empty: true }]), 'Showrooms');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(inventory.length ? inventory : [{ empty: true }]), 'Inventory');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sales.length ? sales : [{ empty: true }]), 'Sales');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(commissions.length ? commissions : [{ empty: true }]), 'Commissions');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="byd360-dealership-report.xlsx"');
    res.send(buf);
  });

  return router;
}
