import express, { Request, Response } from 'express';
import crypto from 'node:crypto';
import * as XLSX from 'xlsx';
import {
  sqlite,
  generateSecureToken,
  hashPassword,
  validatePasswordStrength,
  logOrganizationActivity,
  logCompanyActivity,
  logBranchActivity,
  logCountryActivity,
  logEmployeeActivity,
  logSecurityEvent,
  checkRbacAction,
  nowIso,
} from './db';
import { getClientIp, requireAuth } from './auth';
import { buildSimplePdfBuffer } from './dealer';

type ScopeMode =
  | 'founder'
  | 'super_admin'
  | 'company_admin'
  | 'country_manager'
  | 'branch_manager'
  | 'employee';

interface OrgActorScope {
  mode: ScopeMode;
  isFounder: boolean;
  isGlobal: boolean;
  restrictedCompanyId: string | null;
  restrictedCountryId: string | null;
  restrictedBranchId: string | null;
  canViewPii: boolean;
  canCreateCompanyEntities: boolean;
  canManageCountries: boolean;
  canManageCities: boolean;
  canManageHeadOffices: boolean;
  canManageRegionalOffices: boolean;
  canManageBranches: boolean;
  canManageDepartments: boolean;
  canManageStaff: boolean;
  canTransferStaff: boolean;
  canExportReports: boolean;
}

const DEFAULT_DEPARTMENTS = [
  'Administration',
  'Human Resources (HR)',
  'Finance & Accounts',
  'Sales & Marketing',
  'Vehicle Inventory',
  'Customer Relations',
  'Dealer Management',
  'IT & Technology',
  'Technical Support',
  'Service & Maintenance',
  'Security & Compliance',
  'Operations',
  'Logistics',
  'Legal Department',
];

const COUNTRY_SVG_COORDS: Record<string, { lat: number; lng: number; mapX: number; mapY: number; region: string }> = {
  PK: { lat: 30.3753, lng: 69.3451, mapX: 693, mapY: 166, region: 'South Asia' },
  AE: { lat: 23.4241, lng: 53.8478, mapX: 650, mapY: 185, region: 'Middle East' },
  SA: { lat: 23.8859, lng: 45.0792, mapX: 625, mapY: 184, region: 'Middle East' },
  GB: { lat: 55.3781, lng: -3.436, mapX: 490, mapY: 96, region: 'Europe' },
  DE: { lat: 51.1657, lng: 10.4515, mapX: 529, mapY: 108, region: 'Europe' },
  US: { lat: 37.0902, lng: -95.7129, mapX: 234, mapY: 147, region: 'North America' },
  CN: { lat: 35.8617, lng: 104.1954, mapX: 789, mapY: 150, region: 'East Asia' },
  TR: { lat: 38.9637, lng: 35.2433, mapX: 598, mapY: 142, region: 'Eurasia' },
  QA: { lat: 25.3548, lng: 51.1839, mapX: 642, mapY: 179, region: 'Middle East' },
  OM: { lat: 21.4735, lng: 55.9754, mapX: 655, mapY: 190, region: 'Middle East' },
};

function safeJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function maskPersonalValue(raw: string | null | undefined, reveal: boolean): string {
  if (!raw) return 'Not Provided';
  const str = String(raw).trim();
  if (reveal) return str;
  if (str.length <= 5) return '•••••';
  return `${str.slice(0, 3)}••••••${str.slice(-2)}`;
}

function resolveOrgScope(req: Request): OrgActorScope | null {
  const auth = req.auth;
  if (!auth) return null;

  if (auth.subjectType === 'founder') {
    return {
      mode: 'founder',
      isFounder: true,
      isGlobal: true,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canViewPii: true,
      canCreateCompanyEntities: true,
      canManageCountries: true,
      canManageCities: true,
      canManageHeadOffices: true,
      canManageRegionalOffices: true,
      canManageBranches: true,
      canManageDepartments: true,
      canManageStaff: true,
      canTransferStaff: true,
      canExportReports: true,
    };
  }

  if (auth.subjectType === 'super_admin') {
    const perms = new Set(auth.permissions || []);
    const rbacCreate = checkRbacAction('super_admin', auth.role, 'Companies & Branches', 'create');
    const rbacEdit = checkRbacAction('super_admin', auth.role, 'Companies & Branches', 'edit');
    return {
      mode: 'super_admin',
      isFounder: false,
      isGlobal: true,
      restrictedCompanyId: null,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canViewPii: perms.has('employees.manage'),
      canCreateCompanyEntities: (perms.has('users.create') || perms.has('users.update')) && (rbacCreate || rbacEdit),
      canManageCountries: perms.has('users.update') || perms.has('settings.manage'),
      canManageCities: perms.has('users.update') || perms.has('users.create'),
      canManageHeadOffices: perms.has('users.update') || perms.has('users.create'),
      canManageRegionalOffices: perms.has('users.update') || perms.has('users.create'),
      canManageBranches: perms.has('users.update') || perms.has('users.create'),
      canManageDepartments: perms.has('employees.manage') || perms.has('users.update'),
      canManageStaff: perms.has('employees.manage'),
      canTransferStaff: perms.has('employees.manage') || perms.has('users.update'),
      canExportReports: perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'company_admin' && auth.companyId) {
    const perms = new Set(auth.permissions || []);
    const canBranches = perms.has('branches.manage');
    const canEmployees = perms.has('employees.manage');
    return {
      mode: 'company_admin',
      isFounder: false,
      isGlobal: false,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: null,
      restrictedBranchId: null,
      canViewPii: canEmployees,
      canCreateCompanyEntities: perms.has('company.profile.manage') || canBranches,
      canManageCountries: false,
      canManageCities: canBranches,
      canManageHeadOffices: perms.has('company.profile.manage') || canBranches,
      canManageRegionalOffices: canBranches,
      canManageBranches: canBranches,
      canManageDepartments: canBranches || canEmployees,
      canManageStaff: canEmployees,
      canTransferStaff: canEmployees && canBranches,
      canExportReports: perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'country_manager' && auth.country) {
    const perms = new Set(auth.permissions || []);
    const canBranches = perms.has('branches.manage');
    const canEmployees = perms.has('employees.manage');
    return {
      mode: 'country_manager',
      isFounder: false,
      isGlobal: false,
      restrictedCompanyId: null,
      restrictedCountryId: auth.country.toUpperCase(),
      restrictedBranchId: null,
      canViewPii: canEmployees,
      canCreateCompanyEntities: false,
      canManageCountries: false,
      canManageCities: canBranches || perms.has('country.profile.manage'),
      canManageHeadOffices: false,
      canManageRegionalOffices: canBranches || perms.has('companies.operations.manage'),
      canManageBranches: canBranches,
      canManageDepartments: canBranches || canEmployees,
      canManageStaff: canEmployees,
      canTransferStaff: canEmployees && canBranches,
      canExportReports: perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'branch_manager' && auth.branchId && auth.companyId) {
    const perms = new Set(auth.permissions || []);
    const canEmployees = perms.has('employees.manage');
    return {
      mode: 'branch_manager',
      isFounder: false,
      isGlobal: false,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: auth.country ? auth.country.toUpperCase() : null,
      restrictedBranchId: auth.branchId,
      canViewPii: canEmployees,
      canCreateCompanyEntities: false,
      canManageCountries: false,
      canManageCities: false,
      canManageHeadOffices: false,
      canManageRegionalOffices: false,
      canManageBranches: perms.has('branch.profile.manage'),
      canManageDepartments: perms.has('branch.profile.manage') || canEmployees,
      canManageStaff: canEmployees,
      canTransferStaff: false,
      canExportReports: perms.has('reports.export') || perms.has('reports.view'),
    };
  }

  if (auth.subjectType === 'employee' && auth.companyId) {
    const roleLower = String(auth.role || '').toLowerCase();
    const isHrOrDeptHead = roleLower.includes('hr') || roleLower.includes('head') || roleLower.includes('manager');
    return {
      mode: 'employee',
      isFounder: false,
      isGlobal: false,
      restrictedCompanyId: auth.companyId,
      restrictedCountryId: auth.country ? auth.country.toUpperCase() : null,
      restrictedBranchId: auth.branchId || null,
      canViewPii: false,
      canCreateCompanyEntities: false,
      canManageCountries: false,
      canManageCities: false,
      canManageHeadOffices: false,
      canManageRegionalOffices: false,
      canManageBranches: false,
      canManageDepartments: isHrOrDeptHead,
      canManageStaff: roleLower.includes('hr'),
      canTransferStaff: false,
      canExportReports: false,
    };
  }

  return null;
}

function rejectScopeViolation(req: Request, res: Response, reason: string) {
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'ORG_SCOPE_ACCESS_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId || null,
    details: reason,
    ipAddress: getClientIp(req),
  });
  res.status(403).json({ error: reason });
}

function resolveDateBounds(periodRaw?: string, fromRaw?: string, toRaw?: string) {
  const period = String(periodRaw || 'all').toLowerCase();
  const now = new Date();
  const today = now.toISOString().slice(0, 10);

  if (period === 'daily') {
    return { period, fromIso: `${today}T00:00:00.000Z`, toIso: `${today}T23:59:59.999Z`, label: `Daily (${today})` };
  }
  if (period === 'monthly') {
    return { period, fromIso: `${today.slice(0, 7)}-01T00:00:00.000Z`, toIso: `${today}T23:59:59.999Z`, label: `Monthly (${today.slice(0, 7)})` };
  }
  if (period === 'yearly') {
    return { period, fromIso: `${today.slice(0, 4)}-01-01T00:00:00.000Z`, toIso: `${today}T23:59:59.999Z`, label: `Yearly (${today.slice(0, 4)})` };
  }
  if (period === 'custom' && (fromRaw || toRaw)) {
    const f = fromRaw ? `${String(fromRaw).slice(0, 10)}T00:00:00.000Z` : '2020-01-01T00:00:00.000Z';
    const t = toRaw ? `${String(toRaw).slice(0, 10)}T23:59:59.999Z` : `${today}T23:59:59.999Z`;
    return { period, fromIso: f, toIso: t, label: `Custom (${fromRaw || 'Start'} to ${toRaw || today})` };
  }
  return { period: 'all', fromIso: '2020-01-01T00:00:00.000Z', toIso: '2099-12-31T23:59:59.999Z', label: 'All-Time Verified Records' };
}

function syncCityRecord(countryId: string, cityName: string, stateProvince = '', lat?: number | null, lng?: number | null): string | null {
  const cleanCountry = String(countryId || '').trim().toUpperCase();
  const cleanName = String(cityName || '').trim();
  const cleanState = String(stateProvince || '').trim();
  if (!cleanCountry || !cleanName) return null;

  const normName = cleanName.toLowerCase();
  const normState = cleanState.toLowerCase();
  const existing = sqlite
    .prepare('SELECT id FROM cities WHERE country_id = ? AND normalized_name = ? AND normalized_state = ?')
    .get(cleanCountry, normName, normState) as any;
  if (existing) {
    if (typeof lat === 'number' && typeof lng === 'number') {
      sqlite.prepare('UPDATE cities SET latitude = COALESCE(latitude, ?), longitude = COALESCE(longitude, ?), updated_at = ? WHERE id = ?')
        .run(lat, lng, nowIso(), existing.id);
    }
    return existing.id;
  }

  const id = `city_${generateSecureToken(5)}`;
  const codePrefix = cleanName.replace(/[^A-Za-z]/g, '').toUpperCase().slice(0, 3) || 'CTY';
  const code = `${cleanCountry}-${codePrefix}-${Math.floor(10 + Math.random() * 89)}`;
  const ts = nowIso();
  sqlite
    .prepare(`
      INSERT INTO cities (
        id, country_id, city_code, name, normalized_name, state_province, normalized_state, latitude, longitude, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
    `)
    .run(id, cleanCountry, code, cleanName, normName, cleanState, normState, typeof lat === 'number' ? lat : null, typeof lng === 'number' ? lng : null, ts, ts);
  return id;
}

function auditOrg(
  req: Request,
  scope: {
    companyId?: string | null;
    countryId?: string | null;
    regionalOfficeId?: string | null;
    branchId?: string | null;
  },
  action: string,
  module: string,
  entityType: string,
  entityId: string | null,
  entityName: string | null,
  details: string
) {
  if (!req.auth) return;
  const ip = getClientIp(req);
  logOrganizationActivity({
    actorId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    scopeCompanyId: scope.companyId || null,
    scopeCountryId: scope.countryId || null,
    scopeRegionalOfficeId: scope.regionalOfficeId || null,
    scopeBranchId: scope.branchId || null,
    action,
    module,
    entityType,
    entityId,
    entityName,
    details,
    ipAddress: ip,
  });

  if (scope.companyId) {
    logCompanyActivity({
      companyId: scope.companyId,
      actorId: req.auth.userId,
      actorName: req.auth.fullName,
      actorRole: req.auth.role,
      action,
      module,
      targetId: entityId || entityName,
      details,
      ipAddress: ip,
    });
  }
  if (scope.branchId && scope.companyId) {
    logBranchActivity({
      branchId: scope.branchId,
      companyId: scope.companyId,
      countryId: scope.countryId || 'PK',
      managerId: req.auth.userId,
      actorName: req.auth.fullName,
      actorRole: req.auth.role,
      action,
      module,
      targetId: entityId || entityName,
      details,
      ipAddress: ip,
    });
  }
  if (scope.countryId && req.auth.subjectType === 'country_manager') {
    logCountryActivity({
      countryId: scope.countryId,
      managerId: req.auth.userId,
      actorName: req.auth.fullName,
      actorRole: req.auth.role,
      action,
      module,
      targetId: entityId || entityName,
      details,
      ipAddress: ip,
    });
  }
}

function getScopedCompanies(scope: OrgActorScope): any[] {
  if (scope.restrictedCompanyId) {
    return sqlite.prepare('SELECT * FROM companies WHERE id = ? ORDER BY name ASC').all(scope.restrictedCompanyId) as any[];
  }
  if (scope.restrictedCountryId) {
    return sqlite
      .prepare('SELECT * FROM companies WHERE UPPER(country) = ? OR id IN (SELECT DISTINCT company_id FROM branches WHERE UPPER(country_id) = ?) ORDER BY name ASC')
      .all(scope.restrictedCountryId, scope.restrictedCountryId) as any[];
  }
  return sqlite.prepare('SELECT * FROM companies ORDER BY created_at DESC').all() as any[];
}

export function createCompanyBranchManagementRouter() {
  const router = express.Router();
  router.use(requireAuth);

  router.use((req: Request, res: Response, next) => {
    const scope = resolveOrgScope(req);
    if (!scope) {
      rejectScopeViolation(req, res, 'Access denied: Organizational Company & Branch Management is restricted to authorized administrative or office staff accounts.');
      return;
    }
    (req as any).orgScope = scope;
    next();
  });

  // =========================================================================
  // 1. CENTRALIZED OVERVIEW & SCOPE METADATA
  // =========================================================================
  router.get('/overview', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const companies = getScopedCompanies(scope);
    const companyIds = new Set(companies.map((c) => c.id));

    const allHeadOffices = sqlite.prepare('SELECT * FROM head_offices').all() as any[];
    const headOffices = allHeadOffices.filter((h) => {
      if (scope.restrictedCompanyId && h.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && String(h.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const allRegional = sqlite.prepare('SELECT * FROM regional_offices').all() as any[];
    const regionalOffices = allRegional.filter((r) => {
      if (scope.restrictedCompanyId && r.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && String(r.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const allBranches = sqlite.prepare('SELECT * FROM branches').all() as any[];
    const branches = allBranches.filter((b) => {
      if (scope.restrictedBranchId && b.id !== scope.restrictedBranchId) return false;
      if (scope.restrictedCompanyId && b.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && String(b.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const allDepts = sqlite.prepare('SELECT * FROM employee_departments').all() as any[];
    const departments = allDepts.filter((d) => {
      if (scope.restrictedBranchId && d.branch_id && d.branch_id !== scope.restrictedBranchId) return false;
      if (scope.restrictedCompanyId && d.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && !companyIds.has(d.company_id)) return false;
      return true;
    });

    const allStaff = sqlite.prepare('SELECT id, company_id, country_id, branch_id, status FROM employee_accounts').all() as any[];
    const staff = allStaff.filter((e) => {
      if (scope.restrictedBranchId && e.branch_id !== scope.restrictedBranchId) return false;
      if (scope.restrictedCompanyId && e.company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && String(e.country_id || 'PK').toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const countries = (sqlite.prepare('SELECT * FROM countries').all() as any[]).filter((co) => {
      if (scope.restrictedCountryId && co.id.toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const cities = (sqlite.prepare('SELECT * FROM cities').all() as any[]).filter((ci) => {
      if (scope.restrictedCountryId && String(ci.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
      return true;
    });

    const recentLogs = sqlite
      .prepare('SELECT * FROM organization_activity_logs ORDER BY created_at DESC LIMIT 20')
      .all()
      .filter((l: any) => {
        if (scope.restrictedBranchId && l.scope_branch_id && l.scope_branch_id !== scope.restrictedBranchId) return false;
        if (scope.restrictedCompanyId && l.scope_company_id && l.scope_company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && l.scope_country_id && String(l.scope_country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        return true;
      });

    res.json({
      scope,
      defaultDepartments: DEFAULT_DEPARTMENTS,
      companies: companies.map((c) => ({ id: c.id, name: c.name, country: c.country, city: c.city, status: c.status })),
      metrics: {
        totalCompanies: companies.length,
        totalHeadOffices: headOffices.length,
        totalRegionalOffices: regionalOffices.length,
        activeRegionalOffices: regionalOffices.filter((r) => r.status === 'Active').length,
        totalBranches: branches.length,
        activeBranches: branches.filter((b) => b.status === 'Active').length,
        inactiveBranches: branches.filter((b) => b.status !== 'Active').length,
        totalDepartments: departments.length,
        totalCountries: countries.length,
        totalCities: cities.length,
        totalStaff: staff.length,
        activeStaff: staff.filter((s) => s.status === 'Active').length,
      },
      recentLogs,
    });
  });

  // =========================================================================
  // 2. BYD PAKISTAN & CORPORATE HEAD OFFICE MANAGEMENT MODULE
  // =========================================================================
  router.get('/head-offices', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const rows = sqlite
      .prepare(`
        SELECT ho.*, c.name as company_name, c.status as company_status, c.registration_details as company_reg_details,
               c.authorized_rep as company_authorized_rep, co.name as country_name
        FROM head_offices ho
        JOIN companies c ON c.id = ho.company_id
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(ho.country_id)
        ORDER BY ho.created_at DESC
      `)
      .all() as any[];

    const filtered = rows
      .filter((r) => {
        if (scope.restrictedCompanyId && r.company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && String(r.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        return true;
      })
      .map((r) => {
        const regCount = (sqlite.prepare('SELECT COUNT(*) as c FROM regional_offices WHERE company_id = ? AND (head_office_id = ? OR head_office_id IS NULL)').get(r.company_id, r.id) as any).c;
        const brCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branches WHERE company_id = ?').get(r.company_id) as any).c;
        const staffList = sqlite
          .prepare("SELECT id, employee_code, full_name, department, job_position, status, office_id FROM employee_accounts WHERE company_id = ? AND (office_id = ? OR department IN ('Executive','Administration','Finance','Human Resources (HR)')) ORDER BY full_name ASC")
          .all(r.company_id, r.id);
        return {
          ...r,
          departments: safeJson<string[]>(r.departments_json, []),
          documents: safeJson<any[]>(r.documents_json, []),
          regionalOfficesCount: regCount,
          branchesCount: brCount,
          staffRecords: staffList,
        };
      });

    res.json({
      headOffices: filtered,
      companies: getScopedCompanies(scope),
    });
  });

  router.post('/head-offices', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageHeadOffices) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to create Head Office records.');
      return;
    }

    const companyId = scope.restrictedCompanyId || String(req.body.companyId || '').trim();
    const officeName = String(req.body.officeName || '').trim();
    const address = String(req.body.address || '').trim();
    const countryId = String(req.body.countryId || 'PK').trim().toUpperCase();
    const city = String(req.body.city || '').trim();
    const stateProvince = String(req.body.stateProvince || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const registrationInfo = String(req.body.registrationInfo || '').trim();
    const managementDetails = String(req.body.managementDetails || '').trim();
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : [];
    const lat = req.body.latitude !== undefined && req.body.latitude !== '' ? Number(req.body.latitude) : null;
    const lng = req.body.longitude !== undefined && req.body.longitude !== '' ? Number(req.body.longitude) : null;

    if (!companyId || !officeName || !countryId || !city || !address || !email || !phone) {
      res.status(400).json({ error: 'Company, official office name, country, city, verified address, contact phone, and office email are required.' });
      return;
    }
    if (scope.restrictedCountryId && countryId !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cannot register a Head Office outside your assigned country scope.');
      return;
    }

    const company = sqlite.prepare('SELECT id, name FROM companies WHERE id = ?').get(companyId) as any;
    if (!company) {
      res.status(404).json({ error: 'Linked parent company not found.' });
      return;
    }

    const country = sqlite.prepare('SELECT id FROM countries WHERE UPPER(id) = ?').get(countryId) as any;
    if (!country) {
      res.status(400).json({ error: 'Country does not exist in verified country master table.' });
      return;
    }

    const dup = sqlite.prepare('SELECT id FROM head_offices WHERE company_id = ? AND LOWER(office_name) = LOWER(?)').get(companyId, officeName);
    if (dup) {
      res.status(409).json({ error: 'A Head Office with this official name already exists for this company.' });
      return;
    }

    const cityId = syncCityRecord(countryId, city, stateProvince, lat, lng);
    const id = `ho_${generateSecureToken(5)}`;
    const ts = nowIso();

    sqlite
      .prepare(`
        INSERT INTO head_offices (
          id, company_id, office_name, address, country_id, city_id, city, state_province,
          phone, email, registration_info, management_details, departments_json, documents_json,
          latitude, longitude, status, authorized_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, 'Active', ?, ?, ?)
      `)
      .run(
        id,
        companyId,
        officeName,
        address,
        countryId,
        cityId,
        city,
        stateProvince,
        phone,
        email,
        registrationInfo,
        managementDetails,
        JSON.stringify(departments),
        Number.isFinite(lat) ? lat : null,
        Number.isFinite(lng) ? lng : null,
        req.auth!.fullName,
        ts,
        ts
      );

    auditOrg(
      req,
      { companyId, countryId },
      'HEAD_OFFICE_CREATED',
      'Head Office Management',
      'HeadOffice',
      id,
      officeName,
      `Created official Head Office "${officeName}" in ${city}, ${countryId} for ${company.name}`
    );

    res.status(201).json({ success: true, id });
  });

  router.patch('/head-offices/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageHeadOffices) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to edit Head Office records.');
      return;
    }
    const ho = sqlite.prepare('SELECT * FROM head_offices WHERE id = ?').get(req.params.id) as any;
    if (!ho) {
      res.status(404).json({ error: 'Head Office record not found.' });
      return;
    }
    if (scope.restrictedCompanyId && ho.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cannot modify another company Head Office.');
      return;
    }
    if (scope.restrictedCountryId && ho.country_id.toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cannot modify a Head Office outside your country.');
      return;
    }

    const officeName = req.body.officeName !== undefined ? String(req.body.officeName).trim() : ho.office_name;
    const address = req.body.address !== undefined ? String(req.body.address).trim() : ho.address;
    const city = req.body.city !== undefined ? String(req.body.city).trim() : ho.city;
    const stateProvince = req.body.stateProvince !== undefined ? String(req.body.stateProvince).trim() : ho.state_province;
    const phone = req.body.phone !== undefined ? String(req.body.phone).trim() : ho.phone;
    const email = req.body.email !== undefined ? String(req.body.email).trim().toLowerCase() : ho.email;
    const registrationInfo = req.body.registrationInfo !== undefined ? String(req.body.registrationInfo).trim() : ho.registration_info;
    const managementDetails = req.body.managementDetails !== undefined ? String(req.body.managementDetails).trim() : ho.management_details;
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : ho.status;
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : safeJson<string[]>(ho.departments_json, []);
    const lat = req.body.latitude !== undefined ? (req.body.latitude === '' || req.body.latitude === null ? null : Number(req.body.latitude)) : ho.latitude;
    const lng = req.body.longitude !== undefined ? (req.body.longitude === '' || req.body.longitude === null ? null : Number(req.body.longitude)) : ho.longitude;

    const cityId = syncCityRecord(ho.country_id, city, stateProvince, lat, lng) || ho.city_id;
    const ts = nowIso();
    sqlite
      .prepare(`
        UPDATE head_offices
        SET office_name = ?, address = ?, city_id = ?, city = ?, state_province = ?,
            phone = ?, email = ?, registration_info = ?, management_details = ?,
            departments_json = ?, latitude = ?, longitude = ?, status = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(
        officeName,
        address,
        cityId,
        city,
        stateProvince,
        phone,
        email,
        registrationInfo,
        managementDetails,
        JSON.stringify(departments),
        Number.isFinite(lat) ? lat : null,
        Number.isFinite(lng) ? lng : null,
        status,
        ts,
        ho.id
      );

    auditOrg(req, { companyId: ho.company_id, countryId: ho.country_id }, 'HEAD_OFFICE_UPDATED', 'Head Office Management', 'HeadOffice', ho.id, officeName, `Updated Head Office profile (${status})`);
    res.json({ success: true });
  });

  router.post('/head-offices/:id/documents', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageHeadOffices) {
      rejectScopeViolation(req, res, 'Permission denied: cannot attach Head Office documents.');
      return;
    }
    const ho = sqlite.prepare('SELECT * FROM head_offices WHERE id = ?').get(req.params.id) as any;
    if (!ho) {
      res.status(404).json({ error: 'Head Office not found.' });
      return;
    }
    if (scope.restrictedCompanyId && ho.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cross-company document attachment blocked.');
      return;
    }

    const title = String(req.body.title || '').trim();
    const docType = String(req.body.docType || 'Official Registration').trim();
    const referenceNo = String(req.body.referenceNo || '').trim();
    const fileName = String(req.body.fileName || '').trim();
    const contentBase64 = req.body.contentBase64 ? String(req.body.contentBase64) : '';
    if (!title) {
      res.status(400).json({ error: 'Document title is required.' });
      return;
    }

    const checksum = contentBase64 ? crypto.createHash('sha256').update(contentBase64).digest('hex').slice(0, 16) : null;
    const docs = safeJson<any[]>(ho.documents_json, []);
    docs.unshift({
      id: `hodoc_${generateSecureToken(5)}`,
      title,
      docType,
      referenceNo,
      fileName: fileName || `${title.toLowerCase().replace(/\s+/g, '_')}.pdf`,
      checksumSha256: checksum,
      uploadedBy: req.auth!.fullName,
      uploadedAt: nowIso(),
    });
    sqlite.prepare('UPDATE head_offices SET documents_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(docs), nowIso(), ho.id);
    auditOrg(req, { companyId: ho.company_id, countryId: ho.country_id }, 'HEAD_OFFICE_DOC_ADDED', 'Head Office Management', 'HeadOfficeDocument', ho.id, title, `Attached document ${title}`);
    res.json({ success: true, documents: docs });
  });

  // =========================================================================
  // 3. REGIONAL OFFICES MANAGEMENT
  // =========================================================================
  router.get('/regional-offices', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const search = String(req.query.search || '').trim().toLowerCase();
    const countryFilter = String(req.query.countryId || '').trim().toUpperCase();
    const companyFilter = String(req.query.companyId || '').trim();
    const statusFilter = String(req.query.status || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT ro.*, c.name as company_name, ho.office_name as head_office_name, co.name as country_name
        FROM regional_offices ro
        JOIN companies c ON c.id = ro.company_id
        LEFT JOIN head_offices ho ON ho.id = ro.head_office_id
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(ro.country_id)
        ORDER BY ro.created_at DESC
      `)
      .all() as any[];

    const filtered = rows
      .filter((r) => {
        if (scope.restrictedCompanyId && r.company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && String(r.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        if (countryFilter && countryFilter !== 'ALL' && String(r.country_id).toUpperCase() !== countryFilter) return false;
        if (companyFilter && companyFilter !== 'ALL' && r.company_id !== companyFilter) return false;
        if (statusFilter && statusFilter !== 'ALL' && r.status !== statusFilter) return false;
        if (search) {
          const hay = `${r.office_name} ${r.office_code} ${r.city} ${r.manager_name} ${r.company_name}`.toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      })
      .map((r) => {
        const linkedBranches = sqlite
          .prepare('SELECT id, name, code, city, achieved_units, monthly_target_units, monthly_revenue_pkr, status FROM branches WHERE regional_office_id = ?')
          .all(r.id) as any[];
        const staffCount = (
          sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE office_id = ? OR branch_id IN (SELECT id FROM branches WHERE regional_office_id = ?)').get(r.id, r.id) as any
        ).c;
        const staffList = sqlite
          .prepare('SELECT id, employee_code, full_name, department, job_position, status FROM employee_accounts WHERE office_id = ? ORDER BY full_name ASC')
          .all(r.id);
        const activityHistory = sqlite
          .prepare('SELECT * FROM organization_activity_logs WHERE scope_regional_office_id = ? OR entity_id = ? ORDER BY created_at DESC LIMIT 20')
          .all(r.id, r.id);
        const totalRevenue = linkedBranches.reduce((s, b) => s + Number(b.monthly_revenue_pkr || 0), 0);
        const totalAchieved = linkedBranches.reduce((s, b) => s + Number(b.achieved_units || 0), 0);
        const totalTarget = linkedBranches.reduce((s, b) => s + Number(b.monthly_target_units || 0), 0);
        return {
          ...r,
          departments: safeJson<string[]>(r.departments_json, []),
          documents: safeJson<any[]>(r.documents_json, []),
          linkedBranches,
          employeeTotal: staffCount,
          staffList,
          activityHistory,
          performance: {
            branchesCount: linkedBranches.length,
            totalRevenuePkr: totalRevenue,
            achievedUnits: totalAchieved,
            targetUnits: totalTarget,
            attainmentPct: totalTarget > 0 ? Math.round((totalAchieved / totalTarget) * 100) : null,
          },
        };
      });

    res.json({ regionalOffices: filtered });
  });

  router.post('/regional-offices', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageRegionalOffices) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to create Regional Offices.');
      return;
    }

    const companyId = scope.restrictedCompanyId || String(req.body.companyId || '').trim();
    const headOfficeId = req.body.headOfficeId ? String(req.body.headOfficeId).trim() : null;
    const countryId = (scope.restrictedCountryId || String(req.body.countryId || 'PK')).trim().toUpperCase();
    const city = String(req.body.city || '').trim();
    const stateProvince = String(req.body.stateProvince || '').trim();
    const officeName = String(req.body.officeName || '').trim();
    const officeCode = String(req.body.officeCode || `RO-${countryId}-${Math.floor(100 + Math.random() * 899)}`).trim().toUpperCase();
    const address = String(req.body.address || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const managerId = req.body.managerId ? String(req.body.managerId).trim() : null;
    let managerName = String(req.body.managerName || '').trim();
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : [];
    const lat = req.body.latitude !== undefined && req.body.latitude !== '' ? Number(req.body.latitude) : null;
    const lng = req.body.longitude !== undefined && req.body.longitude !== '' ? Number(req.body.longitude) : null;

    if (!companyId || !countryId || !city || !officeName) {
      res.status(400).json({ error: 'Parent company, country, city, and Regional Office name are required.' });
      return;
    }

    const company = sqlite.prepare('SELECT id, name FROM companies WHERE id = ?').get(companyId) as any;
    if (!company) {
      res.status(404).json({ error: 'Parent company not found.' });
      return;
    }
    const country = sqlite.prepare('SELECT id FROM countries WHERE UPPER(id) = ?').get(countryId) as any;
    if (!country) {
      res.status(400).json({ error: 'Country must exist in the verified countries registry.' });
      return;
    }

    if (headOfficeId) {
      const ho = sqlite.prepare('SELECT id, company_id, country_id FROM head_offices WHERE id = ?').get(headOfficeId) as any;
      if (!ho || ho.company_id !== companyId) {
        res.status(400).json({ error: 'Invalid hierarchy: Head Office must belong to the same parent company.' });
        return;
      }
    }

    if (managerId) {
      const emp = sqlite.prepare('SELECT id, full_name FROM employee_accounts WHERE id = ?').get(managerId) as any;
      const cm = !emp ? (sqlite.prepare('SELECT id, full_name FROM country_manager_accounts WHERE id = ?').get(managerId) as any) : null;
      if (emp) managerName = emp.full_name;
      else if (cm) managerName = cm.full_name;
    }

    const dupCode = sqlite.prepare('SELECT id FROM regional_offices WHERE UPPER(office_code) = ?').get(officeCode);
    if (dupCode) {
      res.status(409).json({ error: `Regional office code "${officeCode}" is already in use.` });
      return;
    }

    const cityId = syncCityRecord(countryId, city, stateProvince, lat, lng);
    const id = `ro_${generateSecureToken(5)}`;
    const ts = nowIso();

    try {
      sqlite
        .prepare(`
          INSERT INTO regional_offices (
            id, company_id, head_office_id, country_id, city_id, city, state_province,
            office_name, office_code, address, phone, email, manager_id, manager_name,
            departments_json, documents_json, latitude, longitude, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, 'Active', ?, ?)
        `)
        .run(
          id,
          companyId,
          headOfficeId,
          countryId,
          cityId,
          city,
          stateProvince,
          officeName,
          officeCode,
          address,
          phone,
          email,
          managerId,
          managerName,
          JSON.stringify(departments),
          Number.isFinite(lat) ? lat : null,
          Number.isFinite(lng) ? lng : null,
          ts,
          ts
        );
    } catch (err: any) {
      res.status(409).json({ error: err?.message || 'Duplicate Regional Office name for this company and country.' });
      return;
    }

    auditOrg(
      req,
      { companyId, countryId, regionalOfficeId: id },
      'REGIONAL_OFFICE_CREATED',
      'Regional Offices Management',
      'RegionalOffice',
      id,
      officeName,
      `Created Regional Office ${officeName} (${officeCode}) in ${city}, ${countryId}`
    );

    res.status(201).json({ success: true, id, officeCode });
  });

  router.patch('/regional-offices/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageRegionalOffices) {
      rejectScopeViolation(req, res, 'Permission denied: cannot modify Regional Offices.');
      return;
    }
    const ro = sqlite.prepare('SELECT * FROM regional_offices WHERE id = ?').get(req.params.id) as any;
    if (!ro) {
      res.status(404).json({ error: 'Regional Office not found.' });
      return;
    }
    if (scope.restrictedCompanyId && ro.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cross-company Regional Office edit blocked.');
      return;
    }
    if (scope.restrictedCountryId && String(ro.country_id).toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cross-country Regional Office edit blocked.');
      return;
    }

    const headOfficeId = req.body.headOfficeId !== undefined ? (req.body.headOfficeId ? String(req.body.headOfficeId) : null) : ro.head_office_id;
    if (headOfficeId) {
      const ho = sqlite.prepare('SELECT id, company_id FROM head_offices WHERE id = ?').get(headOfficeId) as any;
      if (!ho || ho.company_id !== ro.company_id) {
        res.status(400).json({ error: 'Invalid hierarchy: Head Office must belong to the same parent company.' });
        return;
      }
    }

    const officeName = req.body.officeName !== undefined ? String(req.body.officeName).trim() : ro.office_name;
    const city = req.body.city !== undefined ? String(req.body.city).trim() : ro.city;
    const stateProvince = req.body.stateProvince !== undefined ? String(req.body.stateProvince).trim() : ro.state_province;
    const address = req.body.address !== undefined ? String(req.body.address).trim() : ro.address;
    const phone = req.body.phone !== undefined ? String(req.body.phone).trim() : ro.phone;
    const email = req.body.email !== undefined ? String(req.body.email).trim().toLowerCase() : ro.email;
    const managerId = req.body.managerId !== undefined ? (req.body.managerId ? String(req.body.managerId) : null) : ro.manager_id;
    let managerName = req.body.managerName !== undefined ? String(req.body.managerName).trim() : ro.manager_name;
    if (managerId && !req.body.managerName) {
      const emp = sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(managerId) as any;
      if (emp) managerName = emp.full_name;
    }
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : safeJson<string[]>(ro.departments_json, []);
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : ro.status;
    const lat = req.body.latitude !== undefined ? (req.body.latitude === '' || req.body.latitude === null ? null : Number(req.body.latitude)) : ro.latitude;
    const lng = req.body.longitude !== undefined ? (req.body.longitude === '' || req.body.longitude === null ? null : Number(req.body.longitude)) : ro.longitude;

    const cityId = syncCityRecord(ro.country_id, city, stateProvince, lat, lng) || ro.city_id;
    sqlite
      .prepare(`
        UPDATE regional_offices
        SET head_office_id = ?, office_name = ?, city_id = ?, city = ?, state_province = ?,
            address = ?, phone = ?, email = ?, manager_id = ?, manager_name = ?,
            departments_json = ?, latitude = ?, longitude = ?, status = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(
        headOfficeId,
        officeName,
        cityId,
        city,
        stateProvince,
        address,
        phone,
        email,
        managerId,
        managerName,
        JSON.stringify(departments),
        Number.isFinite(lat) ? lat : null,
        Number.isFinite(lng) ? lng : null,
        status,
        nowIso(),
        ro.id
      );

    auditOrg(req, { companyId: ro.company_id, countryId: ro.country_id, regionalOfficeId: ro.id }, 'REGIONAL_OFFICE_UPDATED', 'Regional Offices Management', 'RegionalOffice', ro.id, officeName, `Updated Regional Office details (${status}, Manager: ${managerName || 'Unassigned'})`);
    res.json({ success: true });
  });

  // =========================================================================
  // 4. BRANCH MANAGEMENT SYSTEM (CRUD, MANAGER ASSIGNMENT, TRANSFERS, DOCS)
  // =========================================================================
  router.get('/branches', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const search = String(req.query.search || '').trim().toLowerCase();
    const countryFilter = String(req.query.countryId || '').trim().toUpperCase();
    const companyFilter = String(req.query.companyId || '').trim();
    const statusFilter = String(req.query.status || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT b.*, c.name as company_name, co.name as country_name, ro.office_name as regional_office_name
        FROM branches b
        JOIN companies c ON c.id = b.company_id
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(b.country_id)
        LEFT JOIN regional_offices ro ON ro.id = b.regional_office_id
        ORDER BY b.created_at DESC
      `)
      .all() as any[];

    const filtered = rows
      .filter((b) => {
        if (scope.restrictedBranchId && b.id !== scope.restrictedBranchId) return false;
        if (scope.restrictedCompanyId && b.company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && String(b.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        if (countryFilter && countryFilter !== 'ALL' && String(b.country_id).toUpperCase() !== countryFilter) return false;
        if (companyFilter && companyFilter !== 'ALL' && b.company_id !== companyFilter) return false;
        if (statusFilter && statusFilter !== 'ALL' && b.status !== statusFilter) return false;
        if (search) {
          const hay = `${b.id} ${b.code} ${b.name} ${b.city} ${b.state_province || ''} ${b.manager_name || ''} ${b.company_name}`.toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      })
      .map((b) => {
        const staffCount = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE branch_id = ?').get(b.id) as any).c;
        const dealerCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_accounts WHERE branch_id = ?').get(b.id) as any).c;
        const vehiclesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE branch_id = ?').get(b.id) as any).c;
        const deptsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_departments WHERE branch_id = ?').get(b.id) as any).c;
        return {
          ...b,
          departments: safeJson<string[]>(b.departments_json, []),
          documents: safeJson<any[]>(b.documents_json, []),
          staffCount,
          dealerCount,
          vehiclesCount,
          linkedDepartmentRows: deptsCount,
          attainmentPct: b.monthly_target_units > 0 ? Math.round((Number(b.achieved_units || 0) / Number(b.monthly_target_units)) * 100) : null,
        };
      });

    res.json({ branches: filtered });
  });

  router.post('/branches', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageBranches || scope.restrictedBranchId) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to register new branches.');
      return;
    }

    const companyId = scope.restrictedCompanyId || String(req.body.companyId || '').trim();
    const countryId = (scope.restrictedCountryId || String(req.body.countryId || 'PK')).trim().toUpperCase();
    const regionalOfficeId = req.body.regionalOfficeId ? String(req.body.regionalOfficeId).trim() : null;
    const name = String(req.body.name || '').trim();
    const code = String(req.body.code || `BR-${countryId}-${Math.floor(100 + Math.random() * 899)}`).trim().toUpperCase();
    const city = String(req.body.city || '').trim();
    const stateProvince = String(req.body.stateProvince || '').trim();
    const address = String(req.body.address || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const managerId = req.body.managerId ? String(req.body.managerId).trim() : null;
    let managerName = String(req.body.managerName || '').trim();
    const openingDate = String(req.body.openingDate || nowIso().slice(0, 10)).trim();
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : ['Administration', 'Sales & Marketing', 'Service & Maintenance'];
    const lat = req.body.latitude !== undefined && req.body.latitude !== '' ? Number(req.body.latitude) : null;
    const lng = req.body.longitude !== undefined && req.body.longitude !== '' ? Number(req.body.longitude) : null;

    if (!companyId || !countryId || !name || !city || !address) {
      res.status(400).json({ error: 'Parent company, country, branch name, city, and address are required.' });
      return;
    }

    const company = sqlite.prepare('SELECT id, name FROM companies WHERE id = ?').get(companyId) as any;
    if (!company) {
      res.status(404).json({ error: 'Parent company not found.' });
      return;
    }

    if (regionalOfficeId) {
      const ro = sqlite.prepare('SELECT id, company_id, country_id FROM regional_offices WHERE id = ?').get(regionalOfficeId) as any;
      if (!ro || ro.company_id !== companyId || String(ro.country_id).toUpperCase() !== countryId) {
        res.status(400).json({ error: 'Invalid hierarchy: Regional Office must belong to the same company and country.' });
        return;
      }
    }

    const dupCode = sqlite.prepare('SELECT id FROM branches WHERE UPPER(code) = ?').get(code);
    if (dupCode) {
      res.status(409).json({ error: `Branch code "${code}" already exists.` });
      return;
    }

    if (managerId && !managerName) {
      const bm = sqlite.prepare('SELECT full_name FROM branch_manager_accounts WHERE id = ?').get(managerId) as any;
      const emp = !bm ? (sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(managerId) as any) : null;
      managerName = bm?.full_name || emp?.full_name || '';
    }

    syncCityRecord(countryId, city, stateProvince, lat, lng);
    const id = `br_${generateSecureToken(5)}`;
    const ts = nowIso();

    sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO branches (
            id, company_id, country_id, regional_office_id, code, name, city, state_province,
            address, phone, email, manager_id, manager_name, departments_json, documents_json,
            opening_date, latitude, longitude, approval_status, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, ?, 'Approved', 'Active', ?, ?)
        `)
        .run(
          id,
          companyId,
          countryId,
          regionalOfficeId,
          code,
          name,
          city,
          stateProvince,
          address,
          phone,
          email,
          managerId,
          managerName || 'Assigned Upon Activation',
          JSON.stringify(departments),
          openingDate,
          Number.isFinite(lat) ? lat : null,
          Number.isFinite(lng) ? lng : null,
          ts,
          ts
        );
    })();

    auditOrg(req, { companyId, countryId, regionalOfficeId, branchId: id }, 'BRANCH_CREATED', 'Branch Management', 'Branch', id, name, `Registered branch ${name} (${code}) in ${city}, ${countryId}`);
    res.status(201).json({ success: true, id, code });
  });

  router.get('/branches/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const branch = sqlite
      .prepare(`
        SELECT b.*, c.name as company_name, co.name as country_name, ro.office_name as regional_office_name
        FROM branches b
        JOIN companies c ON c.id = b.company_id
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(b.country_id)
        LEFT JOIN regional_offices ro ON ro.id = b.regional_office_id
        WHERE b.id = ?
      `)
      .get(req.params.id) as any;

    if (!branch) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }
    if (scope.restrictedBranchId && branch.id !== scope.restrictedBranchId) {
      rejectScopeViolation(req, res, 'Cannot inspect another branch profile.');
      return;
    }
    if (scope.restrictedCompanyId && branch.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cannot inspect branch belonging to another company.');
      return;
    }
    if (scope.restrictedCountryId && String(branch.country_id).toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cannot inspect branch outside your assigned country.');
      return;
    }

    const employees = sqlite
      .prepare('SELECT id, employee_code, full_name, email, department, job_position, employment_type, joined_at, status FROM employee_accounts WHERE branch_id = ? ORDER BY full_name ASC')
      .all(branch.id);
    const departmentRows = sqlite
      .prepare('SELECT * FROM employee_departments WHERE branch_id = ? ORDER BY name ASC')
      .all(branch.id);
    const activityLogs = sqlite
      .prepare('SELECT * FROM branch_activity_logs WHERE branch_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(branch.id);

    res.json({
      branch: {
        ...branch,
        departments: safeJson<string[]>(branch.departments_json, []),
        documents: safeJson<any[]>(branch.documents_json, []),
      },
      employees,
      departmentRows,
      activityLogs,
    });
  });

  router.patch('/branches/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const branch = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(req.params.id) as any;
    if (!branch) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }
    if (!scope.canManageBranches) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to edit branches.');
      return;
    }
    if (scope.restrictedBranchId && branch.id !== scope.restrictedBranchId) {
      rejectScopeViolation(req, res, 'Branch Manager cannot modify another branch.');
      return;
    }
    if (scope.restrictedCompanyId && branch.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cross-company branch modification blocked.');
      return;
    }
    if (scope.restrictedCountryId && String(branch.country_id).toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cross-country branch modification blocked.');
      return;
    }

    const regionalOfficeId = req.body.regionalOfficeId !== undefined
      ? (req.body.regionalOfficeId ? String(req.body.regionalOfficeId).trim() : null)
      : branch.regional_office_id;
    if (regionalOfficeId) {
      const ro = sqlite.prepare('SELECT id, company_id FROM regional_offices WHERE id = ?').get(regionalOfficeId) as any;
      if (!ro || ro.company_id !== branch.company_id) {
        res.status(400).json({ error: 'Invalid hierarchy: Regional Office must belong to the same company.' });
        return;
      }
    }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : branch.name;
    const address = req.body.address !== undefined ? String(req.body.address).trim() : branch.address;
    const city = req.body.city !== undefined ? String(req.body.city).trim() : branch.city;
    const stateProvince = req.body.stateProvince !== undefined ? String(req.body.stateProvince).trim() : (branch.state_province || '');
    const phone = req.body.phone !== undefined ? String(req.body.phone).trim() : branch.phone;
    const email = req.body.email !== undefined ? String(req.body.email).trim().toLowerCase() : branch.email;
    const managerId = req.body.managerId !== undefined ? (req.body.managerId ? String(req.body.managerId) : null) : branch.manager_id;
    let managerName = req.body.managerName !== undefined ? String(req.body.managerName).trim() : branch.manager_name;
    if (managerId && !req.body.managerName) {
      const emp = sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(managerId) as any;
      const bm = !emp ? (sqlite.prepare('SELECT full_name FROM branch_manager_accounts WHERE id = ?').get(managerId) as any) : null;
      if (emp || bm) managerName = (emp || bm).full_name;
    }
    const openingDate = req.body.openingDate !== undefined ? String(req.body.openingDate).trim() : (branch.opening_date || '');
    const status = req.body.status && ['Active', 'Inactive', 'Suspended'].includes(String(req.body.status)) ? String(req.body.status) : branch.status;
    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: unknown) => String(d).trim()).filter(Boolean)
      : safeJson<string[]>(branch.departments_json, []);
    const lat = req.body.latitude !== undefined ? (req.body.latitude === '' || req.body.latitude === null ? null : Number(req.body.latitude)) : branch.latitude;
    const lng = req.body.longitude !== undefined ? (req.body.longitude === '' || req.body.longitude === null ? null : Number(req.body.longitude)) : branch.longitude;

    syncCityRecord(branch.country_id, city, stateProvince, lat, lng);
    sqlite
      .prepare(`
        UPDATE branches
        SET regional_office_id = ?, name = ?, address = ?, city = ?, state_province = ?,
            phone = ?, email = ?, manager_id = ?, manager_name = ?, opening_date = ?,
            departments_json = ?, latitude = ?, longitude = ?, status = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(
        regionalOfficeId,
        name,
        address,
        city,
        stateProvince,
        phone,
        email,
        managerId,
        managerName,
        openingDate,
        JSON.stringify(departments),
        Number.isFinite(lat) ? lat : null,
        Number.isFinite(lng) ? lng : null,
        status,
        nowIso(),
        branch.id
      );

    auditOrg(req, { companyId: branch.company_id, countryId: branch.country_id, regionalOfficeId, branchId: branch.id }, 'BRANCH_UPDATED', 'Branch Management', 'Branch', branch.id, name, `Updated branch details (${status}, Manager: ${managerName})`);
    res.json({ success: true });
  });

  router.post('/branches/:id/documents', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const branch = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(req.params.id) as any;
    if (!branch) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }
    if (!scope.canManageBranches || (scope.restrictedBranchId && branch.id !== scope.restrictedBranchId)) {
      rejectScopeViolation(req, res, 'Permission denied: cannot upload documents to this branch.');
      return;
    }
    const title = String(req.body.title || '').trim();
    const docType = String(req.body.docType || 'Branch License / Lease').trim();
    const referenceNo = String(req.body.referenceNo || '').trim();
    if (!title) {
      res.status(400).json({ error: 'Document title is required.' });
      return;
    }
    const docs = safeJson<any[]>(branch.documents_json, []);
    docs.unshift({
      id: `bdoc_${generateSecureToken(5)}`,
      title,
      docType,
      referenceNo,
      uploadedBy: req.auth!.fullName,
      uploadedAt: nowIso(),
    });
    sqlite.prepare('UPDATE branches SET documents_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(docs), nowIso(), branch.id);
    auditOrg(req, { companyId: branch.company_id, countryId: branch.country_id, branchId: branch.id }, 'BRANCH_DOC_UPLOADED', 'Branch Management', 'BranchDocument', branch.id, title, `Attached branch document ${title}`);
    res.json({ success: true, documents: docs });
  });

  router.post('/branches/transfer-employee', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canTransferStaff) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to transfer employees between branches.');
      return;
    }

    const employeeId = String(req.body.employeeId || '').trim();
    const targetBranchId = String(req.body.targetBranchId || '').trim();
    const reason = String(req.body.reason || 'Operational reassignment').trim();
    if (!employeeId || !targetBranchId) {
      res.status(400).json({ error: 'Employee and destination branch are required.' });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(employeeId) as any;
    const targetBranch = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(targetBranchId) as any;
    if (!emp || !targetBranch) {
      res.status(404).json({ error: 'Employee or destination branch not found.' });
      return;
    }
    if (emp.company_id !== targetBranch.company_id) {
      res.status(400).json({ error: 'Invalid hierarchy: cannot transfer an employee to a branch of a different parent company.' });
      return;
    }
    if (scope.restrictedCompanyId && targetBranch.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cannot transfer staff outside your company.');
      return;
    }
    if (scope.restrictedCountryId && String(targetBranch.country_id).toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cannot transfer staff outside your assigned country.');
      return;
    }

    const prevBranchId = emp.branch_id;
    const ts = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE employee_accounts SET branch_id = ?, office_id = NULL, country_id = ?, updated_at = ? WHERE id = ?')
        .run(targetBranch.id, targetBranch.country_id, ts, emp.id);
      sqlite
        .prepare('UPDATE user_accounts SET branch_id = ?, country_id = ?, updated_at = ? WHERE id = ?')
        .run(targetBranch.id, targetBranch.country_id, ts, emp.id);
      sqlite
        .prepare('UPDATE branch_employee_relationships SET branch_id = ?, assigned_by = ?, updated_at = ? WHERE employee_id = ?')
        .run(targetBranch.id, req.auth!.fullName, ts, emp.id);
    })();

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: targetBranch.id,
      countryId: targetBranch.country_id,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_BRANCH_TRANSFERRED',
      module: 'Branch Transfer',
      targetId: targetBranch.code,
      details: `Transferred from ${prevBranchId || 'HQ/Unassigned'} to ${targetBranch.name} (${targetBranch.code}). Reason: ${reason}`,
      ipAddress: getClientIp(req),
    });

    auditOrg(
      req,
      { companyId: emp.company_id, countryId: targetBranch.country_id, regionalOfficeId: targetBranch.regional_office_id, branchId: targetBranch.id },
      'EMPLOYEE_TRANSFERRED',
      'Branch Management',
      'EmployeeTransfer',
      emp.id,
      emp.full_name,
      `Transferred ${emp.full_name} (${emp.employee_code}) to branch ${targetBranch.name} (${targetBranch.code}). Reason: ${reason}`
    );

    res.json({ success: true });
  });

  // =========================================================================
  // 5. DEPARTMENT MANAGEMENT SYSTEM
  // =========================================================================
  router.get('/departments', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const companyFilter = String(req.query.companyId || '').trim();
    const rows = sqlite
      .prepare(`
        SELECT d.*, c.name as company_name, b.name as branch_name, b.country_id as branch_country_id
        FROM employee_departments d
        JOIN companies c ON c.id = d.company_id
        LEFT JOIN branches b ON b.id = d.branch_id
        ORDER BY d.name ASC
      `)
      .all() as any[];

    const filtered = rows
      .filter((d) => {
        if (scope.restrictedBranchId && d.branch_id && d.branch_id !== scope.restrictedBranchId) return false;
        if (scope.restrictedCompanyId && d.company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && d.branch_country_id && String(d.branch_country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        if (companyFilter && companyFilter !== 'ALL' && d.company_id !== companyFilter) return false;
        return true;
      })
      .map((d) => {
        const staffRows = sqlite
          .prepare('SELECT id, employee_code, full_name, job_position, performance_score, status FROM employee_accounts WHERE company_id = ? AND (department_id = ? OR LOWER(department) = LOWER(?))')
          .all(d.company_id, d.id, d.name) as any[];
        const activeCount = staffRows.filter((s) => s.status === 'Active').length;
        const avgPerf = staffRows.length > 0
          ? Math.round((staffRows.reduce((s, r) => s + Number(r.performance_score || 0), 0) / staffRows.length) * 10) / 10
          : null;
        return {
          ...d,
          employeeCount: staffRows.length,
          activeEmployees: activeCount,
          avgPerformanceScore: avgPerf,
          employees: staffRows,
        };
      });

    res.json({
      departments: filtered,
      standardCatalog: DEFAULT_DEPARTMENTS,
    });
  });

  router.post('/departments', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageDepartments) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to create departments.');
      return;
    }

    const companyId = scope.restrictedCompanyId || String(req.body.companyId || '').trim();
    const branchId = scope.restrictedBranchId || (req.body.branchId ? String(req.body.branchId).trim() : null);
    const officeId = req.body.officeId ? String(req.body.officeId).trim() : null;
    const officeType = String(req.body.officeType || (branchId ? 'Branch' : officeId ? 'Regional / Head Office' : 'Company')).trim();
    const name = String(req.body.name || '').trim();
    const code = String(req.body.code || `${name.replace(/[^A-Za-z]/g, '').toUpperCase().slice(0, 4)}-${Math.floor(10 + Math.random() * 89)}`).trim().toUpperCase();
    const headEmployeeId = req.body.headEmployeeId ? String(req.body.headEmployeeId).trim() : null;
    let headName = String(req.body.headName || '').trim();
    const description = String(req.body.description || '').trim();

    if (!companyId || !name) {
      res.status(400).json({ error: 'Company and department name are required.' });
      return;
    }
    if (branchId) {
      const br = sqlite.prepare('SELECT id, company_id FROM branches WHERE id = ?').get(branchId) as any;
      if (!br || br.company_id !== companyId) {
        res.status(400).json({ error: 'Invalid hierarchy: branch must belong to the selected parent company.' });
        return;
      }
    }
    if (headEmployeeId && !headName) {
      const emp = sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(headEmployeeId) as any;
      if (emp) headName = emp.full_name;
    }

    const dup = sqlite.prepare('SELECT id FROM employee_departments WHERE company_id = ? AND (UPPER(code) = ? OR (LOWER(name) = LOWER(?) AND COALESCE(branch_id, \'\') = COALESCE(?, \'\')))').get(companyId, code, name, branchId);
    if (dup) {
      res.status(409).json({ error: 'Department with this code or name already exists in the selected company/branch.' });
      return;
    }

    const id = `dept_${generateSecureToken(5)}`;
    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT INTO employee_departments (
          id, company_id, branch_id, office_id, office_type, name, code, head_employee_id, head_name, description, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
      `)
      .run(id, companyId, branchId, officeId, officeType, name, code, headEmployeeId, headName || null, description, ts, ts);

    auditOrg(req, { companyId, branchId }, 'DEPARTMENT_CREATED', 'Department Management', 'Department', id, name, `Created department ${name} (${code}), Head: ${headName || 'Unassigned'}`);
    res.status(201).json({ success: true, id, code });
  });

  router.patch('/departments/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageDepartments) {
      rejectScopeViolation(req, res, 'Permission denied: cannot update departments.');
      return;
    }
    const dept = sqlite.prepare('SELECT * FROM employee_departments WHERE id = ?').get(req.params.id) as any;
    if (!dept) {
      res.status(404).json({ error: 'Department not found.' });
      return;
    }
    if (scope.restrictedCompanyId && dept.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cross-company department edit blocked.');
      return;
    }
    if (scope.restrictedBranchId && dept.branch_id && dept.branch_id !== scope.restrictedBranchId) {
      rejectScopeViolation(req, res, 'Cross-branch department edit blocked.');
      return;
    }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : dept.name;
    const headEmployeeId = req.body.headEmployeeId !== undefined ? (req.body.headEmployeeId ? String(req.body.headEmployeeId) : null) : dept.head_employee_id;
    let headName = req.body.headName !== undefined ? String(req.body.headName).trim() : dept.head_name;
    if (headEmployeeId && !req.body.headName) {
      const emp = sqlite.prepare('SELECT full_name FROM employee_accounts WHERE id = ?').get(headEmployeeId) as any;
      if (emp) headName = emp.full_name;
    }
    const description = req.body.description !== undefined ? String(req.body.description).trim() : dept.description;
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : dept.status;

    sqlite
      .prepare('UPDATE employee_departments SET name = ?, head_employee_id = ?, head_name = ?, description = ?, status = ?, updated_at = ? WHERE id = ?')
      .run(name, headEmployeeId, headName || null, description, status, nowIso(), dept.id);

    auditOrg(req, { companyId: dept.company_id, branchId: dept.branch_id }, 'DEPARTMENT_UPDATED', 'Department Management', 'Department', dept.id, name, `Updated department ${name} (Head: ${headName || 'Unassigned'}, Status: ${status})`);
    res.json({ success: true });
  });

  // =========================================================================
  // 6. COUNTRY MANAGEMENT SYSTEM (DUPLICATE-FREE ISO CODES + EXPANSION)
  // =========================================================================
  router.get('/countries', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const rows = sqlite.prepare('SELECT * FROM countries ORDER BY name ASC').all() as any[];
    const filtered = rows
      .filter((co) => !scope.restrictedCountryId || co.id.toUpperCase() === scope.restrictedCountryId)
      .map((co) => {
        const companiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM companies WHERE UPPER(country) = UPPER(?) OR LOWER(country) = LOWER(?)').get(co.id, co.name) as any).c;
        const headOfficesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM head_offices WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        const regionalOfficesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM regional_offices WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        const branchesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branches WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        const employeesCount = (sqlite.prepare("SELECT COUNT(*) as c FROM employee_accounts WHERE UPPER(COALESCE(country_id, 'PK')) = UPPER(?)").get(co.id) as any).c;
        const dealershipsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealerships WHERE UPPER(country) = UPPER(?) OR LOWER(country) = LOWER(?)').get(co.id, co.name) as any).c;
        const citiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM cities WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        return {
          ...co,
          companiesCount,
          headOfficesCount,
          regionalOfficesCount,
          branchesCount,
          employeesCount,
          dealershipsCount,
          citiesCount,
        };
      });

    res.json({ countries: filtered });
  });

  router.post('/countries', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageCountries) {
      rejectScopeViolation(req, res, 'Permission denied: only authorized global administrators or Founder can register countries.');
      return;
    }

    const name = String(req.body.name || '').trim();
    const code = String(req.body.code || '').trim().toUpperCase();
    const flagEmoji = String(req.body.flagEmoji || '🌐').trim();
    const currency = String(req.body.currency || '').trim().toUpperCase();
    const dialingCode = String(req.body.dialingCode || '').trim();
    const headquartersCity = String(req.body.headquartersCity || '').trim();
    const timezone = String(req.body.timezone || 'UTC').trim();
    const legalEntity = String(req.body.legalEntity || '').trim();

    if (!name || !code || code.length < 2 || code.length > 3 || !currency) {
      res.status(400).json({ error: 'Country name, valid 2-3 letter ISO code, and currency are required.' });
      return;
    }

    const dup = sqlite.prepare('SELECT id FROM countries WHERE UPPER(code) = ? OR UPPER(id) = ? OR LOWER(name) = LOWER(?)').get(code, code, name);
    if (dup) {
      res.status(409).json({ error: `Duplicate country prevented: ISO code "${code}" or country "${name}" is already registered.` });
      return;
    }

    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT INTO countries (
          id, code, name, flag_emoji, currency, dialing_code, legal_entity, timezone, headquarters_city,
          is_verified, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'Active', ?, ?)
      `)
      .run(code, code, name, flagEmoji, currency, dialingCode, legalEntity, timezone, headquartersCity, ts, ts);

    if (headquartersCity) {
      syncCityRecord(code, headquartersCity);
    }

    auditOrg(req, { countryId: code }, 'COUNTRY_CREATED', 'Country Management', 'Country', code, name, `Added verified country ${name} (${code}, ${currency})`);
    res.status(201).json({ success: true, id: code });
  });

  router.patch('/countries/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageCountries) {
      rejectScopeViolation(req, res, 'Permission denied: cannot modify country registry.');
      return;
    }
    const co = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(req.params.id) as any;
    if (!co) {
      res.status(404).json({ error: 'Country not found.' });
      return;
    }
    const name = req.body.name !== undefined ? String(req.body.name).trim() : co.name;
    const flagEmoji = req.body.flagEmoji !== undefined ? String(req.body.flagEmoji).trim() : co.flag_emoji;
    const currency = req.body.currency !== undefined ? String(req.body.currency).trim().toUpperCase() : co.currency;
    const dialingCode = req.body.dialingCode !== undefined ? String(req.body.dialingCode).trim() : (co.dialing_code || '');
    const headquartersCity = req.body.headquartersCity !== undefined ? String(req.body.headquartersCity).trim() : co.headquarters_city;
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : co.status;

    sqlite
      .prepare('UPDATE countries SET name = ?, flag_emoji = ?, currency = ?, dialing_code = ?, headquarters_city = ?, status = ?, updated_at = ? WHERE id = ?')
      .run(name, flagEmoji, currency, dialingCode, headquartersCity, status, nowIso(), co.id);

    if (headquartersCity) syncCityRecord(co.id, headquartersCity);
    auditOrg(req, { countryId: co.id }, 'COUNTRY_UPDATED', 'Country Management', 'Country', co.id, name, `Updated country ${name} (${status}, ${currency})`);
    res.json({ success: true });
  });

  // =========================================================================
  // 7. CITY MANAGEMENT SYSTEM (COUNTRY-SCOPED & DUPLICATE-FREE)
  // =========================================================================
  router.get('/cities', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const countryFilter = String(req.query.countryId || '').trim().toUpperCase();
    const rows = sqlite
      .prepare(`
        SELECT ci.*, co.name as country_name, co.flag_emoji
        FROM cities ci
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(ci.country_id)
        ORDER BY co.name ASC, ci.name ASC
      `)
      .all() as any[];

    const filtered = rows
      .filter((ci) => {
        if (scope.restrictedCountryId && String(ci.country_id).toUpperCase() !== scope.restrictedCountryId) return false;
        if (countryFilter && countryFilter !== 'ALL' && String(ci.country_id).toUpperCase() !== countryFilter) return false;
        return true;
      })
      .map((ci) => {
        const headOfficesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM head_offices WHERE UPPER(country_id) = UPPER(?) AND LOWER(city) = LOWER(?)').get(ci.country_id, ci.name) as any).c;
        const regionalOfficesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM regional_offices WHERE UPPER(country_id) = UPPER(?) AND LOWER(city) = LOWER(?)').get(ci.country_id, ci.name) as any).c;
        const branchesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branches WHERE UPPER(country_id) = UPPER(?) AND LOWER(city) = LOWER(?)').get(ci.country_id, ci.name) as any).c;
        const dealershipsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealerships WHERE LOWER(city) = LOWER(?)').get(ci.name) as any).c;
        const employeesCount = (
          sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE branch_id IN (SELECT id FROM branches WHERE UPPER(country_id) = UPPER(?) AND LOWER(city) = LOWER(?))').get(ci.country_id, ci.name) as any
        ).c;
        return {
          ...ci,
          headOfficesCount,
          regionalOfficesCount,
          branchesCount,
          dealershipsCount,
          employeesCount,
        };
      });

    res.json({ cities: filtered });
  });

  router.post('/cities', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageCities) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to add cities.');
      return;
    }

    const countryId = (scope.restrictedCountryId || String(req.body.countryId || 'PK')).trim().toUpperCase();
    const name = String(req.body.name || '').trim();
    const stateProvince = String(req.body.stateProvince || '').trim();
    const lat = req.body.latitude !== undefined && req.body.latitude !== '' ? Number(req.body.latitude) : null;
    const lng = req.body.longitude !== undefined && req.body.longitude !== '' ? Number(req.body.longitude) : null;

    if (!countryId || !name) {
      res.status(400).json({ error: 'Country and city name are required.' });
      return;
    }
    const co = sqlite.prepare('SELECT id FROM countries WHERE UPPER(id) = ?').get(countryId);
    if (!co) {
      res.status(400).json({ error: 'Parent country does not exist in countries registry.' });
      return;
    }

    const dup = sqlite
      .prepare('SELECT id FROM cities WHERE UPPER(country_id) = ? AND normalized_name = ? AND normalized_state = ?')
      .get(countryId, name.toLowerCase(), stateProvince.toLowerCase());
    if (dup) {
      res.status(409).json({ error: `City "${name}"${stateProvince ? ` (${stateProvince})` : ''} already exists under country ${countryId}.` });
      return;
    }

    const id = syncCityRecord(countryId, name, stateProvince, Number.isFinite(lat) ? lat : null, Number.isFinite(lng) ? lng : null);
    auditOrg(req, { countryId }, 'CITY_CREATED', 'City Management', 'City', id, name, `Added city ${name} (${stateProvince || 'Standard Region'}) under ${countryId}`);
    res.status(201).json({ success: true, id });
  });

  router.patch('/cities/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageCities) {
      rejectScopeViolation(req, res, 'Permission denied: cannot modify cities.');
      return;
    }
    const ci = sqlite.prepare('SELECT * FROM cities WHERE id = ?').get(req.params.id) as any;
    if (!ci) {
      res.status(404).json({ error: 'City not found.' });
      return;
    }
    if (scope.restrictedCountryId && String(ci.country_id).toUpperCase() !== scope.restrictedCountryId) {
      rejectScopeViolation(req, res, 'Cannot modify cities outside your assigned country.');
      return;
    }

    const name = req.body.name !== undefined ? String(req.body.name).trim() : ci.name;
    const stateProvince = req.body.stateProvince !== undefined ? String(req.body.stateProvince).trim() : ci.state_province;
    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : ci.status;
    const lat = req.body.latitude !== undefined ? (req.body.latitude === '' || req.body.latitude === null ? null : Number(req.body.latitude)) : ci.latitude;
    const lng = req.body.longitude !== undefined ? (req.body.longitude === '' || req.body.longitude === null ? null : Number(req.body.longitude)) : ci.longitude;

    sqlite
      .prepare('UPDATE cities SET name = ?, normalized_name = ?, state_province = ?, normalized_state = ?, latitude = ?, longitude = ?, status = ?, updated_at = ? WHERE id = ?')
      .run(name, name.toLowerCase(), stateProvince, stateProvince.toLowerCase(), Number.isFinite(lat) ? lat : null, Number.isFinite(lng) ? lng : null, status, nowIso(), ci.id);

    auditOrg(req, { countryId: ci.country_id }, 'CITY_UPDATED', 'City Management', 'City', ci.id, name, `Updated city ${name} (${status})`);
    res.json({ success: true });
  });

  // =========================================================================
  // 8. OFFICE STAFF MANAGEMENT (PROVISION, EDIT, TRANSFER, PII PROTECTION)
  // =========================================================================
  router.get('/staff', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const search = String(req.query.search || '').trim().toLowerCase();
    const branchFilter = String(req.query.branchId || '').trim();
    const deptFilter = String(req.query.department || '').trim();
    const statusFilter = String(req.query.status || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT e.*, c.name as company_name, b.name as branch_name, b.code as branch_code,
               ro.office_name as regional_office_name, ho.office_name as head_office_name,
               co.name as country_name
        FROM employee_accounts e
        LEFT JOIN companies c ON c.id = e.company_id
        LEFT JOIN branches b ON b.id = e.branch_id
        LEFT JOIN regional_offices ro ON ro.id = e.office_id
        LEFT JOIN head_offices ho ON ho.id = e.office_id
        LEFT JOIN countries co ON UPPER(co.id) = UPPER(COALESCE(e.country_id, 'PK'))
        ORDER BY e.created_at DESC
      `)
      .all() as any[];

    const filtered = rows
      .filter((e) => {
        if (scope.restrictedBranchId && e.branch_id !== scope.restrictedBranchId) return false;
        if (scope.restrictedCompanyId && e.company_id !== scope.restrictedCompanyId) return false;
        if (scope.restrictedCountryId && String(e.country_id || 'PK').toUpperCase() !== scope.restrictedCountryId) return false;
        if (branchFilter && branchFilter !== 'ALL' && e.branch_id !== branchFilter) return false;
        if (deptFilter && deptFilter !== 'ALL' && e.department !== deptFilter) return false;
        if (statusFilter && statusFilter !== 'ALL' && e.status !== statusFilter) return false;
        if (search) {
          const hay = `${e.employee_code} ${e.full_name} ${e.email} ${e.department} ${e.job_position} ${e.branch_name || ''}`.toLowerCase();
          if (!hay.includes(search)) return false;
        }
        return true;
      })
      .map((e) => {
        const personalInfo = safeJson<Record<string, any>>(e.personal_info_json, {});
        return {
          id: e.id,
          employee_code: e.employee_code,
          full_name: e.full_name,
          email: e.email,
          mobile: maskPersonalValue(e.mobile, scope.canViewPii || e.id === req.auth!.userId),
          company_id: e.company_id,
          company_name: e.company_name,
          country_id: e.country_id || 'PK',
          country_name: e.country_name,
          branch_id: e.branch_id,
          branch_name: e.branch_name,
          office_id: e.office_id,
          office_name: e.head_office_name || e.regional_office_name || e.branch_name || 'Corporate Pool',
          department: e.department,
          job_position: e.job_position,
          employment_type: e.employment_type || 'Full-Time',
          reporting_manager_id: e.reporting_manager_id,
          reporting_manager_name: e.reporting_manager_name,
          joined_at: e.joined_at,
          status: e.status,
          permissions: safeJson<string[]>(e.permissions_json, []),
          personalInfoMasked: !scope.canViewPii && e.id !== req.auth!.userId,
          nationalId: maskPersonalValue(personalInfo.cnic, scope.canViewPii || e.id === req.auth!.userId),
          emergencyContact: maskPersonalValue(personalInfo.emergencyContact, scope.canViewPii || e.id === req.auth!.userId),
        };
      });

    res.json({ staff: filtered });
  });

  router.post('/staff', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageStaff) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to register office staff.');
      return;
    }

    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const companyId = scope.restrictedCompanyId || String(req.body.companyId || '').trim();
    const branchId = scope.restrictedBranchId || (req.body.branchId ? String(req.body.branchId).trim() : null);
    const officeId = req.body.officeId ? String(req.body.officeId).trim() : null;
    const countryId = (scope.restrictedCountryId || String(req.body.countryId || 'PK')).trim().toUpperCase();
    const department = String(req.body.department || 'Operations').trim();
    const jobPosition = String(req.body.jobPosition || 'Office Executive').trim();
    const employmentType = String(req.body.employmentType || 'Full-Time').trim();
    const joinedAt = String(req.body.joinedAt || nowIso().slice(0, 10)).trim();
    const reportingManagerId = req.body.reportingManagerId ? String(req.body.reportingManagerId).trim() : null;
    const reportingManagerName = String(req.body.reportingManagerName || '').trim();
    const permissions = Array.isArray(req.body.permissions)
      ? req.body.permissions.map((p: unknown) => String(p).trim()).filter(Boolean)
      : ['tasks.view', 'attendance.view'];

    if (!fullName || !email || !mobile || !companyId) {
      res.status(400).json({ error: 'Full name, email, mobile, and company are required.' });
      return;
    }
    const pw = validatePasswordStrength(password);
    if (!pw.valid) {
      res.status(400).json({ error: pw.reason });
      return;
    }

    if (branchId) {
      const br = sqlite.prepare('SELECT id, company_id FROM branches WHERE id = ?').get(branchId) as any;
      if (!br || br.company_id !== companyId) {
        res.status(400).json({ error: 'Invalid hierarchy: assigned branch must belong to the parent company.' });
        return;
      }
    }

    const dupEmail =
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM user_accounts WHERE LOWER(email) = ?').get(email);
    if (dupEmail) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const id = `emp_${generateSecureToken(5)}`;
    const code = `EMP-${Math.floor(1000 + Math.random() * 9000)}`;
    const ts = nowIso();
    const personalInfo = {
      cnic: req.body.nationalId ? String(req.body.nationalId).trim() : null,
      emergencyContact: req.body.emergencyContact ? String(req.body.emergencyContact).trim() : null,
    };

    sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO employee_accounts (
            id, company_id, branch_id, office_id, country_id, employee_code, full_name, email, mobile,
            department, job_position, employment_type, reporting_manager_id, reporting_manager_name,
            status, permissions_json, personal_info_json, username, password_hash, email_verified,
            two_factor_enabled, joined_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, 1, 0, ?, ?, ?)
        `)
        .run(
          id,
          companyId,
          branchId,
          officeId,
          countryId,
          code,
          fullName,
          email,
          mobile,
          department,
          jobPosition,
          employmentType,
          reportingManagerId,
          reportingManagerName || null,
          JSON.stringify(permissions),
          JSON.stringify(personalInfo),
          email.split('@')[0],
          hashPassword(password),
          joinedAt,
          ts,
          ts
        );

      sqlite
        .prepare(`
          INSERT OR REPLACE INTO user_accounts (
            id, subject_type, source_table, role, full_name, email, mobile,
            company_id, country_id, branch_id, account_code, status, verification_status,
            email_verified, mobile_verified, mfa_enabled, approved_by, approved_at, created_at, updated_at
          ) VALUES (?, 'employee', 'employee_accounts', ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 'Verified', 1, 1, 0, ?, ?, ?, ?)
        `)
        .run(id, jobPosition, fullName, email, mobile, companyId, countryId, branchId, code, req.auth!.fullName, ts, ts, ts);
    })();

    auditOrg(req, { companyId, countryId, branchId }, 'STAFF_REGISTERED', 'Office Staff Management', 'Employee', id, fullName, `Registered staff ${fullName} (${code}) in ${department}`);
    res.status(201).json({ success: true, id, employeeCode: code });
  });

  router.patch('/staff/:id', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canManageStaff) {
      rejectScopeViolation(req, res, 'Permission denied: cannot modify staff records.');
      return;
    }
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Staff member not found.' });
      return;
    }
    if (scope.restrictedCompanyId && emp.company_id !== scope.restrictedCompanyId) {
      rejectScopeViolation(req, res, 'Cross-company staff update blocked.');
      return;
    }
    if (scope.restrictedBranchId && emp.branch_id !== scope.restrictedBranchId) {
      rejectScopeViolation(req, res, 'Cross-branch staff update blocked.');
      return;
    }

    const fullName = req.body.fullName !== undefined ? String(req.body.fullName).trim() : emp.full_name;
    const department = req.body.department !== undefined ? String(req.body.department).trim() : emp.department;
    const jobPosition = req.body.jobPosition !== undefined ? String(req.body.jobPosition).trim() : emp.job_position;
    const employmentType = req.body.employmentType !== undefined ? String(req.body.employmentType).trim() : (emp.employment_type || 'Full-Time');
    const branchId = req.body.branchId !== undefined ? (req.body.branchId ? String(req.body.branchId) : null) : emp.branch_id;
    const officeId = req.body.officeId !== undefined ? (req.body.officeId ? String(req.body.officeId) : null) : emp.office_id;
    const reportingManagerName = req.body.reportingManagerName !== undefined ? String(req.body.reportingManagerName).trim() : emp.reporting_manager_name;
    const status = req.body.status && ['Active', 'On Leave', 'Suspended'].includes(String(req.body.status)) ? String(req.body.status) : emp.status;
    const permissions = Array.isArray(req.body.permissions)
      ? req.body.permissions.map((p: unknown) => String(p).trim()).filter(Boolean)
      : safeJson<string[]>(emp.permissions_json, []);

    if (branchId && branchId !== emp.branch_id && !scope.canTransferStaff) {
      rejectScopeViolation(req, res, 'You do not have transfer authorization to move staff between branches.');
      return;
    }

    const ts = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare(`
          UPDATE employee_accounts
          SET full_name = ?, department = ?, job_position = ?, employment_type = ?,
              branch_id = ?, office_id = ?, reporting_manager_name = ?, status = ?,
              permissions_json = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(fullName, department, jobPosition, employmentType, branchId, officeId, reportingManagerName || null, status, JSON.stringify(permissions), ts, emp.id);

      sqlite
        .prepare('UPDATE user_accounts SET full_name = ?, role = ?, branch_id = ?, status = ?, updated_at = ? WHERE id = ?')
        .run(fullName, jobPosition, branchId, status, ts, emp.id);
    })();

    auditOrg(req, { companyId: emp.company_id, countryId: emp.country_id, branchId }, 'STAFF_UPDATED', 'Office Staff Management', 'Employee', emp.id, fullName, `Updated staff ${fullName} (${department} / ${status})`);
    res.json({ success: true });
  });

  // =========================================================================
  // 9. COMPANY HIERARCHY & ORGANIZATIONAL STRUCTURE TREE
  // =========================================================================
  router.get('/hierarchy', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const companies = getScopedCompanies(scope);

    const tree = companies.map((comp) => {
      const headOffices = sqlite.prepare('SELECT * FROM head_offices WHERE company_id = ?').all(comp.id) as any[];
      const regionalOffices = sqlite.prepare('SELECT * FROM regional_offices WHERE company_id = ?').all(comp.id) as any[];
      const branches = sqlite.prepare('SELECT * FROM branches WHERE company_id = ?').all(comp.id) as any[];
      const depts = sqlite.prepare('SELECT * FROM employee_departments WHERE company_id = ?').all(comp.id) as any[];
      const employees = sqlite.prepare('SELECT id, employee_code, full_name, department, job_position, branch_id, office_id, status FROM employee_accounts WHERE company_id = ?').all(comp.id) as any[];

      const buildBranchNode = (b: any) => {
        const bDepts = depts.filter((d) => d.branch_id === b.id);
        const bEmps = employees.filter((e) => e.branch_id === b.id);
        return {
          id: b.id,
          code: b.code,
          name: b.name,
          city: b.city,
          countryId: b.country_id,
          managerName: b.manager_name,
          status: b.status,
          departments: bDepts.map((d) => ({
            id: d.id,
            code: d.code,
            name: d.name,
            headName: d.head_name,
            status: d.status,
            staff: bEmps.filter((e) => e.department.toLowerCase() === d.name.toLowerCase()),
          })),
          unassignedDepartmentStaff: bEmps.filter(
            (e) => !bDepts.some((d) => d.name.toLowerCase() === e.department.toLowerCase())
          ),
        };
      };

      const mappedRegional = regionalOffices
        .filter((r) => !scope.restrictedCountryId || String(r.country_id).toUpperCase() === scope.restrictedCountryId)
        .map((r) => ({
          id: r.id,
          code: r.office_code,
          name: r.office_name,
          city: r.city,
          countryId: r.country_id,
          headOfficeId: r.head_office_id,
          managerName: r.manager_name,
          status: r.status,
          branches: branches
            .filter((b) => b.regional_office_id === r.id)
            .filter((b) => !scope.restrictedBranchId || b.id === scope.restrictedBranchId)
            .map(buildBranchNode),
        }));

      const directBranches = branches
        .filter((b) => !b.regional_office_id)
        .filter((b) => !scope.restrictedCountryId || String(b.country_id).toUpperCase() === scope.restrictedCountryId)
        .filter((b) => !scope.restrictedBranchId || b.id === scope.restrictedBranchId)
        .map(buildBranchNode);

      const companyLevelDepts = depts.filter((d) => !d.branch_id);

      return {
        id: comp.id,
        name: comp.name,
        country: comp.country,
        city: comp.city,
        status: comp.status,
        headOffices: headOffices.map((ho) => ({
          id: ho.id,
          name: ho.office_name,
          city: ho.city,
          countryId: ho.country_id,
          status: ho.status,
          regionalOffices: mappedRegional.filter((ro) => ro.headOfficeId === ho.id),
        })),
        regionalOfficesWithoutHo: mappedRegional.filter((ro) => !ro.headOfficeId),
        directBranches,
        companyDepartments: companyLevelDepts,
        totalStaffCount: employees.length,
      };
    });

    res.json({ hierarchy: tree });
  });

  // =========================================================================
  // 10. GLOBAL LOCATIONS MAP INTEGRATION (ZERO FAKE COORDINATES)
  // =========================================================================
  router.get('/map-locations', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const countryFilter = String(req.query.countryId || '').trim().toUpperCase();
    const cityFilter = String(req.query.city || '').trim().toLowerCase();
    const search = String(req.query.search || '').trim().toLowerCase();

    const countries = (sqlite.prepare('SELECT * FROM countries ORDER BY name ASC').all() as any[])
      .filter((co) => !scope.restrictedCountryId || co.id.toUpperCase() === scope.restrictedCountryId)
      .map((co) => {
        const geo = COUNTRY_SVG_COORDS[co.code.toUpperCase()] || { lat: null, lng: null, mapX: 500, mapY: 220, region: 'Global' };
        const hoCnt = (sqlite.prepare('SELECT COUNT(*) as c FROM head_offices WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        const roCnt = (sqlite.prepare('SELECT COUNT(*) as c FROM regional_offices WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        const brCnt = (sqlite.prepare('SELECT COUNT(*) as c FROM branches WHERE UPPER(country_id) = UPPER(?)').get(co.id) as any).c;
        return {
          id: co.id,
          code: co.code,
          name: co.name,
          flagEmoji: co.flag_emoji,
          currency: co.currency,
          headquartersCity: co.headquarters_city,
          status: co.status,
          geo,
          headOfficesCount: hoCnt,
          regionalOfficesCount: roCnt,
          branchesCount: brCnt,
        };
      });

    const markers: any[] = [];

    const headOffices = sqlite.prepare('SELECT ho.*, c.name as company_name FROM head_offices ho JOIN companies c ON c.id = ho.company_id').all() as any[];
    for (const ho of headOffices) {
      if (scope.restrictedCompanyId && ho.company_id !== scope.restrictedCompanyId) continue;
      if (scope.restrictedCountryId && String(ho.country_id).toUpperCase() !== scope.restrictedCountryId) continue;
      markers.push({
        id: ho.id,
        type: 'Head Office',
        name: ho.office_name,
        companyName: ho.company_name,
        countryId: String(ho.country_id).toUpperCase(),
        city: ho.city,
        address: ho.address,
        phone: ho.phone,
        email: ho.email,
        status: ho.status,
        latitude: ho.latitude ?? null,
        longitude: ho.longitude ?? null,
        coordinatesVerified: typeof ho.latitude === 'number' && typeof ho.longitude === 'number',
      });
    }

    const regionalOffices = sqlite.prepare('SELECT ro.*, c.name as company_name FROM regional_offices ro JOIN companies c ON c.id = ro.company_id').all() as any[];
    for (const ro of regionalOffices) {
      if (scope.restrictedCompanyId && ro.company_id !== scope.restrictedCompanyId) continue;
      if (scope.restrictedCountryId && String(ro.country_id).toUpperCase() !== scope.restrictedCountryId) continue;
      markers.push({
        id: ro.id,
        type: 'Regional Office',
        name: ro.office_name,
        code: ro.office_code,
        companyName: ro.company_name,
        countryId: String(ro.country_id).toUpperCase(),
        city: ro.city,
        address: ro.address,
        phone: ro.phone,
        email: ro.email,
        managerName: ro.manager_name,
        status: ro.status,
        latitude: ro.latitude ?? null,
        longitude: ro.longitude ?? null,
        coordinatesVerified: typeof ro.latitude === 'number' && typeof ro.longitude === 'number',
      });
    }

    const branches = sqlite.prepare('SELECT b.*, c.name as company_name FROM branches b JOIN companies c ON c.id = b.company_id').all() as any[];
    for (const b of branches) {
      if (scope.restrictedBranchId && b.id !== scope.restrictedBranchId) continue;
      if (scope.restrictedCompanyId && b.company_id !== scope.restrictedCompanyId) continue;
      if (scope.restrictedCountryId && String(b.country_id).toUpperCase() !== scope.restrictedCountryId) continue;
      markers.push({
        id: b.id,
        type: 'Branch',
        name: b.name,
        code: b.code,
        companyName: b.company_name,
        countryId: String(b.country_id).toUpperCase(),
        city: b.city,
        stateProvince: b.state_province,
        address: b.address,
        phone: b.phone,
        email: b.email,
        managerName: b.manager_name,
        status: b.status,
        latitude: b.latitude ?? null,
        longitude: b.longitude ?? null,
        coordinatesVerified: typeof b.latitude === 'number' && typeof b.longitude === 'number',
      });
    }

    const cities = (sqlite.prepare('SELECT * FROM cities ORDER BY name ASC').all() as any[]).filter(
      (ci) => !scope.restrictedCountryId || String(ci.country_id).toUpperCase() === scope.restrictedCountryId
    );

    const filteredMarkers = markers.filter((m) => {
      if (countryFilter && countryFilter !== 'ALL' && m.countryId !== countryFilter) return false;
      if (cityFilter && cityFilter !== 'all' && String(m.city || '').toLowerCase() !== cityFilter) return false;
      if (search) {
        const hay = `${m.name} ${m.code || ''} ${m.city} ${m.address || ''} ${m.companyName}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    res.json({
      countries,
      cities,
      markers: filteredMarkers,
      countrySvgCoords: COUNTRY_SVG_COORDS,
    });
  });

  // =========================================================================
  // 11. COMPANY & BRANCH REPORTS + REAL EXCEL (XLSX) & PDF EXPORTS
  // =========================================================================
  function buildOrgReport(scope: OrgActorScope, period: string, fromDate?: string, toDate?: string, countryId?: string, companyId?: string) {
    const bounds = resolveDateBounds(period, fromDate, toDate);
    const filterCountry = (scope.restrictedCountryId || (countryId && countryId !== 'ALL' ? countryId.trim().toUpperCase() : '')) || '';
    const filterCompany = (scope.restrictedCompanyId || (companyId && companyId !== 'ALL' ? companyId.trim() : '')) || '';

    const inRange = (iso?: string | null) => !iso || (iso >= bounds.fromIso && iso <= bounds.toIso);

    const companies = getScopedCompanies(scope)
      .filter((c) => !filterCompany || c.id === filterCompany)
      .filter((c) => !filterCountry || String(c.country).toUpperCase() === filterCountry)
      .filter((c) => inRange(c.created_at));

    const headOffices = (sqlite.prepare('SELECT ho.*, c.name as company_name FROM head_offices ho JOIN companies c ON c.id = ho.company_id').all() as any[])
      .filter((h) => !filterCompany || h.company_id === filterCompany)
      .filter((h) => !filterCountry || String(h.country_id).toUpperCase() === filterCountry)
      .filter((h) => inRange(h.created_at));

    const regionalOffices = (sqlite.prepare('SELECT ro.*, c.name as company_name FROM regional_offices ro JOIN companies c ON c.id = ro.company_id').all() as any[])
      .filter((r) => !filterCompany || r.company_id === filterCompany)
      .filter((r) => !filterCountry || String(r.country_id).toUpperCase() === filterCountry)
      .filter((r) => inRange(r.created_at));

    const branches = (sqlite.prepare('SELECT b.*, c.name as company_name FROM branches b JOIN companies c ON c.id = b.company_id').all() as any[])
      .filter((b) => !scope.restrictedBranchId || b.id === scope.restrictedBranchId)
      .filter((b) => !filterCompany || b.company_id === filterCompany)
      .filter((b) => !filterCountry || String(b.country_id).toUpperCase() === filterCountry)
      .filter((b) => inRange(b.created_at));

    const staff = (sqlite.prepare('SELECT id, company_id, country_id, branch_id, department, status, created_at FROM employee_accounts').all() as any[])
      .filter((s) => !scope.restrictedBranchId || s.branch_id === scope.restrictedBranchId)
      .filter((s) => !filterCompany || s.company_id === filterCompany)
      .filter((s) => !filterCountry || String(s.country_id || 'PK').toUpperCase() === filterCountry);

    const countryWiseMap = new Map<string, { country: string; headOffices: number; regionalOffices: number; branches: number; staff: number }>();
    for (const h of headOffices) {
      const k = String(h.country_id).toUpperCase();
      const row = countryWiseMap.get(k) || { country: k, headOffices: 0, regionalOffices: 0, branches: 0, staff: 0 };
      row.headOffices += 1;
      countryWiseMap.set(k, row);
    }
    for (const r of regionalOffices) {
      const k = String(r.country_id).toUpperCase();
      const row = countryWiseMap.get(k) || { country: k, headOffices: 0, regionalOffices: 0, branches: 0, staff: 0 };
      row.regionalOffices += 1;
      countryWiseMap.set(k, row);
    }
    for (const b of branches) {
      const k = String(b.country_id).toUpperCase();
      const row = countryWiseMap.get(k) || { country: k, headOffices: 0, regionalOffices: 0, branches: 0, staff: 0 };
      row.branches += 1;
      countryWiseMap.set(k, row);
    }
    for (const s of staff) {
      const k = String(s.country_id || 'PK').toUpperCase();
      const row = countryWiseMap.get(k) || { country: k, headOffices: 0, regionalOffices: 0, branches: 0, staff: 0 };
      row.staff += 1;
      countryWiseMap.set(k, row);
    }

    const cityWiseMap = new Map<string, { city: string; countryId: string; branches: number; staff: number }>();
    for (const b of branches) {
      const key = `${String(b.country_id).toUpperCase()}:${b.city}`;
      const row = cityWiseMap.get(key) || { city: b.city, countryId: String(b.country_id).toUpperCase(), branches: 0, staff: 0 };
      row.branches += 1;
      row.staff += staff.filter((s) => s.branch_id === b.id).length;
      cityWiseMap.set(key, row);
    }

    const deptWiseMap = new Map<string, { department: string; employees: number; active: number }>();
    for (const s of staff) {
      const d = s.department || 'Unassigned';
      const row = deptWiseMap.get(d) || { department: d, employees: 0, active: 0 };
      row.employees += 1;
      if (s.status === 'Active') row.active += 1;
      deptWiseMap.set(d, row);
    }

    const branchWiseStaff = branches.map((b) => ({
      branchId: b.id,
      code: b.code,
      name: b.name,
      city: b.city,
      status: b.status,
      employees: staff.filter((s) => s.branch_id === b.id).length,
    }));

    return {
      generatedAt: nowIso(),
      periodLabel: bounds.label,
      summary: {
        totalCompanies: companies.length,
        totalHeadOffices: headOffices.length,
        totalRegionalOffices: regionalOffices.length,
        totalBranches: branches.length,
        activeOfficesAndBranches: headOffices.filter((x) => x.status === 'Active').length + regionalOffices.filter((x) => x.status === 'Active').length + branches.filter((x) => x.status === 'Active').length,
        inactiveOfficesAndBranches: headOffices.filter((x) => x.status !== 'Active').length + regionalOffices.filter((x) => x.status !== 'Active').length + branches.filter((x) => x.status !== 'Active').length,
        totalStaff: staff.length,
      },
      countryWiseOffices: Array.from(countryWiseMap.values()),
      cityWiseBranches: Array.from(cityWiseMap.values()),
      departmentWiseEmployees: Array.from(deptWiseMap.values()).sort((a, b) => b.employees - a.employees),
      branchWiseStaff,
      headOffices,
      regionalOffices,
    };
  }

  router.get('/reports', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const period = String(req.query.period || 'all');
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const countryId = req.query.countryId ? String(req.query.countryId) : undefined;
    const companyId = req.query.companyId ? String(req.query.companyId) : undefined;

    const report = buildOrgReport(scope, period, fromDate, toDate, countryId, companyId);
    auditOrg(req, { companyId: scope.restrictedCompanyId, countryId: scope.restrictedCountryId }, 'ORG_REPORT_VIEWED', 'Company & Branch Reports', 'Report', null, report.periodLabel, `Generated report (${report.periodLabel})`);
    res.json(report);
  });

  router.get('/reports/export', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    if (!scope.canExportReports) {
      rejectScopeViolation(req, res, 'Permission denied: you are not authorized to export organizational reports.');
      return;
    }

    const format = String(req.query.format || 'xlsx').toLowerCase();
    const period = String(req.query.period || 'all');
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const countryId = req.query.countryId ? String(req.query.countryId) : undefined;
    const companyId = req.query.companyId ? String(req.query.companyId) : undefined;

    const report = buildOrgReport(scope, period, fromDate, toDate, countryId, companyId);
    auditOrg(req, { companyId: scope.restrictedCompanyId, countryId: scope.restrictedCountryId }, 'ORG_REPORT_EXPORTED', 'Company & Branch Reports', 'ReportExport', format.toUpperCase(), report.periodLabel, `Exported ${format.toUpperCase()} organizational report`);

    if (format === 'pdf') {
      const lines = [
        'BYD PAKISTAN 360 - COMPANY & BRANCH STRUCTURE REPORT',
        `Founder & CEO: Intekhab Alam | Prepared By: ${req.auth!.fullName} (${req.auth!.role})`,
        `Period: ${report.periodLabel} | Generated: ${report.generatedAt}`,
        '----------------------------------------------------------------------',
        `SUMMARY: Companies=${report.summary.totalCompanies} | Head Offices=${report.summary.totalHeadOffices} | Regional Offices=${report.summary.totalRegionalOffices} | Branches=${report.summary.totalBranches} | Staff=${report.summary.totalStaff}`,
        `STATUS: Active Offices/Branches=${report.summary.activeOfficesAndBranches} | Inactive=${report.summary.inactiveOfficesAndBranches}`,
        '----------------------------------------------------------------------',
        'COUNTRY-WISE OFFICES:',
        ...report.countryWiseOffices.map((c) => ` - ${c.country}: HeadOffices=${c.headOffices}, Regional=${c.regionalOffices}, Branches=${c.branches}, Staff=${c.staff}`),
        '----------------------------------------------------------------------',
        'CITY-WISE BRANCHES:',
        ...report.cityWiseBranches.map((c) => ` - ${c.city} (${c.countryId}): Branches=${c.branches}, Staff=${c.staff}`),
        '----------------------------------------------------------------------',
        'DEPARTMENT-WISE EMPLOYEES:',
        ...report.departmentWiseEmployees.map((d) => ` - ${d.department}: Employees=${d.employees} (Active=${d.active})`),
        '----------------------------------------------------------------------',
        'BRANCH-WISE EMPLOYEES:',
        ...report.branchWiseStaff.map((b) => ` - ${b.code} ${b.name} (${b.city}) [${b.status}]: ${b.employees} staff`),
      ];
      const pdfBuf = buildSimplePdfBuffer(`BYD 360 Company & Branch Report (${period})`, lines);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360_Org_Report_${period}.pdf"`);
      res.send(pdfBuf);
      return;
    }

    if (format === 'csv') {
      const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      const csvRows = [
        ['Section', 'Name', 'Country/Scope', 'Metric 1', 'Metric 2', 'Metric 3'].map(esc).join(','),
        ['Summary', 'Companies', report.periodLabel, report.summary.totalCompanies, '', ''].map(esc).join(','),
        ['Summary', 'Head Offices', report.periodLabel, report.summary.totalHeadOffices, '', ''].map(esc).join(','),
        ['Summary', 'Regional Offices', report.periodLabel, report.summary.totalRegionalOffices, '', ''].map(esc).join(','),
        ['Summary', 'Branches', report.periodLabel, report.summary.totalBranches, `Active:${report.summary.activeOfficesAndBranches}`, `Inactive:${report.summary.inactiveOfficesAndBranches}`].map(esc).join(','),
        ['Summary', 'Office Staff', report.periodLabel, report.summary.totalStaff, '', ''].map(esc).join(','),
        ...report.countryWiseOffices.map((c) => ['Country', c.country, c.country, `HO:${c.headOffices}`, `RO:${c.regionalOffices}`, `Branches:${c.branches}`].map(esc).join(',')),
        ...report.cityWiseBranches.map((c) => ['City', c.city, c.countryId, `Branches:${c.branches}`, `Staff:${c.staff}`, ''].map(esc).join(',')),
        ...report.departmentWiseEmployees.map((d) => ['Department', d.department, 'All', `Staff:${d.employees}`, `Active:${d.active}`, ''].map(esc).join(',')),
      ];
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360_Org_Report_${period}.csv"`);
      res.send('\uFEFF' + csvRows.join('\n'));
      return;
    }

    // Default Excel (.xlsx) export
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet([report.summary]), 'Summary');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(report.countryWiseOffices), 'Country Offices');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(report.cityWiseBranches), 'City Branches');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(report.departmentWiseEmployees), 'Department Staff');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(report.branchWiseStaff), 'Branch Staff');
    const xlsxBuf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="BYD360_Org_Report_${period}.xlsx"`);
    res.send(xlsxBuf);
  });

  // =========================================================================
  // 12. IMMUTABLE ORGANIZATION ACTIVITY LOGS & AUDIT HISTORY
  // =========================================================================
  router.get('/activity-logs', (req: Request, res: Response) => {
    const scope = (req as any).orgScope as OrgActorScope;
    const moduleFilter = String(req.query.module || '').trim();
    const search = String(req.query.search || '').trim().toLowerCase();

    const rows = sqlite
      .prepare('SELECT * FROM organization_activity_logs ORDER BY created_at DESC LIMIT 250')
      .all() as any[];

    const filtered = rows.filter((l) => {
      if (scope.restrictedBranchId && l.scope_branch_id && l.scope_branch_id !== scope.restrictedBranchId) return false;
      if (scope.restrictedCompanyId && l.scope_company_id && l.scope_company_id !== scope.restrictedCompanyId) return false;
      if (scope.restrictedCountryId && l.scope_country_id && String(l.scope_country_id).toUpperCase() !== scope.restrictedCountryId) return false;
      if (moduleFilter && moduleFilter !== 'ALL' && l.module !== moduleFilter) return false;
      if (search) {
        const hay = `${l.actor_name} ${l.action} ${l.module} ${l.entity_name || ''} ${l.details || ''}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    const modules = Array.from(new Set(rows.map((r) => r.module))).sort();
    res.json({
      immutable: true,
      logs: filtered,
      modules,
    });
  });

  return router;
}
