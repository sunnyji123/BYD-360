import React from 'react';
import { Car, UserCheck, Activity, Zap, Sparkles } from 'lucide-react';
import { useApp, AppTab } from '../../context/AppContext';

export const MobileNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  const items: { tab: AppTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { tab: 'landing', label: 'Fleet', icon: Car },
    { tab: 'customer', label: 'My Portal', icon: UserCheck },
    { tab: 'battery', label: 'Battery', icon: Activity },
    { tab: 'charging', label: 'Charging', icon: Zap },
    { tab: 'ai-assistant', label: 'AI Advisor', icon: Sparkles },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 border-t border-slate-800/80 backdrop-blur-lg lg:hidden px-2 py-1.5 flex items-center justify-around safe-bottom">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.tab;
        return (
          <button
            key={item.tab}
            onClick={() => setActiveTab(item.tab)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition ${
              isActive ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className={`w-5 h-5 mb-0.5 ${isActive ? 'text-cyan-400 scale-110' : 'text-slate-400'}`} />
            <span className="text-[10px] tracking-tight">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
