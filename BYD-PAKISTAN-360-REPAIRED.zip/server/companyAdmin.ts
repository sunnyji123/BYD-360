import express, { Request, Response } from 'express';
import * as XLSX from 'xlsx';
import {
  sqlite,
  hashPassword,
  generateSecureToken,
  generateNumericOtp,
  generateTotpSecret,
  validatePasswordStrength,
  logCompanyActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireCompanyAdmin,
  requireCompanyPermission,
  CANONICAL_COMPANY_ADMIN_PERMISSIONS,
  CANONICAL_EMPLOYEE_PERMISSIONS,
  getClientIp,
} from './auth';

const ALLOWED_EMPLOYEE_ROLES = [
  'Head Office Staff',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Finance Manager',
  'Service Manager',
  'Technical Support',
];

const FORBIDDEN_PRIVILEGED_ROLES = ['Founder / Owner', 'Super Admin', 'Company Admin', 'Country Manager', 'Branch Manager'];

const EMPLOYEE_GRANTABLE_PERMISSIONS = [
  'employees.manage',
  'branches.manage',
  'dealers.manage',
  'vehicles.manage',
  'customers.manage',
  'sales.manage',
  'finance.manage',
  'reports.view',
  'reports.export',
  ...CANONICAL_EMPLOYEE_PERMISSIONS,
] as const;

function maskNationalId(raw?: string | null): string {
  if (!raw) return 'Not Provided';
  const clean = String(raw).trim();
  if (clean.length <= 6) return '******';
  return `${clean.slice(0, 3)}••••••${clean.slice(-3)}`;
}

function recordCompanyAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.companyId) return;
  logCompanyActivity({
    companyId: req.auth.companyId,
    actorId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function rejectCrossCompanyAccess(req: Request, res: Response, attemptedTarget: string, targetCompanyId?: string | null) {
  const ip = getClientIp(req);
  const msg = `Company Admin (${req.auth?.email}, company=${req.auth?.companyId}) attempted cross-company access on "${attemptedTarget}" (targetCompany=${targetCompanyId || 'unknown'}).`;
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'CROSS_COMPANY_ACCESS_ATTEMPT',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId,
    details: msg,
    ipAddress: ip,
  });
  recordCompanyAction(req, 'CROSS_COMPANY_ACCESS_BLOCKED', 'Security Isolation', attemptedTarget, msg, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Cross-company data access or modification is strictly prohibited.',
  });
}

function rejectPrivilegeOrGovernanceViolation(req: Request, res: Response, reason: string, targetId?: string) {
  const ip = getClientIp(req);
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'COMPANY_PRIVILEGE_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId,
    details: reason,
    ipAddress: ip,
  });
  recordCompanyAction(req, 'PRIVILEGE_ESCALATION_BLOCKED', 'Security Isolation', targetId || null, reason, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Company Admins cannot create/modify Founder, Super Admin, extra Company Admin accounts, or global governance policy.',
  });
}

function assertCompanyQueryNotSpoofed(req: Request, res: Response): boolean {
  const companyId = req.auth!.companyId!;
  const qComp = req.query.companyId ? String(req.query.companyId).trim() : null;
  const bComp = req.body && req.body.companyId ? String(req.body.companyId).trim() : null;

  if ((qComp && qComp !== companyId) || (bComp && bComp !== companyId)) {
    rejectCrossCompanyAccess(req, res, req.originalUrl, qComp || bComp);
    return false;
  }
  return true;
}

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function createCompanyAdminRouter() {
  const router = express.Router();

  // Strictly enforce dedicated Company Admin authentication across all routes
  router.use(requireCompanyAdmin);

  // =========================================================================
  // 1. COMPANY ADMIN REAL-TIME DASHBOARD (STRICTLY COMPANY-SCOPED)
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const company = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(companyId) as any;
    if (!company) {
      res.status(404).json({ error: 'Authorized company profile not found.' });
      return;
    }

    const totalBranches = (sqlite.prepare("SELECT COUNT(*) as c FROM company_branches WHERE company_id = ? AND status = 'Active'").get(companyId) as any).c;
    const totalEmployees = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE company_id = ?').get(companyId) as any).c;
    const totalDealerships = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE company_id = ? AND status = 'Approved'").get(companyId) as any).c;
    const pendingDealers = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE company_id = ? AND status = 'Pending Approval'").get(companyId) as any).c;
    const totalCustomers = (sqlite.prepare("SELECT COUNT(*) as c FROM users WHERE company_id = ? AND role = 'Customer'").get(companyId) as any).c;
    const totalVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE company_id = ?').get(companyId) as any).c;
    const availableVehicleStock = (sqlite
      .prepare("SELECT COUNT(*) as c FROM vehicles WHERE company_id = ? AND sold_at IS NULL AND status != 'Sold' AND delivery_status != 'Delivered'")
      .get(companyId) as any).c;
    const totalBookings = (sqlite.prepare('SELECT COUNT(*) as c FROM bookings WHERE company_id = ?').get(companyId) as any).c;
    const pendingBookings = (sqlite.prepare("SELECT COUNT(*) as c FROM bookings WHERE company_id = ? AND status = 'Pending'").get(companyId) as any).c;
    const totalSales = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE company_id = ? AND sold_at IS NOT NULL').get(companyId) as any).c;

    const revRow = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal,
          COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal,
          COALESCE(SUM(CASE WHEN status = 'Refunded' THEN total_amount ELSE 0 END), 0) as refundedTotal
        FROM payments_invoices
        WHERE company_id = ?
      `)
      .get(companyId) as any;

    const openCrm = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_crm_records WHERE company_id = ? AND status IN ('Open', 'In Progress')").get(companyId) as any).c;
    const openServiceJobs = (sqlite.prepare("SELECT COUNT(*) as c FROM service_jobs WHERE company_id = ? AND status NOT IN ('Completed', 'Closed')").get(companyId) as any).c;

    const empLeaves = sqlite.prepare('SELECT leave_requests_json FROM employee_accounts WHERE company_id = ?').all(companyId) as Array<{ leave_requests_json: string }>;
    const pendingLeaves = empLeaves.reduce((acc, row) => {
      const list = safeJsonParse<any[]>(row.leave_requests_json, []);
      return acc + list.filter((lv) => lv.status === 'Pending').length;
    }, 0);

    const pendingTasks = pendingDealers + pendingBookings + openCrm + pendingLeaves + openServiceJobs;

    const recentActivities = sqlite
      .prepare('SELECT * FROM company_activity_logs WHERE company_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(companyId);

    const notifications = sqlite
      .prepare('SELECT * FROM notifications WHERE company_id = ? OR company_id IS NULL ORDER BY created_at DESC LIMIT 15')
      .all(companyId);

    const branchPerformance = sqlite
      .prepare(`
        SELECT b.*,
          (SELECT COUNT(*) FROM employee_accounts e WHERE e.branch_id = b.id) as staff_count,
          (SELECT COUNT(*) FROM vehicles v WHERE v.branch_id = b.id) as vehicle_count
        FROM company_branches b
        WHERE b.company_id = ?
        ORDER BY b.monthly_revenue_pkr DESC
      `)
      .all(companyId);

    const pendingDealerApplications = sqlite
      .prepare("SELECT * FROM dealerships WHERE company_id = ? AND status = 'Pending Approval' ORDER BY created_at DESC")
      .all(companyId);

    res.json({
      actor: {
        id: req.auth!.userId,
        fullName: req.auth!.fullName,
        email: req.auth!.email,
        role: req.auth!.role,
        companyId,
        permissions: req.auth!.permissions,
      },
      companyProfile: {
        ...company,
        departments: safeJsonParse<string[]>(company.departments_json, []),
        documents: safeJsonParse<any[]>(company.documents_json, []),
        businessInfo: safeJsonParse<Record<string, any>>(company.business_info_json, {}),
      },
      metrics: {
        totalBranches,
        totalEmployees,
        totalDealerships,
        pendingDealers,
        totalCustomers,
        totalVehicles,
        availableVehicleStock,
        totalBookings,
        pendingBookings,
        totalSales,
        companyRevenue: revRow.paidTotal,
        pendingRevenue: revRow.pendingTotal,
        refundedRevenue: revRow.refundedTotal,
        pendingTasks,
        pendingLeaves,
        openCrm,
        openServiceJobs,
        recentActivitiesCount: recentActivities.length,
        notificationsCount: notifications.length,
      },
      branchPerformance,
      pendingDealerApplications,
      recentActivities,
      notifications,
    });
  });

  // =========================================================================
  // 2. COMPANY PROFILE, DOCUMENTS & DEPARTMENTS MANAGEMENT
  // =========================================================================
  router.get('/company', (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const company = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(companyId) as any;
    const roles = sqlite.prepare('SELECT * FROM company_user_roles WHERE company_id = ? ORDER BY role_key ASC').all(companyId);
    const branches = sqlite.prepare('SELECT * FROM company_branches WHERE company_id = ? ORDER BY created_at DESC').all(companyId);

    res.json({
      company: {
        ...company,
        departments: safeJsonParse<string[]>(company.departments_json, []),
        documents: safeJsonParse<any[]>(company.documents_json, []),
        businessInfo: safeJsonParse<Record<string, any>>(company.business_info_json, {}),
      },
      roles: roles.map((r: any) => ({ ...r, permissions: safeJsonParse<string[]>(r.permissions_json, []) })),
      branches,
    });
  });

  router.put('/company', requireCompanyPermission('company.profile.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    // Strictly forbid modifying Founder-controlled workspace status, AI quota, or global policies
    if (
      req.body.status !== undefined ||
      req.body.ai_enabled !== undefined ||
      req.body.aiEnabled !== undefined ||
      req.body.ai_daily_limit !== undefined ||
      req.body.aiDailyLimit !== undefined ||
      req.body.securityPolicy !== undefined ||
      req.body.aiConfig !== undefined
    ) {
      rejectPrivilegeOrGovernanceViolation(
        req,
        res,
        `Company Admin attempted to modify protected governance fields (status/ai_enabled/securityPolicy) on ${companyId}.`,
        companyId
      );
      return;
    }

    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(companyId) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company record not found.' });
      return;
    }

    const name = String(req.body.name || comp.name).trim();
    const logoUrl = String(req.body.logoUrl !== undefined ? req.body.logoUrl : comp.logo_url || '').trim();
    const phone = String(req.body.phone || comp.phone).trim();
    const city = String(req.body.city || comp.city).trim();
    const address = String(req.body.address || comp.address).trim();
    const website = String(req.body.website !== undefined ? req.body.website : comp.website || '').trim();
    const taxId = String(req.body.taxId !== undefined ? req.body.taxId : comp.tax_id || '').trim();
    const authorizedRep = String(req.body.authorizedRep || comp.authorized_rep).trim();
    const registrationDetails = String(req.body.registrationDetails || comp.registration_details).trim();

    const departments = Array.isArray(req.body.departments)
      ? req.body.departments.map((d: any) => String(d).trim()).filter(Boolean)
      : safeJsonParse<string[]>(comp.departments_json, []);

    const documents = Array.isArray(req.body.documents)
      ? req.body.documents
      : safeJsonParse<any[]>(comp.documents_json, []);

    const businessInfo =
      req.body.businessInfo && typeof req.body.businessInfo === 'object'
        ? { ...safeJsonParse<Record<string, any>>(comp.business_info_json, {}), ...req.body.businessInfo }
        : safeJsonParse<Record<string, any>>(comp.business_info_json, {});

    sqlite
      .prepare(`
        UPDATE companies
        SET name = ?, logo_url = ?, phone = ?, city = ?, address = ?, website = ?, tax_id = ?,
            authorized_rep = ?, registration_details = ?, departments_json = ?, documents_json = ?, business_info_json = ?
        WHERE id = ?
      `)
      .run(
        name,
        logoUrl,
        phone,
        city,
        address,
        website,
        taxId,
        authorizedRep,
        registrationDetails,
        JSON.stringify(departments),
        JSON.stringify(documents),
        JSON.stringify(businessInfo),
        companyId
      );

    recordCompanyAction(req, 'COMPANY_PROFILE_UPDATED', 'Company Management', companyId, `Updated profile, ${departments.length} departments & ${documents.length} documents.`);
    res.json({ success: true });
  });

  // =========================================================================
  // 3. EMPLOYEE MANAGEMENT (ACCOUNTS, ATTENDANCE, LEAVE, PERFORMANCE, RBAC)
  // =========================================================================
  router.get('/employees', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const employees = sqlite
      .prepare(`
        SELECT e.*, b.name as branch_name, u.last_login_at, u.role as user_role, u.city as user_city
        FROM employee_accounts e
        LEFT JOIN company_branches b ON b.id = e.branch_id
        LEFT JOIN users u ON u.id = e.user_id
        WHERE e.company_id = ?
        ORDER BY e.created_at DESC
      `)
      .all(companyId)
      .map((e: any) => ({
        ...e,
        attendance: safeJsonParse<any[]>(e.attendance_json, []),
        leaveRequests: safeJsonParse<any[]>(e.leave_requests_json, []),
        permissions: safeJsonParse<string[]>(e.permissions_json, []),
      }));

    const branches = sqlite.prepare('SELECT id, name, code, city FROM company_branches WHERE company_id = ? ORDER BY name ASC').all(companyId);
    const roles = sqlite.prepare('SELECT * FROM company_user_roles WHERE company_id = ?').all(companyId);

    res.json({
      employees,
      branches,
      roles,
      grantablePermissions: [...EMPLOYEE_GRANTABLE_PERMISSIONS],
      allowedRoles: ALLOWED_EMPLOYEE_ROLES,
    });
  });

  router.post('/employees', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const jobPosition = String(req.body.jobPosition || req.body.role || 'Sales Executive').trim();
    const department = String(req.body.department || 'Sales & Retail').trim();
    const branchId = req.body.branchId ? String(req.body.branchId).trim() : null;
    const city = String(req.body.city || req.auth!.city || 'Karachi').trim();
    const employeeCode = String(req.body.employeeCode || `EMP-${req.auth!.country}-${generateNumericOtp(4)}`).trim().toUpperCase();

    if (FORBIDDEN_PRIVILEGED_ROLES.includes(jobPosition)) {
      rejectPrivilegeOrGovernanceViolation(req, res, `Attempted to create privileged role "${jobPosition}" (${email}) inside Company Admin portal.`);
      return;
    }

    if (!ALLOWED_EMPLOYEE_ROLES.includes(jobPosition)) {
      res.status(400).json({ error: `Invalid company staff role "${jobPosition}".` });
      return;
    }

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Employee full name, email, and mobile number are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    if (branchId) {
      const br = sqlite.prepare('SELECT id, company_id FROM company_branches WHERE id = ?').get(branchId) as any;
      if (!br) {
        res.status(404).json({ error: 'Selected branch not found.' });
        return;
      }
      if (br.company_id !== companyId) {
        rejectCrossCompanyAccess(req, res, `branch:${branchId}`, br.company_id);
        return;
      }
    }

    const conflict =
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const codeConflict = sqlite
      .prepare('SELECT id FROM employee_accounts WHERE company_id = ? AND employee_code = ?')
      .get(companyId, employeeCode);
    if (codeConflict) {
      res.status(409).json({ error: `Employee ID "${employeeCode}" is already assigned within your company.` });
      return;
    }

    const allowedGrantSet = new Set<string>(EMPLOYEE_GRANTABLE_PERMISSIONS);
    const defaultRoleRow = sqlite
      .prepare('SELECT permissions_json FROM company_user_roles WHERE company_id = ? AND role_key = ?')
      .get(companyId, jobPosition) as { permissions_json: string } | undefined;
    const requestedPerms = Array.isArray(req.body.permissions)
      ? Array.from(new Set([...req.body.permissions.map((p: any) => String(p).trim()).filter((p: string) => allowedGrantSet.has(p)), ...CANONICAL_EMPLOYEE_PERMISSIONS]))
      : Array.from(new Set([...safeJsonParse<string[]>(defaultRoleRow?.permissions_json, []), ...CANONICAL_EMPLOYEE_PERMISSIONS]));

    const comp = sqlite.prepare('SELECT country FROM companies WHERE id = ?').get(companyId) as any;
    const countryId = String(req.body.countryId || comp?.country || req.auth!.country || 'PK').trim().toUpperCase();
    const userId = `usr_emp_${generateSecureToken(6)}`;
    const empId = `emp_${generateSecureToken(6)}`;
    const now = nowIso();
    const username = `${email.split('@')[0]}_${generateNumericOtp(3)}`;
    const passHash = hashPassword(password);
    const totpSecret = generateTotpSecret();
    const deptRow = sqlite
      .prepare('SELECT id FROM employee_departments WHERE company_id = ? AND LOWER(name) = LOWER(?) LIMIT 1')
      .get(companyId, department) as { id: string } | undefined;
    const repMgrId = req.body.reportingManagerId ? String(req.body.reportingManagerId) : req.auth!.userId;
    const repMgrName = String(req.body.reportingManagerName || req.auth!.fullName);

    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, branch_id, username, full_name, email, mobile, password_hash, role,
          country, city, status, email_verified, mobile_verified, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, ?, ?, ?)
      `)
      .run(
        userId,
        companyId,
        branchId,
        username,
        fullName,
        email,
        mobile,
        passHash,
        jobPosition,
        countryId,
        city,
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_accounts (
          id, user_id, company_id, country_id, branch_id, department_id, employee_code,
          full_name, username, email, mobile, department, job_position,
          reporting_manager_id, reporting_manager_name, password_hash,
          email_verified, two_factor_enabled, two_factor_secret,
          status, attendance_json, leave_requests_json, performance_score, performance_notes, permissions_json,
          joined_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, 'Active', '[]', '[]', ?, ?, ?, ?, ?, ?)
      `)
      .run(
        empId,
        userId,
        companyId,
        countryId,
        branchId,
        deptRow?.id || null,
        employeeCode,
        fullName,
        username,
        email,
        mobile,
        department,
        jobPosition,
        repMgrId,
        repMgrName,
        passHash,
        totpSecret,
        Number(req.body.performanceScore ?? 92.0),
        String(req.body.performanceNotes || 'Onboarded into company roster.'),
        JSON.stringify(requestedPerms),
        now.slice(0, 10),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_profiles (
          id, employee_id, company_id, country_id, branch_id, department_id,
          reporting_manager_id, reporting_manager_name, bio, city, work_location,
          employment_type, responsibilities_json, skills_json, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Head Office / Branch', 'Full-Time Permanent', ?, '[]', ?)
      `)
      .run(
        `ep_${empId}`,
        empId,
        companyId,
        countryId,
        branchId,
        deptRow?.id || null,
        repMgrId,
        repMgrName,
        `${jobPosition} in ${department}.`,
        city,
        JSON.stringify([`Deliver ${department} operational KPIs`]),
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_assignments (
          id, employee_id, company_id, country_id, branch_id, department_id, job_position,
          reporting_manager_id, reporting_manager_name, shift_schedule, effective_from, status, assigned_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Mon-Sat 09:00-18:00', ?, 'Active', ?, ?, ?)
      `)
      .run(
        `ea_${empId}`,
        empId,
        companyId,
        countryId,
        branchId,
        deptRow?.id || null,
        jobPosition,
        repMgrId,
        repMgrName,
        now.slice(0, 10),
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare('INSERT OR REPLACE INTO user_permissions (user_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
      .run(userId, JSON.stringify(requestedPerms), req.auth!.userId, now);

    recordCompanyAction(req, 'EMPLOYEE_CREATED', 'Employee Management', `${fullName} (${employeeCode})`, `Role: ${jobPosition}, Dept: ${department}`);
    res.status(201).json({ success: true, id: empId, employeeId: empId, userId, employeeCode });
  });

  router.patch('/employees/:id', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const nextPosition = req.body.jobPosition ? String(req.body.jobPosition).trim() : emp.job_position;
    if (FORBIDDEN_PRIVILEGED_ROLES.includes(nextPosition)) {
      rejectPrivilegeOrGovernanceViolation(req, res, `Attempted role escalation of employee ${emp.email} to "${nextPosition}".`, emp.id);
      return;
    }
    if (!ALLOWED_EMPLOYEE_ROLES.includes(nextPosition)) {
      res.status(400).json({ error: `Unsupported role "${nextPosition}".` });
      return;
    }

    const branchId = req.body.branchId !== undefined ? (req.body.branchId ? String(req.body.branchId) : null) : emp.branch_id;
    if (branchId) {
      const br = sqlite.prepare('SELECT company_id FROM company_branches WHERE id = ?').get(branchId) as any;
      if (!br) {
        res.status(404).json({ error: 'Selected branch not found.' });
        return;
      }
      if (br.company_id !== companyId) {
        rejectCrossCompanyAccess(req, res, `branch:${branchId}`, br.company_id);
        return;
      }
    }

    const fullName = String(req.body.fullName || emp.full_name).trim();
    const mobile = String(req.body.mobile || emp.mobile).trim();
    const department = String(req.body.department || emp.department).trim();
    const employeeCode = String(req.body.employeeCode || emp.employee_code).trim().toUpperCase();
    const performanceScore = req.body.performanceScore !== undefined ? Number(req.body.performanceScore) : emp.performance_score;
    const performanceNotes = req.body.performanceNotes !== undefined ? String(req.body.performanceNotes) : emp.performance_notes;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE employee_accounts
        SET branch_id = ?, employee_code = ?, full_name = ?, mobile = ?, department = ?,
            job_position = ?, performance_score = ?, performance_notes = ?, updated_at = ?
        WHERE id = ? AND company_id = ?
      `)
      .run(branchId, employeeCode, fullName, mobile, department, nextPosition, performanceScore, performanceNotes, now, emp.id, companyId);

    if (emp.user_id) {
      sqlite
        .prepare('UPDATE users SET full_name = ?, mobile = ?, role = ?, updated_at = ? WHERE id = ? AND company_id = ?')
        .run(fullName, mobile, nextPosition, now, emp.user_id, companyId);
    }

    recordCompanyAction(req, 'EMPLOYEE_UPDATED', 'Employee Management', `${fullName} (${employeeCode})`, `Dept: ${department}, Position: ${nextPosition}, Score: ${performanceScore}`);
    res.json({ success: true });
  });

  router.patch('/employees/:id/status', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const nextStatus = String(req.body.status || '');
    if (!['Active', 'Suspended', 'On Leave'].includes(nextStatus)) {
      res.status(400).json({ error: 'Invalid employee status. Must be Active, On Leave, or Suspended.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE employee_accounts SET status = ?, updated_at = ? WHERE id = ? AND company_id = ?').run(nextStatus, now, emp.id, companyId);

    if (emp.user_id) {
      const userStatus = nextStatus === 'Suspended' ? 'Suspended' : 'Active';
      sqlite.prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ? AND company_id = ?').run(userStatus, now, emp.user_id, companyId);
      if (nextStatus === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(emp.user_id);
      }
    }

    recordCompanyAction(
      req,
      nextStatus === 'Suspended' ? 'EMPLOYEE_SUSPENDED' : 'EMPLOYEE_STATUS_UPDATED',
      'Employee Management',
      `${emp.full_name} (${emp.employee_code})`,
      `Status changed to ${nextStatus}`,
      nextStatus === 'Suspended' ? 'WARNING' : 'SUCCESS'
    );
    res.json({ success: true, status: nextStatus });
  });

  router.post('/employees/:id/attendance', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const date = String(req.body.date || nowIso().slice(0, 10));
    const status = ['Present', 'Late', 'Absent', 'Remote'].includes(String(req.body.status)) ? String(req.body.status) : 'Present';
    const checkIn = String(req.body.checkIn || '09:00');
    const checkOut = String(req.body.checkOut || '18:00');
    const list = safeJsonParse<any[]>(emp.attendance_json, []);
    const filtered = list.filter((x) => x.date !== date);
    filtered.unshift({ date, status, checkIn, checkOut, recordedBy: req.auth!.fullName });

    const now = nowIso();
    sqlite
      .prepare('UPDATE employee_accounts SET attendance_json = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(JSON.stringify(filtered.slice(0, 60)), now, emp.id, companyId);

    sqlite
      .prepare(`
        INSERT INTO employee_attendance (
          id, employee_id, company_id, country_id, branch_id, attendance_date,
          check_in_at, check_out_at, working_hours, status, notes, correction_status, correction_reviewed_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 9.0, ?, 'Recorded by Company Admin', 'Approved', ?, ?, ?)
        ON CONFLICT(employee_id, attendance_date) DO UPDATE SET
          status = excluded.status,
          correction_status = 'Approved',
          correction_reviewed_by = excluded.correction_reviewed_by,
          updated_at = excluded.updated_at
      `)
      .run(
        `att_${generateSecureToken(5)}`,
        emp.id,
        companyId,
        emp.country_id || req.auth!.country,
        emp.branch_id || null,
        date,
        `${date}T${checkIn}:00.000Z`,
        `${date}T${checkOut}:00.000Z`,
        status,
        req.auth!.fullName,
        now,
        now
      );

    recordCompanyAction(req, 'ATTENDANCE_RECORDED', 'Employee Attendance', `${emp.full_name} (${emp.employee_code})`, `${date}: ${status}`);
    res.json({ success: true, attendance: filtered });
  });

  router.post('/employees/:id/leave', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const type = String(req.body.type || 'Annual Leave').trim();
    const startDate = String(req.body.startDate || '').trim();
    const endDate = String(req.body.endDate || '').trim();
    const reason = String(req.body.reason || 'Requested leave').trim();

    if (!startDate || !endDate) {
      res.status(400).json({ error: 'Leave start and end dates are required.' });
      return;
    }

    const list = safeJsonParse<any[]>(emp.leave_requests_json, []);
    const leaveId = `lv_${generateSecureToken(4)}`;
    const now = nowIso();
    list.unshift({ id: leaveId, type, startDate, endDate, reason, status: 'Pending', createdAt: now });

    sqlite
      .prepare('UPDATE employee_accounts SET leave_requests_json = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(JSON.stringify(list), now, emp.id, companyId);

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_leave_requests (
          id, employee_id, company_id, country_id, branch_id, leave_type, start_date, end_date, total_days, reason, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'Pending', ?, ?)
      `)
      .run(leaveId, emp.id, companyId, emp.country_id || req.auth!.country, emp.branch_id || null, type, startDate, endDate, reason, now, now);

    recordCompanyAction(req, 'LEAVE_REQUEST_LOGGED', 'Employee Leave', `${emp.full_name} (${leaveId})`, `${type} ${startDate}..${endDate}`);
    res.status(201).json({ success: true, leaveId, leaveRequests: list });
  });

  router.patch('/employees/:id/leave', requireCompanyPermission('employees.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const leaveId = String(req.body.leaveId || '');
    const decision = String(req.body.status || '');
    if (!['Approved', 'Rejected', 'Pending'].includes(decision)) {
      res.status(400).json({ error: 'Invalid leave decision.' });
      return;
    }

    const list = safeJsonParse<any[]>(emp.leave_requests_json, []);
    const found = list.find((lv) => lv.id === leaveId);
    const normRow = sqlite.prepare('SELECT * FROM employee_leave_requests WHERE id = ? AND employee_id = ?').get(leaveId, emp.id) as any;
    if (!found && !normRow) {
      res.status(404).json({ error: 'Leave request not found.' });
      return;
    }
    const now = nowIso();
    if (found) {
      found.status = decision;
      found.reviewedBy = req.auth!.fullName;
      found.reviewedAt = now;
    }
    if (normRow) {
      sqlite
        .prepare('UPDATE employee_leave_requests SET status = ?, reviewed_by_id = ?, reviewed_by_name = ?, reviewed_at = ?, updated_at = ? WHERE id = ?')
        .run(decision, req.auth!.userId, req.auth!.fullName, now, now, leaveId);
    }

    sqlite
      .prepare('UPDATE employee_accounts SET leave_requests_json = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(JSON.stringify(list), now, emp.id, companyId);

    if (decision !== 'Pending') {
      sqlite
        .prepare(`
          INSERT INTO employee_notifications (
            id, employee_id, company_id, country_id, branch_id, category, title, message,
            sender_name, sender_role, priority, is_read, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Leave Status', ?, ?, ?, 'Company Admin', 'High', 0, ?)
        `)
        .run(
          `enot_${generateSecureToken(5)}`,
          emp.id,
          companyId,
          emp.country_id || req.auth!.country,
          emp.branch_id || null,
          `Leave Request ${decision} (${leaveId})`,
          `Your ${normRow?.leave_type || found?.type || 'Leave'} request has been marked ${decision} by ${req.auth!.fullName}.`,
          req.auth!.fullName,
          now
        );
    }

    recordCompanyAction(req, `LEAVE_${decision.toUpperCase()}`, 'Employee Leave', `${emp.full_name} (${leaveId})`, `${normRow?.leave_type || found?.type || 'Leave'} -> ${decision}`);
    res.json({ success: true, leaveRequests: list });
  });

  router.patch('/employees/:id/permissions', requireCompanyPermission('employees.permissions.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee record not found.' });
      return;
    }
    if (emp.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `employee:${emp.id}`, emp.company_id);
      return;
    }

    const incoming: string[] = Array.isArray(req.body.permissions) ? req.body.permissions.map((p: any) => String(p).trim()) : [];
    const forbiddenInput = incoming.find((p: string) => ['*', 'founder', 'super_admin', 'owner.manage', 'security.policy'].includes(p));
    if (forbiddenInput) {
      rejectPrivilegeOrGovernanceViolation(req, res, `Attempted to grant prohibited global permission "${forbiddenInput}" to employee ${emp.email}.`, emp.id);
      return;
    }

    const allowedSet = new Set<string>(EMPLOYEE_GRANTABLE_PERMISSIONS);
    const cleaned = Array.from(new Set(incoming.filter((p: string) => allowedSet.has(p))));
    const now = nowIso();

    sqlite
      .prepare('UPDATE employee_accounts SET permissions_json = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(JSON.stringify(cleaned), now, emp.id, companyId);

    sqlite
      .prepare(`
        INSERT INTO company_permissions (id, company_id, subject_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(company_id, subject_id) DO UPDATE SET
          permissions_json = excluded.permissions_json,
          updated_by = excluded.updated_by,
          updated_at = excluded.updated_at
      `)
      .run(`cp_${emp.id}`, companyId, emp.id, JSON.stringify(cleaned), req.auth!.userId, now);

    if (emp.user_id) {
      sqlite
        .prepare('INSERT OR REPLACE INTO user_permissions (user_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
        .run(emp.user_id, JSON.stringify(cleaned), req.auth!.userId, now);
    }

    recordCompanyAction(req, 'EMPLOYEE_PERMISSIONS_UPDATED', 'Employee RBAC', emp.email, `Permissions: ${cleaned.join(', ') || 'None'}`);
    res.json({ success: true, permissions: cleaned });
  });

  // =========================================================================
  // 4. BRANCH MANAGEMENT & BRANCH REPORTS
  // =========================================================================
  router.get('/branches', requireCompanyPermission('branches.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const branches = sqlite
      .prepare(`
        SELECT b.*,
          (SELECT COUNT(*) FROM employee_accounts e WHERE e.branch_id = b.id) as employee_count,
          (SELECT COUNT(*) FROM vehicles v WHERE v.branch_id = b.id) as vehicle_count,
          (SELECT COUNT(*) FROM vehicles v WHERE v.branch_id = b.id AND v.sold_at IS NULL AND v.status != 'Sold') as stock_count,
          (SELECT COUNT(*) FROM vehicles v WHERE v.branch_id = b.id AND v.sold_at IS NOT NULL) as sold_count
        FROM company_branches b
        WHERE b.company_id = ?
        ORDER BY b.created_at DESC
      `)
      .all(companyId);

    const employees = sqlite
      .prepare('SELECT id, full_name, job_position, department, branch_id FROM employee_accounts WHERE company_id = ? ORDER BY full_name ASC')
      .all(companyId);

    res.json({ branches, employees });
  });

  router.post('/branches', requireCompanyPermission('branches.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const name = String(req.body.name || '').trim();
    const city = String(req.body.city || '').trim();
    const code = String(req.body.code || (city ? `BR-${city.slice(0, 3).toUpperCase()}-${generateNumericOtp(3)}` : `BR-${generateNumericOtp(4)}`)).trim().toUpperCase();
    const address = String(req.body.address || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || `${code.toLowerCase().replace(/[^a-z0-9]/g, '')}@branch.demo`).trim().toLowerCase();
    const managerIdRaw = req.body.managerId ?? req.body.managerUserId;
    const managerId = managerIdRaw ? String(managerIdRaw) : null;
    let managerName = String(req.body.managerName || (managerId ? '' : 'Branch Coordinator')).trim();

    if (managerId) {
      const mgr = sqlite.prepare('SELECT full_name, company_id FROM employee_accounts WHERE id = ? OR user_id = ?').get(managerId, managerId) as any;
      if (mgr) {
        if (mgr.company_id !== companyId) {
          rejectCrossCompanyAccess(req, res, `manager:${managerId}`, mgr.company_id);
          return;
        }
        managerName = mgr.full_name;
      }
    }

    if (!name || !code || !city || !address || !phone) {
      res.status(400).json({ error: 'Branch name, city, address, and phone are required.' });
      return;
    }

    const comp = sqlite.prepare('SELECT country FROM companies WHERE id = ?').get(companyId) as any;
    const id = `br_${generateSecureToken(6)}`;
    const now = nowIso();

    try {
      sqlite
        .prepare(`
          INSERT INTO company_branches (
            id, company_id, name, code, country, city, address, manager_id, manager_name,
            phone, email, monthly_target_units, achieved_units, monthly_revenue_pkr, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'Active', ?, ?)
        `)
        .run(
          id,
          companyId,
          name,
          code,
          String(req.body.country || comp?.country || 'PK'),
          city,
          address,
          managerId,
          managerName,
          phone,
          email,
          Number(req.body.monthlyTargetUnits || 25),
          now,
          now
        );
    } catch (err: any) {
      res.status(409).json({ error: err?.message || 'Branch code already exists in your company.' });
      return;
    }

    recordCompanyAction(req, 'BRANCH_CREATED', 'Branch Management', `${name} (${code})`, `City: ${city}, Manager: ${managerName}`);
    res.status(201).json({ success: true, id, code });
  });

  router.patch('/branches/:id', requireCompanyPermission('branches.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const br = sqlite.prepare('SELECT * FROM company_branches WHERE id = ?').get(req.params.id) as any;
    if (!br) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }
    if (br.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `branch:${br.id}`, br.company_id);
      return;
    }

    const incomingMgr = req.body.managerId !== undefined ? req.body.managerId : req.body.managerUserId;
    const managerId = incomingMgr !== undefined ? (incomingMgr ? String(incomingMgr) : null) : br.manager_id;
    let managerName = String(req.body.managerName || br.manager_name).trim();
    if (incomingMgr) {
      const mgr = sqlite.prepare('SELECT full_name, company_id FROM employee_accounts WHERE id = ? OR user_id = ?').get(incomingMgr, incomingMgr) as any;
      if (mgr) {
        if (mgr.company_id !== companyId) {
          rejectCrossCompanyAccess(req, res, `manager:${incomingMgr}`, mgr.company_id);
          return;
        }
        managerName = mgr.full_name;
      }
    }

    const status = req.body.status && ['Active', 'Inactive'].includes(String(req.body.status)) ? String(req.body.status) : br.status;
    sqlite
      .prepare(`
        UPDATE company_branches
        SET name = ?, city = ?, address = ?, manager_id = ?, manager_name = ?, phone = ?, email = ?,
            monthly_target_units = ?, achieved_units = ?, monthly_revenue_pkr = ?, status = ?, updated_at = ?
        WHERE id = ? AND company_id = ?
      `)
      .run(
        String(req.body.name || br.name).trim(),
        String(req.body.city || br.city).trim(),
        String(req.body.address || br.address).trim(),
        managerId,
        managerName,
        String(req.body.phone || br.phone).trim(),
        String(req.body.email || br.email).trim().toLowerCase(),
        Number(req.body.monthlyTargetUnits ?? br.monthly_target_units),
        Number(req.body.achievedUnits ?? br.achieved_units),
        Number(req.body.monthlyRevenuePkr ?? br.monthly_revenue_pkr),
        status,
        nowIso(),
        br.id,
        companyId
      );

    recordCompanyAction(req, 'BRANCH_UPDATED', 'Branch Management', `${br.name} (${br.code})`, `Manager: ${managerName}, Status: ${status}`);
    res.json({ success: true });
  });

  router.get('/branches/:id/report', requireCompanyPermission('branches.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const br = sqlite.prepare('SELECT * FROM company_branches WHERE id = ?').get(req.params.id) as any;
    if (!br) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }
    if (br.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `branch_report:${br.id}`, br.company_id);
      return;
    }

    const staff = sqlite.prepare('SELECT id, employee_code, full_name, department, job_position, status, performance_score FROM employee_accounts WHERE branch_id = ? AND company_id = ?').all(br.id, companyId);
    const inventory = sqlite.prepare('SELECT id, vin, model, variant, color, status, delivery_status, sale_price_pkr, sold_at FROM vehicles WHERE branch_id = ? AND company_id = ?').all(br.id, companyId) as any[];
    const cityBookings = sqlite.prepare('SELECT id, booking_type, vehicle_model, customer_name, status, preferred_date FROM bookings WHERE company_id = ? AND LOWER(city) = LOWER(?) ORDER BY created_at DESC LIMIT 20').all(companyId, br.city);

    const stockUnits = inventory.filter((v) => !v.sold_at && v.status !== 'Sold').length;
    const soldUnits = inventory.filter((v) => Boolean(v.sold_at) || v.status === 'Sold').length;
    const salesVolume = inventory.filter((v) => Boolean(v.sold_at)).reduce((sum, v) => sum + Number(v.sale_price_pkr || 0), 0);
    const attainmentPct = br.monthly_target_units > 0 ? Math.round((br.achieved_units / br.monthly_target_units) * 100) : 0;

    res.json({
      branch: br,
      summary: {
        staffCount: staff.length,
        totalAssignedVehicles: inventory.length,
        availableStock: stockUnits,
        soldVehicles: soldUnits,
        salesVolumePkr: salesVolume,
        targetAttainmentPct: attainmentPct,
      },
      staff,
      inventory,
      cityBookings,
    });
  });

  // =========================================================================
  // 5. DEALERSHIP MANAGEMENT & APPROVALS + COMMUNICATION (COMPANY-SCOPED)
  // =========================================================================
  router.get('/dealerships', requireCompanyPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const dealerships = sqlite
      .prepare(`
        SELECT d.*,
          (SELECT COUNT(*) FROM vehicles v WHERE v.dealership_id = d.id AND v.company_id = d.company_id) as inventory_count,
          (SELECT COUNT(*) FROM vehicles v WHERE v.dealership_id = d.id AND v.company_id = d.company_id AND v.sold_at IS NOT NULL) as sold_count
        FROM dealerships d
        WHERE d.company_id = ?
        ORDER BY CASE WHEN d.status = 'Pending Approval' THEN 0 ELSE 1 END, d.created_at DESC
      `)
      .all(companyId);

    res.json({ dealerships });
  });

  router.post('/dealerships', requireCompanyPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const name = String(req.body.name || '').trim();
    const city = String(req.body.city || '').trim();
    const code = String(req.body.code || (city ? `DLR-${city.slice(0, 3).toUpperCase()}-${generateNumericOtp(3)}` : `DLR-${generateNumericOtp(4)}`)).trim().toUpperCase();
    const address = String(req.body.address || '').trim();
    const managerName = String(req.body.managerName || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || `${code.toLowerCase().replace(/[^a-z0-9]/g, '')}@dealer.demo`).trim().toLowerCase();
    const facilityType = String(req.body.facilityType || '3S Flagship Centre').trim();
    const status = ['Approved', 'Pending Approval'].includes(String(req.body.status)) ? String(req.body.status) : 'Approved';

    if (!name || !code || !city || !address || !managerName || !phone) {
      res.status(400).json({ error: 'Dealership name, city, address, manager, and phone are required.' });
      return;
    }

    const comp = sqlite.prepare('SELECT country FROM companies WHERE id = ?').get(companyId) as any;
    const id = `dlr_${generateSecureToken(6)}`;
    sqlite
      .prepare(`
        INSERT INTO dealerships (
          id, company_id, name, code, country, city, address, manager_name, phone, email,
          facility_type, status, active_techs, service_bays, monthly_target_units,
          achieved_units, monthly_revenue_pkr, rating, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 4.8, ?)
      `)
      .run(
        id,
        companyId,
        name,
        code,
        comp?.country || req.auth!.country,
        city,
        address,
        managerName,
        phone,
        email,
        facilityType,
        status,
        Number(req.body.activeTechs || 8),
        Number(req.body.serviceBays || 6),
        Number(req.body.monthlyTargetUnits || 30),
        nowIso()
      );

    recordCompanyAction(req, 'DEALERSHIP_CREATED', 'Dealer Management', `${name} (${code})`, `City: ${city}, Status: ${status}`);
    res.status(201).json({ success: true, id });
  });

  router.patch('/dealerships/:id', requireCompanyPermission('dealers.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `dealership:${dlr.id}`, dlr.company_id);
      return;
    }

    sqlite
      .prepare(`
        UPDATE dealerships
        SET name = ?, city = ?, address = ?, manager_name = ?, phone = ?, email = ?,
            facility_type = ?, active_techs = ?, service_bays = ?, monthly_target_units = ?, achieved_units = ?, monthly_revenue_pkr = ?
        WHERE id = ? AND company_id = ?
      `)
      .run(
        String(req.body.name || dlr.name).trim(),
        String(req.body.city || dlr.city).trim(),
        String(req.body.address || dlr.address).trim(),
        String(req.body.managerName || dlr.manager_name).trim(),
        String(req.body.phone || dlr.phone).trim(),
        String(req.body.email || dlr.email).trim().toLowerCase(),
        String(req.body.facilityType || dlr.facility_type).trim(),
        Number(req.body.activeTechs ?? dlr.active_techs),
        Number(req.body.serviceBays ?? dlr.service_bays),
        Number(req.body.monthlyTargetUnits ?? dlr.monthly_target_units),
        Number(req.body.achievedUnits ?? dlr.achieved_units),
        Number(req.body.monthlyRevenuePkr ?? dlr.monthly_revenue_pkr),
        dlr.id,
        companyId
      );

    recordCompanyAction(req, 'DEALERSHIP_UPDATED', 'Dealer Management', `${dlr.name} (${dlr.code})`, 'Updated dealership profile & KPIs');
    res.json({ success: true });
  });

  router.patch('/dealerships/:id/decision', requireCompanyPermission('dealers.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `dealership_decision:${dlr.id}`, dlr.company_id);
      return;
    }

    const decision = String(req.body.status || '');
    if (!['Approved', 'Rejected', 'Suspended', 'Pending Approval'].includes(decision)) {
      res.status(400).json({ error: 'Invalid dealership decision.' });
      return;
    }

    sqlite.prepare('UPDATE dealerships SET status = ? WHERE id = ? AND company_id = ?').run(decision, dlr.id, companyId);
    recordCompanyAction(req, `DEALERSHIP_${decision.toUpperCase().replace(/\s+/g, '_')}`, 'Dealer Approvals', `${dlr.name} (${dlr.code})`, `Changed from ${dlr.status} to ${decision}`);
    res.json({ success: true, status: decision });
  });

  router.post('/dealerships/:id/communicate', requireCompanyPermission('dealers.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `dealership_comm:${dlr.id}`, dlr.company_id);
      return;
    }

    const subject = String(req.body.subject || '').trim();
    const message = String(req.body.message || '').trim();
    if (!subject || !message) {
      res.status(400).json({ error: 'Dispatch subject and message are required.' });
      return;
    }

    const notifId = `ntf_${generateSecureToken(6)}`;
    sqlite
      .prepare('INSERT INTO notifications (id, company_id, user_id, title, message, category, is_read, created_at) VALUES (?, ?, NULL, ?, ?, ?, 0, ?)')
      .run(notifId, companyId, `[To ${dlr.code}] ${subject}`, message, 'Dealer Directive', nowIso());

    recordCompanyAction(req, 'DEALER_COMMUNICATION_SENT', 'Dealer Communication', `${dlr.name} (${dlr.code})`, subject);
    res.status(201).json({ success: true, notificationId: notifId });
  });

  // =========================================================================
  // 6. VEHICLE & INVENTORY MANAGEMENT + INTER-BRANCH TRANSFERS
  // =========================================================================
  router.get('/vehicles', requireCompanyPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const vehicles = sqlite
      .prepare(`
        SELECT v.*, b.name as branch_name, b.code as branch_code, d.name as dealership_name
        FROM vehicles v
        LEFT JOIN company_branches b ON b.id = v.branch_id
        LEFT JOIN dealerships d ON d.id = v.dealership_id
        WHERE v.company_id = ?
        ORDER BY v.created_at DESC
      `)
      .all(companyId);

    const branches = sqlite.prepare('SELECT id, name, code, city FROM company_branches WHERE company_id = ? ORDER BY name ASC').all(companyId);
    const dealerships = sqlite.prepare('SELECT id, name, code, city FROM dealerships WHERE company_id = ? ORDER BY name ASC').all(companyId);

    res.json({ vehicles, branches, dealerships });
  });

  router.post('/vehicles', requireCompanyPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const rawVin = String(req.body.vin || '').trim().toUpperCase();
    const vin = rawVin || `LBYD2026${generateSecureToken(5).toUpperCase()}`;
    const chassisNumber = String(req.body.chassisNumber || `CH-${vin.slice(-6)}`).trim().toUpperCase();
    const model = String(req.body.model || 'BYD Seal').trim();
    const variant = String(req.body.variant || 'Performance AWD').trim();
    const color = String(req.body.color || 'Atlantis Grey').trim();
    const branchId = req.body.branchId ? String(req.body.branchId) : null;
    const dealershipId = req.body.dealershipId ? String(req.body.dealershipId) : null;
    const deliveryStatus = ['In Stock', 'Reserved', 'In Transit', 'Delivered'].includes(String(req.body.deliveryStatus))
      ? String(req.body.deliveryStatus)
      : 'In Stock';

    if (vin.length < 8) {
      res.status(400).json({ error: 'Valid VIN (minimum 8 characters) is required.' });
      return;
    }

    if (branchId) {
      const br = sqlite.prepare('SELECT company_id FROM company_branches WHERE id = ?').get(branchId) as any;
      if (!br || br.company_id !== companyId) {
        if (br) rejectCrossCompanyAccess(req, res, `branch:${branchId}`, br.company_id);
        else res.status(404).json({ error: 'Target branch not found.' });
        return;
      }
    }

    if (dealershipId) {
      const dlr = sqlite.prepare('SELECT company_id FROM dealerships WHERE id = ?').get(dealershipId) as any;
      if (!dlr || dlr.company_id !== companyId) {
        if (dlr) rejectCrossCompanyAccess(req, res, `dealership:${dealershipId}`, dlr.company_id);
        else res.status(404).json({ error: 'Target dealership not found.' });
        return;
      }
    }

    const id = `veh_${generateSecureToken(6)}`;
    const now = nowIso();
    const markSold = deliveryStatus === 'Delivered' && Boolean(req.body.markAsSold);

    try {
      sqlite
        .prepare(`
          INSERT INTO vehicles (
            id, company_id, branch_id, dealership_id, vin, chassis_number, model, variant, color, year,
            license_plate, owner_name, owner_phone, owner_city, registration_date,
            odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
            warranty_expiry_date, last_service_date, next_service_due_km, status,
            delivery_status, reserved_by, dealership_purchased, sale_price_pkr, sold_at, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 100, 95, '2034-12-31', ?, 10000, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          id,
          companyId,
          branchId,
          dealershipId,
          vin,
          chassisNumber,
          model,
          variant,
          color,
          Number(req.body.year || 2026),
          String(req.body.licensePlate || 'EV-STOCK').trim().toUpperCase(),
          String(req.body.ownerName || 'Company Showroom Stock'),
          String(req.body.ownerPhone || '+92 21 111 293 750'),
          String(req.body.ownerCity || req.auth!.city || 'Karachi'),
          now.slice(0, 10),
          Number(req.body.batteryCapacityKwh || 82.5),
          now.slice(0, 10),
          markSold ? 'Active' : 'In Stock',
          deliveryStatus,
          req.body.reservedBy ? String(req.body.reservedBy) : null,
          String(req.body.dealershipPurchased || 'Authorized Company Branch'),
          Number(req.body.salePricePkr ?? req.body.pricePkr ?? 14990000),
          markSold ? now.slice(0, 10) : null,
          now
        );
    } catch (err: any) {
      res.status(409).json({ error: err?.message || 'Vehicle with this VIN already exists.' });
      return;
    }

    recordCompanyAction(req, 'VEHICLE_ADDED', 'Vehicle Inventory', vin, `${model} ${variant} (${deliveryStatus})`);
    res.status(201).json({ success: true, id, vin });
  });

  router.patch('/vehicles/:id', requireCompanyPermission('vehicles.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const veh = sqlite.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `vehicle:${veh.vin}`, veh.company_id);
      return;
    }

    const deliveryStatus = req.body.deliveryStatus && ['In Stock', 'Reserved', 'In Transit', 'Delivered'].includes(String(req.body.deliveryStatus))
      ? String(req.body.deliveryStatus)
      : veh.delivery_status;
    const status = req.body.status ? String(req.body.status) : veh.status;
    const soldAt = req.body.markAsSold === true && !veh.sold_at ? nowIso().slice(0, 10) : veh.sold_at;

    sqlite
      .prepare(`
        UPDATE vehicles
        SET model = ?, variant = ?, color = ?, sale_price_pkr = ?, status = ?, delivery_status = ?,
            reserved_by = ?, battery_health_soh = ?, owner_name = ?, sold_at = ?
        WHERE id = ? AND company_id = ?
      `)
      .run(
        String(req.body.model || veh.model).trim(),
        String(req.body.variant || veh.variant).trim(),
        String(req.body.color || veh.color).trim(),
        Number(req.body.salePricePkr ?? veh.sale_price_pkr),
        status,
        deliveryStatus,
        req.body.reservedBy !== undefined ? (req.body.reservedBy ? String(req.body.reservedBy) : null) : veh.reserved_by,
        Number(req.body.batteryHealthSoh ?? veh.battery_health_soh),
        String(req.body.ownerName || veh.owner_name || ''),
        soldAt,
        veh.id,
        companyId
      );

    recordCompanyAction(req, 'VEHICLE_UPDATED', 'Vehicle Inventory', veh.vin, `Delivery: ${deliveryStatus}, Price: ${req.body.salePricePkr ?? veh.sale_price_pkr}`);
    res.json({ success: true });
  });

  router.post('/vehicles/:id/transfer', requireCompanyPermission('vehicles.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const veh = sqlite.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `vehicle_transfer:${veh.vin}`, veh.company_id);
      return;
    }

    const targetBranchId = String(req.body.targetBranchId || '').trim();
    if (!targetBranchId) {
      res.status(400).json({ error: 'Target branch ID is required.' });
      return;
    }

    const br = sqlite.prepare('SELECT * FROM company_branches WHERE id = ?').get(targetBranchId) as any;
    if (!br) {
      res.status(404).json({ error: 'Target branch not found.' });
      return;
    }
    if (br.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `transfer_to_branch:${br.id}`, br.company_id);
      return;
    }

    const deliveryStatus = req.body.deliveryStatus && ['In Stock', 'In Transit', 'Reserved', 'Delivered'].includes(String(req.body.deliveryStatus))
      ? String(req.body.deliveryStatus)
      : 'In Transit';

    sqlite
      .prepare('UPDATE vehicles SET branch_id = ?, owner_city = ?, delivery_status = ? WHERE id = ? AND company_id = ?')
      .run(br.id, br.city, deliveryStatus, veh.id, companyId);

    recordCompanyAction(req, 'VEHICLE_TRANSFERRED', 'Vehicle Logistics', veh.vin, `Transferred to branch ${br.name} (${br.code}) [${deliveryStatus}]`);
    res.json({ success: true, branchId: br.id, branchName: br.name, deliveryStatus });
  });

  // =========================================================================
  // 7. CUSTOMER & CRM MANAGEMENT (MASKED PII + HISTORY + ENQUIRIES)
  // =========================================================================
  router.get('/customers', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;
    const reveal = req.query.reveal === '1';

    if (reveal) {
      recordCompanyAction(req, 'SENSITIVE_CUSTOMER_ID_REVEALED', 'Customer Privacy', 'Customers Roster', 'Admin unmasked National ID / CNIC column');
    }

    const customers = sqlite
      .prepare(`
        SELECT u.id, u.full_name, u.email, u.mobile, u.city, u.country, u.cnic_or_id, u.status, u.email_verified, u.created_at,
          (SELECT COUNT(*) FROM bookings b WHERE b.customer_id = u.id AND b.company_id = u.company_id) as booking_count,
          (SELECT COUNT(*) FROM payments_invoices p WHERE p.customer_id = u.id AND p.company_id = u.company_id AND p.status = 'Paid') as paid_invoices_count,
          (SELECT COALESCE(SUM(p.total_amount), 0) FROM payments_invoices p WHERE p.customer_id = u.id AND p.company_id = u.company_id AND p.status = 'Paid') as lifetime_spend
        FROM users u
        WHERE u.company_id = ? AND u.role = 'Customer'
        ORDER BY u.created_at DESC
      `)
      .all(companyId)
      .map((c: any) => ({
        ...c,
        cnic_masked: maskNationalId(c.cnic_or_id),
        cnic_or_id: reveal ? c.cnic_or_id : undefined,
      }));

    const crmRecords = sqlite
      .prepare('SELECT * FROM customer_crm_records WHERE company_id = ? ORDER BY created_at DESC')
      .all(companyId);

    res.json({ customers, crmRecords });
  });

  router.post('/customers', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const city = String(req.body.city || req.auth!.city || 'Karachi').trim();
    const cnicOrId = String(req.body.cnicOrId || '').trim();
    const password = String(req.body.password || `BydCust-${generateNumericOtp(6)}!`);

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Customer full name, email, and mobile are required.' });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const id = `usr_cust_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, username, full_name, email, mobile, password_hash, role,
          country, city, cnic_or_id, status, email_verified, mobile_verified, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Customer', ?, ?, ?, 'Active', 1, 1, ?, ?, ?)
      `)
      .run(id, companyId, email.split('@')[0] + '_' + generateNumericOtp(3), fullName, email, mobile, hashPassword(password), req.auth!.country, city, cnicOrId || null, req.auth!.userId, now, now);

    recordCompanyAction(req, 'CUSTOMER_CREATED', 'Customer Management', `${fullName} (${email})`);
    res.status(201).json({ success: true, id });
  });

  router.patch('/customers/:id', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const cust = sqlite.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id) as any;
    if (!cust) {
      res.status(404).json({ error: 'Customer not found.' });
      return;
    }
    if (cust.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `customer:${cust.id}`, cust.company_id);
      return;
    }
    if (cust.role !== 'Customer') {
      res.status(403).json({ error: 'This endpoint manages Customer accounts only.' });
      return;
    }

    const status = req.body.status && ['Active', 'Suspended'].includes(String(req.body.status)) ? String(req.body.status) : cust.status;
    sqlite
      .prepare('UPDATE users SET full_name = ?, mobile = ?, city = ?, status = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(
        String(req.body.fullName || cust.full_name).trim(),
        String(req.body.mobile || cust.mobile).trim(),
        String(req.body.city || cust.city).trim(),
        status,
        nowIso(),
        cust.id,
        companyId
      );

    recordCompanyAction(req, 'CUSTOMER_UPDATED', 'Customer Management', cust.email, `Status: ${status}`);
    res.json({ success: true });
  });

  router.get('/crm', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const records = sqlite
      .prepare('SELECT * FROM customer_crm_records WHERE company_id = ? ORDER BY created_at DESC')
      .all(req.auth!.companyId!);
    res.json({ crmRecords: records });
  });

  router.post('/crm', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const customerId = req.body.customerId ? String(req.body.customerId) : null;
    const custRow = customerId
      ? (sqlite.prepare('SELECT full_name, mobile, email, company_id FROM users WHERE id = ?').get(customerId) as any)
      : null;
    if (custRow && custRow.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `customer_crm:${customerId}`, custRow.company_id);
      return;
    }

    const customerName = String(req.body.customerName || custRow?.full_name || 'Walk-in / General Prospect').trim();
    const customerPhone = String(req.body.customerPhone || custRow?.mobile || 'N/A').trim();
    const customerEmail = req.body.customerEmail ? String(req.body.customerEmail).trim().toLowerCase() : (custRow?.email || null);
    const recordType = ['Enquiry', 'Complaint', 'Feedback', 'Follow-Up'].includes(String(req.body.recordType))
      ? String(req.body.recordType)
      : 'Enquiry';
    const subject = String(req.body.subject || '').trim();
    const details = String(req.body.details || '').trim();
    const assignedTo = String(req.body.assignedTo || req.auth!.fullName).trim();
    const priority = ['Low', 'Medium', 'High'].includes(String(req.body.priority)) ? String(req.body.priority) : 'Medium';
    const followUpDate = req.body.followUpDate ? String(req.body.followUpDate) : null;

    if (!subject || !details) {
      res.status(400).json({ error: 'CRM subject and details are required.' });
      return;
    }

    const id = `crm_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO customer_crm_records (
          id, company_id, customer_id, customer_name, customer_email, customer_phone,
          record_type, subject, details, assigned_to, priority, status, follow_up_date, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, ?)
      `)
      .run(id, companyId, customerId, customerName, customerEmail, customerPhone, recordType, subject, details, assignedTo, priority, followUpDate, now, now);

    recordCompanyAction(req, 'CRM_RECORD_CREATED', 'Customer & CRM', `${recordType}: ${subject}`, customerName);
    res.status(201).json({ success: true, id });
  });

  router.patch('/crm/:id', requireCompanyPermission('customers.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const rec = sqlite.prepare('SELECT * FROM customer_crm_records WHERE id = ?').get(req.params.id) as any;
    if (!rec) {
      res.status(404).json({ error: 'CRM record not found.' });
      return;
    }
    if (rec.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `crm:${rec.id}`, rec.company_id);
      return;
    }

    const status = ['Open', 'In Progress', 'Resolved', 'Closed'].includes(String(req.body.status)) ? String(req.body.status) : rec.status;
    sqlite
      .prepare('UPDATE customer_crm_records SET status = ?, assigned_to = ?, follow_up_date = ?, resolution_notes = ?, updated_at = ? WHERE id = ? AND company_id = ?')
      .run(
        status,
        String(req.body.assignedTo || rec.assigned_to || '').trim(),
        req.body.followUpDate !== undefined ? req.body.followUpDate : rec.follow_up_date,
        req.body.resolutionNotes !== undefined ? String(req.body.resolutionNotes) : rec.resolution_notes,
        nowIso(),
        rec.id,
        companyId
      );

    recordCompanyAction(req, 'CRM_RECORD_UPDATED', 'Customer & CRM', rec.subject, `Status -> ${status}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 8. SALES, BOOKINGS, INVOICES & REFUNDS
  // =========================================================================
  router.get('/sales-finance', requireCompanyPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const bookings = sqlite.prepare('SELECT * FROM bookings WHERE company_id = ? ORDER BY created_at DESC LIMIT 100').all(companyId);
    const invoices = sqlite.prepare('SELECT * FROM payments_invoices WHERE company_id = ? ORDER BY created_at DESC LIMIT 100').all(companyId);
    const soldVehicles = sqlite
      .prepare(`
        SELECT v.id, v.vin, v.model, v.variant, v.owner_name, v.owner_city, v.sale_price_pkr, v.sold_at,
               b.name as branch_name, v.dealership_purchased
        FROM vehicles v
        LEFT JOIN company_branches b ON b.id = v.branch_id
        WHERE v.company_id = ? AND v.sold_at IS NOT NULL
        ORDER BY v.sold_at DESC
      `)
      .all(companyId);

    const branchRevenue = sqlite
      .prepare('SELECT id, name, code, city, monthly_target_units, achieved_units, monthly_revenue_pkr FROM company_branches WHERE company_id = ? ORDER BY monthly_revenue_pkr DESC')
      .all(companyId);

    const totals = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal,
          COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal,
          COALESCE(SUM(CASE WHEN status = 'Refunded' THEN total_amount ELSE 0 END), 0) as refundedTotal
        FROM payments_invoices
        WHERE company_id = ?
      `)
      .get(companyId) as any;

    res.json({ bookings, invoices, soldVehicles, branchRevenue, totals });
  });

  router.patch('/bookings/:id', requireCompanyPermission('sales.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const bkg = sqlite.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id) as any;
    if (!bkg) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    if (bkg.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `booking:${bkg.id}`, bkg.company_id);
      return;
    }

    const status = ['Pending', 'Confirmed', 'Completed', 'Cancelled'].includes(String(req.body.status)) ? String(req.body.status) : bkg.status;
    sqlite.prepare('UPDATE bookings SET status = ?, notes = ? WHERE id = ? AND company_id = ?').run(status, req.body.notes !== undefined ? String(req.body.notes) : bkg.notes, bkg.id, companyId);
    recordCompanyAction(req, 'BOOKING_STATUS_UPDATED', 'Sales & Bookings', bkg.id, `${bkg.customer_name} (${bkg.vehicle_model}) -> ${status}`);
    res.json({ success: true, status });
  });

  router.post('/invoices', requireCompanyPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const customerId = req.body.customerId ? String(req.body.customerId) : null;
    const custRow = customerId
      ? (sqlite.prepare('SELECT full_name, company_id FROM users WHERE id = ?').get(customerId) as any)
      : null;
    if (custRow && custRow.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `invoice_customer:${customerId}`, custRow.company_id);
      return;
    }
    const customerName = String(req.body.customerName || custRow?.full_name || '').trim();
    const branchId = req.body.branchId ? String(req.body.branchId) : null;
    const branchRow = branchId ? (sqlite.prepare('SELECT name, company_id FROM company_branches WHERE id = ?').get(branchId) as any) : null;
    const dealershipName = String(req.body.dealershipName || branchRow?.name || 'Company Head Office').trim();
    const itemCategory = String(req.body.itemCategory || 'Vehicle Booking').trim();
    const subtotal = Number(req.body.subtotal ?? req.body.amountPkr ?? 0);
    const taxRate = Number(req.body.taxRate ?? 0.17);
    const paymentGateway = String(req.body.paymentGateway || 'Bank Transfer').trim();
    const rawStatus = req.body.status === 'Pending' ? 'Pending Payment' : String(req.body.status || 'Pending Payment');
    const status = ['Paid', 'Pending Payment'].includes(rawStatus) ? rawStatus : 'Pending Payment';

    if (!customerName || subtotal <= 0) {
      res.status(400).json({ error: 'Customer name and positive subtotal are required.' });
      return;
    }

    const comp = sqlite.prepare('SELECT country FROM companies WHERE id = ?').get(companyId) as any;
    const country = comp?.country || 'PK';
    const currency = country === 'AE' ? 'AED' : 'PKR';
    const taxAmount = Math.round(subtotal * taxRate);
    const totalAmount = subtotal + taxAmount;
    const id = `inv_${generateSecureToken(6)}`;
    const invoiceNumber = `INV-${country}-${generateNumericOtp(6)}`;
    const today = nowIso().slice(0, 10);

    sqlite
      .prepare(`
        INSERT INTO payments_invoices (
          id, company_id, invoice_number, customer_id, customer_name, country, currency,
          dealership_name, item_category, subtotal, tax_rate, tax_amount, total_amount,
          status, payment_gateway, transaction_ref, issued_date, due_date, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id,
        companyId,
        invoiceNumber,
        customerId,
        customerName,
        country,
        currency,
        dealershipName,
        itemCategory,
        subtotal,
        taxRate,
        taxAmount,
        totalAmount,
        status,
        paymentGateway,
        `TXN-${generateSecureToken(4).toUpperCase()}`,
        today,
        today,
        nowIso()
      );

    recordCompanyAction(req, 'INVOICE_CREATED', 'Sales & Finance', invoiceNumber, `${customerName} | ${currency} ${totalAmount} (${status})`);
    res.status(201).json({ success: true, id, invoiceNumber, totalAmount, status });
  });

  // Refunds strictly gated behind finance.manage permission
  router.patch('/invoices/:id/refund', requireCompanyPermission('finance.manage'), (req: Request, res: Response) => {
    const companyId = req.auth!.companyId!;
    const inv = sqlite.prepare('SELECT * FROM payments_invoices WHERE id = ?').get(req.params.id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    if (inv.company_id !== companyId) {
      rejectCrossCompanyAccess(req, res, `invoice_refund:${inv.invoice_number}`, inv.company_id);
      return;
    }
    if (inv.status === 'Refunded') {
      res.status(400).json({ error: 'Invoice has already been refunded.' });
      return;
    }

    const reason = String(req.body.reason || 'Customer refund authorized by Finance/Company Admin').trim();
    sqlite
      .prepare("UPDATE payments_invoices SET status = 'Refunded' WHERE id = ? AND company_id = ?")
      .run(inv.id, companyId);

    recordCompanyAction(req, 'INVOICE_REFUNDED', 'Finance & Refunds', inv.invoice_number, `${inv.currency} ${inv.total_amount} | Reason: ${reason}`, 'WARNING');
    res.json({ success: true, invoiceNumber: inv.invoice_number, status: 'Refunded' });
  });

  // =========================================================================
  // 9. REPORTS & ANALYTICS (DAILY, MONTHLY, YEARLY + REAL EXCEL & PDF EXPORT)
  // =========================================================================
  function buildCompanyReportData(companyId: string, period: string) {
    const company = sqlite.prepare('SELECT name, country, city FROM companies WHERE id = ?').get(companyId) as any;
    const branches = sqlite
      .prepare('SELECT name, code, city, manager_name, monthly_target_units, achieved_units, monthly_revenue_pkr, status FROM company_branches WHERE company_id = ?')
      .all(companyId) as any[];
    const dealers = sqlite
      .prepare('SELECT name, code, city, manager_name, status, monthly_target_units, achieved_units, monthly_revenue_pkr, rating FROM dealerships WHERE company_id = ?')
      .all(companyId) as any[];
    const employees = sqlite
      .prepare('SELECT employee_code, full_name, department, job_position, status, performance_score FROM employee_accounts WHERE company_id = ?')
      .all(companyId) as any[];
    const vehiclesByModel = sqlite
      .prepare("SELECT model, COUNT(*) as totalUnits, SUM(CASE WHEN sold_at IS NOT NULL THEN 1 ELSE 0 END) as soldUnits, SUM(CASE WHEN sold_at IS NULL AND status != 'Sold' THEN 1 ELSE 0 END) as availableUnits, ROUND(AVG(battery_health_soh), 1) as avgSoh FROM vehicles WHERE company_id = ? GROUP BY model")
      .all(companyId) as any[];
    const vehiclesList = sqlite
      .prepare('SELECT vin, model, variant, color, status, delivery_status, sale_price_pkr, sold_at FROM vehicles WHERE company_id = ? ORDER BY created_at DESC')
      .all(companyId) as any[];
    const invoices = sqlite
      .prepare('SELECT invoice_number, customer_name, item_category, currency, subtotal, tax_amount, total_amount, status, payment_gateway, issued_date FROM payments_invoices WHERE company_id = ? ORDER BY created_at DESC')
      .all(companyId) as any[];
    const bookingsBreakdown = sqlite
      .prepare('SELECT booking_type, status, COUNT(*) as count FROM bookings WHERE company_id = ? GROUP BY booking_type, status')
      .all(companyId) as any[];
    const crmSummary = sqlite
      .prepare('SELECT record_type, status, COUNT(*) as count FROM customer_crm_records WHERE company_id = ? GROUP BY record_type, status')
      .all(companyId) as any[];

    const multiplier = period === 'daily' ? 1 / 30 : period === 'yearly' ? 12 : 1;
    const financialSummary = invoices.reduce(
      (acc, inv) => {
        if (inv.status === 'Paid') acc.paidTotal += Number(inv.total_amount || 0);
        else if (inv.status === 'Pending Payment') acc.pendingTotal += Number(inv.total_amount || 0);
        else if (inv.status === 'Refunded') acc.refundedTotal += Number(inv.total_amount || 0);
        return acc;
      },
      { paidTotal: 0, pendingTotal: 0, refundedTotal: 0 }
    );

    const branchProjection = branches.map((b) => ({
      ...b,
      projectedTargetUnits: Math.max(1, Math.round(Number(b.monthly_target_units || 0) * multiplier)),
      projectedAchievedUnits: Math.round(Number(b.achieved_units || 0) * multiplier),
      projectedRevenuePkr: Math.round(Number(b.monthly_revenue_pkr || 0) * multiplier),
    }));

    return {
      generatedAt: nowIso(),
      period,
      company,
      branchProjection,
      dealers,
      employees,
      vehiclesByModel,
      vehiclesList,
      invoices,
      bookingsBreakdown,
      crmSummary,
      financialSummary,
    };
  }

  router.get('/reports', requireCompanyPermission('reports.view'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;
    const period = ['daily', 'monthly', 'yearly'].includes(String(req.query.period)) ? String(req.query.period) : 'monthly';
    const report = buildCompanyReportData(companyId, period);
    recordCompanyAction(req, 'COMPANY_REPORT_VIEWED', 'Reports & Analytics', period.toUpperCase(), `Generated ${period} executive breakdown`);
    res.json(report);
  });

  router.get('/export', requireCompanyPermission('reports.export'), (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;
    const format = ['xlsx', 'csv', 'pdf-data'].includes(String(req.query.format)) ? String(req.query.format) : 'xlsx';
    const period = ['daily', 'monthly', 'yearly'].includes(String(req.query.period)) ? String(req.query.period) : 'monthly';
    const data = buildCompanyReportData(companyId, period);

    recordCompanyAction(req, 'COMPANY_REPORT_EXPORTED', 'Reports & Export', `${format.toUpperCase()} (${period})`, `Exported multi-module company report`);

    if (format === 'xlsx') {
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(
        wb,
        XLSX.utils.json_to_sheet([
          {
            Company: data.company?.name,
            Country: data.company?.country,
            City: data.company?.city,
            Period: period.toUpperCase(),
            GeneratedAt: data.generatedAt,
            PaidRevenue: data.financialSummary.paidTotal,
            PendingRevenue: data.financialSummary.pendingTotal,
            RefundedAmount: data.financialSummary.refundedTotal,
          },
        ]),
        'Company Overview'
      );
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.branchProjection.length ? data.branchProjection : [{ Note: 'No branches' }]), 'Branches');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.employees.length ? data.employees : [{ Note: 'No employees' }]), 'Employees');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.dealers.length ? data.dealers : [{ Note: 'No dealerships' }]), 'Dealerships');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.vehiclesList.length ? data.vehiclesList : [{ Note: 'No vehicles' }]), 'Vehicle Inventory');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.invoices.length ? data.invoices : [{ Note: 'No invoices' }]), 'Sales & Finance');

      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360-${companyId}-${period}-report.xlsx"`);
      res.send(buffer);
      return;
    }

    if (format === 'csv') {
      const ws = XLSX.utils.json_to_sheet(data.invoices.length ? data.invoices : data.vehiclesList);
      const csv = XLSX.utils.sheet_to_csv(ws);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="BYD360-${companyId}-${period}-finance.csv"`);
      res.send(csv);
      return;
    }

    res.json(data);
  });

  // =========================================================================
  // 10. COMPANY AUDIT LOGS, LOGIN HISTORY & ROLES (COMPANY-ISOLATED ONLY)
  // =========================================================================
  router.get('/audit-logs', (req: Request, res: Response) => {
    if (!assertCompanyQueryNotSpoofed(req, res)) return;
    const companyId = req.auth!.companyId!;

    const activityLogs = sqlite
      .prepare('SELECT * FROM company_activity_logs WHERE company_id = ? ORDER BY created_at DESC LIMIT 120')
      .all(companyId);

    const loginHistory = sqlite
      .prepare("SELECT id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE company_id = ? AND subject_type IN ('company_admin', 'user') ORDER BY created_at DESC LIMIT 60")
      .all(companyId);

    const securityEvents = sqlite
      .prepare("SELECT * FROM security_events WHERE company_id = ? AND event_type NOT LIKE '%FOUNDER%' ORDER BY created_at DESC LIMIT 50")
      .all(companyId);

    res.json({
      activityLogs,
      loginHistory,
      securityEvents,
      assignedPermissions: req.auth!.permissions,
      canonicalPermissions: [...CANONICAL_COMPANY_ADMIN_PERMISSIONS],
    });
  });

  return router;
}
