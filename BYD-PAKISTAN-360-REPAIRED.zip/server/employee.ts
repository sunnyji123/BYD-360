import express, { Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import {
  sqlite,
  PRIVATE_EMPLOYEE_DOCS_DIR,
  generateSecureToken,
  logEmployeeActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireEmployee,
  requireEmployeePermission,
  CANONICAL_EMPLOYEE_PERMISSIONS,
  getClientIp,
} from './auth';

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB private upload limit
});

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function recordEmployeeAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.employeeId || !req.auth?.companyId) return;
  logEmployeeActivity({
    employeeId: req.auth.employeeId,
    companyId: req.auth.companyId,
    branchId: req.auth.branchId,
    countryId: req.auth.country,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function assertNotImpersonatingEmployee(req: Request, res: Response): boolean {
  const empId = req.auth?.employeeId;
  const empCode = req.auth?.employeeCode;
  const compId = req.auth?.companyId;

  const qEmpId = req.query.employeeId ? String(req.query.employeeId).trim() : null;
  const qEmpCode = req.query.employeeCode ? String(req.query.employeeCode).trim().toUpperCase() : null;
  const qCompId = req.query.companyId ? String(req.query.companyId).trim() : null;

  const bEmpId = req.body?.employeeId || req.body?.employee_id ? String(req.body.employeeId || req.body.employee_id).trim() : null;
  const bCompId = req.body?.companyId || req.body?.company_id ? String(req.body.companyId || req.body.company_id).trim() : null;

  if (
    (qEmpId && qEmpId !== empId) ||
    (qEmpCode && qEmpCode !== empCode) ||
    (bEmpId && bEmpId !== empId) ||
    (qCompId && qCompId !== compId) ||
    (bCompId && bCompId !== compId)
  ) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'EMPLOYEE_IMPERSONATION_ATTEMPT_BLOCKED',
      userId: req.auth?.userId,
      identifier: req.auth?.email,
      companyId: compId,
      details: `Employee ${empCode} (${empId}) attempted cross-employee or cross-company parameter override on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    recordEmployeeAction(
      req,
      'CROSS_EMPLOYEE_ACCESS_BLOCKED',
      'Employee Security',
      qEmpId || bEmpId || qCompId || bCompId,
      'Blocked parameter spoofing / impersonation attempt.',
      'ALERT'
    );
    res.status(403).json({
      error: 'Access Denied: You can only view and manage your own assigned Employee records.',
    });
    return false;
  }
  return true;
}

function getEmployeeContextRow(employeeId: string) {
  return sqlite
    .prepare(`
      SELECT e.*, c.name as company_name, c.country as company_country, c.city as company_city,
             b.name as branch_name, b.code as branch_code, b.city as branch_city,
             co.name as country_name, co.currency as country_currency,
             d.name as department_name, d.code as department_code, d.head_name as department_head
      FROM employee_accounts e
      LEFT JOIN companies c ON c.id = e.company_id
      LEFT JOIN branches b ON b.id = e.branch_id
      LEFT JOIN countries co ON co.id = COALESCE(e.country_id, c.country)
      LEFT JOIN employee_departments d ON d.id = e.department_id
      WHERE e.id = ?
    `)
    .get(employeeId) as any;
}

function computeLeaveSummary(employeeId: string, leaveBalanceJson?: string | null) {
  const entitlements = safeJsonParse<{ annual: number; sick: number; casual: number }>(leaveBalanceJson, {
    annual: 18,
    sick: 10,
    casual: 8,
  });
  const approved = sqlite
    .prepare("SELECT leave_type, COALESCE(SUM(total_days), 0) as used FROM employee_leave_requests WHERE employee_id = ? AND status = 'Approved' GROUP BY leave_type")
    .all(employeeId) as Array<{ leave_type: string; used: number }>;

  let usedAnnual = 0;
  let usedSick = 0;
  let usedCasual = 0;
  for (const row of approved) {
    const t = String(row.leave_type || '').toLowerCase();
    if (t.includes('sick') || t.includes('medical')) usedSick += Number(row.used || 0);
    else if (t.includes('casual')) usedCasual += Number(row.used || 0);
    else usedAnnual += Number(row.used || 0);
  }

  return {
    annual: { total: entitlements.annual || 18, used: usedAnnual, remaining: Math.max(0, (entitlements.annual || 18) - usedAnnual) },
    sick: { total: entitlements.sick || 10, used: usedSick, remaining: Math.max(0, (entitlements.sick || 10) - usedSick) },
    casual: { total: entitlements.casual || 8, used: usedCasual, remaining: Math.max(0, (entitlements.casual || 8) - usedCasual) },
    totalRemaining:
      Math.max(0, (entitlements.annual || 18) - usedAnnual) +
      Math.max(0, (entitlements.sick || 10) - usedSick) +
      Math.max(0, (entitlements.casual || 8) - usedCasual),
  };
}

function savePrivateEmployeeFile(params: {
  file: Express.Multer.File;
  employeeId: string;
  companyId: string;
  countryId: string;
  branchId: string | null;
  category: string;
  title: string;
  uploadedById: string;
  uploadedByRole: string;
}) {
  if (!ALLOWED_MIME_TYPES.has(params.file.mimetype)) {
    throw new Error(`Unsupported file type "${params.file.mimetype}". Allowed: PNG, JPG, WEBP, PDF, TXT, CSV, DOC/DOCX.`);
  }
  if (!fs.existsSync(PRIVATE_EMPLOYEE_DOCS_DIR)) {
    fs.mkdirSync(PRIVATE_EMPLOYEE_DOCS_DIR, { recursive: true });
  }
  const ext = path.extname(params.file.originalname || '').replace(/[^a-zA-Z0-9.]/g, '').slice(0, 10) || '.bin';
  const storageKey = `${params.employeeId}_${Date.now()}_${generateSecureToken(8)}${ext}`;
  const fullPath = path.join(PRIVATE_EMPLOYEE_DOCS_DIR, path.basename(storageKey));
  fs.writeFileSync(fullPath, params.file.buffer);

  const docId = `edoc_${generateSecureToken(6)}`;
  const now = nowIso();
  sqlite
    .prepare(`
      INSERT INTO employee_documents (
        id, employee_id, company_id, country_id, branch_id, category, title,
        original_filename, mime_type, size_bytes, storage_key, uploaded_by_id, uploaded_by_role, is_confidential, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `)
    .run(
      docId,
      params.employeeId,
      params.companyId,
      params.countryId,
      params.branchId,
      params.category,
      params.title,
      params.file.originalname.slice(0, 180),
      params.file.mimetype,
      params.file.size,
      storageKey,
      params.uploadedById,
      params.uploadedByRole,
      now
    );

  return { id: docId, storageKey, createdAt: now };
}

function syncEmployeeAttendanceJson(employeeId: string) {
  const rows = sqlite
    .prepare('SELECT attendance_date, status, check_in_at, check_out_at, working_hours, notes FROM employee_attendance WHERE employee_id = ? ORDER BY attendance_date DESC LIMIT 90')
    .all(employeeId) as any[];
  const serialized = rows.map((r) => ({
    date: r.attendance_date,
    status: r.status,
    checkIn: r.check_in_at ? String(r.check_in_at).slice(11, 16) : null,
    checkOut: r.check_out_at ? String(r.check_out_at).slice(11, 16) : null,
    workingHours: r.working_hours,
    notes: r.notes || 'Employee Self Check-In',
  }));
  sqlite.prepare('UPDATE employee_accounts SET attendance_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(serialized), nowIso(), employeeId);
}

function syncEmployeeLeavesJson(employeeId: string) {
  const rows = sqlite
    .prepare('SELECT id, leave_type, start_date, end_date, total_days, reason, status, reviewed_by_name, reviewed_at, created_at FROM employee_leave_requests WHERE employee_id = ? ORDER BY created_at DESC LIMIT 60')
    .all(employeeId) as any[];
  const serialized = rows.map((r) => ({
    id: r.id,
    type: r.leave_type,
    startDate: r.start_date,
    endDate: r.end_date,
    totalDays: r.total_days,
    reason: r.reason,
    status: r.status,
    reviewedBy: r.reviewed_by_name || undefined,
    reviewedAt: r.reviewed_at || undefined,
    submittedAt: r.created_at,
  }));
  sqlite.prepare('UPDATE employee_accounts SET leave_requests_json = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(serialized), nowIso(), employeeId);
}

export function createEmployeeRouter() {
  const router = express.Router();

  // Strictly enforce verified Employee session on every route
  router.use(requireEmployee);

  // =========================================================================
  // 1. PERSONAL EMPLOYEE DASHBOARD OVERVIEW
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const emp = getEmployeeContextRow(empId);
    if (!emp) {
      res.status(404).json({ error: 'Employee profile not found.' });
      return;
    }

    const profile = sqlite.prepare('SELECT * FROM employee_profiles WHERE employee_id = ?').get(empId) as any;
    const assignment = sqlite.prepare("SELECT * FROM employee_assignments WHERE employee_id = ? AND status = 'Active' ORDER BY created_at DESC LIMIT 1").get(empId) as any;

    const todayDate = nowIso().slice(0, 10);
    const todayAttendance = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?')
      .get(empId, todayDate) as any;

    const recentAttendance = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? ORDER BY attendance_date DESC LIMIT 10')
      .all(empId) as any[];

    const monthPrefix = todayDate.slice(0, 7);
    const monthHoursRow = sqlite
      .prepare('SELECT COALESCE(SUM(working_hours), 0) as totalHours, COUNT(*) as daysLogged FROM employee_attendance WHERE employee_id = ? AND attendance_date LIKE ?')
      .get(empId, `${monthPrefix}%`) as { totalHours: number; daysLogged: number };

    const tasks = sqlite
      .prepare('SELECT * FROM employee_tasks WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId) as any[];
    const pendingTasks = tasks.filter((t) => t.status === 'Pending' || t.status === 'In Progress');
    const completedTasks = tasks.filter((t) => t.status === 'Completed');

    const leaveBalance = computeLeaveSummary(empId, emp.leave_balance_json);
    const pendingLeavesCount = (
      sqlite.prepare("SELECT COUNT(*) as c FROM employee_leave_requests WHERE employee_id = ? AND status = 'Pending'").get(empId) as any
    ).c;

    const canViewSalary = req.auth!.permissions.includes('employee.salary.view');
    const latestSalary = canViewSalary
      ? (sqlite.prepare('SELECT * FROM employee_salary_records WHERE employee_id = ? ORDER BY pay_period DESC LIMIT 1').get(empId) as any)
      : null;

    const notifications = sqlite
      .prepare(`
        SELECT * FROM employee_notifications
        WHERE (employee_id = ?)
           OR (employee_id IS NULL AND company_id = ? AND (branch_id IS NULL OR branch_id = ?))
        ORDER BY created_at DESC LIMIT 15
      `)
      .all(empId, emp.company_id, emp.branch_id || '') as any[];

    const recentActivities = sqlite
      .prepare('SELECT * FROM employee_activity_logs WHERE employee_id = ? ORDER BY created_at DESC LIMIT 15')
      .all(empId);

    const photoDocId = profile?.photo_doc_id || emp.photo_doc_id || null;

    res.json({
      employee: {
        id: emp.id,
        employeeCode: emp.employee_code,
        fullName: emp.full_name,
        email: emp.email,
        mobile: emp.mobile,
        jobPosition: emp.job_position,
        department: emp.department_name || emp.department,
        departmentId: emp.department_id,
        companyId: emp.company_id,
        companyName: emp.company_name,
        countryId: emp.country_id || emp.company_country,
        countryName: emp.country_name || emp.country_id,
        branchId: emp.branch_id,
        branchName: emp.branch_name || 'Head Office / Multi-Branch',
        branchCode: emp.branch_code || null,
        reportingManagerName: emp.reporting_manager_name || 'Assigned Manager',
        joiningDate: emp.joined_at,
        status: emp.status,
        shiftSchedule: assignment?.shift_schedule || 'Mon-Sat 09:00-18:00',
        performanceScore: emp.performance_score,
        photoDocId,
        photoUrl: photoDocId ? `/api/employee/documents/${photoDocId}/download` : null,
        permissions: req.auth!.permissions,
      },
      todayAttendance: todayAttendance || null,
      metrics: {
        todayStatus: todayAttendance ? todayAttendance.status : 'Not Checked In',
        todayHours: todayAttendance?.working_hours || 0,
        monthlyHoursWorked: Number((monthHoursRow.totalHours || 0).toFixed(2)),
        monthlyDaysLogged: monthHoursRow.daysLogged || 0,
        assignedTasksCount: tasks.length,
        pendingTasksCount: pendingTasks.length,
        completedTasksCount: completedTasks.length,
        leaveRemainingDays: leaveBalance.totalRemaining,
        pendingLeavesCount,
        unreadNotificationsCount: notifications.filter((n) => !n.is_read).length,
      },
      leaveBalance,
      salarySummary: canViewSalary
        ? {
            authorized: true,
            latestPayPeriod: latestSalary?.pay_period || null,
            currency: latestSalary?.currency || emp.country_currency || 'PKR',
            netSalary: latestSalary?.net_salary ?? 0,
            paymentStatus: latestSalary?.payment_status || 'Pending',
          }
        : { authorized: false },
      recentAttendance,
      pendingTasks: pendingTasks.slice(0, 6).map((t) => ({
        ...t,
        workUpdates: safeJsonParse(t.work_updates_json, []),
      })),
      notifications,
      recentActivities,
    });
  });

  // =========================================================================
  // 2. EMPLOYEE PROFILE MANAGEMENT (Immutable Org/Role Fields Protected)
  // =========================================================================
  router.get('/profile', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const emp = getEmployeeContextRow(empId);
    const profile = sqlite.prepare('SELECT * FROM employee_profiles WHERE employee_id = ?').get(empId) as any;
    const assignments = sqlite
      .prepare('SELECT * FROM employee_assignments WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId);

    const photoDocId = profile?.photo_doc_id || emp?.photo_doc_id || null;

    res.json({
      employee: {
        id: emp.id,
        employeeCode: emp.employee_code,
        fullName: emp.full_name,
        username: emp.username,
        email: emp.email,
        mobile: emp.mobile,
        jobPosition: emp.job_position,
        department: emp.department_name || emp.department,
        departmentHead: emp.department_head || null,
        companyId: emp.company_id,
        companyName: emp.company_name,
        countryId: emp.country_id || emp.company_country,
        countryName: emp.country_name || emp.country_id,
        branchId: emp.branch_id,
        branchName: emp.branch_name || 'Head Office',
        reportingManagerName: emp.reporting_manager_name,
        joiningDate: emp.joined_at,
        status: emp.status,
        emailVerified: Boolean(emp.email_verified),
        twoFactorEnabled: Boolean(emp.two_factor_enabled),
        photoDocId,
        photoUrl: photoDocId ? `/api/employee/documents/${photoDocId}/download` : null,
      },
      profile: profile
        ? {
            bio: profile.bio,
            dateOfBirth: profile.date_of_birth,
            gender: profile.gender,
            cnicOrId: profile.cnic_or_id,
            address: profile.address,
            city: profile.city,
            emergencyContactName: profile.emergency_contact_name,
            emergencyContactPhone: profile.emergency_contact_phone,
            emergencyContactRelation: profile.emergency_contact_relation,
            workLocation: profile.work_location,
            employmentType: profile.employment_type,
            responsibilities: safeJsonParse<string[]>(profile.responsibilities_json, []),
            skills: safeJsonParse<string[]>(profile.skills_json, []),
            updatedAt: profile.updated_at,
          }
        : null,
      assignments,
      permissions: req.auth!.permissions,
      canonicalPermissions: CANONICAL_EMPLOYEE_PERMISSIONS,
    });
  });

  router.put('/profile', requireEmployeePermission('employee.profile.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const body = req.body || {};

    // Strictly reject tampering with immutable employment / governance / salary fields
    const FORBIDDEN_FIELDS = [
      'jobPosition',
      'job_position',
      'role',
      'permissions',
      'permissions_json',
      'companyId',
      'company_id',
      'countryId',
      'country_id',
      'branchId',
      'branch_id',
      'departmentId',
      'department_id',
      'employeeCode',
      'employee_code',
      'status',
      'salary',
      'baseSalary',
      'netSalary',
      'reportingManagerId',
      'reporting_manager_id',
    ];
    const tampered = FORBIDDEN_FIELDS.find((f) => body[f] !== undefined);
    if (tampered) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'EMPLOYEE_IMMUTABLE_FIELD_TAMPER_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted to alter immutable field "${tampered}" via PUT /api/employee/profile.`,
        ipAddress: getClientIp(req),
      });
      recordEmployeeAction(req, 'IMMUTABLE_FIELD_TAMPER_BLOCKED', 'Employee Profile', tampered, `Attempted to modify restricted field "${tampered}".`, 'ALERT');
      res.status(403).json({
        error: `Forbidden: "${tampered}" is controlled exclusively by HR / Management and cannot be modified by employees.`,
      });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(empId) as any;
    const profile = sqlite.prepare('SELECT * FROM employee_profiles WHERE employee_id = ?').get(empId) as any;
    const now = nowIso();

    const mobile = body.mobile !== undefined ? String(body.mobile).trim() : emp.mobile;
    const bio = body.bio !== undefined ? String(body.bio).trim() : profile?.bio || '';
    const address = body.address !== undefined ? String(body.address).trim() : profile?.address || '';
    const city = body.city !== undefined ? String(body.city).trim() : profile?.city || 'Karachi';
    const dateOfBirth = body.dateOfBirth !== undefined ? String(body.dateOfBirth).trim() : profile?.date_of_birth || null;
    const gender = body.gender !== undefined ? String(body.gender).trim() : profile?.gender || null;
    const cnicOrId = body.cnicOrId !== undefined ? String(body.cnicOrId).trim() : profile?.cnic_or_id || null;
    const emergencyContactName = body.emergencyContactName !== undefined ? String(body.emergencyContactName).trim() : profile?.emergency_contact_name || '';
    const emergencyContactPhone = body.emergencyContactPhone !== undefined ? String(body.emergencyContactPhone).trim() : profile?.emergency_contact_phone || '';
    const emergencyContactRelation = body.emergencyContactRelation !== undefined ? String(body.emergencyContactRelation).trim() : profile?.emergency_contact_relation || 'Family';
    const skills = Array.isArray(body.skills)
      ? body.skills.map((s: any) => String(s).trim()).filter(Boolean).slice(0, 20)
      : safeJsonParse<string[]>(profile?.skills_json, []);

    sqlite.prepare('UPDATE employee_accounts SET mobile = ?, updated_at = ? WHERE id = ?').run(mobile, now, empId);
    if (emp.user_id) {
      sqlite.prepare('UPDATE users SET mobile = ?, city = ?, updated_at = ? WHERE id = ?').run(mobile, city, now, emp.user_id);
    }

    sqlite
      .prepare(`
        UPDATE employee_profiles
        SET bio = ?, address = ?, city = ?, date_of_birth = ?, gender = ?, cnic_or_id = ?,
            emergency_contact_name = ?, emergency_contact_phone = ?, emergency_contact_relation = ?,
            skills_json = ?, updated_at = ?
        WHERE employee_id = ?
      `)
      .run(bio, address, city, dateOfBirth, gender, cnicOrId, emergencyContactName, emergencyContactPhone, emergencyContactRelation, JSON.stringify(skills), now, empId);

    recordEmployeeAction(req, 'EMPLOYEE_PROFILE_UPDATED', 'Employee Profile', emp.employee_code, 'Updated personal contact & emergency information.');
    res.json({ success: true, message: 'Personal profile and contact details updated.' });
  });

  router.post('/profile/photo', requireEmployeePermission('employee.profile.manage'), upload.single('photo'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    if (!req.file) {
      res.status(400).json({ error: 'Profile photograph file is required.' });
      return;
    }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(req.file.mimetype)) {
      res.status(400).json({ error: 'Profile photo must be a JPG, PNG, or WEBP image.' });
      return;
    }

    try {
      const empId = req.auth!.employeeId!;
      const saved = savePrivateEmployeeFile({
        file: req.file,
        employeeId: empId,
        companyId: req.auth!.companyId!,
        countryId: req.auth!.country,
        branchId: req.auth!.branchId || null,
        category: 'Profile Photo',
        title: `Profile Photograph — ${req.auth!.employeeCode}`,
        uploadedById: empId,
        uploadedByRole: req.auth!.role,
      });

      const now = nowIso();
      sqlite.prepare('UPDATE employee_accounts SET photo_doc_id = ?, updated_at = ? WHERE id = ?').run(saved.id, now, empId);
      sqlite.prepare('UPDATE employee_profiles SET photo_doc_id = ?, updated_at = ? WHERE employee_id = ?').run(saved.id, now, empId);

      recordEmployeeAction(req, 'PROFILE_PHOTO_UPDATED', 'Employee Profile', saved.id, 'Uploaded private profile photograph.');
      res.status(201).json({
        success: true,
        photoDocId: saved.id,
        photoUrl: `/api/employee/documents/${saved.id}/download`,
      });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Failed to upload profile photo.' });
    }
  });

  // =========================================================================
  // 3. ATTENDANCE MANAGEMENT (CHECK-IN, CHECK-OUT, HOURS, CORRECTION REQUESTS)
  // =========================================================================
  router.get('/attendance', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const records = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? ORDER BY attendance_date DESC LIMIT 90')
      .all(empId) as any[];

    const todayDate = nowIso().slice(0, 10);
    const todayRecord = records.find((r) => r.attendance_date === todayDate) || null;
    const totalHours = Number(records.reduce((acc, r) => acc + Number(r.working_hours || 0), 0).toFixed(2));
    const presentDays = records.filter((r) => r.status === 'Present' || r.status === 'Remote').length;
    const lateDays = records.filter((r) => r.status === 'Late').length;
    const absentDays = records.filter((r) => r.status === 'Absent').length;

    res.json({
      todayRecord,
      records,
      summary: {
        totalDays: records.length,
        presentDays,
        lateDays,
        absentDays,
        totalHours,
      },
    });
  });

  router.post('/attendance/check-in', requireEmployeePermission('employee.attendance.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const now = new Date();
    const todayDate = now.toISOString().slice(0, 10);

    const existing = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?')
      .get(empId, todayDate) as any;

    if (existing && existing.check_in_at) {
      res.status(409).json({
        error: `Already checked in today (${todayDate}) at ${String(existing.check_in_at).slice(11, 19)} UTC. Duplicate daily check-in is blocked.`,
      });
      return;
    }

    const workMode = ['On-Site', 'Remote', 'Field Duty'].includes(String(req.body?.workMode)) ? String(req.body.workMode) : 'On-Site';
    const notes = String(req.body?.notes || '').trim() || `${workMode} shift check-in`;

    // Standard shift start 09:15 UTC reference for SLA late tracking
    const shiftStart = new Date(`${todayDate}T09:15:00.000Z`);
    const lateMinutes = Math.max(0, Math.round((now.getTime() - shiftStart.getTime()) / 60000));
    const status = workMode === 'Remote' ? 'Remote' : lateMinutes > 15 ? 'Late' : 'Present';

    const attId = `att_${generateSecureToken(6)}`;
    const nowStr = now.toISOString();

    sqlite
      .prepare(`
        INSERT INTO employee_attendance (
          id, employee_id, company_id, country_id, branch_id, attendance_date,
          check_in_at, working_hours, status, late_minutes, work_mode, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        attId,
        empId,
        req.auth!.companyId!,
        req.auth!.country,
        req.auth!.branchId || null,
        todayDate,
        nowStr,
        status,
        lateMinutes,
        workMode,
        notes,
        nowStr,
        nowStr
      );

    syncEmployeeAttendanceJson(empId);
    recordEmployeeAction(req, 'ATTENDANCE_CHECK_IN', 'Attendance', attId, `Checked in on ${todayDate} (${status}, mode: ${workMode}).`);
    res.status(201).json({
      success: true,
      record: sqlite.prepare('SELECT * FROM employee_attendance WHERE id = ?').get(attId),
    });
  });

  router.post('/attendance/check-out', requireEmployeePermission('employee.attendance.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const now = new Date();
    const todayDate = now.toISOString().slice(0, 10);

    const existing = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?')
      .get(empId, todayDate) as any;

    if (!existing || !existing.check_in_at) {
      res.status(400).json({ error: 'Cannot check out before checking in for today.' });
      return;
    }

    if (existing.check_out_at) {
      res.status(409).json({
        error: `Already checked out today (${todayDate}) at ${String(existing.check_out_at).slice(11, 19)} UTC. Duplicate check-out is blocked.`,
      });
      return;
    }

    const checkInMs = new Date(existing.check_in_at).getTime();
    const hoursWorked = Number(Math.max(0.01, (now.getTime() - checkInMs) / 3600000).toFixed(2));
    const shiftEnd = new Date(`${todayDate}T18:00:00.000Z`);
    const earlyLeaveMinutes = Math.max(0, Math.round((shiftEnd.getTime() - now.getTime()) / 60000));
    const nowStr = now.toISOString();
    const outNotes = req.body?.notes ? `${existing.notes || ''} | Out: ${String(req.body.notes).trim()}` : existing.notes;

    sqlite
      .prepare(`
        UPDATE employee_attendance
        SET check_out_at = ?, working_hours = ?, early_leave_minutes = ?, notes = ?, updated_at = ?
        WHERE id = ? AND employee_id = ?
      `)
      .run(nowStr, hoursWorked, earlyLeaveMinutes, outNotes, nowStr, existing.id, empId);

    syncEmployeeAttendanceJson(empId);
    recordEmployeeAction(req, 'ATTENDANCE_CHECK_OUT', 'Attendance', existing.id, `Checked out on ${todayDate}. Hours worked: ${hoursWorked}h.`);
    res.json({
      success: true,
      workingHours: hoursWorked,
      record: sqlite.prepare('SELECT * FROM employee_attendance WHERE id = ?').get(existing.id),
    });
  });

  // Block employees from directly editing official attendance records via PUT/PATCH
  router.put('/attendance/:id', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'EMPLOYEE_ATTENDANCE_EDIT_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Employee ${req.auth!.employeeCode} attempted direct overwrite of official attendance record ${req.params.id}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Employees cannot directly alter official attendance records. Submit an Attendance Correction Request for manager review.',
    });
  });

  router.post('/attendance/correction-request', requireEmployeePermission('employee.attendance.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const attendanceDate = String(req.body.attendanceDate || '').slice(0, 10);
    const reason = String(req.body.reason || '').trim();

    if (!attendanceDate || !reason || reason.length < 5) {
      res.status(400).json({ error: 'Valid attendance date and detailed correction reason are required.' });
      return;
    }

    const existing = sqlite
      .prepare('SELECT * FROM employee_attendance WHERE employee_id = ? AND attendance_date = ?')
      .get(empId, attendanceDate) as any;

    const now = nowIso();
    if (existing) {
      sqlite
        .prepare("UPDATE employee_attendance SET correction_requested = 1, correction_reason = ?, correction_status = 'Pending Manager Review', updated_at = ? WHERE id = ?")
        .run(reason, now, existing.id);
    } else {
      sqlite
        .prepare(`
          INSERT INTO employee_attendance (
            id, employee_id, company_id, country_id, branch_id, attendance_date,
            status, notes, correction_requested, correction_reason, correction_status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, 'Pending Verification', 'Missed punch reported by employee', 1, ?, 'Pending Manager Review', ?, ?)
        `)
        .run(
          `att_${generateSecureToken(6)}`,
          empId,
          req.auth!.companyId!,
          req.auth!.country,
          req.auth!.branchId || null,
          attendanceDate,
          reason,
          now,
          now
        );
    }

    recordEmployeeAction(req, 'ATTENDANCE_CORRECTION_REQUESTED', 'Attendance', attendanceDate, reason);
    res.status(201).json({ success: true, message: 'Attendance correction request submitted for Branch Manager review.' });
  });

  // =========================================================================
  // 4. LEAVE MANAGEMENT (APPLY, BALANCE, HISTORY, CANCEL — NO SELF-APPROVAL)
  // =========================================================================
  router.get('/leaves', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const emp = sqlite.prepare('SELECT leave_balance_json FROM employee_accounts WHERE id = ?').get(empId) as any;
    const balance = computeLeaveSummary(empId, emp?.leave_balance_json);
    const requests = sqlite
      .prepare('SELECT * FROM employee_leave_requests WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId);

    res.json({ balance, requests });
  });

  router.post('/leaves', requireEmployeePermission('employee.leave.manage'), upload.single('supportingDocument'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const body = req.body || {};

    if (body.status && String(body.status) !== 'Pending') {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'EMPLOYEE_SELF_LEAVE_APPROVAL_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted to create pre-approved leave with status "${body.status}".`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Employees cannot approve or alter leave approval status.' });
      return;
    }

    const leaveType = String(body.leaveType || 'Annual Leave').trim();
    const startDate = String(body.startDate || '').slice(0, 10);
    const endDate = String(body.endDate || '').slice(0, 10);
    const reason = String(body.reason || '').trim();

    if (!startDate || !endDate || !reason || reason.length < 4) {
      res.status(400).json({ error: 'Leave type, start date, end date, and reason are required.' });
      return;
    }

    const sMs = new Date(`${startDate}T00:00:00Z`).getTime();
    const eMs = new Date(`${endDate}T00:00:00Z`).getTime();
    if (Number.isNaN(sMs) || Number.isNaN(eMs) || eMs < sMs) {
      res.status(400).json({ error: 'End date must be on or after start date.' });
      return;
    }

    const totalDays = Math.min(60, Math.floor((eMs - sMs) / 86400_000) + 1);
    const emp = sqlite.prepare('SELECT leave_balance_json FROM employee_accounts WHERE id = ?').get(empId) as any;
    const balance = computeLeaveSummary(empId, emp?.leave_balance_json);
    const tLower = leaveType.toLowerCase();
    const availableForType = tLower.includes('sick')
      ? balance.sick.remaining
      : tLower.includes('casual')
      ? balance.casual.remaining
      : balance.annual.remaining;

    if (totalDays > availableForType) {
      res.status(400).json({ error: `Requested ${totalDays} day(s) exceeds your remaining ${leaveType} balance (${availableForType} days).` });
      return;
    }

    let supportingDocId: string | null = null;
    if (req.file) {
      try {
        const saved = savePrivateEmployeeFile({
          file: req.file,
          employeeId: empId,
          companyId: req.auth!.companyId!,
          countryId: req.auth!.country,
          branchId: req.auth!.branchId || null,
          category: 'Leave Supporting Document',
          title: `${leaveType} Proof (${startDate} to ${endDate})`,
          uploadedById: empId,
          uploadedByRole: req.auth!.role,
        });
        supportingDocId = saved.id;
      } catch (err: any) {
        res.status(400).json({ error: err?.message || 'Supporting document upload failed.' });
        return;
      }
    }

    const leaveId = `lv_${generateSecureToken(5)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO employee_leave_requests (
          id, employee_id, company_id, country_id, branch_id, leave_type,
          start_date, end_date, total_days, reason, supporting_doc_id, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)
      `)
      .run(
        leaveId,
        empId,
        req.auth!.companyId!,
        req.auth!.country,
        req.auth!.branchId || null,
        leaveType,
        startDate,
        endDate,
        totalDays,
        reason,
        supportingDocId,
        now,
        now
      );

    syncEmployeeLeavesJson(empId);
    recordEmployeeAction(req, 'LEAVE_APPLIED', 'Leave Management', leaveId, `${leaveType}: ${startDate} to ${endDate} (${totalDays} day(s)).`);
    res.status(201).json({
      success: true,
      leaveId,
      request: sqlite.prepare('SELECT * FROM employee_leave_requests WHERE id = ?').get(leaveId),
    });
  });

  router.patch('/leaves/:id/cancel', requireEmployeePermission('employee.leave.manage'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const lv = sqlite.prepare('SELECT * FROM employee_leave_requests WHERE id = ?').get(req.params.id) as any;
    if (!lv) {
      res.status(404).json({ error: 'Leave request not found.' });
      return;
    }
    if (lv.employee_id !== empId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_EMPLOYEE_LEAVE_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted to cancel another employee's leave request (${req.params.id}).`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: You cannot modify another employee leave request.' });
      return;
    }
    if (lv.status !== 'Pending') {
      res.status(400).json({ error: `Cannot cancel leave request in "${lv.status}" state.` });
      return;
    }

    sqlite.prepare("UPDATE employee_leave_requests SET status = 'Cancelled', updated_at = ? WHERE id = ?").run(nowIso(), lv.id);
    syncEmployeeLeavesJson(empId);
    recordEmployeeAction(req, 'LEAVE_CANCELLED', 'Leave Management', lv.id, 'Cancelled pending leave application.');
    res.json({ success: true });
  });

  // Explicitly block any self-approval attempts on employee leave endpoints
  router.all('/leaves/:id/approve', (req: Request, res: Response) => {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'EMPLOYEE_SELF_LEAVE_APPROVAL_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Employee ${req.auth!.employeeCode} attempted unauthorized self-approval on leave ${req.params.id}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Employees are strictly prohibited from approving or rejecting leave requests.' });
  });

  // =========================================================================
  // 5. TASK & WORK MANAGEMENT
  // =========================================================================
  router.get('/tasks', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const tasks = sqlite
      .prepare('SELECT * FROM employee_tasks WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId)
      .map((t: any) => ({
        ...t,
        workUpdates: safeJsonParse<any[]>(t.work_updates_json, []),
        attachmentDocIds: safeJsonParse<string[]>(t.attachment_doc_ids_json, []),
      }));
    res.json({ tasks });
  });

  router.patch('/tasks/:id/start', requireEmployeePermission('employee.tasks.manage'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const task = sqlite.prepare('SELECT * FROM employee_tasks WHERE id = ?').get(req.params.id) as any;
    if (!task) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    if (task.employee_id !== empId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_EMPLOYEE_TASK_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted to start task ${req.params.id} owned by ${task.employee_id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: Task does not belong to your employee profile.' });
      return;
    }

    const now = nowIso();
    const updates = safeJsonParse<any[]>(task.work_updates_json, []);
    updates.push({ by: req.auth!.fullName, role: req.auth!.role, text: 'Started work on task.', at: now });

    sqlite
      .prepare("UPDATE employee_tasks SET status = 'In Progress', started_at = COALESCE(started_at, ?), work_updates_json = ?, updated_at = ? WHERE id = ?")
      .run(now, JSON.stringify(updates), now, task.id);

    recordEmployeeAction(req, 'TASK_STARTED', 'Task Management', task.task_code, `Marked "${task.title}" In Progress.`);
    res.json({ success: true, status: 'In Progress' });
  });

  router.post('/tasks/:id/update', requireEmployeePermission('employee.tasks.manage'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const task = sqlite.prepare('SELECT * FROM employee_tasks WHERE id = ?').get(req.params.id) as any;
    if (!task) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    if (task.employee_id !== empId) {
      res.status(403).json({ error: 'Access Denied: Task does not belong to your employee profile.' });
      return;
    }

    const note = String(req.body.note || req.body.comment || '').trim();
    if (!note) {
      res.status(400).json({ error: 'Work update comment is required.' });
      return;
    }

    const now = nowIso();
    const updates = safeJsonParse<any[]>(task.work_updates_json, []);
    updates.push({ by: req.auth!.fullName, role: req.auth!.role, text: note, at: now });

    sqlite
      .prepare("UPDATE employee_tasks SET work_updates_json = ?, status = CASE WHEN status = 'Pending' THEN 'In Progress' ELSE status END, updated_at = ? WHERE id = ?")
      .run(JSON.stringify(updates), now, task.id);

    recordEmployeeAction(req, 'TASK_WORK_UPDATED', 'Task Management', task.task_code, note.slice(0, 120));
    res.json({ success: true, workUpdates: updates });
  });

  router.post('/tasks/:id/document', requireEmployeePermission('employee.tasks.manage'), upload.single('file'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const task = sqlite.prepare('SELECT * FROM employee_tasks WHERE id = ?').get(req.params.id) as any;
    if (!task) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    if (task.employee_id !== empId) {
      res.status(403).json({ error: 'Access Denied: Task does not belong to your employee profile.' });
      return;
    }
    if (!req.file) {
      res.status(400).json({ error: 'Task deliverable file is required.' });
      return;
    }

    try {
      const saved = savePrivateEmployeeFile({
        file: req.file,
        employeeId: empId,
        companyId: req.auth!.companyId!,
        countryId: req.auth!.country,
        branchId: req.auth!.branchId || null,
        category: 'Task Deliverable',
        title: String(req.body?.title || `Deliverable — ${task.task_code}`),
        uploadedById: empId,
        uploadedByRole: req.auth!.role,
      });

      const docIds = safeJsonParse<string[]>(task.attachment_doc_ids_json, []);
      docIds.push(saved.id);
      const updates = safeJsonParse<any[]>(task.work_updates_json, []);
      updates.push({ by: req.auth!.fullName, role: req.auth!.role, text: `Uploaded task file: ${req.file.originalname}`, at: saved.createdAt });

      sqlite
        .prepare('UPDATE employee_tasks SET attachment_doc_ids_json = ?, work_updates_json = ?, updated_at = ? WHERE id = ?')
        .run(JSON.stringify(docIds), JSON.stringify(updates), saved.createdAt, task.id);

      recordEmployeeAction(req, 'TASK_DOCUMENT_UPLOADED', 'Task Management', task.task_code, `Uploaded ${req.file.originalname}`);
      res.status(201).json({ success: true, docId: saved.id, attachmentDocIds: docIds });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Task file upload failed.' });
    }
  });

  router.patch('/tasks/:id/complete', requireEmployeePermission('employee.tasks.manage'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const task = sqlite.prepare('SELECT * FROM employee_tasks WHERE id = ?').get(req.params.id) as any;
    if (!task) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    if (task.employee_id !== empId) {
      res.status(403).json({ error: 'Access Denied: Task does not belong to your employee profile.' });
      return;
    }

    const now = nowIso();
    const completionNote = String(req.body?.note || 'Task deliverables completed and submitted.').trim();
    const updates = safeJsonParse<any[]>(task.work_updates_json, []);
    updates.push({ by: req.auth!.fullName, role: req.auth!.role, text: `Completed: ${completionNote}`, at: now });

    sqlite
      .prepare("UPDATE employee_tasks SET status = 'Completed', completed_at = ?, work_updates_json = ?, updated_at = ? WHERE id = ?")
      .run(now, JSON.stringify(updates), now, task.id);

    recordEmployeeAction(req, 'TASK_COMPLETED', 'Task Management', task.task_code, `Completed "${task.title}".`);
    res.json({ success: true, status: 'Completed' });
  });

  // =========================================================================
  // 6. PRIVATE SALARY & PAYROLL VIEWING (STRICTLY READ-ONLY & PERSONAL)
  // =========================================================================
  router.get('/salary', requireEmployeePermission('employee.salary.view'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const records = sqlite
      .prepare('SELECT * FROM employee_salary_records WHERE employee_id = ? ORDER BY pay_period DESC')
      .all(empId) as any[];

    const latest = records[0] || null;
    res.json({
      structure: latest
        ? {
            currency: latest.currency,
            baseSalary: latest.base_salary,
            allowances: latest.allowances,
            bonuses: latest.bonuses,
            deductions: latest.deductions,
            taxDeduction: latest.tax_deduction,
            netSalary: latest.net_salary,
          }
        : null,
      records,
    });
  });

  router.get('/salary/:id/slip', requireEmployeePermission('employee.salary.view'), (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const sal = sqlite.prepare('SELECT * FROM employee_salary_records WHERE id = ?').get(req.params.id) as any;
    if (!sal) {
      res.status(404).json({ error: 'Salary record not found.' });
      return;
    }
    if (sal.employee_id !== empId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_EMPLOYEE_SALARY_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted to access salary record ${req.params.id} owned by ${sal.employee_id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: Salary information is strictly private to each individual employee.' });
      return;
    }

    const emp = sqlite.prepare('SELECT full_name, employee_code, department, job_position FROM employee_accounts WHERE id = ?').get(empId) as any;
    recordEmployeeAction(req, 'SALARY_SLIP_ACCESSED', 'Salary & Payroll', sal.pay_period, `Viewed/downloaded pay slip ${sal.pay_period}.`);
    res.json({
      slip: {
        ...sal,
        employeeName: emp?.full_name,
        employeeCode: emp?.employee_code,
        department: emp?.department,
        jobPosition: emp?.job_position,
      },
    });
  });

  router.all('/salary*', (req: Request, res: Response, next) => {
    if (req.method === 'GET') {
      next();
      return;
    }
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'EMPLOYEE_PAYROLL_MODIFICATION_BLOCKED',
      userId: req.auth!.userId,
      identifier: req.auth!.email,
      companyId: req.auth!.companyId,
      details: `Employee ${req.auth!.employeeCode} attempted ${req.method} on ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Forbidden: Only authorized Payroll / Company Administrators can create or modify salary records.' });
  });

  // =========================================================================
  // 7. PRIVATE DOCUMENT MANAGEMENT (UPLOAD & AUTHENTICATED DOWNLOAD ONLY)
  // =========================================================================
  router.get('/documents', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const docs = sqlite
      .prepare('SELECT id, employee_id, category, title, original_filename, mime_type, size_bytes, uploaded_by_role, is_confidential, created_at FROM employee_documents WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId);
    res.json({ documents: docs });
  });

  router.post('/documents', requireEmployeePermission('employee.documents.manage'), upload.single('file'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    if (!req.file) {
      res.status(400).json({ error: 'Document file is required.' });
      return;
    }

    const category = String(req.body?.category || 'Employment Document').trim();
    const title = String(req.body?.title || req.file.originalname).trim();

    try {
      const saved = savePrivateEmployeeFile({
        file: req.file,
        employeeId: req.auth!.employeeId!,
        companyId: req.auth!.companyId!,
        countryId: req.auth!.country,
        branchId: req.auth!.branchId || null,
        category,
        title,
        uploadedById: req.auth!.employeeId!,
        uploadedByRole: req.auth!.role,
      });

      recordEmployeeAction(req, 'EMPLOYEE_DOCUMENT_UPLOADED', 'Documents', saved.id, `${category}: ${title}`);
      res.status(201).json({
        success: true,
        document: sqlite.prepare('SELECT id, category, title, original_filename, mime_type, size_bytes, uploaded_by_role, created_at FROM employee_documents WHERE id = ?').get(saved.id),
      });
    } catch (err: any) {
      res.status(400).json({ error: err?.message || 'Document upload failed.' });
    }
  });

  router.get('/documents/:id/download', (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const doc = sqlite.prepare('SELECT * FROM employee_documents WHERE id = ?').get(req.params.id) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    if (doc.employee_id !== empId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_EMPLOYEE_DOCUMENT_ACCESS_BLOCKED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Employee ${req.auth!.employeeCode} attempted unauthorized download of document ${req.params.id} belonging to ${doc.employee_id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access Denied: You may only download your own private employee documents.' });
      return;
    }

    const safeFile = path.basename(String(doc.storage_key));
    const fullPath = path.join(PRIVATE_EMPLOYEE_DOCS_DIR, safeFile);
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'Document binary missing from private storage.' });
      return;
    }

    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `${req.query.inline === '1' ? 'inline' : 'attachment'}; filename="${encodeURIComponent(doc.original_filename || safeFile)}"`);
    fs.createReadStream(fullPath).pipe(res);
  });

  // =========================================================================
  // 8. PERFORMANCE & DEVELOPMENT
  // =========================================================================
  router.get('/performance', requireEmployeePermission('employee.performance.view'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const emp = sqlite.prepare('SELECT performance_score, performance_notes FROM employee_accounts WHERE id = ?').get(empId) as any;
    const reviews = sqlite
      .prepare('SELECT * FROM employee_performance_reviews WHERE employee_id = ? ORDER BY created_at DESC')
      .all(empId)
      .map((r: any) => ({
        ...r,
        trainings: safeJsonParse<any[]>(r.trainings_json, []),
        goals: safeJsonParse<any[]>(r.goals_json, []),
      }));

    const taskStats = sqlite
      .prepare(`
        SELECT COUNT(*) as total,
               SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed
        FROM employee_tasks WHERE employee_id = ?
      `)
      .get(empId) as { total: number; completed: number };

    const attStats = sqlite
      .prepare(`
        SELECT COUNT(*) as total,
               SUM(CASE WHEN status IN ('Present', 'Remote') THEN 1 ELSE 0 END) as onTime,
               COALESCE(SUM(working_hours), 0) as totalHours
        FROM employee_attendance WHERE employee_id = ?
      `)
      .get(empId) as { total: number; onTime: number; totalHours: number };

    res.json({
      currentScore: emp?.performance_score ?? 92,
      managerNotes: emp?.performance_notes || '',
      taskCompletionRate: taskStats.total ? Math.round((Number(taskStats.completed || 0) / taskStats.total) * 100) : 100,
      attendanceRate: attStats.total ? Math.round((Number(attStats.onTime || 0) / attStats.total) * 100) : 100,
      totalHoursLogged: Number((attStats.totalHours || 0).toFixed(2)),
      reviews,
    });
  });

  // =========================================================================
  // 9. INTERNAL COMMUNICATION & ANNOUNCEMENTS
  // =========================================================================
  router.get('/communications', (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const notifications = sqlite
      .prepare(`
        SELECT * FROM employee_notifications
        WHERE (employee_id = ?)
           OR (employee_id IS NULL AND company_id = ? AND (branch_id IS NULL OR branch_id = ?))
        ORDER BY created_at DESC LIMIT 50
      `)
      .all(empId, req.auth!.companyId!, req.auth!.branchId || '');

    res.json({ notifications });
  });

  router.patch('/communications/:id/read', (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const row = sqlite.prepare('SELECT * FROM employee_notifications WHERE id = ?').get(req.params.id) as any;
    if (!row) {
      res.status(404).json({ error: 'Notification not found.' });
      return;
    }
    if (row.employee_id && row.employee_id !== empId) {
      res.status(403).json({ error: 'Access Denied.' });
      return;
    }
    sqlite.prepare('UPDATE employee_notifications SET is_read = 1, read_at = ? WHERE id = ?').run(nowIso(), row.id);
    res.json({ success: true });
  });

  // =========================================================================
  // 10. EMPLOYEE SUPPORT & WORKPLACE HELP DESK
  // =========================================================================
  router.get('/support', requireEmployeePermission('employee.support.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const empId = req.auth!.employeeId!;
    const tickets = sqlite
      .prepare('SELECT * FROM support_requests WHERE employee_id = ? OR user_id = ? ORDER BY created_at DESC')
      .all(empId, empId);
    res.json({ tickets });
  });

  router.post('/support', requireEmployeePermission('employee.support.manage'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingEmployee(req, res)) return;
    const category = String(req.body.category || 'HR Query').trim();
    const priority = ['Low', 'Medium', 'High', 'Critical'].includes(String(req.body.priority)) ? String(req.body.priority) : 'Medium';
    const subject = String(req.body.subject || '').trim();
    const description = String(req.body.description || '').trim();

    if (!subject || !description) {
      res.status(400).json({ error: 'Support subject and detailed description are required.' });
      return;
    }

    const id = `sup_emp_${generateSecureToken(5)}`;
    const ticketNumber = `HR-${Math.floor(10000 + Math.random() * 89999)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO support_requests (
          id, ticket_number, company_id, user_id, employee_id, requester_name, requester_email,
          category, priority, subject, description, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?)
      `)
      .run(
        id,
        ticketNumber,
        req.auth!.companyId!,
        req.auth!.userId,
        req.auth!.employeeId!,
        req.auth!.fullName,
        req.auth!.email,
        category,
        priority,
        subject,
        description,
        now,
        now
      );

    recordEmployeeAction(req, 'SUPPORT_TICKET_CREATED', 'Employee Support', ticketNumber, `${category}: ${subject}`);
    res.status(201).json({ success: true, id, ticketNumber });
  });

  // =========================================================================
  // 11. PERSONAL ACTIVITY LOGS & SECURITY AUDIT
  // =========================================================================
  router.get('/audit-logs', (req: Request, res: Response) => {
    const empId = req.auth!.employeeId!;
    const logs = sqlite
      .prepare('SELECT * FROM employee_activity_logs WHERE employee_id = ? ORDER BY created_at DESC LIMIT 80')
      .all(empId);
    res.json({ logs });
  });

  return router;
}
