import React, { useEffect, useState } from 'react';
import {
  Award,
  Briefcase,
  CheckCircle2,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  FolderLock,
  History,
  Plus,
  Settings,
  ShieldCheck,
  Target,
  Upload,
  X,
} from 'lucide-react';
import { api } from '../../services/api';
import { triggerBlobDownload } from './EmployeeOperationsPanels';

interface GovPanelProps {
  scope: any;
  employees: any[];
  companies: any[];
  branches: any[];
  departments: any[];
  documentCategories: string[];
  onNotify: (type: 'success' | 'error', text: string) => void;
  onRefreshDashboard: () => void;
}

// ============================================================================
// JOB POSITIONS, DEPARTMENTS & PROMOTION/TRANSFER HISTORY PANEL
// ============================================================================
export const PositionsPanel: React.FC<GovPanelProps> = ({
  scope,
  employees,
  companies,
  branches,
  departments,
  onNotify,
  onRefreshDashboard,
}) => {
  const [positions, setPositions] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [posForm, setPosForm] = useState({
    companyId: companies[0]?.id || 'comp_byd_pk',
    branchId: '',
    departmentId: '',
    title: '',
    designation: '',
    employmentType: 'Full-Time Permanent',
    reportingManagerName: '',
    minSalary: '0',
    maxSalary: '0',
    responsibilities: '',
  });

  const [promoForm, setPromoForm] = useState({
    employeeId: '',
    changeType: 'Promotion',
    jobPosition: '',
    department: '',
    branchId: '',
    reportingManagerName: '',
    effectiveDate: new Date().toISOString().slice(0, 10),
    notes: '',
  });

  const loadPositions = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtPositions();
      setPositions(res.positions || []);
      setHistory(res.history || []);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load job positions.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPositions();
  }, []);

  const handleCreatePosition = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createEmpMgmtPosition({
        ...posForm,
        branchId: posForm.branchId || null,
        departmentId: posForm.departmentId || null,
        minSalary: Number(posForm.minSalary || 0),
        maxSalary: Number(posForm.maxSalary || 0),
      });
      onNotify('success', `Job position "${posForm.title}" created.`);
      setPosForm((p) => ({ ...p, title: '', designation: '', responsibilities: '' }));
      loadPositions();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to create job position.');
    }
  };

  const handlePromoteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoForm.employeeId) {
      onNotify('error', 'Select an employee first.');
      return;
    }
    try {
      await api.promoteTransferEmpMgmtEmployee(promoForm.employeeId, {
        changeType: promoForm.changeType,
        jobPosition: promoForm.jobPosition || undefined,
        department: promoForm.department || undefined,
        branchId: promoForm.branchId === '' ? undefined : promoForm.branchId === 'HQ' ? null : promoForm.branchId,
        reportingManagerName: promoForm.reportingManagerName || undefined,
        effectiveDate: promoForm.effectiveDate,
        notes: promoForm.notes,
      });
      onNotify('success', `${promoForm.changeType} executed and logged to employment history.`);
      setPromoForm((p) => ({ ...p, jobPosition: '', notes: '' }));
      loadPositions();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Promotion / transfer failed.');
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-bold text-white">Job Positions, Departments &amp; Career Movements</h2>
        <p className="text-xs text-slate-400">
          Linked to existing BYD Pakistan 360 company departments &amp; branches (zero duplicate organization tables).
        </p>
      </div>

      {scope.canManagePositions && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <form onSubmit={handleCreatePosition} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
            <div className="font-bold text-amber-400 uppercase tracking-wider">Define Job Position</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <select
                value={posForm.companyId}
                onChange={(e) => setPosForm({ ...posForm, companyId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <select
                value={posForm.departmentId}
                onChange={(e) => setPosForm({ ...posForm, departmentId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="">Select Department (Optional)</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
              <input
                type="text"
                required
                value={posForm.title}
                onChange={(e) => setPosForm({ ...posForm, title: e.target.value })}
                placeholder="Job Title (e.g. EV Master Technician)"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <select
                value={posForm.employmentType}
                onChange={(e) => setPosForm({ ...posForm, employmentType: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="Full-Time Permanent">Full-Time Permanent</option>
                <option value="Contract">Contract</option>
                <option value="Probation">Probation</option>
                <option value="Part-Time">Part-Time</option>
              </select>
              <input
                type="number"
                min="0"
                value={posForm.minSalary}
                onChange={(e) => setPosForm({ ...posForm, minSalary: e.target.value })}
                placeholder="Min Salary Band"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                min="0"
                value={posForm.maxSalary}
                onChange={(e) => setPosForm({ ...posForm, maxSalary: e.target.value })}
                placeholder="Max Salary Band"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <input
              type="text"
              value={posForm.responsibilities}
              onChange={(e) => setPosForm({ ...posForm, responsibilities: e.target.value })}
              placeholder="Core role responsibilities..."
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
            <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
              Save Job Position
            </button>
          </form>

          <form onSubmit={handlePromoteTransfer} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
            <div className="font-bold text-amber-400 uppercase tracking-wider">Employee Promotion / Branch Transfer</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <select
                required
                value={promoForm.employeeId}
                onChange={(e) => setPromoForm({ ...promoForm, employeeId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white sm:col-span-2"
              >
                <option value="">Select Employee...</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.employeeCode} — {e.fullName} ({e.jobPosition})
                  </option>
                ))}
              </select>
              <select
                value={promoForm.changeType}
                onChange={(e) => setPromoForm({ ...promoForm, changeType: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="Promotion">Promotion</option>
                <option value="Transfer">Branch / Dept Transfer</option>
                <option value="Position">Position Reclassification</option>
              </select>
              <input
                type="date"
                value={promoForm.effectiveDate}
                onChange={(e) => setPromoForm({ ...promoForm, effectiveDate: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="text"
                value={promoForm.jobPosition}
                onChange={(e) => setPromoForm({ ...promoForm, jobPosition: e.target.value })}
                placeholder="New Job Title (optional)"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <select
                value={promoForm.branchId}
                onChange={(e) => setPromoForm({ ...promoForm, branchId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="">Keep Existing Branch</option>
                <option value="HQ">Head Office (No Branch)</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
            <input
              type="text"
              value={promoForm.notes}
              onChange={(e) => setPromoForm({ ...promoForm, notes: e.target.value })}
              placeholder="Official approval order / reason notes..."
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
            <button type="submit" className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold">
              Execute Promotion / Transfer
            </button>
          </form>
        </div>
      )}

      {/* Positions Directory & History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Active Job Positions ({positions.length})</h3>
          {loading ? (
            <p className="text-slate-400">Loading positions...</p>
          ) : positions.length === 0 ? (
            <p className="text-slate-400">No job positions defined yet.</p>
          ) : (
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {positions.map((p) => (
                <div key={p.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                  <div className="flex justify-between font-bold text-white">
                    <span>{p.title}</span>
                    <span className="font-mono text-amber-400">
                      {Number(p.min_salary || 0).toLocaleString()}–{Number(p.max_salary || 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {p.department_name || 'All Departments'} • {p.employment_type}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Position, Transfer &amp; Salary History ({history.length})</h3>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {history.length === 0 ? (
              <p className="text-slate-400">No career movement records yet.</p>
            ) : (
              history.map((h) => (
                <div key={h.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <div className="flex justify-between">
                    <span className="font-bold text-white">
                      {h.full_name} ({h.employee_code})
                    </span>
                    <span className="text-amber-400 font-semibold">{h.change_type}</span>
                  </div>
                  <div className="text-slate-300 mt-0.5">
                    {h.previous_value || 'Initial'} → {h.new_value}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Effective {h.effective_date} • By {h.changed_by_name}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// PERFORMANCE MANAGEMENT PANEL
// ============================================================================
export const PerformancePanel: React.FC<GovPanelProps> = ({ scope, employees, onNotify }) => {
  const [reviews, setReviews] = useState<any[]>([]);
  const [targets, setTargets] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [revForm, setRevForm] = useState({
    employeeId: '',
    reviewCycle: 'Monthly',
    period: new Date().toISOString().slice(0, 7),
    productivityScore: '90',
    workQualityScore: '92',
    attendanceScore: '95',
    taskCompletionScore: '91',
    visibility: 'EmployeeVisible',
    feedback: '',
    improvementPlan: '',
  });

  const [tgtForm, setTgtForm] = useState({
    employeeId: '',
    period: new Date().toISOString().slice(0, 7),
    title: '',
    metricName: 'EV Deliveries / Tickets Closed',
    targetValue: '100',
    achievedValue: '0',
    unit: '%',
  });

  const loadPerf = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtPerformance();
      setReviews(res.reviews || []);
      setTargets(res.targets || []);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load performance records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPerf();
  }, []);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createEmpMgmtReview({
        ...revForm,
        productivityScore: Number(revForm.productivityScore),
        workQualityScore: Number(revForm.workQualityScore),
        attendanceScore: Number(revForm.attendanceScore),
        taskCompletionScore: Number(revForm.taskCompletionScore),
      });
      onNotify('success', `Performance evaluation saved (${res.rating}/100).`);
      setRevForm((p) => ({ ...p, feedback: '', improvementPlan: '' }));
      loadPerf();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to submit evaluation.');
    }
  };

  const handleCreateTarget = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createEmpMgmtTarget({
        ...tgtForm,
        targetValue: Number(tgtForm.targetValue),
        achievedValue: Number(tgtForm.achievedValue),
      });
      onNotify('success', 'Employee target assigned.');
      setTgtForm((p) => ({ ...p, title: '' }));
      loadPerf();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to assign target.');
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-bold text-white">Performance Evaluations &amp; KPI Targets</h2>
        <p className="text-xs text-slate-400">Monthly, Quarterly &amp; Annual reviews plus employee target tracking (RBAC enforced).</p>
      </div>

      {scope.canEvaluatePerformance && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
          <form onSubmit={handleSubmitReview} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="font-bold text-amber-400 uppercase tracking-wider">Submit Manager Performance Evaluation</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <select
                required
                value={revForm.employeeId}
                onChange={(e) => setRevForm({ ...revForm, employeeId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white sm:col-span-2"
              >
                <option value="">Select Employee...</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.employeeCode} — {e.fullName}
                  </option>
                ))}
              </select>
              <select
                value={revForm.reviewCycle}
                onChange={(e) => setRevForm({ ...revForm, reviewCycle: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="Monthly">Monthly</option>
                <option value="Quarterly">Quarterly</option>
                <option value="Annual">Annual</option>
              </select>
              <input
                type="text"
                value={revForm.period}
                onChange={(e) => setRevForm({ ...revForm, period: e.target.value })}
                placeholder="Period (2026-Q2)"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                min="0"
                max="100"
                value={revForm.productivityScore}
                onChange={(e) => setRevForm({ ...revForm, productivityScore: e.target.value })}
                placeholder="Productivity /100"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                min="0"
                max="100"
                value={revForm.workQualityScore}
                onChange={(e) => setRevForm({ ...revForm, workQualityScore: e.target.value })}
                placeholder="Quality /100"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                min="0"
                max="100"
                value={revForm.attendanceScore}
                onChange={(e) => setRevForm({ ...revForm, attendanceScore: e.target.value })}
                placeholder="Attendance /100"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                min="0"
                max="100"
                value={revForm.taskCompletionScore}
                onChange={(e) => setRevForm({ ...revForm, taskCompletionScore: e.target.value })}
                placeholder="Tasks /100"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <select
                value={revForm.visibility}
                onChange={(e) => setRevForm({ ...revForm, visibility: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              >
                <option value="EmployeeVisible">EmployeeVisible</option>
                <option value="ManagerOnly">ManagerOnly</option>
              </select>
            </div>
            <input
              type="text"
              required
              value={revForm.feedback}
              onChange={(e) => setRevForm({ ...revForm, feedback: e.target.value })}
              placeholder="Manager evaluation feedback..."
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
            <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
              Submit Evaluation
            </button>
          </form>

          <form onSubmit={handleCreateTarget} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="font-bold text-amber-400 uppercase tracking-wider">Assign KPI Target</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <select
                required
                value={tgtForm.employeeId}
                onChange={(e) => setTgtForm({ ...tgtForm, employeeId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white sm:col-span-2"
              >
                <option value="">Select Employee...</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.employeeCode} — {e.fullName}
                  </option>
                ))}
              </select>
              <input
                type="text"
                required
                value={tgtForm.title}
                onChange={(e) => setTgtForm({ ...tgtForm, title: e.target.value })}
                placeholder="Target Objective Title"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white sm:col-span-2"
              />
              <input
                type="number"
                value={tgtForm.targetValue}
                onChange={(e) => setTgtForm({ ...tgtForm, targetValue: e.target.value })}
                placeholder="Target Value"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
              <input
                type="number"
                value={tgtForm.achievedValue}
                onChange={(e) => setTgtForm({ ...tgtForm, achievedValue: e.target.value })}
                placeholder="Initial Achieved"
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <button type="submit" className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold">
              Assign Target
            </button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Performance Reviews ({reviews.length})</h3>
          {loading ? (
            <p className="text-slate-400">Loading reviews...</p>
          ) : reviews.length === 0 ? (
            <p className="text-slate-400">No performance evaluations recorded.</p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {reviews.map((r) => (
                <div key={r.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex justify-between">
                    <span className="font-bold text-white">
                      {r.full_name} ({r.employee_code})
                    </span>
                    <span className="font-mono font-bold text-amber-400">{r.rating}/100</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {r.review_cycle || 'Monthly'} • {r.period} • Reviewer: {r.reviewer_name}
                  </div>
                  <p className="text-slate-300">{r.feedback}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Assigned Targets ({targets.length})</h3>
          {targets.length === 0 ? (
            <p className="text-slate-400">No KPI targets assigned.</p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {targets.map((t) => {
                const pct = t.target_value > 0 ? Math.min(100, Math.round((t.achieved_value / t.target_value) * 100)) : 0;
                return (
                  <div key={t.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="font-bold text-white">{t.title}</span>
                      <span className="font-mono tabular-nums text-amber-400">
                        {t.achieved_value}/{t.target_value} {t.unit} ({pct}%)
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div className="h-full bg-amber-500" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-400">
                      <span>
                        {t.full_name} • {t.period}
                      </span>
                      <span className={t.status === 'Achieved' ? 'text-emerald-400 font-semibold' : 'text-slate-300'}>{t.status}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// PRIVATE EMPLOYEE DOCUMENT VAULT PANEL
// ============================================================================
export const DocumentsPanel: React.FC<GovPanelProps> = ({ scope, employees, documentCategories, onNotify, onRefreshDashboard }) => {
  const [docs, setDocs] = useState<any[]>([]);
  const [catFilter, setCatFilter] = useState('ALL');
  const [loading, setLoading] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    employeeId: scope.selfEmployeeId || '',
    category: documentCategories[0] || 'CNIC',
    title: '',
    issueDate: '',
    expiryDate: '',
  });
  const [docFile, setDocFile] = useState<File | null>(null);
  const [previewDoc, setPreviewDoc] = useState<{ title: string; mime: string; url: string | null; text: string | null } | null>(null);

  const loadDocs = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtDocuments({ category: catFilter !== 'ALL' ? catFilter : undefined });
      setDocs(res.documents || []);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load private employee documents.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDocs();
  }, [catFilter]);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docFile) {
      onNotify('error', 'Select a document file (PDF, JPG, PNG, DOCX, max 5MB).');
      return;
    }
    try {
      const fd = new FormData();
      if (uploadForm.employeeId) fd.append('employeeId', uploadForm.employeeId);
      fd.append('category', uploadForm.category);
      fd.append('title', uploadForm.title || docFile.name);
      if (uploadForm.issueDate) fd.append('issueDate', uploadForm.issueDate);
      if (uploadForm.expiryDate) fd.append('expiryDate', uploadForm.expiryDate);
      fd.append('file', docFile);
      await api.uploadEmpMgmtDocument(fd);
      onNotify('success', 'Document securely stored in private HR vault.');
      setUploadForm((p) => ({ ...p, title: '', issueDate: '', expiryDate: '' }));
      setDocFile(null);
      loadDocs();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Document upload failed.');
    }
  };

  const handleDownload = async (d: any) => {
    try {
      const { blob, filename } = await api.downloadEmpMgmtBlob(`/api/employee-management/documents/${encodeURIComponent(d.id)}/download`);
      triggerBlobDownload(blob, filename || d.original_filename || 'document');
    } catch (err: any) {
      onNotify('error', err?.message || 'Protected document download denied.');
    }
  };

  const handlePreview = async (d: any) => {
    try {
      const { blob } = await api.downloadEmpMgmtBlob(`/api/employee-management/documents/${encodeURIComponent(d.id)}/download?inline=1`);
      const mime = String(d.mime_type || blob.type || '');
      if (mime.startsWith('text/')) {
        const text = await blob.text();
        setPreviewDoc({ title: `${d.title} (${d.original_filename})`, mime, url: null, text });
      } else {
        const url = URL.createObjectURL(blob);
        setPreviewDoc({ title: `${d.title} (${d.original_filename})`, mime, url, text: null });
      }
    } catch (err: any) {
      onNotify('error', err?.message || 'Protected document preview denied.');
    }
  };

  const closePreview = () => {
    if (previewDoc?.url) URL.revokeObjectURL(previewDoc.url);
    setPreviewDoc(null);
  };

  const handleVerify = async (id: string, status: 'Verified' | 'Rejected') => {
    try {
      await api.verifyEmpMgmtDocument(id, status);
      onNotify('success', `Document marked as ${status}.`);
      loadDocs();
    } catch (err: any) {
      onNotify('error', err?.message || 'Verification failed.');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Confidential Employee Document Vault</h2>
          <p className="text-xs text-slate-400">
            Zero public links. Every download &amp; preview runs server-side RBAC authorization checks.
          </p>
        </div>
        <select
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-xs text-white"
        >
          <option value="ALL">All Categories</option>
          {documentCategories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <form onSubmit={handleUpload} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
        <div className="font-bold text-amber-400 uppercase tracking-wider">Upload Protected Employee Document</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {!scope.selfOnly && (
            <select
              required
              value={uploadForm.employeeId}
              onChange={(e) => setUploadForm({ ...uploadForm, employeeId: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            >
              <option value="">Select Employee...</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.employeeCode} — {e.fullName}
                </option>
              ))}
            </select>
          )}
          <select
            value={uploadForm.category}
            onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value })}
            className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          >
            {documentCategories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <input
            type="text"
            required
            value={uploadForm.title}
            onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
            placeholder="Document Title"
            className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          />
          <input
            type="date"
            value={uploadForm.issueDate}
            onChange={(e) => setUploadForm({ ...uploadForm, issueDate: e.target.value })}
            title="Issue Date (Optional)"
            className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          />
          <input
            type="date"
            value={uploadForm.expiryDate}
            onChange={(e) => setUploadForm({ ...uploadForm, expiryDate: e.target.value })}
            title="Expiry Date (Optional)"
            className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          />
          <input
            type="file"
            required
            onChange={(e) => setDocFile(e.target.files?.[0] || null)}
            className="rounded-lg bg-slate-950 border border-slate-800 px-2 py-1.5 text-slate-300 file:mr-2 file:rounded file:border-0 file:bg-slate-800 file:px-2 file:py-1 file:text-xs file:text-white"
          />
        </div>
        <div className="flex justify-end">
          <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
            Upload to Private Vault
          </button>
        </div>
      </form>

      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
            <tr>
              <th className="py-2.5 px-3">Employee</th>
              <th className="py-2.5 px-3">Category &amp; Title</th>
              <th className="py-2.5 px-3">File Info</th>
              <th className="py-2.5 px-3">Expiry</th>
              <th className="py-2.5 px-3">Verification</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  Loading encrypted vault index...
                </td>
              </tr>
            ) : docs.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  No documents stored yet.
                </td>
              </tr>
            ) : (
              docs.map((d) => (
                <tr key={d.id} className="hover:bg-slate-950/60">
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white">{d.full_name}</div>
                    <div className="text-[11px] font-mono text-amber-400">{d.employee_code}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-200">{d.title}</div>
                    <div className="text-[11px] text-slate-400">{d.category}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-mono text-[11px]">
                    {d.original_filename} ({Math.max(1, Math.round((d.size_bytes || 0) / 1024))} KB)
                  </td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-slate-300">{d.expiry_date || '—'}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`font-semibold ${
                        d.verification_status === 'Verified'
                          ? 'text-emerald-400'
                          : d.verification_status === 'Rejected'
                          ? 'text-rose-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {d.verification_status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="inline-flex gap-1.5">
                      {scope.canVerifyDocuments && d.verification_status !== 'Verified' && (
                        <button
                          type="button"
                          onClick={() => handleVerify(d.id, 'Verified')}
                          className="px-2 py-1 rounded bg-emerald-600 text-white font-semibold"
                        >
                          Verify
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handlePreview(d)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" /> Preview
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownload(d)}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white font-semibold inline-flex items-center gap-1"
                      >
                        <Download className="w-3 h-3" /> Download
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 flex items-center justify-center p-4">
          <div className="w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-700 p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="text-sm font-bold text-white truncate">{previewDoc.title}</div>
              <button type="button" onClick={closePreview} className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-[72vh] overflow-auto rounded-xl bg-slate-950 border border-slate-800 p-3">
              {previewDoc.text !== null ? (
                <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap">{previewDoc.text}</pre>
              ) : previewDoc.mime.startsWith('image/') && previewDoc.url ? (
                <img src={previewDoc.url} alt={previewDoc.title} className="max-h-[65vh] mx-auto rounded-lg object-contain" />
              ) : previewDoc.mime === 'application/pdf' && previewDoc.url ? (
                <iframe src={previewDoc.url} title={previewDoc.title} className="w-full h-[65vh] rounded-lg bg-white" />
              ) : (
                <p className="text-xs text-slate-400 py-8 text-center">
                  Inline browser preview is unavailable for {previewDoc.mime || 'this file type'}. Use Download to open securely.
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// REPORTS & EXPORTS PANEL
// ============================================================================
const REPORT_TYPES = [
  { id: 'total-employees', label: 'Total Employee Report' },
  { id: 'attendance', label: 'Attendance Report' },
  { id: 'monthly-payroll', label: 'Monthly Payroll Report' },
  { id: 'salary-history', label: 'Salary History Report' },
  { id: 'leaves', label: 'Leave Report' },
  { id: 'department-wise', label: 'Department-Wise Employee Report' },
  { id: 'branch-wise', label: 'Branch-Wise Employee Report' },
  { id: 'performance', label: 'Performance Report' },
  { id: 'document-expiry', label: 'Document Expiry Report' },
];

export const EmployeeReportsPanel: React.FC<{ scope: any; onNotify: (t: 'success' | 'error', m: string) => void }> = ({ scope, onNotify }) => {
  const [reportType, setReportType] = useState('total-employees');
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [report, setReport] = useState<{ title: string; rows: any[] }>({ title: 'Total Employee Report', rows: [] });
  const [loading, setLoading] = useState(false);

  const loadReport = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtReports(reportType, month);
      setReport({ title: res.title, rows: res.rows || [] });
    } catch (err: any) {
      onNotify('error', err?.message || 'Report generation failed.');
      setReport({ title: 'Report Restricted', rows: [] });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [reportType, month]);

  const handleExport = async (format: 'xlsx' | 'pdf' | 'csv') => {
    try {
      const url = api.getEmpMgmtReportExportUrl(reportType, format, month);
      const { blob, filename } = await api.downloadEmpMgmtBlob(url);
      triggerBlobDownload(blob, filename || `BYD360_${reportType}_${month}.${format}`);
      onNotify('success', `Exported ${report.title} as ${format.toUpperCase()}.`);
    } catch (err: any) {
      onNotify('error', err?.message || 'Report export failed.');
    }
  };

  const cols = report.rows.length > 0 ? Object.keys(report.rows[0]) : [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Employee Reports &amp; Exports</h2>
          <p className="text-xs text-slate-400">Real SQLite datasets exportable to Excel (.xlsx), PDF, and CSV.</p>
        </div>
        {scope.canExportReports && (
          <div className="flex flex-wrap gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleExport('xlsx')}
              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold inline-flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel (.xlsx)
            </button>
            <button
              type="button"
              onClick={() => handleExport('pdf')}
              className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold inline-flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" /> Export PDF
            </button>
            <button
              type="button"
              onClick={() => handleExport('csv')}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" /> CSV
            </button>
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs">
        <select
          value={reportType}
          onChange={(e) => setReportType(e.target.value)}
          className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white"
        >
          {REPORT_TYPES.map((rt) => (
            <option key={rt.id} value={rt.id}>
              {rt.label}
            </option>
          ))}
        </select>
        <input
          type="month"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
          className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white"
        />
        <span className="text-slate-400 font-mono">Rows: {report.rows.length}</span>
      </div>

      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
            <tr>
              {cols.length === 0 ? (
                <th className="py-2.5 px-3">Report Preview</th>
              ) : (
                cols.map((c) => (
                  <th key={c} className="py-2.5 px-3 whitespace-nowrap">
                    {c}
                  </th>
                ))
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {loading ? (
              <tr>
                <td colSpan={Math.max(1, cols.length)} className="py-8 text-center text-slate-400">
                  Compiling database report...
                </td>
              </tr>
            ) : report.rows.length === 0 ? (
              <tr>
                <td colSpan={Math.max(1, cols.length)} className="py-8 text-center text-slate-400">
                  No matching rows for this report and month.
                </td>
              </tr>
            ) : (
              report.rows.slice(0, 100).map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-950/60">
                  {cols.map((c) => (
                    <td key={c} className="py-2 px-3 text-slate-200 whitespace-nowrap font-mono tabular-nums">
                      {String(row[c] ?? '—')}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// SETTINGS & IMMUTABLE AUDIT LOGS PANEL
// ============================================================================
export const EmployeeSettingsPanel: React.FC<{ onNotify: (t: 'success' | 'error', m: string) => void }> = ({ onNotify }) => {
  const [settings, setSettings] = useState<any>(null);
  const [canEdit, setCanEdit] = useState(false);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  const loadSettings = async () => {
    try {
      const [sRes, lRes] = await Promise.all([api.getEmpMgmtSettings(), api.getEmpMgmtAuditLogs()]);
      setSettings(sRes.settings);
      setCanEdit(sRes.canEdit);
      setAuditLogs(lRes.logs || []);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load settings.');
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      await api.updateEmpMgmtSettings({
        companyId: settings.company_id,
        employeeIdPrefix: settings.employee_id_prefix,
        workStartTime: settings.work_start_time,
        workEndTime: settings.work_end_time,
        lateGraceMinutes: Number(settings.late_grace_minutes),
        annualLeaveDefault: Number(settings.annual_leave_default),
        sickLeaveDefault: Number(settings.sick_leave_default),
        casualLeaveDefault: Number(settings.casual_leave_default),
        overtimeHourlyRate: Number(settings.overtime_hourly_rate),
      });
      onNotify('success', 'Employee module policy rules updated.');
      loadSettings();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to save module settings.');
    }
  };

  if (!settings) {
    return <div className="py-8 text-center text-xs text-slate-400">Loading module configuration...</div>;
  }

  return (
    <div className="space-y-5 text-xs">
      <div>
        <h2 className="text-lg font-bold text-white">HR Module Settings &amp; Immutable Audit Trail</h2>
        <p className="text-slate-400">Shift timings, default leave quotas, overtime hourly rates &amp; tamper-proof action logs.</p>
      </div>

      <form onSubmit={handleSave} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="block text-slate-400 mb-1">Employee ID Prefix</label>
            <input
              type="text"
              disabled={!canEdit}
              value={settings.employee_id_prefix || 'BYD-PAK-EMP-'}
              onChange={(e) => setSettings({ ...settings, employee_id_prefix: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Shift Start Time</label>
            <input
              type="time"
              disabled={!canEdit}
              value={settings.work_start_time || '09:00'}
              onChange={(e) => setSettings({ ...settings, work_start_time: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Shift End Time</label>
            <input
              type="time"
              disabled={!canEdit}
              value={settings.work_end_time || '18:00'}
              onChange={(e) => setSettings({ ...settings, work_end_time: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Overtime Hourly Rate (PKR)</label>
            <input
              type="number"
              disabled={!canEdit}
              value={settings.overtime_hourly_rate ?? 1200}
              onChange={(e) => setSettings({ ...settings, overtime_hourly_rate: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Annual Leave Quota</label>
            <input
              type="number"
              disabled={!canEdit}
              value={settings.annual_leave_default ?? 18}
              onChange={(e) => setSettings({ ...settings, annual_leave_default: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Sick Leave Quota</label>
            <input
              type="number"
              disabled={!canEdit}
              value={settings.sick_leave_default ?? 10}
              onChange={(e) => setSettings({ ...settings, sick_leave_default: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Casual Leave Quota</label>
            <input
              type="number"
              disabled={!canEdit}
              value={settings.casual_leave_default ?? 8}
              onChange={(e) => setSettings({ ...settings, casual_leave_default: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Late Grace Minutes</label>
            <input
              type="number"
              disabled={!canEdit}
              value={settings.late_grace_minutes ?? 15}
              onChange={(e) => setSettings({ ...settings, late_grace_minutes: e.target.value })}
              className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
            />
          </div>
        </div>
        {canEdit && (
          <div className="flex justify-end">
            <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
              Save HR Module Settings
            </button>
          </div>
        )}
      </form>

      <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
        <h3 className="text-sm font-bold text-white">Immutable Employee Audit Logs ({auditLogs.length})</h3>
        <div className="space-y-1.5 max-h-80 overflow-y-auto">
          {auditLogs.map((l) => (
            <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-wrap justify-between gap-2">
              <div>
                <span className="font-mono font-bold text-amber-400 mr-2">{l.action}</span>
                <span className="text-slate-200">{l.details}</span>
              </div>
              <span className="font-mono text-[11px] text-slate-500">
                {l.actor_name} ({l.actor_role}) • {String(l.created_at).slice(0, 19).replace('T', ' ')}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
