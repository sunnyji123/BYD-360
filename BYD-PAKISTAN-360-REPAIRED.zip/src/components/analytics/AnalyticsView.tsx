import React, { useState } from 'react';
import {
  BarChart2,
  TrendingUp,
  Download,
  Calendar,
  FileSpreadsheet,
  Activity,
  Zap,
  Clock,
  Award,
  Layers,
  ArrowUpRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';

export const AnalyticsView: React.FC = () => {
  const { cityFilter } = useApp();
  const [timeRange, setTimeRange] = useState('2026 Year-to-Date');

  const monthlySalesData = [
    { month: 'Jan', units: 62, revenuePkr: 890 },
    { month: 'Feb', units: 85, revenuePkr: 1220 },
    { month: 'Mar', units: 110, revenuePkr: 1580 },
    { month: 'Apr', units: 145, revenuePkr: 2090 },
    { month: 'May', units: 180, revenuePkr: 2610 },
    { month: 'Jun', units: 215, revenuePkr: 3100 },
    { month: 'Jul', units: 260, revenuePkr: 3750 },
    { month: 'Aug', units: 310, revenuePkr: 4490 },
    { month: 'Sep', units: 370, revenuePkr: 5350 },
    { month: 'Oct', units: 440, revenuePkr: 6380 },
    { month: 'Nov', units: 480, revenuePkr: 6960 },
  ];

  const cityDemandData = [
    { city: 'Karachi (Sindh)', share: 44, units: 563, revM: 8140 },
    { city: 'Lahore (Punjab)', share: 34, units: 435, revM: 6310 },
    { city: 'Islamabad / Rawalpindi', share: 14, units: 179, revM: 2600 },
    { city: 'Faisalabad', share: 5, units: 64, revM: 928 },
    { city: 'Multan & Peshawar', share: 3, units: 39, revM: 565 },
  ];

  const handleExportCSV = () => {
    const rows = [
      ['Month', 'Delivered Units', 'Revenue (Million PKR)'],
      ...monthlySalesData.map((d) => [d.month, d.units, d.revenuePkr]),
      [],
      ['City', 'Market Share %', 'Delivered Units', 'Total Revenue (Million PKR)'],
      ...cityDemandData.map((c) => [c.city, `${c.share}%`, c.units, c.revM]),
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `BYD_Pakistan_Automotive_Analytics_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPDF = () => {
    window.print();
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Strategic Intelligence</span>
          <h2 className="text-2xl font-black text-white">Enterprise Analytics & Automotive Metrics</h2>
          <p className="text-xs text-slate-400">
            Market penetration, Blade Battery health distributions, workshop turnaround & charging throughput
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-xs text-white"
          >
            <option value="2026 Year-to-Date">2026 Year-to-Date</option>
            <option value="Q4 2026 (Oct - Dec)">Q4 2026 (Oct - Dec)</option>
            <option value="Last 30 Days">Last 30 Days</option>
          </select>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-950 text-slate-300 hover:text-white text-xs font-semibold"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handlePrintPDF}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Print Report (PDF)</span>
          </button>
        </div>
      </div>

      {/* Monthly Sales & Delivery Growth Chart */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>Monthly EV Delivery Growth (Pakistan Nationwide)</span>
            </h4>
            <p className="text-xs text-slate-400">Cumulative delivery volume across Mega Motor 3S dealerships</p>
          </div>
          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+674% Growth YoY</span>
          </span>
        </div>

        {/* Visual Bar Chart */}
        <div className="h-56 flex items-end justify-between gap-2 pt-6 px-2 border-b border-slate-800">
          {monthlySalesData.map((d) => {
            const heightPercent = Math.round((d.units / 500) * 100);
            return (
              <div key={d.month} className="flex-1 flex flex-col items-center gap-2 group">
                <span className="text-[10px] font-bold text-cyan-300 opacity-0 group-hover:opacity-100 transition">
                  {d.units}
                </span>
                <div
                  className="w-full max-w-[36px] bg-gradient-to-t from-blue-600 to-cyan-400 rounded-t-lg transition-all duration-300 group-hover:from-blue-500 group-hover:to-cyan-300"
                  style={{ height: `${heightPercent}%` }}
                />
                <span className="text-[10px] text-slate-400 font-semibold">{d.month}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* City-Wise Market Share & Fleet Retention */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* City Breakdown */}
        <div className="lg:col-span-7 rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
          <h4 className="text-sm font-bold text-white">City-Wise Fleet Distribution & Demand</h4>
          <div className="space-y-3">
            {cityDemandData.map((city) => (
              <div key={city.city} className="space-y-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-white">{city.city}</span>
                  <span className="text-cyan-300">{city.units} Units ({city.share}%)</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-600 h-full rounded-full"
                    style={{ width: `${city.share}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Operational Efficiency Metrics */}
        <div className="lg:col-span-5 rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
          <h4 className="text-sm font-bold text-white">Operational Service Benchmarks</h4>
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-slate-400">Mean Service Turnaround:</span>
                <p className="font-bold text-white text-sm">3.2 Hours</p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                Industry Best
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-slate-400">Complaint Resolution SLA:</span>
                <p className="font-bold text-white text-sm">94.2% within 24h</p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                Optimal
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-slate-400">Blade Battery Retention (100k km):</span>
                <p className="font-bold text-white text-sm">96.8% SoH</p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-950 text-purple-400 border border-purple-800">
                Zero Outliers
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
