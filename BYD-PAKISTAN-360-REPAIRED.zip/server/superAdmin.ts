import express, { Request, Response } from 'express';
import {
  sqlite,
  hashPassword,
  generateSecureToken,
  generateNumericOtp,
  validatePasswordStrength,
  logAdminActivity,
  logSecurityEvent,
  getSystemSetting,
  setSystemSetting,
  nowIso,
} from './db';
import {
  requireSuperAdmin,
  requirePermission,
  getClientIp,
} from './auth';

const ALLOWED_NON_ADMIN_ROLES = [
  'Company Admin',
  'Head Office Staff',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Finance Manager',
  'Service Manager',
  'Technical Support',
  'Customer',
];

function recordSaAction(req: Request, action: string, module: string, targetId?: string | null, details?: string | null, status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS') {
  if (!req.auth) return;
  logAdminActivity({
    adminId: req.auth.userId,
    adminName: req.auth.fullName,
    adminRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
    userAgent: String(req.headers['user-agent'] || ''),
    sessionId: req.auth.sessionId || null,
  });
}

function rejectFounderOrAdminManipulation(req: Request, res: Response, reason: string, targetId?: string) {
  const ip = getClientIp(req);
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'FOUNDER_PROTECTION_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    details: reason,
    ipAddress: ip,
  });
  recordSaAction(req, 'PRIVILEGE_ESCALATION_BLOCKED', 'Security Protection', targetId || null, reason, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Super Admins cannot view, create, modify, suspend, or escalate Founder / Owner or fellow Super Admin accounts.',
  });
}

export function createSuperAdminRouter() {
  const router = express.Router();

  // Enforce verified Super Admin (or Founder) authentication on every route
  router.use(requireSuperAdmin);

  // =========================================================================
  // 1. REAL-TIME SUPER ADMIN EXECUTIVE DASHBOARD (14 Metrics + Feeds)
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    const totalRegisteredUsers = (
      sqlite.prepare("SELECT COUNT(*) as c FROM user_accounts WHERE subject_type != 'founder'").get() as any
    ).c || (sqlite.prepare('SELECT COUNT(*) as c FROM users').get() as any).c;
    const totalCompanies = (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c;
    const totalBranches = (sqlite.prepare('SELECT COUNT(*) as c FROM branches').get() as any).c;
    const totalEmployees = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c;
    const totalDealerships = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE status = 'Approved'").get() as any).c;
    const totalCustomers = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts').get() as any).c;
    const totalVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles').get() as any).c;
    const totalVehicleSales = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE sold_at IS NOT NULL').get() as any).c;
    const totalBookings = (sqlite.prepare('SELECT COUNT(*) as c FROM bookings').get() as any).c;

    const revRow = sqlite
      .prepare("SELECT COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal, COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal FROM payments_invoices")
      .get() as any;

    const pendingDealers = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE status = 'Pending Approval'").get() as any).c;
    const pendingDealerAccounts = (sqlite.prepare("SELECT COUNT(*) as c FROM dealer_accounts WHERE verification_status IN ('Pending Verification', 'Under Review')").get() as any).c;
    const pendingKyc = (sqlite.prepare("SELECT COUNT(*) as c FROM identity_verification_records WHERE verification_status IN ('Pending Verification', 'Under Review')").get() as any).c;
    const pendingCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Pending Approval'").get() as any).c;
    const pendingUsers = (sqlite.prepare("SELECT COUNT(*) as c FROM users WHERE status = 'Pending Verification'").get() as any).c;
    const openSupport = (sqlite.prepare("SELECT COUNT(*) as c FROM support_requests WHERE status IN ('Open', 'In Progress')").get() as any).c;
    const pendingApprovals = pendingDealers + pendingDealerAccounts + pendingKyc + pendingCompanies + pendingUsers;

    const systemNotifications = (sqlite.prepare('SELECT COUNT(*) as c FROM notifications').get() as any).c;
    const recentActivitiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM admin_activity_logs').get() as any).c;
    const securityAlerts = (sqlite
      .prepare("SELECT COUNT(*) as c FROM security_events WHERE acknowledged = 0 AND event_type NOT LIKE '%FOUNDER%'")
      .get() as any).c;

    const recentActivitiesList = sqlite
      .prepare('SELECT * FROM admin_activity_logs ORDER BY created_at DESC LIMIT 15')
      .all();
    const recentSecurityAlerts = sqlite
      .prepare("SELECT * FROM security_events WHERE event_type NOT LIKE '%FOUNDER%' ORDER BY created_at DESC LIMIT 10")
      .all();
    const recentNotifications = sqlite
      .prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10')
      .all();
    const pendingDealershipList = sqlite
      .prepare("SELECT d.*, c.name as company_name FROM dealerships d LEFT JOIN companies c ON c.id = d.company_id WHERE d.status = 'Pending Approval' ORDER BY d.created_at DESC")
      .all();

    res.json({
      actor: {
        id: req.auth!.userId,
        fullName: req.auth!.fullName,
        email: req.auth!.email,
        role: req.auth!.role,
        permissions: req.auth!.permissions,
      },
      metrics: {
        totalRegisteredUsers,
        totalCompanies,
        totalBranches,
        totalEmployees,
        totalDealerships,
        totalCustomers,
        totalVehicles,
        totalVehicleSales,
        totalBookings,
        totalRevenue: revRow.paidTotal,
        pendingRevenue: revRow.pendingTotal,
        pendingApprovals,
        openSupportRequests: openSupport,
        systemNotifications,
        recentActivities: recentActivitiesCount,
        securityAlerts,
      },
      pendingDealerships: pendingDealershipList,
      recentActivitiesList,
      recentSecurityAlerts,
      recentNotifications,
    });
  });

  // =========================================================================
  // 2. COMPANIES OVERVIEW & OPERATIONAL METADATA UPDATES
  // =========================================================================
  router.get('/companies', requirePermission('users.view'), (_req: Request, res: Response) => {
    const companies = sqlite
      .prepare(`
        SELECT c.id, c.name, c.country, c.city, c.official_email, c.phone, c.address,
               c.registration_details, c.authorized_rep, c.status, c.approved_by, c.approved_at, c.created_at,
               (SELECT COUNT(*) FROM dealerships d WHERE d.company_id = c.id) as branch_count,
               (SELECT COUNT(*) FROM users u WHERE u.company_id = c.id AND u.role != 'Customer') as employee_count,
               (SELECT COUNT(*) FROM vehicles v WHERE v.company_id = c.id) as vehicle_count
        FROM companies c
        ORDER BY c.created_at DESC
      `)
      .all();
    res.json({ companies });
  });

  router.patch('/companies/:id', requirePermission('users.update'), (req: Request, res: Response) => {
    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(req.params.id) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company not found.' });
      return;
    }

    // Company approval/suspension governance belongs exclusively to the Primary Owner
    if (req.body.status && req.body.status !== comp.status && req.auth!.subjectType !== 'founder') {
      res.status(403).json({
        error: 'Company approval and workspace suspension status are reserved exclusively for the Primary Owner (Founder).',
      });
      return;
    }

    const phone = String(req.body.phone || comp.phone).trim();
    const city = String(req.body.city || comp.city).trim();
    const address = String(req.body.address || comp.address).trim();
    const authorizedRep = String(req.body.authorizedRep || comp.authorized_rep).trim();

    sqlite
      .prepare('UPDATE companies SET phone = ?, city = ?, address = ?, authorized_rep = ? WHERE id = ?')
      .run(phone, city, address, authorizedRep, comp.id);

    recordSaAction(req, 'COMPANY_DETAILS_UPDATED', 'Company Operations', comp.id, `Updated contact/city info for ${comp.name}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 3. DEALERSHIPS & BRANCHES + PENDING DEALER APPROVALS
  // =========================================================================
  router.get('/dealerships', requirePermission('dealers.manage'), (_req: Request, res: Response) => {
    const dealerships = sqlite
      .prepare(`
        SELECT d.*, c.name as company_name
        FROM dealerships d
        LEFT JOIN companies c ON c.id = d.company_id
        ORDER BY
          CASE WHEN d.status = 'Pending Approval' THEN 0 ELSE 1 END,
          d.created_at DESC
      `)
      .all();
    res.json({ dealerships });
  });

  router.post('/dealerships', requirePermission('dealers.manage'), (req: Request, res: Response) => {
    const companyId = String(req.body.companyId || 'comp_byd_pk').trim();
    const name = String(req.body.name || '').trim();
    const code = String(req.body.code || '').trim().toUpperCase();
    const country = String(req.body.country || 'PK').trim();
    const city = String(req.body.city || 'Karachi').trim();
    const address = String(req.body.address || '').trim();
    const managerName = String(req.body.managerName || '').trim();
    const phone = String(req.body.phone || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const facilityType = String(req.body.facilityType || '3S Flagship Centre').trim();
    const status = ['Approved', 'Pending Approval'].includes(String(req.body.status))
      ? String(req.body.status)
      : 'Approved';

    if (!name || !code || !city || !address || !managerName || !phone || !email) {
      res.status(400).json({ error: 'All dealership fields (name, code, city, address, manager, phone, email) are required.' });
      return;
    }

    const comp = sqlite.prepare('SELECT id FROM companies WHERE id = ?').get(companyId);
    if (!comp) {
      res.status(404).json({ error: 'Selected parent company not found.' });
      return;
    }

    const id = `dlr_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO dealerships (
          id, company_id, name, code, country, city, address, manager_name, phone, email,
          facility_type, status, active_techs, service_bays, monthly_target_units,
          achieved_units, monthly_revenue_pkr, rating, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 4.8, ?)
      `)
      .run(
        id,
        companyId,
        name,
        code,
        country,
        city,
        address,
        managerName,
        phone,
        email,
        facilityType,
        status,
        Number(req.body.activeTechs || 8),
        Number(req.body.serviceBays || 6),
        Number(req.body.monthlyTargetUnits || 30),
        now
      );

    recordSaAction(req, 'DEALERSHIP_CREATED', 'Dealer & Branch Management', `${name} (${code})`, `Status: ${status}, City: ${city}`);
    res.status(201).json({ success: true, id });
  });

  router.patch('/dealerships/:id/status', requirePermission('dealers.manage'), (req: Request, res: Response) => {
    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership / branch not found.' });
      return;
    }

    const decision = String(req.body.status || '');
    if (!['Approved', 'Pending Approval', 'Rejected', 'Suspended'].includes(decision)) {
      res.status(400).json({ error: 'Invalid dealership status.' });
      return;
    }

    sqlite.prepare('UPDATE dealerships SET status = ? WHERE id = ?').run(decision, dlr.id);

    recordSaAction(
      req,
      `DEALER_${decision.toUpperCase().replace(/\s+/g, '_')}`,
      'Dealer Approvals',
      `${dlr.name} (${dlr.code})`,
      `Changed dealership status from ${dlr.status} to ${decision}`
    );

    res.json({ success: true, id: dlr.id, status: decision });
  });

  // =========================================================================
  // 4. USER / EMPLOYEE / DEALER / CUSTOMER MANAGEMENT (NON-ADMIN ONLY)
  // =========================================================================
  router.get('/users', requirePermission('users.view'), (req: Request, res: Response) => {
    const category = String(req.query.category || 'all');
    let where = "WHERE u.role NOT IN ('Founder / Owner', 'Super Admin')";
    if (category === 'employees') {
      where += " AND u.role NOT IN ('Customer', 'Dealership Manager', 'Dealership Staff')";
    } else if (category === 'dealers') {
      where += " AND u.role IN ('Dealership Manager', 'Dealership Staff')";
    } else if (category === 'customers') {
      where += " AND u.role = 'Customer'";
    }

    const users = sqlite
      .prepare(`
        SELECT u.id, u.company_id, u.username, u.full_name, u.email, u.mobile, u.role,
               u.country, u.city, u.dealership_id, u.status, u.email_verified,
               u.mobile_verified, u.last_login_at, u.created_at,
               c.name as company_name
        FROM users u
        LEFT JOIN companies c ON c.id = u.company_id
        ${where}
        ORDER BY u.created_at DESC
      `)
      .all();

    res.json({ users });
  });

  router.post('/users', requirePermission('users.create'), (req: Request, res: Response) => {
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const role = String(req.body.role || 'Customer').trim();
    const companyId = req.body.companyId ? String(req.body.companyId) : 'comp_byd_pk';
    const dealershipId = req.body.dealershipId ? String(req.body.dealershipId) : null;
    const country = String(req.body.country || 'PK').trim();
    const city = String(req.body.city || 'Karachi').trim();

    // STRICT FOUNDER & SUPER ADMIN PROTECTION
    if (role === 'Founder / Owner' || role === 'Super Admin') {
      rejectFounderOrAdminManipulation(
        req,
        res,
        `Attempted to create privileged "${role}" account (${email}) from Super Admin workspace.`
      );
      return;
    }

    if (!ALLOWED_NON_ADMIN_ROLES.includes(role)) {
      res.status(400).json({ error: `Unsupported operational role "${role}".` });
      return;
    }

    if (role === 'Customer' && !req.auth!.permissions.includes('customers.manage') && req.auth!.subjectType !== 'founder') {
      res.status(403).json({ error: 'Permission denied: requires customers.manage to create customer accounts.' });
      return;
    }
    if (role !== 'Customer' && !['Dealership Manager', 'Dealership Staff'].includes(role) && !req.auth!.permissions.includes('employees.manage') && req.auth!.subjectType !== 'founder') {
      res.status(403).json({ error: 'Permission denied: requires employees.manage to create employee accounts.' });
      return;
    }
    if (['Dealership Manager', 'Dealership Staff'].includes(role) && !req.auth!.permissions.includes('dealers.manage') && req.auth!.subjectType !== 'founder') {
      res.status(403).json({ error: 'Permission denied: requires dealers.manage to create dealer accounts.' });
      return;
    }

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Full name, email, and mobile number are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const id = `usr_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, username, full_name, email, mobile, password_hash, role,
          country, city, dealership_id, status, email_verified, mobile_verified,
          created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, ?, ?, ?)
      `)
      .run(
        id,
        companyId,
        email.split('@')[0] + '_' + generateNumericOtp(3),
        fullName,
        email,
        mobile,
        hashPassword(password),
        role,
        country,
        city,
        dealershipId,
        req.auth!.userId,
        now,
        now
      );

    recordSaAction(req, 'USER_CREATED', 'User & Role Management', `${fullName} (${email})`, `Role: ${role}, Company: ${companyId}`);
    res.status(201).json({ success: true, id, role });
  });

  router.patch('/users/:id', (req: Request, res: Response) => {
    const targetId = String(req.params.id);

    // STRICT FOUNDER & SUPER ADMIN PROTECTION
    const isFounderTarget = sqlite.prepare('SELECT id FROM founder_accounts WHERE id = ?').get(targetId);
    if (isFounderTarget || targetId === 'founder_intekhab_alam') {
      rejectFounderOrAdminManipulation(req, res, `Attempted to modify Primary Owner account (${targetId}).`, targetId);
      return;
    }
    const isSaTarget = sqlite.prepare('SELECT id, email FROM super_admin_accounts WHERE id = ?').get(targetId) as any;
    if (isSaTarget) {
      rejectFounderOrAdminManipulation(req, res, `Attempted to modify Super Admin account (${isSaTarget.email}) from non-Founder endpoint.`, targetId);
      return;
    }
    const isCaTarget = sqlite.prepare('SELECT id, email FROM company_admin_accounts WHERE id = ?').get(targetId) as any;
    if (isCaTarget) {
      rejectFounderOrAdminManipulation(req, res, `Attempted to modify isolated Company Admin account (${isCaTarget.email}) from non-Founder endpoint.`, targetId);
      return;
    }
    const isCmTarget = sqlite.prepare('SELECT id, email FROM country_manager_accounts WHERE id = ?').get(targetId) as any;
    if (isCmTarget) {
      rejectFounderOrAdminManipulation(req, res, `Attempted to modify isolated Country Manager account (${isCmTarget.email}) from non-Founder endpoint.`, targetId);
      return;
    }

    const user = sqlite.prepare('SELECT * FROM users WHERE id = ?').get(targetId) as any;
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }

    if (user.role === 'Founder / Owner' || user.role === 'Super Admin') {
      rejectFounderOrAdminManipulation(req, res, `Attempted to alter protected "${user.role}" account (${user.email}).`, targetId);
      return;
    }

    const nextRole = req.body.role ? String(req.body.role).trim() : user.role;
    if (nextRole === 'Founder / Owner' || nextRole === 'Super Admin') {
      rejectFounderOrAdminManipulation(req, res, `Attempted role escalation of "${user.email}" to "${nextRole}".`, targetId);
      return;
    }
    if (!ALLOWED_NON_ADMIN_ROLES.includes(nextRole)) {
      res.status(400).json({ error: `Invalid operational role "${nextRole}".` });
      return;
    }

    // Check granular permissions cleanly based on requested mutations
    const isStatusChange = typeof req.body.status === 'string' && req.body.status !== user.status;
    if (isStatusChange && req.auth!.subjectType !== 'founder' && !req.auth!.permissions.includes('users.suspend')) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'PERMISSION_DENIED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        details: `Super Admin denied users.suspend while changing status on ${user.email}`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Permission denied: lacks "users.suspend" permission.' });
      return;
    }

    if (!isStatusChange && req.auth!.subjectType !== 'founder' && !req.auth!.permissions.includes('users.update')) {
      res.status(403).json({ error: 'Permission denied: lacks "users.update" permission.' });
      return;
    }

    const nextStatus = req.body.status && ['Active', 'Suspended', 'Pending Verification'].includes(String(req.body.status))
      ? String(req.body.status)
      : user.status;
    const nextEmailVerified = typeof req.body.emailVerified === 'boolean' ? (req.body.emailVerified ? 1 : 0) : user.email_verified;
    const nextFullName = req.body.fullName ? String(req.body.fullName).trim() : user.full_name;
    const nextCity = req.body.city ? String(req.body.city).trim() : user.city;
    const nextMobile = req.body.mobile ? String(req.body.mobile).trim() : user.mobile;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE users
        SET full_name = ?, mobile = ?, role = ?, city = ?, status = ?, email_verified = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(nextFullName, nextMobile, nextRole, nextCity, nextStatus, nextEmailVerified, now, user.id);

    if (nextStatus === 'Suspended') {
      sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(user.id);
    }

    const actionName = isStatusChange
      ? nextStatus === 'Suspended'
        ? 'USER_SUSPENDED'
        : 'USER_STATUS_UPDATED'
      : 'USER_UPDATED';

    recordSaAction(req, actionName, 'User & Role Management', user.email, `Role: ${nextRole}, Status: ${nextStatus}, EmailVerified: ${Boolean(nextEmailVerified)}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 5. VEHICLE INVENTORY MANAGEMENT
  // =========================================================================
  router.get('/vehicles', requirePermission('vehicles.manage'), (_req: Request, res: Response) => {
    const vehicles = sqlite
      .prepare(`
        SELECT v.*, c.name as company_name
        FROM vehicles v
        LEFT JOIN companies c ON c.id = v.company_id
        ORDER BY v.created_at DESC
      `)
      .all();
    res.json({ vehicles });
  });

  router.post('/vehicles', requirePermission('vehicles.manage'), (req: Request, res: Response) => {
    const companyId = String(req.body.companyId || 'comp_byd_pk').trim();
    const vin = String(req.body.vin || '').trim().toUpperCase();
    const model = String(req.body.model || 'BYD Seal').trim();
    const variant = String(req.body.variant || 'Performance AWD').trim();
    const color = String(req.body.color || 'Atlantis Grey').trim();
    const licensePlate = String(req.body.licensePlate || 'EV-PENDING').trim().toUpperCase();

    if (!vin || vin.length < 8) {
      res.status(400).json({ error: 'Valid VIN (minimum 8 characters) is required.' });
      return;
    }

    const id = `veh_${generateSecureToken(6)}`;
    const now = nowIso();
    try {
      sqlite
        .prepare(`
          INSERT INTO vehicles (
            id, company_id, dealership_id, vin, chassis_number, model, variant, color, year,
            license_plate, owner_name, owner_phone, owner_city, registration_date,
            odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
            warranty_expiry_date, last_service_date, next_service_due_km, status,
            dealership_purchased, sale_price_pkr, sold_at, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 100, 92, '2034-12-31', ?, 10000, 'Active', ?, ?, ?, ?)
        `)
        .run(
          id,
          companyId,
          req.body.dealershipId || null,
          vin,
          `CH-${vin.slice(-6)}`,
          model,
          variant,
          color,
          Number(req.body.year || 2026),
          licensePlate,
          String(req.body.ownerName || 'Dealership Stock'),
          String(req.body.ownerPhone || '+92 21 111 293 750'),
          String(req.body.ownerCity || 'Karachi'),
          now.slice(0, 10),
          Number(req.body.batteryCapacityKwh || 82.5),
          now.slice(0, 10),
          String(req.body.dealershipPurchased || 'Authorized 3S Centre'),
          Number(req.body.salePricePkr || 14990000),
          req.body.markAsSold ? now.slice(0, 10) : null,
          now
        );
    } catch (err: any) {
      res.status(409).json({ error: err?.message || 'A vehicle with this VIN already exists.' });
      return;
    }

    recordSaAction(req, 'VEHICLE_CREATED', 'Vehicle Inventory', vin, `${model} ${variant} (${color})`);
    res.status(201).json({ success: true, id, vin });
  });

  router.patch('/vehicles/:id', requirePermission('vehicles.manage'), (req: Request, res: Response) => {
    const veh = sqlite.prepare('SELECT * FROM vehicles WHERE id = ?').get(req.params.id) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }

    const status = req.body.status ? String(req.body.status) : veh.status;
    const batteryHealthSoh = req.body.batteryHealthSoh !== undefined ? Number(req.body.batteryHealthSoh) : veh.battery_health_soh;
    const soldAt = req.body.markAsSold === true ? nowIso().slice(0, 10) : veh.sold_at;

    sqlite
      .prepare('UPDATE vehicles SET status = ?, battery_health_soh = ?, sold_at = ? WHERE id = ?')
      .run(status, batteryHealthSoh, soldAt, veh.id);

    recordSaAction(req, 'VEHICLE_UPDATED', 'Vehicle Inventory', veh.vin, `Status: ${status}, SoH: ${batteryHealthSoh}%`);
    res.json({ success: true });
  });

  // =========================================================================
  // 6. BOOKINGS, SERVICE JOBS, WARRANTY CLAIMS & SALES TRANSACTIONS
  // =========================================================================
  router.get('/bookings-sales', (req: Request, res: Response) => {
    const canBookings = req.auth!.subjectType === 'founder' || req.auth!.permissions.includes('bookings.manage');
    const canSales = req.auth!.subjectType === 'founder' || req.auth!.permissions.includes('sales.view');

    if (!canBookings && !canSales) {
      res.status(403).json({ error: 'Permission denied: requires bookings.manage or sales.view.' });
      return;
    }

    const bookings = canBookings
      ? sqlite.prepare('SELECT * FROM bookings ORDER BY created_at DESC LIMIT 100').all()
      : [];
    const serviceJobs = canBookings
      ? sqlite.prepare('SELECT * FROM service_jobs ORDER BY created_at DESC LIMIT 100').all()
      : [];
    const warrantyClaims = canBookings
      ? sqlite.prepare('SELECT * FROM warranty_claims ORDER BY created_at DESC LIMIT 100').all()
      : [];
    const invoices = canSales
      ? sqlite.prepare('SELECT * FROM payments_invoices ORDER BY created_at DESC LIMIT 100').all()
      : [];
    const soldVehicles = canSales
      ? sqlite.prepare('SELECT id, vin, model, variant, owner_name, owner_city, dealership_purchased, sale_price_pkr, sold_at FROM vehicles WHERE sold_at IS NOT NULL ORDER BY sold_at DESC').all()
      : [];

    res.json({ bookings, serviceJobs, warrantyClaims, invoices, soldVehicles });
  });

  router.patch('/bookings/:id', requirePermission('bookings.manage'), (req: Request, res: Response) => {
    const bkg = sqlite.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id) as any;
    if (!bkg) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    const status = String(req.body.status || bkg.status);
    sqlite.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, bkg.id);
    recordSaAction(req, 'BOOKING_STATUS_UPDATED', 'Bookings & Operations', bkg.id, `${bkg.booking_type} -> ${status}`);
    res.json({ success: true });
  });

  router.patch('/warranty-claims/:id', requirePermission('bookings.manage'), (req: Request, res: Response) => {
    const clm = sqlite.prepare('SELECT * FROM warranty_claims WHERE id = ?').get(req.params.id) as any;
    if (!clm) {
      res.status(404).json({ error: 'Warranty claim not found.' });
      return;
    }
    const status = String(req.body.status || clm.status);
    const notes = req.body.reviewNotes ? String(req.body.reviewNotes) : clm.review_notes;
    sqlite.prepare('UPDATE warranty_claims SET status = ?, review_notes = ? WHERE id = ?').run(status, notes || null, clm.id);
    recordSaAction(req, 'WARRANTY_CLAIM_UPDATED', 'Warranty Operations', clm.claim_number, `Status -> ${status}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 7. OPERATIONAL REPORTS & ANALYTICS
  // =========================================================================
  router.get('/reports', requirePermission('reports.view'), (req: Request, res: Response) => {
    const regionalDealerships = sqlite
      .prepare(`
        SELECT country, city, COUNT(*) as branches,
               COALESCE(SUM(monthly_target_units), 0) as targetUnits,
               COALESCE(SUM(achieved_units), 0) as achievedUnits,
               COALESCE(SUM(monthly_revenue_pkr), 0) as monthlyRevenuePkr
        FROM dealerships
        GROUP BY country, city
        ORDER BY monthlyRevenuePkr DESC
      `)
      .all();

    const vehiclesByModel = sqlite
      .prepare('SELECT model, COUNT(*) as totalUnits, SUM(CASE WHEN sold_at IS NOT NULL THEN 1 ELSE 0 END) as soldUnits, ROUND(AVG(battery_health_soh), 1) as avgSoh FROM vehicles GROUP BY model')
      .all();

    const usersByRole = sqlite
      .prepare("SELECT role, COUNT(*) as count FROM users WHERE role NOT IN ('Founder / Owner', 'Super Admin') GROUP BY role ORDER BY count DESC")
      .all();

    const revenueByGateway = sqlite
      .prepare("SELECT payment_gateway, currency, COUNT(*) as count, COALESCE(SUM(total_amount), 0) as totalAmount FROM payments_invoices WHERE status = 'Paid' GROUP BY payment_gateway, currency")
      .all();

    const serviceStatusBreakdown = sqlite
      .prepare('SELECT status, COUNT(*) as count FROM service_jobs GROUP BY status')
      .all();

    recordSaAction(req, 'REPORT_ACCESSED', 'Operational Reports', 'Global Summary', 'Viewed regional sales, inventory & service SLA analytics');

    res.json({
      generatedAt: nowIso(),
      regionalDealerships,
      vehiclesByModel,
      usersByRole,
      revenueByGateway,
      serviceStatusBreakdown,
    });
  });

  // =========================================================================
  // 8. SUPPORT REQUESTS / TICKETS
  // =========================================================================
  router.get('/support-requests', requirePermission('users.view'), (_req: Request, res: Response) => {
    const tickets = sqlite.prepare('SELECT * FROM support_requests ORDER BY created_at DESC').all();
    res.json({ tickets });
  });

  router.post('/support-requests', requirePermission('users.view'), (req: Request, res: Response) => {
    const subject = String(req.body.subject || '').trim();
    const description = String(req.body.description || '').trim();
    const category = String(req.body.category || 'Enterprise Support').trim();
    const priority = ['Low', 'Medium', 'High', 'Critical'].includes(String(req.body.priority))
      ? String(req.body.priority)
      : 'Medium';

    if (!subject || !description) {
      res.status(400).json({ error: 'Support ticket subject and description are required.' });
      return;
    }

    const id = `sup_${generateSecureToken(6)}`;
    const ticketNum = `SUP-2026-${generateNumericOtp(3)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO support_requests (
          id, ticket_number, company_id, user_id, requester_name, requester_email,
          category, priority, subject, description, status, assigned_to, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, ?)
      `)
      .run(
        id,
        ticketNum,
        req.body.companyId || null,
        req.auth!.userId,
        String(req.body.requesterName || req.auth!.fullName),
        String(req.body.requesterEmail || req.auth!.email),
        category,
        priority,
        subject,
        description,
        String(req.body.assignedTo || 'Super Admin Desk'),
        now,
        now
      );

    recordSaAction(req, 'SUPPORT_TICKET_CREATED', 'Support Requests', ticketNum, subject);
    res.status(201).json({ success: true, id, ticketNumber: ticketNum });
  });

  router.patch('/support-requests/:id', requirePermission('bookings.manage'), (req: Request, res: Response) => {
    const ticket = sqlite.prepare('SELECT * FROM support_requests WHERE id = ?').get(req.params.id) as any;
    if (!ticket) {
      res.status(404).json({ error: 'Support ticket not found.' });
      return;
    }

    const status = ['Open', 'In Progress', 'Resolved', 'Closed'].includes(String(req.body.status))
      ? String(req.body.status)
      : ticket.status;
    const assignedTo = req.body.assignedTo ? String(req.body.assignedTo) : ticket.assigned_to;
    const resolutionNotes = req.body.resolutionNotes !== undefined ? String(req.body.resolutionNotes) : ticket.resolution_notes;

    sqlite
      .prepare('UPDATE support_requests SET status = ?, assigned_to = ?, resolution_notes = ?, updated_at = ? WHERE id = ?')
      .run(status, assignedTo, resolutionNotes, nowIso(), ticket.id);

    recordSaAction(req, 'SUPPORT_TICKET_UPDATED', 'Support Requests', ticket.ticket_number, `Status -> ${status}`);
    res.json({ success: true });
  });

  // =========================================================================
  // 9. SYSTEM NOTIFICATIONS & ANNOUNCEMENTS
  // =========================================================================
  router.get('/notifications', requirePermission('notifications.manage'), (_req: Request, res: Response) => {
    const notifications = sqlite.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 100').all();
    res.json({ notifications });
  });

  router.post('/notifications', requirePermission('notifications.manage'), (req: Request, res: Response) => {
    const title = String(req.body.title || '').trim();
    const message = String(req.body.message || '').trim();
    const category = String(req.body.category || 'Announcement').trim();
    const companyId = req.body.companyId ? String(req.body.companyId) : null;

    if (!title || !message) {
      res.status(400).json({ error: 'Notification title and message are required.' });
      return;
    }

    const id = `ntf_${generateSecureToken(6)}`;
    sqlite
      .prepare('INSERT INTO notifications (id, company_id, user_id, title, message, category, is_read, created_at) VALUES (?, ?, NULL, ?, ?, ?, 0, ?)')
      .run(id, companyId, title, message, category, nowIso());

    recordSaAction(req, 'NOTIFICATION_BROADCAST', 'System Notifications', title, `Category: ${category}`);
    res.status(201).json({ success: true, id });
  });

  // =========================================================================
  // 10. PERMITTED APPLICATION SETTINGS (STRICTLY ISOLATED FROM FOUNDER POLICY/AI)
  // =========================================================================
  router.get('/settings', requirePermission('settings.manage'), (_req: Request, res: Response) => {
    const operationalSettings = getSystemSetting('app_operational_settings', {});
    res.json({ operationalSettings });
  });

  router.put('/settings', requirePermission('settings.manage'), (req: Request, res: Response) => {
    // Explicitly block tampering with Founder-only security_policy, ai_config, or founder fields
    if (req.body.securityPolicy || req.body.aiConfig || req.body.founder) {
      rejectFounderOrAdminManipulation(
        req,
        res,
        'Super Admin attempted to overwrite Founder security_policy or ai_config settings.'
      );
      return;
    }

    const current = getSystemSetting<Record<string, any>>('app_operational_settings', {});
    const incoming = (req.body.operationalSettings || {}) as Record<string, any>;
    const updated = {
      ...current,
      defaultSupportEmail: String(incoming.defaultSupportEmail ?? current.defaultSupportEmail ?? 'support@bydpakistan360.demo'),
      tollFreeHelpline: String(incoming.tollFreeHelpline ?? current.tollFreeHelpline ?? '0800-293-75'),
      bookingAutoConfirm: typeof incoming.bookingAutoConfirm === 'boolean' ? incoming.bookingAutoConfirm : Boolean(current.bookingAutoConfirm),
      maintenanceBannerEnabled: typeof incoming.maintenanceBannerEnabled === 'boolean' ? incoming.maintenanceBannerEnabled : Boolean(current.maintenanceBannerEnabled),
      maintenanceBannerText: String(incoming.maintenanceBannerText ?? current.maintenanceBannerText ?? ''),
      serviceSlaHours: Number(incoming.serviceSlaHours ?? current.serviceSlaHours ?? 24),
      warrantyReviewSlaHours: Number(incoming.warrantyReviewSlaHours ?? current.warrantyReviewSlaHours ?? 48),
      defaultDisplayCurrency: ['PKR', 'USD', 'AED'].includes(String(incoming.defaultDisplayCurrency))
        ? String(incoming.defaultDisplayCurrency)
        : current.defaultDisplayCurrency || 'PKR',
    };

    setSystemSetting('app_operational_settings', updated, req.auth!.userId);
    recordSaAction(req, 'OPERATIONAL_SETTINGS_UPDATED', 'Application Settings', 'app_operational_settings', `Currency: ${updated.defaultDisplayCurrency}, ServiceSLA: ${updated.serviceSlaHours}h`);
    res.json({ success: true, operationalSettings: updated });
  });

  // =========================================================================
  // 11. AUDIT LOGS, LOGIN HISTORY & OPERATIONAL SECURITY EVENTS
  // =========================================================================
  router.get('/audit-logs', requirePermission('audit_logs.view'), (_req: Request, res: Response) => {
    const adminActivities = sqlite
      .prepare('SELECT * FROM admin_activity_logs ORDER BY created_at DESC LIMIT 150')
      .all();
    const loginHistory = sqlite
      .prepare("SELECT id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, suspicious, created_at FROM login_history WHERE subject_type != 'founder' ORDER BY created_at DESC LIMIT 100")
      .all();
    const securityEvents = sqlite
      .prepare("SELECT * FROM security_events WHERE event_type NOT LIKE '%FOUNDER%' ORDER BY created_at DESC LIMIT 100")
      .all();

    res.json({ adminActivities, loginHistory, securityEvents });
  });

  return router;
}
