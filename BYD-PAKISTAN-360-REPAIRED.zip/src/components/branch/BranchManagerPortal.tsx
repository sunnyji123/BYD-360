import React, { useState, useEffect, useCallback } from 'react';
import {
  Store,
  Shield,
  Lock,
  KeyRound,
  Mail,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  LogOut,
  RefreshCw,
  Building2,
  Users,
  GitBranch,
  Car,
  UserCheck,
  DollarSign,
  FileSpreadsheet,
  Plus,
  Check,
  XCircle,
  ArrowRightLeft,
  Monitor,
  History,
  Trash2,
  Send,
  Printer,
  Download,
  FileText,
  ShieldAlert,
  Bell,
  Wrench,
  Calendar,
  Package,
  MapPin,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AdminDealerGovernancePanel } from '../dealer/AdminDealerGovernancePanel';
import { AdminCustomerGovernancePanel } from '../customer/AdminCustomerGovernancePanel';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { AdminVerificationApprovalPanel } from '../admin/AdminVerificationApprovalPanel';
import { EmployeeManagementHub } from '../employee/EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type BranchPortalTab =
  | 'overview'
  | 'branch'
  | 'employees'
  | 'employee-hub'
  | 'vehicles'
  | 'sales'
  | 'customers'
  | 'dealerships'
  | 'dealership-hub'
  | 'finance'
  | 'service'
  | 'reports'
  | 'security';

type AuthStep = 'login' | 'verify-email' | '2fa' | 'forgot-password';

const SAFE_BRANCH_ROLES = [
  'Sales Manager',
  'Sales Executive',
  'Service Manager',
  'Service Advisor',
  'Workshop Technician',
  'Technical Support',
  'Warranty Manager',
  'Inventory Manager',
  'Finance Manager',
  'Customer Support Agent',
  'Dealership Staff',
  'Dealership Manager',
];

export const BranchManagerPortal: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, setActiveTab } = useApp();
  const isBranchManager = isAuthenticated && currentUser.subjectType === 'branch_manager';

  // Auth Flow State (all hooks declared unconditionally at top)
  const [statusLoading, setStatusLoading] = useState(true);
  const [portalStatus, setPortalStatus] = useState<{
    hasBranchManagers: boolean;
    activeBranchesCount: number;
    twoFactorRequired: boolean;
    emailVerificationRequired: boolean;
    portalIsolated: boolean;
  } | null>(null);

  const [authStep, setAuthStep] = useState<AuthStep>('login');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [identifier, setIdentifier] = useState('');
  const [branchCodeInput, setBranchCodeInput] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [pendingEmail, setPendingEmail] = useState('');
  const [pendingBranchLabel, setPendingBranchLabel] = useState('');
  const [emailOtpCode, setEmailOtpCode] = useState('');
  const [devEmailOtpHint, setDevEmailOtpHint] = useState<string | null>(null);

  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [devLoginOtpHint, setDevLoginOtpHint] = useState<string | null>(null);
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);

  const [forgotEmail, setForgotEmail] = useState('');
  const [resetStage, setResetStage] = useState<'request' | 'confirm'>('request');
  const [resetToken, setResetToken] = useState('');
  const [resetOtpCode, setResetOtpCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [devResetHint, setDevResetHint] = useState<{ resetToken?: string; otpCode?: string } | null>(null);

  // Workspace State
  const [bmTab, setBmTab] = useState<BranchPortalTab>('overview');
  const [banner, setBanner] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [loadingDash, setLoadingDash] = useState(false);
  const [dashboard, setDashboard] = useState<any>(null);

  // Module 2: Branch Profile & Operations
  const [branchForm, setBranchForm] = useState({
    address: '',
    phone: '',
    email: '',
    hoursWeekday: '09:00 - 18:00',
    hoursSaturday: '10:00 - 16:00',
    departmentsText: '',
    dailyShiftLead: '',
    dailyNotes: '',
    announcementTitle: '',
    announcementBody: '',
  });

  // Module 3: Employees
  const [employees, setEmployees] = useState<any[]>([]);
  const [empReport, setEmpReport] = useState<any>(null);
  const [newEmp, setNewEmp] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    role: 'Sales Executive',
    department: 'Sales & Showroom',
    employeeCode: '',
    password: '',
    shiftSchedule: 'Mon-Sat 09:00-18:00',
    dailyTask: 'EV showroom walk-ins & follow-ups',
  });
  const [editingEmp, setEditingEmp] = useState<any>(null);
  const [empEditForm, setEmpEditForm] = useState({
    employeeCode: '',
    department: '',
    jobPosition: '',
    status: 'Active' as 'Active' | 'Suspended' | 'On Leave',
    performanceScore: 92,
    shiftSchedule: '',
    dailyTask: '',
    taskStatus: 'In Progress',
  });
  const [attModalEmp, setAttModalEmp] = useState<any>(null);
  const [attForm, setAttForm] = useState({ status: 'Present' as 'Present' | 'Absent' | 'Late' | 'Remote' | 'Half-Day', checkIn: '09:00', checkOut: '18:00', notes: '' });
  const [leaveModalEmp, setLeaveModalEmp] = useState<any>(null);
  const [leaveForm, setLeaveForm] = useState({ leaveType: 'Annual Leave', startDate: new Date().toISOString().slice(0, 10), endDate: new Date().toISOString().slice(0, 10), reason: '' });

  // Module 4: Vehicles & Transfers
  const [vehiclesData, setVehiclesData] = useState<any>(null);
  const [newVehicle, setNewVehicle] = useState({
    vin: '',
    chassisNumber: '',
    model: 'BYD Seal',
    variant: 'Performance AWD',
    color: 'Arctic Blue',
    year: 2026,
    salePricePkr: 16900000,
    stockState: 'Available' as 'Available' | 'Reserved' | 'Sold' | 'In Transit',
    conditionGrade: 'A+ Factory PDI Passed',
  });
  const [editingVehicle, setEditingVehicle] = useState<any>(null);
  const [vehEditForm, setVehEditForm] = useState({
    stockState: 'Available' as 'Available' | 'Reserved' | 'Sold' | 'In Transit',
    conditionGrade: 'A+ Factory PDI Passed',
    conditionNotes: '',
    reservedCustomerName: '',
  });
  const [transferModalVeh, setTransferModalVeh] = useState<any>(null);
  const [transferForm, setTransferForm] = useState({ targetBranchId: '', reason: '' });

  // Module 5: Sales & Bookings
  const [salesData, setSalesData] = useState<any>(null);
  const [dailyReport, setDailyReport] = useState<any>(null);
  const [newBooking, setNewBooking] = useState({
    customerName: '',
    customerPhone: '+92 300 ',
    bookingType: 'Vehicle Reservation',
    vehicleModel: 'BYD Seal',
    preferredDate: new Date().toISOString().slice(0, 10),
    preferredTime: '11:00 AM',
    notes: '',
  });
  const [newOrder, setNewOrder] = useState({
    vehicleId: '',
    vehicleModel: 'BYD Atto 3',
    customerName: '',
    customerPhone: '+92 300 ',
    salesExecName: '',
    saleAmountPkr: 14900000,
    paidAmountPkr: 2500000,
  });
  const [newInvoice, setNewInvoice] = useState({
    customerName: '',
    itemCategory: 'EV Booking Deposit',
    subtotal: 2500000,
    taxRate: 17,
    paymentGateway: 'Bank Wire / Branch POS',
    status: 'Paid' as 'Paid' | 'Pending Payment',
  });

  // Module 6: Customers & CRM
  const [customersData, setCustomersData] = useState<any>(null);
  const [piiRevealed, setPiiRevealed] = useState(false);
  const [newCustomer, setNewCustomer] = useState({ fullName: '', email: '', mobile: '+92 300 ', cnicOrId: '' });
  const [newCrm, setNewCrm] = useState({
    customerName: '',
    customerEmail: '',
    customerPhone: '+92 300 ',
    recordType: 'Enquiry' as 'Enquiry' | 'Test Drive' | 'Follow-Up' | 'Complaint' | 'Feedback',
    subject: '',
    details: '',
    priority: 'Medium',
    followUpDate: new Date().toISOString().slice(0, 10),
  });
  const [editingCrm, setEditingCrm] = useState<any>(null);
  const [crmEditForm, setCrmEditForm] = useState({ status: 'In Progress', resolutionNotes: '' });

  // Module 7: Dealerships
  const [dealersData, setDealersData] = useState<any>(null);
  const [commDealer, setCommDealer] = useState<any>(null);
  const [commForm, setCommForm] = useState({ subject: '', message: '' });

  // Module 8: Finance
  const [financeData, setFinanceData] = useState<any>(null);
  const [newExpense, setNewExpense] = useState({
    category: 'Utilities & Charging',
    title: '',
    amountPkr: 45000,
    expenseDate: new Date().toISOString().slice(0, 10),
  });
  const [refundTargetInv, setRefundTargetInv] = useState<{ inv: any; mode: 'request' | 'direct' } | null>(null);
  const [refundReason, setRefundReason] = useState('');

  // Module 9: Service, Warranty & Spare Parts
  const [serviceData, setServiceData] = useState<any>(null);
  const [newServiceJob, setNewServiceJob] = useState({
    vin: '',
    model: 'BYD Atto 3',
    licensePlate: '',
    customerName: '',
    customerPhone: '+92 300 ',
    serviceType: '10,000 KM EV Inspection',
    scheduledDate: new Date().toISOString().slice(0, 10),
    reminderDate: '',
    estimatedCostPkr: 22000,
  });
  const [newSparePart, setNewSparePart] = useState({
    sku: '',
    name: '',
    category: 'High Voltage / Thermal',
    compatibleModels: 'BYD Seal, Atto 3',
    stockQuantity: 12,
    reorderLevel: 4,
    unitCostPkr: 18000,
    locationBin: 'B-02',
  });

  // Module 10: Reports & Exports
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [reportData, setReportData] = useState<any>(null);
  const [exporting, setExporting] = useState(false);

  // Module 11: Security, Sessions & Audit Logs
  const [auditData, setAuditData] = useState<any>(null);
  const [bmSessions, setBmSessions] = useState<any[]>([]);
  const [bmLoginHistory, setBmLoginHistory] = useState<any[]>([]);

  const notify = (text: string, type: 'ok' | 'err' = 'ok') => {
    setBanner({ text, type });
    setTimeout(() => setBanner(null), 5000);
  };

  const hasPerm = useCallback(
    (perm: string) => (currentUser?.permissions || []).includes(perm),
    [currentUser]
  );

  const loadPortalStatus = useCallback(async () => {
    setStatusLoading(true);
    try {
      const st = await api.getBranchManagerStatus();
      setPortalStatus(st);
    } catch (err: any) {
      setAuthError(err.message || 'Unable to verify Branch Manager portal status.');
    } finally {
      setStatusLoading(false);
    }
  }, []);

  const loadDashboard = useCallback(async () => {
    if (!isBranchManager) return;
    setLoadingDash(true);
    try {
      const data = await api.getBranchManagerDashboard();
      setDashboard(data);
      const b = data.branch;
      if (b) {
        const wh = b.working_hours || {};
        const ops = b.daily_operations || {};
        setBranchForm((prev) => ({
          ...prev,
          address: b.address || '',
          phone: b.phone || '',
          email: b.email || '',
          hoursWeekday: wh.monSat || wh.weekday || '09:00 - 18:00',
          hoursSaturday: wh.sunday || wh.weekend || 'Closed / Appointment Only',
          departmentsText: Array.isArray(b.departments) ? b.departments.join(', ') : '',
          dailyShiftLead: ops.shiftLead || b.manager_name || '',
          dailyNotes: ops.notes || 'Standard showroom & workshop SLA active',
        }));
      }
    } catch (err: any) {
      notify(err.message || 'Failed to load branch dashboard.', 'err');
    } finally {
      setLoadingDash(false);
    }
  }, [isBranchManager]);

  const loadActiveTabData = useCallback(
    async (tab: BranchPortalTab) => {
      if (!isBranchManager) return;
      try {
        if (tab === 'employees') {
          const [empRes, repRes] = await Promise.all([
            api.getBranchManagerEmployees(),
            api.getBranchEmployeesReport(),
          ]);
          setEmployees(empRes.employees || []);
          setEmpReport(repRes);
        } else if (tab === 'vehicles') {
          const vRes = await api.getBranchManagerVehicles();
          setVehiclesData(vRes);
        } else if (tab === 'sales') {
          const [sRes, dRes] = await Promise.all([
            api.getBranchManagerSalesBookings(),
            api.getBranchDailySalesReport(),
          ]);
          setSalesData(sRes);
          setDailyReport(dRes);
        } else if (tab === 'customers') {
          const cRes = await api.getBranchManagerCustomers(piiRevealed);
          setCustomersData(cRes);
        } else if (tab === 'dealerships') {
          const dRes = await api.getBranchManagerDealerships();
          setDealersData(dRes);
        } else if (tab === 'finance') {
          const fRes = await api.getBranchManagerFinance();
          setFinanceData(fRes);
        } else if (tab === 'service') {
          const svRes = await api.getBranchServiceWarranty();
          setServiceData(svRes);
        } else if (tab === 'reports') {
          const rRes = await api.getBranchManagerReports(reportPeriod);
          setReportData(rRes);
        } else if (tab === 'security') {
          const [aRes, sRes, hRes] = await Promise.all([
            api.getBranchManagerAuditLogs(),
            api.getBranchManagerSessions(),
            api.getBranchManagerLoginHistory(),
          ]);
          setAuditData(aRes);
          setBmSessions(sRes.sessions || []);
          setBmLoginHistory(hRes.history || []);
        }
      } catch (err: any) {
        notify(err.message || `Failed to load ${tab} data.`, 'err');
      }
    },
    [isBranchManager, piiRevealed, reportPeriod]
  );

  useEffect(() => {
    loadPortalStatus();
  }, [loadPortalStatus]);

  useEffect(() => {
    if (isBranchManager) {
      loadDashboard();
    }
  }, [isBranchManager, loadDashboard]);

  useEffect(() => {
    if (isBranchManager && bmTab !== 'overview' && bmTab !== 'branch') {
      loadActiveTabData(bmTab);
    }
  }, [isBranchManager, bmTab, loadActiveTabData]);

  // Auth Handlers
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.branchManagerLogin({
        identifier: identifier.trim(),
        password,
        branchCode: branchCodeInput.trim() || undefined,
      });
      if (res.requiresEmailVerification) {
        setPendingEmail(res.email || identifier.trim());
        setPendingBranchLabel(res.branchName || '');
        setDevEmailOtpHint(res.verificationOutbox?.code || null);
        setAuthStep('verify-email');
        setAuthSuccess(res.message || 'Verify your Branch Manager email OTP before 2FA.');
      } else if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setPendingBranchLabel(`${res.branchName || ''} (${res.managerCode || ''})`);
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setSuspiciousAlert(Boolean(res.suspiciousIpDetected));
        setAuthStep('2fa');
        setAuthSuccess(res.message || '2FA verification required.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Branch Manager sign-in failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.branchManagerVerifyEmail({
        email: pendingEmail,
        code: emailOtpCode.trim(),
      });
      setChallengeToken(res.challengeToken);
      setPendingBranchLabel(`${res.branchName} (${res.managerCode})`);
      setDevLoginOtpHint(res.otpOutbox?.code || null);
      setAuthStep('2fa');
      setAuthSuccess('Email verified. Complete mandatory 2FA to unlock Branch Workspace.');
    } catch (err: any) {
      setAuthError(err.message || 'Email OTP verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.branchManagerVerify2FA({
        challengeToken,
        code: twoFactorCode.trim(),
      });
      loginUser(res.user);
      setPassword('');
      setTwoFactorCode('');
    } catch (err: any) {
      setAuthError(err.message || '2FA code verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      if (resetStage === 'request') {
        const res = await api.branchManagerForgotPassword(forgotEmail.trim());
        setDevResetHint(res.resetOutbox || null);
        if (res.resetOutbox?.resetToken) setResetToken(res.resetOutbox.resetToken);
        if (res.resetOutbox?.otpCode) setResetOtpCode(res.resetOutbox.otpCode);
        setResetStage('confirm');
        setAuthSuccess(res.message);
      } else {
        const res = await api.branchManagerResetPassword({
          token: resetToken.trim(),
          otpCode: resetOtpCode.trim() || undefined,
          newPassword: resetNewPassword,
        });
        setAuthSuccess(res.message);
        setAuthStep('login');
        setResetStage('request');
        setResetNewPassword('');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Password reset failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  // =========================================================================
  // RENDER: ISOLATED BRANCH MANAGER LOGIN PORTAL
  // =========================================================================
  if (!isBranchManager) {
    return (
      <div className="max-w-2xl mx-auto py-8 pb-16 space-y-6">
        <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-cyan-950/30 border border-cyan-500/30 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 text-slate-950 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <Store className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-cyan-400">
                  Isolated Branch Governance Portal
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  BYD PAKISTAN 360 — Branch Manager Access
                </h1>
                <p className="text-xs text-slate-400">
                  Founder &amp; CEO: Intekhab Alam • Branch-Scoped RBAC, Email OTP &amp; Mandatory 2FA
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('landing')}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900"
            >
              Exit Portal
            </button>
          </div>

          {isAuthenticated && (
            <div className="p-4 rounded-xl bg-amber-500/15 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  You are currently signed in as <strong>{currentUser.name}</strong> ({currentUser.role}). Cross-portal access is blocked; sign out to authenticate with an authorized Branch Manager account.
                </span>
              </div>
              <button
                type="button"
                onClick={logoutUser}
                className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-200 border border-rose-700 font-bold"
              >
                Sign Out Current Session
              </button>
            </div>
          )}

          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              Strictly segregated from Founder, Super Admin, Company Admin, Country Manager, Employee, Dealer, and Customer portals. Each Branch Manager can access only their assigned branch.
            </span>
          </div>

          {authError && (
            <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {authSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{authSuccess}</span>
            </div>
          )}

          {statusLoading ? (
            <div className="py-10 text-center text-xs text-slate-400">Verifying Branch Manager portal security state...</div>
          ) : !portalStatus?.hasBranchManagers ? (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-2">
              <div className="font-bold text-white">No Branch Manager Accounts Provisioned</div>
              <p>An authorized Primary Owner must provision and assign a Branch Manager account before branch sign-in becomes active.</p>
            </div>
          ) : authStep === 'verify-email' ? (
            <form onSubmit={handleVerifyEmail} className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-1 text-xs">
                <div className="font-bold text-cyan-300 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>Step 1 of 2: Verify Branch Manager Email ({pendingEmail})</span>
                </div>
                {pendingBranchLabel && <div className="text-slate-400">Assigned Branch: {pendingBranchLabel}</div>}
                {devEmailOtpHint && (
                  <div className="p-2 mt-2 rounded-lg bg-slate-950 border border-amber-500/40 font-mono text-amber-300">
                    Development Mailer OTP: <strong>{devEmailOtpHint}</strong>
                  </div>
                )}
              </div>
              <input
                type="text"
                required
                value={emailOtpCode}
                onChange={(e) => setEmailOtpCode(e.target.value)}
                placeholder="6-digit Email Verification OTP"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
              />
              <div className="flex gap-3">
                <button type="button" onClick={() => setAuthStep('login')} className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold">
                  Back
                </button>
                <button type="submit" disabled={authSubmitting} className="flex-1 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs">
                  {authSubmitting ? 'Verifying...' : 'Verify Email & Proceed to 2FA'}
                </button>
              </div>
            </form>
          ) : authStep === '2fa' ? (
            <form onSubmit={handleVerify2FA} className="space-y-4">
              {suspiciousAlert && (
                <div className="p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-xs text-amber-200 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>New IP address detected for this Branch Manager account. 2FA verification required.</span>
                </div>
              )}
              <div className="p-4 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-1 text-xs">
                <div className="font-bold text-cyan-300 flex items-center gap-2">
                  <KeyRound className="w-4 h-4" />
                  <span>Mandatory Two-Factor Authentication (2FA)</span>
                </div>
                <p className="text-slate-300">Branch Binding: <strong>{pendingBranchLabel}</strong></p>
                {devLoginOtpHint && (
                  <div className="p-2 mt-2 rounded-lg bg-slate-950 border border-amber-500/40 font-mono text-amber-300">
                    One-Time Email 2FA Code: <strong>{devLoginOtpHint}</strong>
                  </div>
                )}
              </div>
              <input
                type="text"
                required
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value)}
                placeholder="6-digit TOTP / Email OTP / Recovery Code"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
                autoFocus
              />
              <div className="flex gap-3">
                <button type="button" onClick={() => setAuthStep('login')} className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold">
                  Back
                </button>
                <button type="submit" disabled={authSubmitting} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-black text-xs uppercase tracking-wider">
                  {authSubmitting ? 'Verifying 2FA...' : 'Unlock Assigned Branch Dashboard'}
                </button>
              </div>
            </form>
          ) : authStep === 'forgot-password' ? (
            <form onSubmit={handleForgotSubmit} className="space-y-4 text-xs">
              {resetStage === 'request' ? (
                <>
                  <p className="text-slate-300">Enter your registered Branch Manager email to request a password reset token &amp; OTP.</p>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="Branch Manager Email"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-white"
                  />
                  <div className="flex gap-3">
                    <button type="button" onClick={() => setAuthStep('login')} className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-200 font-semibold">
                      Back
                    </button>
                    <button type="submit" disabled={authSubmitting} className="flex-1 py-2.5 rounded-xl bg-cyan-600 text-white font-bold">
                      {authSubmitting ? 'Sending...' : 'Request Reset Token & OTP'}
                    </button>
                  </div>
                </>
              ) : (
                <>
                  {devResetHint && (
                    <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/40 text-amber-300 font-mono space-y-1 break-all">
                      <div>Reset Token: {devResetHint.resetToken}</div>
                      <div>OTP Code: {devResetHint.otpCode}</div>
                    </div>
                  )}
                  <input
                    type="text"
                    required
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder="Reset Token"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2 text-white font-mono"
                  />
                  <input
                    type="text"
                    value={resetOtpCode}
                    onChange={(e) => setResetOtpCode(e.target.value)}
                    placeholder="Verification OTP Code"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2 text-white font-mono"
                  />
                  <input
                    type="password"
                    required
                    value={resetNewPassword}
                    onChange={(e) => setResetNewPassword(e.target.value)}
                    placeholder="New Strong Password (10+ chars, upper/lower/digit/symbol)"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2 text-white"
                  />
                  <button type="submit" disabled={authSubmitting} className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold">
                    {authSubmitting ? 'Updating...' : 'Reset Password & Revoke Old Sessions'}
                  </button>
                </>
              )}
            </form>
          ) : (
            <form onSubmit={handlePasswordLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Manager ID, Official Email, Username, or Mobile
                </label>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. BM-PK-KHI-01 or branch.khi@byd360.demo"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Assigned Branch Code / ID Verification (Optional Guard)
                </label>
                <input
                  type="text"
                  value={branchCodeInput}
                  onChange={(e) => setBranchCodeInput(e.target.value)}
                  placeholder="e.g. BR-KHI-01 (rejects if branch does not match assignment)"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 text-xs text-white font-mono focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Branch Manager Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter private password"
                    className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3.5 py-2.5 pr-9 text-xs text-white focus:border-cyan-400 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setAuthError('');
                    setAuthSuccess('');
                    setAuthStep('forgot-password');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-semibold"
                >
                  Forgot Branch Manager Password?
                </button>
                <span className="text-slate-500">{portalStatus?.activeBranchesCount || 0} Active Branches Online</span>
              </div>

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20"
              >
                {authSubmitting ? 'Authenticating Branch Credentials...' : 'Authenticate Branch Manager & Verify 2FA'}
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  // =========================================================================
  // RENDER: AUTHENTICATED 11-MODULE BRANCH MANAGEMENT WORKSPACE
  // =========================================================================
  const branch = dashboard?.branch;
  const company = dashboard?.company;
  const country = dashboard?.country;
  const m = dashboard?.metrics || {};
  const currency = country?.currency || 'PKR';

  const navItems: { id: BranchPortalTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'overview', label: 'Overview', icon: Store },
    { id: 'branch', label: 'Branch Ops', icon: Building2 },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'employee-hub', label: 'Employee Management', icon: Building2 },
    { id: 'vehicles', label: 'Vehicle Inventory', icon: Car },
    { id: 'sales', label: 'Sales & Bookings', icon: FileText },
    { id: 'customers', label: 'Customers (CRM)', icon: UserCheck },
    { id: 'dealerships', label: 'Dealerships', icon: GitBranch },
    { id: 'dealership-hub', label: 'Dealership Hub', icon: Store },
    { id: 'finance', label: 'Branch Finance', icon: DollarSign },
    { id: 'service', label: 'Service & Warranty', icon: Wrench },
    { id: 'reports', label: 'Reports & Export', icon: FileSpreadsheet },
    { id: 'security', label: 'Permissions & Logs', icon: Shield },
  ];

  const handleSaveBranchOps = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const existingAnnouncements = Array.isArray(branch?.announcements) ? branch.announcements : [];
      const nextAnnouncements =
        branchForm.announcementTitle.trim() && branchForm.announcementBody.trim()
          ? [
              {
                id: `ann_${Date.now()}`,
                title: branchForm.announcementTitle.trim(),
                body: branchForm.announcementBody.trim(),
                postedBy: currentUser.name,
                postedAt: new Date().toISOString().slice(0, 10),
              },
              ...existingAnnouncements,
            ]
          : existingAnnouncements;

      await api.updateBranchManagerBranch({
        address: branchForm.address,
        phone: branchForm.phone,
        email: branchForm.email,
        workingHours: { monSat: branchForm.hoursWeekday, sunday: branchForm.hoursSaturday },
        departments: branchForm.departmentsText
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        dailyOperations: { shiftLead: branchForm.dailyShiftLead, notes: branchForm.dailyNotes },
        announcements: nextAnnouncements,
      });
      setBranchForm((p) => ({ ...p, announcementTitle: '', announcementBody: '' }));
      notify('Branch operational profile & announcements saved.');
      await loadDashboard();
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.createBranchManagerEmployee({
        ...newEmp,
        jobPosition: newEmp.role,
      });
      notify(`Created branch employee ${res.employeeCode} (${newEmp.fullName}).`);
      setNewEmp({
        fullName: '',
        email: '',
        mobile: '+92 300 ',
        role: 'Sales Executive',
        department: 'Sales & Showroom',
        employeeCode: '',
        password: '',
        shiftSchedule: 'Mon-Sat 09:00-18:00',
        dailyTask: 'EV showroom walk-ins & follow-ups',
      });
      await Promise.all([loadActiveTabData('employees'), loadDashboard()]);
    } catch (err: any) {
      notify(err.message, 'err');
    }
  };

  const handleExport = async (format: 'xlsx' | 'csv') => {
    setExporting(true);
    try {
      const blob = await api.exportBranchManagerReportBlob(format, reportPeriod);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `byd360-branch-${branch?.code || 'report'}-${reportPeriod}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      notify(`Exported real ${format.toUpperCase()} branch report.`);
    } catch (err: any) {
      notify(err.message, 'err');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header Strip */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/30 border border-cyan-500/30 p-5 sm:p-6 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 text-cyan-300 flex items-center justify-center">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 font-mono text-[10px] font-bold">
                {branch?.code || currentUser.branchId}
              </span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                {currentUser.managerCode || 'BRANCH MANAGER'}
              </span>
              <span className="text-[11px] text-emerald-300 font-semibold">
                {country?.flag_emoji} {country?.name} • {company?.name}
              </span>
            </div>
            <h1 className="text-lg sm:text-xl font-black text-white mt-0.5">
              {branch?.name || currentUser.branchName || 'Assigned Branch Workspace'}
            </h1>
            <p className="text-xs text-slate-400">
              Manager: <strong className="text-slate-200">{currentUser.name}</strong> • Branch-Isolated Operations &amp; Audit Control
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              loadDashboard();
              if (bmTab !== 'overview' && bmTab !== 'branch') loadActiveTabData(bmTab);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-800 bg-slate-950 text-xs text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingDash ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
          <button
            type="button"
            onClick={logoutUser}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-500/40 bg-rose-950/40 text-xs font-bold text-rose-300 hover:text-white"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Sub-Navigation */}
      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 print:hidden">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = bmTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setBmTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition ${
                active ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
            banner.type === 'err'
              ? 'bg-rose-950/60 border-rose-500/40 text-rose-200'
              : 'bg-cyan-950/60 border-cyan-500/40 text-cyan-200'
          }`}
        >
          {banner.type === 'err' ? <AlertTriangle className="w-4 h-4 shrink-0" /> : <CheckCircle2 className="w-4 h-4 shrink-0" />}
          <span>{banner.text}</span>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 1: BRANCH OVERVIEW                                             */}
      {/* ===================================================================== */}
      {bmTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Branch Workforce</span>
                <Users className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1 tabular-nums">{m.totalEmployees ?? 0}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">{m.totalDealers ?? 0} Dealers • {m.totalCustomers ?? 0} Customers</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Branch EV Stock</span>
                <Car className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1 tabular-nums">{m.totalVehicles ?? 0}</div>
              <div className="text-[11px] text-emerald-400 mt-0.5">
                {m.availableVehicles ?? 0} Avail • {m.reservedVehicles ?? 0} Res • {m.soldVehicles ?? 0} Sold
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Bookings &amp; Orders</span>
                <FileText className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white mt-1 tabular-nums">
                {m.totalBookings ?? 0} / {m.totalSalesOrders ?? 0}
              </div>
              <div className="text-[11px] text-amber-300 mt-0.5">{m.pendingTasks ?? 0} Pending Operational Tasks</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Branch Revenue ({currency})</span>
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-xl font-black text-emerald-400 mt-1 tabular-nums font-mono">
                {Number(m.branchRevenuePkr || 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">Expenses: {Number(m.totalExpensesPkr || 0).toLocaleString()}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Branch Notifications */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-cyan-400" />
                <span>Branch Notifications &amp; Dispatches</span>
              </h3>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {(dashboard?.notifications || []).length === 0 ? (
                  <p className="text-xs text-slate-500">No active notifications for this branch.</p>
                ) : (
                  (dashboard?.notifications || []).map((n: any) => (
                    <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{n.title}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300">{n.category}</span>
                      </div>
                      <p className="text-slate-400">{n.message}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Recent Branch Activities */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <span>Recent Branch Activity Audit Trail</span>
              </h3>
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {(dashboard?.recentActivities || []).map((act: any) => (
                  <div key={act.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">{act.action}</div>
                      <div className="text-slate-400">{act.details}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                        {act.actor_name} • {act.created_at?.slice(0, 19).replace('T', ' ')}
                      </div>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${act.status === 'ALERT' ? 'bg-rose-950 text-rose-300' : 'bg-emerald-950 text-emerald-300'}`}>
                      {act.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 2: BRANCH PROFILE & DAILY OPERATIONS                           */}
      {/* ===================================================================== */}
      {bmTab === 'branch' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleSaveBranchOps} className="lg:col-span-2 rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400" />
                <span>Branch Operational Profile &amp; Working Hours</span>
              </h3>
              <span className="font-mono text-[11px] text-cyan-300">ID: {branch?.id} • Code: {branch?.code}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Branch Address</label>
                <input
                  type="text"
                  value={branchForm.address}
                  onChange={(e) => setBranchForm({ ...branchForm, address: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Contact Phone</label>
                <input
                  type="text"
                  value={branchForm.phone}
                  onChange={(e) => setBranchForm({ ...branchForm, phone: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Branch Email</label>
                <input
                  type="email"
                  value={branchForm.email}
                  onChange={(e) => setBranchForm({ ...branchForm, email: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Mon–Sat Working Hours</label>
                <input
                  type="text"
                  value={branchForm.hoursWeekday}
                  onChange={(e) => setBranchForm({ ...branchForm, hoursWeekday: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Active Departments (comma-separated)</label>
                <input
                  type="text"
                  value={branchForm.departmentsText}
                  onChange={(e) => setBranchForm({ ...branchForm, departmentsText: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Daily Operations Shift Lead</label>
                <input
                  type="text"
                  value={branchForm.dailyShiftLead}
                  onChange={(e) => setBranchForm({ ...branchForm, dailyShiftLead: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Daily Operational Brief / Notes</label>
              <textarea
                rows={2}
                value={branchForm.dailyNotes}
                onChange={(e) => setBranchForm({ ...branchForm, dailyNotes: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="font-bold text-cyan-300">Post New Branch Announcement (Optional)</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Announcement Title"
                  value={branchForm.announcementTitle}
                  onChange={(e) => setBranchForm({ ...branchForm, announcementTitle: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Announcement Message"
                  value={branchForm.announcementBody}
                  onChange={(e) => setBranchForm({ ...branchForm, announcementBody: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={!hasPerm('branch.profile.manage')}
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black disabled:opacity-40"
            >
              Save Branch Operational Profile
            </button>
          </form>

          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs">
            <h3 className="text-sm font-bold text-white">Branch Announcements &amp; Targets</h3>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="text-slate-400">Monthly Target: <strong className="text-white">{branch?.monthly_target_units || 25} EVs</strong></div>
              <div className="text-slate-400">Location: <strong className="text-cyan-300">{branch?.city}, {country?.name}</strong></div>
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(branch?.announcements || []).length === 0 ? (
                <p className="text-slate-500">No announcements posted yet.</p>
              ) : (
                (branch?.announcements || []).map((a: any, idx: number) => (
                  <div key={a.id || idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <div className="font-bold text-white">{a.title}</div>
                    <p className="text-slate-400">{a.body}</p>
                    <div className="text-[10px] text-slate-500">{a.postedBy} • {a.postedAt}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 3: EMPLOYEE MANAGEMENT                                         */}
      {/* ===================================================================== */}
      {bmTab === 'employees' && (
        <div className="space-y-6">
          {empReport && (
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Total Staff</div><div className="text-lg font-black text-white tabular-nums">{empReport.totalEmployees}</div></div>
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Active</div><div className="text-lg font-black text-emerald-400 tabular-nums">{empReport.activeCount}</div></div>
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">On Leave</div><div className="text-lg font-black text-amber-400 tabular-nums">{empReport.onLeaveCount}</div></div>
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Pending Leaves</div><div className="text-lg font-black text-cyan-400 tabular-nums">{empReport.pendingLeaves}</div></div>
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Avg KPI Score</div><div className="text-lg font-black text-white tabular-nums">{empReport.averagePerformance}%</div></div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {hasPerm('employees.manage') && (
              <form onSubmit={handleCreateEmployee} className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-2.5 text-xs">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-cyan-400" />
                  <span>Add Branch Employee</span>
                </h3>
                <p className="text-[11px] text-slate-400">Privileged roles (Founder, Super Admin, Company/Country/Branch Manager) are strictly blocked.</p>
                <input type="text" required placeholder="Full Name" value={newEmp.fullName} onChange={(e) => setNewEmp({ ...newEmp, fullName: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="email" required placeholder="Official Email" value={newEmp.email} onChange={(e) => setNewEmp({ ...newEmp, email: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="grid grid-cols-2 gap-2">
                  <input type="tel" required placeholder="Mobile" value={newEmp.mobile} onChange={(e) => setNewEmp({ ...newEmp, mobile: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                  <input type="text" placeholder="Emp Code (opt)" value={newEmp.employeeCode} onChange={(e) => setNewEmp({ ...newEmp, employeeCode: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono" />
                </div>
                <select value={newEmp.role} onChange={(e) => setNewEmp({ ...newEmp, role: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  {SAFE_BRANCH_ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <input type="text" placeholder="Department" value={newEmp.department} onChange={(e) => setNewEmp({ ...newEmp, department: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="text" placeholder="Shift Schedule" value={newEmp.shiftSchedule} onChange={(e) => setNewEmp({ ...newEmp, shiftSchedule: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="text" placeholder="Daily Operational Task" value={newEmp.dailyTask} onChange={(e) => setNewEmp({ ...newEmp, dailyTask: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="password" placeholder="Initial Strong Password (optional)" value={newEmp.password} onChange={(e) => setNewEmp({ ...newEmp, password: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black">
                  Create Branch Employee
                </button>
              </form>
            )}

            <div className={`${hasPerm('employees.manage') ? 'lg:col-span-2' : 'lg:col-span-3'} rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3`}>
              <h3 className="text-sm font-bold text-white">Branch Personnel Roster ({employees.length})</h3>
              <div className="space-y-3">
                {employees.map((emp) => (
                  <div key={emp.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white flex items-center gap-2 flex-wrap">
                          <span>{emp.full_name}</span>
                          <span className="px-2 py-0.5 rounded bg-slate-900 text-cyan-300 font-mono text-[10px]">{emp.employee_code}</span>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">{emp.job_position}</span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${emp.status === 'Active' ? 'bg-emerald-950 text-emerald-300' : emp.status === 'On Leave' ? 'bg-amber-950 text-amber-300' : 'bg-rose-950 text-rose-300'}`}>
                            {emp.status}
                          </span>
                        </div>
                        <div className="text-slate-400 mt-0.5">
                          Dept: {emp.department} • Shift: {emp.shift_schedule || 'Mon-Sat 09:00-18:00'} • Task: {emp.daily_task || 'Standard SLA'} ({emp.task_status || 'In Progress'})
                        </div>
                      </div>
                      {hasPerm('employees.manage') && (
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingEmp(emp);
                              setEmpEditForm({
                                employeeCode: emp.employee_code,
                                department: emp.department,
                                jobPosition: emp.job_position,
                                status: emp.status,
                                performanceScore: emp.performance_score,
                                shiftSchedule: emp.shift_schedule || 'Mon-Sat 09:00-18:00',
                                dailyTask: emp.daily_task || '',
                                taskStatus: emp.task_status || 'In Progress',
                              });
                            }}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold"
                          >
                            Edit / Task
                          </button>
                          <button
                            type="button"
                            onClick={() => setAttModalEmp(emp)}
                            className="px-2.5 py-1 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold"
                          >
                            Attendance
                          </button>
                          <button
                            type="button"
                            onClick={() => setLeaveModalEmp(emp)}
                            className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-800 font-semibold"
                          >
                            Leaves ({(emp.leave_requests || []).filter((l: any) => l.status === 'Pending').length})
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Employee Modals */}
          {editingEmp && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Update Employee &amp; Schedule: {editingEmp.full_name}</h4>
                <input type="text" placeholder="Employee Code" value={empEditForm.employeeCode} onChange={(e) => setEmpEditForm({ ...empEditForm, employeeCode: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono" />
                <input type="text" placeholder="Department" value={empEditForm.department} onChange={(e) => setEmpEditForm({ ...empEditForm, department: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <select value={empEditForm.status} onChange={(e) => setEmpEditForm({ ...empEditForm, status: e.target.value as any })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  <option value="Active">Active</option>
                  <option value="On Leave">On Leave</option>
                  <option value="Suspended">Suspended</option>
                </select>
                <input type="text" placeholder="Shift Schedule" value={empEditForm.shiftSchedule} onChange={(e) => setEmpEditForm({ ...empEditForm, shiftSchedule: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="text" placeholder="Daily Task" value={empEditForm.dailyTask} onChange={(e) => setEmpEditForm({ ...empEditForm, dailyTask: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2 pt-2">
                  <button type="button" onClick={() => setEditingEmp(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await api.updateBranchManagerEmployee(editingEmp.id, {
                          employeeCode: empEditForm.employeeCode,
                          department: empEditForm.department,
                          jobPosition: empEditForm.jobPosition,
                          status: empEditForm.status,
                          performanceScore: empEditForm.performanceScore,
                        });
                        await api.updateBranchEmployeeTaskSchedule(editingEmp.id, {
                          shiftSchedule: empEditForm.shiftSchedule,
                          dailyTask: empEditForm.dailyTask,
                          taskStatus: empEditForm.taskStatus,
                        });
                        setEditingEmp(null);
                        notify('Employee profile & shift task updated.');
                        await loadActiveTabData('employees');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-black"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {attModalEmp && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Record Attendance: {attModalEmp.full_name}</h4>
                <select value={attForm.status} onChange={(e) => setAttForm({ ...attForm, status: e.target.value as any })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  <option value="Present">Present</option>
                  <option value="Late">Late</option>
                  <option value="Half-Day">Half-Day</option>
                  <option value="Remote">Remote</option>
                  <option value="Absent">Absent</option>
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <input type="text" value={attForm.checkIn} onChange={(e) => setAttForm({ ...attForm, checkIn: e.target.value })} placeholder="Check-in (09:00)" className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                  <input type="text" value={attForm.checkOut} onChange={(e) => setAttForm({ ...attForm, checkOut: e.target.value })} placeholder="Check-out (18:00)" className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                </div>
                <div className="max-h-28 overflow-y-auto space-y-1">
                  {(attModalEmp.attendance || []).slice(0, 5).map((a: any, i: number) => (
                    <div key={i} className="p-2 rounded bg-slate-950 flex justify-between text-[11px]">
                      <span className="font-mono text-slate-300">{a.date}</span>
                      <span className="text-cyan-300 font-bold">{a.status}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setAttModalEmp(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Close</button>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await api.recordBranchEmployeeAttendance(attModalEmp.id, attForm);
                        setAttModalEmp(null);
                        notify('Daily attendance recorded.');
                        await loadActiveTabData('employees');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="px-4 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-black"
                  >
                    Mark Today
                  </button>
                </div>
              </div>
            </div>
          )}

          {leaveModalEmp && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Leave Requests: {leaveModalEmp.full_name}</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {(leaveModalEmp.leave_requests || []).map((lv: any) => (
                    <div key={lv.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white">{lv.type} ({lv.startDate} &rarr; {lv.endDate})</div>
                        <div className="text-slate-400">{lv.reason} • <strong className="text-amber-300">{lv.status}</strong></div>
                      </div>
                      {lv.status === 'Pending' && (
                        <div className="flex gap-1">
                          <button type="button" onClick={async () => { await api.updateBranchEmployeeLeave(leaveModalEmp.id, { leaveId: lv.id, action: 'Approved' }); setLeaveModalEmp(null); notify('Leave approved.'); await loadActiveTabData('employees'); }} className="px-2 py-1 rounded bg-emerald-600 text-white font-bold">Approve</button>
                          <button type="button" onClick={async () => { await api.updateBranchEmployeeLeave(leaveModalEmp.id, { leaveId: lv.id, action: 'Rejected' }); setLeaveModalEmp(null); notify('Leave rejected.'); await loadActiveTabData('employees'); }} className="px-2 py-1 rounded bg-rose-900 text-rose-200 font-bold">Reject</button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <div className="border-t border-slate-800 pt-2 space-y-2">
                  <div className="font-semibold text-slate-300">Log New Leave Request</div>
                  <input type="text" placeholder="Leave Type" value={leaveForm.leaveType} onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" placeholder="Reason" value={leaveForm.reason} onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                </div>
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setLeaveModalEmp(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Close</button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateBranchEmployeeLeave(leaveModalEmp.id, { action: 'create', ...leaveForm });
                      setLeaveModalEmp(null);
                      notify('Leave request logged.');
                      await loadActiveTabData('employees');
                    }}
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-black"
                  >
                    Submit Leave
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 4: VEHICLE INVENTORY & TRANSFER REQUESTS                       */}
      {/* ===================================================================== */}
      {bmTab === 'vehicles' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {hasPerm('vehicles.manage') && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await api.addBranchManagerVehicle(newVehicle);
                  notify(`Added VIN ${newVehicle.vin} to branch stock.`);
                  setNewVehicle({ ...newVehicle, vin: '', chassisNumber: '' });
                  await Promise.all([loadActiveTabData('vehicles'), loadDashboard()]);
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-2.5 text-xs"
            >
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>Add Branch EV Stock</span>
              </h3>
              <input type="text" required placeholder="VIN (e.g. LGXBYD360KHI0099)" value={newVehicle.vin} onChange={(e) => setNewVehicle({ ...newVehicle, vin: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono" />
              <input type="text" placeholder="Chassis Number" value={newVehicle.chassisNumber} onChange={(e) => setNewVehicle({ ...newVehicle, chassisNumber: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono" />
              <div className="grid grid-cols-2 gap-2">
                <input type="text" required placeholder="Model" value={newVehicle.model} onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="text" required placeholder="Variant" value={newVehicle.variant} onChange={(e) => setNewVehicle({ ...newVehicle, variant: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input type="text" placeholder="Color" value={newVehicle.color} onChange={(e) => setNewVehicle({ ...newVehicle, color: e.target.value })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="number" placeholder="Price" value={newVehicle.salePricePkr} onChange={(e) => setNewVehicle({ ...newVehicle, salePricePkr: Number(e.target.value) })} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <select value={newVehicle.stockState} onChange={(e) => setNewVehicle({ ...newVehicle, stockState: e.target.value as any })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                <option value="Available">Available</option>
                <option value="Reserved">Reserved</option>
                <option value="In Transit">In Transit</option>
                <option value="Sold">Sold</option>
              </select>
              <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black">Register Branch Vehicle</button>
            </form>
          )}

          <div className={`${hasPerm('vehicles.manage') ? 'lg:col-span-2' : 'lg:col-span-3'} rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3`}>
            <h3 className="text-sm font-bold text-white">Branch Inventory ({vehiclesData?.vehicles?.length || 0})</h3>
            <div className="space-y-2.5">
              {(vehiclesData?.vehicles || []).map((v: any) => (
                <div key={v.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-white flex items-center gap-2 flex-wrap">
                      <span>{v.model} {v.variant}</span>
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-900 text-cyan-300">{v.vin}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${v.stock_state === 'Available' ? 'bg-emerald-950 text-emerald-300' : v.stock_state === 'Reserved' ? 'bg-amber-950 text-amber-300' : 'bg-slate-800 text-slate-300'}`}>
                        {v.stock_state || v.delivery_status}
                      </span>
                    </div>
                    <div className="text-slate-400 mt-0.5">
                      Condition: {v.condition_grade || 'A+'} • {v.color} • Transfer: {v.transfer_request_status || 'None'}
                    </div>
                  </div>
                  {hasPerm('vehicles.manage') && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingVehicle(v);
                          setVehEditForm({
                            stockState: (v.stock_state || 'Available') as any,
                            conditionGrade: v.condition_grade || 'A+ Factory PDI Passed',
                            conditionNotes: v.condition_notes || '',
                            reservedCustomerName: v.reserved_customer_name || '',
                          });
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 text-white font-semibold"
                      >
                        Update Stock
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTransferModalVeh(v);
                          setTransferForm({ targetBranchId: vehiclesData?.siblingBranches?.[0]?.id || '', reason: '' });
                        }}
                        className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-800 font-semibold flex items-center gap-1"
                      >
                        <ArrowRightLeft className="w-3 h-3" /> Transfer Req
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {editingVehicle && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Update Inventory: {editingVehicle.vin}</h4>
                <select value={vehEditForm.stockState} onChange={(e) => setVehEditForm({ ...vehEditForm, stockState: e.target.value as any })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  <option value="Available">Available</option>
                  <option value="Reserved">Reserved</option>
                  <option value="Sold">Sold</option>
                  <option value="In Transit">In Transit</option>
                </select>
                <input type="text" placeholder="Condition Grade" value={vehEditForm.conditionGrade} onChange={(e) => setVehEditForm({ ...vehEditForm, conditionGrade: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <input type="text" placeholder="Reserved Customer Name (optional)" value={vehEditForm.reservedCustomerName} onChange={(e) => setVehEditForm({ ...vehEditForm, reservedCustomerName: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setEditingVehicle(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateBranchManagerVehicle(editingVehicle.id, vehEditForm);
                      setEditingVehicle(null);
                      notify('Vehicle stock updated.');
                      await Promise.all([loadActiveTabData('vehicles'), loadDashboard()]);
                    }}
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-black"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}

          {transferModalVeh && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Request Inter-Branch Transfer: {transferModalVeh.vin}</h4>
                <select value={transferForm.targetBranchId} onChange={(e) => setTransferForm({ ...transferForm, targetBranchId: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  {(vehiclesData?.siblingBranches || []).map((b: any) => (
                    <option key={b.id} value={b.id}>{b.name} ({b.code}) — {b.city}</option>
                  ))}
                </select>
                <input type="text" placeholder="Transfer justification" value={transferForm.reason} onChange={(e) => setTransferForm({ ...transferForm, reason: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setTransferModalVeh(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        await api.requestBranchVehicleTransfer(transferModalVeh.id, transferForm);
                        setTransferModalVeh(null);
                        notify('Vehicle transfer escalation submitted for higher approval.');
                        await loadActiveTabData('vehicles');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="px-4 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-black"
                  >
                    Submit Transfer Request
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 5: SALES & BOOKING MANAGEMENT                                  */}
      {/* ===================================================================== */}
      {bmTab === 'sales' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Branch Monthly Target</div>
              <div className="text-xl font-black text-white tabular-nums">{salesData?.targets?.achievedUnits || 0} / {salesData?.targets?.monthlyTargetUnits || 25} EVs</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Today&apos;s Bookings / Sales</div>
              <div className="text-xl font-black text-cyan-300 tabular-nums">{dailyReport?.bookingsCount || 0} Bookings • {dailyReport?.salesCount || 0} Orders</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
              <div className="text-slate-400">Today&apos;s Collected Value</div>
              <div className="text-xl font-black text-emerald-400 font-mono tabular-nums">{Number(dailyReport?.collectedAmountPkr || 0).toLocaleString()} {currency}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {hasPerm('sales.manage') && (
              <div className="space-y-4">
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      await api.createBranchBooking(newBooking);
                      notify('Branch booking registered.');
                      setNewBooking({ ...newBooking, customerName: '', notes: '' });
                      await loadActiveTabData('sales');
                    } catch (err: any) {
                      notify(err.message, 'err');
                    }
                  }}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
                >
                  <div className="font-bold text-white">Register Booking</div>
                  <input type="text" required placeholder="Customer Name" value={newBooking.customerName} onChange={(e) => setNewBooking({ ...newBooking, customerName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="Customer Phone" value={newBooking.customerPhone} onChange={(e) => setNewBooking({ ...newBooking, customerPhone: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="Vehicle Model" value={newBooking.vehicleModel} onChange={(e) => setNewBooking({ ...newBooking, vehicleModel: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <select value={newBooking.bookingType} onChange={(e) => setNewBooking({ ...newBooking, bookingType: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white">
                    <option value="Vehicle Reservation">Vehicle Reservation</option>
                    <option value="Test Drive">Test Drive</option>
                    <option value="Fleet Enquiry">Fleet Enquiry</option>
                  </select>
                  <button type="submit" className="w-full py-2 rounded-lg bg-cyan-500 text-slate-950 font-black">Register Booking</button>
                </form>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      const res = await api.createBranchSalesOrder(newOrder);
                      notify(`Sales Order ${res.orderNumber} created.`);
                      setNewOrder({ ...newOrder, customerName: '' });
                      await loadActiveTabData('sales');
                    } catch (err: any) {
                      notify(err.message, 'err');
                    }
                  }}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
                >
                  <div className="font-bold text-white">Create Sales Order</div>
                  <input type="text" required placeholder="Customer Name" value={newOrder.customerName} onChange={(e) => setNewOrder({ ...newOrder, customerName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="Phone" value={newOrder.customerPhone} onChange={(e) => setNewOrder({ ...newOrder, customerPhone: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="EV Model" value={newOrder.vehicleModel} onChange={(e) => setNewOrder({ ...newOrder, vehicleModel: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <div className="grid grid-cols-2 gap-2">
                    <input type="number" required placeholder="Total Price" value={newOrder.saleAmountPkr} onChange={(e) => setNewOrder({ ...newOrder, saleAmountPkr: Number(e.target.value) })} className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                    <input type="number" required placeholder="Deposit Paid" value={newOrder.paidAmountPkr} onChange={(e) => setNewOrder({ ...newOrder, paidAmountPkr: Number(e.target.value) })} className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  </div>
                  <button type="submit" className="w-full py-2 rounded-lg bg-emerald-500 text-slate-950 font-black">Create Order</button>
                </form>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      const res = await api.createBranchInvoice(newInvoice);
                      notify(`Invoice ${res.invoiceNumber} generated.`);
                      setNewInvoice({ ...newInvoice, customerName: '' });
                      await loadActiveTabData('sales');
                    } catch (err: any) {
                      notify(err.message, 'err');
                    }
                  }}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
                >
                  <div className="font-bold text-white">Generate Branch Invoice</div>
                  <input type="text" required placeholder="Customer Name" value={newInvoice.customerName} onChange={(e) => setNewInvoice({ ...newInvoice, customerName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="number" required placeholder="Subtotal" value={newInvoice.subtotal} onChange={(e) => setNewInvoice({ ...newInvoice, subtotal: Number(e.target.value) })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <button type="submit" className="w-full py-2 rounded-lg bg-amber-500 text-slate-950 font-black">Issue Invoice</button>
                </form>
              </div>
            )}

            <div className={`${hasPerm('sales.manage') ? 'lg:col-span-2' : 'lg:col-span-3'} space-y-4`}>
              <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Branch Bookings ({salesData?.bookings?.length || 0})</h3>
                <div className="space-y-2">
                  {(salesData?.bookings || []).map((bk: any) => (
                    <div key={bk.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white">{bk.customer_name} • {bk.vehicle_model} ({bk.booking_type})</div>
                        <div className="text-slate-400">{bk.preferred_date} {bk.preferred_time} • Status: <strong className="text-cyan-300">{bk.status}</strong></div>
                      </div>
                      {hasPerm('sales.manage') && (
                        <div className="flex gap-1">
                          {(['Confirmed', 'Completed', 'Cancelled'] as const).map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={async () => {
                                await api.updateBranchBooking(bk.id, { status: st });
                                notify(`Booking marked ${st}.`);
                                await loadActiveTabData('sales');
                              }}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Branch Sales Orders &amp; Deliveries ({salesData?.salesOrders?.length || 0})</h3>
                <div className="space-y-2">
                  {(salesData?.salesOrders || []).map((so: any) => (
                    <div key={so.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white">
                          <span className="font-mono text-cyan-300 mr-2">{so.order_number}</span>
                          {so.customer_name} — {so.vehicle_model}
                        </div>
                        <div className="text-slate-400">
                          Total: {Number(so.sale_amount_pkr).toLocaleString()} {currency} • Paid: {Number(so.paid_amount_pkr).toLocaleString()} • {so.payment_status} • Delivery: <strong className="text-emerald-300">{so.delivery_status}</strong>
                        </div>
                      </div>
                      {hasPerm('sales.manage') && so.delivery_status !== 'Delivered' && (
                        <button
                          type="button"
                          onClick={async () => {
                            await api.updateBranchSalesOrder(so.id, { deliveryStatus: 'Delivered', paymentStatus: 'Paid', paidAmountPkr: so.sale_amount_pkr });
                            notify(`Order ${so.order_number} marked Delivered.`);
                            await Promise.all([loadActiveTabData('sales'), loadDashboard()]);
                          }}
                          className="px-3 py-1 rounded-lg bg-emerald-600 text-white font-bold"
                        >
                          Mark Delivered
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 6: CUSTOMERS (CRM & AUDITED PII MASKING)                       */}
      {/* ===================================================================== */}
      {bmTab === 'customers' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/70 border border-slate-800 text-xs">
            <div className="text-slate-300">
              Customer CNIC and phone numbers are masked by default for branch privacy compliance.
            </div>
            {hasPerm('customers.pii.reveal') && (
              <button
                type="button"
                onClick={async () => {
                  const next = !piiRevealed;
                  setPiiRevealed(next);
                  const res = await api.getBranchManagerCustomers(next);
                  setCustomersData(res);
                  if (next) notify('Revealed customer PII (action written to branch audit log).');
                }}
                className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 ${piiRevealed ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-cyan-300 border border-cyan-500/40'}`}
              >
                {piiRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{piiRevealed ? 'Mask Customer PII' : 'Reveal Sensitive PII (Audited)'}</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {hasPerm('customers.manage') && (
              <div className="space-y-4">
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      await api.createBranchCustomer(newCustomer);
                      notify('Customer registered to branch.');
                      setNewCustomer({ fullName: '', email: '', mobile: '+92 300 ', cnicOrId: '' });
                      await loadActiveTabData('customers');
                    } catch (err: any) {
                      notify(err.message, 'err');
                    }
                  }}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
                >
                  <div className="font-bold text-white">Register Branch Customer</div>
                  <input type="text" required placeholder="Full Name" value={newCustomer.fullName} onChange={(e) => setNewCustomer({ ...newCustomer, fullName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="email" required placeholder="Email" value={newCustomer.email} onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="tel" required placeholder="Mobile" value={newCustomer.mobile} onChange={(e) => setNewCustomer({ ...newCustomer, mobile: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" placeholder="CNIC / National ID" value={newCustomer.cnicOrId} onChange={(e) => setNewCustomer({ ...newCustomer, cnicOrId: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono" />
                  <button type="submit" className="w-full py-2 rounded-lg bg-cyan-500 text-slate-950 font-black">Register Customer</button>
                </form>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    try {
                      await api.createBranchCrmRecord(newCrm);
                      notify(`Logged ${newCrm.recordType} ticket.`);
                      setNewCrm({ ...newCrm, customerName: '', subject: '', details: '' });
                      await loadActiveTabData('customers');
                    } catch (err: any) {
                      notify(err.message, 'err');
                    }
                  }}
                  className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
                >
                  <div className="font-bold text-white">Log Enquiry / Test Drive / Complaint</div>
                  <select value={newCrm.recordType} onChange={(e) => setNewCrm({ ...newCrm, recordType: e.target.value as any })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white">
                    <option value="Enquiry">Enquiry</option>
                    <option value="Test Drive">Test Drive</option>
                    <option value="Follow-Up">Follow-Up</option>
                    <option value="Complaint">Complaint</option>
                    <option value="Feedback">Feedback</option>
                  </select>
                  <input type="text" required placeholder="Customer Name" value={newCrm.customerName} onChange={(e) => setNewCrm({ ...newCrm, customerName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="Phone" value={newCrm.customerPhone} onChange={(e) => setNewCrm({ ...newCrm, customerPhone: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <input type="text" required placeholder="Subject" value={newCrm.subject} onChange={(e) => setNewCrm({ ...newCrm, subject: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <textarea rows={2} required placeholder="Details" value={newCrm.details} onChange={(e) => setNewCrm({ ...newCrm, details: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                  <button type="submit" className="w-full py-2 rounded-lg bg-emerald-500 text-slate-950 font-black">Save CRM Ticket</button>
                </form>
              </div>
            )}

            <div className={`${hasPerm('customers.manage') ? 'lg:col-span-2' : 'lg:col-span-3'} space-y-4`}>
              <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Branch Customers ({customersData?.customers?.length || 0})</h3>
                <div className="space-y-2">
                  {(customersData?.customers || []).map((c: any) => (
                    <div key={c.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap justify-between gap-2">
                      <div>
                        <div className="font-bold text-white">{c.fullName} ({c.email})</div>
                        <div className="text-slate-400 font-mono">Mobile: {c.mobile} • ID/CNIC: {c.cnicOrId}</div>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-900 text-cyan-300 font-semibold self-center">
                        {c.purchaseCount} Orders
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">CRM Enquiries, Complaints &amp; Follow-Ups ({customersData?.crmRecords?.length || 0})</h3>
                <div className="space-y-2">
                  {(customersData?.crmRecords || []).map((r: any) => (
                    <div key={r.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white">
                          <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 text-[10px] mr-2">{r.record_type}</span>
                          {r.subject} — {r.customer_name}
                        </div>
                        <div className="text-slate-400">{r.details} • Phone: {r.customer_phone} • Status: <strong className="text-amber-300">{r.status}</strong></div>
                      </div>
                      {hasPerm('customers.manage') && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingCrm(r);
                            setCrmEditForm({ status: r.status, resolutionNotes: r.resolution_notes || '' });
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 text-white font-semibold"
                        >
                          Update
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {editingCrm && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Update CRM Ticket</h4>
                <select value={crmEditForm.status} onChange={(e) => setCrmEditForm({ ...crmEditForm, status: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                  <option value="Open">Open</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Closed">Closed</option>
                </select>
                <textarea rows={3} placeholder="Resolution Notes" value={crmEditForm.resolutionNotes} onChange={(e) => setCrmEditForm({ ...crmEditForm, resolutionNotes: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setEditingCrm(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateBranchCrmRecord(editingCrm.id, crmEditForm);
                      setEditingCrm(null);
                      notify('CRM ticket updated.');
                      await loadActiveTabData('customers');
                    }}
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-black"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}

          <AdminCustomerGovernancePanel scope="branch-manager" />
          <AdminVerificationApprovalPanel portalLabel="Branch Manager" />
          <AccountSecurityCenter />
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 7: DEALERSHIP MANAGEMENT                                       */}
      {/* ===================================================================== */}
      {bmTab === 'dealerships' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Authorized Branch Dealerships ({dealersData?.dealerships?.length || 0})</h3>
            <div className="space-y-3">
              {(dealersData?.dealerships || []).map((d: any) => (
                <div key={d.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{d.name}</span>
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-slate-900 text-cyan-300">{d.code}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${d.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'}`}>
                        {d.status}
                      </span>
                    </div>
                    <div className="text-slate-400 mt-0.5">
                      Manager: {d.manager_name} • Bays: {d.service_bays} • Techs: {d.active_techs} • Stock: {d.dealer_vehicle_count} EVs • Jobs: {d.service_job_count}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCommDealer(d)}
                      className="px-3 py-1.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" /> Message Dealer
                    </button>
                    {d.status === 'Pending Approval' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.requestBranchDealerApproval(d.id, 'Site inspection verified by Branch Manager.');
                          notify(`Submitted approval escalation for ${d.name}.`);
                          await loadActiveTabData('dealerships');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-black"
                      >
                        Escalate Approval
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {commDealer && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">Send Dispatch to {commDealer.name}</h4>
                <input type="text" placeholder="Subject" value={commForm.subject} onChange={(e) => setCommForm({ ...commForm, subject: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <textarea rows={3} placeholder="Message" value={commForm.message} onChange={(e) => setCommForm({ ...commForm, message: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setCommDealer(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.communicateBranchDealership(commDealer.id, commForm);
                      setCommDealer(null);
                      setCommForm({ subject: '', message: '' });
                      notify('Dealer communication dispatched.');
                    }}
                    className="px-4 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-black"
                  >
                    Send Dispatch
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-slate-800">
            <AdminDealerGovernancePanel scope="branch-manager" />
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 8: BRANCH FINANCE & REFUND APPROVALS                           */}
      {/* ===================================================================== */}
      {bmTab === 'finance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Paid Revenue</div><div className="text-lg font-black text-emerald-400 font-mono tabular-nums">{Number(financeData?.summary?.paidTotal || 0).toLocaleString()} {currency}</div></div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Pending Receivables</div><div className="text-lg font-black text-amber-400 font-mono tabular-nums">{Number(financeData?.summary?.pendingTotal || 0).toLocaleString()} {currency}</div></div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Branch Expenses</div><div className="text-lg font-black text-rose-400 font-mono tabular-nums">{Number(financeData?.summary?.expensesTotal || 0).toLocaleString()} {currency}</div></div>
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Net Branch Cashflow</div><div className="text-lg font-black text-cyan-300 font-mono tabular-nums">{Number(financeData?.summary?.netCashflow || 0).toLocaleString()} {currency}</div></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await api.createBranchExpense(newExpense);
                  notify('Branch operating expense recorded.');
                  setNewExpense({ ...newExpense, title: '' });
                  await Promise.all([loadActiveTabData('finance'), loadDashboard()]);
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-2.5 text-xs"
            >
              <h3 className="text-sm font-bold text-white">Record Branch Expense</h3>
              <input type="text" required placeholder="Category (e.g. Showroom Utilities)" value={newExpense.category} onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <input type="text" required placeholder="Expense Description" value={newExpense.title} onChange={(e) => setNewExpense({ ...newExpense, title: e.target.value })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <input type="number" required placeholder="Amount" value={newExpense.amountPkr} onChange={(e) => setNewExpense({ ...newExpense, amountPkr: Number(e.target.value) })} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-black">Record Expense</button>
            </form>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Branch Invoices &amp; Refund Governance</h3>
              <div className="space-y-2">
                {(financeData?.invoices || []).map((inv: any) => (
                  <div key={inv.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        <span className="font-mono text-cyan-300 mr-2">{inv.invoice_number}</span>
                        {inv.customer_name} — {Number(inv.total_amount).toLocaleString()} {inv.currency}
                      </div>
                      <div className="text-slate-400">{inv.item_category} • {inv.issued_date} • Status: <strong className={inv.status === 'Paid' ? 'text-emerald-300' : inv.status === 'Refunded' ? 'text-rose-300' : 'text-amber-300'}>{inv.status}</strong></div>
                    </div>
                    {inv.status === 'Paid' && (
                      <div className="flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => { setRefundTargetInv({ inv, mode: 'request' }); setRefundReason(''); }}
                          className="px-2.5 py-1 rounded-lg bg-amber-950 text-amber-300 border border-amber-800 font-semibold"
                        >
                          Request Refund Approval
                        </button>
                        {hasPerm('finance.refund.manage') && (
                          <button
                            type="button"
                            onClick={() => { setRefundTargetInv({ inv, mode: 'direct' }); setRefundReason(''); }}
                            className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-semibold"
                          >
                            Execute Direct Refund
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {refundTargetInv && (
            <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
              <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-3 text-xs">
                <h4 className="font-bold text-white text-sm">
                  {refundTargetInv.mode === 'direct' ? 'Execute Authorized Refund' : 'Submit Refund Approval Request'}: {refundTargetInv.inv.invoice_number}
                </h4>
                <textarea rows={3} required placeholder="Reason for refund" value={refundReason} onChange={(e) => setRefundReason(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => setRefundTargetInv(null)} className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        if (refundTargetInv.mode === 'direct') {
                          await api.refundBranchInvoice(refundTargetInv.inv.id, refundReason || 'Authorized direct branch refund');
                          notify('Invoice refunded.');
                        } else {
                          await api.requestBranchInvoiceRefund(refundTargetInv.inv.id, refundReason || 'Customer requested refund');
                          notify('Financial refund escalation submitted to Primary Owner.');
                        }
                        setRefundTargetInv(null);
                        await loadActiveTabData('finance');
                      } catch (err: any) {
                        notify(err.message, 'err');
                      }
                    }}
                    className="px-4 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-black"
                  >
                    Confirm
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 9: SERVICE, WARRANTY & SPARE PARTS                             */}
      {/* ===================================================================== */}
      {bmTab === 'service' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-4">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  const res = await api.createBranchServiceJob(newServiceJob);
                  notify(`Service ticket ${res.ticketNumber} scheduled.`);
                  setNewServiceJob({ ...newServiceJob, vin: '', customerName: '' });
                  await loadActiveTabData('service');
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
            >
              <div className="font-bold text-white flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-cyan-400" /> Schedule Service Appointment</div>
              <input type="text" required placeholder="Vehicle VIN" value={newServiceJob.vin} onChange={(e) => setNewServiceJob({ ...newServiceJob, vin: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono" />
              <input type="text" required placeholder="Customer Name" value={newServiceJob.customerName} onChange={(e) => setNewServiceJob({ ...newServiceJob, customerName: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
              <input type="text" required placeholder="Service Type" value={newServiceJob.serviceType} onChange={(e) => setNewServiceJob({ ...newServiceJob, serviceType: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
              <input type="date" placeholder="Service Reminder Date" value={newServiceJob.reminderDate} onChange={(e) => setNewServiceJob({ ...newServiceJob, reminderDate: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
              <button type="submit" className="w-full py-2 rounded-lg bg-cyan-500 text-slate-950 font-black">Create Service Ticket</button>
            </form>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  await api.createBranchSparePart(newSparePart);
                  notify(`Added spare part ${newSparePart.sku}.`);
                  setNewSparePart({ ...newSparePart, sku: '', name: '' });
                  await loadActiveTabData('service');
                } catch (err: any) {
                  notify(err.message, 'err');
                }
              }}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 p-4 space-y-2 text-xs"
            >
              <div className="font-bold text-white flex items-center gap-1.5"><Package className="w-3.5 h-3.5 text-emerald-400" /> Add Branch Spare Part</div>
              <input type="text" required placeholder="SKU (e.g. BYD-BRK-04)" value={newSparePart.sku} onChange={(e) => setNewSparePart({ ...newSparePart, sku: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white font-mono" />
              <input type="text" required placeholder="Part Name" value={newSparePart.name} onChange={(e) => setNewSparePart({ ...newSparePart, name: e.target.value })} className="w-full rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
              <div className="grid grid-cols-2 gap-2">
                <input type="number" required placeholder="Qty" value={newSparePart.stockQuantity} onChange={(e) => setNewSparePart({ ...newSparePart, stockQuantity: Number(e.target.value) })} className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
                <input type="number" required placeholder="Unit Cost" value={newSparePart.unitCostPkr} onChange={(e) => setNewSparePart({ ...newSparePart, unitCostPkr: Number(e.target.value) })} className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-1.5 text-white" />
              </div>
              <button type="submit" className="w-full py-2 rounded-lg bg-emerald-500 text-slate-950 font-black">Add Spare Part</button>
            </form>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Service Tickets &amp; Reminders ({serviceData?.serviceJobs?.length || 0})</h3>
              <div className="space-y-2">
                {(serviceData?.serviceJobs || []).map((sj: any) => (
                  <div key={sj.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        <span className="font-mono text-cyan-300 mr-2">{sj.ticket_number}</span>
                        {sj.model} ({sj.vin}) — {sj.service_type}
                      </div>
                      <div className="text-slate-400">
                        {sj.customer_name} • Date: {sj.scheduled_date} • Reminder: {sj.reminder_date || 'Not Set'} • Status: <strong className="text-amber-300">{sj.status}</strong>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {sj.status !== 'In Progress' && sj.status !== 'Completed' && (
                        <button type="button" onClick={async () => { await api.updateBranchServiceJob(sj.id, { status: 'In Progress' }); await loadActiveTabData('service'); }} className="px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 font-bold">Start Repair</button>
                      )}
                      {sj.status !== 'Completed' && (
                        <button type="button" onClick={async () => { await api.updateBranchServiceJob(sj.id, { status: 'Completed' }); await loadActiveTabData('service'); }} className="px-2.5 py-1 rounded bg-emerald-600 text-white font-bold">Complete</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Branch Spare Parts &amp; Warranty Claims</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(serviceData?.spareParts || []).map((sp: any) => (
                  <div key={sp.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex justify-between items-center">
                    <div>
                      <div className="font-bold text-white">{sp.name}</div>
                      <div className="text-slate-400 font-mono">{sp.sku} • Bin {sp.location_bin}</div>
                    </div>
                    <span className={`px-2 py-1 rounded font-bold tabular-nums ${sp.stock_quantity <= sp.reorder_level ? 'bg-rose-950 text-rose-300' : 'bg-emerald-950 text-emerald-300'}`}>
                      Qty: {sp.stock_quantity}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 10: REPORTS & MULTI-SHEET EXCEL / CSV / PRINT EXPORTS          */}
      {/* ===================================================================== */}
      {bmTab === 'reports' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setReportPeriod(p)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize ${reportPeriod === p ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-300 border border-slate-800'}`}
                >
                  {p}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 print:hidden">
              {hasPerm('reports.export') && (
                <>
                  <button
                    type="button"
                    disabled={exporting}
                    onClick={() => handleExport('xlsx')}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" /> Export Excel (.xlsx)
                  </button>
                  <button
                    type="button"
                    disabled={exporting}
                    onClick={() => handleExport('csv')}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-bold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" /> Export CSV
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" /> Print / PDF
              </button>
            </div>
          </div>

          {reportData?.summary && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Employees / Avg KPI</div><div className="text-lg font-black text-white tabular-nums">{reportData.summary.employeesTotal} ({reportData.summary.avgAttendanceScore}%)</div></div>
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Vehicles (Avail/Res/Sold)</div><div className="text-lg font-black text-cyan-300 tabular-nums">{reportData.summary.availableVehicles} / {reportData.summary.reservedVehicles} / {reportData.summary.soldVehicles}</div></div>
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Sales Orders / Bookings</div><div className="text-lg font-black text-white tabular-nums">{reportData.summary.salesOrdersCount} / {reportData.summary.bookingsTotal}</div></div>
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800"><div className="text-slate-400">Net Branch Contribution</div><div className="text-lg font-black text-emerald-400 font-mono tabular-nums">{Number(reportData.summary.netContributionPkr || 0).toLocaleString()} {currency}</div></div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE 11: PERMISSIONS, SESSIONS, ESCALATIONS & AUDIT LOGS            */}
      {/* ===================================================================== */}
      {bmTab === 'security' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>Assigned Branch Binding &amp; Server-Enforced RBAC Matrix</span>
            </h3>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
              Assigned Branch: <strong className="text-white">{branch?.name}</strong> (<code className="text-cyan-300">{branch?.id}</code>) • Only the Primary Owner can reassign branches or modify these permissions.
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(dashboard?.canonicalPermissions || []).map((perm: string) => {
                const active = (currentUser.permissions || []).includes(perm);
                return (
                  <span
                    key={perm}
                    className={`px-2.5 py-1 rounded-md font-mono text-[11px] border ${active ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-slate-950 text-slate-500 border-slate-800'}`}
                  >
                    {active ? '✓ ' : '✗ '}{perm}
                  </span>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-cyan-400" />
                <span>Active Branch Manager Sessions ({bmSessions.length})</span>
              </h3>
              <div className="space-y-2">
                {bmSessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">{s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}</div>
                      <div className="text-slate-400 font-mono">IP: {s.ip_address} • Exp: {s.expires_at?.slice(0, 16).replace('T', ' ')}</div>
                    </div>
                    {!s.is_current && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.revokeBranchManagerSession(s.id);
                          setBmSessions((p) => p.filter((x) => x.id !== s.id));
                          notify('Session revoked.');
                        }}
                        className="px-2.5 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <span>Login History &amp; Submitted Escalations</span>
              </h3>
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {(auditData?.escalations || []).map((esc: any) => (
                  <div key={esc.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">{esc.request_type}: {esc.title}</div>
                      <div className="text-slate-400">{esc.created_at?.slice(0, 16).replace('T', ' ')}</div>
                    </div>
                    <span className={`px-2 py-0.5 rounded h-fit font-bold ${esc.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : esc.status === 'Rejected' ? 'bg-rose-950 text-rose-300' : 'bg-amber-950 text-amber-300'}`}>
                      {esc.status}
                    </span>
                  </div>
                ))}
                {bmLoginHistory.slice(0, 8).map((lh: any) => (
                  <div key={lh.id} className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between font-mono">
                    <span className="text-slate-300">{lh.ip_address}</span>
                    <span className="text-slate-500">{lh.created_at?.slice(0, 19).replace('T', ' ')}</span>
                    <span className={lh.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{lh.success ? 'OK' : 'FAIL'}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {bmTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {bmTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
