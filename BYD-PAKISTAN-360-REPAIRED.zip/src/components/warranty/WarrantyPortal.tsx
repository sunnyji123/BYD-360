import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  AlertCircle,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  Plus,
  Upload,
  Calendar,
  Check,
  User,
  Car,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { WarrantyClaim, WarrantyClaimStatus, Vehicle } from '../../types';

export const WarrantyPortal: React.FC = () => {
  const { currentUser, currentRole } = useApp();
  const [claims, setClaims] = useState<WarrantyClaim[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedClaim, setSelectedClaim] = useState<WarrantyClaim | null>(null);

  // New Claim Modal
  const [newClaimModalOpen, setNewClaimModalOpen] = useState(false);
  const [vinInput, setVinInput] = useState('');
  const [modelInput, setModelInput] = useState('BYD Seal');
  const [categoryInput, setCategoryInput] = useState<WarrantyClaim['componentCategory']>('Blade Battery Pack');
  const [faultCodeInput, setFaultCodeInput] = useState('BMS_BAL_ALERT_01');
  const [descInput, setDescInput] = useState('');
  const [amountInput, setAmountInput] = useState(95000);
  const [claimSuccess, setClaimSuccess] = useState(false);

  // Review state
  const [reviewNotesInput, setReviewNotesInput] = useState('');

  const canReview = ['Super Admin', 'Company Management', 'Service Manager', 'Dealer Manager'].includes(currentRole);

  useEffect(() => {
    const load = () => {
      setClaims(db.getWarrantyClaims());
      setVehicles(db.getVehicles());
    };
    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  const handleCreateClaim = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vinInput || !descInput) return;

    const newClaim: WarrantyClaim = {
      id: `war_clm_${Date.now()}`,
      claimNumber: `BYD-WAR-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      vin: vinInput.toUpperCase(),
      vehicleModel: modelInput,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      dealershipName: 'Mega Motor Flagship 3S — Clifton',
      componentCategory: categoryInput,
      issueDescription: descInput,
      faultCode: faultCodeInput,
      submissionDate: new Date().toISOString().split('T')[0],
      status: 'Submitted',
      claimAmountPkr: Number(amountInput),
      attachments: ['uploaded_diagnostic_report.pdf'],
    };

    db.addWarrantyClaim(newClaim);
    setClaimSuccess(true);
    setTimeout(() => {
      setClaimSuccess(false);
      setNewClaimModalOpen(false);
      setDescInput('');
      setVinInput('');
    }, 1800);
  };

  const handleUpdateStatus = (claimId: string, newStatus: WarrantyClaimStatus, approvedAmount?: number) => {
    const target = claims.find((c) => c.id === claimId);
    if (!target) return;

    target.status = newStatus;
    if (approvedAmount !== undefined) {
      target.approvedAmountPkr = approvedAmount;
    }
    if (reviewNotesInput) {
      target.reviewNotes = reviewNotesInput;
    }

    db.updateWarrantyClaim(target);
    db.logAudit({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentRole,
      action: 'WARRANTY_REVIEW_DECISION',
      module: 'Warranty Engine',
      targetId: `${target.claimNumber} -> ${newStatus}`,
    });
    setReviewNotesInput('');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Manufacturer Protection</span>
          <h2 className="text-2xl font-black text-white">BYD Official Warranty & Claim Center</h2>
          <p className="text-xs text-slate-400">
            8-Year Blade Battery & Drive Unit Policy • 6-Year Bumper-to-Bumper Warranty
          </p>
        </div>

        <button
          onClick={() => setNewClaimModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500 transition"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>File Warranty Claim</span>
        </button>
      </div>

      {/* Warranty Policy Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
            <ShieldCheck className="w-4 h-4" />
            <span>Blade Battery & Motor</span>
          </div>
          <p className="text-lg font-black text-white mt-1">8 Years / 160,000 km</p>
          <p className="text-[11px] text-slate-400 mt-1">Guaranteed &gt;70% capacity retention with zero deductible.</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
            <Car className="w-4 h-4" />
            <span>Whole Vehicle Bumper-to-Bumper</span>
          </div>
          <p className="text-lg font-black text-white mt-1">6 Years / 150,000 km</p>
          <p className="text-[11px] text-slate-400 mt-1">Comprehensive electrical, mechanical, and DiLink display coverage.</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
            <Clock className="w-4 h-4" />
            <span>Claim Resolution SLA</span>
          </div>
          <p className="text-lg font-black text-white mt-1">48 Hours Target</p>
          <p className="text-[11px] text-slate-400 mt-1">Fast-track factory authorization for all registered Pakistani owners.</p>
        </div>
      </div>

      {/* Claims List & Approval Interface */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Warranty Claims Register ({claims.length})</span>
          </h4>
          <span className="text-xs text-slate-400">
            {canReview ? 'Review Permissions Active' : 'Owner Tracking Mode'}
          </span>
        </div>

        <div className="space-y-4">
          {claims.map((claim) => (
            <div
              key={claim.id}
              className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-4 text-xs"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                      {claim.claimNumber}
                    </span>
                    <span className="font-bold text-white text-sm">{claim.vehicleModel}</span>
                    <span className="text-slate-400">({claim.componentCategory})</span>
                  </div>
                  <p className="text-slate-400 mt-1">
                    VIN: <strong className="text-slate-300 font-mono">{claim.vin}</strong> • Submitted: {claim.submissionDate} by {claim.customerName}
                  </p>
                </div>

                <div className="text-right">
                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                    claim.status === 'Approved'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : claim.status === 'Rejected'
                      ? 'bg-rose-950 text-rose-400 border border-rose-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {claim.status}
                  </span>
                  <p className="font-bold text-slate-200 mt-1">
                    ₨ {claim.claimAmountPkr.toLocaleString()} PKR
                  </p>
                </div>
              </div>

              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800 text-slate-300">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Issue Description & Fault Code:</span>
                <p>"{claim.issueDescription}"</p>
                {claim.faultCode && (
                  <span className="inline-block mt-1.5 px-2 py-0.5 rounded bg-slate-950 text-cyan-400 font-mono text-[10px]">
                    Fault Code: {claim.faultCode}
                  </span>
                )}
              </div>

              {claim.reviewNotes && (
                <div className="p-3 bg-cyan-950/20 rounded-lg border border-cyan-800/40 text-cyan-300">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 block mb-0.5">Authorizer Review Note:</span>
                  <p>{claim.reviewNotes}</p>
                </div>
              )}

              {/* Review Actions for Managers / Admins */}
              {canReview && claim.status !== 'Approved' && claim.status !== 'Rejected' && (
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <input
                    type="text"
                    placeholder="Enter approval note or technical reasoning..."
                    value={reviewNotesInput}
                    onChange={(e) => setReviewNotesInput(e.target.value)}
                    className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 text-xs text-white"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdateStatus(claim.id, 'Approved', claim.claimAmountPkr)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve Claim</span>
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(claim.id, 'Rejected', 0)}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* New Claim Modal */}
      {newClaimModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Submit Warranty Claim</h3>
            <p className="text-xs text-slate-400 mb-4">Official warranty claim submission under Mega Motor warranty coverage.</p>

            {claimSuccess ? (
              <div className="py-6 text-center space-y-2">
                <Check className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-white">Warranty Claim Submitted!</h4>
                <p className="text-xs text-slate-300">
                  Claim registered in system. Factory service engineer will inspect logs within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleCreateClaim} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">VIN / Chassis Number</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. LGXCE43C5R0108924"
                    value={vinInput}
                    onChange={(e) => setVinInput(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 font-mono text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Vehicle Model</label>
                    <select
                      value={modelInput}
                      onChange={(e) => setModelInput(e.target.value)}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    >
                      <option value="BYD Seal">BYD Seal</option>
                      <option value="BYD Atto 3">BYD Atto 3</option>
                      <option value="BYD Sealion 6">BYD Sealion 6</option>
                      <option value="BYD Shark 6">BYD Shark 6</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Component Category</label>
                    <select
                      value={categoryInput}
                      onChange={(e) => setCategoryInput(e.target.value as WarrantyClaim['componentCategory'])}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    >
                      <option value="Blade Battery Pack">Blade Battery Pack (LFP)</option>
                      <option value="Drive Motor / Inverter">Drive Motor / Inverter</option>
                      <option value="BMS Controller">BMS Controller</option>
                      <option value="On-Board Charger">On-Board Charger (OBC)</option>
                      <option value="Infotainment System">Infotainment / DiLink Display</option>
                      <option value="Chassis / Airbag">Chassis / Airbag System</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Fault / Error Code (if displayed)</label>
                  <input
                    type="text"
                    placeholder="e.g. BMS_ERR_04 or OBC_COMM_WARN"
                    value={faultCodeInput}
                    onChange={(e) => setFaultCodeInput(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 font-mono text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Issue Description</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Describe exact symptoms, charging behavior, or mechanical noises..."
                    value={descInput}
                    onChange={(e) => setDescInput(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-white"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setNewClaimModalOpen(false)}
                    className="px-4 py-2 text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-white shadow-md shadow-cyan-500/20"
                  >
                    Submit Claim
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
