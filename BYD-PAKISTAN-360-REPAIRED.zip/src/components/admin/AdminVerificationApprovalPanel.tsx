import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  Search,
  RefreshCw,
  CheckCircle2,
  XCircle,
  FileText,
  Download,
  Lock,
  Unlock,
  AlertCircle,
  Eye,
  Mail,
  History,
  KeyRound,
  Monitor,
  Settings,
  ShieldCheck,
  Save,
  LogOut,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  portalLabel: string;
  initialSubTab?: SecuritySubTab;
}

type SecuritySubTab = 'queue' | 'logins' | 'sessions' | 'rbac' | 'settings' | 'audit';

export const AdminVerificationApprovalPanel: React.FC<Props> = ({ portalLabel, initialSubTab = 'queue' }) => {
  const [subTab, setSubTab] = useState<SecuritySubTab>(initialSubTab);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  // Login History & KPIs + filters
  const [loginLogs, setLoginLogs] = useState<any[]>([]);
  const [loginStats, setLoginStats] = useState<any>(null);
  const [loginQuery, setLoginQuery] = useState('');
  const [loginRoleFilter, setLoginRoleFilter] = useState('');
  const [loginStatusFilter, setLoginStatusFilter] = useState('');
  const [loginFromDate, setLoginFromDate] = useState('');
  const [loginToDate, setLoginToDate] = useState('');

  // Active Sessions
  const [sessions, setSessions] = useState<any[]>([]);

  // RBAC 6-Role x Module x Action Matrix
  const [rbacRoles, setRbacRoles] = useState<string[]>([]);
  const [rbacModules, setRbacModules] = useState<string[]>([]);
  const [rbacMatrix, setRbacMatrix] = useState<any[]>([]);
  const [selectedRbacRole, setSelectedRbacRole] = useState('Super Admin');
  const [canEditRbac, setCanEditRbac] = useState(false);
  const [savingRbac, setSavingRbac] = useState(false);

  // OTP / 2FA / Password Recovery Policy Settings
  const [secPolicy, setSecPolicy] = useState<any>(null);
  const [smtpConfigured, setSmtpConfigured] = useState(false);
  const [smsConfigured, setSmsConfigured] = useState(false);
  const [canEditSettings, setCanEditSettings] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);

  // Selected Account Verification Detail
  const [detail, setDetail] = useState<any>(null);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [roleFilter, setRoleFilter] = useState('');
  const [verFilter, setVerFilter] = useState('');
  const [searchQ, setSearchQ] = useState('');
  const [reasonDraft, setReasonDraft] = useState('');
  const [notesDraft, setNotesDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState<{ text: string; ok: boolean } | null>(null);

  const flash = (text: string, ok = true) => {
    setNotice({ text, ok });
    setTimeout(() => setNotice(null), 6000);
  };

  const loadLoginActivity = useCallback(async () => {
    try {
      const logRes = await api.getAdminVerificationLoginActivity({
        q: loginQuery || undefined,
        role: loginRoleFilter || undefined,
        status: loginStatusFilter || undefined,
        fromDate: loginFromDate || undefined,
        toDate: loginToDate || undefined,
      });
      setLoginLogs(logRes.logs || []);
      setLoginStats(logRes.stats || null);
    } catch {
      setLoginLogs([]);
    }
  }, [loginQuery, loginRoleFilter, loginStatusFilter, loginFromDate, loginToDate]);

  const loadAccounts = useCallback(async () => {
    setLoading(true);
    try {
      const [accRes, audRes, sessRes, rbacRes, setRes] = await Promise.all([
        api.getAdminVerificationAccounts({
          role: roleFilter || undefined,
          verificationStatus: verFilter || undefined,
          q: searchQ || undefined,
        }),
        api.getAdminVerificationAuditLogs().catch(() => ({ logs: [] })),
        api.getAdminVerificationSessions().catch(() => ({ sessions: [] })),
        api.getAdminRbacMatrix().catch(() => null),
        api.getAdminSecuritySettings().catch(() => null),
      ]);
      setAccounts(accRes.accounts || []);
      setSummary(accRes.summary || null);
      setAuditLogs(audRes.logs || []);
      setSessions(sessRes.sessions || []);

      if (rbacRes) {
        setRbacRoles(rbacRes.roles || []);
        setRbacModules(rbacRes.modules || []);
        setRbacMatrix(rbacRes.matrix || []);
        setCanEditRbac(Boolean(rbacRes.canEditMatrix));
      }
      if (setRes) {
        setSecPolicy(setRes.securityPolicy || null);
        setSmtpConfigured(Boolean(setRes.smtpConfigured));
        setSmsConfigured(Boolean(setRes.smsConfigured));
        setCanEditSettings(Boolean(setRes.canEdit));
      }
      await loadLoginActivity();
    } catch (err: any) {
      flash(err?.message || 'Unable to load security and verification data.', false);
    } finally {
      setLoading(false);
    }
  }, [roleFilter, verFilter, searchQ, loadLoginActivity]);

  useEffect(() => {
    loadAccounts();
  }, [loadAccounts]);

  const inspectAccount = async (userId: string) => {
    setSelectedUserId(userId);
    try {
      const res = await api.getAdminVerificationAccountDetail(userId);
      setDetail(res);
    } catch (err: any) {
      flash(err?.message || 'Unable to load account verification details.', false);
    }
  };

  const applyDecision = async (
    userId: string,
    action:
      | 'mark_under_review'
      | 'approve'
      | 'reject'
      | 'request_documents'
      | 'suspend'
      | 'reactivate'
      | 'verify_email_manual',
    documentId?: string
  ) => {
    try {
      const res = await api.submitAdminVerificationDecision(userId, {
        action,
        reason: reasonDraft.trim() || undefined,
        notes: notesDraft.trim() || undefined,
        documentId,
      });
      flash(res.message);
      setReasonDraft('');
      setNotesDraft('');
      await loadAccounts();
      if (selectedUserId === userId) {
        await inspectAccount(userId);
      }
    } catch (err: any) {
      flash(err?.message || 'Verification decision failed.', false);
    }
  };

  const downloadDocument = async (docId: string, fileName: string) => {
    try {
      const res = await fetch(`/api/verification/documents/${docId}/download`, { credentials: 'include' });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || `HTTP ${res.status}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      flash(err?.message || 'Unable to download verification document.', false);
    }
  };

  const toggleRbacCell = (
    roleKey: string,
    moduleKey: string,
    field: 'can_view' | 'can_create' | 'can_edit' | 'can_delete' | 'can_approve'
  ) => {
    if (roleKey === 'Founder / CEO' || !canEditRbac) return;
    setRbacMatrix((prev) =>
      prev.map((row) =>
        row.role_key === roleKey && row.module_key === moduleKey && !row.is_locked
          ? { ...row, [field]: row[field] ? 0 : 1 }
          : row
      )
    );
  };

  const saveRbacChanges = async () => {
    const rowsForRole = rbacMatrix.filter((r) => r.role_key === selectedRbacRole && !r.is_locked);
    if (rowsForRole.length === 0) return;
    setSavingRbac(true);
    try {
      const res = await api.updateAdminRbacMatrix(
        rowsForRole.map((r) => ({
          roleKey: r.role_key,
          moduleKey: r.module_key,
          canView: Boolean(r.can_view),
          canCreate: Boolean(r.can_create),
          canEdit: Boolean(r.can_edit),
          canDelete: Boolean(r.can_delete),
          canApprove: Boolean(r.can_approve),
        }))
      );
      flash(res.message);
      await loadAccounts();
    } catch (err: any) {
      flash(err?.message || 'Failed to update RBAC permission matrix.', false);
    } finally {
      setSavingRbac(false);
    }
  };

  const saveSecuritySettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!secPolicy) return;
    setSavingSettings(true);
    try {
      const res = await api.updateAdminSecuritySettings(secPolicy);
      setSecPolicy(res.securityPolicy);
      flash(res.message);
    } catch (err: any) {
      flash(err?.message || 'Unable to save enterprise security policy.', false);
    } finally {
      setSavingSettings(false);
    }
  };

  const selectedRoleMatrix = rbacMatrix.filter((r) => r.role_key === selectedRbacRole);

  return (
    <div className="rounded-xl bg-slate-900 border border-slate-800 p-5 sm:p-6 space-y-5 text-xs">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-cyan-400">
            Security &amp; Settings Console · {portalLabel}
          </div>
          <h3 className="text-base font-bold text-white mt-0.5">
            Verification Governance, RBAC Matrix, OTP &amp; 2FA Policy, Sessions &amp; Login Audit
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex flex-wrap rounded-lg bg-slate-950 border border-slate-800 p-0.5 gap-0.5">
            {[
              { id: 'queue', label: 'Verification Queue', Icon: ShieldCheck },
              { id: 'logins', label: 'Login History', Icon: History },
              { id: 'sessions', label: 'Active Sessions', Icon: Monitor },
              { id: 'rbac', label: 'RBAC Roles', Icon: KeyRound },
              { id: 'settings', label: 'OTP & 2FA Policy', Icon: Settings },
              { id: 'audit', label: 'Audit Logs', Icon: ShieldAlert },
            ].map((t) => {
              const Icon = t.Icon;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSubTab(t.id as SecuritySubTab)}
                  className={`px-2.5 py-1.5 rounded-md font-semibold transition flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                    subTab === t.id ? 'bg-cyan-500 text-slate-950' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            onClick={loadAccounts}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {notice && (
        <div
          className={`p-3 rounded-lg border flex items-center gap-2 ${
            notice.ok
              ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
              : 'bg-rose-950/40 border-rose-700/60 text-rose-200'
          }`}
        >
          {notice.ok ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
          <span>{notice.text}</span>
        </div>
      )}

      {subTab === 'queue' && summary && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {[
            { label: 'Scoped Accounts', val: summary.totalAccounts ?? 0 },
            { label: 'Pending Verify', val: summary.pendingVerification ?? 0 },
            { label: 'Under Review', val: summary.underReview ?? 0 },
            { label: 'Verified KYC', val: summary.verifiedAccounts ?? 0 },
            { label: 'Rejected / Suspended', val: summary.rejectedOrSuspended ?? 0 },
            { label: 'Vault Documents', val: summary.totalDocuments ?? 0 },
          ].map((k) => (
            <div key={k.label} className="p-3 rounded-lg bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">{k.label}</div>
              <div className="text-base font-black font-mono tabular-nums text-white mt-0.5">{k.val}</div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 1: VERIFICATION QUEUE */}
      {subTab === 'queue' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQ}
                onChange={(e) => setSearchQ(e.target.value)}
                placeholder="Search name, email, ID, city..."
                className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white"
              />
            </div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">All Scoped Roles</option>
              <option value="Customer">Customer</option>
              <option value="Dealer">Dealer</option>
              <option value="Employee">Employee</option>
              <option value="Branch Manager">Branch Manager</option>
              <option value="Country Manager">Country Manager</option>
              <option value="Company Admin">Company Admin</option>
              <option value="Super Admin">Super Admin</option>
            </select>
            <select
              value={verFilter}
              onChange={(e) => setVerFilter(e.target.value)}
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">All Verification States</option>
              <option value="Not Submitted">Not Submitted</option>
              <option value="Pending Verification">Pending Verification</option>
              <option value="Under Review">Under Review</option>
              <option value="Verified">Verified</option>
              <option value="Rejected">Rejected</option>
              <option value="Suspended">Suspended</option>
            </select>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Account</th>
                  <th className="py-2.5 px-3">Role · Scope</th>
                  <th className="py-2.5 px-3">Email · Mobile</th>
                  <th className="py-2.5 px-3">Docs</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {accounts.map((a) => (
                  <tr
                    key={a.id}
                    className={`hover:bg-slate-900/70 transition ${selectedUserId === a.id ? 'bg-slate-900' : ''}`}
                  >
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{a.full_name}</div>
                      <div className="font-mono text-[11px] text-slate-400">{a.email}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      <div>{a.role}</div>
                      <div className="font-mono text-[11px] text-slate-500">
                        {a.country_id || 'GLOBAL'} {a.company_name ? `· ${a.company_name}` : ''}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px]">
                      <span className={a.email_verified ? 'text-emerald-400' : 'text-amber-300'}>
                        {a.email_verified ? 'Email OK' : 'Email Pending'}
                      </span>
                      <span className="text-slate-600 mx-1">·</span>
                      <span className={a.mobile_verified ? 'text-emerald-400' : 'text-slate-400'}>
                        {a.mobile_verified ? 'SMS OK' : 'SMS Unverified'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-200">{a.document_count ?? 0}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{a.status}</div>
                      <div
                        className={`text-[11px] font-semibold ${
                          a.verification_status === 'Verified'
                            ? 'text-emerald-400'
                            : a.verification_status === 'Rejected' || a.verification_status === 'Suspended'
                              ? 'text-rose-400'
                              : 'text-amber-300'
                        }`}
                      >
                        {a.verification_status}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        type="button"
                        onClick={() => inspectAccount(a.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-cyan-500 text-cyan-300 font-semibold inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Review</span>
                      </button>
                    </td>
                  </tr>
                ))}
                {accounts.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-slate-500">
                      No scoped accounts match your current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {detail?.account && (
            <div className="p-4 sm:p-5 rounded-xl bg-slate-950 border border-slate-700 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="text-[11px] font-mono text-cyan-400">
                    {detail.account.id} · {detail.account.role} · MFA {detail.mfa?.totp_enabled ? 'Enabled' : 'Off'}
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    {detail.account.full_name} ({detail.account.email})
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedUserId(null);
                    setDetail(null);
                  }}
                  className="text-slate-400 hover:text-white font-semibold"
                >
                  Close Review
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-2.5">
                  <input
                    type="text"
                    value={reasonDraft}
                    onChange={(e) => setReasonDraft(e.target.value)}
                    placeholder="Decision reason (required for Reject, Suspend, or Request Docs)"
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    value={notesDraft}
                    onChange={(e) => setNotesDraft(e.target.value)}
                    placeholder="Internal compliance review notes (optional)"
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                  />
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => applyDecision(detail.account.id, 'mark_under_review')}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 font-semibold"
                    >
                      Mark Under Review
                    </button>
                    <button
                      type="button"
                      onClick={() => applyDecision(detail.account.id, 'approve')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold inline-flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Approve &amp; Verify</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => applyDecision(detail.account.id, 'request_documents')}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold"
                    >
                      Request Additional Docs
                    </button>
                    <button
                      type="button"
                      onClick={() => applyDecision(detail.account.id, 'reject')}
                      className="px-3 py-1.5 rounded-lg bg-rose-950 border border-rose-700 text-rose-200 font-bold inline-flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                    {!detail.account.email_verified && (
                      <button
                        type="button"
                        onClick={() => applyDecision(detail.account.id, 'verify_email_manual')}
                        className="px-3 py-1.5 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-200 font-semibold inline-flex items-center gap-1"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Verify Email Status</span>
                      </button>
                    )}
                    {detail.account.status !== 'Suspended' ? (
                      <button
                        type="button"
                        onClick={() => applyDecision(detail.account.id, 'suspend')}
                        className="px-3 py-1.5 rounded-lg bg-rose-900/60 border border-rose-700 text-rose-100 font-bold inline-flex items-center gap-1"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>Suspend</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => applyDecision(detail.account.id, 'reactivate')}
                        className="px-3 py-1.5 rounded-lg bg-emerald-950 border border-emerald-700 text-emerald-200 font-bold inline-flex items-center gap-1"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="font-bold text-white mb-1.5 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Submitted Private Documents ({detail.documents?.length || 0})</span>
                    </div>
                    <div className="space-y-1.5 max-h-32 overflow-y-auto">
                      {(detail.documents || []).map((doc: any) => (
                        <div key={doc.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <div className="font-semibold text-white truncate">{doc.title}</div>
                            <div className="font-mono text-[10px] text-slate-400">
                              {doc.doc_type} · {doc.review_status}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => downloadDocument(doc.id, doc.original_filename)}
                            className="px-2 py-1 rounded bg-slate-950 border border-slate-700 text-cyan-300 font-semibold flex items-center gap-1 shrink-0"
                          >
                            <Download className="w-3 h-3" />
                            <span>View</span>
                          </button>
                        </div>
                      ))}
                      {(!detail.documents || detail.documents.length === 0) && (
                        <div className="text-slate-500">No verification documents submitted yet.</div>
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="font-bold text-white mb-1.5 flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5 text-amber-400" />
                      <span>Approval History ({detail.approvalHistory?.length || 0})</span>
                    </div>
                    <div className="space-y-1 max-h-28 overflow-y-auto">
                      {(detail.approvalHistory || []).map((h: any) => (
                        <div key={h.id} className="p-2 rounded bg-slate-900 border border-slate-800 text-[11px]">
                          <div className="flex justify-between font-semibold">
                            <span className="text-cyan-300">{h.action}</span>
                            <span className="font-mono text-slate-500 tabular-nums">{h.created_at?.slice(0, 16)}</span>
                          </div>
                          <div className="text-slate-300">
                            By {h.actor_name} ({h.actor_role}) · {h.previous_status} → {h.new_status}
                          </div>
                          {h.reason && <div className="text-amber-300 mt-0.5">Reason: {h.reason}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: LOGIN HISTORY & KPI SUMMARY */}
      {subTab === 'logins' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {[
              { label: 'Total Attempts', val: loginStats?.totalAttempts ?? loginLogs.length, cls: 'text-white' },
              { label: 'Successful Logins', val: loginStats?.successfulLogins ?? loginLogs.filter((l) => l.success).length, cls: 'text-emerald-400' },
              { label: 'Failed Attempts', val: loginStats?.failedLogins ?? loginLogs.filter((l) => !l.success).length, cls: 'text-rose-400' },
              { label: 'Suspicious Alerts', val: loginStats?.suspiciousAlerts ?? loginLogs.filter((l) => l.suspicious).length, cls: 'text-amber-300' },
              { label: 'Active Sessions', val: loginStats?.activeSessions ?? sessions.length, cls: 'text-cyan-300' },
            ].map((k) => (
              <div key={k.label} className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-[11px] text-slate-400">{k.label}</div>
                <div className={`text-base font-black font-mono tabular-nums mt-0.5 ${k.cls}`}>{k.val}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
            <input
              type="text"
              value={loginQuery}
              onChange={(e) => setLoginQuery(e.target.value)}
              placeholder="Search user ID, name, IP, device..."
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <select
              value={loginRoleFilter}
              onChange={(e) => setLoginRoleFilter(e.target.value)}
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">All Roles</option>
              <option value="Founder / Owner">Founder / CEO</option>
              <option value="Super Admin">Super Admin</option>
              <option value="Company Admin">Company Admin</option>
              <option value="Country Manager">Country Manager</option>
              <option value="Branch Manager">Branch Manager</option>
              <option value="Employee">Employee</option>
              <option value="Dealer">Dealer</option>
              <option value="Customer">Customer</option>
            </select>
            <select
              value={loginStatusFilter}
              onChange={(e) => setLoginStatusFilter(e.target.value)}
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">All Statuses</option>
              <option value="success">Successful Only</option>
              <option value="failed">Failed Only</option>
              <option value="suspicious">Suspicious Alerts</option>
            </select>
            <input
              type="date"
              value={loginFromDate}
              onChange={(e) => setLoginFromDate(e.target.value)}
              aria-label="From Date"
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
            />
            <input
              type="date"
              value={loginToDate}
              onChange={(e) => setLoginToDate(e.target.value)}
              aria-label="To Date"
              className="rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
            />
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Account · ID</th>
                  <th className="py-2.5 px-3">Role</th>
                  <th className="py-2.5 px-3">Device · Browser · IP</th>
                  <th className="py-2.5 px-3">Outcome · MFA</th>
                  <th className="py-2.5 px-3">Login · Logout / Reason</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {loginLogs.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-900/60">
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-white">{l.account_name || l.identifier}</div>
                      <div className="font-mono text-[11px] text-slate-400">
                        {l.resolved_email || l.identifier} {l.user_id ? `· ${l.user_id}` : ''}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{l.role || l.subject_type}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-300">
                      <div>{l.device_name || 'Workstation'} · {l.browser_name || 'Browser'}</div>
                      <div className="text-slate-400">IP {l.ip_address}</div>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px]">
                      <div className={l.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                        {l.success ? 'SUCCESS' : 'FAILED'} {l.mfa_method ? `· ${l.mfa_method}` : ''}
                      </div>
                      {l.failure_reason && <div className="text-rose-300">{l.failure_reason}</div>}
                      {Boolean(l.suspicious) && (
                        <div className="text-amber-300">ALERT: {l.suspicious_reason || 'Unusual device/IP'}</div>
                      )}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400 tabular-nums">
                      <div>In: {l.created_at?.slice(0, 19).replace('T', ' ')}</div>
                      <div>
                        Out: {l.logout_at ? `${l.logout_at.slice(0, 19).replace('T', ' ')} (${l.termination_reason || 'ended'})` : l.success ? 'Active / Open' : '—'}
                      </div>
                    </td>
                  </tr>
                ))}
                {loginLogs.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-500">
                      No login history records match the active filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBTAB 3: ACTIVE SESSIONS MANAGEMENT */}
      {subTab === 'sessions' && (
        <div className="space-y-3">
          <div className="text-slate-400">
            Live authenticated sessions within your governance scope ({sessions.length} active). Administrators can terminate anomalous sessions immediately.
          </div>
          <div className="space-y-2 max-h-[28rem] overflow-y-auto">
            {sessions.map((s) => (
              <div key={s.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="font-semibold text-white">
                    {s.full_name || s.user_id} · <span className="text-cyan-300">{s.role}</span>{' '}
                    {s.is_current ? <span className="text-emerald-400 font-mono text-[11px]">(Current Session)</span> : null}
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 tabular-nums">
                    {s.email || s.user_id} · {s.device_name} ({s.browser_name}) · IP {s.ip_address}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 tabular-nums">
                    Last Active: {s.last_activity_at?.slice(0, 19).replace('T', ' ')} · Idle Expiry: {s.idle_expires_at?.slice(0, 19).replace('T', ' ') || s.expires_at?.slice(0, 19)}
                  </div>
                </div>
                {!s.is_current && (
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const res = await api.terminateAdminVerificationSession(s.id);
                        flash(res.message);
                        await loadAccounts();
                      } catch (err: any) {
                        flash(err?.message || 'Unable to terminate session.', false);
                      }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-950 border border-rose-800 text-rose-200 font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Terminate Session</span>
                  </button>
                )}
              </div>
            ))}
            {sessions.length === 0 && (
              <div className="py-6 text-center text-slate-500 bg-slate-950 rounded-lg border border-slate-800">
                No active sessions available in scope.
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 4: RBAC ROLE & PERMISSION MATRIX */}
      {subTab === 'rbac' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap gap-1.5">
              {rbacRoles.map((role) => (
                <button
                  key={role}
                  type="button"
                  onClick={() => setSelectedRbacRole(role)}
                  className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap shrink-0 ${
                    selectedRbacRole === role
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-950 border border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
            {canEditRbac && selectedRbacRole !== 'Founder / CEO' && (
              <button
                type="button"
                disabled={savingRbac}
                onClick={saveRbacChanges}
                className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold flex items-center gap-1.5 whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingRbac ? 'Saving Matrix...' : `Save ${selectedRbacRole} Permissions`}</span>
              </button>
            )}
          </div>

          {selectedRbacRole === 'Founder / CEO' && (
            <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/60 text-emerald-200">
              Primary Owner (Founder / CEO) permissions are system-locked and immutable. No administrator or backend action can revoke or alter Founder privileges.
            </div>
          )}

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">Enterprise Module</th>
                  <th className="py-2.5 px-3 text-center">View</th>
                  <th className="py-2.5 px-3 text-center">Create</th>
                  <th className="py-2.5 px-3 text-center">Edit</th>
                  <th className="py-2.5 px-3 text-center">Delete</th>
                  <th className="py-2.5 px-3 text-center">Approve</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {rbacModules.map((mod) => {
                  const row = selectedRoleMatrix.find((r) => r.module_key === mod) || {
                    role_key: selectedRbacRole,
                    module_key: mod,
                    can_view: 0,
                    can_create: 0,
                    can_edit: 0,
                    can_delete: 0,
                    can_approve: 0,
                    is_locked: 1,
                  };
                  const disabled = Boolean(row.is_locked) || selectedRbacRole === 'Founder / CEO' || !canEditRbac;
                  return (
                    <tr key={mod} className="hover:bg-slate-900/60">
                      <td className="py-2.5 px-3 font-semibold text-white">{mod}</td>
                      {(['can_view', 'can_create', 'can_edit', 'can_delete', 'can_approve'] as const).map((field) => (
                        <td key={field} className="py-2.5 px-3 text-center">
                          <input
                            type="checkbox"
                            disabled={disabled}
                            checked={Boolean(row[field])}
                            onChange={() => toggleRbacCell(selectedRbacRole, mod, field)}
                            className="w-4 h-4 accent-cyan-400 cursor-pointer disabled:cursor-not-allowed"
                          />
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBTAB 5: OTP, 2FA & PASSWORD RECOVERY POLICY SETTINGS */}
      {subTab === 'settings' && secPolicy && (
        <form onSubmit={saveSecuritySettings} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px]">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">SMTP Email Dispatcher</span>
              <span className={smtpConfigured ? 'text-emerald-400 font-bold' : 'text-amber-300 font-bold'}>
                {smtpConfigured ? 'Configured (Live SMTP)' : 'Not Configured (Dev Outbox Fallback)'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">SMS OTP Gateway (Twilio / Webhook)</span>
              <span className={smsConfigured ? 'text-emerald-400 font-bold' : 'text-amber-300 font-bold'}>
                {smsConfigured ? 'Configured (Live SMS)' : 'Not Configured (SMS Endpoint 503 Guard)'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              { key: 'otpExpiryMinutes', label: 'OTP Expiry Window (Minutes)', min: 2, max: 60 },
              { key: 'otpMaxAttempts', label: 'Max Invalid OTP Attempts', min: 3, max: 10 },
              { key: 'otpCooldownSeconds', label: 'OTP Resend Cooldown (Seconds)', min: 30, max: 600 },
              { key: 'forgotPasswordCooldownSeconds', label: 'Forgot Password Cooldown (Seconds)', min: 30, max: 600 },
              { key: 'passwordReuseLimit', label: 'Password Reuse History Limit', min: 1, max: 12 },
              { key: 'sessionTimeoutMinutes', label: 'Session Max Lifetime (Minutes)', min: 15, max: 1440 },
              { key: 'idleTimeoutMinutes', label: 'Inactivity Idle Timeout (Minutes)', min: 5, max: 240 },
              { key: 'maxFailedLoginAttempts', label: 'Brute-Force Lockout Threshold', min: 3, max: 15 },
              { key: 'lockoutMinutes', label: 'Account Lockout Duration (Minutes)', min: 5, max: 120 },
            ].map((item) => (
              <label key={item.key} className="p-3 rounded-lg bg-slate-950 border border-slate-800 block space-y-1.5">
                <span className="text-[11px] font-semibold text-slate-300 block">{item.label}</span>
                <input
                  type="number"
                  min={item.min}
                  max={item.max}
                  disabled={!canEditSettings}
                  value={secPolicy[item.key] ?? item.min}
                  onChange={(e) => setSecPolicy({ ...secPolicy, [item.key]: Number(e.target.value) })}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 text-white font-mono tabular-nums disabled:opacity-60"
                />
              </label>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-200 font-semibold">Enforce Mandatory 2FA for All Admin Portals</span>
              <input
                type="checkbox"
                disabled={!canEditSettings}
                checked={secPolicy.enforce2FAForAdmins !== false}
                onChange={(e) => setSecPolicy({ ...secPolicy, enforce2FAForAdmins: e.target.checked })}
                className="w-4 h-4 accent-cyan-400"
              />
            </label>
            <label className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-200 font-semibold">Primary Owner 2FA Lock (Always Enforced)</span>
              <input type="checkbox" checked disabled className="w-4 h-4 accent-emerald-400" />
            </label>
          </div>

          {canEditSettings ? (
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={savingSettings}
                className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5 disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingSettings ? 'Saving Policy...' : 'Save Enterprise Security Policy'}</span>
              </button>
            </div>
          ) : (
            <div className="text-slate-400 text-[11px]">
              Read-only view: Only the Founder / CEO or Super Admin with settings authorization can update global security policies.
            </div>
          )}
        </form>
      )}

      {/* SUBTAB 6: SECURITY AUDIT LOGS */}
      {subTab === 'audit' && (
        <div className="space-y-1.5 max-h-96 overflow-y-auto">
          {auditLogs.map((l) => (
            <div key={l.id} className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="font-semibold text-white">
                  <span className={l.severity === 'CRITICAL' ? 'text-rose-400' : l.severity === 'WARNING' ? 'text-amber-300' : 'text-cyan-300'}>
                    [{l.severity}] {l.action}
                  </span>{' '}
                  · {l.category}
                </div>
                <div className="text-slate-300 mt-0.5">{l.details}</div>
              </div>
              <div className="text-right font-mono text-[11px] text-slate-400 shrink-0 tabular-nums">
                <div>{l.actor_name} ({l.actor_role})</div>
                <div>{l.ip_address} · {l.created_at?.slice(0, 19).replace('T', ' ')}</div>
              </div>
            </div>
          ))}
          {auditLogs.length === 0 && (
            <div className="py-6 text-center text-slate-500 flex items-center justify-center gap-2">
              <ShieldAlert className="w-4 h-4" />
              <span>No scoped security audit events recorded yet.</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
