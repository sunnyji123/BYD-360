import express, { Request, Response } from 'express';
import multer from 'multer';
import mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import { GoogleGenAI } from '@google/genai';
import {
  sqlite,
  generateSecureToken,
  getSystemSetting,
  setSystemSetting,
  logOwnerAudit,
  nowIso,
} from './db';
import { AuthContext, requireAuth, requireFounder } from './auth';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB limit
});

const SUPPORTED_MODELS = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'] as const;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim().length < 10) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Offline fallback AI responses when GEMINI_API_KEY is not configured on server
function getFallbackAIResponse(message: string, language: string, biMetrics: any): string {
  const msg = message.toLowerCase();
  const isUrdu = language === 'ur' || /[\u0600-\u06FF]/.test(message);
  const isRomanUrdu = /^(kya|kaise|kahan|kab|kaun|kyun|kitna|hai|hain|nahi|haan|theek|acha|bura|BYD|car|gadi|seal|atto|sealion|shark|tang|han|dolphin|battery|charge|service|warranty|price|daam|booking|test drive|showroom|dealer)/i.test(message);

  // Price inquiries
  if (msg.includes('price') || msg.includes('daam') || msg.includes('cost') || msg.includes('qeemat')) {
    if (isUrdu) {
      return `BYD gaariyon ki qeematain:\n• BYD Dolphin: ~PKR 5,500,000\n• BYD Atto 3: ~PKR 7,200,000\n• BYD Seal: ~PKR 9,800,000\n• BYD Sealion 6: ~PKR 12,500,000\n• BYD Tang: ~PKR 15,000,000\n• BYD Han: ~PKR 18,500,000\n\nNote: Ye takhmina qeematain hain. Asli qeemat ke liye apne qareebi BYD showroom se rabta karein.`;
    }
    return `BYD Vehicle Prices (Estimated PKR):\n• BYD Dolphin: ~PKR 5,500,000\n• BYD Atto 3: ~PKR 7,200,000\n• BYD Seal: ~PKR 9,800,000\n• BYD Sealion 6: ~PKR 12,500,000\n• BYD Tang: ~PKR 15,000,000\n• BYD Han: ~PKR 18,500,000\n\nNote: These are estimated prices. Contact your nearest BYD showroom for actual pricing.`;
  }

  // Battery inquiries
  if (msg.includes('battery') || msg.includes('blade') || msg.includes('soh') || msg.includes('charge')) {
    if (isUrdu) {
      return `BYD Blade Battery (LFP) Features:\n• 8 saal ya 160,000 km warranty\n• SoH/SoC monitoring available\n• GB/T DC, CCS2, Type 2 AC charging support\n• 60kW-180kW DC fast charging\n• Thermal management system\n\nBattery health check ke liye service appointment book karein.`;
    }
    return `BYD Blade Battery (LFP) Features:\n• 8-year / 160,000 km warranty\n• SoH/SoC health monitoring\n• GB/T DC, CCS2 Combo, Type 2 AC charging\n• 60kW-180kW DC fast charging\n• Advanced thermal management\n\nBook a service appointment for battery health check.`;
  }

  // Service inquiries
  if (msg.includes('service') || msg.includes('servicing') || msg.includes('maintenance')) {
    if (isUrdu) {
      return `BYD Service Options:\n• Routine Maintenance\n• Major Service\n• Battery Check\n• Software Update\n• Tire Rotation\n• Brake Service\n• Warranty Repair\n\nService appointment book karne ke liye "Service & Warranty" section mein jayen.`;
    }
    return `BYD Service Options:\n• Routine Maintenance\n• Major Service\n• Battery Check\n• Software Update\n• Tire Rotation\n• Brake Service\n• Warranty Repair\n\nGo to "Service & Warranty Management" section to book a service appointment.`;
  }

  // Warranty inquiries
  if (msg.includes('warranty') || msg.includes('guarantee')) {
    if (isUrdu) {
      return `BYD Warranty Policy:\n• Vehicle: 6 saal ya 150,000 km\n• Blade Battery: 8 saal ya 160,000 km\n• Motor & Controller: 8 saal ya 150,000 km\n\nWarranty claim file karne ke liye "Service & Warranty" section use karein.`;
    }
    return `BYD Warranty Policy:\n• Vehicle: 6-year / 150,000 km\n• Blade Battery: 8-year / 160,000 km\n• Motor & Controller: 8-year / 150,000 km\n\nUse "Service & Warranty Management" section to file a warranty claim.`;
  }

  // Booking inquiries
  if (msg.includes('booking') || msg.includes('test drive') || msg.includes('reserve')) {
    if (isUrdu) {
      return `BYD Booking Options:\n• New Vehicle Booking\n• Test Drive Booking\n• Service Appointment\n\nBooking ke liye "Sales & Booking Management" section mein jayen.`;
    }
    return `BYD Booking Options:\n• New Vehicle Booking\n• Test Drive Booking\n• Service Appointment\n\nGo to "Sales & Booking Management" section to make a booking.`;
  }

  // Showroom/dealer inquiries
  if (msg.includes('showroom') || msg.includes('dealer') || msg.includes('location') || msg.includes('kahan')) {
    if (isUrdu) {
      return `BYD Showrooms & Dealers:\n• Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Peshawar, Multan\n\nQareebi showroom dhundhne ke liye "Showroom Locator" use karein.`;
    }
    return `BYD Showrooms & Dealers:\n• Lahore, Karachi, Islamabad, Rawalpindi, Faisalabad, Peshawar, Multan\n\nUse "Showroom Locator" to find your nearest BYD showroom.`;
  }

  // Model inquiries
  if (msg.includes('model') || msg.includes('seal') || msg.includes('atto') || msg.includes('sealion') || msg.includes('shark') || msg.includes('tang') || msg.includes('han') || msg.includes('dolphin')) {
    if (isUrdu) {
      return `BYD Models Available:\n• BYD Dolphin (Compact EV)\n• BYD Atto 3 (Compact SUV)\n• BYD Seal (Sedan)\n• BYD Sealion 6 (SUV)\n• BYD Shark 6 (Pickup)\n• BYD Tang (SUV)\n• BYD Han (Sedan)\n\nKisi model ke bare mein tafseelat ke liye bataiye.`;
    }
    return `BYD Models Available:\n• BYD Dolphin (Compact EV)\n• BYD Atto 3 (Compact SUV)\n• BYD Seal (Sedan)\n• BYD Sealion 6 (SUV)\n• BYD Shark 6 (Pickup)\n• BYD Tang (SUV)\n• BYD Han (Sedan)\n\nAsk me about any specific model for details.`;
  }

  // General greeting
  if (msg.includes('hello') || msg.includes('hi') || msg.includes('salam') || msg.includes('assalam') || msg.includes('namaste')) {
    if (isUrdu) {
      return `Assalam-o-Alaikum! Main BYD AI hoon. Main aapki kaise madad kar sakta hoon?\n\nMain yeh bataya sakta hoon:\n• BYD gaariyon ki qeematain\n• Battery aur charging maloomat\n• Service aur warranty\n• Booking aur test drive\n• Showroom locations\n\nAap kya jaanna chahte hain?`;
    }
    return `Hello! I'm BYD AI, your assistant for BYD PAKISTAN 360. How can I help you today?\n\nI can help you with:\n• BYD vehicle prices\n• Battery & charging information\n• Service & warranty\n• Booking & test drive\n• Showroom locations\n\nWhat would you like to know?`;
  }

  // Default response
  if (isUrdu) {
    return `Main BYD AI hoon. Main aapki madad karne ki koshish kar raha hoon lekin live AI responses ke liye server par GEMINI_API_KEY configure hona zaroori hai.\n\nAbhi main aapko yeh bata sakta hoon:\n• BYD gaariyon ki qeematain\n• Battery aur charging maloomat\n• Service aur warranty details\n• Booking aur test drive\n• Showroom locations\n\nAap kya jaanna chahte hain?`;
  }
  return `I'm BYD AI, your assistant for BYD PAKISTAN 360. Live AI responses require GEMINI_API_KEY to be configured on the server.\n\nFor now, I can help you with:\n• BYD vehicle prices\n• Battery & charging information\n• Service & warranty details\n• Booking & test drive\n• Showroom locations\n\nWhat would you like to know?`;
}

async function generateWithResilience(
  client: GoogleGenAI,
  preferredModel: string,
  contents: any,
  systemInstruction: string
): Promise<{ text: string; modelUsed: string }> {
  const fallbackModel = preferredModel === 'gemini-4-hydrogen' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';
  const candidateModels = [preferredModel, fallbackModel];
  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const response = await Promise.race([
        client.models.generateContent({
          model,
          contents,
          config: { systemInstruction },
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`503 UNAVAILABLE: ${model} request timed out`)), 12000)
        ),
      ]);
      return {
        text: response.text || '',
        modelUsed: model,
      };
    } catch (err: any) {
      lastError = err;
      const msg = String(err?.message || '');
      const status = err?.status || err?.code;
      const isTransient =
        status === 503 ||
        status === 429 ||
        msg.includes('503') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('high demand') ||
        msg.includes('timed out');
      if (!isTransient) {
        throw err;
      }
    }
  }
  throw lastError;
}

const BYD_AI_BASE_INSTRUCTION = `
You are "BYD AI", the official Enterprise Automotive & Electric Vehicle Intelligence Assistant for BYD PAKISTAN 360.
Founder & CEO / Primary Owner of BYD PAKISTAN 360: Intekhab Alam.

Core Expertise:
- BYD Electric & Super Hybrid Vehicles: BYD Seal (82.5 kWh Blade Battery, CTB, 570 km WLTP), BYD Atto 3 (60.48 kWh, 420 km WLTP), BYD Sealion 6 (DM-i Super Hybrid, 1,100+ km), BYD Shark 6 (DMO), BYD Tang, BYD Dolphin, BYD Han.
- Blade Battery (LFP) engineering, thermal management, SoH/SoC diagnostics, 8-Year / 160,000 km warranty policy.
- Charging Standards: GB/T DC, CCS2 Combo DC, 7kW AC Wallbox, 60kW-180kW Motorway (M-2, M-1, M-9) DC Fast Charging corridors.
- Multilingual fluency: Respond naturally in English, Urdu (اردو), or Roman Urdu depending on the language the user writes in.

Strict Grounding & Security Rules:
1. Only state live business counts, revenue totals, vehicles, bookings, or customer metrics that appear verbatim inside AUTHORIZED_DB_METRICS in your context. NEVER invent numbers or fabricate internal telemetry.
2. Respect strict tenant & role boundaries: you may only discuss data provided inside AUTHORIZED_DB_METRICS for the signed-in user's permitted scope.
3. Sensitive Operations Rule: You must NEVER directly approve companies, suspend users, approve warranty payouts, or transfer vehicle titles automatically. If a user asks you to perform a sensitive action, clearly state what parameters are affected and instruct them to confirm the action explicitly via the platform confirmation button or authorized control desk.
4. Keep responses concise, structured, accurate, and clearly formatted with Markdown headings/bullets where helpful.
`;

function getAuthorizedBusinessMetrics(auth: AuthContext | null | undefined) {
  if (!auth) {
    return {
      scope: 'PUBLIC_VISITOR',
      note: 'User is not signed in. Private company, financial, employee, or customer records are NOT accessible.',
      supportedModels: ['BYD Seal', 'BYD Atto 3', 'BYD Sealion 6', 'BYD Shark 6'],
    };
  }

  if (auth.subjectType === 'founder' || auth.subjectType === 'super_admin' || auth.role === 'Super Admin') {
    const companies = sqlite
      .prepare('SELECT id, name, country, city, status FROM companies')
      .all();
    const vehicleStats = sqlite
      .prepare('SELECT COUNT(*) as total, SUM(CASE WHEN sold_at IS NOT NULL THEN 1 ELSE 0 END) as sold FROM vehicles')
      .get() as any;
    const userCounts = sqlite
      .prepare("SELECT SUM(CASE WHEN role = 'Customer' THEN 1 ELSE 0 END) as customers, SUM(CASE WHEN role != 'Customer' THEN 1 ELSE 0 END) as staff FROM users")
      .get() as any;
    const dealershipsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealerships').get() as any).c;
    const bookingsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM bookings').get() as any).c;
    const serviceJobsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM service_jobs').get() as any).c;
    const warrantyCount = (sqlite.prepare('SELECT COUNT(*) as c FROM warranty_claims').get() as any).c;
    const invoiceStats = sqlite
      .prepare("SELECT COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal, COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal FROM payments_invoices")
      .get() as any;

    return {
      scope: auth.subjectType === 'founder' ? 'FOUNDER_GLOBAL_OWNER' : 'SUPER_ADMIN_GOVERNANCE',
      actor: auth.fullName,
      companies,
      totals: {
        dealerships: dealershipsCount,
        employees: userCounts.staff || 0,
        customers: userCounts.customers || 0,
        vehicles: vehicleStats.total || 0,
        soldVehicles: vehicleStats.sold || 0,
        bookings: bookingsCount,
        serviceJobs: serviceJobsCount,
        warrantyClaims: warrantyCount,
        paidInvoicesTotal: invoiceStats.paidTotal,
        pendingInvoicesTotal: invoiceStats.pendingTotal,
      },
    };
  }

  if (auth.role === 'Customer') {
    const myVehicles = sqlite
      .prepare('SELECT vin, model, variant, license_plate, odometer_km, battery_health_soh, battery_health_soc, status, warranty_expiry_date FROM vehicles WHERE owner_id = ?')
      .all(auth.userId);
    const myBookings = sqlite
      .prepare('SELECT booking_type, vehicle_model, preferred_date, preferred_time, city, status FROM bookings WHERE customer_id = ? ORDER BY created_at DESC LIMIT 10')
      .all(auth.userId);
    const myServiceJobs = sqlite
      .prepare('SELECT ticket_number, model, service_type, scheduled_date, status, estimated_cost_pkr FROM service_jobs WHERE customer_id = ? ORDER BY created_at DESC LIMIT 10')
      .all(auth.userId);
    const myWarrantyClaims = sqlite
      .prepare('SELECT claim_number, vehicle_model, component_category, status, claim_amount_pkr FROM warranty_claims WHERE customer_id = ? ORDER BY created_at DESC LIMIT 10')
      .all(auth.userId);
    const myInvoices = sqlite
      .prepare('SELECT invoice_number, item_category, currency, total_amount, status, payment_gateway FROM payments_invoices WHERE customer_id = ? ORDER BY created_at DESC LIMIT 10')
      .all(auth.userId);

    return {
      scope: 'CUSTOMER_ISOLATED_PORTAL',
      customerName: auth.fullName,
      city: auth.city,
      myVehicles,
      myBookings,
      myServiceJobs,
      myWarrantyClaims,
      myInvoices,
    };
  }

  // Company-isolated staff & managers
  const cid = auth.companyId;
  const company = cid ? sqlite.prepare('SELECT id, name, country, city, status FROM companies WHERE id = ?').get(cid) : null;
  const dealerships = cid
    ? sqlite.prepare('SELECT id, name, city, achieved_units, monthly_target_units, monthly_revenue_pkr FROM dealerships WHERE company_id = ?').all(cid)
    : [];
  const vehicleStats = cid
    ? (sqlite.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN sold_at IS NOT NULL THEN 1 ELSE 0 END) as sold FROM vehicles WHERE company_id = ?').get(cid) as any)
    : { total: 0, sold: 0 };
  const staffCount = cid
    ? (sqlite.prepare("SELECT COUNT(*) as c FROM users WHERE company_id = ? AND role != 'Customer'").get(cid) as any).c
    : 0;
  const customerCount = cid
    ? (sqlite.prepare("SELECT COUNT(*) as c FROM users WHERE company_id = ? AND role = 'Customer'").get(cid) as any).c
    : 0;
  const serviceJobs = cid
    ? sqlite.prepare('SELECT status, COUNT(*) as count FROM service_jobs WHERE company_id = ? GROUP BY status').all(cid)
    : [];
  const bookingsCount = cid
    ? (sqlite.prepare('SELECT COUNT(*) as c FROM bookings WHERE company_id = ?').get(cid) as any).c
    : 0;
  const invoiceStats = cid
    ? (sqlite.prepare("SELECT COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal, COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal FROM payments_invoices WHERE company_id = ?").get(cid) as any)
    : { paidTotal: 0, pendingTotal: 0 };

  return {
    scope: 'COMPANY_ISOLATED_WORKSPACE',
    role: auth.role,
    company,
    dealerships,
    metrics: {
      staffCount,
      customerCount,
      vehiclesTotal: vehicleStats.total || 0,
      soldVehicles: vehicleStats.sold || 0,
      bookingsCount,
      serviceJobsByStatus: serviceJobs,
      paidRevenueTotal: invoiceStats.paidTotal,
      pendingRevenueTotal: invoiceStats.pendingTotal,
    },
  };
}

function checkAiAccessAndQuota(auth: AuthContext | null | undefined): {
  allowed: boolean;
  status?: number;
  error?: string;
  model: string;
  aiConfig: any;
} {
  const aiConfig = getSystemSetting('ai_config', {
    globalEnabled: true,
    defaultModel: 'gemini-4-hydrogen',
    allowedModels: ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'],
    dailyLimitPerCompany: 250,
    dailyLimitPerUser: 60,
    allowDocumentAnalysis: true,
    allowVoiceAssistant: true,
    requireConfirmationForSensitiveActions: true,
  });

  const model = (SUPPORTED_MODELS as readonly string[]).includes(aiConfig.defaultModel)
    ? aiConfig.defaultModel
    : 'gemini-4-hydrogen';

  if (!aiConfig.globalEnabled && auth?.subjectType !== 'founder') {
    return {
      allowed: false,
      status: 403,
      error: 'BYD AI has been globally disabled by the Primary Owner.',
      model,
      aiConfig,
    };
  }

  if (auth?.companyId && auth.subjectType !== 'founder') {
    const comp = sqlite.prepare('SELECT ai_enabled, ai_daily_limit, name FROM companies WHERE id = ?').get(auth.companyId) as any;
    if (comp && comp.ai_enabled === 0) {
      return {
        allowed: false,
        status: 403,
        error: `BYD AI access is currently disabled for ${comp.name} by the Primary Owner.`,
        model,
        aiConfig,
      };
    }

    const todayPrefix = nowIso().slice(0, 10);
    const companyUsageToday = (sqlite
      .prepare("SELECT COUNT(*) as c FROM ai_usage_logs WHERE company_id = ? AND status = 'SUCCESS' AND created_at LIKE ?")
      .get(auth.companyId, `${todayPrefix}%`) as any).c;

    const compLimit = comp?.ai_daily_limit || aiConfig.dailyLimitPerCompany || 250;
    if (companyUsageToday >= compLimit) {
      return {
        allowed: false,
        status: 429,
        error: `Daily BYD AI query limit (${compLimit}) reached for your company workspace.`,
        model,
        aiConfig,
      };
    }
  }

  if (auth?.userId && auth.subjectType !== 'founder') {
    const todayPrefix = nowIso().slice(0, 10);
    const userUsageToday = (sqlite
      .prepare("SELECT COUNT(*) as c FROM ai_usage_logs WHERE user_id = ? AND status = 'SUCCESS' AND created_at LIKE ?")
      .get(auth.userId, `${todayPrefix}%`) as any).c;
    const userLimit = aiConfig.dailyLimitPerUser || 60;
    if (userUsageToday >= userLimit) {
      return {
        allowed: false,
        status: 429,
        error: `Your personal daily BYD AI limit (${userLimit} queries) has been reached.`,
        model,
        aiConfig,
      };
    }
  }

  return { allowed: true, model, aiConfig };
}

function logAiUsage(params: {
  userId: string;
  companyId: string | null;
  role: string;
  endpoint: string;
  model: string;
  status: 'SUCCESS' | 'ERROR' | 'BLOCKED';
  errorMessage?: string;
  promptChars?: number;
  responseChars?: number;
}) {
  const promptChars = params.promptChars || 0;
  const responseChars = params.responseChars || 0;
  // Rough token/cost estimate for Owner telemetry (~4 chars per token)
  const estCost = ((promptChars / 4) * 0.0000001 + (responseChars / 4) * 0.0000004);

  sqlite
    .prepare(`
      INSERT INTO ai_usage_logs (
        id, user_id, company_id, role, endpoint, model, status, error_message,
        prompt_chars, response_chars, estimated_cost_usd, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `ailog_${generateSecureToken(6)}`,
      params.userId,
      params.companyId,
      params.role,
      params.endpoint,
      params.model,
      params.status,
      params.errorMessage || null,
      promptChars,
      responseChars,
      Number(estCost.toFixed(6)),
      nowIso()
    );
}

export function createAiRouter() {
  const router = express.Router();

  // Truthful BYD AI configuration & connectivity status
  router.get('/ai/status', (req: Request, res: Response) => {
    const access = checkAiAccessAndQuota(req.auth);
    const configured = Boolean(getGeminiClient());
    res.json({
      aiName: 'BYD AI',
      configured,
      enabled: access.allowed,
      model: access.model,
      allowedModels: SUPPORTED_MODELS,
      allowDocumentAnalysis: access.aiConfig.allowDocumentAnalysis !== false,
      allowVoiceAssistant: access.aiConfig.allowVoiceAssistant !== false,
      statusReason: !configured
        ? 'GEMINI_API_KEY is not configured on the server.'
        : !access.allowed
        ? access.error
        : 'Ready for verified server-side Gemini API calls.',
    });
  });

  // List saved conversations for authenticated user
  router.get('/ai/conversations', requireAuth, (req: Request, res: Response) => {
    const rows = sqlite
      .prepare('SELECT id, title, role, created_at, updated_at FROM ai_conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 50')
      .all(req.auth!.userId);
    res.json({ conversations: rows });
  });

  router.post('/ai/conversations', requireAuth, (req: Request, res: Response) => {
    const id = `conv_${generateSecureToken(8)}`;
    const title = String(req.body.title || 'New BYD AI Conversation').slice(0, 120);
    const now = nowIso();
    sqlite
      .prepare('INSERT INTO ai_conversations (id, user_id, company_id, role, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(id, req.auth!.userId, req.auth!.companyId, req.auth!.role, title, now, now);
    res.status(201).json({ conversation: { id, title, role: req.auth!.role, created_at: now, updated_at: now } });
  });

  router.get('/ai/conversations/:id', requireAuth, (req: Request, res: Response) => {
    const conv = sqlite
      .prepare('SELECT * FROM ai_conversations WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.auth!.userId) as any;
    if (!conv) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    const messages = sqlite
      .prepare('SELECT * FROM ai_messages WHERE conversation_id = ? ORDER BY created_at ASC')
      .all(conv.id);
    res.json({ conversation: conv, messages });
  });

  router.delete('/ai/conversations/:id', requireAuth, (req: Request, res: Response) => {
    const info = sqlite
      .prepare('DELETE FROM ai_conversations WHERE id = ? AND user_id = ?')
      .run(req.params.id, req.auth!.userId);
    if (info.changes === 0) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    res.json({ success: true });
  });

  router.post('/ai/conversations/:id/clear', requireAuth, (req: Request, res: Response) => {
    const conv = sqlite
      .prepare('SELECT id FROM ai_conversations WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.auth!.userId);
    if (!conv) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    sqlite.prepare('DELETE FROM ai_messages WHERE conversation_id = ?').run(req.params.id);
    sqlite.prepare('UPDATE ai_conversations SET updated_at = ? WHERE id = ?').run(nowIso(), req.params.id);
    res.json({ success: true });
  });

  // Main BYD AI Chat Endpoint (supports conversation history + Business Intelligence)
  router.post('/ai/chat', async (req: Request, res: Response) => {
    const message = String(req.body.message || '').trim();
    const conversationId = req.body.conversationId ? String(req.body.conversationId) : null;
    const language = String(req.body.language || 'auto');

    if (!message) {
      res.status(400).json({ error: 'Message text is required.' });
      return;
    }

    const access = checkAiAccessAndQuota(req.auth);
    const userId = req.auth?.userId || 'anonymous_visitor';
    const companyId = req.auth?.companyId || null;
    const role = req.auth?.role || 'Public Visitor';

    if (!access.allowed) {
      logAiUsage({
        userId,
        companyId,
        role,
        endpoint: '/api/ai/chat',
        model: access.model,
        status: 'BLOCKED',
        errorMessage: access.error,
        promptChars: message.length,
      });
      res.status(access.status || 403).json({ error: access.error, code: 'AI_BLOCKED' });
      return;
    }

    const client = getGeminiClient();
    const isFallback = !client;

    if (isFallback) {
      logAiUsage({
        userId,
        companyId,
        role,
        endpoint: '/api/ai/chat',
        model: access.model,
        status: 'SUCCESS',
        errorMessage: undefined,
        promptChars: message.length,
      });
      const fallbackReply = getFallbackAIResponse(message, language, getAuthorizedBusinessMetrics(req.auth));
      res.json({
        reply: fallbackReply,
        model: 'fallback-rule-based',
        conversationId: conversationId || `conv_fallback_${generateSecureToken(8)}`,
        biScope: getAuthorizedBusinessMetrics(req.auth).scope,
        isFallback: true,
      });
      return;
    }

    try {
      const biMetrics = getAuthorizedBusinessMetrics(req.auth);
      let activeConvId = conversationId;
      let priorHistoryText = '';

      if (req.auth) {
        if (!activeConvId) {
          activeConvId = `conv_${generateSecureToken(8)}`;
          const now = nowIso();
          sqlite
            .prepare('INSERT INTO ai_conversations (id, user_id, company_id, role, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run(activeConvId, req.auth.userId, req.auth.companyId, req.auth.role, message.slice(0, 60), now, now);
        } else {
          const conv = sqlite
            .prepare('SELECT id FROM ai_conversations WHERE id = ? AND user_id = ?')
            .get(activeConvId, req.auth.userId);
          if (!conv) {
            res.status(404).json({ error: 'Conversation not found.' });
            return;
          }
          const recentMsgs = sqlite
            .prepare('SELECT sender, content FROM ai_messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 8')
            .all(activeConvId) as Array<{ sender: string; content: string }>;
          priorHistoryText = recentMsgs
            .reverse()
            .map((m) => `${m.sender === 'user' ? 'User' : 'BYD AI'}: ${m.content}`)
            .join('\n');
        }
      }

      const fullPrompt = `
AUTHORIZED_DB_METRICS:
${JSON.stringify(biMetrics, null, 2)}

Preferred Language Mode: ${language}
${priorHistoryText ? `\nRECENT_CONVERSATION:\n${priorHistoryText}\n` : ''}
USER_QUERY:
${message}
`;

      const { text: generatedText, modelUsed } = await generateWithResilience(
        client,
        access.model,
        fullPrompt,
        BYD_AI_BASE_INSTRUCTION
      );

      const reply = generatedText || 'BYD AI did not return any text output.';
      const now = nowIso();

      if (req.auth && activeConvId) {
        sqlite
          .prepare("INSERT INTO ai_messages (id, conversation_id, sender, content, model_used, created_at) VALUES (?, ?, 'user', ?, ?, ?)")
          .run(`aim_${generateSecureToken(6)}`, activeConvId, message, modelUsed, now);
        sqlite
          .prepare("INSERT INTO ai_messages (id, conversation_id, sender, content, model_used, created_at) VALUES (?, ?, 'assistant', ?, ?, ?)")
          .run(`aim_${generateSecureToken(6)}`, activeConvId, reply, modelUsed, nowIso());
        sqlite
          .prepare('UPDATE ai_conversations SET updated_at = ? WHERE id = ?')
          .run(nowIso(), activeConvId);
      }

      logAiUsage({
        userId,
        companyId,
        role,
        endpoint: '/api/ai/chat',
        model: modelUsed,
        status: 'SUCCESS',
        promptChars: fullPrompt.length,
        responseChars: reply.length,
      });

      res.json({
        reply,
        model: modelUsed,
        conversationId: activeConvId,
        biScope: biMetrics.scope,
      });
    } catch (err: any) {
      console.error('BYD AI Gemini error:', err);
      logAiUsage({
        userId,
        companyId,
        role,
        endpoint: '/api/ai/chat',
        model: access.model,
        status: 'ERROR',
        errorMessage: err?.message || 'Gemini API error',
        promptChars: message.length,
      });
      res.status(502).json({
        error: err?.message || 'Gemini API request failed.',
        code: 'GEMINI_UPSTREAM_ERROR',
      });
    }
  });

  // Document Intelligence Upload & Analysis (PDF, DOCX, XLSX, CSV, TXT, Images)
  router.post('/ai/upload-analyze', requireAuth, upload.single('file'), async (req: Request, res: Response) => {
    const file = req.file;
    const prompt = String(req.body.prompt || 'Analyze this document and extract key findings, numbers, risks, and action items.').trim();
    const conversationId = req.body.conversationId ? String(req.body.conversationId) : null;

    if (!file) {
      res.status(400).json({ error: 'Please select a file to upload (PDF, DOCX, XLSX, CSV, TXT, or Image).' });
      return;
    }

    const access = checkAiAccessAndQuota(req.auth);
    if (!access.allowed) {
      res.status(access.status || 403).json({ error: access.error });
      return;
    }
    if (access.aiConfig.allowDocumentAnalysis === false && req.auth!.subjectType !== 'founder') {
      res.status(403).json({ error: 'Document analysis has been disabled by the Primary Owner.' });
      return;
    }

    const client = getGeminiClient();
    if (!client) {
      res.status(200).json({
        analysis: `Document Analysis (Offline Mode):\n\nFile: "${file.originalname}"\nSize: ${(file.size / 1024).toFixed(2)} KB\nType: ${file.mimetype}\n\nLive AI document analysis requires GEMINI_API_KEY to be configured on the server.\n\nFor now, the file has been received and stored. To get AI-powered insights, please configure GEMINI_API_KEY in your server environment variables.\n\nSupported formats: PDF, DOCX, XLSX, XLS, CSV, TXT, PNG, JPG, WEBP.`,
        fileName: file.originalname,
        model: 'fallback-rule-based',
        conversationId: conversationId || `conv_fallback_${generateSecureToken(8)}`,
        isFallback: true,
      });
      return;
    }

    try {
      const ext = file.originalname.split('.').pop()?.toLowerCase() || '';
      const mime = file.mimetype;
      let contents: any;

      if (mime === 'application/pdf' || ext === 'pdf' || mime.startsWith('image/')) {
        const cleanMime = mime === 'application/pdf' || ext === 'pdf' ? 'application/pdf' : mime;
        contents = [
          {
            inlineData: {
              data: file.buffer.toString('base64'),
              mimeType: cleanMime,
            },
          },
          `Analyze uploaded file "${file.originalname}" for user ${req.auth!.fullName} (${req.auth!.role}). User instructions: ${prompt}`,
        ];
      } else if (ext === 'docx' || mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        const parsed = await mammoth.extractRawText({ buffer: file.buffer });
        contents = `Uploaded DOCX File: "${file.originalname}"\n\nEXTRACTED_DOCUMENT_TEXT:\n${parsed.value.slice(0, 40000)}\n\nUser instructions: ${prompt}`;
      } else if (['xlsx', 'xls'].includes(ext) || mime.includes('spreadsheet') || mime.includes('excel')) {
        const workbook = XLSX.read(file.buffer, { type: 'buffer' });
        const sheetsSummary = workbook.SheetNames.map((name) => {
          const csv = XLSX.utils.sheet_to_csv(workbook.Sheets[name]);
          return `--- Sheet: ${name} ---\n${csv.slice(0, 15000)}`;
        }).join('\n\n');
        contents = `Uploaded Spreadsheet File: "${file.originalname}"\n\n${sheetsSummary}\n\nUser instructions: ${prompt}`;
      } else if (['csv', 'txt', 'json', 'md', 'log'].includes(ext) || mime.startsWith('text/')) {
        const text = file.buffer.toString('utf-8').slice(0, 45000);
        contents = `Uploaded Text/CSV File: "${file.originalname}"\n\nCONTENT:\n${text}\n\nUser instructions: ${prompt}`;
      } else {
        res.status(400).json({ error: `Unsupported file format (.${ext}). Supported formats: PDF, DOCX, XLSX, XLS, CSV, TXT, PNG, JPG, WEBP.` });
        return;
      }

      const { text: generatedText, modelUsed } = await generateWithResilience(
        client,
        access.model,
        contents,
        BYD_AI_BASE_INSTRUCTION
      );

      const reply = generatedText || 'Unable to extract insights from this document.';

      let activeConvId = conversationId;
      if (!activeConvId) {
        activeConvId = `conv_${generateSecureToken(8)}`;
        const now = nowIso();
        sqlite
          .prepare('INSERT INTO ai_conversations (id, user_id, company_id, role, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .run(activeConvId, req.auth!.userId, req.auth!.companyId, req.auth!.role, `Doc: ${file.originalname}`.slice(0, 80), now, now);
      }

      sqlite
        .prepare("INSERT INTO ai_messages (id, conversation_id, sender, content, attachment_name, model_used, created_at) VALUES (?, ?, 'user', ?, ?, ?, ?)")
        .run(`aim_${generateSecureToken(6)}`, activeConvId, `[Uploaded: ${file.originalname}] ${prompt}`, file.originalname, modelUsed, nowIso());
      sqlite
        .prepare("INSERT INTO ai_messages (id, conversation_id, sender, content, attachment_name, model_used, created_at) VALUES (?, ?, 'assistant', ?, ?, ?, ?)")
        .run(`aim_${generateSecureToken(6)}`, activeConvId, reply, file.originalname, modelUsed, nowIso());

      logAiUsage({
        userId: req.auth!.userId,
        companyId: req.auth!.companyId,
        role: req.auth!.role,
        endpoint: '/api/ai/upload-analyze',
        model: modelUsed,
        status: 'SUCCESS',
        promptChars: prompt.length + file.size,
        responseChars: reply.length,
      });

      res.json({
        analysis: reply,
        fileName: file.originalname,
        model: modelUsed,
        conversationId: activeConvId,
      });
    } catch (err: any) {
      console.error('Document analysis error:', err);
      logAiUsage({
        userId: req.auth!.userId,
        companyId: req.auth!.companyId,
        role: req.auth!.role,
        endpoint: '/api/ai/upload-analyze',
        model: access.model,
        status: 'ERROR',
        errorMessage: err?.message || 'Document analysis error',
      });
      res.status(502).json({ error: err?.message || 'Document analysis failed.' });
    }
  });

  // Compatibility Endpoints for Battery Lab & Executive Dashboard (Honest Gemini calls)
  router.post('/gemini/analyze-battery', async (req: Request, res: Response) => {
    const { batteryData, vin, modelName } = req.body;
    const access = checkAiAccessAndQuota(req.auth);
    const client = getGeminiClient();
    const userId = req.auth?.userId || 'anonymous_visitor';
    const isFallback = !client;

    if (!access.allowed) {
      res.status(access.status || 403).json({ error: access.error });
      return;
    }
    if (isFallback) {
      logAiUsage({
        userId,
        companyId: req.auth?.companyId || null,
        role: req.auth?.role || 'Visitor',
        endpoint: '/api/gemini/analyze-battery',
        model: 'fallback-rule-based',
        status: 'SUCCESS',
        promptChars: JSON.stringify(batteryData || {}).length,
        responseChars: 0,
      });
      const vin = (batteryData?.vin || req.body.vin || 'N/A');
      const modelName = (batteryData?.modelName || req.body.modelName || 'BYD EV');
      const soh = batteryData?.stateOfHealth || batteryData?.soh || 'Unknown';
      const temp = batteryData?.temperature || batteryData?.temp || 'Unknown';
      const voltage = batteryData?.voltage || batteryData?.cellVoltage || 'Unknown';
      const cycles = batteryData?.chargeCycles || batteryData?.cycles || 'Unknown';

      res.json({
        analysis: `BYD Blade Battery Diagnostic (Offline Mode):\n\nVIN: ${vin}\nModel: ${modelName}\nState of Health (SoH): ${soh}\nTemperature: ${temp}\nCell Voltage: ${voltage}\nCharge Cycles: ${cycles}\n\nLive AI battery diagnostics require GEMINI_API_KEY configured on the server.\n\nBasic Assessment:\n• SoH ${soh === 'Unknown' ? 'could not be determined' : soh + '%'} - ${soh !== 'Unknown' && Number(soh) > 80 ? 'Good battery health' : soh !== 'Unknown' && Number(soh) <= 80 ? 'Battery degradation detected - recommend service' : 'Please provide battery data for assessment'}\n• For detailed analysis, visit a BYD service center.\n\nConfigure GEMINI_API_KEY for live AI-powered battery diagnostics.`,
        model: 'fallback-rule-based',
        isFallback: true,
      });
      return;
    }

    try {
      const prompt = `
Analyze the following BYD Blade Battery diagnostic inspection telemetry for VIN ${vin || 'N/A'} (${modelName || 'BYD EV'}):
${JSON.stringify(batteryData, null, 2)}

Provide an executive technical summary containing:
1. Overall State of Health (SoH) assessment.
2. Cell Voltage Uniformity & Thermal Balance Analysis.
3. Rapid-Charge Degradation Risk Score (Low / Medium / High).
4. Recommended Maintenance Actions.
5. Warranty Status compliance check (BYD 8-Year / 160,000 km Blade Battery policy).
`;
      const { text, modelUsed } = await generateWithResilience(
        client,
        access.model,
        prompt,
        BYD_AI_BASE_INSTRUCTION
      );
      logAiUsage({
        userId,
        companyId: req.auth?.companyId || null,
        role: req.auth?.role || 'Visitor',
        endpoint: '/api/gemini/analyze-battery',
        model: modelUsed,
        status: 'SUCCESS',
        promptChars: prompt.length,
        responseChars: text.length,
      });
      res.json({ analysis: text, model: modelUsed, isFallback: false });
    } catch (err: any) {
      logAiUsage({
        userId,
        companyId: req.auth?.companyId || null,
        role: req.auth?.role || 'Visitor',
        endpoint: '/api/gemini/analyze-battery',
        model: access.model,
        status: 'ERROR',
        errorMessage: err?.message,
      });
      res.status(502).json({ error: err?.message || 'Failed to analyze battery health.' });
    }
  });

  router.post('/gemini/executive-summary', requireAuth, async (req: Request, res: Response) => {
    const { metrics, period = 'Current Quarter' } = req.body;
    const access = checkAiAccessAndQuota(req.auth);
    const client = getGeminiClient();
    const isFallback = !client;

    if (!access.allowed) {
      res.status(access.status || 403).json({ error: access.error });
      return;
    }
    if (isFallback) {
      const authBi = getAuthorizedBusinessMetrics(req.auth);
      res.json({
        summary: `Executive Summary (Offline Mode):\n\nPeriod: ${period}\nScope: ${authBi.scope}\n\nLive AI executive summary requires GEMINI_API_KEY configured on the server.\n\nBasic Metrics Available:\n${Object.entries(authBi.totals || {}).map(([k, v]) => `• ${k}: ${v}`).join('\n') || 'No metrics available for your role.'}\n\nConfigure GEMINI_API_KEY for live AI-powered executive insights.`,
        model: 'fallback-rule-based',
        isFallback: true,
      });
      return;
    }

    try {
      const authorizedBi = getAuthorizedBusinessMetrics(req.auth);
      const prompt = `
Provide a high-level corporate briefing based strictly on these authorized enterprise metrics:
${JSON.stringify({ authorizedBi, requestedViewMetrics: metrics }, null, 2)}
Period: ${period}

Format as:
1. Executive Performance Highlight (Sales, Revenue, Delivery Rate)
2. Regional / Dealership Performance Insights
3. Service & Warranty SLA Index
4. Strategic Action Items
`;
      const { text, modelUsed } = await generateWithResilience(
        client,
        access.model,
        prompt,
        BYD_AI_BASE_INSTRUCTION
      );
      logAiUsage({
        userId: req.auth!.userId,
        companyId: req.auth!.companyId,
        role: req.auth!.role,
        endpoint: '/api/gemini/executive-summary',
        model: modelUsed,
        status: 'SUCCESS',
        promptChars: prompt.length,
        responseChars: text.length,
      });
      res.json({ summary: text, model: modelUsed, isFallback: false });
    } catch (err: any) {
      res.status(502).json({ error: err?.message || 'Failed to generate executive summary.' });
    }
  });

  // =========================================================================
  // OWNER-ONLY BYD AI GOVERNANCE & TELEMETRY
  // =========================================================================
  router.get('/owner/ai-settings', requireFounder, (_req: Request, res: Response) => {
    const aiConfig = getSystemSetting('ai_config', {});
    const companies = sqlite.prepare('SELECT id, name, country, status, ai_enabled, ai_daily_limit FROM companies ORDER BY name ASC').all();
    const recentLogs = sqlite.prepare('SELECT * FROM ai_usage_logs ORDER BY created_at DESC LIMIT 60').all();
    const stats = sqlite
      .prepare(`
        SELECT
          COUNT(*) as totalRequests,
          SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as successCount,
          SUM(CASE WHEN status = 'ERROR' THEN 1 ELSE 0 END) as errorCount,
          SUM(CASE WHEN status = 'BLOCKED' THEN 1 ELSE 0 END) as blockedCount,
          COALESCE(SUM(estimated_cost_usd), 0) as totalEstimatedCostUsd
        FROM ai_usage_logs
      `)
      .get();

    res.json({
      geminiKeyConfigured: Boolean(getGeminiClient()),
      aiConfig,
      supportedModels: SUPPORTED_MODELS,
      companies,
      stats,
      recentLogs,
    });
  });

  router.put('/owner/ai-settings', requireFounder, (req: Request, res: Response) => {
    const current = getSystemSetting<Record<string, any>>('ai_config', {});
    const nextConfig = {
      ...current,
      globalEnabled: typeof req.body.globalEnabled === 'boolean' ? req.body.globalEnabled : current.globalEnabled,
      defaultModel: (SUPPORTED_MODELS as readonly string[]).includes(req.body.defaultModel)
        ? req.body.defaultModel
        : current.defaultModel || 'gemini-4-hydrogen',
      dailyLimitPerCompany: Number(req.body.dailyLimitPerCompany || current.dailyLimitPerCompany || 250),
      dailyLimitPerUser: Number(req.body.dailyLimitPerUser || current.dailyLimitPerUser || 60),
      allowDocumentAnalysis: typeof req.body.allowDocumentAnalysis === 'boolean' ? req.body.allowDocumentAnalysis : current.allowDocumentAnalysis,
      allowVoiceAssistant: typeof req.body.allowVoiceAssistant === 'boolean' ? req.body.allowVoiceAssistant : current.allowVoiceAssistant,
    };

    setSystemSetting('ai_config', nextConfig, req.auth!.userId);

    if (Array.isArray(req.body.companyOverrides)) {
      const upd = sqlite.prepare('UPDATE companies SET ai_enabled = ?, ai_daily_limit = ? WHERE id = ?');
      for (const co of req.body.companyOverrides) {
        if (co?.id) {
          upd.run(co.ai_enabled ? 1 : 0, Number(co.ai_daily_limit || 250), co.id);
        }
      }
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'OWNER_AI_SETTINGS_UPDATED',
      module: 'BYD AI Governance',
      details: `Model: ${nextConfig.defaultModel}, GlobalEnabled: ${nextConfig.globalEnabled}`,
    });

    res.json({ success: true, aiConfig: nextConfig });
  });

  return router;
}
