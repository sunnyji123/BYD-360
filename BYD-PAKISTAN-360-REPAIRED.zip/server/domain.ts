import express, { Request, Response } from 'express';
import { sqlite, generateSecureToken, logOwnerAudit, nowIso } from './db';
import { requireAuth, requireRoles } from './auth';

function isGlobalReader(req: Request) {
  return req.auth?.subjectType === 'founder' || req.auth?.subjectType === 'super_admin' || req.auth?.role === 'Super Admin';
}

export function createDomainRouter() {
  const router = express.Router();

  // Public approved dealerships & companies for booking/registration dropdowns
  router.get('/public/companies', (_req: Request, res: Response) => {
    const companies = sqlite
      .prepare("SELECT id, name, country, city FROM companies WHERE status = 'Approved' ORDER BY name ASC")
      .all();
    const dealerships = sqlite
      .prepare("SELECT d.id, d.company_id, d.name, d.code, d.country, d.city, d.address, d.facility_type, d.phone FROM dealerships d JOIN companies c ON c.id = d.company_id WHERE c.status = 'Approved' ORDER BY d.city ASC")
      .all();
    res.json({ companies, dealerships });
  });

  // Vehicles (Strictly isolated: Customer = own vehicles, Staff = own company, Founder/Super Admin = global)
  router.get('/vehicles', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    if (isGlobalReader(req)) {
      const cid = req.query.companyId ? String(req.query.companyId) : null;
      const rows = cid
        ? sqlite.prepare('SELECT * FROM vehicles WHERE company_id = ? ORDER BY created_at DESC').all(cid)
        : sqlite.prepare('SELECT * FROM vehicles ORDER BY created_at DESC').all();
      res.json({ vehicles: rows });
      return;
    }

    if (auth.role === 'Customer') {
      const rows = sqlite
        .prepare('SELECT * FROM vehicles WHERE owner_id = ? ORDER BY created_at DESC')
        .all(auth.userId);
      res.json({ vehicles: rows });
      return;
    }

    const rows = sqlite
      .prepare('SELECT * FROM vehicles WHERE company_id = ? ORDER BY created_at DESC')
      .all(auth.companyId);
    res.json({ vehicles: rows });
  });

  router.post(
    '/vehicles',
    requireAuth,
    requireRoles('Founder / Owner', 'Super Admin', 'Company Admin', 'Dealership Manager', 'Sales Manager', 'Head Office Staff'),
    (req: Request, res: Response) => {
      const auth = req.auth!;
      const companyId = isGlobalReader(req) && req.body.companyId ? String(req.body.companyId) : auth.companyId;
      if (!companyId) {
        res.status(400).json({ error: 'Company context is required to register a vehicle.' });
        return;
      }

      const vin = String(req.body.vin || '').trim().toUpperCase();
      const model = String(req.body.model || 'BYD Seal').trim();
      const variant = String(req.body.variant || 'Standard').trim();
      const color = String(req.body.color || 'Arctic White').trim();
      const licensePlate = String(req.body.licensePlate || 'EV-PENDING').trim().toUpperCase();
      const ownerId = req.body.ownerId ? String(req.body.ownerId) : null;

      if (!vin || vin.length < 8) {
        res.status(400).json({ error: 'Valid VIN number is required.' });
        return;
      }

      const id = `veh_${generateSecureToken(6)}`;
      const now = nowIso();
      try {
        sqlite
          .prepare(`
            INSERT INTO vehicles (
              id, company_id, dealership_id, vin, chassis_number, model, variant, color, year,
              license_plate, owner_id, owner_name, owner_phone, owner_city, registration_date,
              odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
              warranty_expiry_date, last_service_date, next_service_due_km, status,
              dealership_purchased, sale_price_pkr, sold_at, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 100, 90, '2034-12-31', ?, 10000, 'Active', ?, ?, ?, ?)
          `)
          .run(
            id,
            companyId,
            req.body.dealershipId || auth.dealershipId || null,
            vin,
            req.body.chassisNumber || `CH-${vin.slice(-6)}`,
            model,
            variant,
            color,
            Number(req.body.year || 2026),
            licensePlate,
            ownerId,
            req.body.ownerName || 'Dealership Stock',
            req.body.ownerPhone || auth.mobile,
            req.body.ownerCity || auth.city,
            now.slice(0, 10),
            Number(req.body.batteryCapacityKwh || 82.5),
            now.slice(0, 10),
            req.body.dealershipName || 'Authorized 3S Centre',
            Number(req.body.salePricePkr || 14900000),
            ownerId ? now.slice(0, 10) : null,
            now
          );
      } catch (err: any) {
        res.status(409).json({ error: err?.message || 'Vehicle with this VIN already exists.' });
        return;
      }

      logOwnerAudit({
        actorId: auth.userId,
        actorName: auth.fullName,
        actorRole: auth.role,
        action: 'VEHICLE_REGISTERED',
        module: 'Vehicle Inventory',
        targetId: vin,
        companyId,
      });

      res.status(201).json({ success: true, vehicleId: id, vin });
    }
  );

  // Bookings (Test Drive / Service / Reservation)
  router.get('/bookings', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    if (isGlobalReader(req)) {
      res.json({ bookings: sqlite.prepare('SELECT * FROM bookings ORDER BY created_at DESC LIMIT 100').all() });
      return;
    }
    if (auth.role === 'Customer') {
      res.json({ bookings: sqlite.prepare('SELECT * FROM bookings WHERE customer_id = ? ORDER BY created_at DESC').all(auth.userId) });
      return;
    }
    res.json({ bookings: sqlite.prepare('SELECT * FROM bookings WHERE company_id = ? ORDER BY created_at DESC').all(auth.companyId) });
  });

  router.post('/bookings', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    const companyId = req.body.companyId && isGlobalReader(req) ? String(req.body.companyId) : auth.companyId || 'comp_byd_pk';
    const id = `bkg_${generateSecureToken(6)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO bookings (
          id, company_id, dealership_id, customer_id, customer_name, customer_phone,
          booking_type, vehicle_model, preferred_date, preferred_time, city, status, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed', ?, ?)
      `)
      .run(
        id,
        companyId,
        req.body.dealershipId || auth.dealershipId || null,
        auth.role === 'Customer' ? auth.userId : String(req.body.customerId || auth.userId),
        String(req.body.customerName || auth.fullName),
        String(req.body.customerPhone || auth.mobile),
        String(req.body.bookingType || 'Test Drive'),
        String(req.body.vehicleModel || 'BYD Seal'),
        String(req.body.preferredDate || now.slice(0, 10)),
        String(req.body.preferredTime || '11:00 AM'),
        String(req.body.city || auth.city),
        String(req.body.notes || ''),
        now
      );

    res.status(201).json({ success: true, bookingId: id });
  });

  // Service Jobs (Company / Customer Isolated)
  router.get('/service-jobs', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    if (isGlobalReader(req)) {
      res.json({ serviceJobs: sqlite.prepare('SELECT * FROM service_jobs ORDER BY created_at DESC').all() });
      return;
    }
    if (auth.role === 'Customer') {
      res.json({ serviceJobs: sqlite.prepare('SELECT * FROM service_jobs WHERE customer_id = ? ORDER BY created_at DESC').all(auth.userId) });
      return;
    }
    res.json({ serviceJobs: sqlite.prepare('SELECT * FROM service_jobs WHERE company_id = ? ORDER BY created_at DESC').all(auth.companyId) });
  });

  router.post('/service-jobs', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    const companyId = auth.companyId || 'comp_byd_pk';
    const id = `svc_${generateSecureToken(6)}`;
    const ticket = `BYD-SVC-2026-${Math.floor(100 + Math.random() * 899)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO service_jobs (
          id, company_id, ticket_number, vehicle_id, vin, model, license_plate,
          customer_id, customer_name, customer_phone, dealership_id, dealership_name,
          service_type, scheduled_date, scheduled_time, status, estimated_cost_pkr,
          customer_notes, checklist_json, parts_used_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Approval', ?, ?, ?, '[]', ?)
      `)
      .run(
        id,
        companyId,
        ticket,
        String(req.body.vehicleId || 'veh_custom'),
        String(req.body.vin || 'PENDING-VIN'),
        String(req.body.model || 'BYD Seal'),
        String(req.body.licensePlate || 'EV-001'),
        auth.role === 'Customer' ? auth.userId : String(req.body.customerId || auth.userId),
        String(req.body.customerName || auth.fullName),
        String(req.body.customerPhone || auth.mobile),
        String(req.body.dealershipId || auth.dealershipId || 'dlr_khi_clifton'),
        String(req.body.dealershipName || 'Mega Motor Flagship 3S — Clifton'),
        String(req.body.serviceType || 'Routine Maintenance (10,000 km)'),
        String(req.body.scheduledDate || now.slice(0, 10)),
        String(req.body.scheduledTime || '10:30 AM'),
        Number(req.body.estimatedCostPkr || 15000),
        String(req.body.customerNotes || ''),
        JSON.stringify({
          hvLockChecked: false,
          bladeBatteryScanned: false,
          coolantLevelInspected: false,
          brakePadThicknessMm: 9.5,
          tirePressurePsi: 36,
          firmwareVersion: 'BYD-OS-14.2.1-PK',
          roadTestCompleted: false,
        }),
        now
      );

    res.status(201).json({ success: true, id, ticketNumber: ticket });
  });

  // Warranty Claims
  router.get('/warranty-claims', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    if (isGlobalReader(req)) {
      res.json({ claims: sqlite.prepare('SELECT * FROM warranty_claims ORDER BY created_at DESC').all() });
      return;
    }
    if (auth.role === 'Customer') {
      res.json({ claims: sqlite.prepare('SELECT * FROM warranty_claims WHERE customer_id = ? ORDER BY created_at DESC').all(auth.userId) });
      return;
    }
    res.json({ claims: sqlite.prepare('SELECT * FROM warranty_claims WHERE company_id = ? ORDER BY created_at DESC').all(auth.companyId) });
  });

  // Invoices & Payments (Preserves existing financial behavior with backend isolation)
  router.get('/invoices', requireAuth, (req: Request, res: Response) => {
    const auth = req.auth!;
    if (isGlobalReader(req)) {
      res.json({ invoices: sqlite.prepare('SELECT * FROM payments_invoices ORDER BY created_at DESC').all() });
      return;
    }
    if (auth.role === 'Customer') {
      res.json({ invoices: sqlite.prepare('SELECT * FROM payments_invoices WHERE customer_id = ? ORDER BY created_at DESC').all(auth.userId) });
      return;
    }
    res.json({ invoices: sqlite.prepare('SELECT * FROM payments_invoices WHERE company_id = ? ORDER BY created_at DESC').all(auth.companyId) });
  });

  // Super Admin Operational Overview (Explicitly excludes private Owner settings/2FA/recovery secrets)
  router.get('/admin/overview', requireAuth, requireRoles('Founder / Owner', 'Super Admin'), (_req: Request, res: Response) => {
    const companies = sqlite
      .prepare('SELECT id, name, country, city, official_email, status, created_at FROM companies ORDER BY created_at DESC')
      .all();
    const users = sqlite
      .prepare('SELECT id, company_id, full_name, email, mobile, role, country, city, status, created_at FROM users ORDER BY created_at DESC')
      .all();
    const vehicles = sqlite.prepare('SELECT * FROM vehicles ORDER BY created_at DESC').all();
    const dealerships = sqlite.prepare('SELECT * FROM dealerships ORDER BY created_at DESC').all();

    res.json({ companies, users, vehicles, dealerships });
  });

  return router;
}
