import React, { useState, useEffect, useCallback } from 'react';
import {
  Building2,
  CheckCircle2,
  FileText,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { api } from '../../services/api';
import { AdminVerificationApprovalPanel } from './AdminVerificationApprovalPanel';

interface Props {
  onNotify: (msg: string) => void;
}

export const SuperAdminVerificationHubPanel: React.FC<Props> = ({ onNotify }) => {
  const [hubData, setHubData] = useState<{ companies: any[]; companyReviewLogs: any[] }>({
    companies: [],
    companyReviewLogs: [],
  });
  const [remarksMap, setRemarksMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadHub = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminVerificationHub();
      setHubData(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to load company verification queue.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHub();
  }, [loadHub]);

  const applyCompanyDecision = async (
    companyId: string,
    decision: 'mark_under_review' | 'request_documents' | 'verify_documents'
  ) => {
    setError('');
    try {
      const remarks = remarksMap[companyId] || '';
      const res = await api.decideSuperAdminCompanyVerification(companyId, { decision, remarks });
      onNotify(`Company verification updated: ${res.verificationSummary?.status}`);
      await loadHub();
    } catch (err: any) {
      setError(err?.message || 'Verification decision failed.');
    }
  };

  return (
    <div className="space-y-6 text-xs">
      {/* Individual User / Employee / Dealer / Customer & Document KYC Approval + Sessions + RBAC */}
      <AdminVerificationApprovalPanel portalLabel="Super Admin" />

      {/* Corporate Company & Supporting Documents Verification Queue */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Company KYB &amp; Document Review Desk
            </div>
            <h3 className="text-base font-bold text-white mt-0.5">
              Registered Companies &amp; Corporate Filings Verification ({hubData.companies.length})
            </h3>
            <p className="text-slate-400 mt-0.5">
              Perform Super Admin corporate document compliance review. Final workspace activation remains restricted to the Founder / CEO.
            </p>
          </div>
          <button
            type="button"
            onClick={loadHub}
            className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 font-semibold flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Queue</span>
          </button>
        </div>

        {error && <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>}

        <div className="space-y-3">
          {hubData.companies.map((c) => (
            <div key={c.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Building2 className="w-4 h-4 text-cyan-400" />
                    <span className="font-bold text-white text-sm">{c.name}</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-900 border border-slate-700 text-cyan-300">
                      {c.status}
                    </span>
                  </div>
                  <div className="text-slate-400 mt-0.5">
                    {c.city}, {c.country} · Rep: {c.authorized_rep} · Reg: {c.registration_details} · Tax ID: {c.tax_id || 'N/A'}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Attached Docs: {c.documents?.length || 0}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  value={remarksMap[c.id] || ''}
                  onChange={(e) => setRemarksMap({ ...remarksMap, [c.id]: e.target.value })}
                  placeholder="Compliance remarks / missing document instructions..."
                  className="flex-1 rounded-xl bg-slate-900 border border-slate-700 px-3 py-1.5 text-white"
                />
                <button
                  type="button"
                  onClick={() => applyCompanyDecision(c.id, 'mark_under_review')}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-semibold shrink-0"
                >
                  Under Review
                </button>
                <button
                  type="button"
                  onClick={() => applyCompanyDecision(c.id, 'verify_documents')}
                  className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold flex items-center gap-1 shrink-0"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verify Docs</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyCompanyDecision(c.id, 'request_documents')}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold shrink-0"
                >
                  Request Additional Docs
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Company Verification Audit Log */}
        {hubData.companyReviewLogs.length > 0 && (
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>Corporate Verification Audit Trail</span>
            </h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {hubData.companyReviewLogs.map((l) => (
                <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex justify-between gap-2">
                  <div>
                    <span className="font-mono text-cyan-300 font-bold">{l.action}</span>{' '}
                    <span className="text-slate-300">— {l.details}</span>
                    <div className="text-[10px] text-slate-500">By {l.actor_name} ({l.actor_role}) · IP {l.ip_address}</div>
                  </div>
                  <span className="font-mono text-[10px] text-slate-500 shrink-0">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
