import React, { useState } from 'react';
import {
  Smartphone,
  Apple,
  Battery,
  Zap,
  Wrench,
  ShieldCheck,
  Bell,
  Code,
  Download,
  Copy,
  Check,
  Navigation,
  Lock,
  Unlock,
  Wind,
  Layers,
  FileText,
  Info,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const MobilePreview: React.FC = () => {
  const { currentUser, formatPrice } = useApp();
  const [deviceType, setDeviceType] = useState<'ios' | 'android'>('ios');
  const [activeScreen, setActiveScreen] = useState<'home' | 'battery' | 'service' | 'charging'>('home');
  const [isLocked, setIsLocked] = useState(true);
  const [climateActive, setClimateActive] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'main' | 'api' | 'pubspec'>('main');
  const [copied, setCopied] = useState(false);
  const [pushNotif, setPushNotif] = useState<string | null>(null);

  const triggerPush = (msg: string) => {
    setPushNotif(msg);
    setTimeout(() => {
      setPushNotif(null);
    }, 4000);
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const FLUTTER_MAIN_DART = `// BYD Global Mobility Platform - Flutter Native App (Android & iOS)
// Location: /mobile/lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'screens/dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ApiService()),
      ],
      child: const BydMobilityApp(),
    ),
  );
}

class BydMobilityApp extends StatelessWidget {
  const BydMobilityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BYD Global Mobility',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF030712),
        primaryColor: const Color(0xFF06B6D4),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF06B6D4),
          secondary: Color(0xFF3B82F6),
          surface: Color(0xFF0F172A),
        ),
        fontFamily: 'PlusJakartaSans',
      ),
      home: const DashboardScreen(),
    );
  }
}`;

  const FLUTTER_API_SERVICE = `// BYD Secure Enterprise API Client for Mobile
// Location: /mobile/lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService extends ChangeNotifier {
  static const String baseUrl = 'https://api.bydglobal.internal/v1';
  final _storage = const FlutterSecureStorage();

  Future<Map<String, dynamic>> fetchVehicleTelemetry(String vin) async {
    final token = await _storage.read(key: 'jwt_bearer_token');
    final response = await http.get(
      Uri.parse('\$baseUrl/vehicles/\$vin/telemetry'),
      headers: {
        'Authorization': 'Bearer \$token',
        'X-Client-Platform': 'Flutter-Native-v1.0.0',
        'X-Country-Code': 'PK',
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load authorized vehicle state');
    }
  }

  Future<bool> triggerRemoteClimate({required String vin, required bool enable}) async {
    // High-security command signed with ephemeral mobile challenge
    final token = await _storage.read(key: 'jwt_bearer_token');
    final res = await http.post(
      Uri.parse('\$baseUrl/vehicles/\$vin/commands/climate'),
      headers: {'Authorization': 'Bearer \$token', 'Content-Type': 'application/json'},
      body: json.encode({'state': enable ? 'ON' : 'OFF', 'tempCelsius': 22.0}),
    );
    return res.statusCode == 200;
  }
}`;

  const FLUTTER_PUBSPEC = `name: byd_global_mobility
description: "BYD Global Mobility & Intelligent Operations Native Mobile Client."
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.6
  provider: ^6.1.1
  http: ^1.2.0
  flutter_secure_storage: ^9.0.0
  google_maps_flutter: ^2.5.3
  flutter_local_notifications: ^17.0.0
  fl_chart: ^0.66.0
  qr_flutter: ^4.1.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/images/
    - assets/icons/`;

  return (
    <div className="space-y-8 pb-12">
      {/* Notice Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
              Multi-Platform Native Architecture
            </span>
            <h2 className="text-lg font-black text-white">Flutter Mobile Client Preview (Android & iOS)</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            This module provides a live interactive simulator of the dedicated native mobile applications (Android APK & iOS IPA), designed to run off the same unified backend REST APIs as the web platform.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setDeviceType('ios')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                deviceType === 'ios'
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Apple className="w-3.5 h-3.5" />
              <span>iPhone 16 Pro</span>
            </button>
            <button
              onClick={() => setDeviceType('android')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                deviceType === 'android'
                  ? 'bg-cyan-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Pixel Android</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Interactive Mobile Device Simulator */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="mb-2 text-xs text-slate-400 flex items-center gap-2">
            <span>Interactive Mobile Screen Simulator</span>
            <span>•</span>
            <button
              onClick={() => triggerPush('Mega Motor 3S: Your BYD Seal routine service slot is confirmed for tomorrow 11:00 AM.')}
              className="text-[11px] font-bold text-cyan-400 hover:underline flex items-center gap-1"
            >
              <Bell className="w-3 h-3" />
              <span>Test Push Alert</span>
            </button>
          </div>

          {/* Physical Phone Frame */}
          <div
            className={`w-[320px] sm:w-[350px] h-[670px] bg-slate-950 rounded-[48px] p-3 shadow-2xl border-4 ${
              deviceType === 'ios' ? 'border-slate-800 ring-4 ring-slate-900' : 'border-slate-800 ring-2 ring-cyan-500/30'
            } relative flex flex-col justify-between overflow-hidden select-none`}
          >
            {/* Dynamic Island / Notch / Speaker */}
            {deviceType === 'ios' ? (
              <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-30 flex items-center justify-between px-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-950 border border-cyan-500/40" />
              </div>
            ) : (
              <div className="absolute top-3 left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 rounded-full z-30 border border-slate-700" />
            )}

            {/* Mobile Screen Content */}
            <div className="w-full h-full bg-gradient-to-b from-slate-900 via-slate-950 to-black rounded-[38px] p-4 pt-9 flex flex-col justify-between text-slate-100 overflow-y-auto relative">
              {/* Push Notification Overlay Banner */}
              {pushNotif && (
                <div className="absolute top-8 left-3 right-3 z-40 bg-slate-900/95 border border-cyan-500/50 rounded-2xl p-3 shadow-2xl backdrop-blur-md animate-bounce">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-cyan-500 text-slate-950 flex items-center justify-center font-black text-[10px]">
                      BYD
                    </div>
                    <span className="text-[11px] font-bold text-white">BYD Mobility Cloud</span>
                    <span className="text-[9px] text-slate-400 ml-auto">Now</span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1">{pushNotif}</p>
                </div>
              )}

              {/* Status Bar */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-1 pb-2">
                <span className="font-bold text-white">09:41</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-cyan-400">5G</span>
                  <Battery className="w-3.5 h-3.5 text-emerald-400" />
                </div>
              </div>

              {/* Screen Body */}
              {activeScreen === 'home' && (
                <div className="space-y-4 pt-1 flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-base font-black text-white">BYD Seal AWD</h4>
                      <p className="text-[10px] text-slate-400">KHI-EV-882 • Karachi Flagship</p>
                    </div>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                      CONNECTED
                    </span>
                  </div>

                  {/* Vehicle Graphic Visual */}
                  <div className="relative rounded-2xl overflow-hidden h-32 border border-slate-800 bg-slate-900 flex items-center justify-center">
                    <img
                      src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=600&q=80"
                      alt="BYD Seal"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                    <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[11px]">
                      <span className="text-cyan-300 font-bold">Estimated Range</span>
                      <span className="font-mono text-emerald-400 font-extrabold text-sm">485 km</span>
                    </div>
                  </div>

                  {/* Remote Controls Simulation */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setIsLocked(!isLocked)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 transition ${
                        isLocked
                          ? 'bg-slate-900 border-slate-700 text-slate-300'
                          : 'bg-cyan-950/60 border-cyan-500 text-cyan-300'
                      }`}
                    >
                      {isLocked ? <Lock className="w-4 h-4 text-cyan-400" /> : <Unlock className="w-4 h-4 text-emerald-400" />}
                      <span className="text-[11px] font-bold">{isLocked ? 'Locked' : 'Unlocked'}</span>
                    </button>

                    <button
                      onClick={() => setClimateActive(!climateActive)}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 transition ${
                        climateActive
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-900 border-slate-700 text-slate-300'
                      }`}
                    >
                      <Wind className={`w-4 h-4 ${climateActive ? 'text-cyan-400 animate-spin' : 'text-slate-400'}`} />
                      <span className="text-[11px] font-bold">{climateActive ? 'AC: 22°C (ON)' : 'AC Climate'}</span>
                    </button>
                  </div>

                  {/* Quick Metrics */}
                  <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400">Blade Battery SoH</span>
                      <p className="text-sm font-black text-emerald-400 mt-0.5">98.4% Optimal</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400">Current SoC</span>
                      <p className="text-sm font-black text-cyan-400 mt-0.5">82% (Plugged)</p>
                    </div>
                  </div>
                </div>
              )}

              {activeScreen === 'battery' && (
                <div className="space-y-3 pt-1 flex-1">
                  <h4 className="text-sm font-bold text-white">Blade Battery Health</h4>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Pack Chemistry:</span>
                      <span className="font-bold text-white">Lithium Iron Phosphate (LFP)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Thermal Temp:</span>
                      <span className="font-semibold text-cyan-300">29.4°C (Normal)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cell Delta Voltage:</span>
                      <span className="font-mono text-emerald-400">0.012 V</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Warranty Expiry:</span>
                      <span className="text-slate-300">2034-11-11 (8 Yrs)</span>
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800 text-[10px] text-emerald-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Nail penetration test certified cell safety.</span>
                  </div>
                </div>
              )}

              {activeScreen === 'service' && (
                <div className="space-y-3 pt-1 flex-1">
                  <h4 className="text-sm font-bold text-white">Digital Service Ticket</h4>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-[11px]">
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded">
                      BYD-SVC-2026-101
                    </span>
                    <h5 className="font-bold text-white mt-1">Periodic Maintenance (10,000 km)</h5>
                    <p className="text-slate-400 text-[10px]">Mega Motor Clifton • Tomorrow 11:00 AM</p>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
                      <div className="bg-cyan-500 h-full w-2/3" />
                    </div>
                    <span className="text-[10px] text-cyan-400 font-semibold block text-right">Step 4: In Progress</span>
                  </div>
                </div>
              )}

              {activeScreen === 'charging' && (
                <div className="space-y-3 pt-1 flex-1">
                  <h4 className="text-sm font-bold text-white">Nearby Verified Chargers</h4>
                  <div className="space-y-2 text-[11px]">
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-cyan-500/30">
                      <div className="flex justify-between">
                        <span className="font-bold text-white">M-2 Sukheke North</span>
                        <span className="text-emerald-400 font-mono">180 kW</span>
                      </div>
                      <p className="text-slate-400 text-[10px]">Motorway M-2 • 4 Plugs Available</p>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                      <div className="flex justify-between">
                        <span className="font-bold text-white">Clifton Flagship DC Hub</span>
                        <span className="text-cyan-400 font-mono">120 kW</span>
                      </div>
                      <p className="text-slate-400 text-[10px]">Karachi • 2 Plugs Available</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Bottom In-App Nav Bar */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-around text-slate-400 text-[9px] font-semibold">
                <button
                  onClick={() => setActiveScreen('home')}
                  className={`flex flex-col items-center ${activeScreen === 'home' ? 'text-cyan-400 font-bold' : ''}`}
                >
                  <Smartphone className="w-4 h-4 mb-0.5" />
                  <span>Fleet</span>
                </button>
                <button
                  onClick={() => setActiveScreen('battery')}
                  className={`flex flex-col items-center ${activeScreen === 'battery' ? 'text-cyan-400 font-bold' : ''}`}
                >
                  <Battery className="w-4 h-4 mb-0.5" />
                  <span>Battery</span>
                </button>
                <button
                  onClick={() => setActiveScreen('service')}
                  className={`flex flex-col items-center ${activeScreen === 'service' ? 'text-cyan-400 font-bold' : ''}`}
                >
                  <Wrench className="w-4 h-4 mb-0.5" />
                  <span>Service</span>
                </button>
                <button
                  onClick={() => setActiveScreen('charging')}
                  className={`flex flex-col items-center ${activeScreen === 'charging' ? 'text-cyan-400 font-bold' : ''}`}
                >
                  <Zap className="w-4 h-4 mb-0.5" />
                  <span>Chargers</span>
                </button>
              </div>

              {/* iOS Home Indicator Bar */}
              {deviceType === 'ios' && (
                <div className="w-28 h-1 bg-slate-600 rounded-full mx-auto mt-2" />
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Mobile Architecture & Flutter Project Code Explorer */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Code className="w-4 h-4 text-cyan-400" />
                  <span>Cross-Platform Flutter Native Project</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Shared enterprise codebase delivering native 60fps performance on Android APK and Apple iOS IPA
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    copyCode(
                      activeCodeTab === 'main'
                        ? FLUTTER_MAIN_DART
                        : activeCodeTab === 'api'
                        ? FLUTTER_API_SERVICE
                        : FLUTTER_PUBSPEC
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 text-xs text-slate-300 hover:text-white"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
                  <span>{copied ? 'Copied' : 'Copy File'}</span>
                </button>
              </div>
            </div>

            {/* Code Tabs */}
            <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs">
              <button
                onClick={() => setActiveCodeTab('main')}
                className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition ${
                  activeCodeTab === 'main'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                lib/main.dart
              </button>
              <button
                onClick={() => setActiveCodeTab('api')}
                className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition ${
                  activeCodeTab === 'api'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                lib/services/api_service.dart
              </button>
              <button
                onClick={() => setActiveCodeTab('pubspec')}
                className={`px-3 py-1.5 rounded-lg font-mono font-semibold transition ${
                  activeCodeTab === 'pubspec'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                pubspec.yaml
              </button>
            </div>

            {/* Code Box */}
            <div className="rounded-xl bg-slate-950 border border-slate-850 p-4 font-mono text-xs text-slate-300 overflow-x-auto max-h-[380px]">
              <pre>
                {activeCodeTab === 'main' && FLUTTER_MAIN_DART}
                {activeCodeTab === 'api' && FLUTTER_API_SERVICE}
                {activeCodeTab === 'pubspec' && FLUTTER_PUBSPEC}
              </pre>
            </div>

            {/* Mobile Build & Distribution Specification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 space-y-1">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Android Build & Release</span>
                </span>
                <p className="text-slate-400 text-[11px]">
                  Build Command: <code className="text-cyan-300">flutter build appbundle --release</code>
                </p>
                <p className="text-slate-400 text-[11px]">
                  Target: Google Play Store + Samsung Galaxy Store. Signing keys: Keystore v2 / SHA-256.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-850 space-y-1">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Apple className="w-3.5 h-3.5 text-cyan-400" />
                  <span>iOS Build & Distribution</span>
                </span>
                <p className="text-slate-400 text-[11px]">
                  Build Command: <code className="text-cyan-300">flutter build ipa --release</code>
                </p>
                <p className="text-slate-400 text-[11px]">
                  Target: Apple App Store Connect & TestFlight beta rings. Push: APNs HTTP/2 certificate.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
