import React, { useState } from 'react';
import { AlertCircle, ShieldCheck, ChevronDown, ChevronUp, RotateCcw } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DemoNoticeBadge: React.FC = () => {
  const [expanded, setExpanded] = useState(false);
  const [confirmingReset, setConfirmingReset] = useState(false);
  const { resetDemoData, language } = useApp();

  return (
    <div className="w-full bg-slate-900/90 border-b border-cyan-500/20 px-3 py-1.5 text-xs text-slate-300 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-[10px] font-bold text-cyan-300 tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            Independent Prototype
          </span>
          <p className="text-[11px] text-slate-300 font-medium">
            <strong className="text-white">BYD PAKISTAN 360</strong> | Founded & Created By <strong className="text-cyan-300">INTEKHAB ALAM</strong>, FOUNDER.
            <span className="hidden md:inline text-slate-400 ml-1">
              Independent enterprise EV platform prototype (Target Evaluation: PKR 20–25M).
            </span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          {confirmingReset ? (
            <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-0.5 rounded border border-cyan-500/40">
              <span className="text-[10px] text-cyan-300">Reset demo data?</span>
              <button
                onClick={() => {
                  resetDemoData();
                  setConfirmingReset(false);
                }}
                className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 px-1"
              >
                Yes
              </button>
              <button
                onClick={() => setConfirmingReset(false)}
                className="text-[10px] text-slate-400 hover:text-white px-1"
              >
                No
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmingReset(true)}
              className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-cyan-300 transition px-2 py-0.5 rounded hover:bg-slate-800"
              title="Reset to factory demo data"
            >
              <RotateCcw className="w-3 h-3 text-cyan-400" />
              <span className="hidden sm:inline">Reset Sandbox</span>
            </button>
          )}

          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 px-1.5 py-0.5 rounded hover:bg-slate-800"
          >
            <span>Legal Disclaimer</span>
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="mt-2 pt-2 border-t border-slate-800 max-w-7xl mx-auto text-[11px] text-slate-400 space-y-1">
          <p>
            <strong className="text-slate-300">Compliance & Intellectual Property:</strong> This software is an independent engineering concept and functional demonstration architecture crafted for potential evaluation by authorized stakeholders in Pakistan. It does not access proprietary BYD Co., Ltd. or Mega Motor Company internal servers. All battery diagnostics, telematics, and warranty workflows run on a client-verified local database and server-side Gemini 3.8 Flash intelligence module.
          </p>
        </div>
      )}
    </div>
  );
};
