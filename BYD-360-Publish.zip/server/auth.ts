import express, { Request, Response, NextFunction } from 'express';
import {
  sqlite,
  hashPassword,
  verifyPassword,
  sha256,
  generateSecureToken,
  generateNumericOtp,
  validatePasswordStrength,
  generateTotpSecret,
  verifyTotpCode,
  normalizePhone,
  logOwnerAudit,
  logAdminActivity,
  logCompanyActivity,
  logCountryActivity,
  logBranchActivity,
  logEmployeeActivity,
  logDealerActivity,
  logCustomerActivity,
  logSecurityEvent,
  logSecurityAudit,
  logLoginActivity,
  markLoginSessionTerminated,
  checkRbacAction,
  RbacAction,
  syncUnifiedSecurityRegistry,
  getSystemSetting,
  setSystemSetting,
  nowIso,
} from './db';
import { dispatchVerificationEmail, isSmtpConfigured } from './mailer';

export const CANONICAL_SA_PERMISSIONS = [
  'users.view',
  'users.create',
  'users.update',
  'users.suspend',
  'employees.manage',
  'dealers.manage',
  'customers.manage',
  'vehicles.manage',
  'bookings.manage',
  'sales.view',
  'reports.view',
  'notifications.manage',
  'settings.manage',
  'audit_logs.view',
] as const;

export type CanonicalSaPermission = (typeof CANONICAL_SA_PERMISSIONS)[number];

export const CANONICAL_COMPANY_ADMIN_PERMISSIONS = [
  'company.profile.manage',
  'employees.manage',
  'employees.permissions.manage',
  'branches.manage',
  'dealers.manage',
  'vehicles.manage',
  'customers.manage',
  'sales.manage',
  'finance.manage',
  'reports.view',
  'reports.export',
] as const;

export type CanonicalCompanyAdminPermission = (typeof CANONICAL_COMPANY_ADMIN_PERMISSIONS)[number];

export const CANONICAL_COUNTRY_MANAGER_PERMISSIONS = [
  'country.profile.manage',
  'companies.view',
  'companies.operations.manage',
  'branches.view',
  'branches.manage',
  'dealers.manage',
  'employees.view',
  'employees.manage',
  'vehicles.manage',
  'customers.view',
  'customers.pii.reveal',
  'sales.view',
  'finance.sensitive.manage',
  'reports.view',
  'reports.export',
] as const;

export type CanonicalCountryManagerPermission = (typeof CANONICAL_COUNTRY_MANAGER_PERMISSIONS)[number];

export const CANONICAL_BRANCH_MANAGER_PERMISSIONS = [
  'branch.profile.manage',
  'employees.view',
  'employees.manage',
  'vehicles.view',
  'vehicles.manage',
  'sales.view',
  'sales.manage',
  'customers.view',
  'customers.manage',
  'customers.pii.reveal',
  'dealers.manage',
  'finance.view',
  'finance.refund.manage',
  'service.manage',
  'reports.view',
  'reports.export',
] as const;

export type CanonicalBranchManagerPermission = (typeof CANONICAL_BRANCH_MANAGER_PERMISSIONS)[number];

export const CANONICAL_EMPLOYEE_PERMISSIONS = [
  'employee.profile.manage',
  'employee.attendance.manage',
  'employee.leave.manage',
  'employee.tasks.manage',
  'employee.salary.view',
  'employee.documents.manage',
  'employee.performance.view',
  'employee.support.manage',
] as const;

export type CanonicalEmployeePermission = (typeof CANONICAL_EMPLOYEE_PERMISSIONS)[number];

export const CANONICAL_DEALER_PERMISSIONS = [
  'dealer.dashboard.view',
  'dealer.profile.manage',
  'dealer.inventory.view',
  'dealer.vin.view',
  'dealer.crm.manage',
  'dealer.bookings.manage',
  'dealer.sales.view',
  'dealer.commissions.view',
  'dealer.documents.manage',
  'dealer.reports.view',
  'dealer.reports.export',
  'dealer.support.manage',
] as const;

export type CanonicalDealerPermission = (typeof CANONICAL_DEALER_PERMISSIONS)[number];

export interface AuthContext {
  sessionId: string;
  userId: string;
  subjectType: 'founder' | 'super_admin' | 'company_admin' | 'country_manager' | 'branch_manager' | 'employee' | 'dealer' | 'customer' | 'user';
  companyId: string | null;
  branchId?: string | null;
  branchName?: string | null;
  managerCode?: string | null;
  employeeId?: string | null;
  employeeCode?: string | null;
  departmentId?: string | null;
  department?: string | null;
  reportingManagerName?: string | null;
  dealerId?: string | null;
  dealerCode?: string | null;
  dealerCategory?: string | null;
  customerId?: string | null;
  customerCode?: string | null;
  mobileVerified?: boolean;
  verificationStatus?: string | null;
  role: string;
  fullName: string;
  email: string;
  mobile: string;
  country: string;
  city: string;
  dealershipId: string | null;
  permissions: string[];
  twoFactorVerified: boolean;
}

declare global {
  namespace Express {
    interface Request {
      auth?: AuthContext | null;
    }
  }
}

export const SESSION_COOKIE_NAME = 'byd360_session';

function parseCookies(cookieHeader?: string): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const k = decodeURIComponent(part.slice(0, idx).trim());
    const v = decodeURIComponent(part.slice(idx + 1).trim());
    result[k] = v;
  }
  return result;
}

export function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.trim()) {
    return forwarded.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || req.ip || 'unknown';
}

function setSessionCookie(res: Response, rawToken: string, maxAgeMs: number) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProd,
    path: '/',
    maxAge: maxAgeMs,
  });
}

function clearSessionCookie(res: Response) {
  res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
}

// ---------------------------------------------------------------------------
// Sliding-Window Rate Limiter for Auth Endpoints
// ---------------------------------------------------------------------------
const rateLimitBuckets = new Map<string, number[]>();

export function rateLimitAuth(bucketName: string, maxRequests = 20, windowMs = 60_000) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = getClientIp(req);
    const key = `${bucketName}:${ip}`;
    const now = Date.now();
    const prev = rateLimitBuckets.get(key) || [];
    const recent = prev.filter((ts) => now - ts < windowMs);
    if (recent.length >= maxRequests) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'RATE_LIMIT_EXCEEDED',
        details: `Rate limit exceeded on "${bucketName}" from IP ${ip} (${recent.length}/${maxRequests} requests in window).`,
        ipAddress: ip,
      });
      res.status(429).json({
        error: 'Too many authentication requests from this address. Please wait a minute and try again.',
      });
      return;
    }
    recent.push(now);
    rateLimitBuckets.set(key, recent);
    next();
  };
}

export function requireCsrfProtection(req: Request, res: Response, next: NextFunction) {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
    return next();
  }

  // Enforce Origin / Sec-Fetch-Site validation when session cookie is present
  const hasCookie = Boolean(req.headers.cookie && req.headers.cookie.includes('byd360_session='));
  const secFetchSite = String(req.headers['sec-fetch-site'] || '').toLowerCase();
  if (hasCookie && secFetchSite === 'cross-site') {
    res.status(403).json({ error: 'Cross-site state-changing request rejected by CSRF protection.' });
    return;
  }

  const originHeader = String(req.headers.origin || '').trim();
  const refererHeader = String(req.headers.referer || '').trim();
  const hostHeader = String(req.headers['x-forwarded-host'] || req.headers.host || '').trim().toLowerCase();

  if (hasCookie && (originHeader || refererHeader)) {
    const trustedRaw = [
      process.env.APP_URL || '',
      ...(process.env.CSRF_TRUSTED_ORIGINS || '').split(','),
    ]
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);

    const checkUrlHost = (rawUrl: string): boolean => {
      try {
        const parsed = new URL(rawUrl);
        if (hostHeader && parsed.host.toLowerCase() === hostHeader) return true;
        return trustedRaw.some((t) => {
          try {
            return new URL(t).host.toLowerCase() === parsed.host.toLowerCase();
          } catch {
            return t === parsed.host.toLowerCase();
          }
        });
      } catch {
        return false;
      }
    };

    const validSource = originHeader ? checkUrlHost(originHeader) : checkUrlHost(refererHeader);
    if (!validSource) {
      logSecurityAudit({
        actorId: req.auth?.userId || 'anonymous',
        actorName: req.auth?.fullName || 'Unknown',
        actorRole: req.auth?.role || 'Anonymous',
        action: 'CSRF_ORIGIN_BLOCKED',
        category: 'CSRF Protection',
        severity: 'CRITICAL',
        details: `Blocked cross-origin mutation on ${req.originalUrl}`,
        ipAddress: String(req.headers['x-forwarded-for'] || req.ip || 'unknown'),
      });
      res.status(403).json({ error: 'CSRF validation failed: untrusted request origin.' });
      return;
    }
  }

  next();
}

function resolveUserPermissions(userId: string, role: string): string[] {
  const custom = sqlite
    .prepare('SELECT permissions_json FROM user_permissions WHERE user_id = ?')
    .get(userId) as { permissions_json: string } | undefined;
  if (custom) {
    try {
      const parsed = JSON.parse(custom.permissions_json);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      // fallback to role defaults
    }
  }
  const roleRow = sqlite
    .prepare('SELECT permissions_json FROM user_roles WHERE role_key = ?')
    .get(role) as { permissions_json: string } | undefined;
  if (roleRow) {
    try {
      return JSON.parse(roleRow.permissions_json);
    } catch {
      return [];
    }
  }
  if (role === 'Super Admin') {
    const rp = sqlite
      .prepare("SELECT permission_key FROM role_permissions WHERE role_key = 'Super Admin'")
      .all() as Array<{ permission_key: string }>;
    return rp.map((r) => r.permission_key);
  }
  return [];
}

function sanitizeSaPermissions(input: unknown): string[] {
  if (!Array.isArray(input)) return [...CANONICAL_SA_PERMISSIONS];
  const allowed = new Set<string>(CANONICAL_SA_PERMISSIONS);
  return Array.from(new Set(input.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

export function sanitizeCompanyAdminPermissions(input: unknown): string[] {
  if (!Array.isArray(input)) return [...CANONICAL_COMPANY_ADMIN_PERMISSIONS];
  const allowed = new Set<string>(CANONICAL_COMPANY_ADMIN_PERMISSIONS);
  return Array.from(new Set(input.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

function resolveCompanyAdminPermissions(adminId: string, companyId: string): string[] {
  const row = sqlite
    .prepare('SELECT permissions_json FROM company_permissions WHERE company_id = ? AND subject_id = ?')
    .get(companyId, adminId) as { permissions_json: string } | undefined;
  if (row) {
    try {
      const parsed = JSON.parse(row.permissions_json);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      return [];
    }
  }
  return [];
}

export function sanitizeCountryManagerPermissions(input: unknown): string[] {
  if (!Array.isArray(input)) {
    return CANONICAL_COUNTRY_MANAGER_PERMISSIONS.filter((p) => p !== 'finance.sensitive.manage');
  }
  const allowed = new Set<string>(CANONICAL_COUNTRY_MANAGER_PERMISSIONS);
  return Array.from(new Set(input.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

function resolveCountryManagerPermissions(managerId: string): string[] {
  const row = sqlite
    .prepare('SELECT permissions_json FROM country_permissions WHERE manager_id = ?')
    .get(managerId) as { permissions_json: string } | undefined;
  if (row) {
    try {
      const parsed = JSON.parse(row.permissions_json);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      return [];
    }
  }
  return [];
}

export function sanitizeBranchManagerPermissions(input: unknown): string[] {
  if (!Array.isArray(input)) {
    return CANONICAL_BRANCH_MANAGER_PERMISSIONS.filter((p) => p !== 'finance.refund.manage');
  }
  const allowed = new Set<string>(CANONICAL_BRANCH_MANAGER_PERMISSIONS);
  return Array.from(new Set(input.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

function resolveBranchManagerPermissions(managerId: string): string[] {
  const row = sqlite
    .prepare('SELECT permissions_json FROM branch_permissions WHERE manager_id = ?')
    .get(managerId) as { permissions_json: string } | undefined;
  if (row) {
    try {
      const parsed = JSON.parse(row.permissions_json);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      return [];
    }
  }
  return [];
}

export function sanitizeEmployeePermissions(input: unknown): string[] {
  if (!Array.isArray(input)) {
    return [...CANONICAL_EMPLOYEE_PERMISSIONS];
  }
  const allowed = new Set<string>(CANONICAL_EMPLOYEE_PERMISSIONS);
  return Array.from(new Set(input.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

function resolveEmployeePermissions(emp: any): string[] {
  try {
    const parsed = JSON.parse(emp?.permissions_json || '[]');
    if (Array.isArray(parsed)) {
      const allowed = new Set<string>(CANONICAL_EMPLOYEE_PERMISSIONS);
      return parsed.map((p) => String(p).trim()).filter((p) => allowed.has(p));
    }
  } catch {
    // ignore
  }
  return [...CANONICAL_EMPLOYEE_PERMISSIONS];
}

export function sanitizeDealerPermissions(raw: unknown): string[] {
  const allowed = new Set<string>(CANONICAL_DEALER_PERMISSIONS);
  if (!Array.isArray(raw)) return [...CANONICAL_DEALER_PERMISSIONS];
  return Array.from(new Set(raw.map((p) => String(p).trim()).filter((p) => allowed.has(p))));
}

export function resolveDealerPermissions(dealerId: string): string[] {
  const allowed = new Set<string>(CANONICAL_DEALER_PERMISSIONS);
  const row = sqlite
    .prepare('SELECT permissions_json FROM dealer_permissions WHERE dealer_id = ?')
    .get(dealerId) as { permissions_json?: string } | undefined;
  if (row?.permissions_json) {
    try {
      const parsed = JSON.parse(row.permissions_json);
      if (Array.isArray(parsed)) {
        return parsed.map((p) => String(p).trim()).filter((p) => allowed.has(p));
      }
    } catch {
      // ignore
    }
  }
  return [...CANONICAL_DEALER_PERMISSIONS];
}

function createSession(params: {
  userId: string;
  subjectType: 'founder' | 'super_admin' | 'company_admin' | 'country_manager' | 'branch_manager' | 'employee' | 'dealer' | 'customer' | 'user';
  companyId: string | null;
  role: string;
  twoFactorVerified: boolean;
  req: Request;
  res: Response;
  timeoutMinutes?: number;
}) {
  const policy = getSystemSetting('security_policy', { sessionTimeoutMinutes: 120, idleTimeoutMinutes: 45 });
  const timeoutMins = params.timeoutMinutes || policy.sessionTimeoutMinutes || 120;
  const idleMins = policy.idleTimeoutMinutes || Number(process.env.SESSION_IDLE_MINUTES) || 45;
  const maxAgeMs = timeoutMins * 60 * 1000;
  const idleMs = idleMins * 60 * 1000;
  const rawToken = generateSecureToken(32);
  const tokenHash = sha256(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + maxAgeMs).toISOString();
  const idleExpiresAt = new Date(now.getTime() + idleMs).toISOString();
  const ua = String(params.req.headers['user-agent'] || 'Unknown Client').slice(0, 220);
  const ip = getClientIp(params.req);
  const sessionId = `sess_${generateSecureToken(8)}`;
  const deviceLabel = ua.includes('Mobile') ? 'Mobile Browser' : 'Desktop Workstation';
  const deviceFingerprint = sha256(`${ua}|${ip.split('.').slice(0, 3).join('.')}`).slice(0, 24);

  // Check for suspicious new IP/device compared to prior successful logins
  const prevLogin = sqlite
    .prepare('SELECT ip_address, device_fingerprint FROM login_activity_logs WHERE user_id = ? AND success = 1 ORDER BY created_at DESC LIMIT 1')
    .get(params.userId) as { ip_address?: string; device_fingerprint?: string } | undefined;
  const suspiciousNewDevice = Boolean(
    prevLogin &&
      ((prevLogin.ip_address && prevLogin.ip_address !== ip) ||
        (prevLogin.device_fingerprint && prevLogin.device_fingerprint !== deviceFingerprint))
  );

  sqlite
    .prepare(`
      INSERT INTO authentication_sessions (
        id, token_hash, user_id, subject_type, company_id, role, ip_address,
        user_agent, device_label, device_fingerprint, two_factor_verified, expires_at, idle_expires_at, last_activity_at, revoked, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `)
    .run(
      sessionId,
      tokenHash,
      params.userId,
      params.subjectType,
      params.companyId,
      params.role,
      ip,
      ua,
      deviceLabel,
      deviceFingerprint,
      params.twoFactorVerified ? 1 : 0,
      expiresAt,
      idleExpiresAt,
      now.toISOString(),
      now.toISOString()
    );

  if (params.subjectType === 'customer') {
    sqlite
      .prepare(`
        INSERT OR IGNORE INTO customer_sessions (
          id, customer_id, token_hash, device_label, ip_address, user_agent, revoked, last_activity_at, expires_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)
      `)
      .run(sessionId, params.userId, tokenHash, deviceLabel, ip, ua, now.toISOString(), expiresAt, now.toISOString());
  }

  let accountName: string | null = null;
  try {
    const uaRow = sqlite.prepare('SELECT full_name FROM user_accounts WHERE id = ?').get(params.userId) as { full_name?: string } | undefined;
    accountName = uaRow?.full_name || null;
    if (!accountName) {
      if (params.subjectType === 'founder') {
        accountName = (sqlite.prepare('SELECT founder_name FROM founder_accounts WHERE id = ?').get(params.userId) as any)?.founder_name || 'Intekhab Alam';
      } else if (params.subjectType === 'dealer') {
        accountName = (sqlite.prepare('SELECT business_name FROM dealer_accounts WHERE id = ?').get(params.userId) as any)?.business_name || null;
      } else {
        const tbl =
          params.subjectType === 'super_admin'
            ? 'super_admin_accounts'
            : params.subjectType === 'company_admin'
              ? 'company_admin_accounts'
              : params.subjectType === 'country_manager'
                ? 'country_manager_accounts'
                : params.subjectType === 'branch_manager'
                  ? 'branch_manager_accounts'
                  : params.subjectType === 'employee'
                    ? 'employee_accounts'
                    : params.subjectType === 'customer'
                      ? 'customer_accounts'
                      : 'users';
        accountName = (sqlite.prepare(`SELECT full_name FROM ${tbl} WHERE id = ?`).get(params.userId) as any)?.full_name || null;
      }
    }
  } catch {
    accountName = null;
  }

  logLoginActivity({
    userId: params.userId,
    subjectType: params.subjectType,
    identifier: params.userId,
    accountName,
    role: params.role,
    companyId: params.companyId,
    sessionId,
    success: true,
    mfaMethod: params.twoFactorVerified ? 'verified' : 'password',
    ipAddress: ip,
    userAgent: ua,
    deviceFingerprint,
    suspicious: suspiciousNewDevice,
    suspiciousReason: suspiciousNewDevice ? `New IP/device detected (prev IP: ${prevLogin?.ip_address || 'n/a'})` : null,
  });

  if (suspiciousNewDevice) {
    logSecurityAudit({
      actorId: params.userId,
      actorName: accountName || params.userId,
      actorRole: params.role,
      targetUserId: params.userId,
      companyId: params.companyId,
      action: 'SUSPICIOUS_NEW_DEVICE_LOGIN',
      category: 'Session Security',
      severity: 'WARNING',
      details: `Session created from new device/IP (${ip})`,
      ipAddress: ip,
      userAgent: ua,
    });
  }

  setSessionCookie(params.res, rawToken, maxAgeMs);
  return { sessionId, rawToken, expiresAt, idleExpiresAt };
}

// ---------------------------------------------------------------------------
// Auth & RBAC Middleware (Server-Authoritative: Never trusts client-supplied roles!)
// ---------------------------------------------------------------------------
export function attachAuthContext(req: Request, _res: Response, next: NextFunction) {
  req.auth = null;
  const cookies = parseCookies(req.headers.cookie);
  const authHeader = req.headers.authorization;
  let rawToken = cookies[SESSION_COOKIE_NAME];
  if (!rawToken && typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    rawToken = authHeader.slice(7).trim();
  }
  if (!rawToken) return next();

  const tokenHash = sha256(rawToken);
  const session = sqlite
    .prepare('SELECT * FROM authentication_sessions WHERE token_hash = ? AND revoked = 0')
    .get(tokenHash) as any;

  if (!session) return next();

  const now = Date.now();
  const nowStr = new Date(now).toISOString();
  if (new Date(session.expires_at).getTime() <= now) {
    sqlite
      .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'expired', revoked_at = ? WHERE id = ?")
      .run(nowStr, session.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(session.id);
    markLoginSessionTerminated(session.id, 'expired');
    logSecurityAudit({
      actorId: session.user_id,
      actorName: session.user_id,
      actorRole: session.role,
      targetUserId: session.user_id,
      companyId: session.company_id,
      action: 'SESSION_EXPIRED',
      category: 'Session Security',
      details: 'Session expired due to maximum lifetime.',
      ipAddress: getClientIp(req),
    });
    return next();
  }

  const policy = getSystemSetting('security_policy', { sessionTimeoutMinutes: 120, idleTimeoutMinutes: 45 });
  const idleMins = policy.idleTimeoutMinutes || Number(process.env.SESSION_IDLE_MINUTES) || 45;
  const idleMs = idleMins * 60 * 1000;
  const idleExceeded =
    (session.idle_expires_at && new Date(session.idle_expires_at).getTime() <= now) ||
    now - new Date(session.last_activity_at).getTime() > idleMs;

  if (idleExceeded) {
    sqlite
      .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'idle_timeout', revoked_at = ? WHERE id = ?")
      .run(nowStr, session.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(session.id);
    markLoginSessionTerminated(session.id, 'idle_timeout');
    logSecurityAudit({
      actorId: session.user_id,
      actorName: session.user_id,
      actorRole: session.role,
      targetUserId: session.user_id,
      companyId: session.company_id,
      action: 'SESSION_IDLE_TIMEOUT',
      category: 'Session Security',
      details: `Session automatically revoked after ${idleMins}m idle timeout.`,
      ipAddress: getClientIp(req),
    });
    return next();
  }

  const nextIdleExpiresAt = new Date(now + idleMs).toISOString();
  sqlite
    .prepare('UPDATE authentication_sessions SET last_activity_at = ?, idle_expires_at = ? WHERE id = ?')
    .run(nowStr, nextIdleExpiresAt, session.id);

  if (session.subject_type === 'founder') {
    const founder = sqlite.prepare('SELECT * FROM founder_accounts WHERE id = ?').get(session.user_id) as any;
    if (!founder || !founder.is_verified || !session.two_factor_verified) return next();

    req.auth = {
      sessionId: session.id,
      userId: founder.id,
      subjectType: 'founder',
      companyId: null,
      role: 'Founder / Owner',
      fullName: founder.founder_name,
      email: founder.email,
      mobile: founder.mobile,
      country: 'GLOBAL',
      city: 'Karachi HQ',
      dealershipId: null,
      permissions: ['*'],
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'super_admin') {
    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE id = ?').get(session.user_id) as any;
    if (!sa || sa.status !== 'Active' || !sa.email_verified || !session.two_factor_verified) return next();

    req.auth = {
      sessionId: session.id,
      userId: sa.id,
      subjectType: 'super_admin',
      companyId: null,
      role: 'Super Admin',
      fullName: sa.full_name,
      email: sa.email,
      mobile: sa.mobile,
      country: sa.country || 'PK',
      city: sa.city || 'Karachi',
      dealershipId: null,
      permissions: resolveUserPermissions(sa.id, 'Super Admin'),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'company_admin') {
    const ca = sqlite.prepare('SELECT * FROM company_admin_accounts WHERE id = ?').get(session.user_id) as any;
    if (!ca || ca.status !== 'Active' || !ca.email_verified || !session.two_factor_verified) return next();

    const comp = sqlite.prepare('SELECT id, country, city, status FROM companies WHERE id = ?').get(ca.company_id) as any;
    if (!comp || comp.status !== 'Approved') return next();

    req.auth = {
      sessionId: session.id,
      userId: ca.id,
      subjectType: 'company_admin',
      companyId: ca.company_id,
      role: 'Company Admin',
      fullName: ca.full_name,
      email: ca.email,
      mobile: ca.mobile,
      country: comp.country || 'PK',
      city: comp.city || 'Karachi',
      dealershipId: null,
      permissions: resolveCompanyAdminPermissions(ca.id, ca.company_id),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'country_manager') {
    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE id = ?').get(session.user_id) as any;
    if (!cm || cm.status !== 'Active' || !cm.email_verified || !session.two_factor_verified) return next();

    const countryRow = sqlite.prepare("SELECT id, name, headquarters_city, status FROM countries WHERE id = ? AND status = 'Active'").get(cm.country_id) as any;
    if (!countryRow) return next();

    const activeAssignment = sqlite
      .prepare("SELECT id FROM country_assignments WHERE manager_id = ? AND country_id = ? AND status = 'Active'")
      .get(cm.id, cm.country_id);
    if (!activeAssignment) return next();

    req.auth = {
      sessionId: session.id,
      userId: cm.id,
      subjectType: 'country_manager',
      companyId: null,
      managerCode: cm.manager_code,
      role: 'Country Manager',
      fullName: cm.full_name,
      email: cm.email,
      mobile: cm.mobile,
      country: cm.country_id,
      city: countryRow.headquarters_city || 'Karachi',
      dealershipId: null,
      permissions: resolveCountryManagerPermissions(cm.id),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'branch_manager') {
    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE id = ?').get(session.user_id) as any;
    if (!bm || bm.status !== 'Active' || !bm.email_verified || !session.two_factor_verified) return next();

    const branchRow = sqlite.prepare("SELECT * FROM branches WHERE id = ? AND status = 'Active'").get(bm.branch_id) as any;
    if (!branchRow) return next();

    const compRow = sqlite.prepare("SELECT id, status FROM companies WHERE id = ? AND status = 'Approved'").get(bm.company_id) as any;
    if (!compRow) return next();

    const countryRow = sqlite.prepare("SELECT id, status FROM countries WHERE id = ? AND status = 'Active'").get(bm.country_id) as any;
    if (!countryRow) return next();

    const activeAssignment = sqlite
      .prepare("SELECT id FROM branch_assignments WHERE manager_id = ? AND branch_id = ? AND status = 'Active'")
      .get(bm.id, bm.branch_id);
    if (!activeAssignment) return next();

    req.auth = {
      sessionId: session.id,
      userId: bm.id,
      subjectType: 'branch_manager',
      companyId: bm.company_id,
      branchId: bm.branch_id,
      branchName: branchRow.name,
      managerCode: bm.manager_code,
      role: 'Branch Manager',
      fullName: bm.full_name,
      email: bm.email,
      mobile: bm.mobile,
      country: bm.country_id,
      city: branchRow.city || 'Karachi',
      dealershipId: null,
      permissions: resolveBranchManagerPermissions(bm.id),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'employee') {
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(session.user_id) as any;
    if (!emp || emp.status === 'Suspended' || !emp.email_verified || !session.two_factor_verified) return next();

    const compRow = sqlite.prepare("SELECT id, name, country, city, status FROM companies WHERE id = ? AND status = 'Approved'").get(emp.company_id) as any;
    if (!compRow) return next();

    const branchRow = emp.branch_id
      ? (sqlite.prepare('SELECT id, name, city, country_id, status FROM branches WHERE id = ?').get(emp.branch_id) as any)
      : null;

    req.auth = {
      sessionId: session.id,
      userId: emp.id,
      subjectType: 'employee',
      companyId: emp.company_id,
      branchId: emp.branch_id || null,
      branchName: branchRow?.name || null,
      employeeId: emp.id,
      employeeCode: emp.employee_code,
      departmentId: emp.department_id || null,
      department: emp.department || 'Operations',
      reportingManagerName: emp.reporting_manager_name || null,
      role: emp.job_position || 'Employee',
      fullName: emp.full_name,
      email: emp.email,
      mobile: emp.mobile,
      country: emp.country_id || compRow.country || 'PK',
      city: branchRow?.city || compRow.city || 'Karachi',
      dealershipId: null,
      permissions: resolveEmployeePermissions(emp),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'dealer') {
    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(session.user_id) as any;
    if (
      !dealer ||
      dealer.status !== 'Active' ||
      dealer.verification_status !== 'Verified' ||
      !dealer.email_verified ||
      !session.two_factor_verified
    ) {
      return next();
    }

    const compRow = sqlite
      .prepare("SELECT id, name, country, city, status FROM companies WHERE id = ? AND status = 'Approved'")
      .get(dealer.company_id) as any;
    if (!compRow) return next();

    const branchRow = dealer.branch_id
      ? (sqlite.prepare('SELECT id, name, city FROM branches WHERE id = ?').get(dealer.branch_id) as any)
      : null;
    const profileRow = sqlite
      .prepare('SELECT city FROM dealer_profiles WHERE dealer_id = ?')
      .get(dealer.id) as any;

    req.auth = {
      sessionId: session.id,
      userId: dealer.id,
      subjectType: 'dealer',
      companyId: dealer.company_id,
      branchId: dealer.branch_id || null,
      branchName: branchRow?.name || null,
      dealerId: dealer.id,
      dealerCode: dealer.dealer_code,
      dealerCategory: dealer.category || 'Authorized Dealer',
      verificationStatus: dealer.verification_status,
      role: 'Dealer Owner',
      fullName: dealer.business_name,
      email: dealer.email,
      mobile: dealer.mobile,
      country: dealer.country_id || compRow.country || 'PK',
      city: profileRow?.city || branchRow?.city || compRow.city || 'Karachi',
      dealershipId: dealer.dealership_id || null,
      permissions: resolveDealerPermissions(dealer.id),
      twoFactorVerified: true,
    };
    return next();
  }

  if (session.subject_type === 'customer') {
    const cust = sqlite.prepare('SELECT * FROM customer_accounts WHERE id = ?').get(session.user_id) as any;
    if (!cust || cust.status !== 'Active' || !cust.email_verified) return next();

    const profileRow = sqlite.prepare('SELECT preferred_dealership_id FROM customer_profiles WHERE customer_id = ?').get(cust.id) as any;

    sqlite.prepare('UPDATE customer_sessions SET last_activity_at = ? WHERE id = ?').run(nowIso(), session.id);

    req.auth = {
      sessionId: session.id,
      userId: cust.id,
      subjectType: 'customer',
      companyId: cust.company_id || 'comp_byd_pk',
      branchId: cust.branch_id || null,
      customerId: cust.id,
      customerCode: cust.customer_code,
      mobileVerified: Boolean(cust.mobile_verified),
      verificationStatus: cust.verification_status,
      role: 'Customer',
      fullName: cust.full_name,
      email: cust.email,
      mobile: cust.mobile,
      country: cust.country || 'PK',
      city: cust.city || 'Karachi',
      dealershipId: profileRow?.preferred_dealership_id || null,
      permissions: ['customer.portal.access'],
      twoFactorVerified: true,
    };
    return next();
  }

  const user = sqlite.prepare('SELECT * FROM users WHERE id = ?').get(session.user_id) as any;
  if (!user || user.status !== 'Active') return next();

  if (user.company_id && user.role !== 'Customer') {
    const comp = sqlite.prepare('SELECT status FROM companies WHERE id = ?').get(user.company_id) as { status: string } | undefined;
    if (comp && comp.status !== 'Approved') return next();
  }

  req.auth = {
    sessionId: session.id,
    userId: user.id,
    subjectType: 'user',
    companyId: user.company_id || null,
    role: user.role,
    fullName: user.full_name,
    email: user.email,
    mobile: user.mobile,
    country: user.country || 'PK',
    city: user.city || 'Karachi',
    dealershipId: user.dealership_id || null,
    permissions: resolveUserPermissions(user.id, user.role),
    twoFactorVerified: Boolean(session.two_factor_verified),
  };

  return next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Authentication required. Please sign in with a valid account.' });
    return;
  }
  next();
}

export function requireFounder(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Founder authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'founder' || req.auth.role !== 'Founder / Owner') {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'UNAUTHORIZED_OWNER_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Subject "${req.auth.subjectType}" (${req.auth.role}) attempted to access private Founder/Owner endpoint: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This private resource is restricted exclusively to the Primary Owner (Intekhab Alam).',
    });
    return;
  }
  next();
}

export function requireSuperAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Super Admin authentication required.' });
    return;
  }
  if (req.auth.subjectType === 'founder') {
    next();
    return;
  }
  if (req.auth.subjectType !== 'super_admin' || !req.auth.twoFactorVerified) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'UNAUTHORIZED_SUPER_ADMIN_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Unauthorized account (${req.auth.role}) attempted to access Super Admin API: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This resource requires verified Super Admin authentication.',
    });
    return;
  }
  next();
}

export function requirePermission(permKey: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (req.auth.subjectType === 'founder') {
      next();
      return;
    }
    if (req.auth.subjectType !== 'super_admin' || !req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        details: `Super Admin "${req.auth.email}" denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({
        error: `Permission denied: your Super Admin profile lacks the "${permKey}" permission. Request grant from the Primary Owner.`,
      });
      return;
    }
    next();
  };
}

export function requireRbacAction(moduleKey: string, action: RbacAction) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (req.auth.subjectType === 'founder') {
      next();
      return;
    }
    if (!checkRbacAction(req.auth.subjectType, req.auth.role, moduleKey, action)) {
      logSecurityAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        companyId: req.auth.companyId,
        action: 'RBAC_MODULE_ACTION_DENIED',
        category: 'RBAC Enforcement',
        severity: 'CRITICAL',
        details: `Blocked "${action}" on module "${moduleKey}" for role "${req.auth.role}" (${req.originalUrl}).`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({
        error: `RBAC permission denied: role "${req.auth.role}" does not hold "${action}" access for "${moduleKey}".`,
      });
      return;
    }
    next();
  };
}

export function requireRoles(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (req.auth.subjectType === 'founder') {
      next();
      return;
    }
    if (!allowedRoles.includes(req.auth.role)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'RBAC_FORBIDDEN',
        userId: req.auth.userId,
        identifier: req.auth.email,
        companyId: req.auth.companyId,
        details: `Role "${req.auth.role}" denied access to ${req.originalUrl} (required: ${allowedRoles.join(', ')})`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({
        error: `Access denied for role "${req.auth.role}".`,
      });
      return;
    }
    next();
  };
}

export function requireCompanyAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Company Admin authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'company_admin' || !req.auth.companyId || !req.auth.twoFactorVerified) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'UNAUTHORIZED_COMPANY_ADMIN_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Subject "${req.auth.subjectType}" (${req.auth.role}) attempted to access isolated Company Admin endpoint: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This workspace is restricted exclusively to verified Company Administrators.',
    });
    return;
  }
  next();
}

export function requireCompanyPermission(permKey: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Company Admin authentication required.' });
      return;
    }
    if (req.auth.subjectType !== 'company_admin' || !req.auth.companyId || !req.auth.twoFactorVerified) {
      res.status(403).json({ error: 'Access Denied. Verified Company Admin session required.' });
      return;
    }
    if (!req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COMPANY_PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        companyId: req.auth.companyId,
        details: `Company Admin "${req.auth.email}" denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      logCompanyActivity({
        companyId: req.auth.companyId,
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'COMPANY_PERMISSION_DENIED',
        module: 'Company Security',
        targetId: permKey,
        details: `Blocked access to ${req.originalUrl} without "${permKey}".`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
      res.status(403).json({
        error: `Permission denied: your Company Admin profile lacks the "${permKey}" permission.`,
      });
      return;
    }
    next();
  };
}

export function requireCountryManager(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Country Manager authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'country_manager' || !req.auth.country || !req.auth.twoFactorVerified) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'UNAUTHORIZED_COUNTRY_MANAGER_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Subject "${req.auth.subjectType}" (${req.auth.role}) attempted to access isolated Country Manager endpoint: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This workspace is restricted exclusively to verified Country Managers.',
    });
    return;
  }
  next();
}

export function requireCountryPermission(permKey: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Country Manager authentication required.' });
      return;
    }
    if (req.auth.subjectType !== 'country_manager' || !req.auth.country || !req.auth.twoFactorVerified) {
      res.status(403).json({ error: 'Access Denied. Verified Country Manager session required.' });
      return;
    }
    if (!req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COUNTRY_PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        details: `Country Manager "${req.auth.email}" (${req.auth.country}) denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      logCountryActivity({
        countryId: req.auth.country,
        managerId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'COUNTRY_PERMISSION_DENIED',
        module: 'Country Security',
        targetId: permKey,
        details: `Blocked access to ${req.originalUrl} without "${permKey}".`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
      res.status(403).json({
        error: `Permission denied: your Country Manager profile lacks the "${permKey}" permission.`,
      });
      return;
    }
    next();
  };
}

export function requireBranchManager(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Branch Manager authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'branch_manager' || !req.auth.branchId || !req.auth.companyId || !req.auth.twoFactorVerified) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'UNAUTHORIZED_BRANCH_MANAGER_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Subject "${req.auth.subjectType}" (${req.auth.role}) attempted to access isolated Branch Manager endpoint: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This workspace is restricted exclusively to verified Branch Managers.',
    });
    return;
  }
  next();
}

export function requireBranchPermission(permKey: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Branch Manager authentication required.' });
      return;
    }
    if (req.auth.subjectType !== 'branch_manager' || !req.auth.branchId || !req.auth.companyId || !req.auth.twoFactorVerified) {
      res.status(403).json({ error: 'Access Denied. Verified Branch Manager session required.' });
      return;
    }
    if (!req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'BRANCH_PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        companyId: req.auth.companyId,
        details: `Branch Manager "${req.auth.email}" (${req.auth.branchId}) denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      logBranchActivity({
        branchId: req.auth.branchId,
        companyId: req.auth.companyId,
        countryId: req.auth.country,
        managerId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'BRANCH_PERMISSION_DENIED',
        module: 'Branch Security',
        targetId: permKey,
        details: `Blocked access to ${req.originalUrl} without "${permKey}".`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
      res.status(403).json({
        error: `Permission denied: your Branch Manager profile lacks the "${permKey}" permission.`,
      });
      return;
    }
    next();
  };
}

export function requireEmployee(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Employee authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'employee' || !req.auth.employeeId || !req.auth.companyId || !req.auth.twoFactorVerified) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'UNAUTHORIZED_EMPLOYEE_PORTAL_ACCESS_ATTEMPT',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Subject "${req.auth.subjectType}" (${req.auth.role}) attempted to access isolated Employee endpoint: ${req.originalUrl}`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Access Denied. This workspace is restricted exclusively to verified individual Employees.',
    });
    return;
  }
  next();
}

export function requireEmployeePermission(permKey: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Employee authentication required.' });
      return;
    }
    if (req.auth.subjectType !== 'employee' || !req.auth.employeeId || !req.auth.companyId || !req.auth.twoFactorVerified) {
      res.status(403).json({ error: 'Access Denied. Verified Employee session required.' });
      return;
    }
    if (!req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'EMPLOYEE_PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        companyId: req.auth.companyId,
        details: `Employee "${req.auth.email}" (${req.auth.employeeCode}) denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      logEmployeeActivity({
        employeeId: req.auth.employeeId,
        companyId: req.auth.companyId,
        branchId: req.auth.branchId,
        countryId: req.auth.country,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'EMPLOYEE_PERMISSION_DENIED',
        module: 'Employee Security',
        targetId: permKey,
        details: `Blocked access to ${req.originalUrl} without "${permKey}".`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
      res.status(403).json({
        error: `Permission denied: your employee profile does not include "${permKey}".`,
      });
      return;
    }
    next();
  };
}

export function requireDealer(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Dealer authentication required.' });
    return;
  }
  if (req.auth.subjectType !== 'dealer' || !req.auth.dealerId) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'DEALER_PORTAL_PRIVILEGE_MISMATCH',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Non-Dealer session "${req.auth.subjectType}" attempted to access Dealer Portal endpoint ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Forbidden: Only authenticated Verified Dealer accounts may access the Private Dealer Dashboard.',
    });
    return;
  }
  if (!req.auth.twoFactorVerified) {
    res.status(403).json({ error: 'Two-factor authentication is mandatory for Dealer access.' });
    return;
  }
  next();
}

export function requireDealerPermission(permKey: CanonicalDealerPermission) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth || req.auth.subjectType !== 'dealer' || !req.auth.dealerId) {
      res.status(403).json({ error: 'Dealer authentication required.' });
      return;
    }
    if (!req.auth.permissions.includes(permKey)) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'DEALER_PERMISSION_DENIED',
        userId: req.auth.userId,
        identifier: req.auth.email,
        companyId: req.auth.companyId,
        details: `Dealer "${req.auth.email}" (${req.auth.dealerCode}) denied permission "${permKey}" on ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      logDealerActivity({
        dealerId: req.auth.dealerId,
        companyId: req.auth.companyId || 'comp_byd_pk',
        countryId: req.auth.country,
        branchId: req.auth.branchId,
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'DEALER_PERMISSION_DENIED',
        module: 'Dealer Security',
        targetId: permKey,
        details: `Blocked access to ${req.originalUrl} without "${permKey}".`,
        ipAddress: getClientIp(req),
        status: 'ALERT',
      });
      res.status(403).json({
        error: `Permission denied: your dealer profile does not include "${permKey}".`,
      });
      return;
    }
    next();
  };
}

export function requireCustomer(req: Request, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Customer authentication required. Please sign in through the Customer Login Portal.' });
    return;
  }
  if (req.auth.subjectType !== 'customer' || !req.auth.customerId) {
    logSecurityEvent({
      severity: 'WARNING',
      eventType: 'CROSS_PORTAL_CUSTOMER_ACCESS_BLOCKED',
      userId: req.auth.userId,
      identifier: req.auth.email,
      companyId: req.auth.companyId,
      details: `Non-Customer session "${req.auth.subjectType}" (${req.auth.role}) attempted to access private Customer Portal endpoint ${req.originalUrl}.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({
      error: 'Forbidden: Only authenticated Customer Portal accounts may access customer resources.',
    });
    return;
  }
  const cust = sqlite.prepare('SELECT status, email_verified FROM customer_accounts WHERE id = ?').get(req.auth.customerId) as any;
  if (!cust || cust.status !== 'Active' || !cust.email_verified) {
    res.status(403).json({ error: 'Customer account is suspended, unverified, or pending review.' });
    return;
  }
  next();
}

// ---------------------------------------------------------------------------
// Helper to issue Super Admin 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueSuperAdmin2FAChallenge(sa: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'sa_2fa_challenge', ?, ?, 'super_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, sa.email, sha256(challengeToken), sa.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'sa_2fa_otp', ?, ?, 'super_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, sa.email, sha256(emailOtp), sa.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueSuperAdminEmailVerifyOtp(sa: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'sa_email_verify', ?, ?, 'super_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, sa.email, sha256(otpCode), sa.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Helper to issue Company Admin 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueCompanyAdmin2FAChallenge(ca: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'ca_2fa_challenge', ?, ?, 'company_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, ca.email, sha256(challengeToken), ca.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'ca_2fa_otp', ?, ?, 'company_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, ca.email, sha256(emailOtp), ca.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueCompanyAdminEmailVerifyOtp(ca: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'ca_email_verify', ?, ?, 'company_admin', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, ca.email, sha256(otpCode), ca.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Helper to issue Country Manager 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueCountryManager2FAChallenge(cm: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'cm_2fa_challenge', ?, ?, 'country_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, cm.email, sha256(challengeToken), cm.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'cm_2fa_otp', ?, ?, 'country_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, cm.email, sha256(emailOtp), cm.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueCountryManagerEmailVerifyOtp(cm: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'cm_email_verify', ?, ?, 'country_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, cm.email, sha256(otpCode), cm.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Helper to issue Branch Manager 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueBranchManager2FAChallenge(bm: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'bm_2fa_challenge', ?, ?, 'branch_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, bm.email, sha256(challengeToken), bm.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'bm_2fa_otp', ?, ?, 'branch_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, bm.email, sha256(emailOtp), bm.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueBranchManagerEmailVerifyOtp(bm: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'bm_email_verify', ?, ?, 'branch_manager', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, bm.email, sha256(otpCode), bm.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Helper to issue Employee 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueEmployee2FAChallenge(emp: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'emp_2fa_challenge', ?, ?, 'employee', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, emp.email, sha256(challengeToken), emp.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'emp_2fa_otp', ?, ?, 'employee', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, emp.email, sha256(emailOtp), emp.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueEmployeeEmailVerifyOtp(emp: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'emp_email_verify', ?, ?, 'employee', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, emp.email, sha256(otpCode), emp.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Helper to issue Dealer 2FA challenge (TOTP + 6-digit email OTP)
// ---------------------------------------------------------------------------
function issueDealer2FAChallenge(dealer: any) {
  const challengeToken = generateSecureToken(24);
  const emailOtp = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const now = nowIso();

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'dlr_2fa_challenge', ?, ?, 'dealer', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, dealer.email, sha256(challengeToken), dealer.id, expiresAt, now);

  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'dlr_2fa_otp', ?, ?, 'dealer', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, dealer.email, sha256(emailOtp), dealer.id, expiresAt, now);

  return { challengeToken, emailOtp };
}

function issueDealerEmailVerifyOtp(dealer: any) {
  const otpCode = generateNumericOtp(6);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  sqlite
    .prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'dlr_email_verify', ?, ?, 'dealer', ?, 0, ?)
    `)
    .run(`otp_${generateSecureToken(6)}`, dealer.email, sha256(otpCode), dealer.id, expiresAt, nowIso());
  return otpCode;
}

// ---------------------------------------------------------------------------
// Router Registration
// ---------------------------------------------------------------------------
export function createAuthAndOwnerRouter() {
  const router = express.Router();

  // =========================================================================
  // 1. PRIVATE FOUNDER / OWNER AUTHENTICATION PORTAL
  // =========================================================================

  router.get('/auth/founder/status', (_req: Request, res: Response) => {
    const countRow = sqlite.prepare('SELECT COUNT(*) as cnt FROM founder_accounts').get() as { cnt: number };
    const requiresSetupSecret = Boolean(process.env.FOUNDER_SETUP_SECRET);
    res.json({
      initialized: countRow.cnt > 0,
      founderName: 'Intekhab Alam',
      role: 'Founder & CEO',
      accountType: 'Primary Owner',
      accessLevel: 'Global Owner',
      twoFactorRequired: true,
      requiresSetupSecret,
    });
  });

  // One-time secure Founder initialization (permanently locked once 1 Founder exists)
  router.post('/auth/founder/initialize', rateLimitAuth('founder_init', 10, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const existing = (sqlite.prepare('SELECT COUNT(*) as cnt FROM founder_accounts').get() as { cnt: number }).cnt;
    if (existing > 0) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'DUPLICATE_FOUNDER_INIT_BLOCKED',
        details: 'Attempted to re-initialize Primary Owner account when a Founder account already exists.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Founder Primary Owner account is already provisioned. Initialization is permanently locked.' });
      return;
    }

    if (process.env.FOUNDER_SETUP_SECRET && req.body.setupSecret !== process.env.FOUNDER_SETUP_SECRET) {
      res.status(403).json({ error: 'Invalid Founder setup authorization secret.' });
      return;
    }

    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Please provide a valid private Founder email address.' });
      return;
    }
    if (!mobile || mobile.length < 8) {
      res.status(400).json({ error: 'Please provide a valid private Founder mobile number.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const userExists =
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email);
    if (userExists) {
      res.status(409).json({ error: 'Founder email must be completely separate from Super Admin, Company Admin, employee, or customer accounts.' });
      return;
    }

    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));

    const founderId = 'founder_intekhab_alam';
    sqlite
      .prepare(`
        INSERT INTO founder_accounts (
          id, founder_name, role, account_type, access_level, email, mobile,
          password_hash, two_factor_enabled, two_factor_secret, recovery_codes_json,
          is_verified, created_at
        ) VALUES (?, 'Intekhab Alam', 'Founder & CEO', 'Primary Owner', 'Global Owner', ?, ?, ?, 1, ?, ?, 1, ?)
      `)
      .run(
        founderId,
        email,
        mobile,
        hashPassword(password),
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        nowIso()
      );

    logOwnerAudit({
      actorId: founderId,
      actorName: 'Intekhab Alam',
      actorRole: 'Founder & CEO',
      action: 'FOUNDER_PRIMARY_OWNER_INITIALIZED',
      module: 'Founder Authentication',
      targetId: email,
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'FOUNDER_PROVISIONED',
      userId: founderId,
      identifier: email,
      details: 'Primary Owner (Intekhab Alam) security credentials and 2FA provisioned.',
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      message: 'Founder Primary Owner security credentials provisioned. Save your 2FA secret and recovery codes now — they will not be shown again.',
      founder: {
        founderName: 'Intekhab Alam',
        role: 'Founder & CEO',
        accountType: 'Primary Owner',
        accessLevel: 'Global Owner',
        email,
      },
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
    });
  });

  // Step 1: Founder Email/Mobile + Password Verification
  router.post('/auth/founder/login', rateLimitAuth('founder_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal.`,
      });
      return;
    }

    const founder = sqlite
      .prepare("SELECT * FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!founder) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'founder', ?, 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier || 'unknown', 'Founder account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_LOGIN_UNKNOWN_IDENTITY',
        identifier,
        details: `Failed Founder portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Founder credentials.' });
      return;
    }

    if (founder.locked_until && new Date(founder.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Founder login temporarily locked due to repeated failed attempts. Try again after ${founder.locked_until}.`,
      });
      return;
    }

    const passwordValid = verifyPassword(password, founder.password_hash);
    if (!passwordValid) {
      const nextFails = (founder.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE founder_accounts SET failed_login_attempts = ?, locked_until = ? WHERE id = ?')
        .run(nextFails, lockedUntil, founder.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'founder', ?, 'Founder & CEO', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, founder.id, identifier, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'FOUNDER_ACCOUNT_LOCKED' : 'FOUNDER_FAILED_PASSWORD',
        userId: founder.id,
        identifier: founder.email,
        details: shouldLock
          ? `Founder account locked after ${nextFails} failed password attempts.`
          : `Failed Founder password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Founder account temporarily locked.'
          : 'Invalid Founder credentials.',
      });
      return;
    }

    const suspicious = Boolean(founder.last_login_ip && founder.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_FOUNDER_LOGIN_IP',
        userId: founder.id,
        identifier: founder.email,
        details: `Founder password verified from new IP ${ip} (previous: ${founder.last_login_ip}). Awaiting 2FA.`,
        ipAddress: ip,
      });
    }

    sqlite.prepare('UPDATE founder_accounts SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?').run(founder.id);

    // If 2FA is disabled for founder, log in directly without authenticator code
    if (!(founder.two_factor_enabled || 0)) {
      sqlite.prepare('UPDATE founder_accounts SET last_login_at = ?, last_login_ip = ? WHERE id = ?')
        .run(nowIso(), ip, founder.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'founder', ?, 'Founder & CEO', 1, ?, ?, 0, ?)")
        .run(`lh_${generateSecureToken(6)}`, founder.id, founder.email, ip, ua, nowIso());

      logOwnerAudit({
        actorId: founder.id,
        actorName: founder.founder_name,
        actorRole: founder.role,
        action: 'FOUNDER_LOGIN_SUCCESS',
        module: 'Founder Authentication',
        targetId: founder.email,
        ipAddress: ip,
      });

      const session = createSession({
        userId: founder.id,
        subjectType: 'founder',
        companyId: null,
        role: 'Founder / Owner',
        twoFactorVerified: true,
        req,
        res,
      });

      res.json({
        success: true,
        requires2FA: false,
        sessionExpiresAt: session.expiresAt,
        user: {
          id: founder.id,
          name: founder.founder_name,
          fullName: founder.founder_name,
          email: founder.email,
          phone: founder.mobile,
          role: 'Founder / Owner',
          subjectType: 'founder',
          permissions: ['*'],
          verifiedIdentity: true,
        },
      });
      return;
    }

    const challengeToken = generateSecureToken(24);
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
    sqlite
      .prepare(`
        INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
        VALUES (?, ?, 'founder_2fa', ?, ?, 'founder', ?, 0, ?)
      `)
      .run(`otp_${generateSecureToken(6)}`, founder.email, sha256(challengeToken), founder.id, expiresAt, nowIso());

    res.json({
      requires2FA: true,
      challengeToken,
      founderName: founder.founder_name,
      role: founder.role,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Complete Two-Factor Authentication using your 6-digit Authenticator TOTP code or a backup recovery code.',
    });
  });

  // Step 2: Founder 2FA Verification
  router.post('/auth/founder/verify-2fa', rateLimitAuth('founder_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: 'Challenge token and 2FA verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'founder_2fa' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const founder = sqlite.prepare('SELECT * FROM founder_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!founder) {
      res.status(401).json({ error: 'Founder account not found.' });
      return;
    }

    let verified = verifyTotpCode(founder.two_factor_secret, code);

    if (!verified) {
      const storedHashes: string[] = JSON.parse(founder.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE founder_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), founder.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'FOUNDER_RECOVERY_CODE_USED',
          userId: founder.id,
          identifier: founder.email,
          details: `Founder signed in using a one-time backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_2FA_FAILED',
        userId: founder.id,
        identifier: founder.email,
        details: 'Invalid 2FA TOTP / recovery code submitted during Founder login.',
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA authenticator or recovery code.' });
      return;
    }

    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
    sqlite
      .prepare('UPDATE founder_accounts SET last_login_at = ?, last_login_ip = ? WHERE id = ?')
      .run(nowIso(), ip, founder.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'founder', ?, 'Founder & CEO', 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, founder.id, founder.email, ip, ua, nowIso());

    logOwnerAudit({
      actorId: founder.id,
      actorName: founder.founder_name,
      actorRole: founder.role,
      action: 'FOUNDER_2FA_LOGIN_SUCCESS',
      module: 'Founder Authentication',
      targetId: founder.email,
      ipAddress: ip,
    });

    const session = createSession({
      userId: founder.id,
      subjectType: 'founder',
      companyId: null,
      role: 'Founder / Owner',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: founder.id,
        name: founder.founder_name,
        fullName: founder.founder_name,
        email: founder.email,
        phone: founder.mobile,
        role: 'Founder / Owner',
        designation: founder.role,
        accountType: founder.account_type,
        accessLevel: founder.access_level,
        city: 'Karachi HQ',
        country: 'GLOBAL',
        subjectType: 'founder',
        permissions: ['*'],
        verifiedIdentity: true,
      },
    });
  });

  // =========================================================================
  // 2. DEDICATED SUPER ADMIN AUTHENTICATION PORTAL (ISOLATED FROM FOUNDER & USERS)
  // =========================================================================

  router.get('/auth/super-admin/status', (_req: Request, res: Response) => {
    const saCount = (sqlite.prepare('SELECT COUNT(*) as c FROM super_admin_accounts').get() as { c: number }).c;
    const founderCount = (sqlite.prepare('SELECT COUNT(*) as c FROM founder_accounts').get() as { c: number }).c;
    res.json({
      hasSuperAdmin: saCount > 0,
      founderProvisioned: founderCount > 0,
      twoFactorRequired: true,
      inviteOnly: true,
    });
  });

  router.get('/auth/super-admin/invite/:token', (req: Request, res: Response) => {
    const tokenHash = sha256(String(req.params.token || '').trim());
    const inv = sqlite
      .prepare('SELECT * FROM super_admin_invitations WHERE token_hash = ?')
      .get(tokenHash) as any;

    if (!inv || inv.status !== 'Pending' || new Date(inv.expires_at).getTime() <= Date.now()) {
      res.status(404).json({ error: 'Super Admin activation invite link is invalid, already used, or expired.' });
      return;
    }

    res.json({
      valid: true,
      fullName: inv.full_name,
      email: inv.email,
      mobile: inv.mobile || '',
      country: inv.country,
      city: inv.city,
      permissions: JSON.parse(inv.permissions_json || '[]'),
      expiresAt: inv.expires_at,
    });
  });

  router.post('/auth/super-admin/accept-invite', rateLimitAuth('sa_accept_invite', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const password = String(req.body.password || '');
    const mobileInput = String(req.body.mobile || '').trim();

    if (!token) {
      res.status(400).json({ error: 'Activation token is required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const inv = sqlite
      .prepare("SELECT * FROM super_admin_invitations WHERE token_hash = ? AND status = 'Pending'")
      .get(sha256(token)) as any;

    if (!inv || new Date(inv.expires_at).getTime() <= Date.now()) {
      res.status(404).json({ error: 'Super Admin activation token is invalid or expired.' });
      return;
    }

    const email = String(inv.email).trim().toLowerCase();
    const mobile = mobileInput || inv.mobile || `+92-300-${generateNumericOtp(7)}`;

    const conflict =
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists in the platform.' });
      return;
    }

    const saId = `sa_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const permissions = sanitizeSaPermissions(JSON.parse(inv.permissions_json || '[]'));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO super_admin_accounts (
          id, full_name, email, mobile, password_hash, country, city, status,
          email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          authorized_by_founder_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 1, ?, ?, ?, ?, ?)
      `)
      .run(
        saId,
        inv.full_name,
        email,
        mobile,
        hashPassword(password),
        inv.country || 'PK',
        inv.city || 'Karachi',
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        inv.invited_by_founder_id,
        now,
        now
      );

    sqlite
      .prepare('INSERT INTO user_permissions (user_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
      .run(saId, JSON.stringify(permissions), inv.invited_by_founder_id, now);

    sqlite
      .prepare("UPDATE super_admin_invitations SET status = 'Accepted', used_at = ? WHERE id = ?")
      .run(now, inv.id);

    const emailOtp = issueSuperAdminEmailVerifyOtp({ id: saId, email });

    logOwnerAudit({
      actorId: saId,
      actorName: inv.full_name,
      actorRole: 'Super Admin',
      action: 'SUPER_ADMIN_INVITE_ACCEPTED',
      module: 'Super Admin Onboarding',
      targetId: email,
      ipAddress: ip,
    });

    logAdminActivity({
      adminId: saId,
      adminName: inv.full_name,
      adminRole: 'Super Admin',
      action: 'SUPER_ADMIN_ACCOUNT_ACTIVATED_FROM_INVITE',
      module: 'Super Admin Authentication',
      targetId: email,
      details: `Permissions assigned: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Super%20Admin:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      requiresEmailVerification: true,
      email,
      message: 'Super Admin credentials saved. Verify your email with the 6-digit OTP and save your 2FA Authenticator setup before signing in.',
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Super Admin Login Step 1: Email/Mobile + Password
  router.post('/auth/super-admin/login', rateLimitAuth('sa_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Email/mobile and password are required.' });
      return;
    }

    // Strictly reject Founder accounts from logging into Super Admin Portal
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_ACCOUNT_SA_PORTAL_ATTEMPT',
        identifier,
        details: 'Founder credentials submitted on Super Admin portal instead of private Founder portal.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal.`,
      });
      return;
    }

    const sa = sqlite
      .prepare("SELECT * FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!sa) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'super_admin', ?, 'Super Admin', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Super Admin account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUPER_ADMIN_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Super Admin portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Super Admin credentials.' });
      return;
    }

    if (sa.locked_until && new Date(sa.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Super Admin account temporarily locked due to repeated failed attempts. Try again after ${sa.locked_until}.`,
      });
      return;
    }

    if (sa.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_SUPER_ADMIN_LOGIN_BLOCKED',
        userId: sa.id,
        identifier: sa.email,
        details: 'Suspended Super Admin attempted to sign in.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This Super Admin account has been suspended by the Primary Owner.' });
      return;
    }

    if (!verifyPassword(password, sa.password_hash)) {
      const nextFails = (sa.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE super_admin_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), sa.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'super_admin', ?, 'Super Admin', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, sa.id, sa.email, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'SUPER_ADMIN_ACCOUNT_LOCKED' : 'SUPER_ADMIN_FAILED_PASSWORD',
        userId: sa.id,
        identifier: sa.email,
        details: shouldLock
          ? `Super Admin account locked after ${nextFails} failed password attempts.`
          : `Failed Super Admin password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Super Admin account temporarily locked.'
          : 'Invalid Super Admin credentials.',
      });
      return;
    }

    // Password OK -> reset failed attempts
    sqlite
      .prepare('UPDATE super_admin_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), sa.id);

    // Require email verification before 2FA if email not verified yet
    if (!sa.email_verified || sa.status === 'Pending Verification') {
      const emailOtp = issueSuperAdminEmailVerifyOtp(sa);
      res.json({
        requiresEmailVerification: true,
        email: sa.email,
        fullName: sa.full_name,
        message: 'Email verification required before first sign-in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(sa.last_login_ip && sa.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_SUPER_ADMIN_LOGIN_IP',
        userId: sa.id,
        identifier: sa.email,
        details: `Super Admin password verified from new IP ${ip} (previous: ${sa.last_login_ip}).`,
        ipAddress: ip,
      });
    }

    const { challengeToken, emailOtp } = issueSuperAdmin2FAChallenge(sa);

    res.json({
      requires2FA: true,
      challengeToken,
      email: sa.email,
      fullName: sa.full_name,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or a backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Super Admin Email OTP Verification -> Activates email & transitions seamlessly to 2FA
  router.post('/auth/super-admin/verify-email', rateLimitAuth('sa_verify_email', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!sa) {
      res.status(404).json({ error: 'Super Admin account not found.' });
      return;
    }

    if (sa.status === 'Suspended') {
      res.status(403).json({ error: 'Account is suspended by the Primary Owner.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'sa_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
    sqlite
      .prepare("UPDATE super_admin_accounts SET email_verified = 1, status = 'Active', updated_at = ? WHERE id = ?")
      .run(now, sa.id);

    logAdminActivity({
      adminId: sa.id,
      adminName: sa.full_name,
      adminRole: 'Super Admin',
      action: 'SUPER_ADMIN_EMAIL_VERIFIED',
      module: 'Super Admin Authentication',
      targetId: sa.email,
      ipAddress: ip,
    });

    const { challengeToken, emailOtp } = issueSuperAdmin2FAChallenge(sa);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: sa.email,
      fullName: sa.full_name,
      message: 'Email verified and account active. Complete 2FA verification to launch the Super Admin Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Super Admin Login Step 2: 2FA Verification (Authenticator TOTP OR 6-digit Login OTP OR Recovery Code)
  router.post('/auth/super-admin/verify-2fa', rateLimitAuth('sa_verify_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'sa_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!sa || sa.status !== 'Active' || !sa.email_verified) {
      res.status(403).json({ error: 'Super Admin account is not active or email is unverified.' });
      return;
    }

    let verified = verifyTotpCode(sa.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    // Also allow matching latest single-use 6-digit email OTP
    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'sa_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(sa.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    // Or single-use backup recovery code
    if (!verified) {
      const storedHashes: string[] = JSON.parse(sa.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE super_admin_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), sa.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'SUPER_ADMIN_RECOVERY_CODE_USED',
          userId: sa.id,
          identifier: sa.email,
          details: `Super Admin signed in with a backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUPER_ADMIN_2FA_FAILED',
        userId: sa.id,
        identifier: sa.email,
        details: 'Invalid 2FA code submitted on Super Admin portal.',
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE super_admin_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, sa.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'super_admin', ?, 'Super Admin', 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, sa.id, sa.email, ip, ua, now);

    logAdminActivity({
      adminId: sa.id,
      adminName: sa.full_name,
      adminRole: 'Super Admin',
      action: 'SUPER_ADMIN_LOGIN',
      module: 'Super Admin Authentication',
      targetId: sa.email,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: sa.id,
      actorName: sa.full_name,
      actorRole: 'Super Admin',
      action: 'SUPER_ADMIN_2FA_LOGIN_SUCCESS',
      module: 'Super Admin Authentication',
      targetId: sa.email,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveUserPermissions(sa.id, 'Super Admin');
    const session = createSession({
      userId: sa.id,
      subjectType: 'super_admin',
      companyId: null,
      role: 'Super Admin',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: sa.id,
        name: sa.full_name,
        fullName: sa.full_name,
        email: sa.email,
        phone: sa.mobile,
        role: 'Super Admin',
        country: sa.country,
        city: sa.city,
        permissions,
        subjectType: 'super_admin',
        emailVerified: true,
        verifiedIdentity: true,
      },
    });
  });

  // Super Admin Forgot Password
  router.post('/auth/super-admin/forgot-password', rateLimitAuth('sa_forgot_pw', 10, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const sa = sqlite.prepare('SELECT id, full_name, email, status FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) as any;

    if (!sa || sa.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible Super Admin account matches that email, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'super_admin', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), sa.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'sa_pw_reset_otp', ?, ?, 'super_admin', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, sa.email, sha256(resetOtp), sa.id, expiresAt, now);

    logAdminActivity({
      adminId: sa.id,
      adminName: sa.full_name,
      adminRole: 'Super Admin',
      action: 'SUPER_ADMIN_PASSWORD_RESET_REQUESTED',
      module: 'Super Admin Authentication',
      targetId: sa.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Super Admin password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  // Super Admin Reset Password (revokes ALL existing sessions)
  router.post('/auth/super-admin/reset-password', rateLimitAuth('sa_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let saId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'super_admin' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        saId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'sa_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        saId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!saId) {
      res.status(400).json({ error: 'Invalid or expired Super Admin password reset token/OTP.' });
      return;
    }

    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE id = ?').get(saId) as any;
    if (!sa) {
      res.status(404).json({ error: 'Super Admin account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE super_admin_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, sa.id);

    if (resetRowId) {
      sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    }
    if (otpRowId) {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);
    }

    // Revoke ALL active sessions for this Super Admin
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(sa.id);

    logAdminActivity({
      adminId: sa.id,
      adminName: sa.full_name,
      adminRole: 'Super Admin',
      action: 'SUPER_ADMIN_PASSWORD_RESET_COMPLETED',
      module: 'Super Admin Authentication',
      targetId: sa.email,
      details: 'Password changed and all prior sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'SUPER_ADMIN_PASSWORD_RESET',
      userId: sa.id,
      identifier: sa.email,
      details: 'Super Admin password reset completed; prior sessions invalidated.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Super Admin password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/super-admin/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'super_admin') {
        logAdminActivity({
          adminId: req.auth.userId,
          adminName: req.auth.fullName,
          adminRole: 'Super Admin',
          action: 'SUPER_ADMIN_LOGOUT',
          module: 'Super Admin Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'SUPER_ADMIN_LOGOUT',
        module: 'Super Admin Authentication',
        targetId: req.auth.email,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  // =========================================================================
  // 2B. DEDICATED COMPANY ADMIN AUTHENTICATION PORTAL (ISOLATED BY COMPANY)
  // =========================================================================

  router.get('/auth/company-admin/status', (_req: Request, res: Response) => {
    const caCount = (sqlite.prepare('SELECT COUNT(*) as c FROM company_admin_accounts').get() as { c: number }).c;
    const activeCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Approved'").get() as { c: number }).c;
    res.json({
      hasCompanyAdmins: caCount > 0,
      approvedCompaniesCount: activeCompanies,
      twoFactorRequired: true,
      emailVerificationRequired: true,
      portalIsolated: true,
    });
  });

  router.post('/auth/company-admin/login', rateLimitAuth('ca_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Company Admin email/username/mobile and password are required.' });
      return;
    }

    // Reject Founder or Super Admin accounts cleanly
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_ACCOUNT_CA_PORTAL_ATTEMPT',
        identifier,
        details: 'Founder credentials submitted on Company Admin portal.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }

    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({ error: 'Super Admin must sign in through the dedicated Super Admin Portal.' });
      return;
    }

    const isCountryManager = sqlite
      .prepare("SELECT id FROM country_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isCountryManager) {
      res.status(403).json({ error: 'Country Manager must sign in through the dedicated Country Manager Portal.' });
      return;
    }

    const isBranchManager = sqlite
      .prepare("SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isBranchManager) {
      res.status(403).json({ error: 'Branch Manager must sign in through the dedicated Branch Manager Portal.' });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal.`,
      });
      return;
    }

    const ca = sqlite
      .prepare(`
        SELECT * FROM company_admin_accounts
        WHERE LOWER(email) = ?
           OR LOWER(username) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!ca) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'company_admin', ?, 'Company Admin', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Company Admin account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COMPANY_ADMIN_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Company Admin portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Company Admin credentials.' });
      return;
    }

    if (ca.locked_until && new Date(ca.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Company Admin account temporarily locked due to repeated failed attempts. Try again after ${ca.locked_until}.`,
      });
      return;
    }

    if (ca.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_COMPANY_ADMIN_LOGIN_BLOCKED',
        userId: ca.id,
        identifier: ca.email,
        companyId: ca.company_id,
        details: 'Suspended Company Admin attempted to sign in.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This Company Admin account has been suspended by the Primary Owner.' });
      return;
    }

    if (!verifyPassword(password, ca.password_hash)) {
      const nextFails = (ca.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE company_admin_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), ca.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'company_admin', ?, 'Company Admin', ?, 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, ca.id, ca.email, ca.company_id, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'COMPANY_ADMIN_ACCOUNT_LOCKED' : 'COMPANY_ADMIN_FAILED_PASSWORD',
        userId: ca.id,
        identifier: ca.email,
        companyId: ca.company_id,
        details: shouldLock
          ? `Company Admin account locked after ${nextFails} failed password attempts.`
          : `Failed Company Admin password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Company Admin account temporarily locked.'
          : 'Invalid Company Admin credentials.',
      });
      return;
    }

    sqlite
      .prepare('UPDATE company_admin_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), ca.id);

    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(ca.company_id) as any;
    if (!comp || comp.status !== 'Approved') {
      res.status(403).json({
        error: `Company "${comp?.name || ca.company_id}" is currently "${comp?.status || 'Unavailable'}". Primary Owner approval is required before Company Admin sign-in.`,
      });
      return;
    }

    // Require email verification before 2FA
    if (!ca.email_verified || ca.status === 'Pending Verification') {
      const emailOtp = issueCompanyAdminEmailVerifyOtp(ca);
      res.json({
        requiresEmailVerification: true,
        email: ca.email,
        fullName: ca.full_name,
        companyName: comp.name,
        message: 'Email verification required before signing in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(ca.last_login_ip && ca.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_COMPANY_ADMIN_LOGIN_IP',
        userId: ca.id,
        identifier: ca.email,
        companyId: ca.company_id,
        details: `Company Admin password verified from new IP ${ip} (previous: ${ca.last_login_ip}).`,
        ipAddress: ip,
      });
    }

    const { challengeToken, emailOtp } = issueCompanyAdmin2FAChallenge(ca);

    res.json({
      requires2FA: true,
      challengeToken,
      email: ca.email,
      fullName: ca.full_name,
      companyId: ca.company_id,
      companyName: comp.name,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/company-admin/verify-email', rateLimitAuth('ca_verify_email', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const ca = sqlite.prepare('SELECT * FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!ca) {
      res.status(404).json({ error: 'Company Admin account not found.' });
      return;
    }
    if (ca.status === 'Suspended') {
      res.status(403).json({ error: 'Account is suspended by the Primary Owner.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'ca_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);

    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(ca.company_id) as any;
    const isCompApproved = comp && comp.status === 'Approved';

    sqlite
      .prepare('UPDATE company_admin_accounts SET email_verified = 1, status = ?, updated_at = ? WHERE id = ?')
      .run(isCompApproved ? 'Active' : 'Pending Verification', now, ca.id);

    logCompanyActivity({
      companyId: ca.company_id,
      actorId: ca.id,
      actorName: ca.full_name,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_EMAIL_VERIFIED',
      module: 'Company Admin Authentication',
      targetId: ca.email,
      ipAddress: ip,
    });

    if (!isCompApproved) {
      res.json({
        success: true,
        requires2FA: false,
        pendingCompanyApproval: true,
        message: 'Email verified. Your company registration is awaiting Primary Owner approval before portal sign-in.',
      });
      return;
    }

    const { challengeToken, emailOtp } = issueCompanyAdmin2FAChallenge(ca);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: ca.email,
      fullName: ca.full_name,
      companyName: comp.name,
      message: 'Email verified and Company Admin active. Complete 2FA verification to open your Company Admin Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/company-admin/verify-2fa', rateLimitAuth('ca_verify_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'ca_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const ca = sqlite.prepare('SELECT * FROM company_admin_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!ca || ca.status !== 'Active' || !ca.email_verified) {
      res.status(403).json({ error: 'Company Admin account is not active or email is unverified.' });
      return;
    }

    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(ca.company_id) as any;
    if (!comp || comp.status !== 'Approved') {
      res.status(403).json({ error: 'Parent company workspace is not approved.' });
      return;
    }

    let verified = verifyTotpCode(ca.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'ca_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(ca.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    if (!verified) {
      const storedHashes: string[] = JSON.parse(ca.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE company_admin_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), ca.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'COMPANY_ADMIN_RECOVERY_CODE_USED',
          userId: ca.id,
          identifier: ca.email,
          companyId: ca.company_id,
          details: `Company Admin signed in using backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COMPANY_ADMIN_2FA_FAILED',
        userId: ca.id,
        identifier: ca.email,
        companyId: ca.company_id,
        details: 'Invalid 2FA code submitted on Company Admin portal.',
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE company_admin_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, ca.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'company_admin', ?, 'Company Admin', ?, 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, ca.id, ca.email, ca.company_id, ip, ua, now);

    logCompanyActivity({
      companyId: ca.company_id,
      actorId: ca.id,
      actorName: ca.full_name,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_LOGIN',
      module: 'Company Admin Authentication',
      targetId: ca.email,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: ca.id,
      actorName: ca.full_name,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_2FA_LOGIN_SUCCESS',
      module: 'Company Admin Authentication',
      targetId: ca.email,
      companyId: ca.company_id,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveCompanyAdminPermissions(ca.id, ca.company_id);
    const session = createSession({
      userId: ca.id,
      subjectType: 'company_admin',
      companyId: ca.company_id,
      role: 'Company Admin',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: ca.id,
        companyId: ca.company_id,
        name: ca.full_name,
        fullName: ca.full_name,
        email: ca.email,
        phone: ca.mobile,
        role: 'Company Admin',
        designation: ca.designation,
        country: comp.country,
        city: comp.city,
        permissions,
        subjectType: 'company_admin',
        emailVerified: true,
        verifiedIdentity: true,
      },
      company: {
        id: comp.id,
        name: comp.name,
        country: comp.country,
        city: comp.city,
        status: comp.status,
      },
    });
  });

  router.post('/auth/company-admin/forgot-password', rateLimitAuth('ca_forgot_pw', 10, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const ca = sqlite.prepare('SELECT id, company_id, full_name, email, status FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) as any;

    if (!ca || ca.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible Company Admin account matches that email, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'company_admin', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), ca.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'ca_pw_reset_otp', ?, ?, 'company_admin', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, ca.email, sha256(resetOtp), ca.id, expiresAt, now);

    logCompanyActivity({
      companyId: ca.company_id,
      actorId: ca.id,
      actorName: ca.full_name,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_PASSWORD_RESET_REQUESTED',
      module: 'Company Admin Authentication',
      targetId: ca.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Company Admin password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/company-admin/reset-password', rateLimitAuth('ca_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let caId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'company_admin' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        caId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'ca_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        caId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!caId) {
      res.status(400).json({ error: 'Invalid or expired Company Admin password reset token/OTP.' });
      return;
    }

    const ca = sqlite.prepare('SELECT * FROM company_admin_accounts WHERE id = ?').get(caId) as any;
    if (!ca) {
      res.status(404).json({ error: 'Company Admin account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE company_admin_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, ca.id);

    if (resetRowId) {
      sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    }
    if (otpRowId) {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);
    }

    // Revoke ALL active sessions for this Company Admin
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(ca.id);

    logCompanyActivity({
      companyId: ca.company_id,
      actorId: ca.id,
      actorName: ca.full_name,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_PASSWORD_RESET_COMPLETED',
      module: 'Company Admin Authentication',
      targetId: ca.email,
      details: 'Password changed and all prior active sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'COMPANY_ADMIN_PASSWORD_RESET',
      userId: ca.id,
      identifier: ca.email,
      companyId: ca.company_id,
      details: 'Company Admin password reset completed; prior sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Company Admin password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/company-admin/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'company_admin' && req.auth.companyId) {
        logCompanyActivity({
          companyId: req.auth.companyId,
          actorId: req.auth.userId,
          actorName: req.auth.fullName,
          actorRole: 'Company Admin',
          action: 'COMPANY_ADMIN_LOGOUT',
          module: 'Company Admin Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'COMPANY_ADMIN_LOGOUT',
        module: 'Company Admin Authentication',
        targetId: req.auth.email,
        companyId: req.auth.companyId,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/company-admin/sessions', requireCompanyAdmin, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'company_admin' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/company-admin/sessions/:id', requireCompanyAdmin, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'company_admin'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Company Admin session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logCompanyActivity({
      companyId: req.auth!.companyId!,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: 'Company Admin',
      action: 'COMPANY_ADMIN_SESSION_REVOKED',
      module: 'Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/company-admin/login-history', requireCompanyAdmin, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'company_admin' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 2C. DEDICATED COUNTRY MANAGER AUTHENTICATION PORTAL (COUNTRY ISOLATED)
  // =========================================================================

  router.get('/auth/country-manager/status', (_req: Request, res: Response) => {
    const cmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM country_manager_accounts').get() as { c: number }).c;
    const countriesCount = (sqlite.prepare("SELECT COUNT(*) as c FROM countries WHERE status = 'Active'").get() as { c: number }).c;
    res.json({
      hasCountryManagers: cmCount > 0,
      activeCountriesCount: countriesCount,
      twoFactorRequired: true,
      emailVerificationRequired: true,
      portalIsolated: true,
    });
  });

  router.post('/auth/country-manager/login', rateLimitAuth('cm_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const rawIdentifier = String(req.body.identifier || req.body.email || req.body.managerCode || '').trim();
    const identifier = rawIdentifier.toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Country Manager ID / email / mobile and password are required.' });
      return;
    }

    // Strict portal separation across Founder, Super Admin, Company Admin, and Standard Users
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_ACCOUNT_CM_PORTAL_ATTEMPT',
        identifier,
        details: 'Founder credentials submitted on Country Manager portal.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }

    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({ error: 'Super Admin must sign in through the dedicated Super Admin Portal.' });
      return;
    }

    const isCompanyAdmin = sqlite
      .prepare("SELECT id FROM company_admin_accounts WHERE LOWER(email) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier);
    if (isCompanyAdmin) {
      res.status(403).json({ error: 'Company Admin must sign in through the dedicated Company Admin Portal.' });
      return;
    }

    const isBranchManager = sqlite
      .prepare("SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isBranchManager) {
      res.status(403).json({ error: 'Branch Manager must sign in through the dedicated Branch Manager Portal.' });
      return;
    }

    const isEmployeeAccount = sqlite
      .prepare("SELECT id, employee_code FROM employee_accounts WHERE LOWER(email) = ? OR LOWER(employee_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isEmployeeAccount) {
      res.status(403).json({
        error: `Employee account (${isEmployeeAccount.employee_code}) must sign in through the dedicated Employee Portal, not the Country Manager Portal.`,
      });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal, not the Country Manager Portal.`,
      });
      return;
    }

    const isStandardUser = sqlite
      .prepare("SELECT id, role FROM users WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier) as any;
    if (isStandardUser) {
      res.status(403).json({
        error: `${isStandardUser.role} accounts must sign in through the standard BYD Portal, not the Country Manager Portal.`,
      });
      return;
    }

    const cm = sqlite
      .prepare(`
        SELECT * FROM country_manager_accounts
        WHERE LOWER(email) = ?
           OR LOWER(manager_code) = ?
           OR LOWER(username) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!cm) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'country_manager', ?, 'Country Manager', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Country Manager account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COUNTRY_MANAGER_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Country Manager portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Country Manager credentials.' });
      return;
    }

    if (cm.locked_until && new Date(cm.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Country Manager account temporarily locked due to repeated failed attempts. Try again after ${cm.locked_until}.`,
      });
      return;
    }

    if (cm.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_COUNTRY_MANAGER_LOGIN_BLOCKED',
        userId: cm.id,
        identifier: cm.email,
        details: `Suspended Country Manager (${cm.manager_code}) attempted to sign in.`,
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This Country Manager account has been suspended by the Primary Owner.' });
      return;
    }

    if (!verifyPassword(password, cm.password_hash)) {
      const nextFails = (cm.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE country_manager_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), cm.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'country_manager', ?, 'Country Manager', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, cm.id, cm.email, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'COUNTRY_MANAGER_ACCOUNT_LOCKED' : 'COUNTRY_MANAGER_FAILED_PASSWORD',
        userId: cm.id,
        identifier: cm.email,
        details: shouldLock
          ? `Country Manager (${cm.manager_code}) locked after ${nextFails} failed password attempts.`
          : `Failed Country Manager password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Country Manager account temporarily locked.'
          : 'Invalid Country Manager credentials.',
      });
      return;
    }

    sqlite
      .prepare('UPDATE country_manager_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), cm.id);

    const countryRow = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(cm.country_id) as any;
    if (!countryRow || countryRow.status !== 'Active') {
      res.status(403).json({ error: `Assigned country "${cm.country_id}" is inactive or unavailable.` });
      return;
    }

    const activeAssignment = sqlite
      .prepare("SELECT * FROM country_assignments WHERE manager_id = ? AND country_id = ? AND status = 'Active'")
      .get(cm.id, cm.country_id) as any;
    if (!activeAssignment) {
      res.status(403).json({
        error: 'No active Global Country Assignment exists for this manager. Contact the Primary Owner.',
      });
      return;
    }

    if (!cm.email_verified || cm.status === 'Pending Verification') {
      const emailOtp = issueCountryManagerEmailVerifyOtp(cm);
      res.json({
        requiresEmailVerification: true,
        email: cm.email,
        fullName: cm.full_name,
        managerCode: cm.manager_code,
        countryId: countryRow.id,
        countryName: countryRow.name,
        message: 'Email verification required before signing in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(cm.last_login_ip && cm.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_COUNTRY_MANAGER_LOGIN_IP',
        userId: cm.id,
        identifier: cm.email,
        details: `Country Manager password verified from new IP ${ip} (previous: ${cm.last_login_ip}).`,
        ipAddress: ip,
      });
    }

    const { challengeToken, emailOtp } = issueCountryManager2FAChallenge(cm);

    res.json({
      requires2FA: true,
      challengeToken,
      email: cm.email,
      fullName: cm.full_name,
      managerCode: cm.manager_code,
      countryId: countryRow.id,
      countryName: countryRow.name,
      flagEmoji: countryRow.flag_emoji,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/country-manager/verify-email', rateLimitAuth('cm_verify_email', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!cm) {
      res.status(404).json({ error: 'Country Manager account not found.' });
      return;
    }
    if (cm.status === 'Suspended') {
      res.status(403).json({ error: 'Account is suspended by the Primary Owner.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'cm_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
    sqlite
      .prepare("UPDATE country_manager_accounts SET email_verified = 1, status = 'Active', updated_at = ? WHERE id = ?")
      .run(now, cm.id);

    const countryRow = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(cm.country_id) as any;

    logCountryActivity({
      countryId: cm.country_id,
      managerId: cm.id,
      actorName: cm.full_name,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_EMAIL_VERIFIED',
      module: 'Country Manager Authentication',
      targetId: cm.email,
      ipAddress: ip,
    });

    const { challengeToken, emailOtp } = issueCountryManager2FAChallenge(cm);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: cm.email,
      fullName: cm.full_name,
      managerCode: cm.manager_code,
      countryId: countryRow?.id || cm.country_id,
      countryName: countryRow?.name || cm.country_id,
      flagEmoji: countryRow?.flag_emoji || '',
      message: 'Email verified and Country Manager account activated. Complete 2FA to open your Country Management Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/country-manager/verify-2fa', rateLimitAuth('cm_verify_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'cm_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!cm || cm.status !== 'Active' || !cm.email_verified) {
      res.status(403).json({ error: 'Country Manager account is not active or email is unverified.' });
      return;
    }

    const countryRow = sqlite.prepare("SELECT * FROM countries WHERE id = ? AND status = 'Active'").get(cm.country_id) as any;
    const activeAssignment = sqlite
      .prepare("SELECT * FROM country_assignments WHERE manager_id = ? AND country_id = ? AND status = 'Active'")
      .get(cm.id, cm.country_id) as any;

    if (!countryRow || !activeAssignment) {
      res.status(403).json({ error: 'Country assignment is inactive or revoked by Primary Owner.' });
      return;
    }

    let verified = verifyTotpCode(cm.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'cm_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(cm.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    if (!verified) {
      const storedHashes: string[] = JSON.parse(cm.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE country_manager_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), cm.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'COUNTRY_MANAGER_RECOVERY_CODE_USED',
          userId: cm.id,
          identifier: cm.email,
          details: `Country Manager (${cm.manager_code}) signed in using backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'COUNTRY_MANAGER_2FA_FAILED',
        userId: cm.id,
        identifier: cm.email,
        details: `Invalid 2FA code submitted on Country Manager portal (${cm.manager_code}).`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE country_manager_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, cm.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'country_manager', ?, 'Country Manager', 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, cm.id, cm.email, ip, ua, now);

    logCountryActivity({
      countryId: cm.country_id,
      managerId: cm.id,
      actorName: cm.full_name,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_LOGIN',
      module: 'Country Manager Authentication',
      targetId: `${cm.manager_code} (${cm.country_id})`,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: cm.id,
      actorName: cm.full_name,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_2FA_LOGIN_SUCCESS',
      module: 'Country Manager Authentication',
      targetId: `${cm.email} (${cm.manager_code})`,
      details: `Country: ${countryRow.name} (${countryRow.id}) via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveCountryManagerPermissions(cm.id);
    const session = createSession({
      userId: cm.id,
      subjectType: 'country_manager',
      companyId: null,
      role: 'Country Manager',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: cm.id,
        managerCode: cm.manager_code,
        companyId: null,
        name: cm.full_name,
        fullName: cm.full_name,
        email: cm.email,
        phone: cm.mobile,
        role: 'Country Manager',
        designation: cm.designation,
        country: countryRow.id,
        city: countryRow.headquarters_city,
        permissions,
        subjectType: 'country_manager',
        emailVerified: true,
        verifiedIdentity: true,
      },
      country: {
        id: countryRow.id,
        code: countryRow.code,
        name: countryRow.name,
        flagEmoji: countryRow.flag_emoji,
        currency: countryRow.currency,
        legalEntity: countryRow.legal_entity,
        headquartersCity: countryRow.headquarters_city,
      },
      assignment: activeAssignment,
    });
  });

  router.post('/auth/country-manager/forgot-password', rateLimitAuth('cm_forgot_pw', 10, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const cm = sqlite.prepare('SELECT id, country_id, manager_code, full_name, email, status FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) as any;

    if (!cm || cm.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible Country Manager account matches that email, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'country_manager', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), cm.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'cm_pw_reset_otp', ?, ?, 'country_manager', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, cm.email, sha256(resetOtp), cm.id, expiresAt, now);

    logCountryActivity({
      countryId: cm.country_id,
      managerId: cm.id,
      actorName: cm.full_name,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_PASSWORD_RESET_REQUESTED',
      module: 'Country Manager Authentication',
      targetId: cm.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Country Manager password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/country-manager/reset-password', rateLimitAuth('cm_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let cmId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'country_manager' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        cmId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'cm_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        cmId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!cmId) {
      res.status(400).json({ error: 'Invalid or expired Country Manager password reset token/OTP.' });
      return;
    }

    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE id = ?').get(cmId) as any;
    if (!cm) {
      res.status(404).json({ error: 'Country Manager account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE country_manager_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, cm.id);

    if (resetRowId) {
      sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    }
    if (otpRowId) {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);
    }

    // Revoke ALL active sessions for this Country Manager
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(cm.id);

    logCountryActivity({
      countryId: cm.country_id,
      managerId: cm.id,
      actorName: cm.full_name,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_PASSWORD_RESET_COMPLETED',
      module: 'Country Manager Authentication',
      targetId: cm.email,
      details: 'Password changed and all prior active sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'COUNTRY_MANAGER_PASSWORD_RESET',
      userId: cm.id,
      identifier: cm.email,
      details: 'Country Manager password reset completed; prior sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Country Manager password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/country-manager/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'country_manager') {
        logCountryActivity({
          countryId: req.auth.country,
          managerId: req.auth.userId,
          actorName: req.auth.fullName,
          actorRole: 'Country Manager',
          action: 'COUNTRY_MANAGER_LOGOUT',
          module: 'Country Manager Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'COUNTRY_MANAGER_LOGOUT',
        module: 'Country Manager Authentication',
        targetId: req.auth.email,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/country-manager/sessions', requireCountryManager, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'country_manager' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/country-manager/sessions/:id', requireCountryManager, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'country_manager'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Country Manager session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logCountryActivity({
      countryId: req.auth!.country,
      managerId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: 'Country Manager',
      action: 'COUNTRY_MANAGER_SESSION_REVOKED',
      module: 'Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/country-manager/login-history', requireCountryManager, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'country_manager' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 2D. DEDICATED BRANCH MANAGER AUTHENTICATION PORTAL (BRANCH ISOLATED)
  // =========================================================================

  router.get('/auth/branch-manager/status', (_req: Request, res: Response) => {
    const bmCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branch_manager_accounts').get() as { c: number }).c;
    const branchesCount = (sqlite.prepare("SELECT COUNT(*) as c FROM branches WHERE status = 'Active'").get() as { c: number }).c;
    res.json({
      hasBranchManagers: bmCount > 0,
      activeBranchesCount: branchesCount,
      twoFactorRequired: true,
      emailVerificationRequired: true,
      portalIsolated: true,
    });
  });

  router.post('/auth/branch-manager/login', rateLimitAuth('bm_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const rawIdentifier = String(req.body.identifier || req.body.email || req.body.managerCode || '').trim();
    const identifier = rawIdentifier.toLowerCase();
    const password = String(req.body.password || '');
    const suppliedBranchInput = String(req.body.branchId || req.body.branchCode || '').trim();

    if (!identifier || !password) {
      res.status(400).json({ error: 'Branch Manager ID / email / mobile and password are required.' });
      return;
    }

    // Strict portal isolation across Founder, Super Admin, Company Admin, Country Manager & Standard Users
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_ACCOUNT_BM_PORTAL_ATTEMPT',
        identifier,
        details: 'Founder credentials submitted on Branch Manager portal.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }

    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({ error: 'Super Admin must sign in through the dedicated Super Admin Portal.' });
      return;
    }

    const isCompanyAdmin = sqlite
      .prepare("SELECT id FROM company_admin_accounts WHERE LOWER(email) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier);
    if (isCompanyAdmin) {
      res.status(403).json({ error: 'Company Admin must sign in through the dedicated Company Admin Portal.' });
      return;
    }

    const isCountryManager = sqlite
      .prepare("SELECT id FROM country_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isCountryManager) {
      res.status(403).json({ error: 'Country Manager must sign in through the dedicated Country Manager Portal.' });
      return;
    }

    const isEmployeeAccount = sqlite
      .prepare("SELECT id, employee_code FROM employee_accounts WHERE LOWER(email) = ? OR LOWER(employee_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isEmployeeAccount) {
      res.status(403).json({
        error: `Employee account (${isEmployeeAccount.employee_code}) must sign in through the dedicated Employee Portal, not the Branch Manager Portal.`,
      });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal, not the Branch Manager Portal.`,
      });
      return;
    }

    const isStandardUser = sqlite
      .prepare("SELECT id, role FROM users WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier) as any;
    if (isStandardUser) {
      res.status(403).json({
        error: `${isStandardUser.role} accounts must sign in through the standard BYD Portal, not the Branch Manager Portal.`,
      });
      return;
    }

    const bm = sqlite
      .prepare(`
        SELECT * FROM branch_manager_accounts
        WHERE LOWER(email) = ?
           OR LOWER(manager_code) = ?
           OR LOWER(username) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!bm) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'branch_manager', ?, 'Branch Manager', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Branch Manager account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'BRANCH_MANAGER_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Branch Manager portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Branch Manager credentials.' });
      return;
    }

    if (bm.locked_until && new Date(bm.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Branch Manager account temporarily locked due to repeated failed attempts. Try again after ${bm.locked_until}.`,
      });
      return;
    }

    if (bm.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_BRANCH_MANAGER_LOGIN_BLOCKED',
        userId: bm.id,
        identifier: bm.email,
        companyId: bm.company_id,
        details: `Suspended Branch Manager (${bm.manager_code}) attempted to sign in.`,
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This Branch Manager account has been suspended by the Primary Owner.' });
      return;
    }

    if (!verifyPassword(password, bm.password_hash)) {
      const nextFails = (bm.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE branch_manager_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), bm.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'branch_manager', ?, 'Branch Manager', ?, 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, bm.id, bm.email, bm.company_id, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'BRANCH_MANAGER_ACCOUNT_LOCKED' : 'BRANCH_MANAGER_FAILED_PASSWORD',
        userId: bm.id,
        identifier: bm.email,
        companyId: bm.company_id,
        details: shouldLock
          ? `Branch Manager (${bm.manager_code}) locked after ${nextFails} failed password attempts.`
          : `Failed Branch Manager password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Branch Manager account temporarily locked.'
          : 'Invalid Branch Manager credentials.',
      });
      return;
    }

    sqlite
      .prepare('UPDATE branch_manager_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), bm.id);

    const branchRow = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(bm.branch_id) as any;
    if (!branchRow || branchRow.status !== 'Active') {
      res.status(403).json({ error: `Assigned branch "${bm.branch_id}" is inactive or unavailable.` });
      return;
    }

    if (
      suppliedBranchInput &&
      suppliedBranchInput.toUpperCase() !== String(branchRow.id).toUpperCase() &&
      suppliedBranchInput.toUpperCase() !== String(branchRow.code).toUpperCase()
    ) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'BRANCH_LOGIN_MISMATCH_BLOCKED',
        userId: bm.id,
        identifier: bm.email,
        companyId: bm.company_id,
        details: `Branch Manager (${bm.manager_code}, assigned=${branchRow.code}) attempted to sign in specifying foreign branch "${suppliedBranchInput}".`,
        ipAddress: ip,
      });
      res.status(403).json({
        error: `Branch mismatch: your account (${bm.manager_code}) is assigned strictly to ${branchRow.name} (${branchRow.code}).`,
      });
      return;
    }

    const compRow = sqlite.prepare("SELECT * FROM companies WHERE id = ? AND status = 'Approved'").get(bm.company_id) as any;
    if (!compRow) {
      res.status(403).json({ error: 'Parent company workspace is not approved or active.' });
      return;
    }

    const countryRow = sqlite.prepare("SELECT * FROM countries WHERE id = ? AND status = 'Active'").get(bm.country_id) as any;
    if (!countryRow) {
      res.status(403).json({ error: `Assigned country "${bm.country_id}" is inactive or unavailable.` });
      return;
    }

    const activeAssignment = sqlite
      .prepare("SELECT * FROM branch_assignments WHERE manager_id = ? AND branch_id = ? AND status = 'Active'")
      .get(bm.id, bm.branch_id) as any;
    if (!activeAssignment) {
      res.status(403).json({
        error: 'No active Branch Assignment exists for this manager. Contact the Primary Owner.',
      });
      return;
    }

    if (!bm.email_verified || bm.status === 'Pending Verification') {
      const emailOtp = issueBranchManagerEmailVerifyOtp(bm);
      res.json({
        requiresEmailVerification: true,
        email: bm.email,
        fullName: bm.full_name,
        managerCode: bm.manager_code,
        branchId: branchRow.id,
        branchCode: branchRow.code,
        branchName: branchRow.name,
        message: 'Email verification required before signing in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(bm.last_login_ip && bm.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_BRANCH_MANAGER_LOGIN_IP',
        userId: bm.id,
        identifier: bm.email,
        companyId: bm.company_id,
        details: `Branch Manager password verified from new IP ${ip} (previous: ${bm.last_login_ip}).`,
        ipAddress: ip,
      });
    }

    const { challengeToken, emailOtp } = issueBranchManager2FAChallenge(bm);

    res.json({
      requires2FA: true,
      challengeToken,
      email: bm.email,
      fullName: bm.full_name,
      managerCode: bm.manager_code,
      branchId: branchRow.id,
      branchCode: branchRow.code,
      branchName: branchRow.name,
      companyName: compRow.name,
      countryName: countryRow.name,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/branch-manager/verify-email', rateLimitAuth('bm_verify_email', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!bm) {
      res.status(404).json({ error: 'Branch Manager account not found.' });
      return;
    }
    if (bm.status === 'Suspended') {
      res.status(403).json({ error: 'Account is suspended by the Primary Owner.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'bm_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
    sqlite
      .prepare("UPDATE branch_manager_accounts SET email_verified = 1, status = 'Active', updated_at = ? WHERE id = ?")
      .run(now, bm.id);

    const branchRow = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(bm.branch_id) as any;
    const compRow = sqlite.prepare('SELECT name FROM companies WHERE id = ?').get(bm.company_id) as any;
    const countryRow = sqlite.prepare('SELECT name FROM countries WHERE id = ?').get(bm.country_id) as any;

    logBranchActivity({
      branchId: bm.branch_id,
      companyId: bm.company_id,
      countryId: bm.country_id,
      managerId: bm.id,
      actorName: bm.full_name,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_EMAIL_VERIFIED',
      module: 'Branch Manager Authentication',
      targetId: bm.email,
      ipAddress: ip,
    });

    const { challengeToken, emailOtp } = issueBranchManager2FAChallenge(bm);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: bm.email,
      fullName: bm.full_name,
      managerCode: bm.manager_code,
      branchId: bm.branch_id,
      branchCode: branchRow?.code || bm.branch_id,
      branchName: branchRow?.name || bm.branch_id,
      companyName: compRow?.name || bm.company_id,
      countryName: countryRow?.name || bm.country_id,
      message: 'Email verified and Branch Manager account activated. Complete 2FA to open your Branch Management Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/branch-manager/verify-2fa', rateLimitAuth('bm_verify_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'bm_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!bm || bm.status !== 'Active' || !bm.email_verified) {
      res.status(403).json({ error: 'Branch Manager account is not active or email is unverified.' });
      return;
    }

    const branchRow = sqlite.prepare("SELECT * FROM branches WHERE id = ? AND status = 'Active'").get(bm.branch_id) as any;
    const compRow = sqlite.prepare("SELECT * FROM companies WHERE id = ? AND status = 'Approved'").get(bm.company_id) as any;
    const countryRow = sqlite.prepare("SELECT * FROM countries WHERE id = ? AND status = 'Active'").get(bm.country_id) as any;
    const activeAssignment = sqlite
      .prepare("SELECT * FROM branch_assignments WHERE manager_id = ? AND branch_id = ? AND status = 'Active'")
      .get(bm.id, bm.branch_id) as any;

    if (!branchRow || !compRow || !countryRow || !activeAssignment) {
      res.status(403).json({ error: 'Branch assignment is inactive or revoked by Primary Owner.' });
      return;
    }

    let verified = verifyTotpCode(bm.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'bm_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(bm.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    if (!verified) {
      const storedHashes: string[] = JSON.parse(bm.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE branch_manager_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), bm.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'BRANCH_MANAGER_RECOVERY_CODE_USED',
          userId: bm.id,
          identifier: bm.email,
          companyId: bm.company_id,
          details: `Branch Manager (${bm.manager_code}) signed in using backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'BRANCH_MANAGER_2FA_FAILED',
        userId: bm.id,
        identifier: bm.email,
        companyId: bm.company_id,
        details: `Invalid 2FA code submitted on Branch Manager portal (${bm.manager_code}).`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE branch_manager_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, bm.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'branch_manager', ?, 'Branch Manager', ?, 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, bm.id, bm.email, bm.company_id, ip, ua, now);

    logBranchActivity({
      branchId: bm.branch_id,
      companyId: bm.company_id,
      countryId: bm.country_id,
      managerId: bm.id,
      actorName: bm.full_name,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_LOGIN',
      module: 'Branch Manager Authentication',
      targetId: `${bm.manager_code} (${branchRow.code})`,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: bm.id,
      actorName: bm.full_name,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_2FA_LOGIN_SUCCESS',
      module: 'Branch Manager Authentication',
      targetId: `${bm.email} (${bm.manager_code})`,
      companyId: bm.company_id,
      details: `Branch: ${branchRow.name} (${branchRow.code}) via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveBranchManagerPermissions(bm.id);
    const session = createSession({
      userId: bm.id,
      subjectType: 'branch_manager',
      companyId: bm.company_id,
      role: 'Branch Manager',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: bm.id,
        managerCode: bm.manager_code,
        companyId: bm.company_id,
        branchId: bm.branch_id,
        branchName: branchRow.name,
        name: bm.full_name,
        fullName: bm.full_name,
        email: bm.email,
        phone: bm.mobile,
        role: 'Branch Manager',
        designation: bm.designation,
        country: countryRow.id,
        city: branchRow.city,
        permissions,
        subjectType: 'branch_manager',
        emailVerified: true,
        verifiedIdentity: true,
      },
      branch: {
        id: branchRow.id,
        code: branchRow.code,
        name: branchRow.name,
        city: branchRow.city,
        companyName: compRow.name,
        countryName: countryRow.name,
      },
      assignment: activeAssignment,
    });
  });

  router.post('/auth/branch-manager/forgot-password', rateLimitAuth('bm_forgot_pw', 10, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const bm = sqlite.prepare('SELECT id, branch_id, company_id, country_id, manager_code, full_name, email, status FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) as any;

    if (!bm || bm.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible Branch Manager account matches that email, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'branch_manager', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), bm.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'bm_pw_reset_otp', ?, ?, 'branch_manager', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, bm.email, sha256(resetOtp), bm.id, expiresAt, now);

    logBranchActivity({
      branchId: bm.branch_id,
      companyId: bm.company_id,
      countryId: bm.country_id,
      managerId: bm.id,
      actorName: bm.full_name,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_PASSWORD_RESET_REQUESTED',
      module: 'Branch Manager Authentication',
      targetId: bm.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Branch Manager password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/branch-manager/reset-password', rateLimitAuth('bm_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let bmId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'branch_manager' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        bmId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'bm_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        bmId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!bmId) {
      res.status(400).json({ error: 'Invalid or expired Branch Manager password reset token/OTP.' });
      return;
    }

    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE id = ?').get(bmId) as any;
    if (!bm) {
      res.status(404).json({ error: 'Branch Manager account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE branch_manager_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, bm.id);

    if (resetRowId) {
      sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    }
    if (otpRowId) {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);
    }

    // Revoke ALL active sessions for this Branch Manager
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(bm.id);

    logBranchActivity({
      branchId: bm.branch_id,
      companyId: bm.company_id,
      countryId: bm.country_id,
      managerId: bm.id,
      actorName: bm.full_name,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_PASSWORD_RESET_COMPLETED',
      module: 'Branch Manager Authentication',
      targetId: bm.email,
      details: 'Password changed and all prior active sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'BRANCH_MANAGER_PASSWORD_RESET',
      userId: bm.id,
      identifier: bm.email,
      companyId: bm.company_id,
      details: 'Branch Manager password reset completed; prior sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Branch Manager password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/branch-manager/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'branch_manager' && req.auth.branchId && req.auth.companyId) {
        logBranchActivity({
          branchId: req.auth.branchId,
          companyId: req.auth.companyId,
          countryId: req.auth.country,
          managerId: req.auth.userId,
          actorName: req.auth.fullName,
          actorRole: 'Branch Manager',
          action: 'BRANCH_MANAGER_LOGOUT',
          module: 'Branch Manager Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'BRANCH_MANAGER_LOGOUT',
        module: 'Branch Manager Authentication',
        targetId: req.auth.email,
        companyId: req.auth.companyId,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/branch-manager/sessions', requireBranchManager, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'branch_manager' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/branch-manager/sessions/:id', requireBranchManager, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'branch_manager'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Branch Manager session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logBranchActivity({
      branchId: req.auth!.branchId!,
      companyId: req.auth!.companyId!,
      countryId: req.auth!.country,
      managerId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: 'Branch Manager',
      action: 'BRANCH_MANAGER_SESSION_REVOKED',
      module: 'Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/branch-manager/login-history', requireBranchManager, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'branch_manager' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 2F. SEPARATE EMPLOYEE LOGIN, VERIFICATION, 2FA & SESSION MANAGEMENT (/api/auth/employee/*)
  // =========================================================================

  router.get('/auth/employee/status', (_req: Request, res: Response) => {
    const countRow = sqlite.prepare("SELECT COUNT(*) as cnt FROM employee_accounts WHERE status != 'Suspended'").get() as { cnt: number };
    const companiesCount = (sqlite.prepare("SELECT COUNT(*) as cnt FROM companies WHERE status = 'Approved'").get() as { cnt: number }).cnt;
    res.json({
      hasEmployees: countRow.cnt > 0,
      approvedCompaniesCount: companiesCount,
      twoFactorRequired: true,
      emailVerificationRequired: true,
      portalIsolated: true,
    });
  });

  router.post('/auth/employee/login', rateLimitAuth('emp_login', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const rawIdentifier = String(req.body.identifier || req.body.email || req.body.employeeCode || '').trim();
    const identifier = rawIdentifier.toLowerCase();
    const password = String(req.body.password || '');
    const suppliedEmployeeCode = String(req.body.employeeCodeCheck || '').trim().toUpperCase();

    if (!identifier || !password) {
      res.status(400).json({ error: 'Employee ID or email address and password are required.' });
      return;
    }

    // Strictly isolate Employee login from Founder, Super Admin, Company Admin, Country Manager, Branch Manager, and Customer portals
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'FOUNDER_ACCOUNT_EMPLOYEE_PORTAL_ATTEMPT',
        identifier,
        details: 'Founder credentials submitted on Employee portal.',
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }

    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({ error: 'Super Admin must sign in through the dedicated Super Admin Portal.' });
      return;
    }

    const isCompanyAdmin = sqlite
      .prepare("SELECT id FROM company_admin_accounts WHERE LOWER(email) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier);
    if (isCompanyAdmin) {
      res.status(403).json({ error: 'Company Admin must sign in through the dedicated Company Admin Portal.' });
      return;
    }

    const isCountryManager = sqlite
      .prepare("SELECT id FROM country_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isCountryManager) {
      res.status(403).json({ error: 'Country Manager must sign in through the dedicated Country Manager Portal.' });
      return;
    }

    const isBranchManager = sqlite
      .prepare("SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isBranchManager) {
      res.status(403).json({ error: 'Branch Manager must sign in through the dedicated Branch Manager Portal.' });
      return;
    }

    const isCustomer = sqlite
      .prepare("SELECT id FROM users WHERE role = 'Customer' AND (LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', ''))")
      .get(identifier, identifier);
    if (isCustomer) {
      res.status(403).json({ error: 'Customer accounts must sign in through the standard BYD Customer Portal, not the Employee Portal.' });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) must sign in through the dedicated Dealer Login Portal, not the Employee Portal.`,
      });
      return;
    }

    const emp = sqlite
      .prepare(`
        SELECT * FROM employee_accounts
        WHERE LOWER(email) = ?
           OR LOWER(employee_code) = ?
           OR LOWER(COALESCE(username, '')) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!emp) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'employee', ?, 'Employee', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Employee account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'EMPLOYEE_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Employee portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Employee credentials.' });
      return;
    }

    if (emp.locked_until && new Date(emp.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Employee account temporarily locked due to repeated failed attempts. Try again after ${emp.locked_until}.`,
      });
      return;
    }

    if (emp.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_EMPLOYEE_LOGIN_BLOCKED',
        userId: emp.id,
        identifier: emp.email,
        companyId: emp.company_id,
        details: `Suspended Employee (${emp.employee_code}) attempted to sign in.`,
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This employee account has been suspended by an administrator.' });
      return;
    }

    if (!emp.password_hash || !verifyPassword(password, emp.password_hash)) {
      const nextFails = (emp.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE employee_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), emp.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'employee', ?, ?, ?, 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, emp.id, emp.email, emp.job_position || 'Employee', emp.company_id, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'EMPLOYEE_ACCOUNT_LOCKED' : 'EMPLOYEE_FAILED_PASSWORD',
        userId: emp.id,
        identifier: emp.email,
        companyId: emp.company_id,
        details: shouldLock
          ? `Employee (${emp.employee_code}) locked after ${nextFails} failed password attempts.`
          : `Failed Employee password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Employee account temporarily locked.'
          : 'Invalid Employee credentials.',
      });
      return;
    }

    sqlite
      .prepare('UPDATE employee_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), emp.id);

    if (suppliedEmployeeCode && suppliedEmployeeCode !== String(emp.employee_code).toUpperCase()) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'EMPLOYEE_ID_MISMATCH_BLOCKED',
        userId: emp.id,
        identifier: emp.email,
        companyId: emp.company_id,
        details: `Employee (${emp.employee_code}) attempted to sign in with mismatched Employee ID "${suppliedEmployeeCode}".`,
        ipAddress: ip,
      });
      res.status(403).json({
        error: `Employee ID mismatch: verify your individual assigned Employee ID.`,
      });
      return;
    }

    const compRow = sqlite.prepare("SELECT id, name, country, city, status FROM companies WHERE id = ? AND status = 'Approved'").get(emp.company_id) as any;
    if (!compRow) {
      res.status(403).json({ error: 'Parent company workspace is not approved or active.' });
      return;
    }

    const branchRow = emp.branch_id
      ? (sqlite.prepare('SELECT id, code, name, city FROM branches WHERE id = ?').get(emp.branch_id) as any)
      : null;

    if (!emp.email_verified || emp.status === 'Pending Verification') {
      const emailOtp = issueEmployeeEmailVerifyOtp(emp);
      res.json({
        requiresEmailVerification: true,
        email: emp.email,
        fullName: emp.full_name,
        employeeCode: emp.employee_code,
        branchName: branchRow?.name || null,
        companyName: compRow.name,
        message: 'Email verification required before signing in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(emp.last_login_ip && emp.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_EMPLOYEE_LOGIN_IP',
        userId: emp.id,
        identifier: emp.email,
        companyId: emp.company_id,
        details: `Employee (${emp.employee_code}) password verified from new IP ${ip} (previous: ${emp.last_login_ip}).`,
        ipAddress: ip,
      });
    }

    const { challengeToken, emailOtp } = issueEmployee2FAChallenge(emp);

    res.json({
      requires2FA: true,
      challengeToken,
      email: emp.email,
      fullName: emp.full_name,
      employeeCode: emp.employee_code,
      jobPosition: emp.job_position,
      department: emp.department,
      branchName: branchRow?.name || null,
      companyName: compRow.name,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/employee/verify-email', rateLimitAuth('emp_verify_email', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee account not found.' });
      return;
    }
    if (emp.status === 'Suspended') {
      res.status(403).json({ error: 'Account is suspended by an administrator.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'emp_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
    sqlite
      .prepare("UPDATE employee_accounts SET email_verified = 1, status = CASE WHEN status = 'Pending Verification' THEN 'Active' ELSE status END, updated_at = ? WHERE id = ?")
      .run(now, emp.id);
    if (emp.user_id) {
      sqlite
        .prepare("UPDATE users SET email_verified = 1, mobile_verified = 1, status = CASE WHEN status = 'Pending Verification' THEN 'Active' ELSE status END, updated_at = ? WHERE id = ?")
        .run(now, emp.user_id);
    }

    const compRow = sqlite.prepare('SELECT name FROM companies WHERE id = ?').get(emp.company_id) as any;
    const branchRow = emp.branch_id ? (sqlite.prepare('SELECT name FROM branches WHERE id = ?').get(emp.branch_id) as any) : null;

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      countryId: emp.country_id,
      actorName: emp.full_name,
      actorRole: emp.job_position || 'Employee',
      action: 'EMPLOYEE_EMAIL_VERIFIED',
      module: 'Employee Authentication',
      targetId: emp.email,
      ipAddress: ip,
    });

    const { challengeToken, emailOtp } = issueEmployee2FAChallenge(emp);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: emp.email,
      fullName: emp.full_name,
      employeeCode: emp.employee_code,
      jobPosition: emp.job_position,
      department: emp.department,
      branchName: branchRow?.name || null,
      companyName: compRow?.name || emp.company_id,
      message: 'Email verified and Employee account activated. Complete 2FA to open your Personal Employee Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.post('/auth/employee/verify-2fa', rateLimitAuth('emp_verify_2fa', 30, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'emp_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!emp || emp.status === 'Suspended' || !emp.email_verified) {
      res.status(403).json({ error: 'Employee account is suspended, inactive, or email is unverified.' });
      return;
    }

    const compRow = sqlite.prepare("SELECT * FROM companies WHERE id = ? AND status = 'Approved'").get(emp.company_id) as any;
    if (!compRow) {
      res.status(403).json({ error: 'Parent company workspace is inactive or unapproved.' });
      return;
    }

    const branchRow = emp.branch_id ? (sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(emp.branch_id) as any) : null;

    let verified = Boolean(emp.two_factor_secret) && verifyTotpCode(emp.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'emp_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(emp.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    if (!verified) {
      const storedHashes: string[] = JSON.parse(emp.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE employee_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), emp.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'EMPLOYEE_RECOVERY_CODE_USED',
          userId: emp.id,
          identifier: emp.email,
          companyId: emp.company_id,
          details: `Employee (${emp.employee_code}) signed in using backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'EMPLOYEE_2FA_FAILED',
        userId: emp.id,
        identifier: emp.email,
        companyId: emp.company_id,
        details: `Invalid 2FA code submitted on Employee portal (${emp.employee_code}).`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE employee_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, emp.id);
    if (emp.user_id) {
      sqlite.prepare('UPDATE users SET last_login_at = ?, updated_at = ? WHERE id = ?').run(now, now, emp.user_id);
    }

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'employee', ?, ?, ?, 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, emp.id, emp.email, emp.job_position || 'Employee', emp.company_id, ip, ua, now);

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      countryId: emp.country_id || compRow.country,
      actorName: emp.full_name,
      actorRole: emp.job_position || 'Employee',
      action: 'EMPLOYEE_LOGIN',
      module: 'Employee Authentication',
      targetId: `${emp.employee_code}`,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: emp.id,
      actorName: emp.full_name,
      actorRole: emp.job_position || 'Employee',
      action: 'EMPLOYEE_2FA_LOGIN_SUCCESS',
      module: 'Employee Authentication',
      targetId: `${emp.email} (${emp.employee_code})`,
      companyId: emp.company_id,
      details: `Employee login via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveEmployeePermissions(emp);
    const session = createSession({
      userId: emp.id,
      subjectType: 'employee',
      companyId: emp.company_id,
      role: emp.job_position || 'Employee',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: emp.id,
        employeeId: emp.id,
        employeeCode: emp.employee_code,
        companyId: emp.company_id,
        branchId: emp.branch_id,
        branchName: branchRow?.name || null,
        departmentId: emp.department_id,
        department: emp.department,
        reportingManagerName: emp.reporting_manager_name,
        name: emp.full_name,
        fullName: emp.full_name,
        email: emp.email,
        phone: emp.mobile,
        role: emp.job_position || 'Employee',
        designation: emp.job_position,
        country: emp.country_id || compRow.country || 'PK',
        city: branchRow?.city || compRow.city || 'Karachi',
        permissions,
        subjectType: 'employee',
        emailVerified: true,
        verifiedIdentity: true,
      },
      organization: {
        companyId: compRow.id,
        companyName: compRow.name,
        countryId: emp.country_id || compRow.country,
        branchId: emp.branch_id,
        branchName: branchRow?.name || null,
        department: emp.department,
        reportingManagerName: emp.reporting_manager_name,
      },
    });
  });

  router.post('/auth/employee/forgot-password', rateLimitAuth('emp_forgot_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const identifier = String(req.body.email || req.body.identifier || '').trim().toLowerCase();
    const emp = sqlite
      .prepare('SELECT id, branch_id, company_id, country_id, employee_code, full_name, email, job_position, status FROM employee_accounts WHERE LOWER(email) = ? OR LOWER(employee_code) = ?')
      .get(identifier, identifier) as any;

    if (!emp || emp.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible Employee account matches that identifier, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'employee', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), emp.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'emp_pw_reset_otp', ?, ?, 'employee', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, emp.email, sha256(resetOtp), emp.id, expiresAt, now);

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      countryId: emp.country_id,
      actorName: emp.full_name,
      actorRole: emp.job_position || 'Employee',
      action: 'EMPLOYEE_PASSWORD_RESET_REQUESTED',
      module: 'Employee Authentication',
      targetId: emp.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Employee password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/employee/reset-password', rateLimitAuth('emp_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let empId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'employee' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        empId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'emp_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        empId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!empId) {
      res.status(400).json({ error: 'Invalid or expired Employee password reset token/OTP.' });
      return;
    }

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(empId) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee account not found.' });
      return;
    }

    const now = nowIso();
    const nextHash = hashPassword(newPassword);
    sqlite
      .prepare('UPDATE employee_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nextHash, now, emp.id);
    if (emp.user_id) {
      sqlite
        .prepare('UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
        .run(nextHash, now, emp.user_id);
      sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(emp.user_id);
    }

    if (resetRowId) sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    if (otpRowId) sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);

    // Revoke ALL active sessions for this Employee
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(emp.id);

    logEmployeeActivity({
      employeeId: emp.id,
      companyId: emp.company_id,
      branchId: emp.branch_id,
      countryId: emp.country_id,
      actorName: emp.full_name,
      actorRole: emp.job_position || 'Employee',
      action: 'EMPLOYEE_PASSWORD_RESET_COMPLETED',
      module: 'Employee Authentication',
      targetId: emp.email,
      details: 'Password changed and all prior active sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'EMPLOYEE_PASSWORD_RESET',
      userId: emp.id,
      identifier: emp.email,
      companyId: emp.company_id,
      details: 'Employee password reset completed; prior sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Employee password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/employee/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'employee' && req.auth.employeeId && req.auth.companyId) {
        logEmployeeActivity({
          employeeId: req.auth.employeeId,
          companyId: req.auth.companyId,
          branchId: req.auth.branchId,
          countryId: req.auth.country,
          actorName: req.auth.fullName,
          actorRole: req.auth.role,
          action: 'EMPLOYEE_LOGOUT',
          module: 'Employee Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'EMPLOYEE_LOGOUT',
        module: 'Employee Authentication',
        targetId: req.auth.email,
        companyId: req.auth.companyId,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/employee/sessions', requireEmployee, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'employee' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/employee/sessions/:id', requireEmployee, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'employee'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Employee session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logEmployeeActivity({
      employeeId: req.auth!.employeeId!,
      companyId: req.auth!.companyId!,
      branchId: req.auth!.branchId,
      countryId: req.auth!.country,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_SESSION_REVOKED',
      module: 'Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/employee/login-history', requireEmployee, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'employee' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 2G. SEPARATE DEALER LOGIN PORTAL, APPLICATION, VERIFICATION, 2FA & SESSIONS
  // =========================================================================

  router.get('/auth/dealer/status', (_req: Request, res: Response) => {
    const activeCount = (sqlite
      .prepare("SELECT COUNT(*) as cnt FROM dealer_accounts WHERE status = 'Active' AND verification_status = 'Verified'")
      .get() as { cnt: number }).cnt;
    const companies = sqlite
      .prepare("SELECT id, name, country, city FROM companies WHERE status = 'Approved' ORDER BY name ASC")
      .all();
    res.json({
      hasVerifiedDealers: activeCount > 0,
      verifiedDealersCount: activeCount,
      approvedCompanies: companies,
      twoFactorRequired: true,
      emailVerificationRequired: true,
      adminApprovalRequired: true,
      portalIsolated: true,
    });
  });

  // Public dealer application: always created as Pending Approval & Pending Verification (cannot log in until admin approves)
  router.post('/auth/dealer/register', rateLimitAuth('dealer_register', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const businessName = String(req.body.businessName || '').trim();
    const ownerContactName = String(req.body.ownerContactName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const companyId = String(req.body.companyId || 'comp_byd_pk').trim();
    const countryId = String(req.body.countryId || 'PK').trim().toUpperCase();
    const city = String(req.body.city || 'Karachi').trim();
    const businessAddress = String(req.body.businessAddress || '').trim();
    const category = String(req.body.category || 'Authorized EV Reseller').trim();
    const registrationNo = String(req.body.registrationNo || '').trim();
    const taxIdNtn = String(req.body.taxIdNtn || '').trim();

    if (!businessName || !ownerContactName || !email || !mobile || !password) {
      res.status(400).json({ error: 'Business name, authorized contact name, email, mobile number, and password are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const compRow = sqlite.prepare("SELECT id, name, country, status FROM companies WHERE id = ? AND status = 'Approved'").get(companyId) as any;
    if (!compRow) {
      res.status(400).json({ error: 'Selected partner company must be an approved active entity.' });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this business email already exists across BYD PAKISTAN 360.' });
      return;
    }

    const allowedCategories = new Set([
      '3S Flagship Centre',
      '2S Service Facility',
      'Retail Experience Studio',
      'Authorized EV Reseller',
    ]);
    const safeCategory = allowedCategories.has(category) ? category : 'Authorized EV Reseller';

    const dealerId = `dlr_${generateSecureToken(6)}`;
    const dealerCode = `DLR-APP-${countryId.slice(0, 2)}-${generateNumericOtp(4)}`;
    const username = `${email.split('@')[0].replace(/[^a-z0-9._-]/g, '')}_${generateNumericOtp(3)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () => `${generateNumericOtp(4)}-${generateNumericOtp(4)}`);
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO dealer_accounts (
          id, dealer_code, dealership_id, company_id, country_id, branch_id,
          business_name, owner_contact_name, username, email, mobile, password_hash,
          category, verification_status, status, email_verified, two_factor_enabled,
          two_factor_secret, recovery_codes_json, commission_rate_pct, authorized_by,
          created_at, updated_at
        ) VALUES (?, ?, NULL, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, 'Pending Approval', 'Pending Verification', 0, 1, ?, ?, 4.5, 'Pending Admin Approval', ?, ?)
      `)
      .run(
        dealerId,
        dealerCode,
        compRow.id,
        countryId,
        businessName,
        ownerContactName,
        username,
        email,
        mobile,
        hashPassword(password),
        safeCategory,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO dealer_profiles (
          id, dealer_id, business_address, city, country_id, tax_id_ntn, registration_no,
          website, bank_name, bank_account_title, bank_iban_masked,
          pending_change_status, notes, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, '', '', '', '', 'None', 'Self-submitted application awaiting administrator verification.', ?)
      `)
      .run(`dpf_${generateSecureToken(6)}`, dealerId, businessAddress, city, countryId, taxIdNtn, registrationNo, now);

    sqlite
      .prepare(`
        INSERT INTO dealer_permissions (id, dealer_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, 'system_application', ?)
      `)
      .run(`dpm_${generateSecureToken(6)}`, dealerId, JSON.stringify([...CANONICAL_DEALER_PERMISSIONS]), now);

    const emailOtp = issueDealerEmailVerifyOtp({ id: dealerId, email });

    logDealerActivity({
      dealerId,
      companyId: compRow.id,
      countryId,
      actorId: dealerId,
      actorName: ownerContactName,
      actorRole: 'Dealer Applicant',
      action: 'DEALER_APPLICATION_SUBMITTED',
      module: 'Dealer Onboarding',
      targetId: dealerCode,
      details: `Application received for "${businessName}" (${email}); locked Pending Approval until authorized administrator verifies.`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: dealerId,
      actorName: ownerContactName,
      actorRole: 'Dealer Applicant',
      action: 'DEALER_APPLICATION_SUBMITTED',
      module: 'Dealer Management',
      targetId: `${businessName} (${dealerCode})`,
      companyId: compRow.id,
      details: 'Public dealer application submitted; verification & admin approval required before sign-in.',
      ipAddress: ip,
    });

    res.status(201).json({
      success: true,
      pendingAdminApproval: true,
      requiresEmailVerification: true,
      dealer: {
        id: dealerId,
        dealerCode,
        businessName,
        email,
        category: safeCategory,
        verificationStatus: 'Pending Approval',
        status: 'Pending Verification',
      },
      message: 'Dealer application submitted. Verify your email OTP and await administrator approval before signing in.',
      twoFactorProvisioned: {
        totpSecret,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Step 1: Dealer Email / Unique Dealer ID + Password Verification
  router.post('/auth/dealer/login', rateLimitAuth('dealer_login', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const rawIdentifier = String(req.body.identifier || req.body.email || req.body.dealerCode || '').trim();
    const identifier = rawIdentifier.toLowerCase();
    const password = String(req.body.password || '');
    const suppliedDealerCode = String(req.body.dealerCodeCheck || '').trim().toUpperCase();

    if (!identifier || !password) {
      res.status(400).json({ error: 'Unique Dealer ID or registered email address and password are required.' });
      return;
    }

    // Strict Cross-Portal Isolation
    const isFounder = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounder) {
      res.status(403).json({ error: 'Primary Owner must sign in through the private Founder / Owner Portal.' });
      return;
    }
    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({ error: 'Super Admin must sign in through the dedicated Super Admin Portal.' });
      return;
    }
    const isCompanyAdmin = sqlite
      .prepare("SELECT id FROM company_admin_accounts WHERE LOWER(email) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier);
    if (isCompanyAdmin) {
      res.status(403).json({ error: 'Company Admin must sign in through the dedicated Company Admin Portal.' });
      return;
    }
    const isCountryManager = sqlite
      .prepare("SELECT id FROM country_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isCountryManager) {
      res.status(403).json({ error: 'Country Manager must sign in through the dedicated Country Manager Portal.' });
      return;
    }
    const isBranchManager = sqlite
      .prepare("SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier);
    if (isBranchManager) {
      res.status(403).json({ error: 'Branch Manager must sign in through the dedicated Branch Manager Portal.' });
      return;
    }
    const isEmployeeAccount = sqlite
      .prepare("SELECT id, employee_code FROM employee_accounts WHERE LOWER(email) = ? OR LOWER(employee_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isEmployeeAccount) {
      res.status(403).json({ error: `Employee account (${isEmployeeAccount.employee_code}) must sign in through the dedicated Employee Portal.` });
      return;
    }
    const isStandardUser = sqlite
      .prepare("SELECT id, role FROM users WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier) as any;
    if (isStandardUser) {
      res.status(403).json({ error: `${isStandardUser.role} accounts must sign in through the standard BYD Portal, not the Dealer Login Portal.` });
      return;
    }

    const dealer = sqlite
      .prepare(`
        SELECT * FROM dealer_accounts
        WHERE LOWER(email) = ?
           OR LOWER(dealer_code) = ?
           OR LOWER(COALESCE(username, '')) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!dealer) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'dealer', ?, 'Dealer Owner', 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Dealer account not found', ip, ua, nowIso());
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'DEALER_LOGIN_UNKNOWN',
        identifier,
        details: `Failed Dealer portal login attempt for unknown identifier "${identifier}".`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid Dealer credentials.' });
      return;
    }

    if (dealer.locked_until && new Date(dealer.locked_until).getTime() > Date.now()) {
      res.status(423).json({
        error: `Dealer account temporarily locked due to repeated failed attempts. Try again after ${dealer.locked_until}.`,
      });
      return;
    }

    if (dealer.status === 'Suspended') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPENDED_DEALER_LOGIN_BLOCKED',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: `Suspended Dealer (${dealer.dealer_code}) attempted to sign in.`,
        ipAddress: ip,
      });
      res.status(403).json({ error: 'This dealer account has been suspended by an authorized administrator.' });
      return;
    }

    if (dealer.status === 'Rejected' || dealer.verification_status === 'Rejected') {
      res.status(403).json({ error: dealer.rejected_reason || 'This dealer application was rejected by an administrator.' });
      return;
    }

    if (!dealer.password_hash || !verifyPassword(password, dealer.password_hash)) {
      const nextFails = (dealer.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE dealer_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), dealer.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'dealer', ?, 'Dealer Owner', ?, 0, ?, ?, ?, 1, ?)")
        .run(`lh_${generateSecureToken(6)}`, dealer.id, dealer.email, dealer.company_id, 'Incorrect password', ip, ua, nowIso());

      logSecurityEvent({
        severity: shouldLock ? 'CRITICAL' : 'WARNING',
        eventType: shouldLock ? 'DEALER_ACCOUNT_LOCKED' : 'DEALER_FAILED_PASSWORD',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: shouldLock
          ? `Dealer (${dealer.dealer_code}) locked after ${nextFails} failed password attempts.`
          : `Failed Dealer password attempt (${nextFails}/${policy.maxFailedLoginAttempts || 5}).`,
        ipAddress: ip,
      });

      res.status(401).json({
        error: shouldLock
          ? 'Too many failed attempts. Dealer account temporarily locked.'
          : 'Invalid Dealer credentials.',
      });
      return;
    }

    sqlite
      .prepare('UPDATE dealer_accounts SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), dealer.id);

    if (suppliedDealerCode && suppliedDealerCode !== String(dealer.dealer_code).toUpperCase()) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'DEALER_ID_MISMATCH_BLOCKED',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: `Dealer (${dealer.dealer_code}) attempted sign-in with mismatched Dealer ID "${suppliedDealerCode}".`,
        ipAddress: ip,
      });
      res.status(403).json({ error: 'Dealer ID mismatch: verify your assigned Unique Dealer ID.' });
      return;
    }

    if (dealer.verification_status !== 'Verified') {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'UNAPPROVED_DEALER_LOGIN_BLOCKED',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: `Pending/unapproved Dealer (${dealer.dealer_code}) attempted to sign in before admin approval.`,
        ipAddress: ip,
      });
      res.status(403).json({
        error: 'Your dealer account application is pending administrator verification & approval. Login is locked until approved.',
        verificationStatus: dealer.verification_status,
        dealerCode: dealer.dealer_code,
      });
      return;
    }

    const compRow = sqlite.prepare("SELECT id, name, country, city, status FROM companies WHERE id = ? AND status = 'Approved'").get(dealer.company_id) as any;
    if (!compRow) {
      res.status(403).json({ error: 'Assigned partner company is not approved or active.' });
      return;
    }

    const branchRow = dealer.branch_id
      ? (sqlite.prepare('SELECT id, code, name, city FROM branches WHERE id = ?').get(dealer.branch_id) as any)
      : null;

    if (!dealer.email_verified || dealer.status === 'Pending Verification') {
      const emailOtp = issueDealerEmailVerifyOtp(dealer);
      res.json({
        requiresEmailVerification: true,
        email: dealer.email,
        businessName: dealer.business_name,
        dealerCode: dealer.dealer_code,
        branchName: branchRow?.name || null,
        companyName: compRow.name,
        message: 'Email verification required before signing in. Enter the 6-digit verification OTP.',
        verificationOutbox: process.env.SMTP_HOST
          ? undefined
          : {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: emailOtp,
            },
      });
      return;
    }

    const suspicious = Boolean(dealer.last_login_ip && dealer.last_login_ip !== ip);
    if (suspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'SUSPICIOUS_DEALER_LOGIN_IP',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: `Dealer (${dealer.dealer_code}) password verified from new IP ${ip} (previous: ${dealer.last_login_ip}).`,
        ipAddress: ip,
      });
      logDealerActivity({
        dealerId: dealer.id,
        companyId: dealer.company_id,
        countryId: dealer.country_id,
        branchId: dealer.branch_id,
        actorId: dealer.id,
        actorName: dealer.business_name,
        actorRole: 'Dealer Owner',
        action: 'SUSPICIOUS_LOGIN_ALERT',
        module: 'Dealer Security',
        targetId: ip,
        details: `New IP detected (${ip}; previous ${dealer.last_login_ip}). 2FA challenge required.`,
        ipAddress: ip,
        status: 'WARNING',
      });
    }

    const { challengeToken, emailOtp } = issueDealer2FAChallenge(dealer);

    res.json({
      requires2FA: true,
      challengeToken,
      email: dealer.email,
      businessName: dealer.business_name,
      dealerCode: dealer.dealer_code,
      category: dealer.category,
      branchName: branchRow?.name || null,
      companyName: compRow.name,
      suspiciousIpDetected: suspicious,
      message: 'Password verified. Enter your 6-digit Authenticator TOTP code, single-use Login OTP, or backup recovery code.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Step 2a: Dealer Email OTP Verification
  router.post('/auth/dealer/verify-email', rateLimitAuth('dealer_verify_email', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();

    if (!email || !code) {
      res.status(400).json({ error: 'Email and 6-digit verification code are required.' });
      return;
    }

    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!dealer) {
      res.status(404).json({ error: 'Dealer account not found.' });
      return;
    }
    if (dealer.status === 'Suspended' || dealer.status === 'Rejected') {
      res.status(403).json({ error: 'Dealer account is suspended or rejected.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'dlr_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification OTP has expired or was not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification OTP code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);

    const nextStatus = dealer.verification_status === 'Verified' ? 'Active' : dealer.status;
    sqlite
      .prepare('UPDATE dealer_accounts SET email_verified = 1, status = ?, updated_at = ? WHERE id = ?')
      .run(nextStatus, now, dealer.id);

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: dealer.id,
      actorName: dealer.business_name,
      actorRole: 'Dealer Owner',
      action: 'DEALER_EMAIL_VERIFIED',
      module: 'Dealer Authentication',
      targetId: dealer.email,
      ipAddress: ip,
    });

    if (dealer.verification_status !== 'Verified') {
      res.json({
        success: true,
        requiresAdminApproval: true,
        requires2FA: false,
        email: dealer.email,
        dealerCode: dealer.dealer_code,
        verificationStatus: dealer.verification_status,
        message: 'Email verified successfully. Your application remains pending authorized administrator approval before first sign-in.',
      });
      return;
    }

    const compRow = sqlite.prepare('SELECT name FROM companies WHERE id = ?').get(dealer.company_id) as any;
    const branchRow = dealer.branch_id ? (sqlite.prepare('SELECT name FROM branches WHERE id = ?').get(dealer.branch_id) as any) : null;
    const { challengeToken, emailOtp } = issueDealer2FAChallenge(dealer);

    res.json({
      success: true,
      requires2FA: true,
      challengeToken,
      email: dealer.email,
      businessName: dealer.business_name,
      dealerCode: dealer.dealer_code,
      category: dealer.category,
      branchName: branchRow?.name || null,
      companyName: compRow?.name || dealer.company_id,
      message: 'Email verified and Dealer account activated. Complete 2FA to open your Dealer Dashboard.',
      otpOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development 2FA Email OTP Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Step 2b: Dealer Mandatory 2FA Verification
  router.post('/auth/dealer/verify-2fa', rateLimitAuth('dealer_verify_2fa', 30, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: '2FA challenge token and verification code are required.' });
      return;
    }

    const challenge = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE purpose = 'dlr_2fa_challenge' AND code_hash = ? AND used_at IS NULL
      `)
      .get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(challenge.subject_id) as any;
    if (!dealer || dealer.status !== 'Active' || dealer.verification_status !== 'Verified' || !dealer.email_verified) {
      res.status(403).json({ error: 'Dealer account is suspended, unapproved, or email is unverified.' });
      return;
    }

    const compRow = sqlite.prepare("SELECT * FROM companies WHERE id = ? AND status = 'Approved'").get(dealer.company_id) as any;
    if (!compRow) {
      res.status(403).json({ error: 'Assigned partner company is inactive or unapproved.' });
      return;
    }

    const branchRow = dealer.branch_id ? (sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(dealer.branch_id) as any) : null;
    const profileRow = sqlite.prepare('SELECT city FROM dealer_profiles WHERE dealer_id = ?').get(dealer.id) as any;

    let verified = Boolean(dealer.two_factor_secret) && verifyTotpCode(dealer.two_factor_secret, code);
    let method = 'TOTP Authenticator';

    if (!verified) {
      const otpRow = sqlite
        .prepare(`
          SELECT * FROM otp_verifications
          WHERE subject_id = ? AND purpose = 'dlr_2fa_otp' AND used_at IS NULL
          ORDER BY created_at DESC LIMIT 1
        `)
        .get(dealer.id) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(code)) {
        verified = true;
        method = 'Single-Use Email OTP';
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
    }

    if (!verified) {
      const storedHashes: string[] = JSON.parse(dealer.recovery_codes_json || '[]');
      const inputHash = sha256(code);
      const matchIdx = storedHashes.findIndex((h) => h === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        method = 'Backup Recovery Code';
        storedHashes.splice(matchIdx, 1);
        sqlite
          .prepare('UPDATE dealer_accounts SET recovery_codes_json = ? WHERE id = ?')
          .run(JSON.stringify(storedHashes), dealer.id);
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'DEALER_RECOVERY_CODE_USED',
          userId: dealer.id,
          identifier: dealer.email,
          companyId: dealer.company_id,
          details: `Dealer (${dealer.dealer_code}) signed in using backup recovery code (${storedHashes.length} remaining).`,
          ipAddress: ip,
        });
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'DEALER_2FA_FAILED',
        userId: dealer.id,
        identifier: dealer.email,
        companyId: dealer.company_id,
        details: `Invalid 2FA code submitted on Dealer portal (${dealer.dealer_code}).`,
        ipAddress: ip,
      });
      res.status(401).json({ error: 'Invalid 2FA TOTP, login OTP, or backup recovery code.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, challenge.id);
    sqlite
      .prepare('UPDATE dealer_accounts SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, dealer.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'dealer', ?, 'Dealer Owner', ?, 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, dealer.id, dealer.email, dealer.company_id, ip, ua, now);

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id || compRow.country,
      branchId: dealer.branch_id,
      actorId: dealer.id,
      actorName: dealer.business_name,
      actorRole: 'Dealer Owner',
      action: 'DEALER_LOGIN',
      module: 'Dealer Authentication',
      targetId: dealer.dealer_code,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: dealer.id,
      actorName: dealer.business_name,
      actorRole: 'Dealer Owner',
      action: 'DEALER_2FA_LOGIN_SUCCESS',
      module: 'Dealer Authentication',
      targetId: `${dealer.email} (${dealer.dealer_code})`,
      companyId: dealer.company_id,
      details: `Dealer login via ${method}`,
      ipAddress: ip,
    });

    const permissions = resolveDealerPermissions(dealer.id);
    const session = createSession({
      userId: dealer.id,
      subjectType: 'dealer',
      companyId: dealer.company_id,
      role: 'Dealer Owner',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: dealer.id,
        dealerId: dealer.id,
        dealerCode: dealer.dealer_code,
        dealerCategory: dealer.category,
        verificationStatus: dealer.verification_status,
        dealershipId: dealer.dealership_id || null,
        companyId: dealer.company_id,
        branchId: dealer.branch_id || null,
        branchName: branchRow?.name || null,
        name: dealer.business_name,
        fullName: dealer.business_name,
        email: dealer.email,
        phone: dealer.mobile,
        role: 'Dealer Owner',
        designation: dealer.category,
        country: dealer.country_id || compRow.country || 'PK',
        city: profileRow?.city || branchRow?.city || compRow.city || 'Karachi',
        permissions,
        subjectType: 'dealer',
        emailVerified: true,
        verifiedIdentity: true,
      },
      organization: {
        companyId: compRow.id,
        companyName: compRow.name,
        countryId: dealer.country_id || compRow.country,
        branchId: dealer.branch_id || null,
        branchName: branchRow?.name || null,
      },
    });
  });

  // Dealer Forgot & Reset Password (revokes all active sessions)
  router.post('/auth/dealer/forgot-password', rateLimitAuth('dealer_forgot_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const identifier = String(req.body.email || req.body.identifier || '').trim().toLowerCase();
    const dealer = sqlite
      .prepare('SELECT id, branch_id, company_id, country_id, dealer_code, business_name, email, status FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ?')
      .get(identifier, identifier) as any;

    if (!dealer || dealer.status === 'Suspended' || dealer.status === 'Rejected') {
      res.json({
        success: true,
        message: 'If an eligible Dealer account matches that identifier, a reset token and OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'dealer', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), dealer.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'dlr_pw_reset_otp', ?, ?, 'dealer', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, dealer.email, sha256(resetOtp), dealer.id, expiresAt, now);

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: dealer.id,
      actorName: dealer.business_name,
      actorRole: 'Dealer Owner',
      action: 'DEALER_PASSWORD_RESET_REQUESTED',
      module: 'Dealer Authentication',
      targetId: dealer.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Dealer password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/dealer/reset-password', rateLimitAuth('dealer_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let dealerId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'dealer' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        dealerId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'dlr_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        dealerId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!dealerId) {
      res.status(400).json({ error: 'Invalid or expired Dealer password reset token/OTP.' });
      return;
    }

    const dealer = sqlite.prepare('SELECT * FROM dealer_accounts WHERE id = ?').get(dealerId) as any;
    if (!dealer) {
      res.status(404).json({ error: 'Dealer account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE dealer_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, dealer.id);

    if (resetRowId) sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    if (otpRowId) sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);

    // Revoke ALL active sessions for this Dealer
    sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'dealer'").run(dealer.id);

    logDealerActivity({
      dealerId: dealer.id,
      companyId: dealer.company_id,
      countryId: dealer.country_id,
      branchId: dealer.branch_id,
      actorId: dealer.id,
      actorName: dealer.business_name,
      actorRole: 'Dealer Owner',
      action: 'DEALER_PASSWORD_RESET_COMPLETED',
      module: 'Dealer Authentication',
      targetId: dealer.email,
      details: 'Password changed and all prior active dealer sessions revoked.',
      ipAddress: ip,
    });

    logSecurityEvent({
      severity: 'INFO',
      eventType: 'DEALER_PASSWORD_RESET',
      userId: dealer.id,
      identifier: dealer.email,
      companyId: dealer.company_id,
      details: 'Dealer password reset completed; prior sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Dealer password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/dealer/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'dealer' && req.auth.dealerId && req.auth.companyId) {
        logDealerActivity({
          dealerId: req.auth.dealerId,
          companyId: req.auth.companyId,
          countryId: req.auth.country,
          branchId: req.auth.branchId,
          actorId: req.auth.userId,
          actorName: req.auth.fullName,
          actorRole: 'Dealer Owner',
          action: 'DEALER_LOGOUT',
          module: 'Dealer Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'DEALER_LOGOUT',
        module: 'Dealer Authentication',
        targetId: req.auth.email,
        companyId: req.auth.companyId,
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/dealer/sessions', requireDealer, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'dealer' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/dealer/sessions/:id', requireDealer, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'dealer'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Dealer session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logDealerActivity({
      dealerId: req.auth!.dealerId!,
      companyId: req.auth!.companyId!,
      countryId: req.auth!.country,
      branchId: req.auth!.branchId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: 'Dealer Owner',
      action: 'DEALER_SESSION_REVOKED',
      module: 'Dealer Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/dealer/login-history', requireDealer, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'dealer' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 2H. DEDICATED CUSTOMER LOGIN & REGISTRATION PORTAL (/api/auth/customer/*)
  // =========================================================================

  const isSmsConfigured = () =>
    Boolean(
      (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_FROM_NUMBER) ||
        process.env.SMS_API_KEY
    );

  router.get('/auth/customer/status', (_req: Request, res: Response) => {
    const customersCount = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_accounts WHERE status = 'Active'").get() as any).c;
    res.json({
      portal: 'customer',
      customersCount,
      smsConfigured: isSmsConfigured(),
      smtpConfigured: Boolean(process.env.SMTP_HOST),
      paymentGatewayConfigured: Boolean(process.env.STRIPE_SECRET_KEY || process.env.PAYFAST_MERCHANT_ID),
    });
  });

  router.post('/auth/customer/register', rateLimitAuth('customer_register', 15, 60_000), async (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobileRaw = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const confirmPassword = String(req.body.confirmPassword || '');
    const country = String(req.body.country || 'PK').trim().toUpperCase();
    const city = String(req.body.city || 'Karachi').trim();
    const address = String(req.body.address || '').trim();
    const cnicOrId = String(req.body.cnicOrId || '').trim();
    const termsAccepted = req.body.termsAccepted === true || req.body.termsAccepted === 'true';
    const privacyAccepted = req.body.privacyAccepted === true || req.body.privacyAccepted === 'true';

    if (!fullName || fullName.length < 2) {
      res.status(400).json({ error: 'Full name (at least 2 characters) is required.' });
      return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'A valid email address is required.' });
      return;
    }
    if (!mobileRaw || !/^\+\d[\d\s-]{7,18}$/.test(mobileRaw)) {
      res.status(400).json({ error: 'A valid mobile number with country code (e.g. +92 300 1234567) is required.' });
      return;
    }
    if (!termsAccepted || !privacyAccepted) {
      res.status(400).json({ error: 'You must explicitly accept both the Terms of Service and Privacy Policy to register.' });
      return;
    }
    if (confirmPassword !== password) {
      res.status(400).json({ error: 'Password and Confirm Password do not match.' });
      return;
    }
    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const normMobile = normalizePhone(mobileRaw);
    const emailExists =
      sqlite.prepare('SELECT id FROM user_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM customer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);

    if (emailExists) {
      res.status(409).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const verifiedPhoneExists =
      sqlite.prepare('SELECT id FROM user_accounts WHERE verified_phone = ? AND mobile_verified = 1').get(normMobile) ||
      sqlite.prepare("SELECT id FROM customer_accounts WHERE REPLACE(REPLACE(REPLACE(mobile, ' ', ''), '-', ''), '(', '') = ?").get(normMobile);
    if (verifiedPhoneExists) {
      res.status(409).json({ error: 'An account with this mobile number already exists.' });
      return;
    }

    // Match company to country where available
    const compRow =
      (sqlite.prepare("SELECT id FROM companies WHERE country = ? AND status = 'Approved' LIMIT 1").get(country) as any) ||
      (sqlite.prepare("SELECT id FROM companies WHERE id = 'comp_byd_pk'").get() as any);
    const companyId = compRow?.id || 'comp_byd_pk';

    const customerId = `cust_${generateSecureToken(6)}`;
    const customerCode = `CUS-${country}-2026-${generateNumericOtp(4)}`;
    const now = nowIso();
    const otpCode = generateNumericOtp(6);
    const verificationToken = generateSecureToken(32);
    const otpExpires = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const smsReady = isSmsConfigured();

    const insertTx = sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO customer_accounts (
            id, customer_code, company_id, country_id, full_name, email, mobile, password_hash,
            role, account_type, country, city, address, verification_status, status,
            email_verified, mobile_verified, terms_accepted, terms_accepted_at, privacy_accepted, privacy_accepted_at,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Customer', 'Individual Customer', ?, ?, ?, 'Pending Verification', 'Pending Verification', 0, 0, 1, ?, 1, ?, ?, ?)
        `)
        .run(
          customerId,
          customerCode,
          companyId,
          country,
          fullName,
          email,
          mobileRaw,
          hashPassword(password),
          country,
          city,
          address,
          now,
          now,
          now,
          now
        );

      sqlite
        .prepare(`
          INSERT INTO customer_profiles (
            customer_id, cnic_or_id, preferred_language, preferred_currency, updated_at
          ) VALUES (?, ?, 'en', ?, ?)
        `)
        .run(
          customerId,
          cnicOrId,
          country === 'AE' ? 'AED' : country === 'SA' ? 'SAR' : country === 'GB' ? 'GBP' : country === 'DE' ? 'EUR' : 'PKR',
          now
        );

      sqlite
        .prepare(`
          INSERT INTO customer_verifications (id, customer_id, channel, target, status, otp_ref, provider, created_at)
          VALUES (?, ?, 'email', ?, 'Pending', ?, ?, ?)
        `)
        .run(
          `cver_${generateSecureToken(6)}`,
          customerId,
          email,
          otpCode.slice(0, 2) + '****',
          isSmtpConfigured() ? 'SMTP Mailer' : 'Development Mailer Outbox',
          now
        );

      sqlite
        .prepare(`
          INSERT INTO customer_verifications (id, customer_id, channel, target, status, provider, metadata_json, created_at)
          VALUES (?, ?, 'mobile', ?, ?, ?, ?, ?)
        `)
        .run(
          `cver_${generateSecureToken(6)}`,
          customerId,
          mobileRaw,
          smsReady ? 'Pending' : 'Provider Not Configured',
          smsReady ? 'Configured SMS Gateway' : 'Not Configured',
          JSON.stringify({ smsConfigured: smsReady }),
          now
        );

      sqlite
        .prepare(`
          INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
          VALUES (?, ?, 'cus_email_verify', ?, ?, 'customer', ?, 0, ?)
        `)
        .run(`otp_${generateSecureToken(6)}`, email, sha256(otpCode), customerId, otpExpires, now);

      sqlite
        .prepare(`
          INSERT INTO email_verification_tokens (id, user_id, subject_type, email, token_hash, expires_at, created_ip, created_at)
          VALUES (?, ?, 'customer', ?, ?, ?, ?, ?)
        `)
        .run(`evt_${generateSecureToken(6)}`, customerId, email, sha256(verificationToken), otpExpires, ip, now);
    });
    insertTx();
    syncUnifiedSecurityRegistry();

    const dispatchRes = await dispatchVerificationEmail({
      to: email,
      subject: 'BYD PAKISTAN 360 — Verify Your Customer Email',
      text: `Welcome to BYD PAKISTAN 360. Verify your email with OTP ${otpCode} or verification token ${verificationToken}. Expires in 30 minutes.`,
    });

    logCustomerActivity({
      customerId,
      companyId,
      countryId: country,
      actorId: customerId,
      actorName: fullName,
      actorRole: 'Customer',
      action: 'CUSTOMER_REGISTERED',
      module: 'Customer Onboarding',
      targetId: customerCode,
      details: `Registered new customer account (${email}) with Terms & Privacy consent`,
      ipAddress: ip,
    });

    logOwnerAudit({
      actorId: customerId,
      actorName: fullName,
      actorRole: 'Customer',
      action: 'CUSTOMER_PORTAL_REGISTERED',
      module: 'Customer Onboarding',
      targetId: `${email} (${customerCode})`,
      companyId,
      ipAddress: ip,
    });

    logSecurityAudit({
      actorId: customerId,
      actorName: fullName,
      actorRole: 'Customer',
      targetUserId: customerId,
      companyId,
      countryId: country,
      action: 'CUSTOMER_REGISTERED',
      category: 'Registration & Verification',
      details: `Customer ${customerCode} registered (${email}); termsAcceptedAt=${now}; privacyAcceptedAt=${now}`,
      ipAddress: ip,
    });

    res.status(201).json({
      success: true,
      requiresEmailVerification: true,
      smsConfigured: smsReady,
      emailDeliveryMode: dispatchRes.mode,
      customer: {
        id: customerId,
        customerCode,
        fullName,
        email,
        mobile: mobileRaw,
        country,
        city,
        verificationStatus: 'Pending Verification',
        status: 'Pending Verification',
      },
      message: smsReady
        ? 'Customer account created. Verify your email OTP/token (and optional mobile SMS OTP) to activate login.'
        : 'Customer account created. Verify your email with the 6-digit OTP or verification token to activate login. (Mobile SMS OTP requires an external SMS provider configuration.)',
      verificationOutbox:
        dispatchRes.mode === 'dev_outbox'
          ? {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: otpCode,
              verificationToken,
            }
          : undefined,
    });
  });

  router.post('/auth/customer/verify-email', rateLimitAuth('customer_verify_email', 20, 60_000), (req: Request, res: Response) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();
    if (!email || !code) {
      res.status(400).json({ error: 'Email address and 6-digit verification code are required.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'cus_email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Email verification code expired or not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAtt = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, otpRow.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect email verification code.' });
      return;
    }

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
      sqlite.prepare('UPDATE email_verification_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL').run(now, otpRow.subject_id);
      sqlite
        .prepare(`
          UPDATE customer_accounts
          SET email_verified = 1,
              status = CASE WHEN status = 'Suspended' THEN 'Suspended' ELSE 'Active' END,
              verification_status = CASE WHEN verification_status = 'Verified' THEN 'Verified' ELSE 'Email Verified' END,
              updated_at = ?
          WHERE id = ?
        `)
        .run(now, otpRow.subject_id);

      sqlite
        .prepare(`
          UPDATE customer_verifications
          SET status = 'Verified', verified_at = ?
          WHERE customer_id = ? AND channel = 'email' AND status = 'Pending'
        `)
        .run(now, otpRow.subject_id);
    })();
    syncUnifiedSecurityRegistry();

    const cust = sqlite.prepare('SELECT id, customer_code, company_id, country_id, full_name FROM customer_accounts WHERE id = ?').get(otpRow.subject_id) as any;
    if (cust) {
      logCustomerActivity({
        customerId: cust.id,
        companyId: cust.company_id,
        countryId: cust.country_id,
        actorId: cust.id,
        actorName: cust.full_name,
        actorRole: 'Customer',
        action: 'CUSTOMER_EMAIL_VERIFIED',
        module: 'Customer Authentication',
        targetId: cust.customer_code,
        ipAddress: getClientIp(req),
      });
      logSecurityAudit({
        actorId: cust.id,
        actorName: cust.full_name,
        actorRole: 'Customer',
        targetUserId: cust.id,
        companyId: cust.company_id,
        countryId: cust.country_id,
        action: 'EMAIL_VERIFIED_OTP',
        category: 'Registration & Verification',
        details: `Customer email verified via 6-digit OTP (${cust.customer_code})`,
        ipAddress: getClientIp(req),
      });
    }

    res.json({
      success: true,
      message: 'Email verified and Customer Portal account activated. You may now sign in.',
    });
  });

  router.post('/auth/customer/resend-otp', rateLimitAuth('customer_resend_otp', 10, 60_000), (req: Request, res: Response) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const cust = sqlite.prepare('SELECT id, full_name, email, email_verified FROM customer_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!cust) {
      res.json({ success: true, message: 'If an unverified customer account matches that email, a fresh code has been sent.' });
      return;
    }
    if (cust.email_verified) {
      res.status(400).json({ error: 'This customer email is already verified. You can sign in directly.' });
      return;
    }

    const otpCode = generateNumericOtp(6);
    const otpExpires = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
        VALUES (?, ?, 'cus_email_verify', ?, ?, 'customer', ?, 0, ?)
      `)
      .run(`otp_${generateSecureToken(6)}`, cust.email, sha256(otpCode), cust.id, otpExpires, now);

    res.json({
      success: true,
      message: 'A new 6-digit email verification code has been issued.',
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: otpCode,
          },
    });
  });

  router.post('/auth/customer/mobile/request-otp', (req: Request, res: Response) => {
    if (!isSmsConfigured()) {
      res.status(503).json({
        smsConfigured: false,
        error: 'SMS provider is not configured on this server. Configure TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_FROM_NUMBER (or SMS_API_KEY) to enable mobile OTP verification.',
      });
      return;
    }
    res.status(501).json({
      smsConfigured: true,
      error: 'External SMS gateway webhook integration must be triggered for mobile OTP dispatch.',
    });
  });

  router.post('/auth/customer/mobile/verify-otp', (_req: Request, res: Response) => {
    if (!isSmsConfigured()) {
      res.status(503).json({
        smsConfigured: false,
        error: 'SMS provider is not configured on this server. Mobile OTP cannot be verified without a configured SMS provider.',
      });
      return;
    }
    res.status(400).json({ error: 'Invalid or expired mobile SMS OTP.' });
  });

  router.post('/auth/customer/login', rateLimitAuth('customer_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown Client').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Customer email (or Customer ID) and password are required.' });
      return;
    }

    // Strict Portal Separation: reject Founder / SA / CA / CM / BM / Employee / Dealer accounts
    const nonCustomerHit =
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(identifier) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(identifier) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(identifier) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ?').get(identifier, identifier) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ? OR LOWER(manager_code) = ?').get(identifier, identifier) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ? OR LOWER(employee_code) = ?').get(identifier, identifier) ||
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ?').get(identifier, identifier) ||
      sqlite.prepare("SELECT id FROM users WHERE LOWER(email) = ? AND role != 'Customer'").get(identifier);

    if (nonCustomerHit) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'NON_CUSTOMER_ON_CUSTOMER_PORTAL',
        identifier,
        details: `Corporate/Staff/Dealer/Admin account attempted login on isolated Customer Portal.`,
        ipAddress: ip,
      });
      res.status(403).json({
        error: 'This account belongs to a corporate, dealer, or administration portal and cannot sign in through the Customer Portal.',
      });
      return;
    }

    const cust = sqlite
      .prepare(`
        SELECT * FROM customer_accounts
        WHERE LOWER(email) = ? OR LOWER(customer_code) = ?
      `)
      .get(identifier, identifier) as any;

    if (!cust) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'customer', ?, 0, ?, ?, ?, 0, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Customer account not found', ip, ua, nowIso());
      res.status(401).json({ error: 'Invalid customer credentials.' });
      return;
    }

    if (cust.locked_until && new Date(cust.locked_until).getTime() > Date.now()) {
      res.status(423).json({ error: `Customer account temporarily locked until ${cust.locked_until}.` });
      return;
    }

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!verifyPassword(password, cust.password_hash)) {
      const nextFails = (cust.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE customer_accounts SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), cust.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'customer', ?, 'Customer', ?, 0, ?, ?, ?, ?, ?)")
        .run(`lh_${generateSecureToken(6)}`, cust.id, identifier, cust.company_id, 'Invalid password', ip, ua, shouldLock ? 1 : 0, nowIso());

      if (shouldLock) {
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'CUSTOMER_ACCOUNT_LOCKED',
          userId: cust.id,
          identifier: cust.email,
          companyId: cust.company_id,
          details: `Customer account (${cust.customer_code}) locked after ${nextFails} failed password attempts.`,
          ipAddress: ip,
        });
      }

      res.status(401).json({
        error: shouldLock ? 'Account locked due to multiple failed sign-in attempts.' : 'Invalid customer credentials.',
      });
      return;
    }

    if (!cust.email_verified || cust.status === 'Pending Verification') {
      res.status(403).json({
        error: 'Please verify your email address before signing in to the Customer Portal.',
        requiresEmailVerification: true,
        email: cust.email,
      });
      return;
    }

    if (cust.status === 'Suspended') {
      res.status(403).json({
        error: 'Your customer account has been suspended by an administrator. Please contact BYD Care support.',
      });
      return;
    }

    const isSuspicious = Boolean(cust.last_login_ip && cust.last_login_ip !== ip);
    const now = nowIso();

    sqlite
      .prepare('UPDATE customer_accounts SET failed_login_attempts = 0, locked_until = NULL, last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(now, ip, now, cust.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'customer', ?, 'Customer', ?, 1, ?, ?, ?, ?)")
      .run(`lh_${generateSecureToken(6)}`, cust.id, cust.email, cust.company_id, ip, ua, isSuspicious ? 1 : 0, now);

    if (isSuspicious) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'CUSTOMER_SUSPICIOUS_LOGIN_ALERT',
        userId: cust.id,
        identifier: cust.email,
        companyId: cust.company_id,
        details: `Customer ${cust.customer_code} signed in from a new IP address (${ip}, previous: ${cust.last_login_ip}).`,
        ipAddress: ip,
      });
      sqlite
        .prepare(`
          INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
          VALUES (?, ?, ?, ?, 'Security', ?, ?, 'High', 'profile', 0, ?)
        `)
        .run(
          `cnot_${generateSecureToken(6)}`,
          cust.id,
          cust.company_id,
          cust.country_id || cust.country,
          'New Sign-In Detected on Your Customer Account',
          `A sign-in occurred from IP ${ip} (${ua.slice(0, 80)}). Review your active sessions if this was not you.`,
          now
        );
    }

    logCustomerActivity({
      customerId: cust.id,
      companyId: cust.company_id,
      countryId: cust.country_id || cust.country,
      branchId: cust.branch_id,
      actorId: cust.id,
      actorName: cust.full_name,
      actorRole: 'Customer',
      action: 'CUSTOMER_LOGIN_SUCCESS',
      module: 'Customer Authentication',
      targetId: cust.customer_code,
      details: isSuspicious ? `Signed in from new IP ${ip}` : 'Signed in to Customer Portal',
      ipAddress: ip,
    });

    const profileRow = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(cust.id) as any;
    const session = createSession({
      userId: cust.id,
      subjectType: 'customer',
      companyId: cust.company_id || 'comp_byd_pk',
      role: 'Customer',
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      suspiciousLoginAlert: isSuspicious,
      user: {
        id: cust.id,
        customerId: cust.id,
        customerCode: cust.customer_code,
        companyId: cust.company_id,
        branchId: cust.branch_id || null,
        name: cust.full_name,
        fullName: cust.full_name,
        email: cust.email,
        phone: cust.mobile,
        role: 'Customer',
        accountType: cust.account_type,
        country: cust.country,
        city: cust.city,
        address: cust.address,
        verificationStatus: cust.verification_status,
        emailVerified: Boolean(cust.email_verified),
        mobileVerified: Boolean(cust.mobile_verified),
        verifiedIdentity: cust.verification_status === 'Verified',
        avatarUrl: profileRow?.avatar_url || '',
        subjectType: 'customer',
        permissions: ['customer.portal.access'],
      },
    });
  });

  router.post('/auth/customer/forgot-password', rateLimitAuth('customer_forgot_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const identifier = String(req.body.email || req.body.identifier || '').trim().toLowerCase();
    const cust = sqlite
      .prepare('SELECT id, customer_code, company_id, country_id, full_name, email, status FROM customer_accounts WHERE LOWER(email) = ? OR LOWER(customer_code) = ?')
      .get(identifier, identifier) as any;

    if (!cust || cust.status === 'Suspended') {
      res.json({
        success: true,
        message: 'If an eligible customer account matches that identifier, a password reset token and 6-digit OTP have been issued.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const resetOtp = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 20 * 60 * 1000).toISOString();
    const now = nowIso();

    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'customer', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), cust.id, expiresAt, now);

    sqlite
      .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'cus_pw_reset_otp', ?, ?, 'customer', ?, 0, ?)")
      .run(`otp_${generateSecureToken(6)}`, cust.email, sha256(resetOtp), cust.id, expiresAt, now);

    logCustomerActivity({
      customerId: cust.id,
      companyId: cust.company_id,
      countryId: cust.country_id,
      actorId: cust.id,
      actorName: cust.full_name,
      actorRole: 'Customer',
      action: 'CUSTOMER_PASSWORD_RESET_REQUESTED',
      module: 'Customer Authentication',
      targetId: cust.email,
      ipAddress: ip,
    });

    res.json({
      success: true,
      message: 'Customer password reset token and 6-digit OTP issued (valid for 20 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
            otpCode: resetOtp,
          },
    });
  });

  router.post('/auth/customer/reset-password', rateLimitAuth('customer_reset_pw', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const token = String(req.body.token || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const otpCode = String(req.body.otpCode || '').trim();
    const newPassword = String(req.body.newPassword || '');
    const confirmPassword = String(req.body.confirmPassword ?? newPassword);

    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'New password and Confirm Password do not match.' });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    let customerId: string | null = null;
    let resetRowId: string | null = null;
    let otpRowId: string | null = null;

    if (token) {
      const resetRow = sqlite
        .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'customer' AND used_at IS NULL")
        .get(sha256(token)) as any;
      if (resetRow && new Date(resetRow.expires_at).getTime() > Date.now()) {
        customerId = resetRow.user_id;
        resetRowId = resetRow.id;
      }
    } else if (email && otpCode) {
      const otpRow = sqlite
        .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'cus_pw_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
        .get(email) as any;
      if (otpRow && new Date(otpRow.expires_at).getTime() > Date.now() && otpRow.code_hash === sha256(otpCode)) {
        customerId = otpRow.subject_id;
        otpRowId = otpRow.id;
      }
    }

    if (!customerId) {
      res.status(400).json({ error: 'Invalid or expired customer password reset token/OTP.' });
      return;
    }

    const cust = sqlite.prepare('SELECT * FROM customer_accounts WHERE id = ?').get(customerId) as any;
    if (!cust) {
      res.status(404).json({ error: 'Customer account not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE customer_accounts SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(hashPassword(newPassword), now, cust.id);

    if (resetRowId) sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRowId);
    if (otpRowId) sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRowId);

    // Revoke ALL prior active customer sessions
    sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'customer'").run(cust.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(cust.id);

    logCustomerActivity({
      customerId: cust.id,
      companyId: cust.company_id,
      countryId: cust.country_id,
      actorId: cust.id,
      actorName: cust.full_name,
      actorRole: 'Customer',
      action: 'CUSTOMER_PASSWORD_RESET_COMPLETED',
      module: 'Customer Authentication',
      targetId: cust.email,
      details: 'Password reset completed and all prior customer sessions revoked.',
      ipAddress: ip,
    });

    res.json({ success: true, message: 'Customer password updated and all previous sessions revoked. Please sign in again.' });
  });

  router.post('/auth/customer/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?").run(nowIso(), req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(req.auth.sessionId);
      if (req.auth.subjectType === 'customer' && req.auth.customerId) {
        logCustomerActivity({
          customerId: req.auth.customerId,
          companyId: req.auth.companyId,
          countryId: req.auth.country,
          branchId: req.auth.branchId,
          actorId: req.auth.userId,
          actorName: req.auth.fullName,
          actorRole: 'Customer',
          action: 'CUSTOMER_LOGOUT',
          module: 'Customer Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.get('/auth/customer/sessions', requireCustomer, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND subject_type = 'customer' AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/customer/sessions/:id', requireCustomer, (req: Request, res: Response) => {
    const target = sqlite
      .prepare("SELECT id, user_id FROM authentication_sessions WHERE id = ? AND subject_type = 'customer'")
      .get(req.params.id) as any;
    if (!target || target.user_id !== req.auth!.userId) {
      res.status(404).json({ error: 'Customer session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    logCustomerActivity({
      customerId: req.auth!.customerId!,
      companyId: req.auth!.companyId,
      countryId: req.auth!.country,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: 'Customer',
      action: 'CUSTOMER_SESSION_REVOKED',
      module: 'Customer Session Management',
      targetId: target.id,
      ipAddress: getClientIp(req),
    });
    res.json({ success: true });
  });

  router.get('/auth/customer/login-history', requireCustomer, (req: Request, res: Response) => {
    const history = sqlite
      .prepare("SELECT id, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'customer' ORDER BY created_at DESC LIMIT 40")
      .all(req.auth!.userId);
    res.json({ history });
  });

  // =========================================================================
  // 3. PRIVATE FOUNDER / OWNER DASHBOARD & GOVERNANCE APIS (/api/owner/*)
  // =========================================================================

  router.get('/owner/overview', requireFounder, (_req: Request, res: Response) => {
    const totalCountries = (sqlite.prepare("SELECT COUNT(*) as c FROM countries WHERE status = 'Active'").get() as any).c;
    const totalCompanies = (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c;
    const approvedCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Approved'").get() as any).c;
    const pendingCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Pending Approval'").get() as any).c;
    const totalBranches = (sqlite.prepare('SELECT COUNT(*) as c FROM branches').get() as any).c;
    const totalDealerships = (sqlite.prepare('SELECT COUNT(*) as c FROM dealerships').get() as any).c;
    const totalEmployees = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c;
    const totalCustomers = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts').get() as any).c;
    const totalVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles').get() as any).c;
    const totalSoldVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE sold_at IS NOT NULL').get() as any).c;
    const totalBookings = (sqlite.prepare('SELECT COUNT(*) as c FROM bookings').get() as any).c;
    const totalServiceJobs = (sqlite.prepare('SELECT COUNT(*) as c FROM service_jobs').get() as any).c;
    const totalWarrantyClaims = (sqlite.prepare('SELECT COUNT(*) as c FROM warranty_claims').get() as any).c;
    const revenueStats = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal,
          COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal,
          COUNT(*) as invoiceCount
        FROM payments_invoices
      `)
      .get() as any;

    const activeSessions = (sqlite
      .prepare('SELECT COUNT(*) as c FROM authentication_sessions WHERE revoked = 0 AND expires_at > ?')
      .get(nowIso()) as any).c;
    const unackAlerts = (sqlite.prepare('SELECT COUNT(*) as c FROM security_events WHERE acknowledged = 0').get() as any).c;
    const recentActivities = sqlite
      .prepare('SELECT * FROM owner_audit_logs ORDER BY created_at DESC LIMIT 20')
      .all();
    const securityEvents = sqlite
      .prepare('SELECT * FROM security_events ORDER BY created_at DESC LIMIT 20')
      .all();
    const companies = sqlite.prepare('SELECT * FROM companies ORDER BY created_at DESC').all();
    const superAdmins = sqlite
      .prepare(`
        SELECT sa.id, sa.full_name, sa.email, sa.mobile, sa.country, sa.city, sa.status,
               sa.email_verified, sa.two_factor_enabled, sa.last_login_at, sa.created_at,
               up.permissions_json
        FROM super_admin_accounts sa
        LEFT JOIN user_permissions up ON up.user_id = sa.id
        ORDER BY sa.created_at DESC
      `)
      .all()
      .map((sa: any) => ({
        ...sa,
        role: 'Super Admin',
        permissions: sa.permissions_json ? JSON.parse(sa.permissions_json) : [...CANONICAL_SA_PERMISSIONS],
      }));

    const pendingSaInvites = sqlite
      .prepare("SELECT id, email, full_name, mobile, country, city, status, expires_at, created_at FROM super_admin_invitations WHERE status = 'Pending' ORDER BY created_at DESC")
      .all();

    const companyAdmins = sqlite
      .prepare(`
        SELECT ca.id, ca.company_id, ca.full_name, ca.username, ca.email, ca.mobile,
               ca.designation, ca.status, ca.email_verified, ca.two_factor_enabled,
               ca.last_login_at, ca.created_at, c.name as company_name,
               cp.permissions_json
        FROM company_admin_accounts ca
        LEFT JOIN companies c ON c.id = ca.company_id
        LEFT JOIN company_permissions cp ON cp.company_id = ca.company_id AND cp.subject_id = ca.id
        ORDER BY ca.created_at DESC
      `)
      .all()
      .map((ca: any) => ({
        ...ca,
        permissions: ca.permissions_json ? JSON.parse(ca.permissions_json) : [...CANONICAL_COMPANY_ADMIN_PERMISSIONS],
      }));

    const aiLogsCount = (sqlite.prepare('SELECT COUNT(*) as c FROM ai_usage_logs').get() as any).c;
    const policy = getSystemSetting('security_policy', {});
    const countries = sqlite.prepare('SELECT id, code, name, flag_emoji, currency, headquarters_city, status FROM countries ORDER BY name ASC').all();
    const countryManagers = sqlite
      .prepare(`
        SELECT cm.id, cm.manager_code, cm.country_id, cm.full_name, cm.username, cm.email, cm.mobile,
               cm.designation, cm.status, cm.email_verified, cm.two_factor_enabled, cm.appointed_at,
               cm.last_login_at, cm.created_at,
               c.name as country_name, c.flag_emoji,
               cp.permissions_json
        FROM country_manager_accounts cm
        LEFT JOIN countries c ON c.id = cm.country_id
        LEFT JOIN country_permissions cp ON cp.manager_id = cm.id
        ORDER BY cm.created_at DESC
      `)
      .all()
      .map((cm: any) => ({
        ...cm,
        permissions: cm.permissions_json ? JSON.parse(cm.permissions_json) : [],
      }));
    const countryEscalations = sqlite
      .prepare('SELECT * FROM country_escalation_requests ORDER BY created_at DESC LIMIT 50')
      .all();

    const branches = sqlite
      .prepare(`
        SELECT b.id, b.company_id, b.country_id, b.code, b.name, b.city, b.address, b.phone, b.email,
               b.manager_id, b.manager_name, b.monthly_target_units, b.achieved_units, b.monthly_revenue_pkr, b.status,
               c.name as company_name
        FROM branches b
        LEFT JOIN companies c ON c.id = b.company_id
        ORDER BY b.country_id ASC, b.name ASC
      `)
      .all();

    const branchManagers = sqlite
      .prepare(`
        SELECT bm.id, bm.manager_code, bm.company_id, bm.country_id, bm.branch_id, bm.full_name, bm.username,
               bm.email, bm.mobile, bm.designation, bm.status, bm.email_verified, bm.two_factor_enabled,
               bm.appointed_at, bm.last_login_at, bm.created_at,
               b.name as branch_name, b.code as branch_code, b.city as branch_city,
               c.name as company_name,
               bp.permissions_json
        FROM branch_manager_accounts bm
        LEFT JOIN branches b ON b.id = bm.branch_id
        LEFT JOIN companies c ON c.id = bm.company_id
        LEFT JOIN branch_permissions bp ON bp.manager_id = bm.id
        ORDER BY bm.created_at DESC
      `)
      .all()
      .map((bm: any) => ({
        ...bm,
        permissions: bm.permissions_json ? JSON.parse(bm.permissions_json) : [],
      }));

    const branchEscalations = sqlite
      .prepare(`
        SELECT be.*, b.name as branch_name, b.code as branch_code
        FROM branch_escalations be
        LEFT JOIN branches b ON b.id = be.branch_id
        ORDER BY be.created_at DESC LIMIT 50
      `)
      .all();

    res.json({
      founder: {
        name: 'Intekhab Alam',
        role: 'Founder & CEO',
        accountType: 'Primary Owner',
        accessLevel: 'Global Owner',
      },
      metrics: {
        totalCountries,
        totalCompanies,
        approvedCompanies,
        pendingCompanies,
        totalBranches,
        totalDealerships,
        totalEmployees,
        totalCustomers,
        totalVehicles,
        totalSoldVehicles,
        totalBookings,
        totalServiceJobs,
        totalWarrantyClaims,
        paidRevenueTotal: revenueStats.paidTotal,
        pendingRevenueTotal: revenueStats.pendingTotal,
        totalInvoices: revenueStats.invoiceCount,
        activeSessions,
        unacknowledgedAlerts: unackAlerts,
        aiQueriesLogged: aiLogsCount,
      },
      companies,
      superAdmins,
      pendingSaInvites,
      companyAdmins,
      countries,
      countryManagers,
      countryEscalations,
      branches,
      branchManagers,
      branchEscalations,
      recentActivities,
      securityEvents,
      securityPolicy: policy,
    });
  });

  // Owner directly creates a new Super Admin in super_admin_accounts + sets canonical permissions + 2FA + Email OTP
  router.post('/owner/super-admins', requireFounder, (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const city = String(req.body.city || 'Karachi').trim();
    const country = String(req.body.country || 'PK').trim();
    const permissions = sanitizeSaPermissions(req.body.permissions);

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Full name, email, and mobile are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const saId = `sa_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO super_admin_accounts (
          id, full_name, email, mobile, password_hash, country, city, status,
          email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          authorized_by_founder_id, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 1, ?, ?, ?, ?, ?)
      `)
      .run(
        saId,
        fullName,
        email,
        mobile,
        hashPassword(password),
        country,
        city,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare('INSERT INTO user_permissions (user_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
      .run(saId, JSON.stringify(permissions), req.auth!.userId, now);

    const emailOtp = issueSuperAdminEmailVerifyOtp({ id: saId, email });

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SUPER_ADMIN_CREATED_BY_OWNER',
      module: 'Owner Governance',
      targetId: `${fullName} (${email})`,
      details: `Granted permissions: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Super%20Admin:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      superAdmin: { id: saId, full_name: fullName, email, mobile, role: 'Super Admin', status: 'Pending Verification', permissions },
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Owner issues a secure single-use Super Admin Activation Invite link
  router.post('/owner/super-admins/invite', requireFounder, (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const country = String(req.body.country || 'PK').trim();
    const city = String(req.body.city || 'Karachi').trim();
    const permissions = sanitizeSaPermissions(req.body.permissions);

    if (!fullName || !email) {
      res.status(400).json({ error: 'Full name and email are required to issue a Super Admin invite.' });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const rawToken = generateSecureToken(24);
    const invId = `sainv_${generateSecureToken(6)}`;
    const expiresAt = new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString();

    sqlite
      .prepare(`
        INSERT INTO super_admin_invitations (
          id, token_hash, email, full_name, mobile, country, city, permissions_json,
          invited_by_founder_id, status, expires_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)
      `)
      .run(
        invId,
        sha256(rawToken),
        email,
        fullName,
        mobile || null,
        country,
        city,
        JSON.stringify(permissions),
        req.auth!.userId,
        expiresAt,
        nowIso()
      );

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SUPER_ADMIN_INVITE_ISSUED',
      module: 'Owner Governance',
      targetId: `${fullName} (${email})`,
      details: `Permissions: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    res.status(201).json({
      success: true,
      invitationId: invId,
      inviteToken: rawToken,
      inviteUrl: `/?portal=super-admin&sa-invite=${rawToken}`,
      expiresAt,
      message: 'Secure single-use Super Admin activation invite created.',
    });
  });

  // Owner updates Super Admin permissions or suspends/reactivates them
  router.patch('/owner/super-admins/:id/permissions', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE id = ?').get(id) as any;
    if (!sa) {
      res.status(404).json({ error: 'Super Admin account not found.' });
      return;
    }

    const hasPermsField = Array.isArray(req.body.permissions);
    const permissions = hasPermsField ? sanitizeSaPermissions(req.body.permissions) : [];
    const status: string | undefined = req.body.status;
    const now = nowIso();

    if (hasPermsField) {
      sqlite
        .prepare(`
          INSERT INTO user_permissions (user_id, permissions_json, updated_by, updated_at)
          VALUES (?, ?, ?, ?)
          ON CONFLICT(user_id) DO UPDATE SET
            permissions_json = excluded.permissions_json,
            updated_by = excluded.updated_by,
            updated_at = excluded.updated_at
        `)
        .run(id, JSON.stringify(permissions), req.auth!.userId, now);
    }

    if (status && ['Active', 'Suspended'].includes(status)) {
      sqlite.prepare('UPDATE super_admin_accounts SET status = ?, updated_at = ? WHERE id = ?').run(status, now, id);
      if (status === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(id);
      }
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SUPER_ADMIN_PERMISSIONS_UPDATED',
      module: 'Owner Governance',
      targetId: sa.email,
      details: `Permissions: [${hasPermsField ? permissions.join(', ') : 'unchanged'}] Status: ${status || sa.status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  // Owner provisions a dedicated Company Admin account for an approved company
  router.post('/owner/company-admins', requireFounder, (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const companyId = String(req.body.companyId || '').trim();
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const designation = String(req.body.designation || 'Company Administrator').trim();
    const permissions = sanitizeCompanyAdminPermissions(req.body.permissions);

    if (!companyId || !fullName || !email || !mobile) {
      res.status(400).json({ error: 'Company ID, full name, email, and mobile number are required.' });
      return;
    }
    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(companyId) as any;
    if (!comp) {
      res.status(404).json({ error: 'Target company not found.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists across the platform.' });
      return;
    }

    const caId = `ca_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO company_admin_accounts (
          id, company_id, full_name, username, email, mobile, password_hash, designation,
          status, email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          authorized_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 1, ?, ?, ?, ?, ?)
      `)
      .run(
        caId,
        companyId,
        fullName,
        email.split('@')[0] + '_ca_' + generateNumericOtp(3),
        email,
        mobile,
        hashPassword(password),
        designation,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO company_permissions (id, company_id, subject_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(`cp_${caId}`, companyId, caId, JSON.stringify(permissions), req.auth!.userId, now);

    const emailOtp = issueCompanyAdminEmailVerifyOtp({ id: caId, email });

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMPANY_ADMIN_PROVISIONED_BY_OWNER',
      module: 'Owner Governance',
      targetId: `${fullName} (${email})`,
      companyId,
      details: `Permissions: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    logCompanyActivity({
      companyId,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMPANY_ADMIN_CREATED',
      module: 'Company Governance',
      targetId: email,
      details: `Company Admin authorized by Primary Owner.`,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Company%20Admin:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      companyAdmin: { id: caId, company_id: companyId, full_name: fullName, email, mobile, designation, status: 'Pending Verification', permissions },
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Owner updates Company Admin permissions or suspends/activates them
  router.patch('/owner/company-admins/:id/permissions', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const ca = sqlite.prepare('SELECT * FROM company_admin_accounts WHERE id = ?').get(id) as any;
    if (!ca) {
      res.status(404).json({ error: 'Company Admin account not found.' });
      return;
    }

    const hasPermsField = Array.isArray(req.body.permissions);
    const permissions = hasPermsField ? sanitizeCompanyAdminPermissions(req.body.permissions) : [];
    const status: string | undefined = req.body.status;
    const now = nowIso();

    if (hasPermsField) {
      sqlite
        .prepare(`
          INSERT INTO company_permissions (id, company_id, subject_id, permissions_json, updated_by, updated_at)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(company_id, subject_id) DO UPDATE SET
            permissions_json = excluded.permissions_json,
            updated_by = excluded.updated_by,
            updated_at = excluded.updated_at
        `)
        .run(`cp_${ca.id}`, ca.company_id, ca.id, JSON.stringify(permissions), req.auth!.userId, now);
    }

    if (status && ['Active', 'Suspended'].includes(status)) {
      sqlite.prepare('UPDATE company_admin_accounts SET status = ?, updated_at = ? WHERE id = ?').run(status, now, ca.id);
      if (status === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(ca.id);
      }
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COMPANY_ADMIN_PERMISSIONS_UPDATED',
      module: 'Owner Governance',
      targetId: ca.email,
      companyId: ca.company_id,
      details: `Permissions: [${hasPermsField ? permissions.join(', ') : 'unchanged'}] Status: ${status || ca.status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  // =========================================================================
  // GLOBAL COUNTRY ASSIGNMENT SYSTEM (PRIMARY OWNER GOVERNED)
  // =========================================================================

  // Owner provisions a Country Manager + assigns them to a single country
  router.post('/owner/country-managers', requireFounder, (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const countryId = String(req.body.countryId || '').trim().toUpperCase();
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const designation = String(req.body.designation || 'Country Manager').trim();
    const managerCodeInput = String(req.body.managerCode || '').trim().toUpperCase();
    const permissions = sanitizeCountryManagerPermissions(req.body.permissions);

    if (!countryId || !fullName || !email || !mobile) {
      res.status(400).json({ error: 'Country ID, full name, email, and mobile number are required.' });
      return;
    }

    const countryRow = sqlite.prepare('SELECT * FROM countries WHERE id = ?').get(countryId) as any;
    if (!countryRow) {
      res.status(404).json({ error: 'Target country not found in global registry.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists across the platform.' });
      return;
    }

    const managerCode = managerCodeInput || `CM-${countryId}-${generateNumericOtp(3)}`;
    const codeExists = sqlite.prepare('SELECT id FROM country_manager_accounts WHERE UPPER(manager_code) = ?').get(managerCode);
    if (codeExists) {
      res.status(409).json({ error: `Manager ID "${managerCode}" already exists.` });
      return;
    }

    const cmId = `cm_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO country_manager_accounts (
          id, manager_code, country_id, full_name, username, email, mobile, password_hash, designation,
          status, email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          authorized_by, appointed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 1, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        cmId,
        managerCode,
        countryId,
        fullName,
        email.split('@')[0] + '_cm_' + generateNumericOtp(3),
        email,
        mobile,
        hashPassword(password),
        designation,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        req.auth!.userId,
        now.slice(0, 10),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO country_assignments (
          id, manager_id, country_id, country_name, status, appointed_by, appointment_date, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `ca_assign_${generateSecureToken(6)}`,
        cmId,
        countryId,
        countryRow.name,
        req.auth!.fullName,
        now.slice(0, 10),
        `Assigned by Primary Owner (${req.auth!.fullName})`,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO country_permissions (id, manager_id, country_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(`cp_${cmId}`, cmId, countryId, JSON.stringify(permissions), req.auth!.userId, now);

    const emailOtp = issueCountryManagerEmailVerifyOtp({ id: cmId, email });

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_MANAGER_PROVISIONED_BY_OWNER',
      module: 'Global Country Assignment',
      targetId: `${fullName} (${managerCode} -> ${countryId})`,
      details: `Country: ${countryRow.name}, Permissions: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    logCountryActivity({
      countryId,
      managerId: cmId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_MANAGER_APPOINTED',
      module: 'Global Country Assignment',
      targetId: `${managerCode} (${email})`,
      details: `Appointed Country Manager for ${countryRow.name} by Primary Owner.`,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Country%20Manager:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      countryManager: {
        id: cmId,
        manager_code: managerCode,
        country_id: countryId,
        country_name: countryRow.name,
        full_name: fullName,
        email,
        mobile,
        designation,
        status: 'Pending Verification',
        permissions,
      },
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Owner updates or reassigns a Country Manager's assigned country (audit logged + revokes active sessions)
  router.patch('/owner/country-managers/:id/assign-country', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const newCountryId = String(req.body.countryId || '').trim().toUpperCase();
    const notes = String(req.body.notes || '').trim();
    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE id = ?').get(id) as any;
    if (!cm) {
      res.status(404).json({ error: 'Country Manager account not found.' });
      return;
    }

    const newCountry = sqlite.prepare("SELECT * FROM countries WHERE id = ? AND status = 'Active'").get(newCountryId) as any;
    if (!newCountry) {
      res.status(404).json({ error: 'Target country not found or inactive.' });
      return;
    }

    const prevCountryId = cm.country_id;
    const now = nowIso();

    sqlite
      .prepare("UPDATE country_assignments SET status = 'Reassigned', updated_at = ? WHERE manager_id = ? AND status = 'Active'")
      .run(now, cm.id);

    sqlite
      .prepare(`
        INSERT INTO country_assignments (
          id, manager_id, country_id, country_name, status, appointed_by, appointment_date, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `ca_assign_${generateSecureToken(6)}`,
        cm.id,
        newCountryId,
        newCountry.name,
        req.auth!.fullName,
        now.slice(0, 10),
        notes || `Reassigned from ${prevCountryId} to ${newCountryId} by Primary Owner`,
        now,
        now
      );

    sqlite
      .prepare('UPDATE country_manager_accounts SET country_id = ?, appointed_at = ?, updated_at = ? WHERE id = ?')
      .run(newCountryId, now.slice(0, 10), now, cm.id);
    sqlite
      .prepare('UPDATE country_permissions SET country_id = ?, updated_by = ?, updated_at = ? WHERE manager_id = ?')
      .run(newCountryId, req.auth!.userId, now, cm.id);

    // Revoke existing sessions so jurisdiction switch enforces re-authentication cleanly
    sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'country_manager'").run(cm.id);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_MANAGER_JURISDICTION_CHANGED',
      module: 'Global Country Assignment',
      targetId: `${cm.full_name} (${cm.manager_code})`,
      details: `Country changed from ${prevCountryId} to ${newCountryId} (${newCountry.name}). Active sessions revoked.`,
      ipAddress: getClientIp(req),
    });

    logCountryActivity({
      countryId: newCountryId,
      managerId: cm.id,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_ASSIGNMENT_UPDATED',
      module: 'Global Country Assignment',
      targetId: cm.manager_code,
      details: `Assigned to ${newCountry.name} (previous: ${prevCountryId}).`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, previousCountry: prevCountryId, countryId: newCountryId, countryName: newCountry.name });
  });

  // Owner updates Country Manager permissions or status
  router.patch('/owner/country-managers/:id/permissions', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const cm = sqlite.prepare('SELECT * FROM country_manager_accounts WHERE id = ?').get(id) as any;
    if (!cm) {
      res.status(404).json({ error: 'Country Manager account not found.' });
      return;
    }

    const hasPermsField = Array.isArray(req.body.permissions);
    const permissions = hasPermsField ? sanitizeCountryManagerPermissions(req.body.permissions) : [];
    const status: string | undefined = req.body.status;
    const now = nowIso();

    if (hasPermsField) {
      sqlite
        .prepare(`
          INSERT INTO country_permissions (id, manager_id, country_id, permissions_json, updated_by, updated_at)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(manager_id) DO UPDATE SET
            permissions_json = excluded.permissions_json,
            updated_by = excluded.updated_by,
            updated_at = excluded.updated_at
        `)
        .run(`cp_${cm.id}`, cm.id, cm.country_id, JSON.stringify(permissions), req.auth!.userId, now);
    }

    if (status && ['Active', 'Suspended'].includes(status)) {
      sqlite.prepare('UPDATE country_manager_accounts SET status = ?, updated_at = ? WHERE id = ?').run(status, now, cm.id);
      if (status === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(cm.id);
      }
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'COUNTRY_MANAGER_PERMISSIONS_UPDATED',
      module: 'Global Country Assignment',
      targetId: `${cm.email} (${cm.manager_code})`,
      details: `Permissions: [${hasPermsField ? permissions.join(', ') : 'unchanged'}] Status: ${status || cm.status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  // Owner reviews & approves/rejects Country Manager escalation requests (new branches, sensitive refunds, company requests)
  router.patch('/owner/country-escalations/:id', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const esc = sqlite.prepare('SELECT * FROM country_escalation_requests WHERE id = ?').get(id) as any;
    if (!esc) {
      res.status(404).json({ error: 'Escalation request not found.' });
      return;
    }

    const decision = String(req.body.status || 'Approved');
    const reviewNotes = String(req.body.reviewNotes || '').trim();
    if (!['Approved', 'Rejected'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE country_escalation_requests SET status = ?, reviewed_by = ?, review_notes = ?, updated_at = ? WHERE id = ?')
      .run(decision, req.auth!.fullName, reviewNotes || null, now, id);

    // Apply downstream side-effects when Owner approves
    if (decision === 'Approved' && esc.request_type === 'New Branch Approval' && esc.target_id) {
      const cbr = sqlite.prepare('SELECT * FROM country_branches WHERE id = ?').get(esc.target_id) as any;
      if (cbr) {
        const companyBranchId = cbr.company_branch_id || `br_${generateSecureToken(5)}`;
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO company_branches (
              id, company_id, name, code, country, city, address, manager_id, manager_name,
              phone, email, monthly_target_units, achieved_units, monthly_revenue_pkr, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 'Active', ?, ?)
          `)
          .run(companyBranchId, cbr.company_id, cbr.name, cbr.code, cbr.country_id, cbr.city, cbr.address, cbr.manager_id, cbr.manager_name, cbr.phone, cbr.email, cbr.monthly_target_units, now, now);

        sqlite
          .prepare("UPDATE country_branches SET approval_status = 'Approved', status = 'Active', company_branch_id = ?, approved_by = ?, updated_at = ? WHERE id = ?")
          .run(companyBranchId, req.auth!.fullName, now, cbr.id);
      }
    } else if (decision === 'Rejected' && esc.request_type === 'New Branch Approval' && esc.target_id) {
      sqlite
        .prepare("UPDATE country_branches SET approval_status = 'Rejected', status = 'Inactive', approved_by = ?, updated_at = ? WHERE id = ?")
        .run(req.auth!.fullName, now, esc.target_id);
    } else if (decision === 'Approved' && esc.request_type === 'Financial Refund Approval' && esc.target_id) {
      sqlite
        .prepare("UPDATE payments_invoices SET status = 'Refunded' WHERE id = ?")
        .run(esc.target_id);
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `COUNTRY_ESCALATION_${decision.toUpperCase()}`,
      module: 'Owner Governance',
      targetId: `${esc.request_type}: ${esc.title}`,
      companyId: esc.company_id || null,
      details: reviewNotes || `Escalation ${decision} by Primary Owner.`,
      ipAddress: getClientIp(req),
    });

    logCountryActivity({
      countryId: esc.country_id,
      managerId: esc.manager_id,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `ESCALATION_${decision.toUpperCase()}`,
      module: 'Higher Approval Governance',
      targetId: esc.id,
      details: `${esc.title} — ${decision}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, id, status: decision });
  });

  // =========================================================================
  // BRANCH MANAGER PROVISIONING, ASSIGNMENT & ESCALATION GOVERNANCE (OWNER ONLY)
  // =========================================================================

  router.post('/owner/branch-managers', requireFounder, (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const branchId = String(req.body.branchId || '').trim();
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const designation = String(req.body.designation || 'Branch Manager').trim();
    const managerCodeInput = String(req.body.managerCode || '').trim().toUpperCase();
    const permissions = sanitizeBranchManagerPermissions(req.body.permissions);

    if (!branchId || !fullName || !email || !mobile) {
      res.status(400).json({ error: 'Branch ID, full name, email, and mobile number are required.' });
      return;
    }

    const branchRow = sqlite.prepare("SELECT * FROM branches WHERE id = ? AND status = 'Active'").get(branchId) as any;
    if (!branchRow) {
      res.status(404).json({ error: 'Target active branch not found.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (conflict) {
      res.status(409).json({ error: 'An account with this email already exists across the platform.' });
      return;
    }

    const managerCode = managerCodeInput || `BM-${branchRow.country_id}-${generateNumericOtp(3)}`;
    const codeExists = sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE UPPER(manager_code) = ?').get(managerCode);
    if (codeExists) {
      res.status(409).json({ error: `Manager ID "${managerCode}" already exists.` });
      return;
    }

    const bmId = `bm_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO branch_manager_accounts (
          id, manager_code, company_id, country_id, branch_id, full_name, username, email, mobile,
          password_hash, designation, status, email_verified, two_factor_enabled, two_factor_secret,
          recovery_codes_json, authorized_by, appointed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 1, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        bmId,
        managerCode,
        branchRow.company_id,
        branchRow.country_id,
        branchRow.id,
        fullName,
        email.split('@')[0] + '_bm_' + generateNumericOtp(3),
        email,
        mobile,
        hashPassword(password),
        designation,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        req.auth!.userId,
        now.slice(0, 10),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO branch_assignments (
          id, manager_id, company_id, country_id, branch_id, branch_name, status, appointed_by, appointment_date, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `ba_${generateSecureToken(6)}`,
        bmId,
        branchRow.company_id,
        branchRow.country_id,
        branchRow.id,
        branchRow.name,
        req.auth!.fullName,
        now.slice(0, 10),
        `Assigned by Primary Owner (${req.auth!.fullName})`,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO branch_permissions (id, manager_id, branch_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `)
      .run(`bp_${bmId}`, bmId, branchRow.id, JSON.stringify(permissions), req.auth!.userId, now);

    sqlite.prepare('UPDATE branches SET manager_id = ?, manager_name = ?, updated_at = ? WHERE id = ?').run(bmId, fullName, now, branchRow.id);

    const emailOtp = issueBranchManagerEmailVerifyOtp({ id: bmId, email });

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'BRANCH_MANAGER_PROVISIONED_BY_OWNER',
      module: 'Branch Assignment Governance',
      targetId: `${fullName} (${managerCode} -> ${branchRow.code})`,
      companyId: branchRow.company_id,
      details: `Branch: ${branchRow.name} (${branchRow.id}), Permissions: ${permissions.join(', ')}`,
      ipAddress: ip,
    });

    logBranchActivity({
      branchId: branchRow.id,
      companyId: branchRow.company_id,
      countryId: branchRow.country_id,
      managerId: bmId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'BRANCH_MANAGER_APPOINTED',
      module: 'Branch Assignment Governance',
      targetId: `${managerCode} (${email})`,
      details: `Appointed Branch Manager for ${branchRow.name} by Primary Owner.`,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Branch%20Manager:${encodeURIComponent(email)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      branchManager: {
        id: bmId,
        manager_code: managerCode,
        branch_id: branchRow.id,
        branch_name: branchRow.name,
        company_id: branchRow.company_id,
        country_id: branchRow.country_id,
        full_name: fullName,
        email,
        mobile,
        designation,
        status: 'Pending Verification',
        permissions,
      },
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  router.patch('/owner/branch-managers/:id/assign-branch', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const newBranchId = String(req.body.branchId || '').trim();
    const notes = String(req.body.notes || '').trim();
    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE id = ?').get(id) as any;
    if (!bm) {
      res.status(404).json({ error: 'Branch Manager account not found.' });
      return;
    }

    const newBranch = sqlite.prepare("SELECT * FROM branches WHERE id = ? AND status = 'Active'").get(newBranchId) as any;
    if (!newBranch) {
      res.status(404).json({ error: 'Target active branch not found.' });
      return;
    }

    const prevBranchId = bm.branch_id;
    const now = nowIso();

    sqlite
      .prepare("UPDATE branch_assignments SET status = 'Reassigned', updated_at = ? WHERE manager_id = ? AND status = 'Active'")
      .run(now, bm.id);

    sqlite
      .prepare(`
        INSERT INTO branch_assignments (
          id, manager_id, company_id, country_id, branch_id, branch_name, status, appointed_by, appointment_date, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?, ?, ?)
      `)
      .run(
        `ba_${generateSecureToken(6)}`,
        bm.id,
        newBranch.company_id,
        newBranch.country_id,
        newBranch.id,
        newBranch.name,
        req.auth!.fullName,
        now.slice(0, 10),
        notes || `Reassigned from ${prevBranchId} to ${newBranch.id} by Primary Owner`,
        now,
        now
      );

    sqlite
      .prepare('UPDATE branch_manager_accounts SET branch_id = ?, company_id = ?, country_id = ?, appointed_at = ?, updated_at = ? WHERE id = ?')
      .run(newBranch.id, newBranch.company_id, newBranch.country_id, now.slice(0, 10), now, bm.id);

    sqlite
      .prepare('UPDATE branch_permissions SET branch_id = ?, updated_by = ?, updated_at = ? WHERE manager_id = ?')
      .run(newBranch.id, req.auth!.userId, now, bm.id);

    sqlite.prepare('UPDATE branches SET manager_id = ?, manager_name = ?, updated_at = ? WHERE id = ?').run(bm.id, bm.full_name, now, newBranch.id);

    // Revoke ALL active sessions for this Branch Manager immediately
    sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'branch_manager'").run(bm.id);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'BRANCH_MANAGER_ASSIGNMENT_CHANGED',
      module: 'Branch Assignment Governance',
      targetId: `${bm.full_name} (${bm.manager_code})`,
      companyId: newBranch.company_id,
      details: `Branch changed from ${prevBranchId} to ${newBranch.id} (${newBranch.name}). Active sessions revoked.`,
      ipAddress: getClientIp(req),
    });

    logBranchActivity({
      branchId: newBranch.id,
      companyId: newBranch.company_id,
      countryId: newBranch.country_id,
      managerId: bm.id,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'BRANCH_ASSIGNMENT_UPDATED',
      module: 'Branch Assignment Governance',
      targetId: bm.manager_code,
      details: `Assigned to ${newBranch.name} (${newBranch.code}). Previous branch: ${prevBranchId}.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      previousBranchId: prevBranchId,
      branchId: newBranch.id,
      branchName: newBranch.name,
      branchCode: newBranch.code,
    });
  });

  router.patch('/owner/branch-managers/:id/permissions', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const bm = sqlite.prepare('SELECT * FROM branch_manager_accounts WHERE id = ?').get(id) as any;
    if (!bm) {
      res.status(404).json({ error: 'Branch Manager account not found.' });
      return;
    }

    const hasPermsField = Array.isArray(req.body.permissions);
    const permissions = hasPermsField ? sanitizeBranchManagerPermissions(req.body.permissions) : [];
    const status: string | undefined = req.body.status;
    const now = nowIso();

    if (hasPermsField) {
      sqlite
        .prepare(`
          INSERT INTO branch_permissions (id, manager_id, branch_id, permissions_json, updated_by, updated_at)
          VALUES (?, ?, ?, ?, ?, ?)
          ON CONFLICT(manager_id) DO UPDATE SET
            permissions_json = excluded.permissions_json,
            updated_by = excluded.updated_by,
            updated_at = excluded.updated_at
        `)
        .run(`bp_${bm.id}`, bm.id, bm.branch_id, JSON.stringify(permissions), req.auth!.userId, now);
    }

    if (status && ['Active', 'Suspended'].includes(status)) {
      sqlite.prepare('UPDATE branch_manager_accounts SET status = ?, updated_at = ? WHERE id = ?').run(status, now, bm.id);
      if (status === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(bm.id);
      }
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'BRANCH_MANAGER_PERMISSIONS_UPDATED',
      module: 'Branch Assignment Governance',
      targetId: `${bm.email} (${bm.manager_code})`,
      companyId: bm.company_id,
      details: `Permissions: [${hasPermsField ? permissions.join(', ') : 'unchanged'}] Status: ${status || bm.status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true });
  });

  router.patch('/owner/branch-escalations/:id', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const esc = sqlite.prepare('SELECT * FROM branch_escalations WHERE id = ?').get(id) as any;
    if (!esc) {
      res.status(404).json({ error: 'Branch escalation request not found.' });
      return;
    }

    const decision = String(req.body.status || 'Approved');
    const reviewNotes = String(req.body.reviewNotes || '').trim();
    if (!['Approved', 'Rejected'].includes(decision)) {
      res.status(400).json({ error: 'Decision must be Approved or Rejected.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE branch_escalations SET status = ?, reviewed_by = ?, review_notes = ?, updated_at = ? WHERE id = ?')
      .run(decision, req.auth!.fullName, reviewNotes || null, now, id);

    if (decision === 'Approved' && esc.request_type === 'Dealer Approval Request' && esc.target_id) {
      sqlite.prepare("UPDATE dealerships SET status = 'Approved' WHERE id = ?").run(esc.target_id);
    } else if (decision === 'Rejected' && esc.request_type === 'Dealer Approval Request' && esc.target_id) {
      sqlite.prepare("UPDATE dealerships SET status = 'Rejected' WHERE id = ?").run(esc.target_id);
    } else if (decision === 'Approved' && esc.request_type === 'Vehicle Transfer Request' && esc.target_id) {
      const binv = sqlite.prepare('SELECT * FROM branch_inventory WHERE vehicle_id = ?').get(esc.target_id) as any;
      if (binv && binv.transfer_target_branch_id) {
        sqlite.prepare("UPDATE vehicles SET branch_id = ?, delivery_status = 'In Transit' WHERE id = ?").run(binv.transfer_target_branch_id, binv.vehicle_id);
        sqlite.prepare("UPDATE branch_inventory SET branch_id = ?, stock_state = 'In Transit', transfer_request_status = 'Approved', updated_by = ?, updated_at = ? WHERE vehicle_id = ?").run(binv.transfer_target_branch_id, req.auth!.fullName, now, binv.vehicle_id);
      }
    } else if (decision === 'Rejected' && esc.request_type === 'Vehicle Transfer Request' && esc.target_id) {
      sqlite.prepare("UPDATE branch_inventory SET transfer_request_status = 'Rejected', updated_by = ?, updated_at = ? WHERE vehicle_id = ?").run(req.auth!.fullName, now, esc.target_id);
    } else if (decision === 'Approved' && esc.request_type === 'Financial Refund Approval' && esc.target_id) {
      sqlite.prepare("UPDATE payments_invoices SET status = 'Refunded' WHERE id = ?").run(esc.target_id);
      sqlite.prepare("UPDATE branch_sales SET payment_status = 'Refunded', updated_at = ? WHERE invoice_id = ?").run(now, esc.target_id);
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `BRANCH_ESCALATION_${decision.toUpperCase()}`,
      module: 'Owner Governance',
      targetId: `${esc.request_type}: ${esc.title}`,
      companyId: esc.company_id || null,
      details: reviewNotes || `Branch escalation ${decision} by Primary Owner.`,
      ipAddress: getClientIp(req),
    });

    logBranchActivity({
      branchId: esc.branch_id,
      companyId: esc.company_id,
      countryId: esc.country_id,
      managerId: esc.manager_id,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `ESCALATION_${decision.toUpperCase()}`,
      module: 'Higher Approval Governance',
      targetId: esc.id,
      details: `${esc.title} — ${decision}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, id, status: decision });
  });

  // Owner approves/rejects/suspends a company registration
  router.patch('/owner/companies/:id/approve', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const decision = String(req.body.status || 'Approved');
    const reason = String(req.body.reason || '');

    if (!['Approved', 'Rejected', 'Suspended'].includes(decision)) {
      res.status(400).json({ error: 'Invalid company status decision.' });
      return;
    }

    const comp = sqlite.prepare('SELECT * FROM companies WHERE id = ?').get(id) as any;
    if (!comp) {
      res.status(404).json({ error: 'Company record not found.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare('UPDATE companies SET status = ?, approved_by = ?, approved_at = ?, rejection_reason = ? WHERE id = ?')
      .run(decision, req.auth!.fullName, now, reason || null, id);

    if (decision === 'Approved') {
      sqlite
        .prepare("UPDATE company_admin_accounts SET status = CASE WHEN email_verified = 1 THEN 'Active' ELSE 'Pending Verification' END, updated_at = ? WHERE company_id = ?")
        .run(now, id);
      sqlite
        .prepare("UPDATE users SET status = 'Active', email_verified = 1, updated_at = ? WHERE company_id = ? AND role = 'Company Admin'")
        .run(now, id);
      sqlite
        .prepare("UPDATE country_company_relationships SET operational_status = 'Active', updated_at = ? WHERE company_id = ?")
        .run(now, id);
    } else {
      sqlite
        .prepare("UPDATE company_admin_accounts SET status = 'Suspended', updated_at = ? WHERE company_id = ?")
        .run(now, id);
      sqlite
        .prepare("UPDATE users SET status = 'Suspended', updated_at = ? WHERE company_id = ? AND role != 'Customer'")
        .run(now, id);
      sqlite
        .prepare('UPDATE country_company_relationships SET operational_status = ?, updated_at = ? WHERE company_id = ?')
        .run(decision, now, id);
      sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE company_id = ?').run(id);
    }

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `COMPANY_${decision.toUpperCase()}`,
      module: 'Company Governance',
      targetId: `${comp.name} (${comp.id})`,
      companyId: comp.id,
      details: reason || `Company status changed to ${decision}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, companyId: id, status: decision });
  });

  router.get('/owner/security-events', requireFounder, (_req: Request, res: Response) => {
    const events = sqlite.prepare('SELECT * FROM security_events ORDER BY created_at DESC LIMIT 100').all();
    const loginHistory = sqlite.prepare('SELECT * FROM login_history ORDER BY created_at DESC LIMIT 100').all();
    const sessions = sqlite
      .prepare('SELECT id, user_id, subject_type, company_id, role, ip_address, device_label, expires_at, last_activity_at, created_at FROM authentication_sessions WHERE revoked = 0 AND expires_at > ? ORDER BY last_activity_at DESC')
      .all(nowIso());
    res.json({ events, loginHistory, activeSessions: sessions });
  });

  router.patch('/owner/security-events/:id/ack', requireFounder, (req: Request, res: Response) => {
    sqlite.prepare('UPDATE security_events SET acknowledged = 1 WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  router.get('/owner/audit-logs', requireFounder, (_req: Request, res: Response) => {
    const logs = sqlite.prepare('SELECT * FROM owner_audit_logs ORDER BY created_at DESC LIMIT 200').all();
    res.json({ logs });
  });

  router.get('/owner/settings', requireFounder, (_req: Request, res: Response) => {
    res.json({
      securityPolicy: getSystemSetting('security_policy', {}),
      aiConfig: getSystemSetting('ai_config', {}),
    });
  });

  router.put('/owner/settings', requireFounder, (req: Request, res: Response) => {
    const current = getSystemSetting('security_policy', {});
    const updated = { ...current, ...(req.body.securityPolicy || {}) };
    setSystemSetting('security_policy', updated, req.auth!.userId);
    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SYSTEM_SECURITY_POLICY_UPDATED',
      module: 'Owner Settings',
      details: JSON.stringify(updated),
      ipAddress: getClientIp(req),
    });
    res.json({ success: true, securityPolicy: updated });
  });

  router.get('/owner/backup/export', requireFounder, (req: Request, res: Response) => {
    const usersSanitized = sqlite
      .prepare('SELECT id, company_id, username, full_name, email, mobile, role, country, city, dealership_id, status, email_verified, created_at FROM users')
      .all();
    const superAdminsSanitized = sqlite
      .prepare('SELECT id, full_name, email, mobile, country, city, status, email_verified, authorized_by_founder_id, created_at FROM super_admin_accounts')
      .all();
    const backup = {
      exportedAt: nowIso(),
      exportedBy: req.auth!.fullName,
      platform: 'BYD PAKISTAN 360',
      companies: sqlite.prepare('SELECT * FROM companies').all(),
      dealerships: sqlite.prepare('SELECT * FROM dealerships').all(),
      superAdmins: superAdminsSanitized,
      users: usersSanitized,
      vehicles: sqlite.prepare('SELECT * FROM vehicles').all(),
      bookings: sqlite.prepare('SELECT * FROM bookings').all(),
      service_jobs: sqlite.prepare('SELECT * FROM service_jobs').all(),
      warranty_claims: sqlite.prepare('SELECT * FROM warranty_claims').all(),
      payments_invoices: sqlite.prepare('SELECT * FROM payments_invoices').all(),
      audit_logs: sqlite.prepare('SELECT * FROM owner_audit_logs ORDER BY created_at DESC LIMIT 500').all(),
    };

    const policy = getSystemSetting('security_policy', {});
    setSystemSetting('security_policy', { ...policy, lastBackupAt: nowIso() }, req.auth!.userId);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'OWNER_DATABASE_BACKUP_EXPORTED',
      module: 'Database Backup',
      ipAddress: getClientIp(req),
    });

    res.json(backup);
  });

  // =========================================================================
  // 4. STANDARD ENTERPRISE & CUSTOMER AUTHENTICATION
  // =========================================================================

  router.get('/auth/me', (req: Request, res: Response) => {
    if (!req.auth) {
      res.json({ authenticated: false, user: null });
      return;
    }
    res.json({ authenticated: true, user: req.auth });
  });

  router.post('/auth/login', rateLimitAuth('standard_login', 30, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Email/mobile and password are required.' });
      return;
    }

    // Strictly prevent Owner/Founder login via the standard portal
    const isFounderEmail = sqlite
      .prepare("SELECT id FROM founder_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isFounderEmail) {
      res.status(403).json({
        error: 'Primary Owner authentication is isolated. Please sign in through the private Founder / Owner Portal.',
      });
      return;
    }

    // Strictly prevent Super Admin login via the standard public portal
    const isSuperAdmin = sqlite
      .prepare("SELECT id FROM super_admin_accounts WHERE LOWER(email) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier);
    if (isSuperAdmin) {
      res.status(403).json({
        error: 'Super Admin authentication is isolated. Please sign in through the dedicated Super Admin Portal.',
      });
      return;
    }

    // Strictly prevent Company Admin login via the standard public portal
    const isCompanyAdmin = sqlite
      .prepare(`
        SELECT id FROM company_admin_accounts
        WHERE LOWER(email) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier);
    if (isCompanyAdmin) {
      res.status(403).json({
        error: 'Company Admin authentication is isolated. Please sign in through the dedicated Company Admin Portal.',
      });
      return;
    }

    // Strictly prevent Country Manager login via the standard public portal
    const isCountryManager = sqlite
      .prepare(`
        SELECT id FROM country_manager_accounts
        WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier);
    if (isCountryManager) {
      res.status(403).json({
        error: 'Country Manager authentication is isolated. Please sign in through the dedicated Country Manager Portal.',
      });
      return;
    }

    // Strictly prevent Branch Manager login via the standard public portal
    const isBranchManager = sqlite
      .prepare(`
        SELECT id FROM branch_manager_accounts
        WHERE LOWER(email) = ? OR LOWER(manager_code) = ? OR LOWER(username) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier, identifier);
    if (isBranchManager) {
      res.status(403).json({
        error: 'Branch Manager authentication is isolated. Please sign in through the dedicated Branch Manager Portal.',
      });
      return;
    }

    // Isolate dedicated corporate employees (non-Dealership roles) into the dedicated Employee Portal
    const isolatedEmp = sqlite
      .prepare(`
        SELECT id, employee_code, job_position FROM employee_accounts
        WHERE (LOWER(email) = ? OR LOWER(employee_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', ''))
          AND job_position NOT IN ('Dealership Manager', 'Dealership Staff', 'Dealer Owner', 'Dealer Manager')
      `)
      .get(identifier, identifier, identifier, identifier) as any;
    if (isolatedEmp) {
      res.status(403).json({
        error: `Employee account (${isolatedEmp.employee_code}) authentication is isolated. Please sign in through the dedicated Employee Login Portal.`,
      });
      return;
    }

    const isDealerAccount = sqlite
      .prepare("SELECT id, dealer_code FROM dealer_accounts WHERE LOWER(email) = ? OR LOWER(dealer_code) = ? OR LOWER(COALESCE(username, '')) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier, identifier) as any;
    if (isDealerAccount) {
      res.status(403).json({
        error: `Dealer account (${isDealerAccount.dealer_code}) authentication is isolated. Please sign in through the dedicated Dealer Login Portal.`,
      });
      return;
    }

    const isCustomerAccount = sqlite
      .prepare("SELECT id, customer_code FROM customer_accounts WHERE LOWER(email) = ? OR LOWER(customer_code) = ? OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')")
      .get(identifier, identifier, identifier) as any;
    if (isCustomerAccount) {
      res.status(403).json({
        error: `Customer account (${isCustomerAccount.customer_code}) authentication is isolated. Please sign in through the dedicated Customer Login Portal.`,
      });
      return;
    }

    const user = sqlite
      .prepare(`
        SELECT * FROM users
        WHERE LOWER(email) = ?
           OR LOWER(username) = ?
           OR REPLACE(mobile, ' ', '') = REPLACE(?, ' ', '')
      `)
      .get(identifier, identifier, identifier) as any;

    if (user && user.role === 'Company Admin') {
      res.status(403).json({
        error: 'Company Admin authentication is isolated. Please sign in through the dedicated Company Admin Portal.',
      });
      return;
    }
    if (user && user.role === 'Customer') {
      res.status(403).json({
        error: 'Customer authentication is isolated. Please sign in through the dedicated Customer Login Portal.',
      });
      return;
    }

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!user) {
      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, NULL, 'user', ?, 0, ?, ?, ?, 0, ?)")
        .run(`lh_${generateSecureToken(6)}`, identifier, 'Account not found', ip, ua, nowIso());
      res.status(401).json({ error: 'Invalid credentials.' });
      return;
    }

    if (user.locked_until && new Date(user.locked_until).getTime() > Date.now()) {
      res.status(423).json({ error: `Account temporarily locked due to failed login attempts until ${user.locked_until}.` });
      return;
    }

    if (!verifyPassword(password, user.password_hash)) {
      const nextFails = (user.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite
        .prepare('UPDATE users SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), user.id);

      sqlite
        .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, failure_reason, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'user', ?, ?, ?, 0, ?, ?, ?, ?, ?)")
        .run(`lh_${generateSecureToken(6)}`, user.id, identifier, user.role, user.company_id, 'Invalid password', ip, ua, shouldLock ? 1 : 0, nowIso());

      if (shouldLock) {
        logSecurityEvent({
          severity: 'WARNING',
          eventType: 'USER_ACCOUNT_LOCKED',
          userId: user.id,
          identifier: user.email,
          companyId: user.company_id,
          details: `Account locked after ${nextFails} failed password attempts.`,
          ipAddress: ip,
        });
      }

      res.status(401).json({
        error: shouldLock ? 'Account locked due to too many failed attempts.' : 'Invalid credentials.',
      });
      return;
    }

    if (user.status !== 'Active') {
      res.status(403).json({
        error:
          user.status === 'Pending Verification'
            ? 'Your account or company registration is still pending verification/Owner approval.'
            : 'This account has been suspended by an administrator.',
      });
      return;
    }

    if (user.company_id && user.role !== 'Customer') {
      const comp = sqlite.prepare('SELECT name, status FROM companies WHERE id = ?').get(user.company_id) as any;
      if (comp && comp.status !== 'Approved') {
        res.status(403).json({
          error: `Company workspace "${comp.name}" is currently "${comp.status}". Owner approval is required before signing in.`,
        });
        return;
      }
    }

    sqlite
      .prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = ?, updated_at = ? WHERE id = ?')
      .run(nowIso(), nowIso(), user.id);

    sqlite
      .prepare("INSERT INTO login_history (id, user_id, subject_type, identifier, role, company_id, success, ip_address, user_agent, suspicious, created_at) VALUES (?, ?, 'user', ?, ?, ?, 1, ?, ?, 0, ?)")
      .run(`lh_${generateSecureToken(6)}`, user.id, user.email, user.role, user.company_id, ip, ua, nowIso());

    logOwnerAudit({
      actorId: user.id,
      actorName: user.full_name,
      actorRole: user.role,
      action: 'USER_LOGIN_SUCCESS',
      module: 'Authentication',
      targetId: user.email,
      companyId: user.company_id,
      ipAddress: ip,
    });

    const session = createSession({
      userId: user.id,
      subjectType: 'user',
      companyId: user.company_id || null,
      role: user.role,
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: user.id,
        companyId: user.company_id,
        name: user.full_name,
        fullName: user.full_name,
        email: user.email,
        phone: user.mobile,
        role: user.role,
        country: user.country,
        city: user.city,
        dealershipId: user.dealership_id,
        emailVerified: Boolean(user.email_verified),
        permissions: resolveUserPermissions(user.id, user.role),
        subjectType: 'user',
      },
    });
  });

  // Public Customer Registration
  router.post('/auth/register-customer', rateLimitAuth('std_register_customer', 15, 60_000), async (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const password = String(req.body.password || '');
    const country = String(req.body.country || 'PK').trim().toUpperCase();
    const city = String(req.body.city || 'Karachi').trim();
    const cnicOrId = String(req.body.cnicOrId || '').trim();
    const companyId = String(req.body.companyId || 'comp_byd_pk').trim();
    const termsAccepted = req.body.termsAccepted === true || req.body.termsAccepted === 'true';
    const privacyAccepted = req.body.privacyAccepted === true || req.body.privacyAccepted === 'true';

    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Full name, email, and mobile number are required.' });
      return;
    }
    if (!termsAccepted || !privacyAccepted) {
      res.status(400).json({ error: 'You must accept the Terms of Service and Privacy Policy to register.' });
      return;
    }
    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const normMobile = normalizePhone(mobile);
    const exists =
      sqlite.prepare('SELECT id FROM user_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM customer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (exists) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const phoneConflict = sqlite
      .prepare('SELECT id FROM user_accounts WHERE verified_phone = ? AND mobile_verified = 1')
      .get(normMobile);
    if (phoneConflict) {
      res.status(409).json({ error: 'This mobile number is already verified on another account.' });
      return;
    }

    const userId = `usr_cust_${generateSecureToken(6)}`;
    const now = nowIso();
    const otpCode = generateNumericOtp(6);
    const verificationToken = generateSecureToken(32);
    const otpExpires = new Date(Date.now() + 30 * 60 * 1000).toISOString();

    sqlite.transaction(() => {
      sqlite
        .prepare(`
          INSERT INTO users (
            id, company_id, username, full_name, email, mobile, password_hash, role,
            country, city, cnic_or_id, status, email_verified, mobile_verified,
            terms_accepted, terms_accepted_at, privacy_accepted, privacy_accepted_at,
            created_by, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Customer', ?, ?, ?, 'Pending Verification', 0, 0, 1, ?, 1, ?, 'self_registration', ?, ?)
        `)
        .run(
          userId,
          companyId,
          email.split('@')[0] + '_' + generateNumericOtp(3),
          fullName,
          email,
          mobile,
          hashPassword(password),
          country,
          city,
          cnicOrId || null,
          now,
          now,
          now,
          now
        );

      sqlite
        .prepare(`
          INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
          VALUES (?, ?, 'email_verify', ?, ?, 'user', ?, 0, ?)
        `)
        .run(`otp_${generateSecureToken(6)}`, email, sha256(otpCode), userId, otpExpires, now);

      sqlite
        .prepare(`
          INSERT INTO email_verification_tokens (id, user_id, subject_type, email, token_hash, expires_at, created_ip, created_at)
          VALUES (?, ?, 'user', ?, ?, ?, ?, ?)
        `)
        .run(`evt_${generateSecureToken(6)}`, userId, email, sha256(verificationToken), otpExpires, ip, now);
    })();
    syncUnifiedSecurityRegistry();

    const dispatchRes = await dispatchVerificationEmail({
      to: email,
      subject: 'BYD PAKISTAN 360 — Verify Your Email',
      text: `Verify your BYD PAKISTAN 360 account with code ${otpCode} or verification token ${verificationToken}.`,
    });

    logOwnerAudit({
      actorId: userId,
      actorName: fullName,
      actorRole: 'Customer',
      action: 'CUSTOMER_SELF_REGISTERED',
      module: 'Customer Onboarding',
      targetId: email,
      companyId,
      ipAddress: ip,
    });

    logSecurityAudit({
      actorId: userId,
      actorName: fullName,
      actorRole: 'Customer',
      targetUserId: userId,
      companyId,
      countryId: country,
      action: 'STANDARD_CUSTOMER_REGISTERED',
      category: 'Registration & Verification',
      details: `Registered ${email}; termsAcceptedAt=${now}; privacyAcceptedAt=${now}`,
      ipAddress: ip,
    });

    res.status(201).json({
      success: true,
      requiresEmailVerification: true,
      email,
      message: 'Customer account created. Verify your email with the 6-digit verification code or verification token to activate login.',
      verificationOutbox:
        dispatchRes.mode === 'dev_outbox'
          ? {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: otpCode,
              verificationToken,
            }
          : undefined,
    });
  });

  // Verify Email / OTP -> activates Customer account (never falsely sets mobile_verified!)
  router.post('/auth/verify-email', (req: Request, res: Response) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();
    if (!email || !code) {
      res.status(400).json({ error: 'Email and verification code are required.' });
      return;
    }

    const otpRow = sqlite
      .prepare(`
        SELECT * FROM otp_verifications
        WHERE LOWER(identifier) = ? AND purpose = 'email_verify' AND used_at IS NULL
        ORDER BY created_at DESC LIMIT 1
      `)
      .get(email) as any;

    if (!otpRow || new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Verification code expired or not found.' });
      return;
    }

    if (otpRow.code_hash !== sha256(code)) {
      const nextAttempts = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAttempts, otpRow.id);
      if (nextAttempts >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(400).json({ error: 'Incorrect verification code.' });
      return;
    }

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
      sqlite.prepare('UPDATE email_verification_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL').run(now, otpRow.subject_id);
      sqlite
        .prepare("UPDATE users SET status = 'Active', email_verified = 1, updated_at = ? WHERE id = ?")
        .run(now, otpRow.subject_id);
    })();
    syncUnifiedSecurityRegistry();

    res.json({ success: true, message: 'Email verified and customer account activated. You may now sign in.' });
  });

  // Independent Company Registration (awaits Owner approval)
  router.post('/auth/register-company', (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const name = String(req.body.companyName || '').trim();
    const country = String(req.body.country || 'PK').trim();
    const city = String(req.body.city || '').trim();
    const officialEmail = String(req.body.officialEmail || '').trim().toLowerCase();
    const phone = String(req.body.phone || '').trim();
    const address = String(req.body.address || '').trim();
    const registrationDetails = String(req.body.registrationDetails || '').trim();
    const authorizedRep = String(req.body.authorizedRep || '').trim();
    const adminPassword = String(req.body.adminPassword || '');

    if (!name || !city || !officialEmail || !phone || !address || !registrationDetails || !authorizedRep) {
      res.status(400).json({ error: 'All company registration fields and authorized representative details are required.' });
      return;
    }

    const strength = validatePasswordStrength(adminPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const conflict =
      sqlite.prepare('SELECT id FROM companies WHERE LOWER(official_email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(officialEmail) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(officialEmail);
    if (conflict) {
      res.status(409).json({ error: 'A company or account with this official email already exists.' });
      return;
    }

    const companyId = `comp_${generateSecureToken(6)}`;
    const caId = `ca_${generateSecureToken(6)}`;
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () =>
      `${generateNumericOtp(4)}-${generateNumericOtp(4)}`
    );
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO companies (
          id, name, country, city, official_email, phone, address, registration_details,
          authorized_rep, status, ai_enabled, ai_daily_limit, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Approval', 1, 250, ?)
      `)
      .run(companyId, name, country, city, officialEmail, phone, address, registrationDetails, authorizedRep, now);

    sqlite
      .prepare(`
        INSERT INTO company_admin_accounts (
          id, company_id, full_name, username, email, mobile, password_hash, designation,
          status, email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          authorized_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Managing Director & Company Admin', 'Pending Verification', 0, 1, ?, ?, 'company_registration', ?, ?)
      `)
      .run(
        caId,
        companyId,
        authorizedRep,
        officialEmail.split('@')[0] + '_ca_' + generateNumericOtp(3),
        officialEmail,
        phone,
        hashPassword(adminPassword),
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO company_permissions (id, company_id, subject_id, permissions_json, updated_by, updated_at)
        VALUES (?, ?, ?, ?, 'company_registration', ?)
      `)
      .run(`cp_${caId}`, companyId, caId, JSON.stringify([...CANONICAL_COMPANY_ADMIN_PERMISSIONS]), now);

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO country_company_relationships (
          id, country_id, company_id, relationship_type, operational_status, performance_rating, notes, updated_at
        ) VALUES (?, ?, ?, 'Authorized National Partner', 'Pending Approval', 90.0, 'Registered company awaiting approval', ?)
      `)
      .run(`ccr_${country}_${companyId}`, country, companyId, now);

    const emailOtp = issueCompanyAdminEmailVerifyOtp({ id: caId, email: officialEmail });

    logOwnerAudit({
      actorId: caId,
      actorName: authorizedRep,
      actorRole: 'Company Admin',
      action: 'COMPANY_REGISTRATION_SUBMITTED',
      module: 'Company Onboarding',
      targetId: `${name} (${companyId})`,
      companyId,
      ipAddress: ip,
    });

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Company%20Admin:${encodeURIComponent(officialEmail)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    res.status(201).json({
      success: true,
      companyId,
      companyAdminId: caId,
      status: 'Pending Approval',
      requiresEmailVerification: true,
      message: 'Company registration submitted. Verify your official email OTP and await Primary Owner approval to sign into the dedicated Company Admin Portal.',
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Employee Invitation Lookup & Activation
  router.get('/auth/invite/:token', (req: Request, res: Response) => {
    const tokenHash = sha256(String(req.params.token || ''));
    const inv = sqlite
      .prepare(`
        SELECT i.*, c.name as company_name
        FROM invitations i
        JOIN companies c ON c.id = i.company_id
        WHERE i.token_hash = ?
      `)
      .get(tokenHash) as any;

    if (!inv || inv.status !== 'Pending' || new Date(inv.expires_at).getTime() <= Date.now()) {
      res.status(404).json({ error: 'Invitation link is invalid or has expired.' });
      return;
    }

    res.json({
      valid: true,
      fullName: inv.full_name,
      email: inv.email,
      role: inv.role,
      companyName: inv.company_name,
      city: inv.city,
      expiresAt: inv.expires_at,
    });
  });

  router.post('/auth/accept-invite', (req: Request, res: Response) => {
    const token = String(req.body.token || '');
    const password = String(req.body.password || '');
    const mobile = String(req.body.mobile || '').trim();

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const tokenHash = sha256(token);
    const inv = sqlite.prepare("SELECT * FROM invitations WHERE token_hash = ? AND status = 'Pending'").get(tokenHash) as any;
    if (!inv || new Date(inv.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Invitation token is invalid or expired.' });
      return;
    }

    const invRoleLower = String(inv.role || '').toLowerCase();
    if (
      [
        'founder',
        'owner',
        'super admin',
        'superadmin',
        'super_admin',
        'company admin',
        'company_admin',
        'country manager',
        'country_manager',
        'branch manager',
        'branch_manager',
        'system admin',
        'dealer',
        'customer',
      ].some((kw) => invRoleLower.includes(kw))
    ) {
      res.status(403).json({ error: 'Privileged governance or external roles cannot be activated via employee invitations.' });
      return;
    }

    const userExists = sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(inv.email.toLowerCase());
    if (userExists) {
      res.status(409).json({ error: 'An account with this invited email already exists.' });
      return;
    }

    const comp = sqlite.prepare('SELECT country, city FROM companies WHERE id = ?').get(inv.company_id) as any;
    const userId = `usr_emp_${generateSecureToken(6)}`;
    const empId = `emp_${generateSecureToken(6)}`;
    const now = nowIso();
    const cleanEmail = inv.email.toLowerCase();
    const passHash = hashPassword(password);
    const username = `${cleanEmail.split('@')[0].replace(/[^a-z0-9_]/gi, '_')}_${generateNumericOtp(3)}`;
    const countryId = inv.country_id || comp?.country || 'PK';
    const branchId = inv.branch_id || null;
    const empCode = inv.employee_code || `EMP-${countryId}-${generateNumericOtp(4)}`;
    const department = inv.department || 'Branch Operations';
    const totpSecret = generateTotpSecret();
    const recoveryCodes = Array.from({ length: 6 }, () => `${generateNumericOtp(4)}-${generateNumericOtp(4)}`);
    const hashedRecoveryCodes = recoveryCodes.map((c) => sha256(c));

    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, branch_id, username, full_name, email, mobile, password_hash, role,
          country, city, dealership_id, status, email_verified, mobile_verified,
          created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Verification', 0, 0, ?, ?, ?)
      `)
      .run(
        userId,
        inv.company_id,
        branchId,
        username,
        inv.full_name,
        cleanEmail,
        mobile || inv.mobile || '+92 300 0000000',
        passHash,
        inv.role,
        countryId,
        inv.city || comp?.city || 'Karachi',
        inv.dealership_id || null,
        inv.invited_by,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_accounts (
          id, user_id, company_id, country_id, branch_id, department_id, employee_code,
          full_name, username, email, mobile, department, job_position,
          reporting_manager_id, reporting_manager_name, password_hash,
          email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
          status, attendance_json, leave_requests_json, performance_score, permissions_json,
          joined_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?, ?, 'Pending Verification', '[]', '[]', 92.0, ?, ?, ?, ?)
      `)
      .run(
        empId,
        userId,
        inv.company_id,
        countryId,
        branchId,
        inv.department_id || null,
        empCode,
        inv.full_name,
        username,
        cleanEmail,
        mobile || inv.mobile || '+92 300 0000000',
        department,
        inv.role,
        inv.reporting_manager_id || null,
        inv.reporting_manager_name || 'Assigned Reporting Manager',
        passHash,
        totpSecret,
        JSON.stringify(hashedRecoveryCodes),
        JSON.stringify([...CANONICAL_EMPLOYEE_PERMISSIONS]),
        now.slice(0, 10),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_profiles (
          id, employee_id, company_id, country_id, branch_id, department_id,
          reporting_manager_id, reporting_manager_name, bio, city, work_location,
          employment_type, responsibilities_json, skills_json, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'On-Site 3S Hub', 'Full-Time Permanent', ?, '[]', ?)
      `)
      .run(
        `ep_${empId}`,
        empId,
        inv.company_id,
        countryId,
        branchId,
        inv.department_id || null,
        inv.reporting_manager_id || null,
        inv.reporting_manager_name || 'Assigned Reporting Manager',
        `${inv.role} — BYD PAKISTAN 360.`,
        inv.city || comp?.city || 'Karachi',
        JSON.stringify([`Execute ${department} duties under ${inv.reporting_manager_name || 'Branch Management'}`]),
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_assignments (
          id, employee_id, company_id, country_id, branch_id, department_id, job_position,
          reporting_manager_id, reporting_manager_name, shift_schedule, effective_from, status, assigned_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Mon-Sat 09:00-18:00', ?, 'Active', ?, ?, ?)
      `)
      .run(
        `ea_${empId}`,
        empId,
        inv.company_id,
        countryId,
        branchId,
        inv.department_id || null,
        inv.role,
        inv.reporting_manager_id || null,
        inv.reporting_manager_name || 'Assigned Reporting Manager',
        now.slice(0, 10),
        inv.invited_by,
        now,
        now
      );

    sqlite
      .prepare("UPDATE invitations SET status = 'Accepted', used_at = ? WHERE id = ?")
      .run(now, inv.id);

    const emailOtp = issueEmployeeEmailVerifyOtp({ id: empId, email: cleanEmail });
    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360%20Employee:${encodeURIComponent(cleanEmail)}?secret=${totpSecret}&issuer=BYD%20PAKISTAN%20360`;

    logOwnerAudit({
      actorId: empId,
      actorName: inv.full_name,
      actorRole: inv.role,
      action: 'EMPLOYEE_INVITE_ACCEPTED',
      module: 'Staff Onboarding',
      targetId: `${cleanEmail} (${empCode})`,
      companyId: inv.company_id,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      employeeId: empId,
      employeeCode: empCode,
      email: cleanEmail,
      requiresEmailVerification: true,
      message: 'Password created. Verify your email OTP and save your 2FA secret before signing into the Employee Portal.',
      twoFactorSetup: {
        secret: totpSecret,
        otpAuthUri,
        recoveryCodes,
      },
      verificationOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            code: emailOtp,
          },
    });
  });

  // Forgot & Reset Password (standard user accounts only; Super Admin & Founder isolated)
  router.post('/auth/forgot-password', rateLimitAuth('std_forgot_pw', 15, 60_000), (req: Request, res: Response) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const user = sqlite.prepare('SELECT id, full_name, company_id FROM users WHERE LOWER(email) = ?').get(email) as any;

    if (!user) {
      res.json({
        success: true,
        message: 'If an account matches that email, a password reset token has been generated.',
      });
      return;
    }

    const rawResetToken = generateSecureToken(20);
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    sqlite
      .prepare("INSERT INTO password_resets (id, token_hash, user_id, subject_type, expires_at, created_at) VALUES (?, ?, ?, 'user', ?, ?)")
      .run(`rst_${generateSecureToken(6)}`, sha256(rawResetToken), user.id, expiresAt, nowIso());

    logOwnerAudit({
      actorId: user.id,
      actorName: user.full_name,
      actorRole: 'User',
      action: 'PASSWORD_RESET_REQUESTED',
      module: 'Authentication',
      targetId: email,
      companyId: user.company_id,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      message: 'Password reset token generated (valid for 30 minutes).',
      resetOutbox: process.env.SMTP_HOST
        ? undefined
        : {
            notice: 'Development Mailer Outbox (SMTP not configured)',
            resetToken: rawResetToken,
          },
    });
  });

  router.post('/auth/reset-password', (req: Request, res: Response) => {
    const token = String(req.body.token || '').trim();
    const newPassword = String(req.body.newPassword || '');
    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const resetRow = sqlite
      .prepare("SELECT * FROM password_resets WHERE token_hash = ? AND subject_type = 'user' AND used_at IS NULL")
      .get(sha256(token)) as any;

    if (!resetRow || new Date(resetRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Password reset token is invalid or expired.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?').run(hashPassword(newPassword), now, resetRow.user_id);
    sqlite.prepare('UPDATE password_resets SET used_at = ? WHERE id = ?').run(now, resetRow.id);
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(resetRow.user_id);

    res.json({ success: true, message: 'Password updated successfully. All previous sessions have been revoked.' });
  });

  // Session Management & Logout
  router.get('/auth/sessions', requireAuth, (req: Request, res: Response) => {
    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, last_activity_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());
    res.json({ sessions });
  });

  router.delete('/auth/sessions/:id', requireAuth, (req: Request, res: Response) => {
    const target = sqlite.prepare('SELECT id, user_id FROM authentication_sessions WHERE id = ?').get(req.params.id) as any;
    if (!target || (target.user_id !== req.auth!.userId && req.auth!.subjectType !== 'founder')) {
      res.status(404).json({ error: 'Session not found.' });
      return;
    }
    sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    res.json({ success: true });
  });

  router.get('/auth/login-history', requireAuth, (req: Request, res: Response) => {
    const rows = sqlite
      .prepare('SELECT id, identifier, role, success, failure_reason, ip_address, user_agent, suspicious, created_at FROM login_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(req.auth!.userId);
    res.json({ history: rows });
  });

  router.post('/auth/logout', (req: Request, res: Response) => {
    if (req.auth?.sessionId) {
      const now = nowIso();
      sqlite
        .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout', revoked_at = ? WHERE id = ?")
        .run(now, req.auth.sessionId);
      sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(req.auth.sessionId);
      markLoginSessionTerminated(req.auth.sessionId, 'logout');
      if (req.auth.subjectType === 'super_admin') {
        logAdminActivity({
          adminId: req.auth.userId,
          adminName: req.auth.fullName,
          adminRole: 'Super Admin',
          action: 'SUPER_ADMIN_LOGOUT',
          module: 'Super Admin Authentication',
          targetId: req.auth.email,
          ipAddress: getClientIp(req),
        });
      }
      logOwnerAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'LOGOUT',
        module: 'Authentication',
        targetId: req.auth.email,
        companyId: req.auth.companyId,
        ipAddress: getClientIp(req),
      });
      logSecurityAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        targetUserId: req.auth.userId,
        companyId: req.auth.companyId,
        countryId: req.auth.country,
        branchId: req.auth.branchId || null,
        action: 'LOGOUT',
        category: 'Session Security',
        details: 'Single-session logout completed.',
        ipAddress: getClientIp(req),
      });
    }
    clearSessionCookie(res);
    res.json({ success: true });
  });

  router.post('/auth/logout-all', requireAuth, (req: Request, res: Response) => {
    const now = nowIso();
    const userId = req.auth!.userId;
    const revRes = sqlite
      .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'logout_all', revoked_at = ? WHERE user_id = ? AND revoked = 0")
      .run(now, userId);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(userId);
    markLoginSessionTerminated(userId, 'logout_all', true);

    logSecurityAudit({
      actorId: userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: userId,
      companyId: req.auth!.companyId,
      countryId: req.auth!.country,
      branchId: req.auth!.branchId || null,
      action: 'LOGOUT_ALL_DEVICES',
      category: 'Session Security',
      details: `Revoked ${revRes.changes} active session(s) across all devices.`,
      ipAddress: getClientIp(req),
    });

    clearSessionCookie(res);
    res.json({
      success: true,
      revokedSessions: revRes.changes,
      message: `All ${revRes.changes} active sessions across all devices have been revoked.`,
    });
  });

  // =========================================================================
  // 5. COMPANY-ISOLATED EMPLOYEE MANAGEMENT & INVITATIONS
  // =========================================================================
  const STAFF_MANAGER_ROLES = ['Founder / Owner', 'Super Admin', 'Company Admin', 'Dealership Manager'];

  router.get('/employees', requireAuth, requireRoles(...STAFF_MANAGER_ROLES, 'Head Office Staff'), (req: Request, res: Response) => {
    const isGlobal = req.auth!.subjectType === 'founder' || req.auth!.subjectType === 'super_admin';
    if (req.auth!.subjectType === 'super_admin' && !req.auth!.permissions.includes('employees.manage') && !req.auth!.permissions.includes('users.view')) {
      res.status(403).json({ error: 'Permission denied: requires users.view or employees.manage.' });
      return;
    }
    const companyFilter = isGlobal && req.query.companyId ? String(req.query.companyId) : req.auth!.companyId;

    const users = isGlobal && !companyFilter
      ? sqlite.prepare("SELECT id, company_id, username, full_name, email, mobile, role, country, city, dealership_id, status, email_verified, last_login_at, created_at FROM users WHERE role != 'Customer' ORDER BY created_at DESC").all()
      : sqlite.prepare("SELECT id, company_id, username, full_name, email, mobile, role, country, city, dealership_id, status, email_verified, last_login_at, created_at FROM users WHERE company_id = ? AND role != 'Customer' ORDER BY created_at DESC").all(companyFilter);

    const invitations = isGlobal && !companyFilter
      ? sqlite.prepare('SELECT id, company_id, email, full_name, mobile, role, city, status, expires_at, created_at FROM invitations ORDER BY created_at DESC').all()
      : sqlite.prepare('SELECT id, company_id, email, full_name, mobile, role, city, status, expires_at, created_at FROM invitations WHERE company_id = ? ORDER BY created_at DESC').all(companyFilter);

    res.json({ employees: users, invitations });
  });

  router.post('/employees/invite', requireAuth, requireRoles(...STAFF_MANAGER_ROLES), (req: Request, res: Response) => {
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const mobile = String(req.body.mobile || '').trim();
    const role = String(req.body.role || 'Sales Executive').trim();
    const city = String(req.body.city || req.auth!.city || 'Karachi').trim();
    const dealershipId = req.body.dealershipId ? String(req.body.dealershipId) : req.auth!.dealershipId;
    const branchId = req.body.branchId ? String(req.body.branchId).trim() : req.auth!.branchId || null;
    const department = String(req.body.department || 'Branch Operations').trim();
    const departmentId = req.body.departmentId ? String(req.body.departmentId).trim() : null;
    const countryId = String(req.body.countryId || req.auth!.country || 'PK').trim().toUpperCase();
    const employeeCode = req.body.employeeCode
      ? String(req.body.employeeCode).trim().toUpperCase()
      : `EMP-${countryId}-${generateNumericOtp(4)}`;
    const reportingManagerId = req.body.reportingManagerId ? String(req.body.reportingManagerId).trim() : req.auth!.userId;
    const reportingManagerName = String(req.body.reportingManagerName || req.auth!.fullName).trim();

    const isGlobal = req.auth!.subjectType === 'founder' || req.auth!.subjectType === 'super_admin';
    if (req.auth!.subjectType === 'super_admin' && !req.auth!.permissions.includes('employees.manage') && !req.auth!.permissions.includes('users.create')) {
      res.status(403).json({ error: 'Permission denied: requires employees.manage or users.create.' });
      return;
    }
    const targetCompanyId = isGlobal && req.body.companyId ? String(req.body.companyId) : req.auth!.companyId;

    if (!targetCompanyId) {
      res.status(400).json({ error: 'Target company ID is required.' });
      return;
    }

    const roleLower = role.toLowerCase();
    if (
      [
        'founder',
        'owner',
        'super admin',
        'superadmin',
        'super_admin',
        'company admin',
        'company_admin',
        'country manager',
        'country_manager',
        'branch manager',
        'branch_manager',
        'system admin',
        'dealer',
        'customer',
      ].some((kw) => roleLower.includes(kw))
    ) {
      res.status(403).json({ error: 'Privileged governance or external roles cannot be created through employee invitations.' });
      return;
    }

    if (!fullName || !email) {
      res.status(400).json({ error: 'Employee name and email are required.' });
      return;
    }

    const exists =
      sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM company_admin_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM country_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM branch_manager_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(email) ||
      sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(email);
    if (exists) {
      res.status(409).json({ error: 'An active or registered account with this email already exists.' });
      return;
    }

    const codeExists = sqlite
      .prepare('SELECT id FROM employee_accounts WHERE company_id = ? AND employee_code = ?')
      .get(targetCompanyId, employeeCode);
    if (codeExists) {
      res.status(409).json({ error: `Employee ID "${employeeCode}" is already assigned within this company.` });
      return;
    }

    const rawToken = generateSecureToken(20);
    const invId = `inv_${generateSecureToken(6)}`;
    const expiresAt = new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString();

    sqlite
      .prepare(`
        INSERT INTO invitations (
          id, token_hash, company_id, email, full_name, mobile, role,
          dealership_id, city, employee_code, country_id, branch_id, department_id, department,
          reporting_manager_id, reporting_manager_name, invited_by, status, expires_at, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)
      `)
      .run(
        invId,
        sha256(rawToken),
        targetCompanyId,
        email,
        fullName,
        mobile || null,
        role,
        dealershipId || null,
        city,
        employeeCode,
        countryId,
        branchId,
        departmentId,
        department,
        reportingManagerId,
        reportingManagerName,
        req.auth!.fullName,
        expiresAt,
        nowIso()
      );

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'EMPLOYEE_INVITED',
      module: 'Staff Management',
      targetId: `${email} (${employeeCode} • ${role})`,
      companyId: targetCompanyId,
      ipAddress: getClientIp(req),
    });

    res.status(201).json({
      success: true,
      invitationId: invId,
      employeeCode,
      inviteToken: rawToken,
      inviteUrl: `/?invite=${rawToken}`,
      expiresAt,
      message: 'Secure single-use invitation generated with Employee ID & organization mapping. The employee will set their own private password and activate 2FA.',
    });
  });

  router.patch('/employees/:id/status', requireAuth, requireRoles(...STAFF_MANAGER_ROLES), (req: Request, res: Response) => {
    const target = sqlite.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id) as any;
    if (!target) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    const isGlobal = req.auth!.subjectType === 'founder' || req.auth!.subjectType === 'super_admin';
    if (!isGlobal && target.company_id !== req.auth!.companyId) {
      res.status(403).json({ error: 'Cross-company modification is strictly forbidden.' });
      return;
    }
    if (req.auth!.subjectType === 'super_admin' && !req.auth!.permissions.includes('employees.manage') && !req.auth!.permissions.includes('users.suspend')) {
      res.status(403).json({ error: 'Permission denied: requires employees.manage or users.suspend.' });
      return;
    }
    if (target.role === 'Super Admin' || target.role === 'Founder / Owner') {
      res.status(403).json({ error: 'Only the Primary Owner can modify Super Admin or Founder accounts.' });
      return;
    }

    const nextStatus = String(req.body.status || '');
    if (!['Active', 'Suspended'].includes(nextStatus)) {
      res.status(400).json({ error: 'Invalid status.' });
      return;
    }
    sqlite.prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ?').run(nextStatus, nowIso(), target.id);
    if (nextStatus === 'Suspended') {
      sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(target.id);
    }
    res.json({ success: true });
  });

  // =========================================================================
  // GENERAL USER REGISTRATION — Email + Password + Authenticator (TOTP) Setup
  // =========================================================================
  router.post('/auth/register-user', rateLimitAuth('user_register', 15, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const fullName = String(req.body.fullName || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const mobile = String(req.body.mobile || '').trim();

    if (!fullName || !email || !password) {
      res.status(400).json({ error: 'Full name, email, and password are required.' });
      return;
    }

    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason || 'Weak password.' });
      return;
    }

    const existing = sqlite.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const userId = `user_${generateSecureToken(8)}`;
    const passwordHash = hashPassword(password);
    const totpSecret = generateTotpSecret();
    const now = nowIso();

    try {
      sqlite.prepare(`
        INSERT INTO users (id, company_id, username, full_name, email, mobile, password_hash, role, country, city, cnic_or_id, status, email_verified, mobile_verified, two_factor_enabled, two_factor_secret, failed_login_attempts, created_by, last_login_at, created_at, updated_at)
        VALUES (?, NULL, ?, ?, ?, ?, ?, 'User', 'PK', 'Karachi', NULL, 'Active', 1, 0, 1, ?, 0, NULL, NULL, ?, ?)
      `).run(
        userId,
        email.split('@')[0],
        fullName,
        email,
        mobile || null,
        passwordHash,
        totpSecret,
        now,
        now
      );

      // Generate recovery codes
      const recoveryCodes: string[] = [];
      for (let i = 0; i < 6; i++) {
        recoveryCodes.push(generateSecureToken(16));
      }
      const codeHashes = recoveryCodes.map(c => sha256(c));
      for (const hash of codeHashes) {
        sqlite.prepare('INSERT INTO mfa_recovery_codes (id, user_id, subject_type, code_hash, created_at) VALUES (?, ?, ?, ?, ?)')
          .run(`mrc_${generateSecureToken(6)}`, userId, 'user', hash, now);
      }

      // MFA settings
      sqlite.prepare('INSERT INTO mfa_settings (user_id, subject_type, totp_enabled, email_otp_enabled, sms_otp_enabled, totp_secret, mfa_required, enrolled_at, updated_at) VALUES (?, ?, 1, 0, 0, ?, 1, ?, ?)')
        .run(userId, 'user', totpSecret, now, now);

      logOwnerAudit({
        actorId: userId,
        actorName: fullName,
        actorRole: 'User',
        action: 'USER_REGISTER_WITH_2FA',
        module: 'Authentication',
        targetId: email,
        ipAddress: ip,
      });

      res.json({
        success: true,
        userId,
        fullName,
        email,
        message: 'Account registered successfully. Set up your authenticator app with the TOTP secret below.',
        totpSecret,
        recoveryCodes,
        instructions: [
          '1. Download Google Authenticator, Authy, or Microsoft Authenticator app.',
          '2. Add new account and enter the TOTP Secret shown above.',
          '3. The app will show a 6-digit code that changes every 30 seconds.',
          '4. Use your email, password, and this 6-digit code to login.',
          '5. Save your Recovery Codes — each can be used once if you lose your phone.',
        ],
      });
    } catch (err: any) {
      logSecurityEvent({
        severity: 'ERROR',
        eventType: 'USER_REGISTER_ERROR',
        identifier: email,
        details: err.message,
        ipAddress: ip,
      });
      res.status(500).json({ error: 'Registration failed. Please try again.' });
    }
  });

  // =========================================================================
  // GENERAL USER LOGIN — Step 1: Email + Password → 2FA Challenge
  // =========================================================================
  router.post('/auth/login-user', rateLimitAuth('user_login', 20, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const identifier = String(req.body.identifier || req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (!identifier || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const user = sqlite.prepare('SELECT * FROM users WHERE LOWER(email) = ?').get(identifier) as any;

    const policy = getSystemSetting('security_policy', { maxFailedLoginAttempts: 5, lockoutMinutes: 15 });

    if (!user) {
      res.status(401).json({ error: 'Invalid credentials.' });
      return;
    }

    if (user.locked_until && new Date(user.locked_until).getTime() > Date.now()) {
      res.status(423).json({ error: `Account temporarily locked. Try again after ${user.locked_until}.` });
      return;
    }

    if (!verifyPassword(password, user.password_hash)) {
      const nextFails = (user.failed_login_attempts || 0) + 1;
      const shouldLock = nextFails >= (policy.maxFailedLoginAttempts || 5);
      const lockedUntil = shouldLock
        ? new Date(Date.now() + (policy.lockoutMinutes || 15) * 60 * 1000).toISOString()
        : null;

      sqlite.prepare('UPDATE users SET failed_login_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?')
        .run(nextFails, lockedUntil, nowIso(), user.id);

      res.status(401).json({
        error: shouldLock ? 'Too many failed attempts. Account temporarily locked.' : 'Invalid credentials.',
      });
      return;
    }

    if (user.status !== 'Active') {
      res.status(403).json({
        error: user.status === 'Pending Verification' ? 'Account pending verification.' : 'Account suspended.',
      });
      return;
    }

    sqlite.prepare('UPDATE users SET failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?')
      .run(nowIso(), user.id);

    const challengeToken = generateSecureToken(24);
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    sqlite.prepare(`
      INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
      VALUES (?, ?, 'user_2fa', ?, ?, 'user', ?, 0, ?)
    `).run(`otp_${generateSecureToken(6)}`, user.email, sha256(challengeToken), user.id, expiresAt, nowIso());

    res.json({
      requires2FA: true,
      challengeToken,
      userName: user.full_name,
      role: user.role,
      message: 'Password verified. Enter the 6-digit code from your authenticator app.',
    });
  });

  // =========================================================================
  // GENERAL USER LOGIN — Step 2: Verify 6-Digit Authenticator Code
  // =========================================================================
  router.post('/auth/verify-user-2fa', rateLimitAuth('user_2fa', 25, 60_000), (req: Request, res: Response) => {
    const ip = getClientIp(req);
    const ua = String(req.headers['user-agent'] || 'Unknown').slice(0, 220);
    const challengeToken = String(req.body.challengeToken || '');
    const code = String(req.body.code || '').trim();

    if (!challengeToken || !code) {
      res.status(400).json({ error: 'Challenge token and 6-digit code are required.' });
      return;
    }

    const challenge = sqlite.prepare(`
      SELECT * FROM otp_verifications
      WHERE purpose = 'user_2fa' AND code_hash = ? AND used_at IS NULL
    `).get(sha256(challengeToken)) as any;

    if (!challenge || new Date(challenge.expires_at).getTime() <= Date.now()) {
      res.status(401).json({ error: '2FA challenge expired or invalid. Please sign in again.' });
      return;
    }

    const user = sqlite.prepare('SELECT * FROM users WHERE id = ?').get(challenge.subject_id) as any;
    if (!user) {
      res.status(401).json({ error: 'User account not found.' });
      return;
    }

    let verified = verifyTotpCode(user.two_factor_secret, code);

    if (!verified) {
      const storedHashes: string[] = [];
      const rows = sqlite.prepare('SELECT code_hash FROM mfa_recovery_codes WHERE user_id = ? AND used_at IS NULL').all(user.id);
      const inputHash = sha256(code);
      const matchIdx = rows.findIndex((r: any) => r.code_hash === inputHash);
      if (matchIdx !== -1) {
        verified = true;
        sqlite.prepare('UPDATE mfa_recovery_codes SET used_at = ? WHERE code_hash = ?').run(nowIso(), inputHash);
      }
    }

    if (!verified) {
      const nextAtt = (challenge.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAtt, challenge.id);
      if (nextAtt >= 5) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
      }
      res.status(401).json({ error: 'Invalid 6-digit authenticator code.' });
      return;
    }

    sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), challenge.id);
    sqlite.prepare('UPDATE users SET last_login_at = ?, last_login_ip = ?, updated_at = ? WHERE id = ?')
      .run(nowIso(), ip, nowIso(), user.id);

    const session = createSession({
      userId: user.id,
      subjectType: 'user',
      companyId: user.company_id || null,
      role: user.role,
      twoFactorVerified: true,
      req,
      res,
    });

    res.json({
      success: true,
      sessionExpiresAt: session.expiresAt,
      user: {
        id: user.id,
        name: user.full_name,
        fullName: user.full_name,
        email: user.email,
        phone: user.mobile,
        role: user.role,
        subjectType: 'user',
        permissions: resolveUserPermissions(user.id, user.role),
        verifiedIdentity: true,
      },
    });
  });

  return router;
}
