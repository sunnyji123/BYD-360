import React, { useState, useEffect } from 'react';
import {
  Bell,
  CheckCircle,
  Clock,
  Shield,
  Car,
  Wrench,
  Megaphone,
  Smartphone,
  Mail,
  Send,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { NotificationItem } from '../../types';

export const NotificationCenter: React.FC = () => {
  const { setActiveTab, currentRole } = useApp();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<string>('All');

  // Broadcast modal for Admins
  const [broadcastOpen, setBroadcastOpen] = useState(false);
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Multi-channel preview simulator state
  const [previewItem, setPreviewItem] = useState<NotificationItem | null>(null);

  useEffect(() => {
    const load = () => {
      setNotifications(db.getNotifications());
    };
    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  const filteredNotifications = notifications.filter((n) =>
    selectedFilter === 'All' ? true : n.category === selectedFilter
  );

  const handleMarkAllRead = () => {
    db.markAllNotificationsAsRead();
  };

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMsg) return;

    db.addNotification({
      id: `notif_${Date.now()}`,
      title: broadcastTitle,
      message: broadcastMsg,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Announcement',
      read: false,
    });

    setBroadcastSuccess(true);
    setTimeout(() => {
      setBroadcastSuccess(false);
      setBroadcastOpen(false);
      setBroadcastTitle('');
      setBroadcastMsg('');
    }, 1500);
  };

  return (
    <div className="space-y-8 pb-12 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Communication Gateway</span>
          <h2 className="text-2xl font-black text-white">Notifications & Alerts Center</h2>
          <p className="text-xs text-slate-400">
            Real-time multi-channel delivery status for service, warranty, and network announcements
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {['Super Admin', 'Company Management'].includes(currentRole) && (
            <button
              onClick={() => setBroadcastOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-500/20"
            >
              <Megaphone className="w-3.5 h-3.5" />
              <span>Broadcast Announcement</span>
            </button>
          )}

          <button
            onClick={handleMarkAllRead}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-950 text-slate-300 hover:text-white text-xs font-semibold"
          >
            <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>Mark All as Read</span>
          </button>
        </div>
      </div>

      {/* Filter Category Pills */}
      <div className="flex flex-wrap gap-1.5">
        {['All', 'Service', 'Warranty', 'Delivery', 'Security', 'Announcement'].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedFilter(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedFilter === cat
                ? 'bg-cyan-500 text-slate-950'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Notifications Feed */}
      <div className="space-y-3">
        {filteredNotifications.map((notif) => (
          <div
            key={notif.id}
            onClick={() => {
              db.markNotificationAsRead(notif.id);
              setPreviewItem(notif);
            }}
            className={`p-4 rounded-2xl border transition cursor-pointer flex items-start justify-between gap-4 ${
              notif.read
                ? 'bg-slate-950/60 border-slate-800 text-slate-400'
                : 'bg-slate-900 border-cyan-500/40 text-slate-200 shadow-md shadow-cyan-500/5'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`p-2.5 rounded-xl ${
                notif.category === 'Service'
                  ? 'bg-cyan-950 text-cyan-400'
                  : notif.category === 'Warranty'
                  ? 'bg-purple-950 text-purple-400'
                  : notif.category === 'Announcement'
                  ? 'bg-amber-950 text-amber-400'
                  : 'bg-emerald-950 text-emerald-400'
              }`}>
                {notif.category === 'Service' && <Wrench className="w-4 h-4" />}
                {notif.category === 'Warranty' && <Shield className="w-4 h-4" />}
                {notif.category === 'Announcement' && <Megaphone className="w-4 h-4" />}
                {notif.category === 'Security' && <Clock className="w-4 h-4" />}
                {notif.category === 'Delivery' && <Car className="w-4 h-4" />}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-white">{notif.title}</h4>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {notif.category}
                  </span>
                  {!notif.read && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  )}
                </div>
                <p className="text-xs text-slate-300 mt-1">{notif.message}</p>
                <span className="text-[10px] text-slate-500 mt-2 block">{notif.timestamp}</span>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setPreviewItem(notif);
              }}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 flex-shrink-0"
            >
              <span>Channel Preview</span>
            </button>
          </div>
        ))}
      </div>

      {/* Multi-Channel Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Multi-Channel Delivery Simulator (Pakistan)</h3>
              <button
                onClick={() => setPreviewItem(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800"
              >
                Close
              </button>
            </div>

            {/* In-App Preview */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1">
                <Bell className="w-3 h-3" /> In-App Notification (PWA Push)
              </span>
              <p className="text-xs font-semibold text-white">{previewItem.title}</p>
              <p className="text-xs text-slate-300">{previewItem.message}</p>
            </div>

            {/* SMS / WhatsApp Preview */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                <Smartphone className="w-3 h-3" /> WhatsApp / SMS Dispatch (+92 300 8241100)
              </span>
              <p className="text-xs font-mono text-emerald-300">
                [BYD PAKISTAN]: {previewItem.title} - {previewItem.message} Ref: BYD-360-PK. Support: 0800-BYD-PK
              </p>
            </div>

            {/* Email Preview */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-blue-400 flex items-center gap-1">
                <Mail className="w-3 h-3" /> Official Email Dispatch
              </span>
              <p className="text-xs font-bold text-white">Subject: {previewItem.title}</p>
              <p className="text-xs text-slate-400">From: notifications@bydpakistan.com.pk</p>
              <p className="text-xs text-slate-300 mt-1">{previewItem.message}</p>
            </div>

            <button
              onClick={() => setPreviewItem(null)}
              className="w-full py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Broadcast Announcement Modal */}
      {broadcastOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 text-slate-100 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-1">Broadcast Network Announcement</h3>
            <p className="text-xs text-slate-400 mb-4">Send instant push notification to all BYD vehicle owners in Pakistan.</p>

            {broadcastSuccess ? (
              <div className="py-6 text-center space-y-2">
                <Check className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-white">Announcement Dispatched!</h4>
                <p className="text-xs text-slate-300">Queued for delivery across all registered customer accounts.</p>
              </div>
            ) : (
              <form onSubmit={handleSendBroadcast} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Headline</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. New M-2 Bhera 180kW Fast Charger Operational"
                    value={broadcastTitle}
                    onChange={(e) => setBroadcastTitle(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Detailed Message</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Provide details about firmware updates, new charging bays, or holiday service hours..."
                    value={broadcastMsg}
                    onChange={(e) => setBroadcastMsg(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setBroadcastOpen(false)}
                    className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-xs text-white"
                  >
                    Send Broadcast
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
