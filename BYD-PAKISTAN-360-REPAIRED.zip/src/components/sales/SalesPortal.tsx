import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  Calendar,
  Truck,
  RefreshCcw,
  FileText,
  AlertCircle,
  CheckCircle2,
  Search,
  Filter,
  Plus,
  Edit,
  Delete,
  Download,
  ArrowRight,
  LayoutList,
  PieChart,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import {
  Booking,
  SalesOrder,
  Payment,
  Installment,
  Refund,
  SalesCommission,
  DeliveryRecord,
  BookingStatus,
  PaymentStatus,
  DeliveryStatus,
  InstallmentStatus,
  RefundStatus,
} from '../../types';

type SalesTab =
  | 'dashboard'
  | 'bookings'
  | 'sales-orders'
  | 'payments'
  | 'installments'
  | 'refunds'
  | 'commissions'
  | 'deliveries';

export const SalesPortal: React.FC = () => {
  const { currentUser, currentRole, formatPrice } = useApp();

  // Tabs
  const [activeTab, setActiveTab] = useState<SalesTab>('dashboard');

  // Data state
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [installments, setInstallments] = useState<Installment[]>([]);
  const [refunds, setRefunds] = useState<Refund[]>([]);
  const [commissions, setCommissions] = useState<SalesCommission[]>([]);
  const [deliveries, setDeliveries] = useState<DeliveryRecord[]>([]);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  useEffect(() => {
    const load = () => {
      setBookings(db.getBookings());
      setSalesOrders(db.getSalesOrders());
      setPayments(db.getPayments());
      setInstallments(db.getInstallments());
      setRefunds(db.getRefunds());
      setCommissions(db.getSalesCommissions());
      setDeliveries(db.getDeliveryRecords());
    };
    load();
    const unsub = db.subscribe(load);
    return () => unsub();
  }, []);

  // Computed stats
  const totalBookings = bookings.length;
  const pendingBookings = bookings.filter((b) => b.bookingStatus === 'Pending Review').length;
  const completedSales = salesOrders.filter((s) => s.paymentStatus === 'Fully Paid').length;
  const totalRevenue = salesOrders.reduce((sum, s) => sum + s.paidAmountPkr, 0);
  const pendingInstallments = installments.filter((i) => i.status === 'Pending').length;
  const pendingRefunds = refunds.filter((r) => r.status === 'Pending').length;
  const pendingCommissions = commissions.filter((c) => c.status === 'Pending').length;
  const pendingDeliveries = deliveries.filter((d) => d.deliveryStatus !== 'Delivered').length;

  const filteredBookings = bookings.filter(
    (b) =>
      (searchQuery === '' ||
        b.bookingRef.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.vehicleModel.toLowerCase().includes(searchQuery.toLowerCase())) &&
      (statusFilter === 'All' || b.bookingStatus === statusFilter)
  );

  const handleCreateBooking = () => {
    alert('New booking creation form will open here. (Phase 1 UI skeleton)');
  };

  const handleConfirmBooking = (booking: Booking) => {
    const updated = { ...booking, bookingStatus: 'Approved' as BookingStatus, paymentStatus: 'Deposit Verified' as PaymentStatus };
    db.updateBooking(updated);
  };

  const handleRejectBooking = (booking: Booking) => {
    const updated = { ...booking, bookingStatus: 'Rejected' as BookingStatus };
    db.updateBooking(updated);
  };

  const handleMarkInstallmentPaid = (installment: Installment) => {
    const updated = { ...installment, status: 'Paid' as InstallmentStatus, paymentDate: new Date().toISOString() };
    db.updateInstallment(updated);
  };

  const handleApproveRefund = (refund: Refund) => {
    const updated = { ...refund, status: 'Approved' as RefundStatus, approvedBy: currentUser?.name };
    db.updateRefund(updated);
  };

  const handleMarkDelivered = (delivery: DeliveryRecord) => {
    const updated = { ...delivery, deliveryStatus: 'Delivered' as DeliveryStatus, pdiCompleted: true };
    db.updateDeliveryRecord(updated);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Sales &amp; Booking Management</h1>
          <p className="text-gray-600 text-sm">
            Manage vehicle bookings, sales orders, payments, installments, refunds, commissions &amp; deliveries
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleCreateBooking}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition"
          >
            <Plus size={18} />
            New Booking
          </button>
          <button
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition"
          >
            <Download size={18} />
            Export
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Bookings"
          value={totalBookings}
          icon={<Calendar size={24} />}
          color="bg-blue-50 text-blue-700 border-blue-200"
          change="+12% vs last month"
        />
        <StatCard
          title="Pending Review"
          value={pendingBookings}
          icon={<AlertCircle size={24} />}
          color="bg-amber-50 text-amber-700 border-amber-200"
          change="Requires action"
        />
        <StatCard
          title="Total Revenue"
          value={formatPrice(totalRevenue)}
          icon={<DollarSign size={24} />}
          color="bg-green-50 text-green-700 border-green-200"
          change="+8% vs last month"
        />
        <StatCard
          title="Completed Sales"
          value={completedSales}
          icon={<CheckCircle2 size={24} />}
          color="bg-emerald-50 text-emerald-700 border-emerald-200"
          change="Fully paid orders"
        />
        <StatCard
          title="Pending Installments"
          value={pendingInstallments}
          icon={<RefreshCcw size={24} />}
          color="bg-purple-50 text-purple-700 border-purple-200"
          change="Due soon"
        />
        <StatCard
          title="Pending Refunds"
          value={pendingRefunds}
          icon={<FileText size={24} />}
          color="bg-rose-50 text-rose-700 border-rose-200"
          change="Requires approval"
        />
        <StatCard
          title="Pending Commissions"
          value={pendingCommissions}
          icon={<PieChart size={24} />}
          color="bg-indigo-50 text-indigo-700 border-indigo-200"
          change="Awaiting payout"
        />
        <StatCard
          title="Pending Deliveries"
          value={pendingDeliveries}
          icon={<Truck size={24} />}
          color="bg-orange-50 text-orange-700 border-orange-200"
          change="Awaiting handover"
        />
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 overflow-x-auto pb-2">
        {[
          { id: 'dashboard', label: 'Dashboard' },
          { id: 'bookings', label: 'Bookings' },
          { id: 'sales-orders', label: 'Sales Orders' },
          { id: 'payments', label: 'Payments' },
          { id: 'installments', label: 'Installments' },
          { id: 'refunds', label: 'Refunds' },
          { id: 'commissions', label: 'Commissions' },
          { id: 'deliveries', label: 'Deliveries' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as SalesTab)}
            className={`px-4 py-2 rounded-md text-sm font-medium whitespace-nowrap transition ${
              activeTab === (tab.id as SalesTab)
                ? 'bg-green-600 text-white shadow-sm'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'dashboard' && (
        <DashboardView
          bookings={bookings}
          salesOrders={salesOrders}
          payments={payments}
          formatPrice={formatPrice}
        />
      )}
      {activeTab === 'bookings' && (
        <BookingManagement
          bookings={filteredBookings}
          onConfirm={handleConfirmBooking}
          onReject={handleRejectBooking}
          searchQuery={searchQuery}
          onSearch={setSearchQuery}
          onStatusFilter={setStatusFilter}
          statusFilter={statusFilter}
          formatPrice={formatPrice}
        />
      )}
      {activeTab === 'sales-orders' && (
        <SalesOrdersView salesOrders={salesOrders} formatPrice={formatPrice} />
      )}
      {activeTab === 'payments' && <PaymentTrackingView payments={payments} formatPrice={formatPrice} />}
      {activeTab === 'installments' && (
        <InstallmentRecordsView installments={installments} onMarkPaid={handleMarkInstallmentPaid} formatPrice={formatPrice} />
      )}
      {activeTab === 'refunds' && <RefundsView refunds={refunds} onApprove={handleApproveRefund} formatPrice={formatPrice} />}
      {activeTab === 'commissions' && (
        <SalesCommissionsView commissions={commissions} formatPrice={formatPrice} />
      )}
      {activeTab === 'deliveries' && (
        <DeliveryStatusView deliveries={deliveries} onMarkDelivered={handleMarkDelivered} formatPrice={formatPrice} />
      )}
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: React.ReactNode;
  icon: React.ReactNode;
  color: string;
  change: string;
}

function StatCard({ title, value, icon, color, change }: StatCardProps) {
  return (
    <div className={`p-5 rounded-xl border ${color}`}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          <p className="text-xs text-gray-500 mt-1">{change}</p>
        </div>
        <div className="p-2 bg-white/50 rounded-lg">{icon}</div>
      </div>
    </div>
  );
}

// ============================================================================
// DASHBOARD VIEW
// ============================================================================
interface DashboardViewProps {
  bookings: Booking[];
  salesOrders: SalesOrder[];
  payments: Payment[];
  formatPrice: (amountInPkr: number) => string;
}

function DashboardView({ bookings, salesOrders, payments, formatPrice }: DashboardViewProps) {
  const recentBookings = bookings.slice(0, 5);
  const recentPayments = payments.slice(0, 5);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Calendar size={20} /> Recent Bookings
        </h2>
        <div className="overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="pb-2 font-medium text-gray-600">Ref</th>
                <th className="pb-2 font-medium text-gray-600">Customer</th>
                <th className="pb-2 font-medium text-gray-600">Model</th>
                <th className="pb-2 font-medium text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentBookings.map((b) => (
                <tr key={b.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-2 font-mono text-xs">{b.bookingRef}</td>
                  <td className="py-2">{b.customerName}</td>
                  <td className="py-2">{b.vehicleModel}</td>
                  <td className="py-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      b.bookingStatus === 'Approved'
                        ? 'bg-green-100 text-green-700'
                        : b.bookingStatus === 'Pending Review'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {b.bookingStatus}
                    </span>
                  </td>
                </tr>
              ))}
              {recentBookings.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-4 text-center text-gray-500">
                    No bookings found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
          <DollarSign size={20} /> Recent Payments
        </h2>
        <div className="overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="pb-2 font-medium text-gray-600">Ref</th>
                <th className="pb-2 font-medium text-gray-600">Customer</th>
                <th className="pb-2 font-medium text-gray-600">Amount</th>
                <th className="pb-2 font-medium text-gray-600">Status</th>
              </tr>
            </thead>
            <tbody>
              {recentPayments.map((p) => (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="py-2 font-mono text-xs">{p.paymentRef}</td>
                  <td className="py-2">{p.customerId}</td>
                  <td className="py-2 font-medium">{formatPrice(p.amountPkr)}</td>
                  <td className="py-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      p.paymentStatus === 'Paid'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {p.paymentStatus}
                    </span>
                  </td>
                </tr>
              ))}
              {recentPayments.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-4 text-center text-gray-500">
                    No payments found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// BOOKING MANAGEMENT
// ============================================================================
interface BookingManagementProps {
  bookings: Booking[];
  onConfirm: (b: Booking) => void;
  onReject: (b: Booking) => void;
  searchQuery: string;
  onSearch: (q: string) => void;
  onStatusFilter: (s: string) => void;
  statusFilter: string;
  formatPrice: (amountInPkr: number) => string;
}

function BookingManagement({
  bookings,
  onConfirm,
  onReject,
  searchQuery,
  onSearch,
  onStatusFilter,
  statusFilter,
  formatPrice,
}: BookingManagementProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex flex-col md:flex-row gap-4 mb-4">
        <div className="relative flex-1">
          <Search size={18} className="absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder="Search bookings by ref, customer, or model..."
            value={searchQuery}
            onChange={(e) => onSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-sm"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => onStatusFilter(e.target.value)}
          className="pl-4 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none text-sm bg-white"
        >
          <option value="All">All Status</option>
          <option value="Pending Review">Pending Review</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
          <option value="Cancelled">Cancelled</option>
          <option value="Completed">Completed</option>
        </select>
      </div>

      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Booking Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Model</th>
              <th className="pb-3 font-medium text-gray-600">Price</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{b.bookingRef}</td>
                <td className="py-3">{b.customerName}</td>
                <td className="py-3">{b.vehicleModel}</td>
                <td className="py-3 font-medium">{formatPrice(b.quotedPricePkr)}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    b.bookingStatus === 'Approved'
                      ? 'bg-green-100 text-green-700'
                      : b.bookingStatus === 'Pending Review'
                      ? 'bg-amber-100 text-amber-700'
                      : b.bookingStatus === 'Rejected'
                      ? 'bg-rose-100 text-rose-700'
                      : b.bookingStatus === 'Completed'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {b.bookingStatus}
                  </span>
                </td>
                <td className="py-3">
                  {b.bookingStatus === 'Pending Review' && (
                    <>
                      <button
                        onClick={() => onConfirm(b)}
                        className="mr-2 px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => onReject(b)}
                        className="px-3 py-1 bg-rose-600 text-white text-xs rounded hover:bg-rose-700 transition"
                      >
                        Reject
                      </button>
                    </>
                  )}
                  {b.bookingStatus !== 'Pending Review' && (
                    <button className="px-3 py-1 text-green-600 text-xs hover:underline">
                      View Details
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {bookings.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-500">
                  No bookings found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// SALES ORDERS VIEW
// ============================================================================
interface SalesOrdersViewProps {
  salesOrders: SalesOrder[];
  formatPrice: (amountInPkr: number) => string;
}

function SalesOrdersView({ salesOrders, formatPrice }: SalesOrdersViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Sales Orders</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Sale Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Model</th>
              <th className="pb-3 font-medium text-gray-600">Amount</th>
              <th className="pb-3 font-medium text-gray-600">Paid</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">Delivery</th>
            </tr>
          </thead>
          <tbody>
            {salesOrders.map((o) => (
              <tr key={o.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{o.saleRef}</td>
                <td className="py-3">{o.customerName}</td>
                <td className="py-3">{o.vehicleModel}</td>
                <td className="py-3 font-medium">{formatPrice(o.saleAmountPkr)}</td>
                <td className="py-3 font-medium">{formatPrice(o.paidAmountPkr)}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    o.paymentStatus === 'Fully Paid'
                      ? 'bg-green-100 text-green-700'
                      : o.paymentStatus === 'Deposit Verified'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {o.paymentStatus}
                  </span>
                </td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    o.deliveryStatus === 'Delivered'
                      ? 'bg-green-100 text-green-700'
                      : o.deliveryStatus === 'Pre-Delivery Inspection'
                      ? 'bg-blue-100 text-blue-700'
                      : o.deliveryStatus === 'Ready for Delivery'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {o.deliveryStatus}
                  </span>
                </td>
              </tr>
            ))}
            {salesOrders.length === 0 && (
              <tr>
                <td colSpan={7} className="py-8 text-center text-gray-500">
                  No sales orders found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// PAYMENT TRACKING VIEW
// ============================================================================
interface PaymentTrackingViewProps {
  payments: Payment[];
  formatPrice: (amountInPkr: number) => string;
}

function PaymentTrackingView({ payments, formatPrice }: PaymentTrackingViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Payment Tracking</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Payment Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Amount</th>
              <th className="pb-3 font-medium text-gray-600">Gateway</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{p.paymentRef}</td>
                <td className="py-3">{p.customerId}</td>
                <td className="py-3 font-medium">{formatPrice(p.amountPkr)}</td>
                <td className="py-3">{p.gatewayName}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    p.paymentStatus === 'Paid'
                      ? 'bg-green-100 text-green-700'
                      : p.paymentStatus === 'Awaiting Payment Verification'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {p.paymentStatus}
                  </span>
                </td>
                <td className="py-3">{p.paymentDate}</td>
              </tr>
            ))}
            {payments.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-500">
                  No payments found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// INSTALLMENT RECORDS VIEW
// ============================================================================
interface InstallmentRecordsViewProps {
  installments: Installment[];
  onMarkPaid: (i: Installment) => void;
  formatPrice: (amountInPkr: number) => string;
}

function InstallmentRecordsView({ installments, onMarkPaid, formatPrice }: InstallmentRecordsViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Installment Records</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Due Date</th>
              <th className="pb-3 font-medium text-gray-600">Amount</th>
              <th className="pb-3 font-medium text-gray-600">Paid</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">Action</th>
            </tr>
          </thead>
          <tbody>
            {installments.map((i) => (
              <tr key={i.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{i.installmentRef}</td>
                <td className="py-3">{i.customerName}</td>
                <td className="py-3">{i.dueDate}</td>
                <td className="py-3 font-medium">{formatPrice(i.amountPkr)}</td>
                <td className="py-3 font-medium">{formatPrice(i.paidAmountPkr)}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    i.status === 'Paid'
                      ? 'bg-green-100 text-green-700'
                      : i.status === 'Pending'
                      ? 'bg-amber-100 text-amber-700'
                      : i.status === 'Overdue'
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {i.status}
                  </span>
                </td>
                <td className="py-3">
                  {i.status === 'Pending' && (
                    <button
                      onClick={() => onMarkPaid(i)}
                      className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition"
                    >
                      Mark Paid
                    </button>
                  )}
                  {i.status !== 'Pending' && (
                    <span className="text-xs text-gray-500">—</span>
                  )}
                </td>
              </tr>
            ))}
            {installments.length === 0 && (
              <tr>
                <td colSpan={7} className="py-8 text-center text-gray-500">
                  No installments found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// REFUNDS VIEW
// ============================================================================
interface RefundsViewProps {
  refunds: Refund[];
  onApprove: (r: Refund) => void;
  formatPrice: (amountInPkr: number) => string;
}

function RefundsView({ refunds, onApprove, formatPrice }: RefundsViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Refunds</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Refund Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Amount</th>
              <th className="pb-3 font-medium text-gray-600">Reason</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">Action</th>
            </tr>
          </thead>
          <tbody>
            {refunds.map((r) => (
              <tr key={r.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{r.refundRef}</td>
                <td className="py-3">{r.customerName}</td>
                <td className="py-3 font-medium">{formatPrice(r.amountPkr)}</td>
                <td className="py-3 text-sm">{r.reason}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    r.status === 'Approved'
                      ? 'bg-green-100 text-green-700'
                      : r.status === 'Pending'
                      ? 'bg-amber-100 text-amber-700'
                      : r.status === 'Rejected'
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}>
                    {r.status}
                  </span>
                </td>
                <td className="py-3">
                  {r.status === 'Pending' && (
                    <button
                      onClick={() => onApprove(r)}
                      className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition"
                    >
                      Approve
                    </button>
                  )}
                  {r.status !== 'Pending' && (
                    <span className="text-xs text-gray-500">—</span>
                  )}
                </td>
              </tr>
            ))}
            {refunds.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-500">
                  No refunds found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// SALES COMMISSIONS VIEW
// ============================================================================
interface SalesCommissionsViewProps {
  commissions: SalesCommission[];
  formatPrice: (amountInPkr: number) => string;
}

function SalesCommissionsView({ commissions, formatPrice }: SalesCommissionsViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Sales Commissions</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Ref</th>
              <th className="pb-3 font-medium text-gray-600">Dealer</th>
              <th className="pb-3 font-medium text-gray-600">Sale Amount</th>
              <th className="pb-3 font-medium text-gray-600">Rate %</th>
              <th className="pb-3 font-medium text-gray-600">Commission</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
            </tr>
          </thead>
          <tbody>
            {commissions.map((c) => (
              <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{c.commissionRef}</td>
                <td className="py-3">{c.dealerId || 'N/A'}</td>
                <td className="py-3 font-medium">{formatPrice(c.saleAmountPkr)}</td>
                <td className="py-3">{c.commissionRatePct}%</td>
                <td className="py-3 font-medium">{formatPrice(c.commissionAmountPkr)}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    c.status === 'Paid'
                      ? 'bg-green-100 text-green-700'
                      : c.status === 'Approved'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {c.status}
                  </span>
                </td>
              </tr>
            ))}
            {commissions.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-500">
                  No commissions found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// DELIVERY STATUS VIEW
// ============================================================================
interface DeliveryStatusViewProps {
  deliveries: DeliveryRecord[];
  onMarkDelivered: (d: DeliveryRecord) => void;
  formatPrice: (amountInPkr: number) => string;
}

function DeliveryStatusView({ deliveries, onMarkDelivered, formatPrice }: DeliveryStatusViewProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <h2 className="text-lg font-bold text-gray-900 mb-4">Delivery Status</h2>
      <div className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pb-3 font-medium text-gray-600">Delivery Ref</th>
              <th className="pb-3 font-medium text-gray-600">Customer</th>
              <th className="pb-3 font-medium text-gray-600">Model</th>
              <th className="pb-3 font-medium text-gray-600">Date</th>
              <th className="pb-3 font-medium text-gray-600">Status</th>
              <th className="pb-3 font-medium text-gray-600">PDI</th>
              <th className="pb-3 font-medium text-gray-600">Action</th>
            </tr>
          </thead>
          <tbody>
            {deliveries.map((d) => (
              <tr key={d.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="py-3 font-mono text-xs">{d.deliveryRef}</td>
                <td className="py-3">{d.customerName}</td>
                <td className="py-3">{d.vehicleModel}</td>
                <td className="py-3">{d.deliveryDate}</td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    d.deliveryStatus === 'Delivered'
                      ? 'bg-green-100 text-green-700'
                      : d.deliveryStatus === 'Pre-Delivery Inspection'
                      ? 'bg-blue-100 text-blue-700'
                      : d.deliveryStatus === 'Ready for Delivery'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {d.deliveryStatus}
                  </span>
                </td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    d.pdiCompleted ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {d.pdiCompleted ? 'Completed' : 'Pending'}
                  </span>
                </td>
                <td className="py-3">
                  {d.deliveryStatus !== 'Delivered' && (
                    <button
                      onClick={() => onMarkDelivered(d)}
                      className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition"
                    >
                      Mark Delivered
                    </button>
                  )}
                  {d.deliveryStatus === 'Delivered' && (
                    <span className="text-xs text-gray-500">Delivered</span>
                  )}
                </td>
              </tr>
            ))}
            {deliveries.length === 0 && (
              <tr>
                <td colSpan={7} className="py-8 text-center text-gray-500">
                  No deliveries found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
