import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { db } from '../../services/db';
import { ServiceJob, WarrantyClaim, BatteryInspectionRecord, MaintenanceReminder, Technician, SparePart } from '../../types';

export const ServicePortal: React.FC = () => {
  const { currentUser, currentRole } = useApp();
  const [activeTab, setActiveTab] = useState<'dashboard'|'service-jobs'|'warranty-claims'|'battery-records'|'maintenance-reminders'|'technicians'|'spare-parts'>('dashboard');
  const [serviceJobs, setServiceJobs] = useState<ServiceJob[]>([]);
  const [warrantyClaims, setWarrantyClaims] = useState<WarrantyClaim[]>([]);
  const [batteryRecords, setBatteryRecords] = useState<BatteryInspectionRecord[]>([]);
  const [maintenanceReminders, setMaintenanceReminders] = useState<MaintenanceReminder[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [spareParts, setSpareParts] = useState<SparePart[]>([]);

  useEffect(() => {
    setServiceJobs(db.getServiceJobs());
    setWarrantyClaims(db.getWarrantyClaims());
    setBatteryRecords(db.getBatteryRecords());
    setMaintenanceReminders(db.getMaintenanceReminders());
    setTechnicians(db.getTechnicians());
    setSpareParts(db.getSpareParts());
  }, []);

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'service-jobs', label: 'Service Jobs', icon: '🔧' },
    { id: 'warranty-claims', label: 'Warranty Claims', icon: '🛡️' },
    { id: 'battery-records', label: 'Battery Records', icon: '🔋' },
    { id: 'maintenance-reminders', label: 'Maintenance Reminders', icon: '⏰' },
    { id: 'technicians', label: 'Technicians', icon: '👨‍🔧' },
    { id: 'spare-parts', label: 'Spare Parts', icon: '📦' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Service & Warranty Management</h1>
          <p className="text-gray-600">BYD Pakistan 360 — Service Centers & Warranty Portal</p>
        </div>
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === (tab.id as typeof activeTab)
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">Total Service Jobs</p>
                <p className="text-2xl font-bold text-gray-800">{serviceJobs.length}</p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">🔧</div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">Warranty Claims</p>
                <p className="text-2xl font-bold text-gray-800">{warrantyClaims.length}</p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center text-green-600">🛡️</div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">Technicians</p>
                <p className="text-2xl font-bold text-gray-800">{technicians.length}</p>
              </div>
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600">👨‍🔧</div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow border border-gray-100">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm">Pending Reminders</p>
                <p className="text-2xl font-bold text-gray-800">{maintenanceReminders.filter((r) => r.status === 'Pending').length}</p>
              </div>
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600">⏰</div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow border border-gray-100 p-6">
        {activeTab === 'dashboard' && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔧</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Service & Warranty Dashboard</h3>
            <p className="text-gray-600">Manage service appointments, warranty claims, battery inspections, maintenance reminders, technicians, and spare parts inventory.</p>
          </div>
        )}
        {activeTab === 'service-jobs' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Service Jobs</h3>
            <p className="text-gray-600">Service job management coming soon with full CRUD operations.</p>
          </div>
        )}
        {activeTab === 'warranty-claims' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Warranty Claims</h3>
            <p className="text-gray-600">Warranty claim tracking and processing.</p>
          </div>
        )}
        {activeTab === 'battery-records' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Battery Records</h3>
            <p className="text-gray-600">Battery inspection and health monitoring records.</p>
          </div>
        )}
        {activeTab === 'maintenance-reminders' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Maintenance Reminders</h3>
            <p className="text-gray-600">Automated maintenance reminders for customers.</p>
          </div>
        )}
        {activeTab === 'technicians' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Technicians</h3>
            <p className="text-gray-600">Technician management and assignment.</p>
          </div>
        )}
        {activeTab === 'spare-parts' && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Spare Parts</h3>
            <p className="text-gray-600">Spare parts inventory management.</p>
          </div>
        )}
      </div>
    </div>
  );
};