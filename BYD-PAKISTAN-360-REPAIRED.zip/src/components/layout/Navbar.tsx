import React, { useState } from 'react';
import {
  Shield,
  Bell,
  Globe,
  UserCheck,
  Menu,
  X,
  Zap,
  MapPin,
  Sparkles,
  ChevronDown,
  Layers,
  Wrench,
  Car,
  Briefcase,
  FileText,
  Activity,
  Award,
  Scale,
  Package,
  DollarSign,
  Smartphone,
  Code,
  Coins,
  Lock,
  Crown,
  LogOut,
  Store,
  BadgeCheck,
} from 'lucide-react';
import { useApp, AppTab } from '../../context/AppContext';
import { CountryCode, CurrencyCode } from '../../types';
import { GLOBAL_COUNTRIES } from '../../data/mockData';
import { PWAInstallButton } from '../common/PWAInstallButton';

const ROLE_BADGE_MAP: Record<string, { badge: string; color: string }> = {
  'Founder / Owner': { badge: 'OWNER', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' },
  'Super Admin': { badge: 'SUPER', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' },
  'Global Super Admin': { badge: 'SUPER', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' },
  'Company Admin': { badge: 'COMPANY', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
  'Country Manager': { badge: 'COUNTRY', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
  'Branch Manager': { badge: 'BRANCH', color: 'bg-sky-500/20 text-sky-300 border-sky-500/30' },
  'Head Office Staff': { badge: 'HQ STAFF', color: 'bg-sky-500/20 text-sky-300 border-sky-500/30' },
  'Dealership Manager': { badge: 'DEALER', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  'Dealer Owner': { badge: 'DEALER', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  'Dealership Staff': { badge: 'STAFF', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  'Sales Manager': { badge: 'SALES MGR', color: 'bg-teal-500/20 text-teal-300 border-teal-500/30' },
  'Sales Executive': { badge: 'SALES', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' },
  'Finance Manager': { badge: 'FINANCE', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
  'Service Manager': { badge: 'SERVICE', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  'Technical Support': { badge: 'TECH', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
  Customer: { badge: 'CUSTOMER', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
};

const CURRENCIES: CurrencyCode[] = ['PKR', 'AED', 'SAR', 'USD', 'GBP', 'EUR'];

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    currentRole,
    currentUser,
    isAuthenticated,
    logoutUser,
    language,
    setLanguage,
    selectedCountry,
    setSelectedCountry,
    countryConfig,
    selectedCurrency,
    setSelectedCurrency,
    cityFilter,
    setCityFilter,
    unreadCount,
    t,
    openAuthModal,
    openFounderPortal,
    openSuperAdminPortal,
    openCompanyAdminPortal,
    openCountryManagerPortal,
    openBranchManagerPortal,
    openEmployeePortal,
    openDealerPortal,
    openCustomerPortal,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [accountDropdownOpen, setAccountDropdownOpen] = useState(false);
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);

  const navLinks: { tab: AppTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { tab: 'landing', label: t('landing'), icon: Car },
    { tab: 'customer', label: t('customer'), icon: UserCheck },
    { tab: 'company', label: t('company'), icon: Briefcase },
    { tab: 'country', label: t('country'), icon: Globe },
    { tab: 'branch', label: t('branch'), icon: Store },
    { tab: 'employee', label: t('employee'), icon: BadgeCheck },
    { tab: 'dealer', label: t('dealer'), icon: Layers },
    { tab: 'service', label: t('service'), icon: Wrench },
    { tab: 'battery', label: t('battery'), icon: Activity },
    { tab: 'charging', label: t('charging'), icon: Zap },
    { tab: 'warranty', label: t('warranty'), icon: Shield },
    { tab: 'inventory', label: t('inventory'), icon: Package },
    { tab: 'finance', label: t('finance'), icon: DollarSign },
    { tab: 'ai-assistant', label: t('aiAssistant'), icon: Sparkles },
    { tab: 'mobile-preview', label: t('mobilePreview'), icon: Smartphone },
    { tab: 'architecture', label: t('architecture'), icon: Code },
    { tab: 'analytics', label: t('analytics'), icon: FileText },
    { tab: 'admin', label: t('admin'), icon: Award },
    { tab: 'owner', label: t('owner'), icon: Crown },
    { tab: 'presentation', label: t('presentation'), icon: Layers },
    { tab: 'about', label: t('about'), icon: Scale },
  ];

  const currentRoleConfig = isAuthenticated
    ? ROLE_BADGE_MAP[currentRole] || { badge: currentRole.toUpperCase().slice(0, 10), color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' }
    : { badge: 'GUEST', color: 'bg-slate-800 text-slate-300 border-slate-700' };

  const handleNextLanguage = () => {
    if (language === 'en') setLanguage('ur');
    else if (language === 'ur') setLanguage('ar');
    else setLanguage('en');
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 border-b border-slate-800/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Brand */}
          <div
            onClick={() => setActiveTab('landing')}
            className="flex items-center gap-2.5 cursor-pointer group flex-shrink-0"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-600 to-amber-500 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-400/40 transition">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold tracking-wider text-base sm:text-lg text-white">BYD</span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-800 tracking-wider">
                  GLOBAL 360
                </span>
                <span className="hidden sm:inline-block text-[11px]">{countryConfig.flagEmoji}</span>
              </div>
              <p className="text-[9px] text-slate-400 font-medium tracking-wider hidden sm:block">
                Mobility & Operations Platform
              </p>
            </div>
          </div>

          {/* Center Navigation for Desktop */}
          <nav className="hidden xl:flex items-center space-x-1 overflow-x-auto py-1 text-xs font-semibold">
            {navLinks.slice(0, 8).map((link) => {
              const Icon = link.icon;
              const isActive = activeTab === link.tab;
              return (
                <button
                  key={link.tab}
                  onClick={() => setActiveTab(link.tab)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all duration-150 whitespace-nowrap ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                </button>
              );
            })}

            {/* Quick dropdown for more modules */}
            <div className="relative group">
              <button className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-900 text-xs font-bold border border-slate-800">
                <span>More Modules</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>
              <div className="absolute right-0 mt-1 w-56 py-1.5 bg-slate-900 border border-slate-800 rounded-xl shadow-xl hidden group-hover:block z-50">
                {navLinks.slice(8).map((link) => {
                  const Icon = link.icon;
                  const isActive = activeTab === link.tab;
                  return (
                    <button
                      key={link.tab}
                      onClick={() => setActiveTab(link.tab)}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-left text-xs ${
                        isActive ? 'text-cyan-400 bg-cyan-950/40 font-bold' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{link.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2">
            {/* Country Jurisdiction Selector */}
            <div className="relative hidden md:block">
              <button
                onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-900/80 text-xs text-slate-200 hover:text-white hover:border-slate-700"
                title="Select Operating Country / Legal Entity"
              >
                <span>{countryConfig.flagEmoji}</span>
                <span className="font-semibold">{countryConfig.code}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>
              {countryDropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-60 py-1.5 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50">
                  <div className="px-3 py-1 border-b border-slate-800 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    Sovereign Jurisdiction
                  </div>
                  {GLOBAL_COUNTRIES.map((c) => (
                    <button
                      key={c.code}
                      onClick={() => {
                        setSelectedCountry(c.code);
                        setCountryDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-1.5 flex items-center justify-between text-left text-xs ${
                        selectedCountry === c.code
                          ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{c.flagEmoji}</span>
                        <span>{c.name}</span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{c.defaultCurrency}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Currency Selector */}
            <div className="relative hidden sm:block">
              <button
                onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
                className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-slate-800 bg-slate-900/80 text-xs text-slate-200 hover:text-white font-mono"
                title="Active Display Currency"
              >
                <Coins className="w-3 h-3 text-amber-400" />
                <span className="font-bold">{selectedCurrency}</span>
                <ChevronDown className="w-2.5 h-2.5 text-slate-400" />
              </button>
              {currencyDropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-28 py-1 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-50">
                  {CURRENCIES.map((curr) => (
                    <button
                      key={curr}
                      onClick={() => {
                        setSelectedCurrency(curr);
                        setCurrencyDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-1 text-left text-xs font-mono ${
                        selectedCurrency === curr ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {curr}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Separate Founder Portal Button */}
            <button
              onClick={openFounderPortal}
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-amber-500/40 bg-amber-950/30 text-xs font-bold text-amber-300 hover:text-amber-200 hover:border-amber-400 transition"
              title="Private Founder / Primary Owner Login (Intekhab Alam)"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>Founder</span>
            </button>

            {/* Enterprise & Customer Sign In Button */}
            {!isAuthenticated && (
              <button
                onClick={() => openAuthModal('login')}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-cyan-500/40 bg-gradient-to-r from-cyan-950/60 to-blue-950/60 text-xs font-semibold text-cyan-300 hover:text-white hover:border-cyan-400 transition"
                title="Corporate & Customer Login / Registration"
              >
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sign In</span>
              </button>
            )}

            {/* Authenticated Identity Pill (Server Verified) */}
            <div className="relative">
              <button
                onClick={() => setAccountDropdownOpen(!accountDropdownOpen)}
                className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition ${currentRoleConfig.color} shadow-sm`}
                title={isAuthenticated ? `Authenticated as ${currentUser.name} (${currentRole})` : 'Not signed in — click to authenticate'}
              >
                <span className="text-[10px] uppercase font-bold tracking-wider">{currentRoleConfig.badge}</span>
                <span className="hidden lg:inline font-medium text-slate-200 truncate max-w-[100px]">
                  {isAuthenticated ? currentUser.name.split(' ')[0] : 'Sign In'}
                </span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {accountDropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-64 py-2 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl z-50 text-xs">
                  {isAuthenticated ? (
                    <>
                      <div className="px-3.5 py-2 border-b border-slate-800">
                        <div className="font-bold text-white truncate">{currentUser.name}</div>
                        <div className="text-[11px] text-cyan-300">{currentRole}</div>
                        <div className="text-[10px] text-slate-400 truncate font-mono">{currentUser.email}</div>
                      </div>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openAuthModal('sessions');
                        }}
                        className="w-full px-3.5 py-2 text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                      >
                        <Shield className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Active Sessions &amp; History</span>
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openAuthModal('login');
                        }}
                        className="w-full px-3.5 py-2 text-left text-slate-200 hover:bg-slate-800 flex items-center gap-2"
                      >
                        <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                        <span>Switch Account (Re-Authenticate)</span>
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          logoutUser();
                        }}
                        className="w-full px-3.5 py-2 text-left text-rose-300 hover:bg-rose-950/50 flex items-center gap-2 font-semibold"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out Safely</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="px-3.5 py-2 border-b border-slate-800 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                        Server-Verified Authentication
                      </div>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openCustomerPortal('login');
                        }}
                        className="w-full px-3.5 py-2 text-left text-emerald-300 hover:bg-emerald-950/40 font-bold"
                      >
                        Dedicated Customer Login Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openCustomerPortal('register');
                        }}
                        className="w-full px-3.5 py-2 text-left text-slate-200 hover:bg-slate-800"
                      >
                        Register Customer Account
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openAuthModal('login');
                        }}
                        className="w-full px-3.5 py-2 text-left text-cyan-300 hover:bg-slate-800 font-semibold border-t border-slate-800 mt-1"
                      >
                        Corporate / Dealership Sign In
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openAuthModal('register-company');
                        }}
                        className="w-full px-3.5 py-2 text-left text-slate-200 hover:bg-slate-800"
                      >
                        Register New Company
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openDealerPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-blue-300 hover:bg-blue-950/40 font-bold border-t border-slate-800 mt-1"
                      >
                        Dedicated Dealer Login Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openEmployeePortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-teal-300 hover:bg-teal-950/40 font-bold"
                      >
                        Dedicated Employee Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openBranchManagerPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-sky-300 hover:bg-sky-950/40 font-bold"
                      >
                        Dedicated Branch Manager Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openCountryManagerPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-emerald-300 hover:bg-emerald-950/40 font-bold"
                      >
                        Dedicated Country Manager Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openCompanyAdminPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-cyan-300 hover:bg-cyan-950/40 font-bold"
                      >
                        Dedicated Company Admin Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openSuperAdminPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-indigo-300 hover:bg-indigo-950/40 font-bold"
                      >
                        Dedicated Super Admin Portal
                      </button>
                      <button
                        onClick={() => {
                          setAccountDropdownOpen(false);
                          openFounderPortal();
                        }}
                        className="w-full px-3.5 py-2 text-left text-amber-300 hover:bg-amber-950/40 font-bold"
                      >
                        Private Founder / Owner Portal
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Notifications Button */}
            <button
              onClick={() => setActiveTab('notifications')}
              className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-900 transition"
              title="Notifications"
            >
              <Bell className="w-4 h-4 text-slate-300" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-cyan-500 text-[9px] font-extrabold text-slate-950">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Language Toggle (EN / اردو / العربية) */}
            <button
              onClick={handleNextLanguage}
              className="flex items-center gap-1 px-2 py-1 rounded-lg border border-slate-800 bg-slate-900/60 text-xs font-semibold text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40"
              title="Switch language (English / Urdu / Arabic)"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>
                {language === 'en' ? 'EN' : language === 'ur' ? 'اردو' : 'العربية'}
              </span>
            </button>

            {/* PWA Install Button */}
            <div className="hidden sm:block">
              <PWAInstallButton compact />
            </div>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-900"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-800 bg-slate-950 px-4 pt-3 pb-6 space-y-2">
          <div className="pb-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => {
                  openAuthModal('login');
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/40 text-xs font-semibold text-cyan-300 hover:text-white"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isAuthenticated ? 'Account' : 'Sign In'}</span>
              </button>
              <button
                onClick={() => {
                  openCustomerPortal('login');
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/30 text-xs font-bold text-emerald-300"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Customer</span>
              </button>
              <button
                onClick={() => {
                  openDealerPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-blue-500/40 bg-blue-950/30 text-xs font-bold text-blue-300"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Dealer</span>
              </button>
              <button
                onClick={() => {
                  openEmployeePortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-teal-500/40 bg-teal-950/30 text-xs font-bold text-teal-300"
              >
                <BadgeCheck className="w-3.5 h-3.5" />
                <span>Employee</span>
              </button>
              <button
                onClick={() => {
                  openBranchManagerPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-sky-500/40 bg-sky-950/30 text-xs font-bold text-sky-300"
              >
                <Store className="w-3.5 h-3.5" />
                <span>Branch</span>
              </button>
              <button
                onClick={() => {
                  openCountryManagerPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/30 text-xs font-bold text-emerald-300"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Country</span>
              </button>
              <button
                onClick={() => {
                  openCompanyAdminPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/30 text-xs font-bold text-cyan-300"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>Company</span>
              </button>
              <button
                onClick={() => {
                  openSuperAdminPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-indigo-500/40 bg-indigo-950/30 text-xs font-bold text-indigo-300"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Super Admin</span>
              </button>
              <button
                onClick={() => {
                  openFounderPortal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-amber-500/40 bg-amber-950/30 text-xs font-bold text-amber-300"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Founder</span>
              </button>
            </div>
            <PWAInstallButton compact />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeTab === link.tab;
              return (
                <button
                  key={link.tab}
                  onClick={() => {
                    setActiveTab(link.tab);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-left ${
                    isActive ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-300 hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="truncate">{link.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-800">
            <label className="text-[11px] text-slate-400 font-medium block mb-1">Filter by Territory / City:</label>
            <div className="flex flex-wrap gap-1">
              {['All', ...countryConfig.cities].map((city) => (
                <button
                  key={city}
                  onClick={() => {
                    setCityFilter(city);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-2.5 py-1 rounded text-xs ${
                    cityFilter === city ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-300'
                  }`}
                >
                  {city === 'All' ? `All (${countryConfig.code})` : city}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
