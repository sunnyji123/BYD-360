import React, { useState, useEffect, useCallback } from 'react';
import { Globe, TrendingUp, DollarSign, RefreshCw } from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  formatPrice: (n: number) => string;
}

export const SuperAdminDealersAnalyticsPanel: React.FC<Props> = ({ formatPrice }) => {
  const [data, setData] = useState<{ countryBreakdown: any[]; recentTransactions: any[]; dealerPerformance: any[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.getSuperAdminDealersAnalytics();
      setData(res);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (!data) return null;

  return (
    <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 space-y-5 text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
            Dealer Performance &amp; Financial Ledger
          </div>
          <h4 className="text-sm font-black text-white mt-0.5">
            Country-Wise Dealer Summary, Sales Performance &amp; Commission Transactions
          </h4>
        </div>
        <button
          type="button"
          onClick={load}
          className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 font-semibold flex items-center gap-1"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Country Breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {(data.countryBreakdown || []).map((c: any) => (
          <div key={c.countryId} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>{c.countryName} ({c.countryId})</span>
              </span>
              <span className="font-mono text-[11px] text-emerald-400">{c.verifiedDealers}/{c.dealerAccounts} Verified</span>
            </div>
            <div className="font-mono text-sm font-black text-white tabular-nums">{formatPrice(c.totalSalesVolumePkr || 0)}</div>
            <div className="text-[11px] text-slate-400 font-mono">
              Sales: {c.totalSales} · Commissions: {formatPrice(c.totalCommissionPkr || 0)}
            </div>
          </div>
        ))}
      </div>

      {/* Dealer Leaderboard & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="font-bold text-white flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Dealer Sales &amp; Stock Performance ({data.dealerPerformance?.length || 0})</span>
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto">
            {(data.dealerPerformance || []).map((d: any) => (
              <div key={d.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div>
                  <div className="font-semibold text-white">{d.business_name} ({d.dealer_code})</div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {d.country_id} · Stock: {d.stockUnits} · Bookings: {d.bookingsCount} · Sales: {d.salesCount}
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-emerald-400 font-bold">{formatPrice(d.salesRevenuePkr || 0)}</div>
                  <div className="text-[10px] text-amber-300">Comm: {formatPrice(d.commissionPkr || 0)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="font-bold text-white flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-cyan-400" />
            <span>Recent Dealer Sales Transactions ({data.recentTransactions?.length || 0})</span>
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto">
            {(data.recentTransactions || []).map((t: any) => (
              <div key={t.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div>
                  <div className="font-mono font-bold text-cyan-300">{t.sale_ref} · {t.vehicle_model}</div>
                  <div className="text-[11px] text-slate-300">
                    {t.dealer_name} → Customer: {t.customer_name || 'Verified Buyer'}
                  </div>
                </div>
                <div className="text-right font-mono tabular-nums">
                  <div className="text-white font-bold">{formatPrice(t.sale_amount_pkr || 0)}</div>
                  <div className="text-[10px] text-emerald-400">{t.payment_status}</div>
                </div>
              </div>
            ))}
            {(!data.recentTransactions || data.recentTransactions.length === 0) && (
              <div className="text-slate-500 py-4 text-center">No dealer sale transactions recorded yet.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
