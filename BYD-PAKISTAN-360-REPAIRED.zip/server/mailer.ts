import nodemailer from 'nodemailer';

export function isSmtpConfigured(): boolean {
  return Boolean(
    process.env.SMTP_HOST &&
      process.env.SMTP_HOST.trim() &&
      process.env.SMTP_USER &&
      process.env.SMTP_PASS
  );
}

export function isSmsGatewayConfigured(): boolean {
  const twilioReady = Boolean(
    process.env.TWILIO_ACCOUNT_SID &&
      process.env.TWILIO_AUTH_TOKEN &&
      process.env.TWILIO_FROM_NUMBER
  );
  const customSmsReady = Boolean(
    process.env.SMS_API_KEY &&
      process.env.SMS_API_URL
  );
  return twilioReady || customSmsReady;
}

export async function dispatchVerificationEmail(params: {
  to: string;
  subject: string;
  text: string;
  html?: string;
}): Promise<{ delivered: boolean; mode: 'smtp' | 'dev_outbox' | 'unconfigured' }> {
  if (isSmtpConfigured()) {
    const port = Number(process.env.SMTP_PORT || 587);
    const secure = process.env.SMTP_SECURE === 'true' || port === 465;
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST!.trim(),
      port,
      secure,
      auth: {
        user: process.env.SMTP_USER!.trim(),
        pass: process.env.SMTP_PASS!.trim(),
      },
    });
    await transporter.sendMail({
      from: process.env.SMTP_FROM || `BYD PAKISTAN 360 <${process.env.SMTP_USER}>`,
      to: params.to,
      subject: params.subject,
      text: params.text,
      html: params.html || `<p>${params.text.replace(/\n/g, '<br/>')}</p>`,
    });
    return { delivered: true, mode: 'smtp' };
  }

  if (process.env.NODE_ENV === 'production') {
    return { delivered: false, mode: 'unconfigured' };
  }

  return { delivered: false, mode: 'dev_outbox' };
}

export async function dispatchSmsOtp(params: {
  toPhone: string;
  message: string;
}): Promise<{ delivered: boolean; provider: string; error?: string }> {
  if (
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_FROM_NUMBER
  ) {
    const sid = process.env.TWILIO_ACCOUNT_SID.trim();
    const token = process.env.TWILIO_AUTH_TOKEN.trim();
    const from = process.env.TWILIO_FROM_NUMBER.trim();
    const endpoint = `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`;
    const body = new URLSearchParams({
      To: params.toPhone,
      From: from,
      Body: params.message,
    });
    const auth = Buffer.from(`${sid}:${token}`).toString('base64');
    const resp = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    });
    if (!resp.ok) {
      const errText = await resp.text().catch(() => 'Twilio delivery failure');
      return { delivered: false, provider: 'Twilio', error: errText.slice(0, 200) };
    }
    return { delivered: true, provider: 'Twilio' };
  }

  if (process.env.SMS_API_KEY && process.env.SMS_API_URL) {
    const resp = await fetch(process.env.SMS_API_URL.trim(), {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.SMS_API_KEY.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ to: params.toPhone, message: params.message }),
    });
    if (!resp.ok) {
      return { delivered: false, provider: 'Configured SMS Webhook', error: `HTTP ${resp.status}` };
    }
    return { delivered: true, provider: 'Configured SMS Webhook' };
  }

  return {
    delivered: false,
    provider: 'Not Configured',
    error: 'External SMS OTP provider is not configured (set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER or SMS_API_URL + SMS_API_KEY).',
  };
}
