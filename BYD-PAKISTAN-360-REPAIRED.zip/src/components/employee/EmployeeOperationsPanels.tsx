import React, { useEffect, useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  CreditCard,
  DollarSign,
  Download,
  Edit3,
  FileText,
  LogIn,
  LogOut,
  Plus,
  RefreshCw,
  ShieldCheck,
  Upload,
  XCircle,
} from 'lucide-react';
import { api } from '../../services/api';

export function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

interface SubPanelProps {
  scope: any;
  employees: any[];
  branches: any[];
  departments: any[];
  leaveTypes: string[];
  onNotify: (type: 'success' | 'error', text: string) => void;
  onRefreshDashboard: () => void;
}

// ============================================================================
// ATTENDANCE MANAGEMENT PANEL
// ============================================================================
export const AttendancePanel: React.FC<SubPanelProps> = ({
  scope,
  employees,
  branches,
  departments,
  onNotify,
  onRefreshDashboard,
}) => {
  const today = new Date().toISOString().slice(0, 10);
  const [viewMode, setViewMode] = useState<'logs' | 'reports'>('logs');
  const [dateFilter, setDateFilter] = useState<string>(today);
  const [monthFilter, setMonthFilter] = useState<string>(today.slice(0, 7));
  const [branchFilter, setBranchFilter] = useState<string>('ALL');
  const [deptFilter, setDeptFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [records, setRecords] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({});
  const [reportData, setReportData] = useState<{ branchWise: any[]; departmentWise: any[]; totalRecords: number }>({
    branchWise: [],
    departmentWise: [],
    totalRecords: 0,
  });
  const [loading, setLoading] = useState(false);

  const [markForm, setMarkForm] = useState({
    employeeId: '',
    attendanceDate: today,
    status: 'Present',
    workMode: 'On-Site',
    workingHours: '8',
    overtimeHours: '0',
    notes: '',
  });
  const [editingRecord, setEditingRecord] = useState<any | null>(null);
  const [editForm, setEditForm] = useState({ status: 'Present', workingHours: '8', overtimeHours: '0', notes: '' });

  const loadAttendance = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtAttendance({
        date: dateFilter || undefined,
        month: !dateFilter ? monthFilter : undefined,
        branchId: branchFilter !== 'ALL' ? branchFilter : undefined,
        department: deptFilter !== 'ALL' ? deptFilter : undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
      });
      setRecords(res.records || []);
      setSummary(res.summary || {});
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load attendance records.');
    } finally {
      setLoading(false);
    }
  };

  const loadReports = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtAttendanceReport(monthFilter);
      setReportData({
        branchWise: res.branchWise || [],
        departmentWise: res.departmentWise || [],
        totalRecords: res.totalRecords || 0,
      });
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load attendance breakdown report.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (viewMode === 'logs') loadAttendance();
    else loadReports();
  }, [viewMode, dateFilter, monthFilter, branchFilter, deptFilter, statusFilter]);

  const handleSelfPunch = async (action: 'check-in' | 'check-out') => {
    try {
      const res = await api.markEmpMgmtAttendance({
        action,
        employeeId: scope.selfEmployeeId || markForm.employeeId,
        attendanceDate: today,
      });
      onNotify(
        'success',
        action === 'check-in'
          ? 'Checked in successfully with server timestamp.'
          : `Checked out (${res.workingHours ?? 0}h logged, OT ${res.overtimeHours ?? 0}h).`
      );
      loadAttendance();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || `Attendance ${action} failed.`);
    }
  };

  const handleManagerMark = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!markForm.employeeId) {
      onNotify('error', 'Select an employee first.');
      return;
    }
    try {
      await api.markEmpMgmtAttendance({
        action: 'mark',
        employeeId: markForm.employeeId,
        attendanceDate: markForm.attendanceDate,
        status: markForm.status,
        workMode: markForm.workMode,
        workingHours: Number(markForm.workingHours || 0),
        overtimeHours: Number(markForm.overtimeHours || 0),
        notes: markForm.notes,
      });
      onNotify('success', `Attendance marked (${markForm.status}) for ${markForm.attendanceDate}.`);
      setMarkForm((p) => ({ ...p, notes: '' }));
      loadAttendance();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to mark attendance.');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRecord) return;
    try {
      await api.updateEmpMgmtAttendance(editingRecord.id, {
        status: editForm.status,
        workingHours: Number(editForm.workingHours || 0),
        overtimeHours: Number(editForm.overtimeHours || 0),
        notes: editForm.notes,
      });
      onNotify('success', 'Attendance record amended and audit-logged.');
      setEditingRecord(null);
      loadAttendance();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to amend attendance.');
    }
  };

  const uniqueDepts = Array.from(new Set(departments.map((d) => d.name).concat(employees.map((e) => e.department).filter(Boolean))));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Attendance Management</h2>
          <p className="text-xs text-slate-400">Server-timestamped check-in/out, duplicate daily prevention, overtime hours &amp; branch attendance analytics.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {scope.selfEmployeeId && (
            <>
              <button
                type="button"
                onClick={() => handleSelfPunch('check-in')}
                className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Today Check-In</span>
              </button>
              <button
                type="button"
                onClick={() => handleSelfPunch('check-out')}
                className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 whitespace-nowrap"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Today Check-Out</span>
              </button>
            </>
          )}
          <div className="inline-flex rounded-lg bg-slate-900 border border-slate-800 p-0.5">
            <button
              type="button"
              onClick={() => setViewMode('logs')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold ${viewMode === 'logs' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'}`}
            >
              Daily Logs
            </button>
            <button
              type="button"
              onClick={() => setViewMode('reports')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold ${viewMode === 'reports' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'}`}
            >
              Branch &amp; Dept Summary
            </button>
          </div>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-slate-400">Logged Records</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">{summary.total ?? 0}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-emerald-400">Present / Remote</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">{summary.present ?? 0}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-amber-400">Late Arrivals</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">{summary.late ?? 0}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-rose-400">Absent</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">{summary.absent ?? 0}</div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-cyan-400">Hours / Overtime</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">
            {summary.totalHours ?? 0}h <span className="text-xs text-amber-400">(+{summary.overtimeHours ?? 0}h OT)</span>
          </div>
        </div>
      </div>

      {/* Authorized HR/Manager Daily Mark Form */}
      {scope.canManageAttendance && viewMode === 'logs' && (
        <form onSubmit={handleManagerMark} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">Mark Daily Attendance (Authorized HR / Manager)</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-xs">
            <select
              value={markForm.employeeId}
              onChange={(e) => setMarkForm({ ...markForm, employeeId: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white sm:col-span-2"
              required
            >
              <option value="">Select Employee...</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.employeeCode} — {e.fullName} ({e.department})
                </option>
              ))}
            </select>
            <input
              type="date"
              value={markForm.attendanceDate}
              onChange={(e) => setMarkForm({ ...markForm, attendanceDate: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              required
            />
            <select
              value={markForm.status}
              onChange={(e) => setMarkForm({ ...markForm, status: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            >
              <option value="Present">Present</option>
              <option value="Late">Late</option>
              <option value="Half Day">Half Day</option>
              <option value="Remote">Remote</option>
              <option value="Absent">Absent</option>
            </select>
            <input
              type="number"
              step="0.5"
              min="0"
              max="24"
              value={markForm.workingHours}
              onChange={(e) => setMarkForm({ ...markForm, workingHours: e.target.value })}
              placeholder="Hours"
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
            <input
              type="number"
              step="0.5"
              min="0"
              max="12"
              value={markForm.overtimeHours}
              onChange={(e) => setMarkForm({ ...markForm, overtimeHours: e.target.value })}
              placeholder="OT Hours"
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <input
              type="text"
              value={markForm.notes}
              onChange={(e) => setMarkForm({ ...markForm, notes: e.target.value })}
              placeholder="Attendance remarks / shift note..."
              className="flex-1 min-w-[200px] rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white"
            />
            <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs whitespace-nowrap">
              Save Attendance Record
            </button>
          </div>
        </form>
      )}

      {viewMode === 'logs' ? (
        <>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            />
            <button
              type="button"
              onClick={() => setDateFilter('')}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              Show Month ({monthFilter})
            </button>
            <input
              type="month"
              value={monthFilter}
              onChange={(e) => {
                setMonthFilter(e.target.value);
                setDateFilter('');
              }}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            />
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Branches</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Departments</option>
              {uniqueDepts.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Statuses</option>
              <option value="Present">Present</option>
              <option value="Late">Late</option>
              <option value="Half Day">Half Day</option>
              <option value="Remote">Remote</option>
              <option value="Absent">Absent</option>
            </select>
          </div>

          <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Employee</th>
                  <th className="py-2.5 px-3">Department &amp; Branch</th>
                  <th className="py-2.5 px-3">Check-In / Out</th>
                  <th className="py-2.5 px-3">Hours / OT</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Loading attendance records...
                    </td>
                  </tr>
                ) : records.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No attendance records found for the selected filter.
                    </td>
                  </tr>
                ) : (
                  records.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-950/60">
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-200">{r.attendance_date}</td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-white">{r.full_name}</div>
                        <div className="text-[11px] font-mono text-amber-400">{r.employee_code}</div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">
                        <div>{r.department}</div>
                        <div className="text-[11px] text-slate-500">{r.branch_name || 'Head Office'}</div>
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-300">
                        <div>In: {r.check_in_at ? r.check_in_at.slice(11, 16) : '—'}</div>
                        <div>Out: {r.check_out_at ? r.check_out_at.slice(11, 16) : '—'}</div>
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-slate-200">
                        {r.working_hours || 0}h / <span className="text-amber-400">+{r.overtime_hours || 0}h</span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`text-xs font-semibold ${
                            r.status === 'Present' || r.status === 'Remote'
                              ? 'text-emerald-400'
                              : r.status === 'Late' || r.status === 'Half Day'
                              ? 'text-amber-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {scope.canManageAttendance && (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingRecord(r);
                              setEditForm({
                                status: r.status,
                                workingHours: String(r.working_hours ?? 8),
                                overtimeHours: String(r.overtime_hours ?? 0),
                                notes: r.notes || '',
                              });
                            }}
                            className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold inline-flex items-center gap-1"
                          >
                            <Edit3 className="w-3 h-3" /> Edit
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-3">
            <h3 className="text-sm font-bold text-white">Branch-Wise Attendance ({monthFilter})</h3>
            {reportData.branchWise.length === 0 ? (
              <p className="text-xs text-slate-400">No branch attendance records in {monthFilter}.</p>
            ) : (
              <div className="space-y-2 text-xs">
                {reportData.branchWise.map((b) => (
                  <div key={b.branch} className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white">{b.branch}</div>
                      <div className="text-slate-400 font-mono tabular-nums">
                        Hours: {b.hours}h • OT: {b.overtime}h
                      </div>
                    </div>
                    <div className="text-right font-mono tabular-nums">
                      <span className="text-emerald-400 mr-2">P:{b.present}</span>
                      <span className="text-amber-400 mr-2">L:{b.late}</span>
                      <span className="text-rose-400">A:{b.absent}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-3">
            <h3 className="text-sm font-bold text-white">Department-Wise Attendance ({monthFilter})</h3>
            {reportData.departmentWise.length === 0 ? (
              <p className="text-xs text-slate-400">No department attendance records in {monthFilter}.</p>
            ) : (
              <div className="space-y-2 text-xs">
                {reportData.departmentWise.map((d) => (
                  <div key={d.department} className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white">{d.department}</div>
                      <div className="text-slate-400 font-mono tabular-nums">
                        Hours: {d.hours}h • OT: {d.overtime}h
                      </div>
                    </div>
                    <div className="text-right font-mono tabular-nums">
                      <span className="text-emerald-400 mr-2">P:{d.present}</span>
                      <span className="text-amber-400 mr-2">L:{d.late}</span>
                      <span className="text-rose-400">A:{d.absent}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {editingRecord && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4">
          <form onSubmit={handleSaveEdit} className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-white">
              Amend Attendance — {editingRecord.full_name} ({editingRecord.attendance_date})
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Status</label>
                <select
                  value={editForm.status}
                  onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                >
                  <option value="Present">Present</option>
                  <option value="Late">Late</option>
                  <option value="Half Day">Half Day</option>
                  <option value="Remote">Remote</option>
                  <option value="Absent">Absent</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Working Hours</label>
                <input
                  type="number"
                  step="0.5"
                  value={editForm.workingHours}
                  onChange={(e) => setEditForm({ ...editForm, workingHours: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Overtime Hours</label>
                <input
                  type="number"
                  step="0.5"
                  value={editForm.overtimeHours}
                  onChange={(e) => setEditForm({ ...editForm, overtimeHours: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-slate-400 mb-1">Audit Amendment Note</label>
                <input
                  type="text"
                  required
                  value={editForm.notes}
                  onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setEditingRecord(null)} className="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-bold">
                Save Amendment
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// SALARY & PAYROLL MANAGEMENT PANEL
// ============================================================================
export const PayrollPanel: React.FC<SubPanelProps> = ({ scope, employees, onNotify, onRefreshDashboard }) => {
  const currentMonth = new Date().toISOString().slice(0, 7);
  const [subTab, setSubTab] = useState<'runs' | 'structures'>('runs');
  const [payPeriod, setPayPeriod] = useState(currentMonth);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [structures, setStructures] = useState<any[]>([]);
  const [records, setRecords] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const [runForm, setRunForm] = useState({
    payPeriod: currentMonth,
    employeeId: '',
    bonuses: '0',
    advanceSalary: '0',
    overtimePayment: '',
  });

  const [editingStruct, setEditingStruct] = useState<any | null>(null);
  const [structForm, setStructForm] = useState({
    basicSalary: '0',
    houseAllowance: '0',
    medicalAllowance: '0',
    transportAllowance: '0',
    otherAllowances: '0',
    taxDeduction: '0',
    otherDeductions: '0',
    currency: 'PKR',
    bankName: '',
    bankAccountTitle: '',
    bankIban: '',
    notes: '',
  });

  const [payingRecord, setPayingRecord] = useState<any | null>(null);
  const [paymentForm, setPaymentForm] = useState({
    bankReference: '',
    paymentDate: new Date().toISOString().slice(0, 10),
  });

  const loadPayroll = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtPayroll({
        payPeriod: payPeriod === 'ALL' ? undefined : payPeriod,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
      });
      setStructures(res.structures || []);
      setRecords(res.payrollRecords || []);
      setSummary(res.summary || {});
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load payroll data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPayroll();
  }, [payPeriod, statusFilter]);

  const handleProcessPayroll = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.processEmpMgmtPayroll({
        payPeriod: runForm.payPeriod,
        employeeId: runForm.employeeId || undefined,
        bonuses: Number(runForm.bonuses || 0),
        advanceSalary: Number(runForm.advanceSalary || 0),
        overtimePayment: runForm.overtimePayment === '' ? undefined : Number(runForm.overtimePayment),
      });
      onNotify(
        'success',
        `Payroll processed for ${res.processedCount} employee(s).${res.skipped?.length ? ` Skipped existing: ${res.skipped.length}` : ''}`
      );
      setPayPeriod(runForm.payPeriod);
      loadPayroll();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Payroll processing failed.');
    }
  };

  const handleApprove = async (id: string, decision: 'Approved' | 'Rejected') => {
    try {
      await api.approveEmpMgmtPayroll(id, decision);
      onNotify('success', `Payroll record marked as ${decision}.`);
      loadPayroll();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to update payroll approval status.');
    }
  };

  const handleConfirmPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingRecord) return;
    try {
      await api.payEmpMgmtPayroll(payingRecord.id, paymentForm.bankReference, paymentForm.paymentDate);
      onNotify('success', `Verified bank payment recorded (${paymentForm.bankReference}).`);
      setPayingRecord(null);
      setPaymentForm({ bankReference: '', paymentDate: new Date().toISOString().slice(0, 10) });
      loadPayroll();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Payment verification failed.');
    }
  };

  const handleDownloadPayslip = async (rec: any) => {
    try {
      const { blob, filename } = await api.downloadEmpMgmtBlob(`/api/employee-management/payroll/${encodeURIComponent(rec.id)}/payslip.pdf`);
      triggerBlobDownload(blob, filename || `Payslip_${rec.employee_code}_${rec.pay_period}.pdf`);
      onNotify('success', `Downloaded PDF payslip for ${rec.employee_code}.`);
    } catch (err: any) {
      onNotify('error', err?.message || 'Payslip PDF download failed.');
    }
  };

  const handleSaveStructure = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStruct) return;
    try {
      await api.saveEmpMgmtSalaryStructure(editingStruct.employee_id, {
        basicSalary: Number(structForm.basicSalary || 0),
        houseAllowance: Number(structForm.houseAllowance || 0),
        medicalAllowance: Number(structForm.medicalAllowance || 0),
        transportAllowance: Number(structForm.transportAllowance || 0),
        otherAllowances: Number(structForm.otherAllowances || 0),
        taxDeduction: Number(structForm.taxDeduction || 0),
        otherDeductions: Number(structForm.otherDeductions || 0),
        currency: structForm.currency,
        bankName: structForm.bankName,
        bankAccountTitle: structForm.bankAccountTitle,
        bankIban: structForm.bankIban,
        notes: structForm.notes,
      });
      onNotify('success', `Salary structure updated for ${editingStruct.full_name}.`);
      setEditingStruct(null);
      loadPayroll();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to save salary structure.');
    }
  };

  const structPreviewNet = Math.max(
    0,
    Number(structForm.basicSalary || 0) +
      Number(structForm.houseAllowance || 0) +
      Number(structForm.medicalAllowance || 0) +
      Number(structForm.transportAllowance || 0) +
      Number(structForm.otherAllowances || 0) -
      Number(structForm.taxDeduction || 0) -
      Number(structForm.otherDeductions || 0)
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Salary &amp; Payroll Management</h2>
          <p className="text-xs text-slate-400">
            Net = Basic + Allowances + Overtime + Bonuses − Deductions. Strict approval &amp; verified bank reference required before disbursement.
          </p>
        </div>
        <div className="inline-flex rounded-lg bg-slate-900 border border-slate-800 p-0.5 text-xs">
          <button
            type="button"
            onClick={() => setSubTab('runs')}
            className={`px-3 py-1.5 rounded-md font-semibold ${subTab === 'runs' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'}`}
          >
            Monthly Payroll &amp; Payslips
          </button>
          <button
            type="button"
            onClick={() => setSubTab('structures')}
            className={`px-3 py-1.5 rounded-md font-semibold ${subTab === 'structures' ? 'bg-amber-500 text-slate-950' : 'text-slate-300'}`}
          >
            Salary Structures ({structures.length})
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-slate-400">Gross Payroll</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">
            PKR {Number(summary.totalGross || 0).toLocaleString()}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-amber-400">Net Payable</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">
            PKR {Number(summary.totalNet || 0).toLocaleString()}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-emerald-400">Verified Disbursed</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">
            PKR {Number(summary.paidTotal || 0).toLocaleString()}
          </div>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-cyan-400">Pending Approvals</div>
          <div className="text-xl font-bold text-white font-mono tabular-nums mt-1">{summary.pendingApprovalCount ?? 0}</div>
        </div>
      </div>

      {subTab === 'runs' ? (
        <>
          {scope.canProcessPayroll && (
            <form onSubmit={handleProcessPayroll} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">Generate Monthly Payroll Run</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Pay Period</label>
                  <input
                    type="month"
                    value={runForm.payPeriod}
                    onChange={(e) => setRunForm({ ...runForm, payPeriod: e.target.value })}
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Target Scope</label>
                  <select
                    value={runForm.employeeId}
                    onChange={(e) => setRunForm({ ...runForm, employeeId: e.target.value })}
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  >
                    <option value="">All Eligible Active Employees (Batch)</option>
                    {employees
                      .filter((e) => e.status === 'Active')
                      .map((e) => (
                        <option key={e.id} value={e.id}>
                          {e.employeeCode} — {e.fullName}
                        </option>
                      ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Overtime Pay (blank = auto)</label>
                  <input
                    type="number"
                    min="0"
                    value={runForm.overtimePayment}
                    onChange={(e) => setRunForm({ ...runForm, overtimePayment: e.target.value })}
                    placeholder="Auto from attendance"
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Performance Bonus</label>
                  <input
                    type="number"
                    min="0"
                    value={runForm.bonuses}
                    onChange={(e) => setRunForm({ ...runForm, bonuses: e.target.value })}
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Advance Salary Recovery</label>
                  <input
                    type="number"
                    min="0"
                    value={runForm.advanceSalary}
                    onChange={(e) => setRunForm({ ...runForm, advanceSalary: e.target.value })}
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end">
                <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs">
                  Process Payroll Run
                </button>
              </div>
            </form>
          )}

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <input
              type="month"
              value={payPeriod === 'ALL' ? '' : payPeriod}
              onChange={(e) => setPayPeriod(e.target.value || 'ALL')}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            />
            <button
              type="button"
              onClick={() => setPayPeriod('ALL')}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
            >
              All Periods
            </button>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Statuses</option>
              <option value="Pending Approval">Pending Approval</option>
              <option value="Approved">Approved</option>
              <option value="Paid">Paid</option>
              <option value="Pending">Unpaid</option>
            </select>
          </div>

          <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Period</th>
                  <th className="py-2.5 px-3">Employee</th>
                  <th className="py-2.5 px-3 text-right">Basic</th>
                  <th className="py-2.5 px-3 text-right">Allow + OT + Bonus</th>
                  <th className="py-2.5 px-3 text-right">Deductions</th>
                  <th className="py-2.5 px-3 text-right">Net Payable</th>
                  <th className="py-2.5 px-3">Approval &amp; Payment</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      Loading payroll records...
                    </td>
                  </tr>
                ) : records.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      No payroll records match the current filter.
                    </td>
                  </tr>
                ) : (
                  records.map((r) => {
                    const addOns = Number(r.allowances || 0) + Number(r.overtime_payment || 0) + Number(r.bonuses || 0);
                    const totalDed = Number(r.tax_deduction || 0) + Number(r.other_deductions || 0) + Number(r.advance_salary || 0);
                    return (
                      <tr key={r.id} className="hover:bg-slate-950/60">
                        <td className="py-2.5 px-3 font-mono tabular-nums text-white">{r.pay_period}</td>
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-white">{r.full_name}</div>
                          <div className="text-[11px] font-mono text-amber-400">{r.employee_code}</div>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">
                          {Number(r.basic_salary || r.base_salary || 0).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-400">+{addOns.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-400">-{totalDed.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-white">
                          {r.currency} {Number(r.net_salary || 0).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3">
                          <div
                            className={`font-semibold ${
                              r.approval_status === 'Approved'
                                ? 'text-emerald-400'
                                : r.approval_status === 'Rejected'
                                ? 'text-rose-400'
                                : 'text-amber-400'
                            }`}
                          >
                            {r.approval_status}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {r.payment_status === 'Paid' ? `Paid (${r.verified_payment_ref || r.bank_reference})` : 'Unpaid'}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            {scope.canApprovePayroll && r.approval_status === 'Pending Approval' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleApprove(r.id, 'Approved')}
                                  className="px-2 py-1 rounded bg-emerald-600 text-white font-semibold"
                                >
                                  Approve
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleApprove(r.id, 'Rejected')}
                                  className="px-2 py-1 rounded bg-rose-700 text-white font-semibold"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                            {scope.canPayPayroll && r.approval_status === 'Approved' && r.payment_status !== 'Paid' && (
                              <button
                                type="button"
                                onClick={() => setPayingRecord(r)}
                                className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold"
                              >
                                Record Payment
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleDownloadPayslip(r)}
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white font-semibold inline-flex items-center gap-1"
                            >
                              <Download className="w-3 h-3" /> PDF
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-2.5 px-3">Employee</th>
                <th className="py-2.5 px-3 text-right">Basic</th>
                <th className="py-2.5 px-3 text-right">House</th>
                <th className="py-2.5 px-3 text-right">Medical</th>
                <th className="py-2.5 px-3 text-right">Transport</th>
                <th className="py-2.5 px-3 text-right">Tax &amp; Ded</th>
                <th className="py-2.5 px-3">Bank Account</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {structures.map((s) => (
                <tr key={s.id} className="hover:bg-slate-950/60">
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white">{s.full_name}</div>
                    <div className="text-[11px] font-mono text-amber-400">{s.employee_code}</div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-white">{Number(s.basic_salary || 0).toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{Number(s.house_allowance || 0).toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{Number(s.medical_allowance || 0).toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-300">{Number(s.transport_allowance || 0).toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-400">
                    -{(Number(s.tax_deduction || 0) + Number(s.other_deductions || 0)).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">{s.bank_name || 'Unassigned'}</td>
                  <td className="py-2.5 px-3 text-right">
                    {scope.canProcessPayroll && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingStruct(s);
                          setStructForm({
                            basicSalary: String(s.basic_salary ?? 0),
                            houseAllowance: String(s.house_allowance ?? 0),
                            medicalAllowance: String(s.medical_allowance ?? 0),
                            transportAllowance: String(s.transport_allowance ?? 0),
                            otherAllowances: String(s.other_allowances ?? 0),
                            taxDeduction: String(s.tax_deduction ?? 0),
                            otherDeductions: String(s.other_deductions ?? 0),
                            currency: s.currency || 'PKR',
                            bankName: s.bank_name || '',
                            bankAccountTitle: s.bank_account_title || '',
                            bankIban: s.bank_iban || '',
                            notes: '',
                          });
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white font-semibold"
                      >
                        Configure
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editingStruct && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4">
          <form onSubmit={handleSaveStructure} className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">
                Salary Structure — {editingStruct.full_name} ({editingStruct.employee_code})
              </h3>
              <span className="font-mono font-bold text-amber-400">
                Net Baseline: {structForm.currency} {structPreviewNet.toLocaleString()}
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                ['basicSalary', 'Basic Salary'],
                ['houseAllowance', 'House Allowance'],
                ['medicalAllowance', 'Medical Allowance'],
                ['transportAllowance', 'Transport Allowance'],
                ['otherAllowances', 'Other Allowances'],
                ['taxDeduction', 'Tax Deduction'],
                ['otherDeductions', 'Other Deductions'],
              ].map(([k, label]) => (
                <div key={k}>
                  <label className="block text-slate-400 mb-1">{label}</label>
                  <input
                    type="number"
                    min="0"
                    value={(structForm as any)[k]}
                    onChange={(e) => setStructForm({ ...structForm, [k]: e.target.value })}
                    className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-1.5 text-white font-mono"
                  />
                </div>
              ))}
              <div>
                <label className="block text-slate-400 mb-1">Bank Name</label>
                <input
                  type="text"
                  value={structForm.bankName}
                  onChange={(e) => setStructForm({ ...structForm, bankName: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">IBAN / Account No.</label>
                <input
                  type="text"
                  value={structForm.bankIban}
                  onChange={(e) => setStructForm({ ...structForm, bankIban: e.target.value })}
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-1.5 text-white font-mono"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setEditingStruct(null)} className="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 text-slate-950 font-bold">
                Save Structure
              </button>
            </div>
          </form>
        </div>
      )}

      {payingRecord && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4">
          <form onSubmit={handleConfirmPayment} className="w-full max-w-md rounded-2xl bg-slate-900 border border-amber-500/40 p-5 space-y-4 text-xs">
            <h3 className="text-sm font-bold text-white">Verify Bank Disbursement</h3>
            <p className="text-slate-300">
              Recording salary payment of{' '}
              <span className="font-mono font-bold text-amber-400">
                {payingRecord.currency} {Number(payingRecord.net_salary || 0).toLocaleString()}
              </span>{' '}
              for {payingRecord.full_name} ({payingRecord.pay_period}). Verified bank transfer reference is mandatory.
            </p>
            <div>
              <label className="block text-slate-400 mb-1">Verified Bank Transfer / IBFT Reference *</label>
              <input
                type="text"
                required
                minLength={4}
                value={paymentForm.bankReference}
                onChange={(e) => setPaymentForm({ ...paymentForm, bankReference: e.target.value })}
                placeholder="e.g. IBFT-HBL-2026-88412"
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Disbursement Date</label>
              <input
                type="date"
                required
                value={paymentForm.paymentDate}
                onChange={(e) => setPaymentForm({ ...paymentForm, paymentDate: e.target.value })}
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPayingRecord(null)} className="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold">
                Confirm &amp; Mark Paid
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// LEAVE MANAGEMENT PANEL
// ============================================================================
export const LeaveManagementPanel: React.FC<SubPanelProps> = ({
  scope,
  employees,
  leaveTypes,
  onNotify,
  onRefreshDashboard,
}) => {
  const [requests, setRequests] = useState<any[]>([]);
  const [balances, setBalances] = useState<any[]>([]);
  const [deptSummary, setDeptSummary] = useState<any[]>([]);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [loading, setLoading] = useState(false);

  const [leaveForm, setLeaveForm] = useState({
    employeeId: scope.selfEmployeeId || '',
    leaveType: leaveTypes[0] || 'Annual Leave',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    reason: '',
  });
  const [supportFile, setSupportFile] = useState<File | null>(null);

  const loadLeaves = async () => {
    setLoading(true);
    try {
      const res = await api.getEmpMgmtLeaves({ status: statusFilter !== 'ALL' ? statusFilter : undefined });
      setRequests(res.requests || []);
      setBalances(res.balances || []);
      setDeptSummary(res.departmentSummary || []);
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to load leave records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLeaves();
  }, [statusFilter]);

  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      if (leaveForm.employeeId) fd.append('employeeId', leaveForm.employeeId);
      fd.append('leaveType', leaveForm.leaveType);
      fd.append('startDate', leaveForm.startDate);
      fd.append('endDate', leaveForm.endDate);
      fd.append('reason', leaveForm.reason);
      if (supportFile) fd.append('supportingDocument', supportFile);
      const res = await api.submitEmpMgmtLeave(fd);
      onNotify('success', `Leave application submitted (${res.totalDays} day(s)).`);
      setLeaveForm((p) => ({ ...p, reason: '' }));
      setSupportFile(null);
      loadLeaves();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Failed to submit leave request.');
    }
  };

  const handleDecide = async (id: string, decision: 'Approved' | 'Rejected') => {
    const note = decision === 'Rejected' ? 'Declined after manager schedule review' : 'Approved by authorized manager';
    try {
      await api.decideEmpMgmtLeave(id, decision, note);
      onNotify('success', `Leave request ${decision.toLowerCase()}.`);
      loadLeaves();
      onRefreshDashboard();
    } catch (err: any) {
      onNotify('error', err?.message || 'Leave decision failed.');
    }
  };

  const handleOpenDoc = async (docId: string) => {
    try {
      const { blob, filename } = await api.downloadEmpMgmtBlob(`/api/employee-management/documents/${encodeURIComponent(docId)}/download`);
      triggerBlobDownload(blob, filename);
    } catch (err: any) {
      onNotify('error', err?.message || 'Unable to download supporting document.');
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-white">Leave Management</h2>
          <p className="text-xs text-slate-400">
            Supports Annual, Casual, Sick, Emergency, Unpaid, Maternity &amp; Approved Leaves with balance enforcement and self-approval blocks.
          </p>
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-lg bg-slate-900 border border-slate-800 px-3 py-1.5 text-xs text-white"
        >
          <option value="ALL">All Requests</option>
          <option value="Pending">Pending Approval</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
        </select>
      </div>

      {/* Leave Application Form (shown for employees or authorized managers submitting on behalf) */}
      {(scope.canApplyLeave || scope.canManageProfiles) && (
        <form onSubmit={handleSubmitLeave} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="font-bold text-amber-400 uppercase tracking-wider">Submit Leave Application</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {!scope.selfOnly && (
              <select
                value={leaveForm.employeeId}
                onChange={(e) => setLeaveForm({ ...leaveForm, employeeId: e.target.value })}
                className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
                required
              >
                <option value="">Select Employee...</option>
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.employeeCode} — {e.fullName}
                  </option>
                ))}
              </select>
            )}
            <select
              value={leaveForm.leaveType}
              onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            >
              {leaveTypes.map((lt) => (
                <option key={lt} value={lt}>
                  {lt}
                </option>
              ))}
            </select>
            <input
              type="date"
              value={leaveForm.startDate}
              onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              required
            />
            <input
              type="date"
              value={leaveForm.endDate}
              onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
              className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              required
            />
            <input
              type="file"
              onChange={(e) => setSupportFile(e.target.files?.[0] || null)}
              className="rounded-lg bg-slate-950 border border-slate-800 px-2 py-1.5 text-slate-300 file:mr-2 file:rounded file:border-0 file:bg-slate-800 file:px-2 file:py-1 file:text-xs file:text-white"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <input
              type="text"
              required
              minLength={4}
              value={leaveForm.reason}
              onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
              placeholder="Reason for leave request..."
              className="flex-1 min-w-[240px] rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-white"
            />
            <button type="submit" className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
              Submit Leave Request
            </button>
          </div>
        </form>
      )}

      {/* Leave Requests Table */}
      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
            <tr>
              <th className="py-2.5 px-3">Employee</th>
              <th className="py-2.5 px-3">Type &amp; Dates</th>
              <th className="py-2.5 px-3">Days</th>
              <th className="py-2.5 px-3">Reason &amp; Proof</th>
              <th className="py-2.5 px-3">Status &amp; Approver</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  Loading leave requests...
                </td>
              </tr>
            ) : requests.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-400">
                  No leave requests match this filter.
                </td>
              </tr>
            ) : (
              requests.map((r) => (
                <tr key={r.id} className="hover:bg-slate-950/60">
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-white">{r.full_name}</div>
                    <div className="text-[11px] font-mono text-amber-400">{r.employee_code}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-semibold text-slate-200">{r.leave_type}</div>
                    <div className="text-[11px] font-mono tabular-nums text-slate-400">
                      {r.start_date} to {r.end_date}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-mono tabular-nums text-white">{r.total_days}d</td>
                  <td className="py-2.5 px-3 text-slate-300 max-w-xs">
                    <div className="truncate">{r.reason}</div>
                    {r.supporting_doc_id && (
                      <button
                        type="button"
                        onClick={() => handleOpenDoc(r.supporting_doc_id)}
                        className="text-[11px] text-amber-400 hover:underline inline-flex items-center gap-1 mt-0.5"
                      >
                        <FileText className="w-3 h-3" /> Private Supporting Doc
                      </button>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    <div
                      className={`font-semibold ${
                        r.status === 'Approved' ? 'text-emerald-400' : r.status === 'Rejected' ? 'text-rose-400' : 'text-amber-400'
                      }`}
                    >
                      {r.status}
                    </div>
                    {r.reviewed_by_name && <div className="text-[11px] text-slate-400">By {r.reviewed_by_name}</div>}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    {scope.canApproveLeave && r.status === 'Pending' && r.employee_id !== scope.selfEmployeeId && (
                      <div className="inline-flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleDecide(r.id, 'Approved')}
                          className="px-2.5 py-1 rounded bg-emerald-600 text-white font-semibold"
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDecide(r.id, 'Rejected')}
                          className="px-2.5 py-1 rounded bg-rose-700 text-white font-semibold"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Leave Balances & Department Leave Report */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Employee Leave Balances</h3>
          <div className="space-y-1.5 max-h-60 overflow-y-auto">
            {balances.map((b) => (
              <div key={b.employeeId} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div>
                  <span className="font-semibold text-white">{b.fullName}</span>
                  <span className="ml-2 text-[11px] font-mono text-amber-400">{b.employeeCode}</span>
                </div>
                <div className="font-mono tabular-nums text-slate-300">
                  Ann:{b.annual.remaining}/{b.annual.total} • Sick:{b.sick.remaining}/{b.sick.total} • Cas:{b.casual.remaining}/{b.casual.total}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-2.5">
          <h3 className="text-sm font-bold text-white">Department-Wise Leave Report</h3>
          {deptSummary.length === 0 ? (
            <p className="text-slate-400">No leave utilization records yet.</p>
          ) : (
            <div className="space-y-1.5">
              {deptSummary.map((d) => (
                <div key={d.department} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <span className="font-semibold text-white">{d.department}</span>
                  <span className="font-mono tabular-nums text-slate-300">
                    Requests: {d.totalRequests} • Approved Days: {d.approvedDays} • Pending: {d.pending}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
