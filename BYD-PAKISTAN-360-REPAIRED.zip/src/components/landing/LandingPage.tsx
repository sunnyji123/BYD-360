import React, { useState } from 'react';
import {
  Zap,
  ShieldCheck,
  BatteryCharging,
  Gauge,
  ArrowRight,
  CheckCircle,
  Sparkles,
  MapPin,
  Calendar,
  Layers,
  ChevronRight,
  Award,
  Flame,
  FileCheck2,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VehicleModelType, SalesLead } from '../../types';
import { db } from '../../services/db';

const VEHICLES: {
  id: VehicleModelType;
  title: string;
  tagline: string;
  type: string;
  specs: { acceleration: string; range: string; power: string; battery: string };
  pricePkr: string;
  image: string;
  highlights: string[];
}[] = [
  {
    id: 'BYD Seal',
    title: 'BYD Seal',
    tagline: 'Pure Electric Ocean-Aesthetics Sports Sedan',
    type: 'Pure EV (CTB Architecture)',
    specs: {
      acceleration: '3.8s 0-100 km/h',
      range: '570 km WLTP',
      power: '390 kW (523 hp AWD)',
      battery: '82.56 kWh Blade Battery',
    },
    pricePkr: 'Starting from ₨ 14,790,000 PKR',
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1000&q=80',
    highlights: ['Cell-to-Body (CTB) Structural Rigidity', 'Rotating 15.6" DiLink Cockpit', '150 kW DC Fast Charging', 'iTAC Intelligent Torque Adaption'],
  },
  {
    id: 'BYD Atto 3',
    title: 'BYD Atto 3',
    tagline: 'Dynamic Urban Electric Crossover SUV',
    type: 'Pure EV (e-Platform 3.0)',
    specs: {
      acceleration: '7.3s 0-100 km/h',
      range: '420 km WLTP',
      power: '150 kW (201 hp FWD)',
      battery: '60.48 kWh Blade Battery',
    },
    pricePkr: 'Starting from ₨ 8,990,000 PKR',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80',
    highlights: ['Panoramic Sunroof with UV Protection', 'Gym & Guitar-Inspired Interior Trim', '8-Year / 160,000 km Warranty', 'V2L Vehicle-to-Load 3.3kW Power'],
  },
  {
    id: 'BYD Sealion 6',
    title: 'BYD Sealion 6',
    tagline: 'Super DM-i Plug-in Hybrid Luxury SUV',
    type: 'DM-i Super Hybrid (PHEV)',
    specs: {
      acceleration: '5.9s 0-100 km/h',
      range: '1,100+ km Combined',
      power: '238 kW AWD Combined',
      battery: '18.3 kWh Blade Battery',
    },
    pricePkr: 'Starting from ₨ 11,500,000 PKR',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1000&q=80',
    highlights: ['Ultra-Low Fuel Consumption 4.4L/100km', 'Dual Mode Electric-First Architecture', 'Whisper-Quiet NVH Acoustic Glass', 'Long-Distance Intercity Cruiser'],
  },
  {
    id: 'BYD Shark 6',
    title: 'BYD Shark 6',
    tagline: 'DMO Super Hybrid 4WD Utility Truck',
    type: 'DMO Off-Road Super Hybrid',
    specs: {
      acceleration: '5.7s 0-100 km/h',
      range: '840 km Combined',
      power: '320 kW (430 hp Dual-Motor)',
      battery: '29.58 kWh Blade Battery',
    },
    pricePkr: 'Starting from ₨ 19,800,000 PKR',
    image: 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&w=1000&q=80',
    highlights: ['Independent Double Wishbone Suspension', 'Heavy Duty 2,500 kg Towing Capacity', 'Terrain Mode (Sand, Mud, Snow, Rock)', 'Vehicle-to-Load Onsite Generator'],
  },
];

export const LandingPage: React.FC = () => {
  const { setActiveTab } = useApp();
  const [selectedModel, setSelectedModel] = useState<VehicleModelType>('BYD Seal');
  const [testDriveModalOpen, setTestDriveModalOpen] = useState(false);
  const [testDriveSuccess, setTestDriveSuccess] = useState(false);
  const [batteryTab, setBatteryTab] = useState<'nail' | 'lfp' | 'ctb'>('nail');

  // Booking Form State
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: 'Karachi',
    model: 'BYD Seal' as VehicleModelType,
    preferredDate: '',
  });

  const activeVehicle = VEHICLES.find((v) => v.id === selectedModel) || VEHICLES[0];

  const handleTestDriveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    const newLead: SalesLead = {
      id: `lead_${Date.now()}`,
      customerName: formData.name,
      phone: formData.phone,
      email: `${formData.name.toLowerCase().replace(/\s+/g, '.')}@inquiry.pk`,
      city: formData.city,
      interestedModel: formData.model,
      budgetPkr: 15000000,
      dealershipId: 'dlr_khi_clifton',
      source: 'Online Inquiry',
      stage: 'Test Drive Scheduled',
      testDriveDate: formData.preferredDate || '2026-11-20 02:00 PM',
      assignedSalesExec: 'Farhan Zaidi',
      notes: 'Customer booked test drive via BYD Pakistan 360 portal.',
      createdAt: new Date().toISOString(),
    };

    db.addSalesLead(newLead);
    setTestDriveSuccess(true);
    setTimeout(() => {
      setTestDriveSuccess(false);
      setTestDriveModalOpen(false);
      setFormData({ name: '', phone: '', city: 'Karachi', model: 'BYD Seal', preferredDate: '' });
    }, 2200);
  };

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-slate-800 shadow-2xl">
        {/* Glow ambient background elements */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-6 py-16 sm:py-24 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-xs font-semibold text-cyan-300">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>Next-Generation E-Mobility in Pakistan</span>
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>Partnered with Mega Motor Co.</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
              Electrifying Pakistan with <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500 bg-clip-text text-transparent">BYD 360</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Experience the world’s leading New Energy Vehicle ecosystem. Designed with revolutionary <strong>Blade Battery</strong> safety, ultra-fast charging across major Pakistani cities and motorways, and comprehensive 3S customer management.
            </p>

            {/* Metric counters */}
            <div className="grid grid-cols-3 gap-4 pt-2 border-y border-slate-800/80 py-4">
              <div>
                <p className="text-2xl sm:text-3xl font-black text-cyan-400">1,280+</p>
                <p className="text-xs text-slate-400 font-medium">Booked Units in PK</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-black text-white">8 Years</p>
                <p className="text-xs text-slate-400 font-medium">Blade Battery Warranty</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl font-black text-emerald-400">180 kW</p>
                <p className="text-xs text-slate-400 font-medium">M-2 DC Fast Charging</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => setTestDriveModalOpen(true)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-sm shadow-lg shadow-cyan-500/25 hover:from-cyan-400 hover:to-blue-500 transition active:scale-95"
              >
                <span>Book VIP Test Drive</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveTab('customer')}
                className="flex items-center gap-2 px-6 py-3 rounded-xl border border-slate-700 bg-slate-900/80 text-slate-200 font-semibold text-sm hover:border-cyan-500/50 hover:text-white transition"
              >
                <span>Customer Portal</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => setActiveTab('ai-assistant')}
                className="flex items-center gap-2 px-4 py-3 rounded-xl border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 font-semibold text-sm hover:bg-cyan-900/50 transition"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>AI Advisor</span>
              </button>
            </div>
          </div>

          {/* Hero Visual Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl group">
              <img
                src={activeVehicle.image}
                alt={activeVehicle.title}
                className="w-full h-80 sm:h-96 object-cover object-center group-hover:scale-105 transition duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />

              <div className="absolute bottom-0 left-0 right-0 p-6 space-y-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded-md border border-cyan-500/30">
                  {activeVehicle.type}
                </span>
                <h3 className="text-2xl font-bold text-white">{activeVehicle.title}</h3>
                <p className="text-xs text-slate-300">{activeVehicle.tagline}</p>
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                  <span className="text-xs font-semibold text-cyan-300">{activeVehicle.specs.acceleration}</span>
                  <span className="text-xs font-semibold text-white">{activeVehicle.specs.range}</span>
                  <span className="text-xs font-bold text-slate-200">{activeVehicle.pricePkr}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Model Selection Showcase */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-cyan-400 tracking-wider uppercase">BYD Pakistan Lineup</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Select Your New Energy Vehicle</h2>
            <p className="text-xs sm:text-sm text-slate-400">Engineered for Pakistani terrain, climate resilience, and zero-emission luxury.</p>
          </div>

          {/* Model Selector Buttons */}
          <div className="flex flex-wrap gap-2">
            {VEHICLES.map((v) => (
              <button
                key={v.id}
                onClick={() => setSelectedModel(v.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                  selectedModel === v.id
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {v.title}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Vehicle Detailed Card */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 lg:p-8 backdrop-blur-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-6 space-y-5">
            <div>
              <span className="px-2.5 py-1 rounded bg-blue-950 text-blue-400 text-xs font-bold border border-blue-800">
                {activeVehicle.type}
              </span>
              <h3 className="text-3xl font-black text-white mt-2">{activeVehicle.title}</h3>
              <p className="text-sm text-slate-300 mt-1">{activeVehicle.tagline}</p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <Gauge className="w-4 h-4 text-cyan-400 mb-1" />
                <p className="text-[10px] text-slate-400">0-100 km/h</p>
                <p className="text-xs sm:text-sm font-bold text-white">{activeVehicle.specs.acceleration}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <BatteryCharging className="w-4 h-4 text-emerald-400 mb-1" />
                <p className="text-[10px] text-slate-400">Driving Range</p>
                <p className="text-xs sm:text-sm font-bold text-white">{activeVehicle.specs.range}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <Zap className="w-4 h-4 text-amber-400 mb-1" />
                <p className="text-[10px] text-slate-400">Powertrain</p>
                <p className="text-xs sm:text-sm font-bold text-white">{activeVehicle.specs.power}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <ShieldCheck className="w-4 h-4 text-blue-400 mb-1" />
                <p className="text-[10px] text-slate-400">Battery Pack</p>
                <p className="text-xs sm:text-sm font-bold text-white">{activeVehicle.specs.battery}</p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Key Engineering Advantages:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                {activeVehicle.highlights.map((h, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
                    <span>{h}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 flex flex-wrap items-center gap-3">
              <button
                onClick={() => {
                  setFormData((prev) => ({ ...prev, model: activeVehicle.id }));
                  setTestDriveModalOpen(true);
                }}
                className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm transition shadow-lg shadow-cyan-500/20"
              >
                Schedule Test Drive
              </button>
              <button
                onClick={() => setActiveTab('battery')}
                className="px-5 py-2.5 rounded-xl border border-slate-700 bg-slate-950 hover:bg-slate-900 text-slate-200 font-semibold text-xs sm:text-sm transition"
              >
                Inspect Blade Battery
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-slate-800 relative">
            <img
              src={activeVehicle.image}
              alt={activeVehicle.title}
              className="w-full h-80 sm:h-96 object-cover"
            />
            <div className="absolute top-4 right-4 px-3 py-1.5 rounded-xl bg-slate-950/80 backdrop-blur-md border border-slate-700 text-xs font-bold text-cyan-300">
              {activeVehicle.pricePkr}
            </div>
          </div>
        </div>
      </section>

      {/* Blade Battery Technology Spotlight */}
      <section className="rounded-3xl border border-cyan-500/30 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Zap className="w-64 h-64 text-cyan-400" />
        </div>

        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/40 text-xs font-bold text-cyan-300">
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>BYD Proprietary Safety Innovation</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
            The World’s Safest EV Battery: <span className="text-cyan-400">BYD Blade Battery</span>
          </h2>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            While traditional ternary lithium batteries can suffer thermal runaway reaching over 500°C under mechanical damage, the BYD Blade Battery uses <strong>Lithium Iron Phosphate (LFP)</strong> chemistry in a long, structural cell matrix that easily passes the stringent <strong>Nail Penetration Test</strong> with zero smoke and zero fire.
          </p>

          {/* Interactive Technology Tabs */}
          <div className="flex border-b border-slate-800">
            <button
              onClick={() => setBatteryTab('nail')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition ${
                batteryTab === 'nail'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Nail Penetration Safety Test
            </button>
            <button
              onClick={() => setBatteryTab('lfp')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition ${
                batteryTab === 'lfp'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              LFP Chemistry & Thermal Stability
            </button>
            <button
              onClick={() => setBatteryTab('ctb')}
              className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition ${
                batteryTab === 'ctb'
                  ? 'border-cyan-400 text-cyan-300 bg-cyan-950/30'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Cell-to-Body (CTB) Integration
            </button>
          </div>

          {/* Tab Content Display */}
          <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs sm:text-sm text-slate-300 space-y-3">
            {batteryTab === 'nail' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-cyan-400 font-bold">
                  <Flame className="w-4 h-4 text-cyan-400" />
                  <span>Mount Everest of Battery Safety Testing:</span>
                </div>
                <p>
                  During the nail penetration test, a 5mm steel nail is driven directly through the charged battery cell. Conventional NCM ternary batteries instantly exceed 500°C and violently combust. The BYD Blade Battery surface temperature remains between <strong>30°C and 60°C</strong> with no flames or smoke.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400">Peak Temp in Nail Test</span>
                    <p className="text-base font-extrabold text-emerald-400">30°C – 60°C</p>
                  </div>
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400">Crush Test Resistance</span>
                    <p className="text-base font-extrabold text-cyan-400">46-Ton Truck Roll</p>
                  </div>
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400">Fleet Thermal Incidents</span>
                    <p className="text-base font-extrabold text-blue-400">Zero Spontaneous</p>
                  </div>
                </div>
              </div>
            )}

            {batteryTab === 'lfp' && (
              <div className="space-y-2">
                <p className="font-semibold text-white">High Thermal Decomposition Threshold:</p>
                <p>
                  Lithium Iron Phosphate (LFP) only begins thermal decomposition at temperatures above 500°C, compared to 200°C for nickel-cobalt-manganese chemistries. LFP does not release oxygen during high-stress conditions, eliminating the internal fuel that drives battery fires.
                </p>
                <p className="text-cyan-300 font-medium">
                  Ideal for Pakistani summer temperatures reaching 45°C+ in Sindh and Punjab, maintaining active cooling stability without degradation.
                </p>
              </div>
            )}

            {batteryTab === 'ctb' && (
              <div className="space-y-2">
                <p className="font-semibold text-white">Blade Battery as Structural Vehicle Floor:</p>
                <p>
                  In the BYD Seal, the Blade Battery pack is integrated directly into the car chassis via Cell-to-Body (CTB) technology. Rather than carrying heavy deadweight casing, each blade cell serves as a structural crossbeam, resulting in a phenomenal torsional rigidity of <strong>40,500 N·m/deg</strong> — rivaling multi-million dollar supercars.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Nationwide Pakistan Network */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-cyan-400 tracking-wider uppercase">Nationwide Infrastructure</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Pakistan 3S Dealerships & Charging Grid</h2>
          <p className="text-xs sm:text-sm text-slate-400">Full sales, certified service, warranty coverage, and high-speed DC highway corridors.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-cyan-400" />
            </div>
            <h4 className="text-lg font-bold text-white">Karachi & Sindh</h4>
            <p className="text-xs text-slate-400">Mega Motor Clifton 3S Flagship Centre & Shahrah-e-Faisal Experience Studio. 6 service bays, 180kW Hubco Fast Charger.</p>
            <button
              onClick={() => setActiveTab('dealer')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>View Karachi 3S Hub</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-blue-400" />
            </div>
            <h4 className="text-lg font-bold text-white">Lahore & Punjab</h4>
            <p className="text-xs text-slate-400">BYD Lahore Central Gulberg III & DHA Phase 5. Liquid-cooled 240kW ultra-fast terminal and certified EV Master Techs.</p>
            <button
              onClick={() => setActiveTab('dealer')}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>View Lahore 3S Hub</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center">
              <Zap className="w-5 h-5 text-emerald-400" />
            </div>
            <h4 className="text-lg font-bold text-white">Motorways & Capital</h4>
            <p className="text-xs text-slate-400">M-2 Motorway Bhera & Sukheke fast charging corridors linking Islamabad Blue Area Hub to Lahore in under 3.5 hours.</p>
            <button
              onClick={() => setActiveTab('charging')}
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <span>Explore Charging Map</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Test Drive Modal */}
      {testDriveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 sm:p-8 text-slate-100 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-1">Book a VIP BYD Test Drive</h3>
            <p className="text-xs text-slate-400 mb-5">Experience zero-emission performance with an authorized BYD product specialist.</p>

            {testDriveSuccess ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-white">Test Drive Reserved!</h4>
                <p className="text-xs text-slate-300">
                  A sales consultant from your nearest BYD dealership will contact you at {formData.phone} to confirm timing.
                </p>
              </div>
            ) : (
              <form onSubmit={handleTestDriveSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Asad Qureshi"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number (Pakistan)</label>
                    <input
                      type="tel"
                      required
                      placeholder="+92 300 1234567"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">City</label>
                    <select
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="Karachi">Karachi (Clifton / Faisal)</option>
                      <option value="Lahore">Lahore (Gulberg / DHA)</option>
                      <option value="Islamabad">Islamabad (Blue Area)</option>
                      <option value="Faisalabad">Faisalabad (Canal Rd)</option>
                      <option value="Multan">Multan</option>
                      <option value="Peshawar">Peshawar</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Select Model</label>
                    <select
                      value={formData.model}
                      onChange={(e) => setFormData({ ...formData, model: e.target.value as VehicleModelType })}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="BYD Seal">BYD Seal (Sedan)</option>
                      <option value="BYD Atto 3">BYD Atto 3 (SUV)</option>
                      <option value="BYD Sealion 6">BYD Sealion 6 (DM-i Hybrid)</option>
                      <option value="BYD Shark 6">BYD Shark 6 (Pickup)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Preferred Date</label>
                    <input
                      type="date"
                      value={formData.preferredDate}
                      onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setTestDriveModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-xs text-white shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500"
                  >
                    Confirm Booking
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
