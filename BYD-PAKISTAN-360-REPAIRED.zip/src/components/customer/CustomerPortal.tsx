import React, { useState, useEffect, useCallback } from 'react';
import {
  Car,
  Wrench,
  Shield,
  Calendar,
  AlertCircle,
  FileText,
  Battery,
  CheckCircle2,
  Download,
  User,
  Lock,
  LogOut,
  Heart,
  MessageSquare,
  CreditCard,
  Bell,
  HelpCircle,
  Search,
  RefreshCw,
  Upload,
  KeyRound,
  History,
  Monitor,
  Trash2,
  Mail,
  Send,
  Plus,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';

type CustomerTab =
  | 'overview'
  | 'explore'
  | 'inquiries'
  | 'test-drives'
  | 'bookings'
  | 'payments'
  | 'vehicles'
  | 'warranty'
  | 'documents'
  | 'profile';

type AuthGateMode = 'login' | 'register' | 'verify-email' | 'forgot-password';

const COUNTRY_OPTIONS = [
  { code: 'PK', label: 'Pakistan (PK)' },
  { code: 'AE', label: 'United Arab Emirates (AE)' },
  { code: 'SA', label: 'Saudi Arabia (SA)' },
  { code: 'GB', label: 'United Kingdom (GB)' },
  { code: 'DE', label: 'Germany (DE)' },
];

export const CustomerPortal: React.FC = () => {
  const {
    currentUser,
    isAuthenticated,
    loginUser,
    logoutUser,
    refreshSession,
    formatPrice,
    customerAuthInitialMode,
    setActiveTab,
  } = useApp();

  const isCustomerLoggedIn = isAuthenticated && currentUser.subjectType === 'customer';

  // Gate Auth State
  const [authMode, setAuthMode] = useState<AuthGateMode>(customerAuthInitialMode || 'login');
  const [portalStatus, setPortalStatus] = useState<{
    customersCount: number;
    smsConfigured: boolean;
    smtpConfigured: boolean;
    paymentGatewayConfigured: boolean;
  } | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');

  // Login inputs
  const [loginId, setLoginId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Registration inputs
  const [regForm, setRegForm] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    country: 'PK',
    city: 'Karachi',
    address: '',
    cnicOrId: '',
    password: '',
    confirmPassword: '',
    termsAccepted: false,
    privacyAccepted: false,
  });
  const [verifyEmail, setVerifyEmail] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [verifyTokenInput, setVerifyTokenInput] = useState('');
  const [outboxOtp, setOutboxOtp] = useState<string | null>(null);
  const [outboxToken, setOutboxToken] = useState<string | null>(null);

  // Forgot / Reset password
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [resetStep, setResetStep] = useState<'request' | 'confirm'>('request');

  // Workspace State
  const [custTab, setCustTab] = useState<CustomerTab>('overview');
  const [wsLoading, setWsLoading] = useState(false);
  const [banner, setBanner] = useState<{ text: string; type: 'ok' | 'err' } | null>(null);

  const [dashboard, setDashboard] = useState<any>(null);
  const [exploreData, setExploreData] = useState<{
    vehicles: any[];
    showrooms: any[];
    serviceDealerships: any[];
  } | null>(null);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [testDrives, setTestDrives] = useState<any[]>([]);
  const [bookingsData, setBookingsData] = useState<{ bookings: any[]; documents: any[] } | null>(null);
  const [paymentsData, setPaymentsData] = useState<{
    payments: any[];
    invoices: any[];
    paymentGatewayConfigured: boolean;
  } | null>(null);
  const [myVehicles, setMyVehicles] = useState<any[]>([]);
  const [serviceData, setServiceData] = useState<{ serviceRequests: any[]; serviceHistory: any[] } | null>(null);
  const [warrantyData, setWarrantyData] = useState<{
    warranties: any[];
    claims: any[];
    warrantyServiceHistory: any[];
  } | null>(null);
  const [documents, setDocuments] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [profileData, setProfileData] = useState<any>(null);

  // Search/Filter for Explore
  const [exploreQuery, setExploreQuery] = useState('');
  const [exploreCity, setExploreCity] = useState('');
  const [exploreAvail, setExploreAvail] = useState('');

  // Quick Action Forms
  const [inqForm, setInqForm] = useState({
    inventoryId: '',
    dealerId: '',
    vehicleModel: 'BYD Seal',
    variant: 'Performance AWD',
    inquiryType: 'Price Quote',
    subject: '',
    message: '',
    preferredContact: 'Email',
  });

  const [tdForm, setTdForm] = useState({
    dealerId: '',
    inventoryId: '',
    vehicleModel: 'BYD Seal',
    variant: 'Performance AWD',
    preferredDate: '2026-11-28',
    preferredTime: '11:00 AM',
    city: 'Karachi',
    notes: '',
  });
  const [rescheduleTarget, setRescheduleTarget] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState('2026-12-02');
  const [rescheduleTime, setRescheduleTime] = useState('02:30 PM');

  const [bookingNotes, setBookingNotes] = useState<Record<string, string>>({});
  const [uploadState, setUploadState] = useState<{
    bookingId: string;
    docCategory: string;
    docTitle: string;
    file: File | null;
  }>({
    bookingId: '',
    docCategory: 'Payment Proof',
    docTitle: 'Bank Transfer Receipt',
    file: null,
  });

  const [regVehicleForm, setRegVehicleForm] = useState({
    vin: '',
    model: 'BYD Seal',
    variant: 'Dynamic',
    licensePlate: '',
    color: 'Arctic White',
    modelYear: 2026,
    dealershipName: '',
  });

  const [svcForm, setSvcForm] = useState({
    customerVehicleId: '',
    dealershipId: '',
    serviceType: 'Routine 10,000 km EV Inspection',
    preferredDate: '2026-12-04',
    preferredTime: '10:30 AM',
    complaintDetails: '',
  });

  const [claimForm, setClaimForm] = useState({
    warrantyRecordId: '',
    dealershipName: '',
    componentCategory: 'Blade Battery Pack',
    issueDescription: '',
    faultCode: '',
  });

  const [ticketForm, setTicketForm] = useState({
    category: 'Account & Verification',
    priority: 'Normal',
    subject: '',
    description: '',
  });

  // Profile & Security Form State
  const [profileEdit, setProfileEdit] = useState({
    fullName: '',
    email: '',
    mobile: '',
    country: 'PK',
    city: '',
    address: '',
    cnicOrId: '',
    emergencyContact: '',
    preferredLanguage: 'en',
    preferredCurrency: 'PKR',
    emailAlerts: true,
    smsAlerts: false,
    serviceReminders: true,
  });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [deletionReason, setDeletionReason] = useState('');

  useEffect(() => {
    setAuthMode(customerAuthInitialMode);
  }, [customerAuthInitialMode]);

  useEffect(() => {
    api
      .getCustomerPortalStatus()
      .then((res) => setPortalStatus(res))
      .catch(() => {});
  }, []);

  const flash = (text: string, type: 'ok' | 'err' = 'ok') => {
    setBanner({ text, type });
    setTimeout(() => setBanner(null), 6000);
  };

  const loadTab = useCallback(
    async (tab: CustomerTab, forceExplore = false) => {
      if (!isCustomerLoggedIn) return;
      setWsLoading(true);
      try {
        if (tab === 'overview' || forceExplore) {
          const [dash, exp] = await Promise.all([
            api.getCustomerDashboard(),
            api.exploreCustomerVehicles({ q: exploreQuery, city: exploreCity, availability: exploreAvail }),
          ]);
          setDashboard(dash);
          setExploreData(exp);
          if (exp.showrooms?.[0]?.dealer_id && !tdForm.dealerId) {
            setTdForm((p) => ({ ...p, dealerId: exp.showrooms[0].dealer_id }));
          }
          if (exp.serviceDealerships?.[0]?.id && !svcForm.dealershipId) {
            setSvcForm((p) => ({ ...p, dealershipId: exp.serviceDealerships[0].id }));
          }
        }
        if (tab === 'explore') {
          const [exp, fav] = await Promise.all([
            api.exploreCustomerVehicles({ q: exploreQuery, city: exploreCity, availability: exploreAvail }),
            api.getCustomerFavorites(),
          ]);
          setExploreData(exp);
          setFavorites(fav.favorites || []);
        } else if (tab === 'inquiries') {
          const [res, exp] = await Promise.all([
            api.getCustomerInquiries(),
            exploreData ? Promise.resolve(exploreData) : api.exploreCustomerVehicles(),
          ]);
          setInquiries(res.inquiries || []);
          if (!exploreData) setExploreData(exp);
        } else if (tab === 'test-drives') {
          const [res, exp] = await Promise.all([
            api.getCustomerTestDrives(),
            exploreData ? Promise.resolve(exploreData) : api.exploreCustomerVehicles(),
          ]);
          setTestDrives(res.testDrives || []);
          if (!exploreData) setExploreData(exp);
        } else if (tab === 'bookings') {
          const res = await api.getCustomerBookings();
          setBookingsData(res);
          if (res.bookings?.[0]?.id && !uploadState.bookingId) {
            setUploadState((u) => ({ ...u, bookingId: res.bookings[0].id }));
          }
        } else if (tab === 'payments') {
          const res = await api.getCustomerPayments();
          setPaymentsData(res);
        } else if (tab === 'vehicles') {
          const [veh, svc, exp] = await Promise.all([
            api.getCustomerVehicles(),
            api.getCustomerService(),
            exploreData ? Promise.resolve(exploreData) : api.exploreCustomerVehicles(),
          ]);
          setMyVehicles(veh.vehicles || []);
          setServiceData(svc);
          if (!exploreData) setExploreData(exp);
          if (veh.vehicles?.[0]?.id && !svcForm.customerVehicleId) {
            setSvcForm((p) => ({ ...p, customerVehicleId: veh.vehicles[0].id }));
          }
        } else if (tab === 'warranty') {
          const res = await api.getCustomerWarranty();
          setWarrantyData(res);
          if (res.warranties?.[0]?.id && !claimForm.warrantyRecordId) {
            setClaimForm((p) => ({ ...p, warrantyRecordId: res.warranties[0].id }));
          }
        } else if (tab === 'documents') {
          const [d, n, t] = await Promise.all([
            api.getCustomerDocuments(),
            api.getCustomerNotifications(),
            api.getCustomerSupportTickets(),
          ]);
          setDocuments(d.documents || []);
          setNotifications(n.notifications || []);
          setTickets(t.tickets || []);
        } else if (tab === 'profile') {
          const p = await api.getCustomerProfile();
          setProfileData(p);
          const comms = p.profile?.communicationPrefs || {};
          setProfileEdit({
            fullName: p.account?.fullName || '',
            email: p.account?.email || '',
            mobile: p.account?.mobile || '',
            country: p.account?.country || 'PK',
            city: p.account?.city || '',
            address: p.account?.address || '',
            cnicOrId: p.profile?.cnicOrId || '',
            emergencyContact: p.profile?.emergencyContact || '',
            preferredLanguage: p.profile?.preferredLanguage || 'en',
            preferredCurrency: p.profile?.preferredCurrency || 'PKR',
            emailAlerts: comms.emailUpdates !== false,
            smsAlerts: Boolean(comms.promotionalOffers),
            serviceReminders: comms.serviceReminders !== false,
          });
        }
      } catch (err: any) {
        flash(err?.message || 'Unable to load customer portal data.', 'err');
      } finally {
        setWsLoading(false);
      }
    },
    [isCustomerLoggedIn, exploreQuery, exploreCity, exploreAvail, exploreData, tdForm.dealerId, svcForm.dealershipId, svcForm.customerVehicleId, uploadState.bookingId, claimForm.warrantyRecordId]
  );

  useEffect(() => {
    if (isCustomerLoggedIn) {
      loadTab(custTab);
    }
  }, [isCustomerLoggedIn, custTab]);

  const handleDownloadBlob = async (url: string, fallbackName: string) => {
    try {
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || `Download failed (${res.status})`);
      }
      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objUrl;
      a.download = fallbackName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objUrl);
    } catch (err: any) {
      flash(err?.message || 'Unable to download file.', 'err');
    }
  };

  // =========================================================================
  // AUTH GATE (UNAUTHENTICATED OR NON-CUSTOMER SESSION)
  // =========================================================================
  if (!isCustomerLoggedIn) {
    return (
      <div className="max-w-3xl mx-auto py-8 px-4 space-y-6">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Car className="w-6 h-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
                  BYD PAKISTAN 360 • Dedicated Customer Portal
                </div>
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  Customer Authentication &amp; Vehicle Ownership
                </h1>
              </div>
            </div>
            {portalStatus && (
              <div className="text-[11px] text-slate-400 font-mono text-right">
                <div>Registered Customers: {portalStatus.customersCount}</div>
                <div>SMS OTP: {portalStatus.smsConfigured ? 'Enabled' : 'Not Configured'}</div>
              </div>
            )}
          </div>

          {isAuthenticated && currentUser.subjectType !== 'customer' && (
            <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="font-bold">Isolated Portal Separation Active</div>
                <p className="text-amber-300/90 mt-0.5">
                  You are currently authenticated in a corporate/admin/dealer portal as <strong>{currentUser.name}</strong> ({currentUser.role}). Sign out before signing into a private Customer account.
                </p>
              </div>
              <button
                type="button"
                onClick={logoutUser}
                className="px-3.5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold shrink-0"
              >
                Sign Out Current Session
              </button>
            </div>
          )}

          {/* Mode Tabs */}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'login', label: 'Customer Sign In' },
              { id: 'register', label: 'Register Customer Account' },
              { id: 'verify-email', label: 'Verify Email OTP' },
              { id: 'forgot-password', label: 'Forgot / Reset Password' },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setAuthMode(m.id as AuthGateMode);
                  setAuthError('');
                  setAuthSuccess('');
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition ${
                  authMode === m.id
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {authError && (
            <div className="p-3.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {authSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{authSuccess}</span>
            </div>
          )}

          {/* SIGN IN */}
          {authMode === 'login' && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setAuthError('');
                setAuthSuccess('');
                setAuthLoading(true);
                try {
                  const res = await api.customerLogin({ identifier: loginId.trim(), password: loginPassword });
                  setLoginPassword('');
                  loginUser(res.user);
                  await refreshSession();
                } catch (err: any) {
                  setAuthError(err?.message || 'Customer login failed.');
                  if (String(err?.message || '').toLowerCase().includes('verify your email')) {
                    setVerifyEmail(loginId.trim());
                  }
                } finally {
                  setAuthLoading(false);
                }
              }}
              className="space-y-4 text-xs"
            >
              <div>
                <label className="block font-semibold text-slate-300 mb-1.5">
                  Customer ID, Registered Email, or Mobile Number
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder="CUS-PK-2026-001 or customer@domain.com"
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-slate-300">Password</label>
                  <button
                    type="button"
                    onClick={() => setAuthMode('forgot-password')}
                    className="text-emerald-400 hover:text-emerald-300 font-semibold"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter your customer password"
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black uppercase tracking-wider disabled:opacity-50"
              >
                {authLoading ? 'Signing In...' : 'Sign In to Customer Dashboard'}
              </button>
            </form>
          )}

          {/* REGISTER */}
          {authMode === 'register' && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setAuthError('');
                setAuthSuccess('');
                if (regForm.password !== regForm.confirmPassword) {
                  setAuthError('Password and Confirm Password do not match.');
                  return;
                }
                if (!regForm.termsAccepted || !regForm.privacyAccepted) {
                  setAuthError('You must accept both the Terms of Service and Privacy Policy to register.');
                  return;
                }
                setAuthLoading(true);
                try {
                  const res = await api.customerRegister(regForm);
                  setVerifyEmail(res.customer.email);
                  setOutboxOtp(res.verificationOutbox?.code || null);
                  setOutboxToken(res.verificationOutbox?.verificationToken || null);
                  setAuthSuccess(res.message);
                  setAuthMode('verify-email');
                } catch (err: any) {
                  setAuthError(err?.message || 'Registration failed.');
                } finally {
                  setAuthLoading(false);
                }
              }}
              className="space-y-3.5 text-xs"
            >
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                Your unique Customer ID (<span className="font-mono text-emerald-300">CUS-{regForm.country}-2026-XXXX</span>) is generated server-side upon registration. Email OTP verification is required before portal sign-in.
                {portalStatus && !portalStatus.smsConfigured && (
                  <span className="block mt-1 text-amber-300">
                    Mobile SMS OTP is disabled until an SMS provider (Twilio / SMS_API_KEY) is configured.
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Full Legal Name"
                  value={regForm.fullName}
                  onChange={(e) => setRegForm({ ...regForm, fullName: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <input
                  type="email"
                  required
                  placeholder="Email Address"
                  value={regForm.email}
                  onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <input
                  type="tel"
                  required
                  placeholder="Mobile (+92 300 1234567)"
                  value={regForm.mobile}
                  onChange={(e) => setRegForm({ ...regForm, mobile: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <select
                  value={regForm.country}
                  onChange={(e) => setRegForm({ ...regForm, country: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                >
                  {COUNTRY_OPTIONS.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.label}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  placeholder="City"
                  value={regForm.city}
                  onChange={(e) => setRegForm({ ...regForm, city: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <input
                  type="text"
                  placeholder="CNIC / National ID (Optional)"
                  value={regForm.cnicOrId}
                  onChange={(e) => setRegForm({ ...regForm, cnicOrId: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white font-mono"
                />
              </div>
              <input
                type="text"
                placeholder="Residential Address (Optional)"
                value={regForm.address}
                onChange={(e) => setRegForm({ ...regForm, address: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="password"
                  required
                  placeholder="Password (10+ chars, Aa1!)"
                  value={regForm.password}
                  onChange={(e) => setRegForm({ ...regForm, password: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <input
                  type="password"
                  required
                  placeholder="Confirm Password"
                  value={regForm.confirmPassword}
                  onChange={(e) => setRegForm({ ...regForm, confirmPassword: e.target.value })}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
              </div>

              <div className="space-y-2 rounded-xl bg-slate-950 border border-slate-800 p-3 text-slate-300">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={regForm.termsAccepted}
                    onChange={(e) => setRegForm({ ...regForm, termsAccepted: e.target.checked })}
                    className="mt-0.5"
                  />
                  <span>I accept the BYD PAKISTAN 360 Terms of Service &amp; Digital Ownership Conditions.</span>
                </label>
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={regForm.privacyAccepted}
                    onChange={(e) => setRegForm({ ...regForm, privacyAccepted: e.target.checked })}
                    className="mt-0.5"
                  />
                  <span>I consent to Privacy Policy processing for identity verification, vehicle bookings, and warranty records.</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={authLoading || !regForm.termsAccepted || !regForm.privacyAccepted}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black uppercase tracking-wider disabled:opacity-50"
              >
                {authLoading ? 'Creating Customer Account...' : 'Create Customer Account & Send Email Verification'}
              </button>
            </form>
          )}

          {/* VERIFY EMAIL */}
          {authMode === 'verify-email' && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setAuthError('');
                setAuthSuccess('');
                setAuthLoading(true);
                try {
                  if (verifyTokenInput.trim()) {
                    const res = await api.verifyEmailToken(verifyTokenInput.trim());
                    setAuthSuccess(res.message);
                    setLoginId(res.email || verifyEmail.trim());
                  } else {
                    const res = await api.customerVerifyEmail({ email: verifyEmail.trim(), code: verifyCode.trim() });
                    setAuthSuccess(res.message);
                    setLoginId(verifyEmail.trim());
                  }
                  setVerifyCode('');
                  setVerifyTokenInput('');
                  setOutboxOtp(null);
                  setOutboxToken(null);
                  setAuthMode('login');
                } catch (err: any) {
                  setAuthError(err?.message || 'Verification failed.');
                } finally {
                  setAuthLoading(false);
                }
              }}
              className="space-y-4 text-xs"
            >
              {(outboxOtp || outboxToken) && (
                <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200 font-mono space-y-1 break-all">
                  <div>Local Development Outbox (SMTP not configured):</div>
                  {outboxOtp && <div>6-Digit OTP Code = <strong>{outboxOtp}</strong></div>}
                  {outboxToken && <div className="text-[11px]">Verification Token = <strong>{outboxToken}</strong></div>}
                </div>
              )}
              <input
                type="email"
                required={!verifyTokenInput.trim()}
                placeholder="Customer Registered Email"
                value={verifyEmail}
                onChange={(e) => setVerifyEmail(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
              />
              <input
                type="text"
                maxLength={6}
                placeholder="6-Digit Email OTP"
                value={verifyCode}
                onChange={(e) => setVerifyCode(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-4 py-3 text-center text-lg font-mono tracking-widest text-emerald-300"
              />
              <input
                type="text"
                placeholder="Or paste single-use Email Verification Token"
                value={verifyTokenInput}
                onChange={(e) => setVerifyTokenInput(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={authLoading}
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
                >
                  {authLoading ? 'Verifying...' : 'Verify Email & Activate'}
                </button>
                <button
                  type="button"
                  disabled={!verifyEmail || authLoading}
                  onClick={async () => {
                    setAuthError('');
                    try {
                      const res = await api.resendEmailVerification(verifyEmail.trim());
                      setOutboxOtp(res.verificationOutbox?.code || null);
                      setOutboxToken(res.verificationOutbox?.verificationToken || null);
                      setAuthSuccess(res.message);
                    } catch (err: any) {
                      setAuthError(err?.message || 'Unable to resend verification email.');
                    }
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold"
                >
                  Resend Verification
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD */}
          {authMode === 'forgot-password' && (
            resetStep === 'request' ? (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setAuthError('');
                  setAuthLoading(true);
                  try {
                    const res = await api.customerForgotPassword(forgotIdentifier.trim());
                    setAuthSuccess(res.message);
                    if (res.resetOutbox?.resetToken) {
                      setResetToken(res.resetOutbox.resetToken);
                      setResetOtp(res.resetOutbox.otpCode);
                    }
                    setResetStep('confirm');
                  } catch (err: any) {
                    setAuthError(err?.message || 'Password reset request failed.');
                  } finally {
                    setAuthLoading(false);
                  }
                }}
                className="space-y-4 text-xs"
              >
                <input
                  type="text"
                  required
                  placeholder="Registered Customer Email or Customer ID"
                  value={forgotIdentifier}
                  onChange={(e) => setForgotIdentifier(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2.5 text-white"
                />
                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black"
                >
                  Request Customer Password Reset
                </button>
              </form>
            ) : (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setAuthError('');
                  if (resetNewPassword !== resetConfirmPassword) {
                    setAuthError('Passwords do not match.');
                    return;
                  }
                  setAuthLoading(true);
                  try {
                    const res = await api.customerResetPassword({
                      token: resetToken.trim(),
                      otpCode: resetOtp.trim() || undefined,
                      newPassword: resetNewPassword,
                      confirmPassword: resetConfirmPassword,
                    });
                    setAuthSuccess(res.message);
                    setResetStep('request');
                    setAuthMode('login');
                  } catch (err: any) {
                    setAuthError(err?.message || 'Could not reset password.');
                  } finally {
                    setAuthLoading(false);
                  }
                }}
                className="space-y-3 text-xs"
              >
                {resetToken && (
                  <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 font-mono break-all">
                    Local Outbox Token: {resetToken} • OTP: {resetOtp}
                  </div>
                )}
                <input
                  type="text"
                  required
                  placeholder="Reset Token"
                  value={resetToken}
                  onChange={(e) => setResetToken(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                />
                <input
                  type="password"
                  required
                  placeholder="New Strong Password"
                  value={resetNewPassword}
                  onChange={(e) => setResetNewPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="password"
                  required
                  placeholder="Confirm New Password"
                  value={resetConfirmPassword}
                  onChange={(e) => setResetConfirmPassword(e.target.value)}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
                >
                  Confirm Password Reset &amp; Revoke Old Sessions
                </button>
              </form>
            )
          )}
        </div>
      </div>
    );
  }

  const cust = dashboard?.customer || currentUser;
  const metrics = dashboard?.metrics || {};
  const unreadNotifs = notifications.filter((n) => !n.is_read).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono font-bold">
              {cust.customerCode || cust.customer_code || currentUser.customerCode}
            </span>
            <span
              className={`px-2 py-0.5 rounded font-bold border ${
                cust.verificationStatus === 'Verified' || cust.verification_status === 'Verified'
                  ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40'
                  : 'bg-amber-950 text-amber-300 border-amber-500/40'
              }`}
            >
              {cust.verificationStatus || cust.verification_status || 'Pending Verification'}
            </span>
            <span className="text-slate-400 font-mono">
              {cust.city || currentUser.city}, {cust.country || currentUser.country}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white">
            {cust.fullName || cust.full_name || currentUser.name}
          </h1>
          <p className="text-xs text-slate-400">
            BYD PAKISTAN 360 • Authenticated Customer Workspace • {cust.email || currentUser.email}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => loadTab(custTab, true)}
            disabled={wsLoading}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${wsLoading ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
          <button
            type="button"
            onClick={() => setCustTab('explore')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black"
          >
            <Car className="w-3.5 h-3.5" />
            <span>Explore Vehicles</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('charging')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold"
          >
            <Battery className="w-3.5 h-3.5" />
            <span>Chargers</span>
          </button>
          <button
            type="button"
            onClick={logoutUser}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-300 hover:text-white text-xs font-bold"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
        {[
          { id: 'overview', label: 'Overview', icon: User },
          { id: 'explore', label: 'Explore Vehicles', icon: Search },
          { id: 'inquiries', label: 'Inquiries', icon: MessageSquare },
          { id: 'test-drives', label: 'Test Drives', icon: Calendar },
          { id: 'bookings', label: 'Bookings', icon: Car },
          { id: 'payments', label: 'Payments & Invoices', icon: CreditCard },
          { id: 'vehicles', label: 'My Vehicles & Service', icon: Wrench },
          { id: 'warranty', label: 'Warranty & Claims', icon: Shield },
          { id: 'documents', label: `Docs & Support${unreadNotifs > 0 ? ` (${unreadNotifs})` : ''}`, icon: FileText },
          { id: 'profile', label: 'Profile & Security', icon: Lock },
        ].map((t) => {
          const Icon = t.icon;
          const active = custTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setCustTab(t.id as CustomerTab)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold transition ${
                active
                  ? 'bg-emerald-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
            banner.type === 'ok'
              ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/50 border-rose-500/40 text-rose-200'
          }`}
        >
          {banner.type === 'ok' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
          <span>{banner.text}</span>
        </div>
      )}

      {/* TAB 1: OVERVIEW */}
      {custTab === 'overview' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              { label: 'Owned Vehicles', val: metrics.registeredVehicles ?? 0, color: 'text-white' },
              { label: 'Active Bookings', val: metrics.activeBookings ?? 0, color: 'text-cyan-300' },
              { label: 'Test Drives', val: metrics.testDrivesCount ?? 0, color: 'text-emerald-300' },
              { label: 'Service Requests', val: metrics.activeServices ?? 0, color: 'text-amber-300' },
              { label: 'Pending Balance', val: formatPrice(metrics.pendingPaymentsPkr || 0), color: 'text-rose-300' },
              { label: 'Unread Notices', val: metrics.unreadNotifications ?? 0, color: 'text-indigo-300' },
            ].map((k) => (
              <div key={k.label} className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="text-[11px] text-slate-400">{k.label}</div>
                <div className={`text-lg font-black font-mono tabular-nums mt-1 ${k.color}`}>{k.val}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-emerald-400" />
                <span>Customer Notifications</span>
              </h3>
              {(dashboard?.notifications || []).length === 0 ? (
                <p className="text-slate-400">No recent notifications.</p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {(dashboard?.notifications || []).map((n: any) => (
                    <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-white">{n.title}</span>
                        <span className="text-[10px] font-mono text-slate-500">{n.created_at?.slice(0, 10)}</span>
                      </div>
                      <p className="text-slate-300">{n.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-cyan-400" />
                <span>Recent Account Activity</span>
              </h3>
              {(dashboard?.recentActivity || []).length === 0 ? (
                <p className="text-slate-400">No recorded activity yet.</p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {(dashboard?.recentActivity || []).map((a: any) => (
                    <div key={a.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-semibold text-white">{a.action}</div>
                        <div className="text-[11px] text-slate-400">{a.details}</div>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500 shrink-0">{a.created_at?.slice(0, 16).replace('T', ' ')}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {(dashboard?.ownershipTransfers || []).length > 0 && (
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Verified Title &amp; Ownership Transfers</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {dashboard.ownershipTransfers.map((tr: any) => (
                  <div key={tr.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <div className="font-bold text-white">{tr.vehicle_model} • <span className="font-mono text-cyan-300">{tr.vin}</span></div>
                    <div className="text-slate-400 mt-1">
                      Previous Owner: {tr.previous_owner_name} &rarr; New Owner: {tr.new_owner_name} ({tr.status})
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: EXPLORE VEHICLES */}
      {custTab === 'explore' && (
        <div className="space-y-6 text-xs">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={exploreQuery}
                onChange={(e) => setExploreQuery(e.target.value)}
                placeholder="Search BYD model, trim, color, showroom..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              />
            </div>
            <input
              type="text"
              value={exploreCity}
              onChange={(e) => setExploreCity(e.target.value)}
              placeholder="City filter"
              className="w-36 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
            />
            <select
              value={exploreAvail}
              onChange={(e) => setExploreAvail(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
            >
              <option value="">All Stock States</option>
              <option value="Available">Available</option>
              <option value="In Transit">In Transit</option>
            </select>
            <button
              type="button"
              onClick={() => loadTab('explore')}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
            >
              Filter Catalog
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(exploreData?.vehicles || []).map((v: any) => {
              const isFav = favorites.some((f) => f.inventory_id === v.inventoryId);
              const price = Number(v.officialPricePkr || 0);
              return (
                <div key={v.inventoryId} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                          {v.showroomName} • {v.showroomCity}
                        </span>
                        <h3 className="text-base font-black text-white">{v.model}</h3>
                        <p className="text-slate-300">{v.variant} • {v.exteriorColor} ({v.modelYear})</p>
                      </div>
                      <button
                        type="button"
                        onClick={async () => {
                          if (isFav) {
                            await api.removeCustomerFavorite(v.inventoryId);
                            setFavorites((prev) => prev.filter((x) => x.inventory_id !== v.inventoryId));
                          } else {
                            await api.addCustomerFavorite(v.inventoryId);
                            const fav = await api.getCustomerFavorites();
                            setFavorites(fav.favorites || []);
                          }
                        }}
                        className={`p-2 rounded-xl border ${
                          isFav
                            ? 'bg-rose-950/60 border-rose-500/40 text-rose-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                        title={isFav ? 'Remove from Favorites' : 'Save to Favorites'}
                      >
                        <Heart className="w-4 h-4" />
                      </button>
                    </div>

                    {v.specs && (
                      <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 grid grid-cols-2 gap-1.5 font-mono">
                        <div>Battery: {v.specs.batteryCapacity}</div>
                        <div>Range: {v.specs.rangeRating}</div>
                        <div>Drive: {v.specs.drivetrain}</div>
                        <div>Stock: {v.availabilityStatus}</div>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Approved Showroom Price</span>
                      <span className="text-sm font-black font-mono text-emerald-300">
                        {price > 0 ? formatPrice(price) : 'Price on Request'}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setInqForm((p) => ({
                            ...p,
                            inventoryId: v.inventoryId,
                            dealerId: v.dealerId,
                            vehicleModel: v.model,
                            variant: v.variant,
                            subject: `Inquiry: ${v.model} ${v.variant}`,
                          }));
                          setCustTab('inquiries');
                        }}
                        className="py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold"
                      >
                        Inquire
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTdForm((p) => ({
                            ...p,
                            inventoryId: v.inventoryId,
                            dealerId: v.dealerId,
                            vehicleModel: v.model,
                            variant: v.variant,
                            city: v.showroomCity,
                          }));
                          setCustTab('test-drives');
                        }}
                        className="py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                      >
                        Test Drive
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const res = await api.createCustomerBooking({
                              inventoryId: v.inventoryId,
                              exteriorColor: v.exteriorColor,
                              customerNotes: bookingNotes[v.inventoryId] || '',
                            });
                            flash(`Booking ${res.bookingRef} submitted (${res.bookingStatus}). Invoice ${res.invoiceNumber} issued.`);
                            setCustTab('bookings');
                          } catch (err: any) {
                            flash(err?.message || 'Could not create booking.', 'err');
                          }
                        }}
                        className="py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
                      >
                        Book Now
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: INQUIRIES */}
      {custTab === 'inquiries' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.createCustomerInquiry({
                  ...inqForm,
                  inventoryId: inqForm.inventoryId || null,
                  dealerId: inqForm.dealerId || null,
                });
                flash(`Inquiry ${res.inquiryRef} submitted.`);
                setInqForm((p) => ({ ...p, subject: '', message: '' }));
                await loadTab('inquiries');
              } catch (err: any) {
                flash(err?.message || 'Unable to submit inquiry.', 'err');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Send className="w-4 h-4 text-emerald-400" />
              <span>Submit New Vehicle Inquiry</span>
            </h3>
            <input
              type="text"
              required
              placeholder="BYD Model (e.g. BYD Seal)"
              value={inqForm.vehicleModel}
              onChange={(e) => setInqForm({ ...inqForm, vehicleModel: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <select
              value={inqForm.inquiryType}
              onChange={(e) => setInqForm({ ...inqForm, inquiryType: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="Price Quote">Price Quote</option>
              <option value="Availability & Delivery">Availability &amp; Delivery</option>
              <option value="Financing / Fleet">Financing / Fleet</option>
              <option value="Battery & Charging">Battery &amp; Charging</option>
            </select>
            <input
              type="text"
              required
              placeholder="Subject"
              value={inqForm.subject}
              onChange={(e) => setInqForm({ ...inqForm, subject: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <textarea
              rows={4}
              required
              placeholder="Ask about price, delivery lead time, colors, or charger setup..."
              value={inqForm.message}
              onChange={(e) => setInqForm({ ...inqForm, message: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black">
              Send Inquiry
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">My Inquiries ({inquiries.length})</h3>
            {inquiries.length === 0 ? (
              <p className="text-slate-400">No inquiries submitted yet.</p>
            ) : (
              <div className="space-y-3">
                {inquiries.map((inq: any) => (
                  <div key={inq.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-emerald-300 font-bold">{inq.inquiry_ref} • {inq.vehicle_model}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold">{inq.status}</span>
                    </div>
                    <div className="font-bold text-white">{inq.subject}</div>
                    <p className="text-slate-300">{inq.message}</p>
                    {inq.reply_text && (
                      <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-200">
                        <div className="font-bold text-[11px]">Showroom / Advisor Reply:</div>
                        <div>{inq.reply_text}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: TEST DRIVES */}
      {custTab === 'test-drives' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.requestCustomerTestDrive(tdForm);
                flash(`Test drive ${res.requestNumber} scheduled (${res.status}).`);
                setTdForm((p) => ({ ...p, notes: '' }));
                await loadTab('test-drives');
              } catch (err: any) {
                flash(err?.message || 'Unable to book test drive.', 'err');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span>Book Showroom Test Drive</span>
            </h3>
            <select
              required
              value={tdForm.dealerId}
              onChange={(e) => setTdForm({ ...tdForm, dealerId: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              {(exploreData?.showrooms || []).map((s: any) => (
                <option key={s.dealer_id} value={s.dealer_id}>
                  {s.name} ({s.city})
                </option>
              ))}
            </select>
            <input
              type="text"
              required
              placeholder="BYD Model"
              value={tdForm.vehicleModel}
              onChange={(e) => setTdForm({ ...tdForm, vehicleModel: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                required
                value={tdForm.preferredDate}
                onChange={(e) => setTdForm({ ...tdForm, preferredDate: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="text"
                required
                value={tdForm.preferredTime}
                onChange={(e) => setTdForm({ ...tdForm, preferredTime: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <textarea
              rows={2}
              placeholder="Optional preference notes"
              value={tdForm.notes}
              onChange={(e) => setTdForm({ ...tdForm, notes: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black">
              Request Test Drive
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Test Drive Requests ({testDrives.length})</h3>
            {testDrives.map((td: any) => (
              <div key={td.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="font-bold text-white">
                    <span className="font-mono text-cyan-300 mr-2">{td.request_number}</span>
                    {td.vehicle_model} • {td.showroom_name}
                  </div>
                  <span className="px-2.5 py-0.5 rounded bg-slate-800 text-amber-300 font-bold">{td.status}</span>
                </div>
                <div className="text-slate-400 font-mono">
                  Date: {td.preferred_date} @ {td.preferred_time} ({td.city})
                </div>
                {td.status !== 'Cancelled' && td.status !== 'Completed' && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {rescheduleTarget === td.id ? (
                      <>
                        <input
                          type="date"
                          value={rescheduleDate}
                          onChange={(e) => setRescheduleDate(e.target.value)}
                          className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white"
                        />
                        <input
                          type="text"
                          value={rescheduleTime}
                          onChange={(e) => setRescheduleTime(e.target.value)}
                          className="rounded-lg bg-slate-900 border border-slate-700 px-2 py-1 text-white w-28"
                        />
                        <button
                          type="button"
                          onClick={async () => {
                            await api.updateCustomerTestDrive(td.id, {
                              action: 'reschedule',
                              preferredDate: rescheduleDate,
                              preferredTime: rescheduleTime,
                            });
                            setRescheduleTarget(null);
                            flash('Test drive rescheduled (pending showroom confirmation).');
                            await loadTab('test-drives');
                          }}
                          className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-bold"
                        >
                          Save
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setRescheduleTarget(td.id)}
                        className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold"
                      >
                        Reschedule
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={async () => {
                        await api.updateCustomerTestDrive(td.id, { action: 'cancel' });
                        flash('Test drive cancelled.');
                        await loadTab('test-drives');
                      }}
                      className="px-3 py-1 rounded-lg bg-rose-950 border border-rose-500/40 text-rose-300 font-bold"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: BOOKINGS & KYC UPLOAD */}
      {custTab === 'bookings' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Vehicle Reservations &amp; Bookings ({bookingsData?.bookings?.length || 0})</h3>
              {(bookingsData?.bookings || []).map((b: any) => (
                <div key={b.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-mono font-bold text-emerald-300 mr-2">{b.booking_ref}</span>
                      <span className="font-bold text-white">{b.vehicle_model} — {b.variant}</span>
                    </div>
                    <div className="flex gap-1.5">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold">{b.booking_status}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-amber-300 font-bold">Pay: {b.payment_status}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-emerald-300 font-bold">Deliv: {b.delivery_status}</span>
                    </div>
                  </div>
                  <div className="text-slate-400">
                    Showroom: {b.showroom_name} • Token Required: <strong className="font-mono text-white">{formatPrice(b.booking_amount_pkr || 0)}</strong>
                  </div>
                  {b.payment_instructions && (
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                      {b.payment_instructions}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!uploadState.bookingId || !uploadState.file) {
                  flash('Select a booking and file to upload.', 'err');
                  return;
                }
                try {
                  const res = await api.uploadCustomerBookingDocument(uploadState.bookingId, {
                    docCategory: uploadState.docCategory,
                    docTitle: uploadState.docTitle,
                    file: uploadState.file,
                  });
                  flash(`Uploaded ${res.fileName} securely for admin payment/KYC verification.`);
                  setUploadState((u) => ({ ...u, file: null }));
                  await loadTab('bookings');
                } catch (err: any) {
                  flash(err?.message || 'Document upload failed.', 'err');
                }
              }}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
            >
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-emerald-400" />
                <span>Upload Payment Proof / KYC</span>
              </h3>
              <select
                required
                value={uploadState.bookingId}
                onChange={(e) => setUploadState({ ...uploadState, bookingId: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="">Select Booking...</option>
                {(bookingsData?.bookings || []).map((b: any) => (
                  <option key={b.id} value={b.id}>
                    {b.booking_ref} — {b.vehicle_model}
                  </option>
                ))}
              </select>
              <select
                value={uploadState.docCategory}
                onChange={(e) => setUploadState({ ...uploadState, docCategory: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="Payment Proof">Bank / Dealership Payment Proof</option>
                <option value="KYC Identity">CNIC / Passport KYC</option>
                <option value="Financing Approval">Bank Lease / Financing Approval</option>
              </select>
              <input
                type="text"
                required
                placeholder="Document Title"
                value={uploadState.docTitle}
                onChange={(e) => setUploadState({ ...uploadState, docTitle: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="file"
                required
                accept=".pdf,.png,.jpg,.jpeg,.txt"
                onChange={(e) => setUploadState({ ...uploadState, file: e.target.files?.[0] || null })}
                className="w-full text-slate-300"
              />
              <button type="submit" className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black">
                Upload Document to Vault
              </button>
            </form>
          </div>
        </div>
      )}

      {/* TAB 6: PAYMENTS & INVOICES */}
      {custTab === 'payments' && (
        <div className="space-y-6 text-xs">
          {!paymentsData?.paymentGatewayConfigured && (
            <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 text-amber-200">
              Online card checkout requires Stripe (`STRIPE_SECRET_KEY`) or PayFast (`PAYFAST_MERCHANT_ID`) configuration. Verified showroom &amp; bank transfer receipts uploaded under Bookings are recorded and verified by authorized finance admins.
            </div>
          )}

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 overflow-x-auto space-y-3">
            <h3 className="text-sm font-bold text-white">Customer Invoices ({paymentsData?.invoices?.length || 0})</h3>
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">PDF</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {(paymentsData?.invoices || []).map((inv: any) => (
                  <tr key={inv.id}>
                    <td className="py-2.5 px-3 text-cyan-300 font-bold">{inv.invoice_number}</td>
                    <td className="py-2.5 px-3 font-sans text-white">{inv.description}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-emerald-300">{formatPrice(inv.total_pkr || 0)}</td>
                    <td className="py-2.5 px-3">{inv.status}</td>
                    <td className="py-2.5 px-3">
                      <button
                        type="button"
                        onClick={() => handleDownloadBlob(`/api/customer/invoices/${inv.id}/pdf`, `${inv.invoice_number}.pdf`)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-sans font-bold"
                      >
                        <Download className="w-3 h-3" /> PDF
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 overflow-x-auto space-y-3">
            <h3 className="text-sm font-bold text-white">Verified Payments Ledger ({paymentsData?.payments?.length || 0})</h3>
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Reference</th>
                  <th className="py-2.5 px-3">Method</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {(paymentsData?.payments || []).map((p: any) => (
                  <tr key={p.id}>
                    <td className="py-2.5 px-3 text-emerald-300 font-bold">{p.payment_ref}</td>
                    <td className="py-2.5 px-3 font-sans text-slate-300">{p.method}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-white">{formatPrice(p.amount_pkr || 0)}</td>
                    <td className="py-2.5 px-3">{p.status}</td>
                    <td className="py-2.5 px-3 text-slate-400">{p.created_at?.slice(0, 10)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 7: MY VEHICLES & SERVICE */}
      {custTab === 'vehicles' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">My Registered BYD Vehicles ({myVehicles.length})</h3>
                {myVehicles.map((v: any) => (
                  <div key={v.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-white text-sm">{v.model} ({v.variant})</div>
                      <div className="font-mono text-[11px] text-cyan-300">VIN: {v.vin} • Plate: {v.license_plate}</div>
                      <div className="text-slate-400">Odometer: {v.odometer_km?.toLocaleString() || 0} km • Blade Battery SoH: {v.battery_soh ?? 100}%</div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="text-emerald-300 font-bold">{v.color} ({v.model_year})</div>
                      <div className="text-slate-500">Registered {v.registration_date}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
                <h3 className="text-sm font-bold text-white">Service Requests ({serviceData?.serviceRequests?.length || 0}) &amp; Maintenance History</h3>
                {(serviceData?.serviceRequests || []).map((sr: any) => (
                  <div key={sr.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        <span className="font-mono text-cyan-300 mr-2">{sr.request_number}</span>
                        {sr.service_type}
                      </div>
                      <div className="text-slate-400">{sr.preferred_date} @ {sr.preferred_time} • Technician: {sr.technician_assigned || 'Unassigned'}</div>
                    </div>
                    <span className="px-2.5 py-0.5 rounded bg-slate-800 text-amber-300 font-bold">{sr.status}</span>
                  </div>
                ))}
                {(serviceData?.serviceHistory || []).map((sh: any) => (
                  <div key={sh.id} className="p-3 rounded-xl bg-slate-950 border border-emerald-500/20 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-emerald-300">{sh.service_type} — Completed {sh.service_date}</div>
                      <div className="text-slate-400">{sh.summary} • Next Due: {sh.next_due_km?.toLocaleString()} km</div>
                    </div>
                    <div className="font-mono text-white">{formatPrice(sh.cost_pkr || 0)}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    const res = await api.registerCustomerVehicle(regVehicleForm);
                    flash(`Vehicle registered with automatic 8yr/6yr Blade Battery & vehicle warranty (${res.warrantyId}).`);
                    setRegVehicleForm((p) => ({ ...p, vin: '', licensePlate: '' }));
                    await loadTab('vehicles');
                  } catch (err: any) {
                    flash(err?.message || 'Vehicle registration failed.', 'err');
                  }
                }}
                className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-2.5"
              >
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  <span>Register Owned Vehicle</span>
                </h3>
                <input
                  type="text"
                  required
                  placeholder="17-Character VIN"
                  value={regVehicleForm.vin}
                  onChange={(e) => setRegVehicleForm({ ...regVehicleForm, vin: e.target.value.toUpperCase() })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                />
                <input
                  type="text"
                  required
                  placeholder="Model (e.g. BYD Seal)"
                  value={regVehicleForm.model}
                  onChange={(e) => setRegVehicleForm({ ...regVehicleForm, model: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  required
                  placeholder="License Plate (e.g. KHI-EV-991)"
                  value={regVehicleForm.licensePlate}
                  onChange={(e) => setRegVehicleForm({ ...regVehicleForm, licensePlate: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                />
                <button type="submit" className="w-full py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black">
                  Register Vehicle &amp; Activate Warranty
                </button>
              </form>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  try {
                    const res = await api.createCustomerServiceRequest(svcForm);
                    flash(`Service booking ${res.requestNumber} scheduled.`);
                    setSvcForm((p) => ({ ...p, complaintDetails: '' }));
                    await loadTab('vehicles');
                  } catch (err: any) {
                    flash(err?.message || 'Service booking failed.', 'err');
                  }
                }}
                className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-2.5"
              >
                <h3 className="text-sm font-bold text-white">Book 3S Workshop Service</h3>
                <select
                  required
                  value={svcForm.customerVehicleId}
                  onChange={(e) => setSvcForm({ ...svcForm, customerVehicleId: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="">Select My Vehicle...</option>
                  {myVehicles.map((v: any) => (
                    <option key={v.id} value={v.id}>
                      {v.model} ({v.license_plate})
                    </option>
                  ))}
                </select>
                <select
                  required
                  value={svcForm.dealershipId}
                  onChange={(e) => setSvcForm({ ...svcForm, dealershipId: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {(exploreData?.serviceDealerships || []).map((d: any) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.city})
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={svcForm.serviceType}
                  onChange={(e) => setSvcForm({ ...svcForm, serviceType: e.target.value })}
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    required
                    value={svcForm.preferredDate}
                    onChange={(e) => setSvcForm({ ...svcForm, preferredDate: e.target.value })}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    required
                    value={svcForm.preferredTime}
                    onChange={(e) => setSvcForm({ ...svcForm, preferredTime: e.target.value })}
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                </div>
                <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-black">
                  Book Service Appointment
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: WARRANTY & CLAIMS */}
      {custTab === 'warranty' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <div className="lg:col-span-2 space-y-4">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Active Warranties ({warrantyData?.warranties?.length || 0})</h3>
              {(warrantyData?.warranties || []).map((w: any) => (
                <div key={w.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{w.model} • <span className="font-mono text-cyan-300">{w.vin}</span></span>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-bold">{w.warranty_status}</span>
                  </div>
                  <div className="text-slate-300">{w.coverage_notes}</div>
                  <div className="font-mono text-slate-400">
                    Vehicle Warranty until {w.vehicle_warranty_expiry} • Blade Battery until {w.battery_warranty_expiry}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Warranty Claims ({warrantyData?.claims?.length || 0})</h3>
              {(warrantyData?.claims || []).map((c: any) => (
                <div key={c.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-amber-300 font-bold">{c.claim_number} • {c.component_category}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold">{c.status}</span>
                  </div>
                  <p className="text-slate-300">{c.issue_description}</p>
                  {c.review_notes && <div className="text-emerald-300">Admin Note: {c.review_notes}</div>}
                </div>
              ))}
            </div>
          </div>

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.submitCustomerWarrantyClaim(claimForm);
                flash(`Warranty claim ${res.claimNumber} submitted (${res.status}).`);
                setClaimForm((p) => ({ ...p, issueDescription: '', faultCode: '' }));
                await loadTab('warranty');
              } catch (err: any) {
                flash(err?.message || 'Unable to submit warranty claim.', 'err');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Submit Warranty Claim</span>
            </h3>
            <select
              required
              value={claimForm.warrantyRecordId}
              onChange={(e) => setClaimForm({ ...claimForm, warrantyRecordId: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="">Select Covered Vehicle...</option>
              {(warrantyData?.warranties || []).map((w: any) => (
                <option key={w.id} value={w.id}>
                  {w.model} ({w.vin})
                </option>
              ))}
            </select>
            <select
              value={claimForm.componentCategory}
              onChange={(e) => setClaimForm({ ...claimForm, componentCategory: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            >
              <option value="Blade Battery Pack">Blade Battery Pack</option>
              <option value="Electric Drive Motor">Electric Drive Motor</option>
              <option value="On-Board Charger / Inverter">On-Board Charger / Inverter</option>
              <option value="DiLink Infotainment / ADAS">DiLink Infotainment / ADAS</option>
            </select>
            <input
              type="text"
              placeholder="Diagnostic Fault Code (Optional)"
              value={claimForm.faultCode}
              onChange={(e) => setClaimForm({ ...claimForm, faultCode: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
            />
            <textarea
              rows={3}
              required
              placeholder="Describe component symptoms..."
              value={claimForm.issueDescription}
              onChange={(e) => setClaimForm({ ...claimForm, issueDescription: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black">
              Submit Claim for Technical Review
            </button>
          </form>
        </div>
      )}

      {/* TAB 9: DOCUMENTS, NOTIFICATIONS & SUPPORT */}
      {custTab === 'documents' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Document Vault ({documents.length})</h3>
            {documents.map((doc: any) => (
              <div key={doc.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                <div>
                  <div className="font-bold text-white">{doc.doc_title}</div>
                  <div className="text-slate-400">{doc.doc_category} • {doc.verification_status}</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleDownloadBlob(`/api/customer/documents/${doc.id}/download`, doc.file_name || 'document.txt')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 className="text-sm font-bold text-white">Notifications ({notifications.length})</h3>
            {notifications.map((n: any) => (
              <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{n.title}</span>
                  {!n.is_read && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.markCustomerNotificationRead(n.id);
                        setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, is_read: 1 } : x)));
                      }}
                      className="text-[10px] text-emerald-400 font-bold"
                    >
                      Mark Read
                    </button>
                  )}
                </div>
                <p className="text-slate-300">{n.message}</p>
              </div>
            ))}
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>Support Tickets ({tickets.length})</span>
            </h3>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  const res = await api.createCustomerSupportTicket(ticketForm);
                  flash(`Support ticket ${res.ticketNumber} created.`);
                  setTicketForm((p) => ({ ...p, subject: '', description: '' }));
                  await loadTab('documents');
                } catch (err: any) {
                  flash(err?.message || 'Unable to submit support ticket.', 'err');
                }
              }}
              className="space-y-2"
            >
              <select
                value={ticketForm.category}
                onChange={(e) => setTicketForm({ ...ticketForm, category: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              >
                <option value="Account & Verification">Account &amp; Verification</option>
                <option value="Booking & Delivery">Booking &amp; Delivery</option>
                <option value="Technical & Charging">Technical &amp; Charging</option>
                <option value="Billing & Invoice">Billing &amp; Invoice</option>
              </select>
              <input
                type="text"
                required
                placeholder="Ticket Subject"
                value={ticketForm.subject}
                onChange={(e) => setTicketForm({ ...ticketForm, subject: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <textarea
                rows={2}
                required
                placeholder="Issue details..."
                value={ticketForm.description}
                onChange={(e) => setTicketForm({ ...ticketForm, description: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button type="submit" className="w-full py-2 rounded-xl bg-cyan-500 text-slate-950 font-black">
                Submit Support Ticket
              </button>
            </form>

            <div className="space-y-2">
              {tickets.map((t: any) => (
                <div key={t.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex justify-between font-bold">
                    <span className="font-mono text-cyan-300">{t.ticket_number}</span>
                    <span className="text-amber-300">{t.status}</span>
                  </div>
                  <div className="font-semibold text-white">{t.subject}</div>
                  {t.reply_text && <div className="text-emerald-300">Reply: {t.reply_text}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 10: PROFILE, SESSIONS & SECURITY */}
      {custTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.updateCustomerProfile({
                  fullName: profileEdit.fullName,
                  email: profileEdit.email,
                  mobile: profileEdit.mobile,
                  country: profileEdit.country,
                  city: profileEdit.city,
                  address: profileEdit.address,
                  cnicOrId: profileEdit.cnicOrId,
                  emergencyContact: profileEdit.emergencyContact,
                  preferredLanguage: profileEdit.preferredLanguage,
                  preferredCurrency: profileEdit.preferredCurrency,
                  communicationPrefs: {
                    emailAlerts: profileEdit.emailAlerts,
                    smsAlerts: profileEdit.smsAlerts,
                    serviceReminders: profileEdit.serviceReminders,
                  },
                });
                flash(res.message);
                await refreshSession();
                await loadTab('profile');
              } catch (err: any) {
                flash(err?.message || 'Unable to update profile.', 'err');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3"
          >
            <h3 className="text-sm font-bold text-white">Customer Profile &amp; Preferences</h3>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                required
                placeholder="Full Name"
                value={profileEdit.fullName}
                onChange={(e) => setProfileEdit({ ...profileEdit, fullName: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="email"
                required
                placeholder="Email"
                value={profileEdit.email}
                onChange={(e) => setProfileEdit({ ...profileEdit, email: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="tel"
                required
                placeholder="Mobile"
                value={profileEdit.mobile}
                onChange={(e) => setProfileEdit({ ...profileEdit, mobile: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="text"
                required
                placeholder="City"
                value={profileEdit.city}
                onChange={(e) => setProfileEdit({ ...profileEdit, city: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="text"
              placeholder="Address"
              value={profileEdit.address}
              onChange={(e) => setProfileEdit({ ...profileEdit, address: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="CNIC / National ID"
                value={profileEdit.cnicOrId}
                onChange={(e) => setProfileEdit({ ...profileEdit, cnicOrId: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
              />
              <input
                type="text"
                placeholder="Emergency Contact"
                value={profileEdit.emergencyContact}
                onChange={(e) => setProfileEdit({ ...profileEdit, emergencyContact: e.target.value })}
                className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <div className="flex flex-wrap gap-4 pt-1 text-slate-300">
              <label className="flex items-center gap-1.5">
                <input type="checkbox" checked={profileEdit.emailAlerts} onChange={(e) => setProfileEdit({ ...profileEdit, emailAlerts: e.target.checked })} />
                <span>Email Alerts</span>
              </label>
              <label className="flex items-center gap-1.5">
                <input type="checkbox" checked={profileEdit.serviceReminders} onChange={(e) => setProfileEdit({ ...profileEdit, serviceReminders: e.target.checked })} />
                <span>Service Reminders</span>
              </label>
            </div>
            <button type="submit" className="w-full py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black">
              Save Customer Profile
            </button>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <div className="font-bold text-rose-300">Account Deletion Request</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Reason for deletion request..."
                  value={deletionReason}
                  onChange={(e) => setDeletionReason(e.target.value)}
                  className="flex-1 rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const res = await api.requestCustomerDeletion(deletionReason || 'Customer requested closure');
                      flash(res.message);
                    } catch (err: any) {
                      flash(err?.message || 'Deletion request blocked due to active records.', 'err');
                    }
                  }}
                  className="px-3.5 py-2 rounded-xl bg-rose-950 border border-rose-500/40 text-rose-200 font-bold"
                >
                  Request Deletion
                </button>
              </div>
            </div>
          </form>

          <div className="space-y-4">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  const res = await api.changeCustomerPassword(pwForm);
                  flash(res.message);
                  setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
                } catch (err: any) {
                  flash(err?.message || 'Password update failed.', 'err');
                }
              }}
              className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3"
            >
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-cyan-400" />
                <span>Change Password</span>
              </h3>
              <input
                type="password"
                required
                placeholder="Current Password"
                value={pwForm.currentPassword}
                onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="password"
                required
                placeholder="New Strong Password"
                value={pwForm.newPassword}
                onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="password"
                required
                placeholder="Confirm New Password"
                value={pwForm.confirmPassword}
                onChange={(e) => setPwForm({ ...pwForm, confirmPassword: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-black">
                Update Password
              </button>
            </form>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-emerald-400" />
                <span>Active Sessions ({profileData?.sessions?.length || 0}) &amp; Login History</span>
              </h3>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {(profileData?.sessions || []).map((s: any) => (
                  <div key={s.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-white">
                        {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}
                      </div>
                      <div className="font-mono text-[10px] text-slate-400">IP: {s.ip_address} • Exp: {s.expires_at?.slice(0, 16)}</div>
                    </div>
                    {!s.is_current && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.revokeCustomerSession(s.id);
                          await loadTab('profile');
                        }}
                        className="px-2 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <div className="space-y-1.5 max-h-40 overflow-y-auto pt-2 border-t border-slate-800">
                {(profileData?.loginHistory || []).map((h: any) => (
                  <div key={h.id} className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex justify-between font-mono text-[11px]">
                    <span className="text-slate-300">{h.ip_address}</span>
                    <span className="text-slate-500">{h.created_at?.slice(0, 16)}</span>
                    <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {h.success ? 'SUCCESS' : 'FAILED'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2">
            <AccountSecurityCenter />
          </div>
        </div>
      )}
    </div>
  );
};
