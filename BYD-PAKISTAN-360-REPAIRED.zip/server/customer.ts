import express, { Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import {
  sqlite,
  PRIVATE_CUSTOMER_DOCS_DIR,
  generateSecureToken,
  generateNumericOtp,
  hashPassword,
  verifyPassword,
  validatePasswordStrength,
  sha256,
  logCustomerActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import { requireCustomer, getClientIp } from './auth';
import { buildSimplePdfBuffer } from './dealer';

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'text/plain',
  'text/csv',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
});

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

const isSmsConfigured = () =>
  Boolean(
    (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_FROM_NUMBER) ||
      process.env.SMS_API_KEY
  );

const isPaymentGatewayConfigured = () =>
  Boolean(process.env.STRIPE_SECRET_KEY || process.env.PAYFAST_MERCHANT_ID);

// Official specs aligned with existing BYD Pakistan 360 catalog records (zero invented specs)
const VERIFIED_MODEL_SPECS: Record<
  string,
  { batteryCapacity: string; rangeRating: string; chargingSpec: string; drivetrain: string; warrantySummary: string }
> = {
  'BYD Seal': {
    batteryCapacity: '82.5 kWh LFP Blade Battery',
    rangeRating: 'Up to 570 km (WLTP)',
    chargingSpec: '150 kW DC Fast Charge (30–80% in ~26 min) / 11 kW AC',
    drivetrain: 'Cell-to-Body (CTB) AWD / RWD',
    warrantySummary: '8 Years Battery / 6 Years Vehicle',
  },
  'BYD Atto 3': {
    batteryCapacity: '60.48 kWh LFP Blade Battery',
    rangeRating: '420 km (WLTP) / 480 km (NEDC)',
    chargingSpec: '88 kW DC Fast Charge / 7 kW AC Wallbox',
    drivetrain: 'e-Platform 3.0 Front-Wheel Drive',
    warrantySummary: '8 Years Battery / 6 Years Vehicle',
  },
  'BYD Sealion 6': {
    batteryCapacity: '18.3 kWh LFP Blade Battery + DM-i Super Hybrid',
    rangeRating: '1,092 km Combined Range',
    chargingSpec: '18 kW DC / 6.6 kW AC Charging + V2L',
    drivetrain: 'DM-i Super Hybrid AWD',
    warrantySummary: '8 Years Battery / 6 Years Vehicle',
  },
  'BYD Shark 6': {
    batteryCapacity: '29.58 kWh LFP Blade Battery + DMO Hybrid',
    rangeRating: '840 km Combined Range (100 km Pure EV)',
    chargingSpec: '55 kW DC Fast Charge / 6.6 kW AC + V2L',
    drivetrain: 'DMO Dual-Motor 4WD Off-Road Utility',
    warrantySummary: '8 Years Battery / 6 Years Vehicle',
  },
  'BYD Han EV': {
    batteryCapacity: '85.4 kWh LFP Blade Battery',
    rangeRating: '521 km (WLTP)',
    chargingSpec: '120 kW DC Fast Charge / 11 kW AC',
    drivetrain: 'Flagship Dual-Motor AWD',
    warrantySummary: '8 Years Battery / 6 Years Vehicle',
  },
};

function recordCustomerAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.customerId) return;
  logCustomerActivity({
    customerId: req.auth.customerId,
    companyId: req.auth.companyId,
    countryId: req.auth.country,
    branchId: req.auth.branchId,
    actorId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: 'Customer',
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function assertNotImpersonatingCustomer(req: Request, res: Response): boolean {
  const customerId = req.auth?.customerId;
  const customerCode = req.auth?.customerCode;

  const qCustomerId = req.query.customerId ? String(req.query.customerId).trim() : null;
  const qCustomerCode = req.query.customerCode ? String(req.query.customerCode).trim().toUpperCase() : null;
  const bCustomerId =
    req.body?.customerId || req.body?.customer_id
      ? String(req.body.customerId || req.body.customer_id).trim()
      : null;
  const bCustomerCode =
    req.body?.customerCode || req.body?.customer_code
      ? String(req.body.customerCode || req.body.customer_code).trim().toUpperCase()
      : null;

  if (
    (qCustomerId && qCustomerId !== customerId) ||
    (qCustomerCode && qCustomerCode !== customerCode) ||
    (bCustomerId && bCustomerId !== customerId) ||
    (bCustomerCode && bCustomerCode !== customerCode)
  ) {
    logSecurityEvent({
      severity: 'CRITICAL',
      eventType: 'CUSTOMER_IMPERSONATION_ATTEMPT',
      userId: req.auth?.userId,
      identifier: req.auth?.email,
      companyId: req.auth?.companyId,
      details: `Customer "${customerCode}" attempted cross-customer query/payload override.`,
      ipAddress: getClientIp(req),
    });
    res.status(403).json({ error: 'Forbidden: Cross-customer impersonation attempt blocked.' });
    return false;
  }
  return true;
}

export function createCustomerRouter() {
  const router = express.Router();
  router.use(requireCustomer);

  // Explicit forbidden actions for Customer Role (Section 8, 9, 11, 14)
  router.all('/bookings/:id/confirm-payment', (req: Request, res: Response) => {
    recordCustomerAction(req, 'UNAUTHORIZED_PAYMENT_SELF_CONFIRM', 'Customer Security', req.params.id, 'Customer attempted to self-confirm payment.', 'ALERT');
    res.status(403).json({ error: 'Forbidden: Payments can only be verified by authorized dealership finance or administrators.' });
  });

  router.post('/payments*', (_req: Request, res: Response) => {
    res.status(403).json({ error: 'Forbidden: Customers cannot directly create or alter verified payment records.' });
  });
  router.put('/payments*', (_req: Request, res: Response) => {
    res.status(403).json({ error: 'Forbidden: Customers cannot alter official payment records.' });
  });
  router.patch('/payments*', (_req: Request, res: Response) => {
    res.status(403).json({ error: 'Forbidden: Customers cannot alter official payment records.' });
  });
  router.delete('/payments*', (_req: Request, res: Response) => {
    res.status(403).json({ error: 'Forbidden: Customers cannot delete payment records.' });
  });

  router.all('/warranty/claims/:id/approve', (req: Request, res: Response) => {
    recordCustomerAction(req, 'UNAUTHORIZED_WARRANTY_APPROVAL', 'Customer Security', req.params.id, 'Customer attempted to approve warranty claim.', 'ALERT');
    res.status(403).json({ error: 'Forbidden: Warranty claims can only be approved by authorized Warranty Managers or Administrators.' });
  });

  router.all('/inventory*', (_req: Request, res: Response) => {
    res.status(403).json({ error: 'Forbidden: Customers cannot modify dealership or company vehicle inventory.' });
  });

  // 1. Customer Dashboard Overview
  router.get('/dashboard', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;

    const cust = sqlite.prepare('SELECT * FROM customer_accounts WHERE id = ?').get(customerId) as any;
    const prof = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(customerId) as any;

    const totalInquiries = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_inquiries WHERE customer_id = ?').get(customerId) as any).c;
    const activeBookings = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_bookings WHERE customer_id = ? AND booking_status IN ('Approved')").get(customerId) as any).c;
    const pendingBookings = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_bookings WHERE customer_id = ? AND booking_status = 'Pending Review'").get(customerId) as any).c;
    const completedPurchases = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_bookings WHERE customer_id = ? AND booking_status = 'Completed'").get(customerId) as any).c;
    const testDriveRequests = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_test_drive_requests WHERE customer_id = ?').get(customerId) as any).c;
    const serviceAppointments = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_service_requests WHERE customer_id = ?').get(customerId) as any).c;
    const registeredVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_vehicles WHERE customer_id = ?').get(customerId) as any).c;
    const warrantiesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_warranty_records WHERE customer_id = ?').get(customerId) as any).c;
    const unreadNotifications = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_notifications WHERE customer_id = ? AND is_read = 0').get(customerId) as any).c;
    const favoritesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_favorites WHERE customer_id = ?').get(customerId) as any).c;
    const openTicketsCount = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_support_tickets WHERE customer_id = ? AND status IN ('Open','In Progress')").get(customerId) as any).c;
    const pendingPaymentsPkr = (sqlite.prepare('SELECT COALESCE(SUM(outstanding_balance_pkr), 0) as total FROM customer_invoices WHERE customer_id = ?').get(customerId) as any).total;

    const recentActivity = sqlite
      .prepare('SELECT * FROM customer_activity_logs WHERE customer_id = ? ORDER BY created_at DESC LIMIT 12')
      .all(customerId);
    const notifications = sqlite
      .prepare('SELECT * FROM customer_notifications WHERE customer_id = ? ORDER BY created_at DESC LIMIT 8')
      .all(customerId);
    const vehicles = sqlite
      .prepare('SELECT * FROM customer_vehicles WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);

    const ownershipTransfers: any[] = [];

    res.json({
      customer: {
        id: cust.id,
        customerCode: cust.customer_code,
        fullName: cust.full_name,
        email: cust.email,
        mobile: cust.mobile,
        country: cust.country,
        city: cust.city,
        address: cust.address,
        accountType: cust.account_type,
        verificationStatus: cust.verification_status,
        status: cust.status,
        emailVerified: Boolean(cust.email_verified),
        mobileVerified: Boolean(cust.mobile_verified),
        avatarUrl: prof?.avatar_url || '',
        lastLoginAt: cust.last_login_at,
        lastLoginIp: cust.last_login_ip,
      },
      metrics: {
        totalInquiries,
        activeBookings,
        pendingBookings,
        completedPurchases,
        testDriveRequests,
        serviceAppointments,
        registeredVehicles,
        warrantiesCount,
        unreadNotifications,
        favoritesCount,
        openTicketsCount,
        pendingPaymentsPkr,
      },
      systemCapabilities: {
        smsConfigured: isSmsConfigured(),
        smtpConfigured: Boolean(process.env.SMTP_HOST),
        paymentGatewayConfigured: isPaymentGatewayConfigured(),
      },
      vehicles,
      notifications,
      recentActivity,
      ownershipTransfers,
    });
  });

  // 2. Customer Profile, Security & Account Deletion Request
  router.get('/profile', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const cust = sqlite.prepare('SELECT * FROM customer_accounts WHERE id = ?').get(customerId) as any;
    const prof = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(customerId) as any;
    const verifications = sqlite.prepare('SELECT * FROM customer_verifications WHERE customer_id = ? ORDER BY created_at DESC').all(customerId);
    const sessions = sqlite
      .prepare("SELECT id, device_label, ip_address, user_agent, last_activity_at, expires_at, created_at, CASE WHEN id = ? THEN 1 ELSE 0 END as is_current FROM authentication_sessions WHERE user_id = ? AND subject_type = 'customer' AND revoked = 0 AND expires_at > ? ORDER BY last_activity_at DESC")
      .all(req.auth!.sessionId, customerId, nowIso());
    const loginHistory = sqlite
      .prepare("SELECT id, identifier, ip_address, user_agent, success, failure_reason, suspicious, created_at FROM login_history WHERE user_id = ? AND subject_type = 'customer' ORDER BY created_at DESC LIMIT 30")
      .all(customerId);

    res.json({
      account: {
        id: cust.id,
        customerCode: cust.customer_code,
        fullName: cust.full_name,
        email: cust.email,
        mobile: cust.mobile,
        country: cust.country,
        city: cust.city,
        address: cust.address,
        accountType: cust.account_type,
        role: cust.role,
        verificationStatus: cust.verification_status,
        status: cust.status,
        emailVerified: Boolean(cust.email_verified),
        mobileVerified: Boolean(cust.mobile_verified),
        deletionRequestedAt: cust.deletion_requested_at,
        deletionReason: cust.deletion_reason,
        createdAt: cust.created_at,
      },
      profile: {
        avatarUrl: prof?.avatar_url || '',
        cnicOrId: prof?.cnic_or_id || '',
        dateOfBirth: prof?.date_of_birth || '',
        preferredLanguage: prof?.preferred_language || 'en',
        preferredCurrency: prof?.preferred_currency || 'PKR',
        preferredDealershipId: prof?.preferred_dealership_id || '',
        emergencyContact: prof?.emergency_contact || '',
        communicationPrefs: safeJsonParse(prof?.communication_prefs_json, {
          emailUpdates: true,
          serviceReminders: true,
          warrantyAlerts: true,
          promotionalOffers: false,
        }),
      },
      verifications,
      sessions,
      loginHistory,
      smsConfigured: isSmsConfigured(),
    });
  });

  router.put('/profile', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;

    // Block customers from altering protected system attributes
    if (
      req.body.customerCode !== undefined ||
      req.body.customer_code !== undefined ||
      req.body.role !== undefined ||
      req.body.verificationStatus !== undefined ||
      req.body.verification_status !== undefined ||
      req.body.emailVerified !== undefined ||
      req.body.mobileVerified !== undefined ||
      req.body.status !== undefined
    ) {
      recordCustomerAction(req, 'FORBIDDEN_PROFILE_TAMPER', 'Customer Profile', customerId, 'Attempted to modify Customer ID, role, or verification status.', 'ALERT');
      res.status(403).json({ error: 'Forbidden: Customers cannot modify Customer ID, role, account status, or verification status.' });
      return;
    }

    const current = sqlite.prepare('SELECT * FROM customer_accounts WHERE id = ?').get(customerId) as any;
    const prof = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(customerId) as any;

    const fullName = req.body.fullName !== undefined ? String(req.body.fullName).trim() : current.full_name;
    const mobile = req.body.mobile !== undefined ? String(req.body.mobile).trim() : current.mobile;
    const country = req.body.country !== undefined ? String(req.body.country).trim().toUpperCase() : current.country;
    const city = req.body.city !== undefined ? String(req.body.city).trim() : current.city;
    const address = req.body.address !== undefined ? String(req.body.address).trim() : current.address;
    const newEmail = req.body.email !== undefined ? String(req.body.email).trim().toLowerCase() : current.email.toLowerCase();

    if (!fullName || fullName.length < 2) {
      res.status(400).json({ error: 'Full name must be at least 2 characters.' });
      return;
    }
    if (!mobile || !/^\+\d[\d\s-]{7,18}$/.test(mobile)) {
      res.status(400).json({ error: 'Mobile number must include country code (e.g. +92 300 1234567).' });
      return;
    }

    let emailChanged = false;
    let verificationOutbox: any = undefined;
    const now = nowIso();

    if (newEmail !== current.email.toLowerCase()) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
        res.status(400).json({ error: 'Please provide a valid email address.' });
        return;
      }
      const conflict =
        sqlite.prepare('SELECT id FROM customer_accounts WHERE LOWER(email) = ? AND id != ?').get(newEmail, customerId) ||
        sqlite.prepare('SELECT id FROM founder_accounts WHERE LOWER(email) = ?').get(newEmail) ||
        sqlite.prepare('SELECT id FROM super_admin_accounts WHERE LOWER(email) = ?').get(newEmail) ||
        sqlite.prepare('SELECT id FROM dealer_accounts WHERE LOWER(email) = ?').get(newEmail) ||
        sqlite.prepare('SELECT id FROM employee_accounts WHERE LOWER(email) = ?').get(newEmail);
      if (conflict) {
        res.status(409).json({ error: 'Another account already uses this email address.' });
        return;
      }
      emailChanged = true;
    }

    const mobileChanged = mobile.replace(/\s+/g, '') !== current.mobile.replace(/\s+/g, '');

    sqlite
      .prepare(`
        UPDATE customer_accounts
        SET full_name = ?,
            email = ?,
            mobile = ?,
            country = ?,
            city = ?,
            address = ?,
            email_verified = CASE WHEN ? = 1 THEN 0 ELSE email_verified END,
            mobile_verified = CASE WHEN ? = 1 THEN 0 ELSE mobile_verified END,
            verification_status = CASE WHEN ? = 1 THEN 'Unverified' ELSE verification_status END,
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        fullName,
        newEmail,
        mobile,
        country,
        city,
        address,
        emailChanged ? 1 : 0,
        mobileChanged ? 1 : 0,
        emailChanged ? 1 : 0,
        now,
        customerId
      );

    if (emailChanged) {
      const otpCode = generateNumericOtp(6);
      const otpExpires = new Date(Date.now() + 30 * 60 * 1000).toISOString();
      sqlite
        .prepare("INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at) VALUES (?, ?, 'cus_email_verify', ?, ?, 'customer', ?, 0, ?)")
        .run(`otp_${generateSecureToken(6)}`, newEmail, sha256(otpCode), customerId, otpExpires, now);
      verificationOutbox = process.env.SMTP_HOST
        ? undefined
        : { notice: 'Development Mailer Outbox (SMTP not configured)', code: otpCode };
    }

    const existingComms = safeJsonParse(prof?.communication_prefs_json, {
      emailUpdates: true,
      serviceReminders: true,
      warrantyAlerts: true,
      promotionalOffers: false,
    });

    sqlite
      .prepare(`
        INSERT INTO customer_profiles (
          customer_id, avatar_url, cnic_or_id, date_of_birth, preferred_language,
          preferred_currency, preferred_dealership_id, communication_prefs_json, emergency_contact, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(customer_id) DO UPDATE SET
          avatar_url = excluded.avatar_url,
          cnic_or_id = excluded.cnic_or_id,
          date_of_birth = excluded.date_of_birth,
          preferred_language = excluded.preferred_language,
          preferred_currency = excluded.preferred_currency,
          preferred_dealership_id = excluded.preferred_dealership_id,
          communication_prefs_json = excluded.communication_prefs_json,
          emergency_contact = excluded.emergency_contact,
          updated_at = excluded.updated_at
      `)
      .run(
        customerId,
        req.body.avatarUrl !== undefined ? String(req.body.avatarUrl).trim() : prof?.avatar_url || '',
        req.body.cnicOrId !== undefined ? String(req.body.cnicOrId).trim() : prof?.cnic_or_id || '',
        req.body.dateOfBirth !== undefined ? String(req.body.dateOfBirth).trim() : prof?.date_of_birth || null,
        req.body.preferredLanguage !== undefined ? String(req.body.preferredLanguage).trim() : prof?.preferred_language || 'en',
        req.body.preferredCurrency !== undefined ? String(req.body.preferredCurrency).trim() : prof?.preferred_currency || 'PKR',
        req.body.preferredDealershipId !== undefined ? String(req.body.preferredDealershipId).trim() : prof?.preferred_dealership_id || null,
        JSON.stringify(req.body.communicationPrefs || existingComms),
        req.body.emergencyContact !== undefined ? String(req.body.emergencyContact).trim() : prof?.emergency_contact || '',
        now
      );

    recordCustomerAction(req, 'CUSTOMER_PROFILE_UPDATED', 'Customer Profile', customerId, emailChanged ? 'Profile and email updated (email re-verification triggered).' : 'Personal profile and communication preferences updated.');

    res.json({
      success: true,
      emailChanged,
      mobileChanged,
      verificationOutbox,
      message: emailChanged
        ? 'Profile updated. Please verify your new email address using the OTP code sent.'
        : 'Customer profile and preferences updated.',
    });
  });

  router.post('/change-password', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const currentPassword = String(req.body.currentPassword || '');
    const newPassword = String(req.body.newPassword || '');
    const confirmPassword = String(req.body.confirmPassword || '');

    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'New password and Confirm Password do not match.' });
      return;
    }
    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const cust = sqlite.prepare('SELECT password_hash FROM customer_accounts WHERE id = ?').get(customerId) as any;
    if (!cust || !verifyPassword(currentPassword, cust.password_hash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    const now = nowIso();
    sqlite.prepare('UPDATE customer_accounts SET password_hash = ?, updated_at = ? WHERE id = ?').run(hashPassword(newPassword), now, customerId);
    // Revoke other sessions cleanly while keeping active session intact
    sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'customer' AND id != ?").run(customerId, req.auth!.sessionId);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ? AND id != ?').run(customerId, req.auth!.sessionId);

    recordCustomerAction(req, 'CUSTOMER_PASSWORD_CHANGED', 'Customer Security', customerId, 'Password updated and other sessions terminated.');
    res.json({ success: true, message: 'Password updated and other active sessions revoked.' });
  });

  router.post('/deletion-request', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const reason = String(req.body.reason || '').trim();
    if (!reason || reason.length < 10) {
      res.status(400).json({ error: 'Please specify a reason (at least 10 characters) for requesting account deletion.' });
      return;
    }

    // Legal/business retention checks before deletion can be processed
    const activeBooking = sqlite
      .prepare("SELECT booking_ref FROM customer_bookings WHERE customer_id = ? AND booking_status IN ('Pending Review', 'Approved')")
      .get(customerId) as any;
    const unpaidInvoice = sqlite
      .prepare('SELECT invoice_number FROM customer_invoices WHERE customer_id = ? AND outstanding_balance_pkr > 0')
      .get(customerId) as any;
    const openWarrantyClaim = sqlite
      .prepare("SELECT claim_number FROM customer_warranty_claims WHERE customer_id = ? AND status IN ('Submitted', 'Technical Review')")
      .get(customerId) as any;

    if (activeBooking || unpaidInvoice || openWarrantyClaim) {
      res.status(409).json({
        error: `Account deletion cannot be submitted while active commitments remain open (${
          activeBooking?.booking_ref || unpaidInvoice?.invoice_number || openWarrantyClaim?.claim_number
        }). Please settle or cancel open obligations first.`,
      });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare("UPDATE customer_accounts SET status = 'Deletion Requested', deletion_requested_at = ?, deletion_reason = ?, updated_at = ? WHERE id = ?")
      .run(now, reason, now, customerId);

    sqlite
      .prepare(`
        INSERT INTO customer_support_tickets (
          id, ticket_number, customer_id, company_id, country_id, branch_id, category, priority,
          subject, description, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Account & Privacy', 'High', 'Customer Account Deletion Request', ?, 'Open', ?, ?)
      `)
      .run(
        `csup_${generateSecureToken(6)}`,
        `DEL-CUS-${generateNumericOtp(6)}`,
        customerId,
        req.auth!.companyId,
        req.auth!.country,
        req.auth!.branchId,
        `Deletion request submitted by ${req.auth!.fullName} (${req.auth!.customerCode}). Reason: ${reason}`,
        now,
        now
      );

    recordCustomerAction(req, 'CUSTOMER_DELETION_REQUESTED', 'Customer Privacy', customerId, reason, 'WARNING');
    res.json({
      success: true,
      message: 'Account deletion request logged for compliance & statutory retention review. An administrator will finalize closure.',
    });
  });

  // 3. Vehicle Exploration (Verified Showrooms & Approved Inventory from Database)
  router.get('/vehicles/explore', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const q = String(req.query.q || '').trim().toLowerCase();
    const modelFilter = String(req.query.model || '').trim();
    const cityFilter = String(req.query.city || '').trim();
    const countryFilter = String(req.query.country || '').trim();
    const availabilityFilter = String(req.query.availability || '').trim();

    const favRows = sqlite.prepare('SELECT inventory_id FROM customer_favorites WHERE customer_id = ?').all(customerId) as any[];
    const favSet = new Set(favRows.map((f) => f.inventory_id));

    const rows = sqlite
      .prepare(`
        SELECT i.*,
               d.business_name as dealer_name,
               d.dealer_code,
               d.mobile as dealer_mobile,
               d.email as dealer_email,
               dp.city as dealer_city,
               dp.business_address as dealer_address,
               c.name as company_name
        FROM dealer_vehicle_inventory i
        JOIN dealer_accounts d ON i.dealer_id = d.id
        LEFT JOIN dealer_profiles dp ON d.id = dp.dealer_id
        LEFT JOIN companies c ON i.company_id = c.id
        WHERE d.status = 'Active' AND d.verification_status = 'Verified'
        ORDER BY i.created_at DESC
      `)
      .all() as any[];

    const catalog = rows
      .map((r) => {
        const specs = VERIFIED_MODEL_SPECS[r.model] || {
          batteryCapacity: 'LFP Blade Battery',
          rangeRating: 'Available at Showroom',
          chargingSpec: 'CCS2 DC Fast / AC Wallbox',
          drivetrain: 'BYD Electric Architecture',
          warrantySummary: '8 Years Battery / 6 Years Vehicle',
        };
        const hasOfficialPrice = Number(r.approved_selling_price_pkr) > 0;
        return {
          inventoryId: r.id,
          stockNumber: r.stock_number,
          model: r.model,
          variant: r.variant,
          modelYear: r.model_year,
          exteriorColor: r.exterior_color,
          interiorColor: r.interior_color,
          imageUrl: r.image_url,
          availabilityStatus: r.availability_status,
          deliveryStatus: r.delivery_status,
          officialPricePkr: hasOfficialPrice ? Number(r.approved_selling_price_pkr) : null,
          priceDisplay: hasOfficialPrice ? `PKR ${Number(r.approved_selling_price_pkr).toLocaleString()}` : 'Price on Request',
          specs,
          dealerId: r.dealer_id,
          dealerCode: r.dealer_code,
          showroomName: r.dealer_name,
          showroomCity: r.dealer_city || 'Karachi',
          showroomAddress: r.dealer_address || 'Authorized 3S Facility',
          showroomPhone: r.dealer_mobile,
          showroomEmail: r.dealer_email,
          companyId: r.company_id,
          companyName: r.company_name || 'BYD Authorized Partner',
          countryId: r.country_id,
          branchId: r.branch_id,
          isFavorite: favSet.has(r.id),
        };
      })
      .filter((item) => {
        if (modelFilter && modelFilter !== 'All' && item.model !== modelFilter) return false;
        if (cityFilter && cityFilter !== 'All' && item.showroomCity.toLowerCase() !== cityFilter.toLowerCase()) return false;
        if (countryFilter && countryFilter !== 'All' && item.countryId !== countryFilter) return false;
        if (availabilityFilter && availabilityFilter !== 'All' && item.availabilityStatus !== availabilityFilter) return false;
        if (q) {
          const hay = `${item.model} ${item.variant} ${item.exteriorColor} ${item.showroomName} ${item.showroomCity}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

    const showrooms = sqlite
      .prepare(`
        SELECT d.id as dealer_id, d.dealer_code, d.business_name as name, d.company_id, d.country_id, d.branch_id,
               d.mobile, d.email, COALESCE(dp.city, 'Karachi') as city, COALESCE(dp.business_address, '') as address
        FROM dealer_accounts d
        LEFT JOIN dealer_profiles dp ON d.id = dp.dealer_id
        WHERE d.status = 'Active' AND d.verification_status = 'Verified'
        ORDER BY d.business_name ASC
      `)
      .all();

    const serviceDealerships = sqlite
      .prepare("SELECT id, name, city, address, phone, country FROM dealerships WHERE status = 'Approved' ORDER BY name ASC")
      .all();

    res.json({ vehicles: catalog, showrooms, serviceDealerships });
  });

  // 4. Customer Favorites
  router.get('/favorites', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const favorites = sqlite
      .prepare(`
        SELECT f.*, i.exterior_color, i.interior_color, i.approved_selling_price_pkr, i.availability_status, i.image_url,
               d.business_name as showroom_name
        FROM customer_favorites f
        LEFT JOIN dealer_vehicle_inventory i ON f.inventory_id = i.id
        LEFT JOIN dealer_accounts d ON f.dealer_id = d.id
        WHERE f.customer_id = ?
        ORDER BY f.created_at DESC
      `)
      .all(req.auth!.customerId!);
    res.json({ favorites });
  });

  router.post('/favorites', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const inventoryId = String(req.body.inventoryId || '').trim();
    const notes = String(req.body.notes || '').trim();
    if (!inventoryId) {
      res.status(400).json({ error: 'Vehicle inventory ID is required.' });
      return;
    }

    const inv = sqlite.prepare('SELECT id, model, variant, dealer_id FROM dealer_vehicle_inventory WHERE id = ?').get(inventoryId) as any;
    if (!inv) {
      res.status(404).json({ error: 'Requested vehicle listing was not found.' });
      return;
    }

    const existing = sqlite
      .prepare('SELECT id FROM customer_favorites WHERE customer_id = ? AND inventory_id = ?')
      .get(customerId, inventoryId) as any;
    if (existing) {
      res.json({ success: true, favoriteId: existing.id, alreadySaved: true });
      return;
    }

    const favId = `cfav_${generateSecureToken(6)}`;
    sqlite
      .prepare('INSERT INTO customer_favorites (id, customer_id, inventory_id, model, variant, dealer_id, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(favId, customerId, inv.id, inv.model, inv.variant, inv.dealer_id, notes, nowIso());

    recordCustomerAction(req, 'VEHICLE_SAVED_FAVORITE', 'Favorites', inv.id, `Saved ${inv.model} (${inv.variant}) to favorites.`);
    res.status(201).json({ success: true, favoriteId: favId });
  });

  router.delete('/favorites/:id', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const target = sqlite
      .prepare('SELECT id, customer_id FROM customer_favorites WHERE id = ? OR inventory_id = ? AND customer_id = ?')
      .get(req.params.id, req.params.id, customerId) as any;
    if (!target || target.customer_id !== customerId) {
      res.status(404).json({ error: 'Favorite entry not found for your account.' });
      return;
    }
    sqlite.prepare('DELETE FROM customer_favorites WHERE id = ? AND customer_id = ?').run(target.id, customerId);
    res.json({ success: true });
  });

  // 5. Customer Inquiries
  router.get('/inquiries', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const inquiries = sqlite
      .prepare('SELECT * FROM customer_inquiries WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ inquiries });
  });

  router.post('/inquiries', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const inventoryId = req.body.inventoryId ? String(req.body.inventoryId).trim() : null;
    const dealerIdInput = req.body.dealerId ? String(req.body.dealerId).trim() : null;
    const vehicleModel = String(req.body.vehicleModel || '').trim();
    const inquiryType = String(req.body.inquiryType || 'Vehicle Information').trim();
    const subject = String(req.body.subject || '').trim();
    const message = String(req.body.message || '').trim();
    const preferredContact = String(req.body.preferredContact || 'Email').trim();

    if (!subject || !message) {
      res.status(400).json({ error: 'Inquiry subject and message are required.' });
      return;
    }

    let inv: any = null;
    if (inventoryId) {
      inv = sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(inventoryId) as any;
    }

    const dealer = dealerIdInput || inv?.dealer_id
      ? (sqlite.prepare('SELECT id, business_name, company_id, country_id, branch_id FROM dealer_accounts WHERE id = ?').get(dealerIdInput || inv?.dealer_id) as any)
      : null;

    if (!inv && !vehicleModel) {
      res.status(400).json({ error: 'Please select a vehicle model for your inquiry.' });
      return;
    }

    const now = nowIso();
    const inquiryId = `cinq_${generateSecureToken(6)}`;
    const inquiryRef = `INQ-CUS-2026-${generateNumericOtp(4)}`;

    sqlite
      .prepare(`
        INSERT INTO customer_inquiries (
          id, inquiry_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
          inventory_id, vehicle_model, variant, inquiry_type, subject, message, preferred_contact,
          status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted', ?, ?)
      `)
      .run(
        inquiryId,
        inquiryRef,
        customerId,
        dealer?.company_id || inv?.company_id || req.auth!.companyId || 'comp_byd_pk',
        dealer?.country_id || inv?.country_id || req.auth!.country || 'PK',
        dealer?.branch_id || inv?.branch_id || null,
        dealer?.id || null,
        dealer?.business_name || 'BYD Pakistan Customer Desk',
        inv?.id || null,
        inv?.model || vehicleModel,
        inv?.variant || String(req.body.variant || ''),
        inquiryType,
        subject,
        message,
        preferredContact,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Announcement', ?, ?, 'Normal', 'inquiries', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        customerId,
        dealer?.company_id || req.auth!.companyId,
        dealer?.country_id || req.auth!.country,
        `Inquiry ${inquiryRef} Submitted`,
        `Your inquiry regarding ${inv?.model || vehicleModel} has been routed to ${dealer?.business_name || 'BYD Pakistan Customer Desk'}.`,
        now
      );

    recordCustomerAction(req, 'INQUIRY_SUBMITTED', 'Customer Inquiries', inquiryRef, subject);
    res.status(201).json({ success: true, inquiryId, inquiryRef });
  });

  // 6. Test Drive Requests (Confirmed ONLY when authorized staff/showroom approves)
  router.get('/test-drives', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const testDrives = sqlite
      .prepare('SELECT * FROM customer_test_drive_requests WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ testDrives });
  });

  router.post('/test-drives', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const dealerId = String(req.body.dealerId || '').trim();
    const inventoryId = req.body.inventoryId ? String(req.body.inventoryId).trim() : null;
    const vehicleModel = String(req.body.vehicleModel || '').trim();
    const variant = String(req.body.variant || '').trim();
    const preferredDate = String(req.body.preferredDate || '').trim();
    const preferredTime = String(req.body.preferredTime || '').trim();
    const city = String(req.body.city || req.auth!.city || 'Karachi').trim();
    const notes = String(req.body.notes || '').trim();

    if (!dealerId || !preferredDate || !preferredTime) {
      res.status(400).json({ error: 'Authorized showroom, preferred date, and time slot are required.' });
      return;
    }

    const dealer = sqlite
      .prepare(`
        SELECT d.*, COALESCE(dp.city, 'Karachi') as showroom_city
        FROM dealer_accounts d
        LEFT JOIN dealer_profiles dp ON d.id = dp.dealer_id
        WHERE d.id = ? AND d.status = 'Active' AND d.verification_status = 'Verified'
      `)
      .get(dealerId) as any;

    if (!dealer) {
      res.status(404).json({ error: 'Selected showroom is not verified or unavailable.' });
      return;
    }

    const inv = inventoryId ? (sqlite.prepare('SELECT * FROM dealer_vehicle_inventory WHERE id = ?').get(inventoryId) as any) : null;
    if (!inv && !vehicleModel) {
      res.status(400).json({ error: 'Vehicle model is required for a test drive request.' });
      return;
    }

    const now = nowIso();
    const id = `ctd_${generateSecureToken(6)}`;
    const requestNumber = `TD-CUS-2026-${generateNumericOtp(4)}`;

    sqlite
      .prepare(`
        INSERT INTO customer_test_drive_requests (
          id, request_number, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
          inventory_id, vehicle_model, variant, preferred_date, preferred_time, city, notes,
          status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Showroom Confirmation', ?, ?)
      `)
      .run(
        id,
        requestNumber,
        customerId,
        dealer.company_id,
        dealer.country_id,
        dealer.branch_id,
        dealer.id,
        dealer.business_name,
        inv?.id || null,
        inv?.model || vehicleModel,
        inv?.variant || variant,
        preferredDate,
        preferredTime,
        city || dealer.showroom_city,
        notes,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Test Drive', ?, ?, 'Normal', 'test-drives', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        customerId,
        dealer.company_id,
        dealer.country_id,
        `Test Drive Request ${requestNumber} Submitted`,
        `Awaiting showroom confirmation from ${dealer.business_name} for ${preferredDate} at ${preferredTime}.`,
        now
      );

    recordCustomerAction(req, 'TEST_DRIVE_REQUESTED', 'Test Drives', requestNumber, `${inv?.model || vehicleModel} at ${dealer.business_name}`);
    res.status(201).json({ success: true, id, requestNumber, status: 'Pending Showroom Confirmation' });
  });

  router.patch('/test-drives/:id', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const td = sqlite.prepare('SELECT * FROM customer_test_drive_requests WHERE id = ?').get(req.params.id) as any;
    if (!td) {
      res.status(404).json({ error: 'Test drive request not found.' });
      return;
    }
    if (td.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: You cannot modify another customer test drive request.' });
      return;
    }

    if (req.body.status === 'Confirmed') {
      res.status(403).json({ error: 'Forbidden: Only authorized showroom staff or administrators can confirm a test drive.' });
      return;
    }
    if (td.status === 'Completed' || td.status === 'Cancelled') {
      res.status(400).json({ error: `Cannot modify a test drive that is already ${td.status}.` });
      return;
    }

    const action = String(req.body.action || 'reschedule');
    const now = nowIso();
    if (action === 'cancel' || req.body.status === 'Cancelled') {
      sqlite
        .prepare("UPDATE customer_test_drive_requests SET status = 'Cancelled', updated_at = ? WHERE id = ?")
        .run(now, td.id);
      recordCustomerAction(req, 'TEST_DRIVE_CANCELLED', 'Test Drives', td.request_number, 'Cancelled by customer.');
      res.json({ success: true, status: 'Cancelled' });
      return;
    }

    const preferredDate = req.body.preferredDate ? String(req.body.preferredDate).trim() : td.preferred_date;
    const preferredTime = req.body.preferredTime ? String(req.body.preferredTime).trim() : td.preferred_time;
    const notes = req.body.notes !== undefined ? String(req.body.notes).trim() : td.notes;

    sqlite
      .prepare(`
        UPDATE customer_test_drive_requests
        SET preferred_date = ?, preferred_time = ?, notes = ?,
            status = 'Pending Showroom Confirmation', confirmed_by = NULL, confirmed_at = NULL, updated_at = ?
        WHERE id = ?
      `)
      .run(preferredDate, preferredTime, notes, now, td.id);

    recordCustomerAction(req, 'TEST_DRIVE_RESCHEDULED', 'Test Drives', td.request_number, `Rescheduled to ${preferredDate} ${preferredTime}`);
    res.json({ success: true, status: 'Pending Showroom Confirmation' });
  });

  router.delete('/test-drives/:id', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const td = sqlite.prepare('SELECT * FROM customer_test_drive_requests WHERE id = ?').get(req.params.id) as any;
    if (!td) {
      res.status(404).json({ error: 'Test drive request not found.' });
      return;
    }
    if (td.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: Cross-customer test drive access denied.' });
      return;
    }
    sqlite.prepare("UPDATE customer_test_drive_requests SET status = 'Cancelled', updated_at = ? WHERE id = ?").run(nowIso(), td.id);
    res.json({ success: true, status: 'Cancelled' });
  });

  // 7. Vehicle Bookings & Secure Booking Document Upload
  router.get('/bookings', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const bookings = sqlite
      .prepare('SELECT * FROM customer_bookings WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId) as any[];
    const docs = sqlite
      .prepare('SELECT id, customer_id, booking_id, doc_category, doc_title, file_name, mime_type, file_size, verification_status, created_at FROM customer_booking_documents WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    res.json({ bookings, documents: docs });
  });

  router.post('/bookings', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const inventoryId = String(req.body.inventoryId || '').trim();
    const exteriorColor = String(req.body.exteriorColor || '').trim();
    const interiorColor = String(req.body.interiorColor || '').trim();
    const customerNotes = String(req.body.customerNotes || '').trim();

    if (!inventoryId) {
      res.status(400).json({ error: 'Selected vehicle inventory item is required.' });
      return;
    }

    const inv = sqlite
      .prepare(`
        SELECT i.*, d.business_name as dealer_name, d.dealer_code, d.status as dealer_status, d.verification_status as dealer_ver
        FROM dealer_vehicle_inventory i
        JOIN dealer_accounts d ON i.dealer_id = d.id
        WHERE i.id = ?
      `)
      .get(inventoryId) as any;

    if (!inv || inv.dealer_status !== 'Active' || inv.dealer_ver !== 'Verified') {
      res.status(404).json({ error: 'Selected vehicle stock or showroom is unavailable.' });
      return;
    }
    if (inv.availability_status !== 'Available') {
      res.status(409).json({ error: `Vehicle stock ${inv.stock_number} is currently "${inv.availability_status}" and cannot be booked.` });
      return;
    }

    // Prevent duplicate active bookings for the same vehicle stock by this customer
    const dup = sqlite
      .prepare("SELECT booking_ref FROM customer_bookings WHERE customer_id = ? AND inventory_id = ? AND booking_status IN ('Pending Review', 'Approved')")
      .get(customerId, inventoryId) as any;
    if (dup) {
      res.status(409).json({ error: `You already have an active booking (${dup.booking_ref}) for this vehicle unit.` });
      return;
    }

    const pricePkr = Number(inv.approved_selling_price_pkr || 0);
    const depositPkr = pricePkr > 0 ? Math.round(pricePkr * 0.1) : 1000000;
    const now = nowIso();
    const bookingId = `cbk_${generateSecureToken(6)}`;
    const bookingRef = `BK-CUS-2026-${generateNumericOtp(4)}`;
    const paymentInstructions = `Remit refundable booking deposit of PKR ${depositPkr.toLocaleString()} via IBFT / Pay Order to ${inv.dealer_name} (${inv.dealer_code}) quoting reference ${bookingRef}, and upload payment proof in Booking Documents.`;

    sqlite
      .prepare(`
        INSERT INTO customer_bookings (
          id, booking_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
          inventory_id, vehicle_model, variant, exterior_color, interior_color,
          quoted_price_pkr, booking_deposit_pkr, booking_status, payment_status, delivery_status,
          payment_instructions, customer_notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Review', 'Awaiting Payment Verification', 'Awaiting Booking Approval', ?, ?, ?, ?)
      `)
      .run(
        bookingId,
        bookingRef,
        customerId,
        inv.company_id,
        inv.country_id,
        inv.branch_id,
        inv.dealer_id,
        inv.dealer_name,
        inv.id,
        inv.model,
        inv.variant,
        exteriorColor || inv.exterior_color,
        interiorColor || inv.interior_color,
        pricePkr,
        depositPkr,
        paymentInstructions,
        customerNotes,
        now,
        now
      );

    // Issue official pro-forma invoice for the booking
    const invoiceId = `cinv_${generateSecureToken(6)}`;
    const invoiceNumber = `INV-CUS-2026-${generateNumericOtp(5)}`;
    const taxRate = inv.country_id === 'AE' ? 5.0 : inv.country_id === 'SA' ? 15.0 : 18.0;
    const totalAmount = pricePkr;
    const subtotal = totalAmount > 0 ? Math.round(totalAmount / (1 + taxRate / 100)) : 0;
    const taxAmount = totalAmount - subtotal;

    sqlite
      .prepare(`
        INSERT INTO customer_invoices (
          id, invoice_number, customer_id, booking_id, company_id, country_id, branch_id,
          dealership_name, item_category, vehicle_model, currency, subtotal_pkr, tax_rate, tax_amount_pkr,
          total_amount_pkr, amount_paid_pkr, outstanding_balance_pkr, status, issued_date, due_date, notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Vehicle Booking', ?, 'PKR', ?, ?, ?, ?, 0, ?, 'Issued', ?, ?, ?, ?, ?)
      `)
      .run(
        invoiceId,
        invoiceNumber,
        customerId,
        bookingId,
        inv.company_id,
        inv.country_id,
        inv.branch_id,
        inv.dealer_name,
        `${inv.model} ${inv.variant}`,
        subtotal,
        taxRate,
        taxAmount,
        totalAmount,
        totalAmount,
        now.slice(0, 10),
        new Date(Date.now() + 7 * 86400 * 1000).toISOString().slice(0, 10),
        `Pro-forma booking invoice for ${bookingRef}.`,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Booking', ?, ?, 'High', 'bookings', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        customerId,
        inv.company_id,
        inv.country_id,
        `Vehicle Booking ${bookingRef} Submitted`,
        `Booking request for ${inv.model} (${inv.variant}) submitted to ${inv.dealer_name}. Please upload required KYC & payment proof documents.`,
        now
      );

    recordCustomerAction(req, 'VEHICLE_BOOKING_CREATED', 'Vehicle Bookings', bookingRef, `${inv.model} (${inv.variant}) at ${inv.dealer_name}`);
    res.status(201).json({
      success: true,
      bookingId,
      bookingRef,
      invoiceNumber,
      bookingStatus: 'Pending Review',
      paymentInstructions,
    });
  });

  router.post('/bookings/:id/documents', upload.single('file'), (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const booking = sqlite.prepare('SELECT * FROM customer_bookings WHERE id = ?').get(req.params.id) as any;
    if (!booking) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    if (booking.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: You cannot upload documents to another customer booking.' });
      return;
    }
    if (!req.file) {
      res.status(400).json({ error: 'Document file is required.' });
      return;
    }
    if (!ALLOWED_MIME_TYPES.has(req.file.mimetype)) {
      res.status(400).json({ error: 'Unsupported document type. Upload PDF, JPG, PNG, WebP, TXT, CSV, or DOCX.' });
      return;
    }

    const docCategory = String(req.body.docCategory || 'Identity / CNIC').trim();
    const docTitle = String(req.body.docTitle || req.file.originalname).trim();
    fs.mkdirSync(PRIVATE_CUSTOMER_DOCS_DIR, { recursive: true });

    const docId = `cdoc_${generateSecureToken(8)}`;
    const safeName = `${docId}_${path.basename(req.file.originalname).replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const fullPath = path.join(PRIVATE_CUSTOMER_DOCS_DIR, safeName);
    fs.writeFileSync(fullPath, req.file.buffer);

    sqlite
      .prepare(`
        INSERT INTO customer_booking_documents (
          id, customer_id, booking_id, doc_category, doc_title, file_name, mime_type,
          file_size, storage_path, verification_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted', ?)
      `)
      .run(docId, customerId, booking.id, docCategory, docTitle, req.file.originalname, req.file.mimetype, req.file.size, fullPath, nowIso());

    recordCustomerAction(req, 'BOOKING_DOCUMENT_UPLOADED', 'Customer Documents', booking.booking_ref, `${docCategory}: ${req.file.originalname}`);
    res.status(201).json({ success: true, documentId: docId, fileName: req.file.originalname });
  });

  // 8. Customer Payments & Invoices
  router.get('/payments', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const payments = sqlite
      .prepare('SELECT * FROM customer_payments WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    const invoices = sqlite
      .prepare('SELECT * FROM customer_invoices WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    res.json({
      payments,
      invoices,
      paymentGatewayConfigured: isPaymentGatewayConfigured(),
    });
  });

  router.get('/invoices', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const invoices = sqlite
      .prepare('SELECT * FROM customer_invoices WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ invoices });
  });

  router.get('/invoices/:id/pdf', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const inv = sqlite.prepare('SELECT * FROM customer_invoices WHERE id = ?').get(req.params.id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    if (inv.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: Cross-customer invoice access denied.' });
      return;
    }

    const pdf = buildSimplePdfBuffer(`BYD PAKISTAN 360 - OFFICIAL CUSTOMER INVOICE`, [
      `Invoice Number: ${inv.invoice_number}`,
      `Customer: ${req.auth!.fullName} (${req.auth!.customerCode})`,
      `Showroom: ${inv.dealership_name}`,
      `Vehicle / Item: ${inv.vehicle_model || inv.item_category}`,
      `Issued Date: ${inv.issued_date} | Due Date: ${inv.due_date}`,
      `Subtotal: PKR ${Number(inv.subtotal_pkr).toLocaleString()}`,
      `Tax (${inv.tax_rate}%): PKR ${Number(inv.tax_amount_pkr).toLocaleString()}`,
      `Total Amount: PKR ${Number(inv.total_amount_pkr).toLocaleString()}`,
      `Amount Paid: PKR ${Number(inv.amount_paid_pkr).toLocaleString()}`,
      `Outstanding Balance: PKR ${Number(inv.outstanding_balance_pkr).toLocaleString()}`,
      `Invoice Status: ${inv.status}`,
      `Founder & CEO Governance: Intekhab Alam — BYD PAKISTAN 360`,
    ]);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${inv.invoice_number}.pdf"`);
    res.send(pdf);
  });

  // 9. Customer Owned Vehicles, Service Requests & History
  router.get('/my-vehicles', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const vehicles = sqlite
      .prepare('SELECT * FROM customer_vehicles WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ vehicles });
  });

  router.post('/my-vehicles', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const vin = String(req.body.vin || '').trim().toUpperCase();
    const model = String(req.body.model || '').trim();
    const variant = String(req.body.variant || 'Standard Edition').trim();
    const licensePlate = String(req.body.licensePlate || '').trim().toUpperCase();
    const color = String(req.body.color || 'Atlantis Grey').trim();
    const modelYear = Number(req.body.modelYear || 2026);
    const registrationDate = String(req.body.registrationDate || nowIso().slice(0, 10)).trim();
    const dealershipName = String(req.body.dealershipName || 'Mega Motor Flagship 3S — Clifton').trim();

    if (!vin || vin.length < 8 || !model || !licensePlate) {
      res.status(400).json({ error: 'Valid VIN (minimum 8 chars), BYD model, and license plate are required.' });
      return;
    }

    const dup = sqlite.prepare('SELECT id, customer_id FROM customer_vehicles WHERE UPPER(vin) = ?').get(vin) as any;
    if (dup) {
      res.status(409).json({
        error: dup.customer_id === customerId
          ? 'This VIN is already registered in your vehicle garage.'
          : 'This VIN is already registered to another verified owner.',
      });
      return;
    }

    const now = nowIso();
    const vehId = `cveh_${generateSecureToken(6)}`;
    const batteryKwh = model === 'BYD Seal' ? 82.5 : model === 'BYD Han EV' ? 85.4 : model === 'BYD Shark 6' ? 29.58 : model === 'BYD Sealion 6' ? 18.3 : 60.48;
    const warrantyEndYear = Number(registrationDate.slice(0, 4) || 2026) + 8;
    const warrantyExpiry = `${warrantyEndYear}${registrationDate.slice(4) || '-01-01'}`;

    sqlite
      .prepare(`
        INSERT INTO customer_vehicles (
          id, customer_id, company_id, country_id, branch_id, dealership_name,
          vin, chassis_number, model, variant, color, model_year, license_plate, registration_date,
          odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
          warranty_start_date, warranty_expiry_date, next_service_due_km, status, ownership_verified, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 100.0, 90.0, ?, ?, 10000, 'Active', 1, ?, ?)
      `)
      .run(
        vehId,
        customerId,
        req.auth!.companyId || 'comp_byd_pk',
        req.auth!.country || 'PK',
        req.auth!.branchId || null,
        dealershipName,
        vin,
        `CHAS-${vin.slice(-6)}`,
        model,
        variant,
        color,
        modelYear,
        licensePlate,
        registrationDate,
        batteryKwh,
        registrationDate,
        warrantyExpiry,
        now,
        now
      );

    // Automatically provision customer warranty record
    const warId = `cwar_${generateSecureToken(6)}`;
    sqlite
      .prepare(`
        INSERT INTO customer_warranty_records (
          id, warranty_number, customer_id, customer_vehicle_id, vin, model, company_id,
          coverage_type, battery_warranty_years, vehicle_warranty_years, start_date, expiry_date,
          terms_summary, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Blade Battery (8 Yr / 160,000 km) & Vehicle Bumper-to-Bumper (6 Yr / 150,000 km)', 8, 6, ?, ?, ?, 'Active', ?, ?)
      `)
      .run(
        warId,
        `WAR-BYD-${generateNumericOtp(5)}`,
        customerId,
        vehId,
        vin,
        model,
        req.auth!.companyId || 'comp_byd_pk',
        registrationDate,
        warrantyExpiry,
        'Official BYD manufacturer Blade Battery & EV drivetrain coverage registered subject to authorized 3S periodic inspection.',
        now,
        now
      );

    recordCustomerAction(req, 'VEHICLE_REGISTERED', 'Customer Vehicles', vin, `${model} (${licensePlate})`);
    res.status(201).json({ success: true, vehicleId: vehId, warrantyId: warId });
  });

  router.get('/service-requests', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const requests = sqlite
      .prepare('SELECT * FROM customer_service_requests WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    const history = sqlite
      .prepare('SELECT * FROM customer_service_history WHERE customer_id = ? ORDER BY service_date DESC')
      .all(customerId);
    res.json({ serviceRequests: requests, serviceHistory: history });
  });

  router.post('/service-requests', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const customerVehicleId = String(req.body.customerVehicleId || '').trim();
    const dealershipId = String(req.body.dealershipId || '').trim();
    const serviceType = String(req.body.serviceType || 'Routine Maintenance (10,000 km)').trim();
    const preferredDate = String(req.body.preferredDate || '').trim();
    const preferredTime = String(req.body.preferredTime || '').trim();
    const complaintDetails = String(req.body.complaintDetails || '').trim();

    if (!customerVehicleId || !dealershipId || !preferredDate || !preferredTime) {
      res.status(400).json({ error: 'Vehicle, authorized service center, preferred date, and time are required.' });
      return;
    }

    const veh = sqlite.prepare('SELECT * FROM customer_vehicles WHERE id = ?').get(customerVehicleId) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: You can only book service for vehicles registered to your account.' });
      return;
    }

    const dlr = sqlite.prepare("SELECT * FROM dealerships WHERE id = ? AND status = 'Approved'").get(dealershipId) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Selected service center is not approved or unavailable.' });
      return;
    }

    const now = nowIso();
    const svcId = `csvc_${generateSecureToken(6)}`;
    const requestNumber = `BYD-SVC-2026-${generateNumericOtp(4)}`;

    sqlite
      .prepare(`
        INSERT INTO customer_service_requests (
          id, request_number, customer_id, customer_vehicle_id, vin, model, license_plate,
          company_id, country_id, branch_id, dealership_id, dealership_name, service_type,
          preferred_date, preferred_time, complaint_details, status, estimated_cost_pkr, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Confirmation', 15000, ?, ?)
      `)
      .run(
        svcId,
        requestNumber,
        customerId,
        veh.id,
        veh.vin,
        veh.model,
        veh.license_plate,
        dlr.company_id || req.auth!.companyId,
        dlr.country || req.auth!.country,
        dlr.branch_id || null,
        dlr.id,
        dlr.name,
        serviceType,
        preferredDate,
        preferredTime,
        complaintDetails,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Service', ?, ?, 'Normal', 'service', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        customerId,
        dlr.company_id || req.auth!.companyId,
        dlr.country || req.auth!.country,
        `Service Request ${requestNumber} Received`,
        `${serviceType} for ${veh.model} (${veh.license_plate}) at ${dlr.name} scheduled for ${preferredDate}.`,
        now
      );

    recordCustomerAction(req, 'SERVICE_REQUEST_CREATED', 'Service & Maintenance', requestNumber, `${veh.vin} at ${dlr.name}`);
    res.status(201).json({ success: true, id: svcId, requestNumber, status: 'Pending Confirmation' });
  });

  // 10. Warranty Management
  router.get('/warranty', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const warranties = sqlite
      .prepare('SELECT * FROM customer_warranty_records WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    const claims = sqlite
      .prepare('SELECT * FROM customer_warranty_claims WHERE customer_id = ? ORDER BY created_at DESC')
      .all(customerId);
    const warrantyServiceHistory = sqlite
      .prepare("SELECT * FROM customer_service_history WHERE customer_id = ? AND (LOWER(service_type) LIKE '%battery%' OR LOWER(service_type) LIKE '%warranty%' OR LOWER(summary) LIKE '%warranty%') ORDER BY service_date DESC")
      .all(customerId);
    res.json({ warranties, claims, warrantyServiceHistory });
  });

  router.post('/warranty/claims', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const warrantyRecordId = String(req.body.warrantyRecordId || '').trim();
    const dealershipName = String(req.body.dealershipName || 'Mega Motor Flagship 3S — Clifton').trim();
    const componentCategory = String(req.body.componentCategory || '').trim();
    const issueDescription = String(req.body.issueDescription || '').trim();
    const faultCode = String(req.body.faultCode || '').trim().toUpperCase();

    if (!warrantyRecordId || !componentCategory || !issueDescription) {
      res.status(400).json({ error: 'Warranty record, component category, and issue description are required.' });
      return;
    }

    const war = sqlite.prepare('SELECT * FROM customer_warranty_records WHERE id = ?').get(warrantyRecordId) as any;
    if (!war) {
      res.status(404).json({ error: 'Warranty record not found.' });
      return;
    }
    if (war.customer_id !== customerId) {
      res.status(403).json({ error: 'Forbidden: Cross-customer warranty access denied.' });
      return;
    }

    const now = nowIso();
    const claimId = `cwclm_${generateSecureToken(6)}`;
    const claimNumber = `BYD-WAR-2026-${generateNumericOtp(4)}`;

    sqlite
      .prepare(`
        INSERT INTO customer_warranty_claims (
          id, claim_number, customer_id, warranty_record_id, vin, vehicle_model, company_id, country_id, branch_id,
          dealership_name, component_category, issue_description, fault_code, submission_date,
          status, claim_amount_pkr, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted', 0, ?, ?)
      `)
      .run(
        claimId,
        claimNumber,
        customerId,
        war.id,
        war.vin,
        war.model,
        war.company_id || req.auth!.companyId,
        req.auth!.country,
        req.auth!.branchId || null,
        dealershipName,
        componentCategory,
        issueDescription,
        faultCode,
        now.slice(0, 10),
        now,
        now
      );

    recordCustomerAction(req, 'WARRANTY_CLAIM_SUBMITTED', 'Warranty Management', claimNumber, `${war.model} (${componentCategory})`);
    res.status(201).json({ success: true, id: claimId, claimNumber, status: 'Submitted' });
  });

  // 11. Notifications & Customer Support
  router.get('/notifications', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const notifications = sqlite
      .prepare('SELECT * FROM customer_notifications WHERE customer_id = ? ORDER BY created_at DESC LIMIT 60')
      .all(req.auth!.customerId!);
    res.json({ notifications });
  });

  router.patch('/notifications/:id/read', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    if (req.params.id === 'all') {
      sqlite.prepare('UPDATE customer_notifications SET is_read = 1 WHERE customer_id = ?').run(customerId);
      res.json({ success: true });
      return;
    }
    const notif = sqlite.prepare('SELECT id, customer_id FROM customer_notifications WHERE id = ?').get(req.params.id) as any;
    if (!notif || notif.customer_id !== customerId) {
      res.status(404).json({ error: 'Notification not found.' });
      return;
    }
    sqlite.prepare('UPDATE customer_notifications SET is_read = 1 WHERE id = ?').run(notif.id);
    res.json({ success: true });
  });

  router.get('/support', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const tickets = sqlite
      .prepare('SELECT * FROM customer_support_tickets WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ tickets });
  });

  router.post('/support', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const category = String(req.body.category || 'General Inquiry').trim();
    const priority = String(req.body.priority || 'Medium').trim();
    const subject = String(req.body.subject || '').trim();
    const description = String(req.body.description || '').trim();

    if (!subject || !description) {
      res.status(400).json({ error: 'Support ticket subject and description are required.' });
      return;
    }

    const now = nowIso();
    const ticketId = `csup_${generateSecureToken(6)}`;
    const ticketNumber = `SUP-CUS-2026-${generateNumericOtp(4)}`;

    sqlite
      .prepare(`
        INSERT INTO customer_support_tickets (
          id, ticket_number, customer_id, company_id, country_id, branch_id, category, priority,
          subject, description, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?)
      `)
      .run(
        ticketId,
        ticketNumber,
        customerId,
        req.auth!.companyId,
        req.auth!.country,
        req.auth!.branchId || null,
        category,
        priority,
        subject,
        description,
        now,
        now
      );

    recordCustomerAction(req, 'SUPPORT_TICKET_CREATED', 'Customer Support', ticketNumber, subject);
    res.status(201).json({ success: true, id: ticketId, ticketNumber, status: 'Open' });
  });

  // 12. Customer Documents (Strictly Isolated Vault)
  router.get('/documents', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const documents = sqlite
      .prepare('SELECT id, customer_id, booking_id, doc_category, doc_title, file_name, mime_type, file_size, verification_status, verified_by, verified_at, created_at FROM customer_booking_documents WHERE customer_id = ? ORDER BY created_at DESC')
      .all(req.auth!.customerId!);
    res.json({ documents });
  });

  router.get('/documents/:docId/download', (req: Request, res: Response) => {
    if (!assertNotImpersonatingCustomer(req, res)) return;
    const customerId = req.auth!.customerId!;
    const doc = sqlite.prepare('SELECT * FROM customer_booking_documents WHERE id = ?').get(req.params.docId) as any;
    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }
    if (doc.customer_id !== customerId) {
      logSecurityEvent({
        severity: 'CRITICAL',
        eventType: 'CROSS_CUSTOMER_DOCUMENT_ACCESS_BLOCKED',
        userId: customerId,
        identifier: req.auth!.email,
        companyId: req.auth!.companyId,
        details: `Customer ${req.auth!.customerCode} attempted unauthorized download of document ${doc.id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Forbidden: Cross-customer document download blocked.' });
      return;
    }

    if (String(doc.storage_path).startsWith('virtual:')) {
      const pdf = buildSimplePdfBuffer(`BYD PAKISTAN 360 - ${doc.doc_category.toUpperCase()}`, [
        `Document Title: ${doc.doc_title}`,
        `Customer: ${req.auth!.fullName} (${req.auth!.customerCode})`,
        `Verification Status: ${doc.verification_status} (${doc.verified_by || 'BYD Official Desk'})`,
        `Issued Date: ${doc.created_at}`,
        `Document Reference: ${doc.id}`,
        `Governance: Founder & CEO Intekhab Alam`,
      ]);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${doc.file_name}"`);
      res.send(pdf);
      return;
    }

    if (!fs.existsSync(doc.storage_path)) {
      res.status(404).json({ error: 'Document file no longer exists on disk.' });
      return;
    }
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${doc.file_name}"`);
    res.sendFile(path.resolve(doc.storage_path));
  });

  return router;
}
