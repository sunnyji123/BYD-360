import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  Search,
  Plus,
  Eye,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  companies: any[];
  legacyUsers: any[];
  userCategory: 'all' | 'employees' | 'dealers' | 'customers';
  onCategoryChange: (c: 'all' | 'employees' | 'dealers' | 'customers') => void;
  onRefreshLegacy: () => Promise<void>;
  onNotify: (msg: string) => void;
}

const NON_ADMIN_ROLES = [
  'Company Admin',
  'Head Office Staff',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Finance Manager',
  'Service Manager',
  'Technical Support',
  'Customer',
];

export const SuperAdminUsersPanel: React.FC<Props> = ({
  companies,
  onRefreshLegacy,
  onNotify,
}) => {
  const [directory, setDirectory] = useState<any[]>([]);
  const [availableRoles, setAvailableRoles] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [showAdd, setShowAdd] = useState(false);
  const [newUser, setNewUser] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    password: '',
    role: 'Customer',
    companyId: 'comp_byd_pk',
    country: 'PK',
    city: 'Karachi',
  });

  const [profileData, setProfileData] = useState<any>(null);
  const [profileLoading, setProfileLoading] = useState(false);

  const loadDirectory = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminUsersDirectory({
        search: search || undefined,
        role: roleFilter,
        status: statusFilter,
      });
      setDirectory(res.users || []);
      setAvailableRoles(res.availableRoles || []);
    } catch (err: any) {
      setError(err?.message || 'Unable to load unified user directory.');
    } finally {
      setLoading(false);
    }
  }, [search, roleFilter, statusFilter]);

  useEffect(() => {
    loadDirectory();
  }, [loadDirectory]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.createSuperAdminUser(newUser);
      onNotify(`User account provisioned (${res.role}).`);
      setShowAdd(false);
      setNewUser({
        fullName: '',
        email: '',
        mobile: '+92 300 ',
        password: '',
        role: 'Customer',
        companyId: 'comp_byd_pk',
        country: 'PK',
        city: 'Karachi',
      });
      await loadDirectory();
      await onRefreshLegacy();
    } catch (err: any) {
      setError(err?.message || 'Failed to create operational user.');
    }
  };

  const handleAccessChange = async (id: string, payload: { status?: string; verificationStatus?: string }) => {
    setError('');
    try {
      await api.updateSuperAdminUserAccess(id, payload);
      onNotify('User account access and verification status updated.');
      await loadDirectory();
      if (profileData?.profile?.id === id) {
        const ref = await api.getSuperAdminUserProfile(id);
        setProfileData(ref);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to update user access.');
    }
  };

  const inspectUser = async (id: string) => {
    setProfileLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminUserProfile(id);
      setProfileData(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to inspect user profile.');
    } finally {
      setProfileLoading(false);
    }
  };

  return (
    <div className="space-y-6 text-xs">
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Unified Identity Directory (Non-Admin &amp; Operational Roles)
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              User Management, Account Activation, KYC Status &amp; Activity History ({directory.length})
            </h3>
            <p className="text-slate-400 mt-0.5">
              Founder / Owner and fellow Super Admin accounts are strictly isolated and protected against Super Admin inspection or tampering.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={loadDirectory}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAdd(!showAdd)}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create User</span>
            </button>
          </div>
        </div>

        {error && <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>}

        {showAdd && (
          <form onSubmit={handleCreateUser} className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/40 grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input required placeholder="Full Name" value={newUser.fullName} onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            <input required type="email" placeholder="Email Address" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            <input required placeholder="Mobile (+92...)" value={newUser.mobile} onChange={(e) => setNewUser({ ...newUser, mobile: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            <input required type="password" placeholder="Strong Password (12+ chars)" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white">
              {NON_ADMIN_ROLES.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
            <select value={newUser.companyId} onChange={(e) => setNewUser({ ...newUser, companyId: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white">
              {(companies.length ? companies : [{ id: 'comp_byd_pk', name: 'Mega Motor Company (BYD Pakistan)' }]).map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <input placeholder="City" value={newUser.city} onChange={(e) => setNewUser({ ...newUser, city: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            <button type="submit" className="rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2">
              Provision Account
            </button>
          </form>
        )}

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, email, user ID, city..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
          <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white">
            <option value="ALL">All Operational Roles</option>
            {availableRoles.map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white">
            <option value="ALL">All Account Statuses</option>
            <option value="Active">Active</option>
            <option value="Pending Verification">Pending Verification</option>
            <option value="Suspended">Suspended</option>
            <option value="Verified">KYC Verified</option>
          </select>
        </div>

        {/* Directory Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">User · ID</th>
                <th className="py-3 px-4">Role · Company</th>
                <th className="py-3 px-4">Registration</th>
                <th className="py-3 px-4">Status · KYC</th>
                <th className="py-3 px-4 text-right">Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {directory.map((u) => (
                <tr key={u.id} className="hover:bg-slate-900/60">
                  <td className="py-3 px-4">
                    <div className="font-bold text-white">{u.full_name}</div>
                    <div className="font-mono text-[11px] text-cyan-300">{u.email}</div>
                    <div className="font-mono text-[10px] text-slate-500">{u.id} · {u.city || '—'}, {u.country_id || 'GLOBAL'}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-white">{u.role}</div>
                    <div className="text-slate-400 text-[11px]">{u.company_name || 'Global Portal'}</div>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-400 tabular-nums">
                    <div>Joined: {u.created_at?.slice(0, 10)}</div>
                    <div>Last Login: {u.last_login_at ? u.last_login_at.slice(0, 10) : 'Never'}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        u.status === 'Active'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : u.status === 'Suspended'
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : 'bg-amber-950 text-amber-300 border-amber-800'
                      }`}
                    >
                      {u.status}
                    </span>
                    <div className="text-[10px] font-mono text-slate-400 mt-1">
                      KYC: {u.verification_status} {u.two_factor_enabled ? '· 2FA' : ''}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="inline-flex flex-wrap justify-end gap-1.5">
                      <button
                        type="button"
                        onClick={() => inspectUser(u.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 font-semibold inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Profile</span>
                      </button>
                      {u.verification_status !== 'Verified' && (
                        <button
                          type="button"
                          onClick={() => handleAccessChange(u.id, { verificationStatus: 'Verified', status: 'Active' })}
                          className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-700 text-emerald-300 font-semibold"
                        >
                          Verify
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleAccessChange(u.id, { status: u.status === 'Suspended' ? 'Active' : 'Suspended' })}
                        className={`px-2.5 py-1 rounded-lg border font-semibold inline-flex items-center gap-1 ${
                          u.status === 'Suspended'
                            ? 'bg-emerald-950 border-emerald-700 text-emerald-300'
                            : 'bg-rose-950 border-rose-700 text-rose-300'
                        }`}
                      >
                        {u.status === 'Suspended' ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                        <span>{u.status === 'Suspended' ? 'Activate' : 'Suspend'}</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {directory.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-slate-500">
                    No Data Available matching user directory filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* User Profile & Login/Activity History Inspector */}
      {profileLoading && <div className="text-center text-slate-400">Loading user profile...</div>}
      {profileData?.profile && (
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="text-[11px] font-mono text-cyan-400">
                {profileData.profile.id} · {profileData.profile.role} · Source: {profileData.profile.source_table || 'users'}
              </div>
              <h4 className="text-base font-black text-white">
                {profileData.profile.full_name} ({profileData.profile.email})
              </h4>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Mobile (Protected): {profileData.profile.mobile} · Company: {profileData.profile.company_name || 'Global'} · Created {profileData.profile.created_at?.slice(0, 10)}
              </div>
            </div>
            <button type="button" onClick={() => setProfileData(null)} className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-300 hover:text-white">
              Close Profile
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h5 className="font-bold text-white">Login &amp; Security Activity History ({profileData.loginHistory?.length || 0})</h5>
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {(profileData.loginHistory || []).map((l: any) => (
                  <div key={l.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px]">
                    <div className="flex justify-between">
                      <span className={l.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                        {l.success ? 'LOGIN OK' : 'LOGIN FAILED'}
                      </span>
                      <span className="text-slate-500">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
                    </div>
                    <div className="text-slate-300">{l.device_name || 'Client'} · {l.browser_name || 'Web'} · IP {l.ip_address}</div>
                  </div>
                ))}
                {(!profileData.loginHistory || profileData.loginHistory.length === 0) && (
                  <div className="text-slate-500">No login events recorded for this user yet.</div>
                )}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <h5 className="font-bold text-white">Verification &amp; Approval Audit Trail ({profileData.approvalHistory?.length || 0})</h5>
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {(profileData.approvalHistory || []).map((a: any) => (
                  <div key={a.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-[11px]">
                    <div className="flex justify-between font-semibold">
                      <span className="text-cyan-300">{a.action}</span>
                      <span className="font-mono text-slate-500">{a.created_at?.slice(0, 16)}</span>
                    </div>
                    <div className="text-slate-300">{a.actor_name} ({a.actor_role}) · {a.previous_status} → {a.new_status}</div>
                    {a.reason && <div className="text-amber-300 mt-0.5">Remark: {a.reason}</div>}
                  </div>
                ))}
                {(!profileData.approvalHistory || profileData.approvalHistory.length === 0) && (
                  <div className="text-slate-500">No approval audit records recorded yet.</div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
