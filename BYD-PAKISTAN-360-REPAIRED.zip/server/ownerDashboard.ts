import express, { Request, Response } from 'express';
import {
  sqlite,
  logOwnerAudit,
  logSecurityAudit,
  nowIso,
  parseUserAgentInfo,
  RBAC_ROLES,
  RBAC_MODULES,
} from './db';
import { requireFounder, getClientIp } from './auth';

type PeriodFilter = 'all' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';

const COUNTRY_GEO_MAP: Record<string, { lat: number; lng: number; mapX: number; mapY: number; region: string }> = {
  PK: { lat: 30.3753, lng: 69.3451, mapX: 693, mapY: 166, region: 'South Asia' },
  AE: { lat: 23.4241, lng: 53.8478, mapX: 650, mapY: 185, region: 'Middle East' },
  SA: { lat: 23.8859, lng: 45.0792, mapX: 625, mapY: 184, region: 'Middle East' },
  GB: { lat: 55.3781, lng: -3.436, mapX: 490, mapY: 96, region: 'Europe' },
  DE: { lat: 51.1657, lng: 10.4515, mapX: 529, mapY: 108, region: 'Europe' },
  US: { lat: 37.0902, lng: -95.7129, mapX: 234, mapY: 147, region: 'North America' },
  CN: { lat: 35.8617, lng: 104.1954, mapX: 789, mapY: 150, region: 'East Asia' },
  TR: { lat: 38.9637, lng: 35.2433, mapX: 598, mapY: 142, region: 'Eurasia' },
  QA: { lat: 25.3548, lng: 51.1839, mapX: 642, mapY: 179, region: 'Middle East' },
  OM: { lat: 21.4735, lng: 55.9754, mapX: 655, mapY: 190, region: 'Middle East' },
};

function resolveDateBounds(periodRaw?: string, fromRaw?: string, toRaw?: string): {
  period: PeriodFilter;
  fromIso: string | null;
  toIso: string | null;
  label: string;
} {
  const p = String(periodRaw || 'all').toLowerCase();
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  if (p === 'daily') {
    return {
      period: 'daily',
      fromIso: `${todayStr}T00:00:00.000Z`,
      toIso: `${todayStr}T23:59:59.999Z`,
      label: `Today (${todayStr})`,
    };
  }
  if (p === 'weekly') {
    const start = new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000);
    return {
      period: 'weekly',
      fromIso: `${start.toISOString().slice(0, 10)}T00:00:00.000Z`,
      toIso: `${todayStr}T23:59:59.999Z`,
      label: `Last 7 Days (${start.toISOString().slice(0, 10)} to ${todayStr})`,
    };
  }
  if (p === 'monthly') {
    const monthStart = `${todayStr.slice(0, 7)}-01T00:00:00.000Z`;
    return {
      period: 'monthly',
      fromIso: monthStart,
      toIso: `${todayStr}T23:59:59.999Z`,
      label: `Current Month (${todayStr.slice(0, 7)})`,
    };
  }
  if (p === 'yearly') {
    const yearStart = `${todayStr.slice(0, 4)}-01-01T00:00:00.000Z`;
    return {
      period: 'yearly',
      fromIso: yearStart,
      toIso: `${todayStr}T23:59:59.999Z`,
      label: `Current Year (${todayStr.slice(0, 4)})`,
    };
  }
  if (p === 'custom' && (fromRaw || toRaw)) {
    const f = fromRaw ? `${String(fromRaw).slice(0, 10)}T00:00:00.000Z` : null;
    const t = toRaw ? `${String(toRaw).slice(0, 10)}T23:59:59.999Z` : null;
    return {
      period: 'custom',
      fromIso: f,
      toIso: t,
      label: `Custom (${fromRaw || 'Start'} to ${toRaw || 'Present'})`,
    };
  }
  return {
    period: 'all',
    fromIso: null,
    toIso: null,
    label: 'All Verified Database Records',
  };
}

function inDateRange(ts: string | null | undefined, fromIso: string | null, toIso: string | null): boolean {
  if (!fromIso && !toIso) return true;
  if (!ts) return false;
  const normalized = ts.length === 10 ? `${ts}T12:00:00.000Z` : ts;
  if (fromIso && normalized < fromIso) return false;
  if (toIso && normalized > toIso) return false;
  return true;
}

function normalizeCountryCode(val: string | null | undefined, companiesMap: Map<string, any>, companyId?: string | null): string {
  const direct = String(val || '').trim().toUpperCase();
  if (direct) return direct;
  if (companyId && companiesMap.has(companyId)) {
    return String(companiesMap.get(companyId).country || '').trim().toUpperCase();
  }
  return 'UNASSIGNED';
}

function computeVerifiedLedger(params: {
  fromIso: string | null;
  toIso: string | null;
  countryFilter: string | null;
}) {
  const companies = sqlite.prepare('SELECT id, name, country, city, status FROM companies').all() as any[];
  const companiesMap = new Map<string, any>(companies.map((c) => [c.id, c]));
  const branches = sqlite.prepare('SELECT id, name, company_id, country_id, city FROM branches').all() as any[];
  const branchesMap = new Map<string, any>(branches.map((b) => [b.id, b]));
  const dealerAccounts = sqlite.prepare('SELECT id, business_name, dealer_code, country_id, company_id, branch_id FROM dealer_accounts').all() as any[];
  const dealerAccMap = new Map<string, any>(dealerAccounts.map((d) => [d.id, d]));

  const dealerSales = sqlite.prepare('SELECT * FROM dealer_sales ORDER BY created_at DESC').all() as any[];
  const branchSales = sqlite.prepare('SELECT * FROM branch_sales ORDER BY created_at DESC').all() as any[];
  const invoices = sqlite.prepare('SELECT * FROM payments_invoices ORDER BY COALESCE(issued_date, created_at) DESC').all() as any[];
  const dealerBookings = sqlite.prepare('SELECT * FROM dealer_bookings ORDER BY created_at DESC').all() as any[];
  const customerBookings = sqlite.prepare('SELECT * FROM customer_bookings ORDER BY created_at DESC').all() as any[];
  const branchExpenses = sqlite.prepare('SELECT * FROM branch_expenses ORDER BY COALESCE(expense_date, created_at) DESC').all() as any[];
  const commissions = sqlite.prepare('SELECT * FROM dealer_commissions ORDER BY created_at DESC').all() as any[];
  const salaries = sqlite.prepare('SELECT * FROM employee_salary_records ORDER BY COALESCE(payment_date, created_at) DESC').all() as any[];

  const matchCountry = (code: string) => !params.countryFilter || params.countryFilter === 'ALL' || code === params.countryFilter;

  const linkedInvoiceIdsInBranchSales = new Set<string>(
    branchSales.map((bs) => String(bs.invoice_id || '')).filter(Boolean)
  );

  let totalVehicleSalesValue = 0;
  let totalReceivedPayments = 0;
  let pendingPayments = 0;
  let operatingExpenses = 0;
  let commissionExpenses = 0;
  let payrollExpenses = 0;

  const countryLedger = new Map<string, {
    countryCode: string;
    vehicleSalesValue: number;
    receivedPayments: number;
    pendingPayments: number;
    operatingExpenses: number;
    commissionExpenses: number;
    payrollExpenses: number;
    totalExpenses: number;
    netProfit: number;
    completedSalesCount: number;
    pendingOrdersCount: number;
  }>();

  const ensureCountryRow = (code: string) => {
    if (!countryLedger.has(code)) {
      countryLedger.set(code, {
        countryCode: code,
        vehicleSalesValue: 0,
        receivedPayments: 0,
        pendingPayments: 0,
        operatingExpenses: 0,
        commissionExpenses: 0,
        payrollExpenses: 0,
        totalExpenses: 0,
        netProfit: 0,
        completedSalesCount: 0,
        pendingOrdersCount: 0,
      });
    }
    return countryLedger.get(code)!;
  };

  const transactions: any[] = [];
  const timeBuckets = new Map<string, { period: string; revenue: number; expenses: number; profit: number; pending: number }>();
  const ensureBucket = (isoTs: string) => {
    const key = String(isoTs || nowIso()).slice(0, 10);
    if (!timeBuckets.has(key)) {
      timeBuckets.set(key, { period: key, revenue: 0, expenses: 0, profit: 0, pending: 0 });
    }
    return timeBuckets.get(key)!;
  };

  // 1. Dealer Sales
  for (const ds of dealerSales) {
    const cc = normalizeCountryCode(ds.country_id, companiesMap, ds.company_id);
    if (!matchCountry(cc) || !inDateRange(ds.created_at, params.fromIso, params.toIso)) continue;
    const saleAmt = Number(ds.sale_amount_pkr || 0);
    const paidAmt = Number(ds.paid_amount_pkr || 0);
    const isVerifiedPaid = ['Payment Verified', 'Paid', 'Settled'].includes(String(ds.payment_status || ''));
    const cleared = isVerifiedPaid ? paidAmt : 0;
    const unpaidDelta = Math.max(0, saleAmt - cleared);

    totalVehicleSalesValue += saleAmt;
    totalReceivedPayments += cleared;
    pendingPayments += unpaidDelta;

    const cRow = ensureCountryRow(cc);
    cRow.vehicleSalesValue += saleAmt;
    cRow.receivedPayments += cleared;
    cRow.pendingPayments += unpaidDelta;
    if (ds.delivery_status === 'Delivered' || isVerifiedPaid) cRow.completedSalesCount += 1;

    const b = ensureBucket(ds.created_at);
    b.revenue += cleared;
    b.pending += unpaidDelta;

    const dInfo = dealerAccMap.get(ds.dealer_id);
    transactions.push({
      id: ds.id,
      ref: ds.sale_ref || ds.id,
      type: 'Dealer Vehicle Sale',
      direction: 'INFLOW',
      countryCode: cc,
      entityName: dInfo?.business_name || ds.dealer_id,
      description: `${ds.vehicle_model} (${ds.vin || 'VIN Pending'})`,
      amount: saleAmt,
      clearedAmount: cleared,
      pendingAmount: unpaidDelta,
      currency: 'PKR',
      status: ds.payment_status,
      deliveryStatus: ds.delivery_status,
      date: ds.created_at,
    });
  }

  // 2. Payments & Invoices (Paid only counted as received; unpaid stays pending)
  for (const inv of invoices) {
    const cc = normalizeCountryCode(inv.country, companiesMap, inv.company_id);
    const ts = inv.issued_date ? `${inv.issued_date}T12:00:00.000Z` : inv.created_at;
    if (!matchCountry(cc) || !inDateRange(ts, params.fromIso, params.toIso)) continue;
    const amt = Number(inv.total_amount || 0);
    const isPaid = inv.status === 'Paid';
    const isVoid = ['Cancelled', 'Refunded', 'Void'].includes(String(inv.status || ''));
    if (isVoid) continue;

    if (isPaid) {
      totalVehicleSalesValue += amt;
      totalReceivedPayments += amt;
      ensureCountryRow(cc).vehicleSalesValue += amt;
      ensureCountryRow(cc).receivedPayments += amt;
      ensureCountryRow(cc).completedSalesCount += 1;
      ensureBucket(ts).revenue += amt;
    } else {
      pendingPayments += amt;
      ensureCountryRow(cc).pendingPayments += amt;
      ensureBucket(ts).pending += amt;
    }

    transactions.push({
      id: inv.id,
      ref: inv.invoice_number || inv.id,
      type: inv.item_category || 'Official Invoice',
      direction: 'INFLOW',
      countryCode: cc,
      entityName: inv.dealership_name || inv.customer_name || inv.company_id,
      description: `Invoice ${inv.invoice_number} — ${inv.customer_name || 'Client'}`,
      amount: amt,
      clearedAmount: isPaid ? amt : 0,
      pendingAmount: isPaid ? 0 : amt,
      currency: inv.currency || 'PKR',
      status: inv.status,
      deliveryStatus: isPaid ? 'Settled' : 'Awaiting Settlement',
      date: ts,
    });
  }

  // 3. Direct Branch Sales that do NOT already have a payments_invoices link (prevents double counting)
  for (const bs of branchSales) {
    if (bs.invoice_id && linkedInvoiceIdsInBranchSales.has(String(bs.invoice_id))) {
      // Check if that invoice exists in payments_invoices; if yes, already accounted above
      if (invoices.some((i) => i.id === bs.invoice_id)) continue;
    }
    const cc = normalizeCountryCode(bs.country_id, companiesMap, bs.company_id);
    if (!matchCountry(cc) || !inDateRange(bs.created_at, params.fromIso, params.toIso)) continue;
    const amt = Number(bs.sale_amount_pkr || 0);
    const paid = bs.payment_status === 'Paid' ? Number(bs.paid_amount_pkr || amt) : 0;
    const pend = Math.max(0, amt - paid);

    totalVehicleSalesValue += amt;
    totalReceivedPayments += paid;
    pendingPayments += pend;

    const cRow = ensureCountryRow(cc);
    cRow.vehicleSalesValue += amt;
    cRow.receivedPayments += paid;
    cRow.pendingPayments += pend;
    if (bs.delivery_status === 'Delivered' || bs.payment_status === 'Paid') cRow.completedSalesCount += 1;

    ensureBucket(bs.created_at).revenue += paid;
    ensureBucket(bs.created_at).pending += pend;

    transactions.push({
      id: bs.id,
      ref: bs.order_number || bs.id,
      type: 'Direct Branch Sale',
      direction: 'INFLOW',
      countryCode: cc,
      entityName: branchesMap.get(bs.branch_id)?.name || bs.branch_id,
      description: `${bs.vehicle_model} (${bs.customer_name})`,
      amount: amt,
      clearedAmount: paid,
      pendingAmount: pend,
      currency: 'PKR',
      status: bs.payment_status,
      deliveryStatus: bs.delivery_status,
      date: bs.created_at,
    });
  }

  // 4. Unconverted / Unpaid Dealer & Customer Bookings -> strictly Pending Payments, NEVER Received Revenue
  for (const dbk of dealerBookings) {
    if (['Converted to Sale', 'Cancelled', 'Rejected'].includes(String(dbk.booking_status || ''))) continue;
    const cc = normalizeCountryCode(dbk.country_id, companiesMap, dbk.company_id);
    if (!matchCountry(cc) || !inDateRange(dbk.created_at, params.fromIso, params.toIso)) continue;
    const isPaid = dbk.payment_status === 'Fully Paid';
    if (isPaid) continue; // converted/paid tracked in dealer_sales
    const amt = Number(dbk.agreed_price_pkr || 0);
    pendingPayments += amt;
    ensureCountryRow(cc).pendingPayments += amt;
    ensureCountryRow(cc).pendingOrdersCount += 1;
    ensureBucket(dbk.created_at).pending += amt;

    transactions.push({
      id: dbk.id,
      ref: dbk.booking_ref || dbk.id,
      type: 'Pending Dealer Order',
      direction: 'PENDING',
      countryCode: cc,
      entityName: dealerAccMap.get(dbk.dealer_id)?.business_name || dbk.dealer_id,
      description: `${dbk.vehicle_model} — Unpaid Pending Order`,
      amount: amt,
      clearedAmount: 0,
      pendingAmount: amt,
      currency: 'PKR',
      status: dbk.payment_status || 'Pending Verification',
      deliveryStatus: dbk.booking_status,
      date: dbk.created_at,
    });
  }

  for (const cbk of customerBookings) {
    if (['Cancelled', 'Rejected'].includes(String(cbk.booking_status || ''))) continue;
    const cc = normalizeCountryCode(cbk.country_id, companiesMap, cbk.company_id);
    if (!matchCountry(cc) || !inDateRange(cbk.created_at, params.fromIso, params.toIso)) continue;
    const quoted = Number(cbk.quoted_price_pkr || 0);
    const deposit = cbk.payment_status === 'Fully Paid' ? Number(cbk.booking_deposit_pkr || 0) : 0;
    const outstanding = Math.max(0, quoted - deposit);
    if (outstanding > 0) {
      pendingPayments += outstanding;
      ensureCountryRow(cc).pendingPayments += outstanding;
      ensureCountryRow(cc).pendingOrdersCount += 1;
      ensureBucket(cbk.created_at).pending += outstanding;
    }
  }

  // 5. Operating Expenses (branch_expenses)
  for (const exp of branchExpenses) {
    if (String(exp.status || '') === 'Cancelled') continue;
    const branch = branchesMap.get(exp.branch_id);
    const cc = normalizeCountryCode(branch?.country_id, companiesMap, exp.company_id);
    const ts = exp.expense_date ? `${exp.expense_date}T12:00:00.000Z` : exp.created_at;
    if (!matchCountry(cc) || !inDateRange(ts, params.fromIso, params.toIso)) continue;
    const amt = Number(exp.amount_pkr || 0);
    operatingExpenses += amt;
    ensureCountryRow(cc).operatingExpenses += amt;
    ensureBucket(ts).expenses += amt;

    transactions.push({
      id: exp.id,
      ref: exp.id,
      type: `Operating Expense (${exp.category})`,
      direction: 'OUTFLOW',
      countryCode: cc,
      entityName: branch?.name || exp.branch_id,
      description: exp.title,
      amount: amt,
      clearedAmount: amt,
      pendingAmount: 0,
      currency: 'PKR',
      status: exp.status,
      deliveryStatus: 'Recorded Expense',
      date: ts,
    });
  }

  // 6. Dealer Commissions
  for (const comm of commissions) {
    if (!['Paid', 'Approved'].includes(String(comm.status || ''))) continue;
    const cc = normalizeCountryCode(comm.country_id, companiesMap, comm.company_id);
    if (!matchCountry(cc) || !inDateRange(comm.created_at, params.fromIso, params.toIso)) continue;
    const amt = Number(comm.commission_amount_pkr || 0);
    commissionExpenses += amt;
    ensureCountryRow(cc).commissionExpenses += amt;
    ensureBucket(comm.created_at).expenses += amt;

    transactions.push({
      id: comm.id,
      ref: comm.payout_reference || comm.id,
      type: 'Dealer Commission Payout',
      direction: 'OUTFLOW',
      countryCode: cc,
      entityName: dealerAccMap.get(comm.dealer_id)?.business_name || comm.dealer_id,
      description: `Commission (${comm.commission_rate_pct}%) on sale ${comm.sale_id}`,
      amount: amt,
      clearedAmount: comm.status === 'Paid' ? amt : 0,
      pendingAmount: comm.status === 'Approved' ? amt : 0,
      currency: 'PKR',
      status: comm.status,
      deliveryStatus: 'Commission Ledger',
      date: comm.created_at,
    });
  }

  // 7. Payroll Expenses (Paid employee salary records)
  for (const sal of salaries) {
    if (sal.payment_status !== 'Paid') continue;
    const cc = normalizeCountryCode(sal.country_id, companiesMap, sal.company_id);
    const ts = sal.payment_date ? `${sal.payment_date}T12:00:00.000Z` : sal.created_at;
    if (!matchCountry(cc) || !inDateRange(ts, params.fromIso, params.toIso)) continue;
    const amt = Number(sal.net_salary || 0);
    payrollExpenses += amt;
    ensureCountryRow(cc).payrollExpenses += amt;
    ensureBucket(ts).expenses += amt;
  }

  const totalExpenses = operatingExpenses + commissionExpenses + payrollExpenses;
  const netProfit = totalReceivedPayments - totalExpenses;

  for (const row of countryLedger.values()) {
    row.totalExpenses = row.operatingExpenses + row.commissionExpenses + row.payrollExpenses;
    row.netProfit = row.receivedPayments - row.totalExpenses;
  }

  for (const b of timeBuckets.values()) {
    b.profit = b.revenue - b.expenses;
  }

  const timeSeries = Array.from(timeBuckets.values()).sort((a, b) => a.period.localeCompare(b.period));
  transactions.sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));

  return {
    totalCompanyRevenue: totalReceivedPayments,
    totalVehicleSalesValue,
    totalReceivedPayments,
    pendingPayments,
    outstandingAmount: pendingPayments,
    operatingExpenses,
    commissionExpenses,
    payrollExpenses,
    totalExpenses,
    netProfit,
    profitMarginPct: totalReceivedPayments > 0 ? Number(((netProfit / totalReceivedPayments) * 100).toFixed(2)) : 0,
    countryLedger,
    timeSeries,
    transactions,
  };
}

export function createOwnerDashboardRouter() {
  const router = express.Router();

  // =========================================================================
  // 1. CENTRALIZED FOUNDER ANALYTICS OVERVIEW
  // =========================================================================
  router.get('/analytics-overview', requireFounder, (req: Request, res: Response) => {
    const ledger = computeVerifiedLedger({ fromIso: null, toIso: null, countryFilter: null });

    const totalCountries = (sqlite.prepare("SELECT COUNT(*) as c FROM countries WHERE status = 'Active'").get() as any).c;
    const operationalCountries = (sqlite.prepare(`
      SELECT COUNT(DISTINCT country_id) as c FROM (
        SELECT country as country_id FROM companies WHERE status = 'Approved'
        UNION ALL
        SELECT country_id FROM branches WHERE status = 'Active'
      )
    `).get() as any).c;

    const totalRegisteredCompanies = (sqlite.prepare('SELECT COUNT(*) as c FROM companies').get() as any).c;
    const approvedCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Approved'").get() as any).c;
    const pendingCompanies = (sqlite.prepare("SELECT COUNT(*) as c FROM companies WHERE status = 'Pending Approval'").get() as any).c;

    const totalBranches = (sqlite.prepare('SELECT COUNT(*) as c FROM branches').get() as any).c;
    const activeBranches = (sqlite.prepare("SELECT COUNT(*) as c FROM branches WHERE status = 'Active'").get() as any).c;

    const totalDealerships = (sqlite.prepare('SELECT COUNT(*) as c FROM dealerships').get() as any).c;
    const activeDealerships = (sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE status = 'Approved'").get() as any).c;

    const totalEmployees = (sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts').get() as any).c;
    const activeEmployees = (sqlite.prepare("SELECT COUNT(*) as c FROM employee_accounts WHERE status = 'Active'").get() as any).c;

    const totalCustomers = (sqlite.prepare('SELECT COUNT(*) as c FROM customer_accounts').get() as any).c;
    const verifiedCustomers = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_accounts WHERE verification_status = 'Verified'").get() as any).c;

    const totalVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles').get() as any).c;
    const soldVehicles = (sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE sold_at IS NOT NULL').get() as any).c;
    const availableVehicles = Math.max(0, totalVehicles - soldVehicles);

    const dealerSalesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_sales').get() as any).c;
    const branchSalesCount = (sqlite.prepare('SELECT COUNT(*) as c FROM branch_sales').get() as any).c;
    const pendingDealerOrders = (sqlite.prepare("SELECT COUNT(*) as c FROM dealer_bookings WHERE booking_status NOT IN ('Converted to Sale', 'Cancelled', 'Rejected')").get() as any).c;
    const pendingCustOrders = (sqlite.prepare("SELECT COUNT(*) as c FROM customer_bookings WHERE booking_status NOT IN ('Completed', 'Cancelled', 'Rejected')").get() as any).c;
    const cancelledOrders =
      (sqlite.prepare("SELECT COUNT(*) as c FROM dealer_bookings WHERE booking_status IN ('Cancelled', 'Rejected')").get() as any).c +
      (sqlite.prepare("SELECT COUNT(*) as c FROM customer_bookings WHERE booking_status IN ('Cancelled', 'Rejected')").get() as any).c;

    const totalVehicleSales = dealerSalesCount + branchSalesCount;
    const pendingOrders = pendingDealerOrders + pendingCustOrders;

    const totalSuperAdmins = (sqlite.prepare('SELECT COUNT(*) as c FROM super_admin_accounts').get() as any).c;
    const activeSuperAdmins = (sqlite.prepare("SELECT COUNT(*) as c FROM super_admin_accounts WHERE status = 'Active'").get() as any).c;

    const activeSessions = (sqlite
      .prepare('SELECT COUNT(*) as c FROM authentication_sessions WHERE revoked = 0 AND expires_at > ?')
      .get(nowIso()) as any).c;
    const unacknowledgedAlerts = (sqlite.prepare('SELECT COUNT(*) as c FROM security_events WHERE acknowledged = 0').get() as any).c;

    if (String(req.query.track || '') === '1') {
      logOwnerAudit({
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        action: 'OWNER_DASHBOARD_VIEWED',
        module: 'Founder Command Center',
        targetId: 'Global Enterprise Overview',
        details: `Reviewed global KPIs (${totalRegisteredCompanies} companies, ${totalEmployees} employees, ${totalVehicleSales} sales)`,
        ipAddress: getClientIp(req),
        userAgent: req.headers['user-agent'] || null,
        sessionId: req.auth!.sessionId || null,
      });
    }

    res.json({
      overview: {
        totalCountries,
        operationalCountries,
        totalRegisteredCompanies,
        approvedCompanies,
        pendingCompanies,
        totalBranches,
        activeBranches,
        totalDealerships,
        activeDealerships,
        totalEmployees,
        activeEmployees,
        totalCustomers,
        verifiedCustomers,
        totalVehicles,
        soldVehicles,
        availableVehicles,
        totalVehicleSales,
        completedSales: totalVehicleSales,
        pendingOrders,
        cancelledOrders,
        totalSuperAdmins,
        activeSuperAdmins,
        totalRevenue: ledger.totalReceivedPayments,
        totalVehicleSalesValue: ledger.totalVehicleSalesValue,
        receivedPayments: ledger.totalReceivedPayments,
        pendingPayments: ledger.pendingPayments,
        outstandingAmount: ledger.outstandingAmount,
        totalExpenses: ledger.totalExpenses,
        operatingExpenses: ledger.operatingExpenses,
        commissionExpenses: ledger.commissionExpenses,
        payrollExpenses: ledger.payrollExpenses,
        netProfit: ledger.netProfit,
        profitMarginPct: ledger.profitMarginPct,
        activeSessions,
        unacknowledgedAlerts,
      },
      timeSeries: ledger.timeSeries,
    });
  });

  // =========================================================================
  // 2. ALL COUNTRIES GLOBAL DATA + INTERACTIVE MAP METRICS
  // =========================================================================
  router.get('/countries', requireFounder, (_req: Request, res: Response) => {
    const countries = sqlite.prepare('SELECT * FROM countries ORDER BY name ASC').all() as any[];
    const companies = sqlite.prepare('SELECT id, name, country, city, status FROM companies').all() as any[];
    const branches = sqlite.prepare('SELECT * FROM branches').all() as any[];
    const dealerships = sqlite.prepare('SELECT * FROM dealerships').all() as any[];
    const employees = sqlite.prepare('SELECT id, country_id, status, performance_score FROM employee_accounts').all() as any[];
    const customers = sqlite.prepare('SELECT id, country_id, country, status FROM customer_accounts').all() as any[];
    const vehicles = sqlite.prepare('SELECT id, company_id, dealership_id, branch_id, sold_at FROM vehicles').all() as any[];
    const ledger = computeVerifiedLedger({ fromIso: null, toIso: null, countryFilter: null });

    const branchMap = new Map(branches.map((b) => [b.id, b]));
    const companyMap = new Map(companies.map((c) => [c.id, c]));

    const countryRows = countries.map((c) => {
      const code = String(c.code || c.id).toUpperCase();
      const cCompanies = companies.filter((co) => String(co.country || '').toUpperCase() === code);
      const cBranches = branches.filter((b) => String(b.country_id || '').toUpperCase() === code);
      const cDealerships = dealerships.filter((d) => String(d.country || '').toUpperCase() === code);
      const cEmployees = employees.filter((e) => String(e.country_id || '').toUpperCase() === code);
      const cCustomers = customers.filter((cu) => String(cu.country_id || cu.country || '').toUpperCase() === code);
      const cVehicles = vehicles.filter((v) => {
        const b = branchMap.get(v.branch_id);
        const co = companyMap.get(v.company_id);
        const vc = String(b?.country_id || co?.country || '').toUpperCase();
        return vc === code;
      });
      const cSoldVehicles = cVehicles.filter((v) => Boolean(v.sold_at)).length;
      const fin = ledger.countryLedger.get(code);

      const targetUnits = cBranches.reduce((acc, b) => acc + Number(b.monthly_target_units || 0), 0) ||
        cDealerships.reduce((acc, d) => acc + Number(d.monthly_target_units || 0), 0);
      const achievedUnits = cBranches.reduce((acc, b) => acc + Number(b.achieved_units || 0), 0) ||
        cDealerships.reduce((acc, d) => acc + Number(d.achieved_units || 0), 0);
      const performancePct = targetUnits > 0 ? Number(((achievedUnits / targetUnits) * 100).toFixed(1)) : null;

      const avgEmpScore =
        cEmployees.length > 0
          ? Number((cEmployees.reduce((s, e) => s + Number(e.performance_score || 0), 0) / cEmployees.length).toFixed(1))
          : null;

      const hasOperations =
        cCompanies.length > 0 ||
        cBranches.length > 0 ||
        cDealerships.length > 0 ||
        cEmployees.length > 0 ||
        cCustomers.length > 0 ||
        cVehicles.length > 0 ||
        (fin?.completedSalesCount || 0) > 0;

      const geo = COUNTRY_GEO_MAP[code] || { lat: 25, lng: 55, mapX: 640, mapY: 180, region: 'Global' };

      return {
        id: c.id,
        code,
        name: c.name,
        flagEmoji: c.flag_emoji || '',
        currency: c.currency || 'PKR',
        headquartersCity: c.headquarters_city || null,
        status: c.status,
        hasOperations,
        geo,
        companiesCount: cCompanies.length,
        companies: cCompanies.map((co) => ({ id: co.id, name: co.name, status: co.status, city: co.city })),
        branchesCount: cBranches.length,
        dealershipsCount: cDealerships.length,
        activeDealershipsCount: cDealerships.filter((d) => d.status === 'Approved').length,
        employeesCount: cEmployees.length,
        customersCount: cCustomers.length,
        inventoryTotal: cVehicles.length,
        inventoryAvailable: Math.max(0, cVehicles.length - cSoldVehicles),
        inventorySold: cSoldVehicles,
        vehicleSalesCount: fin?.completedSalesCount || 0,
        pendingOrdersCount: fin?.pendingOrdersCount || 0,
        revenue: fin?.receivedPayments || 0,
        vehicleSalesValue: fin?.vehicleSalesValue || 0,
        pendingPayments: fin?.pendingPayments || 0,
        expenses: fin?.totalExpenses || 0,
        operatingExpenses: fin?.operatingExpenses || 0,
        commissionExpenses: fin?.commissionExpenses || 0,
        payrollExpenses: fin?.payrollExpenses || 0,
        netProfit: fin?.netProfit || 0,
        targetUnits,
        achievedUnits,
        performancePct,
        avgEmployeeScore: avgEmpScore,
      };
    });

    res.json({
      totalRegisteredCountries: countryRows.length,
      activeOperationalCountries: countryRows.filter((c) => c.hasOperations).length,
      countries: countryRows,
    });
  });

  // =========================================================================
  // 3. TOTAL REVENUE & FINANCIAL OVERVIEW (Daily/Weekly/Monthly/Yearly/Custom)
  // =========================================================================
  router.get('/finance', requireFounder, (req: Request, res: Response) => {
    const periodParam = String(req.query.period || 'all');
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const countryParam = req.query.countryId ? String(req.query.countryId).toUpperCase() : 'ALL';

    const bounds = resolveDateBounds(periodParam, fromDate, toDate);
    const ledger = computeVerifiedLedger({
      fromIso: bounds.fromIso,
      toIso: bounds.toIso,
      countryFilter: countryParam === 'ALL' ? null : countryParam,
    });

    const countryRows = Array.from(ledger.countryLedger.values()).sort((a, b) => b.receivedPayments - a.receivedPayments);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'FINANCIAL_REPORT_ACCESSED',
      module: 'Founder Financial Intelligence',
      targetId: `${bounds.period.toUpperCase()} / ${countryParam}`,
      details: `Accessed financial report (${bounds.label}). Received: ${ledger.totalReceivedPayments}, Expenses: ${ledger.totalExpenses}, Net Profit: ${ledger.netProfit}`,
      ipAddress: getClientIp(req),
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    res.json({
      filter: {
        period: bounds.period,
        label: bounds.label,
        fromDate: bounds.fromIso,
        toDate: bounds.toIso,
        countryId: countryParam,
      },
      summary: {
        totalCompanyRevenue: ledger.totalCompanyRevenue,
        totalVehicleSalesValue: ledger.totalVehicleSalesValue,
        totalReceivedPayments: ledger.totalReceivedPayments,
        pendingPayments: ledger.pendingPayments,
        outstandingAmount: ledger.outstandingAmount,
        totalExpenses: ledger.totalExpenses,
        operatingExpenses: ledger.operatingExpenses,
        commissionExpenses: ledger.commissionExpenses,
        payrollExpenses: ledger.payrollExpenses,
        netProfit: ledger.netProfit,
        profitMarginPct: ledger.profitMarginPct,
      },
      countryFinancialReports: countryRows,
      timeSeries: ledger.timeSeries,
      transactions: ledger.transactions,
    });
  });

  // =========================================================================
  // 4. TOTAL VEHICLE SALES & ORDER PIPELINE + DRILL-DOWN
  // =========================================================================
  router.get('/sales', requireFounder, (req: Request, res: Response) => {
    const periodParam = String(req.query.period || 'all');
    const fromDate = req.query.fromDate ? String(req.query.fromDate) : undefined;
    const toDate = req.query.toDate ? String(req.query.toDate) : undefined;
    const countryFilter = req.query.countryId ? String(req.query.countryId).toUpperCase() : 'ALL';
    const statusFilter = req.query.status ? String(req.query.status).toLowerCase() : 'all';
    const search = req.query.search ? String(req.query.search).trim().toLowerCase() : '';

    const bounds = resolveDateBounds(periodParam, fromDate, toDate);
    const companies = sqlite.prepare('SELECT id, name, country FROM companies').all() as any[];
    const companiesMap = new Map(companies.map((c) => [c.id, c]));
    const branches = sqlite.prepare('SELECT id, name, country_id, city FROM branches').all() as any[];
    const branchesMap = new Map(branches.map((b) => [b.id, b]));
    const dealers = sqlite.prepare('SELECT id, business_name, dealer_code FROM dealer_accounts').all() as any[];
    const dealersMap = new Map(dealers.map((d) => [d.id, d]));
    const customers = sqlite.prepare('SELECT id, full_name, customer_code FROM customer_accounts').all() as any[];
    const customersMap = new Map(customers.map((c) => [c.id, c]));

    const records: any[] = [];

    // Verified Dealer Sales
    for (const ds of sqlite.prepare('SELECT * FROM dealer_sales ORDER BY created_at DESC').all() as any[]) {
      const cc = normalizeCountryCode(ds.country_id, companiesMap, ds.company_id);
      if (!inDateRange(ds.created_at, bounds.fromIso, bounds.toIso)) continue;
      if (countryFilter !== 'ALL' && cc !== countryFilter) continue;
      const cust = customersMap.get(ds.customer_id);
      const dlr = dealersMap.get(ds.dealer_id);
      const statusCategory = ds.delivery_status === 'Cancelled' ? 'cancelled' : 'completed';
      records.push({
        id: ds.id,
        source: 'dealer_sales',
        orderRef: ds.sale_ref || ds.id,
        vehicleModel: ds.vehicle_model,
        vin: ds.vin || 'N/A',
        countryCode: cc,
        companyName: companiesMap.get(ds.company_id)?.name || ds.company_id,
        branchName: branchesMap.get(ds.branch_id)?.name || ds.branch_id || 'Unassigned',
        dealershipName: dlr?.business_name || ds.dealer_id || 'Direct',
        customerName: cust?.full_name || ds.customer_id || 'Walk-in / Verified Buyer',
        saleAmount: Number(ds.sale_amount_pkr || 0),
        paidAmount: ['Payment Verified', 'Paid', 'Settled'].includes(String(ds.payment_status || '')) ? Number(ds.paid_amount_pkr || 0) : 0,
        paymentStatus: ds.payment_status,
        orderStatus: ds.delivery_status || 'Completed',
        statusCategory,
        createdAt: ds.created_at,
      });
    }

    // Direct Branch Sales (excluding if duplicate? Include clearly labeled channel)
    for (const bs of sqlite.prepare('SELECT * FROM branch_sales ORDER BY created_at DESC').all() as any[]) {
      const cc = normalizeCountryCode(bs.country_id, companiesMap, bs.company_id);
      if (!inDateRange(bs.created_at, bounds.fromIso, bounds.toIso)) continue;
      if (countryFilter !== 'ALL' && cc !== countryFilter) continue;
      const statusCategory = bs.delivery_status === 'Cancelled' ? 'cancelled' : 'completed';
      records.push({
        id: bs.id,
        source: 'branch_sales',
        orderRef: bs.order_number || bs.id,
        vehicleModel: bs.vehicle_model,
        vin: bs.vin || 'N/A',
        countryCode: cc,
        companyName: companiesMap.get(bs.company_id)?.name || bs.company_id,
        branchName: branchesMap.get(bs.branch_id)?.name || bs.branch_id,
        dealershipName: 'Branch Direct Showroom',
        customerName: bs.customer_name || bs.customer_id,
        saleAmount: Number(bs.sale_amount_pkr || 0),
        paidAmount: bs.payment_status === 'Paid' ? Number(bs.paid_amount_pkr || 0) : 0,
        paymentStatus: bs.payment_status,
        orderStatus: bs.delivery_status || 'Delivered',
        statusCategory,
        createdAt: bs.created_at,
      });
    }

    // Dealer Bookings (Pending & Cancelled only; Converted are already in dealer_sales)
    for (const dbk of sqlite.prepare("SELECT * FROM dealer_bookings WHERE booking_status != 'Converted to Sale' ORDER BY created_at DESC").all() as any[]) {
      const cc = normalizeCountryCode(dbk.country_id, companiesMap, dbk.company_id);
      if (!inDateRange(dbk.created_at, bounds.fromIso, bounds.toIso)) continue;
      if (countryFilter !== 'ALL' && cc !== countryFilter) continue;
      const isCancelled = ['Cancelled', 'Rejected'].includes(String(dbk.booking_status || ''));
      const cust = customersMap.get(dbk.customer_id);
      const dlr = dealersMap.get(dbk.dealer_id);
      records.push({
        id: dbk.id,
        source: 'dealer_bookings',
        orderRef: dbk.booking_ref || dbk.id,
        vehicleModel: dbk.vehicle_model,
        vin: 'Pending Allocation',
        countryCode: cc,
        companyName: companiesMap.get(dbk.company_id)?.name || dbk.company_id,
        branchName: branchesMap.get(dbk.branch_id)?.name || dbk.branch_id || 'Unassigned',
        dealershipName: dlr?.business_name || dbk.dealer_id,
        customerName: cust?.full_name || dbk.customer_id,
        saleAmount: Number(dbk.agreed_price_pkr || 0),
        paidAmount: dbk.payment_status === 'Fully Paid' ? Number(dbk.agreed_price_pkr || 0) : 0,
        paymentStatus: dbk.payment_status,
        orderStatus: dbk.booking_status,
        statusCategory: isCancelled ? 'cancelled' : 'pending',
        createdAt: dbk.created_at,
      });
    }

    // Customer Bookings (unconverted / active pipeline or cancelled)
    for (const cbk of sqlite.prepare("SELECT * FROM customer_bookings WHERE booking_status != 'Completed' ORDER BY created_at DESC").all() as any[]) {
      const cc = normalizeCountryCode(cbk.country_id, companiesMap, cbk.company_id);
      if (!inDateRange(cbk.created_at, bounds.fromIso, bounds.toIso)) continue;
      if (countryFilter !== 'ALL' && cc !== countryFilter) continue;
      const isCancelled = ['Cancelled', 'Rejected'].includes(String(cbk.booking_status || ''));
      const cust = customersMap.get(cbk.customer_id);
      records.push({
        id: cbk.id,
        source: 'customer_bookings',
        orderRef: cbk.booking_ref || cbk.id,
        vehicleModel: cbk.vehicle_model,
        vin: 'Customer Portal Order',
        countryCode: cc,
        companyName: companiesMap.get(cbk.company_id)?.name || cbk.company_id,
        branchName: branchesMap.get(cbk.branch_id)?.name || cbk.branch_id || 'Unassigned',
        dealershipName: cbk.dealership_name || 'Customer Direct',
        customerName: cust?.full_name || cbk.customer_id,
        saleAmount: Number(cbk.quoted_price_pkr || 0),
        paidAmount: cbk.payment_status === 'Fully Paid' ? Number(cbk.booking_deposit_pkr || 0) : 0,
        paymentStatus: cbk.payment_status,
        orderStatus: cbk.booking_status,
        statusCategory: isCancelled ? 'cancelled' : 'pending',
        createdAt: cbk.created_at,
      });
    }

    const filtered = records.filter((r) => {
      if (statusFilter !== 'all' && r.statusCategory !== statusFilter) return false;
      if (search) {
        const hay = `${r.orderRef} ${r.vehicleModel} ${r.vin} ${r.customerName} ${r.dealershipName} ${r.countryCode}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    const completedSales = filtered.filter((r) => r.statusCategory === 'completed');
    const pendingOrders = filtered.filter((r) => r.statusCategory === 'pending');
    const cancelledOrders = filtered.filter((r) => r.statusCategory === 'cancelled');

    const byCountryMap = new Map<string, { countryCode: string; completed: number; pending: number; cancelled: number; revenue: number; value: number }>();
    const byModelMap = new Map<string, { model: string; totalUnits: number; completedUnits: number; pendingUnits: number; revenue: number }>();
    const monthlyMap = new Map<string, { month: string; units: number; revenue: number }>();
    const yearlyMap = new Map<string, { year: string; units: number; revenue: number }>();

    for (const r of filtered) {
      if (!byCountryMap.has(r.countryCode)) {
        byCountryMap.set(r.countryCode, { countryCode: r.countryCode, completed: 0, pending: 0, cancelled: 0, revenue: 0, value: 0 });
      }
      const cm = byCountryMap.get(r.countryCode)!;
      if (r.statusCategory === 'completed') cm.completed += 1;
      else if (r.statusCategory === 'pending') cm.pending += 1;
      else cm.cancelled += 1;
      cm.revenue += r.paidAmount;
      cm.value += r.saleAmount;

      const modelKey = String(r.vehicleModel || 'Other BYD Model').trim();
      if (!byModelMap.has(modelKey)) {
        byModelMap.set(modelKey, { model: modelKey, totalUnits: 0, completedUnits: 0, pendingUnits: 0, revenue: 0 });
      }
      const mm = byModelMap.get(modelKey)!;
      mm.totalUnits += 1;
      if (r.statusCategory === 'completed') mm.completedUnits += 1;
      if (r.statusCategory === 'pending') mm.pendingUnits += 1;
      mm.revenue += r.paidAmount;

      const mo = String(r.createdAt || nowIso()).slice(0, 7);
      if (!monthlyMap.has(mo)) monthlyMap.set(mo, { month: mo, units: 0, revenue: 0 });
      monthlyMap.get(mo)!.units += 1;
      monthlyMap.get(mo)!.revenue += r.paidAmount;

      const yr = String(r.createdAt || nowIso()).slice(0, 4);
      if (!yearlyMap.has(yr)) yearlyMap.set(yr, { year: yr, units: 0, revenue: 0 });
      yearlyMap.get(yr)!.units += 1;
      yearlyMap.get(yr)!.revenue += r.paidAmount;
    }

    res.json({
      summary: {
        totalRecords: filtered.length,
        completedCount: completedSales.length,
        pendingCount: pendingOrders.length,
        cancelledCount: cancelledOrders.length,
        totalSalesValue: completedSales.reduce((s, r) => s + r.saleAmount, 0),
        totalPaidRevenue: completedSales.reduce((s, r) => s + r.paidAmount, 0),
        pendingPipelineValue: pendingOrders.reduce((s, r) => s + r.saleAmount, 0),
      },
      byCountry: Array.from(byCountryMap.values()).sort((a, b) => b.revenue - a.revenue),
      byModel: Array.from(byModelMap.values()).sort((a, b) => b.totalUnits - a.totalUnits),
      monthlyTrend: Array.from(monthlyMap.values()).sort((a, b) => a.month.localeCompare(b.month)),
      yearlyTrend: Array.from(yearlyMap.values()).sort((a, b) => a.year.localeCompare(b.year)),
      records: filtered.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))),
    });
  });

  router.get('/sales/:recordId', requireFounder, (req: Request, res: Response) => {
    const { recordId } = req.params;
    const ds = sqlite.prepare('SELECT * FROM dealer_sales WHERE id = ?').get(recordId) as any;
    const bs = !ds ? (sqlite.prepare('SELECT * FROM branch_sales WHERE id = ?').get(recordId) as any) : null;
    const dbk = !ds && !bs ? (sqlite.prepare('SELECT * FROM dealer_bookings WHERE id = ?').get(recordId) as any) : null;
    const cbk = !ds && !bs && !dbk ? (sqlite.prepare('SELECT * FROM customer_bookings WHERE id = ?').get(recordId) as any) : null;

    const record = ds || bs || dbk || cbk;
    if (!record) {
      res.status(404).json({ error: 'Sales/order record not found.' });
      return;
    }

    const commission = ds ? sqlite.prepare('SELECT * FROM dealer_commissions WHERE sale_id = ?').get(ds.id) : null;
    const customer = record.customer_id
      ? sqlite.prepare('SELECT id, customer_code, full_name, email, mobile, city, country FROM customer_accounts WHERE id = ?').get(record.customer_id)
      : null;

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'OWNER_SALES_RECORD_VIEWED',
      module: 'Founder Sales Intelligence',
      targetId: recordId,
      ipAddress: getClientIp(req),
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    res.json({
      source: ds ? 'dealer_sales' : bs ? 'branch_sales' : dbk ? 'dealer_bookings' : 'customer_bookings',
      record,
      commission,
      customer,
    });
  });

  // =========================================================================
  // 5 & 6. EMPLOYEE & DEALERSHIP MANAGEMENT OVERVIEW + DETAIL DRILL-DOWN
  // =========================================================================
  router.get('/workforce', requireFounder, (_req: Request, res: Response) => {
    const companies = sqlite.prepare('SELECT id, name, country FROM companies').all() as any[];
    const companiesMap = new Map(companies.map((c) => [c.id, c]));
    const branches = sqlite.prepare('SELECT id, name, city, country_id FROM branches').all() as any[];
    const branchesMap = new Map(branches.map((b) => [b.id, b]));

    // Employees
    const employeesRaw = sqlite.prepare('SELECT * FROM employee_accounts ORDER BY created_at DESC').all() as any[];
    const salaryRecords = sqlite.prepare('SELECT * FROM employee_salary_records ORDER BY pay_period DESC').all() as any[];
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

    const empByCountry = new Map<string, { countryCode: string; total: number; active: number; avgScore: number; scoresSum: number }>();
    const empByDept = new Map<string, { department: string; total: number; active: number; avgScore: number; scoresSum: number }>();

    const employees = employeesRaw.map((e) => {
      const cc = normalizeCountryCode(e.country_id, companiesMap, e.company_id);
      const dept = e.department || 'General Operations';
      const score = Number(e.performance_score || 0);
      const latestSal = salaryRecords.find((s) => s.employee_id === e.id);

      if (!empByCountry.has(cc)) empByCountry.set(cc, { countryCode: cc, total: 0, active: 0, avgScore: 0, scoresSum: 0 });
      const ce = empByCountry.get(cc)!;
      ce.total += 1;
      if (e.status === 'Active') ce.active += 1;
      ce.scoresSum += score;

      if (!empByDept.has(dept)) empByDept.set(dept, { department: dept, total: 0, active: 0, avgScore: 0, scoresSum: 0 });
      const de = empByDept.get(dept)!;
      de.total += 1;
      if (e.status === 'Active') de.active += 1;
      de.scoresSum += score;

      return {
        id: e.id,
        employeeCode: e.employee_code,
        fullName: e.full_name,
        email: e.email,
        mobile: e.mobile,
        department: dept,
        jobPosition: e.job_position,
        countryCode: cc,
        companyName: companiesMap.get(e.company_id)?.name || e.company_id,
        branchName: branchesMap.get(e.branch_id)?.name || e.branch_id || 'Unassigned',
        reportingManagerName: e.reporting_manager_name || 'N/A',
        status: e.status,
        emailVerified: Boolean(e.email_verified),
        twoFactorEnabled: Boolean(e.two_factor_enabled),
        performanceScore: score,
        joinedAt: e.joined_at || e.created_at,
        lastLoginAt: e.last_login_at,
        latestSalary: latestSal
          ? { netSalary: latestSal.net_salary, currency: latestSal.currency, payPeriod: latestSal.pay_period, status: latestSal.payment_status }
          : null,
      };
    });

    for (const ce of empByCountry.values()) ce.avgScore = ce.total > 0 ? Number((ce.scoresSum / ce.total).toFixed(1)) : 0;
    for (const de of empByDept.values()) de.avgScore = de.total > 0 ? Number((de.scoresSum / de.total).toFixed(1)) : 0;

    // Dealerships
    const dealershipsRaw = sqlite.prepare('SELECT * FROM dealerships ORDER BY created_at DESC').all() as any[];
    const dealerAccs = sqlite.prepare('SELECT * FROM dealer_accounts').all() as any[];
    const dealerSales = sqlite.prepare('SELECT * FROM dealer_sales').all() as any[];
    const dealerComms = sqlite.prepare('SELECT * FROM dealer_commissions').all() as any[];

    const dlrByCountry = new Map<string, { countryCode: string; total: number; active: number; revenue: number; targetUnits: number; achievedUnits: number }>();

    const dealerships = dealershipsRaw.map((d) => {
      const acc = dealerAccs.find((a) => a.dealership_id === d.id);
      const sales = acc ? dealerSales.filter((s) => s.dealer_id === acc.id) : [];
      const comms = acc ? dealerComms.filter((c) => c.dealer_id === acc.id) : [];
      const realizedRevenue = sales.reduce((sum, s) => sum + Number(s.paid_amount_pkr || 0), 0);
      const cc = normalizeCountryCode(d.country, companiesMap, d.company_id);
      const isActive = d.status === 'Approved' || acc?.status === 'Active';

      if (!dlrByCountry.has(cc)) {
        dlrByCountry.set(cc, { countryCode: cc, total: 0, active: 0, revenue: 0, targetUnits: 0, achievedUnits: 0 });
      }
      const dc = dlrByCountry.get(cc)!;
      dc.total += 1;
      if (isActive) dc.active += 1;
      dc.revenue += Number(d.monthly_revenue_pkr || 0);
      dc.targetUnits += Number(d.monthly_target_units || 0);
      dc.achievedUnits += Number(d.achieved_units || 0);

      const targetUnits = Number(d.monthly_target_units || 0);
      const achievedUnits = Number(d.achieved_units || 0);
      const targetAttainmentPct = targetUnits > 0 ? Number(((achievedUnits / targetUnits) * 100).toFixed(1)) : 0;

      return {
        id: d.id,
        dealerAccountId: acc?.id || null,
        dealerCode: acc?.dealer_code || d.code,
        name: d.name,
        companyName: companiesMap.get(d.company_id)?.name || d.company_id,
        countryCode: cc,
        city: d.city,
        branchName: branchesMap.get(d.branch_id)?.name || 'Independent Hub',
        managerName: d.manager_name || acc?.owner_contact_name || 'Unassigned',
        email: d.email || acc?.email || null,
        facilityType: d.facility_type,
        status: d.status,
        accountStatus: acc?.status || 'Not Linked',
        verificationStatus: acc?.verification_status || d.status,
        monthlyTargetUnits: targetUnits,
        achievedUnits,
        targetAttainmentPct,
        monthlyReportedRevenue: Number(d.monthly_revenue_pkr || 0),
        verifiedSalesCount: sales.length,
        verifiedSalesRevenue: realizedRevenue,
        commissionRatePct: acc?.commission_rate_pct ?? null,
        totalCommissionsPkr: comms.reduce((s, c) => s + Number(c.commission_amount_pkr || 0), 0),
        rating: Number(d.rating || 0),
      };
    });

    res.json({
      employeesOverview: {
        summary: {
          total: employees.length,
          active: employees.filter((e) => e.status === 'Active').length,
          inactive: employees.filter((e) => e.status !== 'Active').length,
          newRegistrations30d: employeesRaw.filter((e) => String(e.created_at || '') >= thirtyDaysAgo).length,
          avgPerformanceScore:
            employees.length > 0
              ? Number((employees.reduce((s, e) => s + e.performanceScore, 0) / employees.length).toFixed(1))
              : 0,
        },
        byCountry: Array.from(empByCountry.values()),
        byDepartment: Array.from(empByDept.values()),
        employees,
      },
      dealershipsOverview: {
        summary: {
          total: dealerships.length,
          active: dealerships.filter((d) => d.status === 'Approved').length,
          inactive: dealerships.filter((d) => d.status !== 'Approved' && d.status !== 'Pending Approval').length,
          pendingApproval: dealerships.filter((d) => d.status === 'Pending Approval').length,
          totalTargetUnits: dealerships.reduce((s, d) => s + d.monthlyTargetUnits, 0),
          totalAchievedUnits: dealerships.reduce((s, d) => s + d.achievedUnits, 0),
          totalMonthlyReportedRevenue: dealerships.reduce((s, d) => s + d.monthlyReportedRevenue, 0),
          totalVerifiedSalesRevenue: dealerships.reduce((s, d) => s + d.verifiedSalesRevenue, 0),
        },
        byCountry: Array.from(dlrByCountry.values()),
        dealerships: dealerships.sort((a, b) => b.achievedUnits - a.achievedUnits),
      },
    });
  });

  router.get('/workforce/employees/:id', requireFounder, (req: Request, res: Response) => {
    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(req.params.id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee account not found.' });
      return;
    }
    const { password_hash: _ph, two_factor_secret: _tf, recovery_codes_json: _rc, ...safeEmp } = emp;
    const salaryHistory = sqlite
      .prepare('SELECT * FROM employee_salary_records WHERE employee_id = ? ORDER BY pay_period DESC')
      .all(emp.id);
    const loginLogs = sqlite
      .prepare('SELECT id, identifier, ip_address, device_name, browser_name, success, failure_reason, created_at FROM login_activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 15')
      .all(emp.id);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'OWNER_EMPLOYEE_DETAIL_VIEWED',
      module: 'Founder Workforce Oversight',
      targetId: `${emp.employee_code} (${emp.full_name})`,
      companyId: emp.company_id,
      ipAddress: getClientIp(req),
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    res.json({
      employee: {
        ...safeEmp,
        attendance: emp.attendance_json ? JSON.parse(emp.attendance_json) : [],
        leaveBalance: emp.leave_balance_json ? JSON.parse(emp.leave_balance_json) : null,
        permissions: emp.permissions_json ? JSON.parse(emp.permissions_json) : [],
      },
      salaryHistory,
      loginLogs,
    });
  });

  router.get('/workforce/dealerships/:id', requireFounder, (req: Request, res: Response) => {
    const dealership = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(req.params.id) as any;
    if (!dealership) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    const dealerAccount = sqlite
      .prepare('SELECT id, dealer_code, business_name, owner_contact_name, email, mobile, category, verification_status, status, commission_rate_pct, last_login_at, created_at FROM dealer_accounts WHERE dealership_id = ?')
      .get(dealership.id) as any;
    const sales = dealerAccount
      ? sqlite.prepare('SELECT * FROM dealer_sales WHERE dealer_id = ? ORDER BY created_at DESC').all(dealerAccount.id)
      : [];
    const bookings = dealerAccount
      ? sqlite.prepare('SELECT * FROM dealer_bookings WHERE dealer_id = ? ORDER BY created_at DESC').all(dealerAccount.id)
      : [];
    const commissions = dealerAccount
      ? sqlite.prepare('SELECT * FROM dealer_commissions WHERE dealer_id = ? ORDER BY created_at DESC').all(dealerAccount.id)
      : [];
    const vehicles = sqlite.prepare('SELECT id, model, variant, vin, status, sale_price_pkr, sold_at FROM vehicles WHERE dealership_id = ?').all(dealership.id);

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'OWNER_DEALERSHIP_DETAIL_VIEWED',
      module: 'Founder Dealership Oversight',
      targetId: `${dealership.code} (${dealership.name})`,
      companyId: dealership.company_id,
      ipAddress: getClientIp(req),
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    res.json({ dealership, dealerAccount, sales, bookings, commissions, vehicles });
  });

  // =========================================================================
  // 8. SUPER ADMIN ACTIVITY MONITOR & ACCESS REVOCATION
  // =========================================================================
  router.get('/super-admins/activity', requireFounder, (_req: Request, res: Response) => {
    const superAdmins = sqlite
      .prepare(`
        SELECT sa.id, sa.full_name, sa.email, sa.mobile, sa.country, sa.city, sa.status,
               sa.email_verified, sa.two_factor_enabled, sa.last_login_at, sa.created_at,
               up.permissions_json
        FROM super_admin_accounts sa
        LEFT JOIN user_permissions up ON up.user_id = sa.id
        ORDER BY sa.created_at DESC
      `)
      .all()
      .map((sa: any) => ({
        ...sa,
        permissions: sa.permissions_json ? JSON.parse(sa.permissions_json) : [],
      }));

    const saIds = new Set(superAdmins.map((s: any) => s.id));

    const adminLogs = sqlite.prepare('SELECT * FROM admin_activity_logs ORDER BY created_at DESC LIMIT 100').all() as any[];
    const securityLogs = sqlite
      .prepare("SELECT * FROM security_audit_logs WHERE actor_role = 'Super Admin' OR actor_id IN (SELECT id FROM super_admin_accounts) ORDER BY created_at DESC LIMIT 100")
      .all() as any[];
    const ownerAuditSaLogs = sqlite
      .prepare("SELECT * FROM owner_audit_logs WHERE actor_role = 'Super Admin' OR actor_id IN (SELECT id FROM super_admin_accounts) ORDER BY created_at DESC LIMIT 100")
      .all() as any[];
    const loginLogs = sqlite
      .prepare("SELECT * FROM login_activity_logs WHERE subject_type = 'super_admin' ORDER BY created_at DESC LIMIT 60")
      .all() as any[];

    const activeSessions = sqlite
      .prepare("SELECT id, user_id, ip_address, user_agent, device_label, expires_at, last_activity_at, created_at FROM authentication_sessions WHERE subject_type = 'super_admin' AND revoked = 0 AND expires_at > ? ORDER BY last_activity_at DESC")
      .all(nowIso())
      .map((s: any) => {
        const ua = parseUserAgentInfo(s.user_agent);
        return { ...s, deviceName: ua.deviceName, browserName: ua.browserName };
      });

    const combinedActivities = [
      ...adminLogs.map((l) => ({
        id: l.id,
        actorId: l.admin_id,
        actorName: l.admin_name,
        actorRole: l.admin_role,
        action: l.action,
        module: l.module,
        targetId: l.target_id,
        details: l.details,
        ipAddress: l.ip_address,
        status: l.status,
        createdAt: l.created_at,
      })),
      ...securityLogs.map((l) => ({
        id: l.id,
        actorId: l.actor_id,
        actorName: l.actor_name,
        actorRole: l.actor_role,
        action: l.action,
        module: l.category,
        targetId: l.target_user_id,
        details: l.details,
        ipAddress: l.ip_address,
        status: l.severity,
        createdAt: l.created_at,
      })),
      ...ownerAuditSaLogs
        .filter((l) => saIds.has(l.actor_id) || l.actor_role === 'Super Admin')
        .map((l) => ({
          id: l.id,
          actorId: l.actor_id,
          actorName: l.actor_name,
          actorRole: l.actor_role,
          action: l.action,
          module: l.module,
          targetId: l.target_id,
          details: l.details,
          ipAddress: l.ip_address,
          status: l.status,
          createdAt: l.created_at,
        })),
    ].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));

    res.json({
      superAdmins,
      activeSessions,
      loginLogs,
      activities: combinedActivities.slice(0, 100),
    });
  });

  router.post('/super-admins/:id/revoke-access', requireFounder, (req: Request, res: Response) => {
    const { id } = req.params;
    const reason = String(req.body?.reason || 'Access explicitly revoked by Founder / CEO').trim();
    const sa = sqlite.prepare('SELECT * FROM super_admin_accounts WHERE id = ?').get(id) as any;
    if (!sa) {
      res.status(404).json({ error: 'Super Admin account not found.' });
      return;
    }

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite.prepare("UPDATE super_admin_accounts SET status = 'Suspended', updated_at = ? WHERE id = ?").run(now, id);
      sqlite
        .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_at = ?, revoked_reason = ? WHERE user_id = ? AND revoked = 0")
        .run(now, reason, id);
    })();

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SUPER_ADMIN_ACCESS_REVOKED',
      module: 'Owner Governance',
      targetId: `${sa.full_name} (${sa.email})`,
      details: reason,
      ipAddress: getClientIp(req),
      status: 'WARNING',
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: sa.id,
      action: 'SUPER_ADMIN_ACCESS_REVOKED',
      category: 'Access Revocation',
      severity: 'WARNING',
      details: `${sa.email} suspended and all active sessions revoked: ${reason}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, message: `All access and active sessions revoked for ${sa.full_name}.` });
  });

  // =========================================================================
  // 9. SYSTEM-WIDE PERMISSIONS (ALL 6 ROLES — FOUNDER VERIFIED CONTROL)
  // =========================================================================
  router.get('/rbac-overview', requireFounder, (_req: Request, res: Response) => {
    const matrix = sqlite
      .prepare('SELECT role_key, module_key, can_view, can_create, can_edit, can_delete, can_approve, is_locked, updated_by, updated_at FROM rbac_role_action_permissions')
      .all() as any[];

    const roleSummaries = [...RBAC_ROLES].map((roleKey) => {
      const entries = matrix.filter((m) => m.role_key === roleKey);
      const financeRow = entries.find((m) => m.module_key === 'Finance & Invoices');
      const sysRow = entries.find((m) => m.module_key === 'System & Backup');
      const rbacRow = entries.find((m) => m.module_key === 'RBAC & Roles');
      return {
        roleKey,
        immutable: roleKey === 'Founder / CEO',
        moduleAccessCount: entries.filter((e) => e.can_view === 1).length,
        totalModules: RBAC_MODULES.length,
        financialAccess: Boolean(financeRow && (financeRow.can_view || financeRow.can_edit || financeRow.can_approve)),
        reportsAccess: Boolean(entries.some((e) => e.can_view === 1)),
        administrativeAccess: Boolean((sysRow && (sysRow.can_view || sysRow.can_edit)) || (rbacRow && rbacRow.can_edit)),
      };
    });

    res.json({
      roles: [...RBAC_ROLES],
      modules: [...RBAC_MODULES],
      matrix,
      roleSummaries,
    });
  });

  router.put('/rbac-overview', requireFounder, (req: Request, res: Response) => {
    const updates = Array.isArray(req.body?.updates) ? req.body.updates : [];
    if (updates.length === 0) {
      res.status(400).json({ error: 'At least one permission update is required.' });
      return;
    }

    const validRoles = new Set<string>(RBAC_ROLES as unknown as string[]);
    const validModules = new Set<string>(RBAC_MODULES as unknown as string[]);

    for (const u of updates) {
      if (!validRoles.has(String(u.roleKey)) || !validModules.has(String(u.moduleKey))) {
        res.status(400).json({ error: `Invalid role (${u.roleKey}) or module (${u.moduleKey}).` });
        return;
      }
      if (u.roleKey === 'Founder / CEO') {
        res.status(403).json({
          error: 'Founder / CEO root permissions are immutable and protected against modification or lock-out.',
        });
        return;
      }
    }

    const now = nowIso();
    const stmt = sqlite.prepare(`
      UPDATE rbac_role_action_permissions
      SET can_view = ?, can_create = ?, can_edit = ?, can_delete = ?, can_approve = ?, updated_by = ?, updated_at = ?
      WHERE role_key = ? AND module_key = ? AND is_locked = 0
    `);

    sqlite.transaction(() => {
      for (const u of updates) {
        stmt.run(
          u.canView ? 1 : 0,
          u.canCreate ? 1 : 0,
          u.canEdit ? 1 : 0,
          u.canDelete ? 1 : 0,
          u.canApprove ? 1 : 0,
          req.auth!.fullName,
          now,
          u.roleKey,
          u.moduleKey
        );
      }
    })();

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SYSTEM_PERMISSIONS_UPDATED',
      module: 'System-Wide RBAC',
      targetId: `${updates.length} role-module cells`,
      details: updates.map((u: any) => `${u.roleKey}:${u.moduleKey}`).slice(0, 10).join(', '),
      ipAddress: getClientIp(req),
      status: 'WARNING',
      userAgent: req.headers['user-agent'] || null,
      sessionId: req.auth!.sessionId || null,
    });

    res.json({ success: true, updatedCount: updates.length });
  });

  // =========================================================================
  // 10. IMMUTABLE OWNER ACTIVITY LOGS
  // =========================================================================
  router.get('/activity-logs', requireFounder, (req: Request, res: Response) => {
    const category = String(req.query.category || 'all').toLowerCase();
    const search = String(req.query.search || '').trim().toLowerCase();
    const fromDate = req.query.fromDate ? `${String(req.query.fromDate).slice(0, 10)}T00:00:00.000Z` : null;
    const toDate = req.query.toDate ? `${String(req.query.toDate).slice(0, 10)}T23:59:59.999Z` : null;
    const limit = Math.min(300, Math.max(20, Number(req.query.limit || 150)));

    const auditRows = sqlite
      .prepare('SELECT * FROM owner_audit_logs ORDER BY created_at DESC LIMIT 500')
      .all() as any[];

    const founderLoginRows = sqlite
      .prepare("SELECT * FROM login_activity_logs WHERE subject_type = 'founder' ORDER BY created_at DESC LIMIT 100")
      .all() as any[];

    const adminRows = sqlite
      .prepare('SELECT * FROM admin_activity_logs ORDER BY created_at DESC LIMIT 100')
      .all() as any[];

    const unified = [
      ...auditRows.map((a) => {
        const ua = a.user_agent ? parseUserAgentInfo(a.user_agent) : null;
        return {
          id: a.id,
          source: 'owner_audit_logs',
          actorId: a.actor_id,
          actorName: a.actor_name,
          actorRole: a.actor_role,
          action: a.action,
          module: a.module,
          targetId: a.target_id,
          details: a.details,
          ipAddress: a.ip_address || 'server',
          deviceName: a.device_name || ua?.deviceName || 'Web Client',
          browserName: a.browser_name || ua?.browserName || 'Authenticated Session',
          sessionId: a.session_id || null,
          status: a.status || 'SUCCESS',
          createdAt: a.created_at,
        };
      }),
      ...founderLoginRows.map((l) => {
        const ua = parseUserAgentInfo(l.user_agent);
        return {
          id: l.id,
          source: 'founder_login_activity',
          actorId: l.user_id || 'founder',
          actorName: l.account_name || l.identifier,
          actorRole: l.role || 'Founder & CEO',
          action: l.success ? 'FOUNDER_SESSION_AUTHENTICATED' : 'FOUNDER_LOGIN_BLOCKED',
          module: 'Founder Authentication & 2FA',
          targetId: l.identifier,
          details: l.success ? `MFA: ${l.mfa_method || '2FA'}${l.suspicious ? ' (New IP Alert)' : ''}` : `Reason: ${l.failure_reason || 'Denied'}`,
          ipAddress: l.ip_address || 'unknown',
          deviceName: l.device_name || ua.deviceName,
          browserName: l.browser_name || ua.browserName,
          sessionId: l.session_id || null,
          status: l.success ? (l.suspicious ? 'WARNING' : 'SUCCESS') : 'ALERT',
          createdAt: l.created_at,
        };
      }),
      ...adminRows.map((ad) => ({
        id: ad.id,
        source: 'admin_activity_logs',
        actorId: ad.admin_id,
        actorName: ad.admin_name,
        actorRole: ad.admin_role,
        action: ad.action,
        module: ad.module,
        targetId: ad.target_id,
        details: ad.details,
        ipAddress: ad.ip_address || 'server',
        deviceName: 'Admin Console',
        browserName: 'Verified Session',
        sessionId: null,
        status: ad.status || 'SUCCESS',
        createdAt: ad.created_at,
      })),
    ];

    const filtered = unified.filter((item) => {
      if (!inDateRange(item.createdAt, fromDate, toDate)) return false;

      if (category === 'founder') {
        if (!String(item.actorRole || '').toLowerCase().includes('founder')) return false;
      } else if (category === 'super_admin') {
        if (
          !String(item.actorRole || '').toLowerCase().includes('super admin') &&
          !String(item.action || '').includes('SUPER_ADMIN')
        ) {
          return false;
        }
      } else if (category === 'finance') {
        if (!String(item.action || '').includes('FINANCIAL') && !String(item.module || '').toLowerCase().includes('financ')) return false;
      } else if (category === 'permissions') {
        if (!String(item.action || '').includes('PERMISSION') && !String(item.action || '').includes('RBAC')) return false;
      } else if (category === 'employees') {
        if (!String(item.action || '').includes('EMPLOYEE') && !String(item.module || '').toLowerCase().includes('workforce')) return false;
      } else if (category === 'dealerships') {
        if (!String(item.action || '').includes('DEALER') && !String(item.module || '').toLowerCase().includes('dealer')) return false;
      } else if (category === 'logins') {
        if (!String(item.action || '').includes('LOGIN') && !String(item.action || '').includes('SESSION') && !String(item.source || '').includes('login')) return false;
      }

      if (search) {
        const hay = `${item.actorName} ${item.actorRole} ${item.action} ${item.module} ${item.targetId || ''} ${item.details || ''} ${item.ipAddress} ${item.deviceName} ${item.browserName}`.toLowerCase();
        if (!hay.includes(search)) return false;
      }
      return true;
    });

    filtered.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));

    res.json({
      immutable: true,
      totalMatched: filtered.length,
      logs: filtered.slice(0, limit),
    });
  });

  return router;
}
