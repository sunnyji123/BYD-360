import React, { useState, useEffect, useCallback } from 'react';
import { UserPlus, Copy, Check, Shield, RefreshCw, AlertCircle, Lock } from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';

const INVITABLE_ROLES = [
  'Company Admin',
  'Head Office Staff',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Finance Manager',
  'Service Manager',
  'Technical Support',
];

export const TeamInvitePanel: React.FC = () => {
  const { isAuthenticated, currentUser, openAuthModal } = useApp();
  const [employees, setEmployees] = useState<any[]>([]);
  const [invitations, setInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Invite Form
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('+92 300 ');
  const [role, setRole] = useState('Sales Executive');
  const [city, setCity] = useState('Karachi');
  const [generatedInvite, setGeneratedInvite] = useState<{ token: string; url: string; email: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const canManageTeam =
    isAuthenticated &&
    ['Founder / Owner', 'Super Admin', 'Global Super Admin', 'Company Admin', 'Dealership Manager', 'Head Office Staff'].includes(
      currentUser.role
    );

  const loadEmployees = useCallback(async () => {
    if (!canManageTeam) return;
    setLoading(true);
    setError('');
    try {
      const res = await api.getEmployees();
      setEmployees(res.employees || []);
      setInvitations(res.invitations || []);
    } catch (err: any) {
      setError(err.message || 'Unable to load company staff.');
    } finally {
      setLoading(false);
    }
  }, [canManageTeam]);

  useEffect(() => {
    loadEmployees();
  }, [loadEmployees]);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setGeneratedInvite(null);
    try {
      const res = await api.inviteEmployee({ fullName, email, mobile, role, city });
      setGeneratedInvite({ token: res.inviteToken, url: res.inviteUrl, email });
      setFullName('');
      setEmail('');
      await loadEmployees();
    } catch (err: any) {
      setError(err.message || 'Failed to generate employee invitation.');
    }
  };

  if (!canManageTeam) {
    return (
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Lock className="w-5 h-5 text-amber-400" />
          <div className="text-xs">
            <div className="font-bold text-white">Company-Isolated Staff &amp; Invitation Desk</div>
            <div className="text-slate-400">
              Sign in as a Company Admin, Dealership Manager, Super Admin, or Primary Owner to invite and manage company employees.
            </div>
          </div>
        </div>
        <button
          onClick={() => openAuthModal('login')}
          className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs shrink-0"
        >
          Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h4 className="text-base font-bold text-white flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-cyan-400" />
            <span>Company-Isolated Staff Directory &amp; Secure Invitations</span>
          </h4>
          <p className="text-xs text-slate-400">
            Invite employees with single-use cryptographic tokens — every employee sets their own private password upon activation.
          </p>
        </div>
        <button
          onClick={loadEmployees}
          className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:text-white flex items-center gap-1"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-xs text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {generatedInvite && (
        <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs space-y-2">
          <div className="font-bold text-emerald-300">
            Single-Use Invitation Link Generated for {generatedInvite.email}
          </div>
          <div className="flex items-center justify-between gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <code className="text-cyan-300 font-mono break-all">
              {window.location.origin}{generatedInvite.url}
            </code>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard?.writeText(`${window.location.origin}${generatedInvite.url}`);
                setCopied(true);
                setTimeout(() => setCopied(false), 1800);
              }}
              className="px-2.5 py-1 rounded bg-slate-800 text-white font-semibold shrink-0 flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Link'}</span>
            </button>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">Token: {generatedInvite.token}</div>
        </div>
      )}

      <form onSubmit={handleInvite} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
        <input
          type="text"
          required
          placeholder="Employee Full Name"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
        />
        <input
          type="email"
          required
          placeholder="Work Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
        />
        <input
          type="tel"
          placeholder="Mobile Number"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
        />
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
        >
          {INVITABLE_ROLES.map((r) => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
        <input
          type="text"
          required
          placeholder="City"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
        />
        <button
          type="submit"
          className="rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2"
        >
          Generate Invite
        </button>
      </form>

      {/* Active Staff Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
            <tr>
              <th className="py-2.5 px-3">Name</th>
              <th className="py-2.5 px-3">Email</th>
              <th className="py-2.5 px-3">Role</th>
              <th className="py-2.5 px-3">City</th>
              <th className="py-2.5 px-3">Status</th>
              <th className="py-2.5 px-3">Control</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {employees.map((emp) => (
              <tr key={emp.id} className="hover:bg-slate-900">
                <td className="py-2.5 px-3 font-bold text-white">{emp.full_name}</td>
                <td className="py-2.5 px-3 font-mono text-slate-300">{emp.email}</td>
                <td className="py-2.5 px-3 text-cyan-300 font-semibold">{emp.role}</td>
                <td className="py-2.5 px-3 text-slate-400">{emp.city}</td>
                <td className="py-2.5 px-3">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${emp.status === 'Active' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                    {emp.status}
                  </span>
                </td>
                <td className="py-2.5 px-3">
                  {emp.role !== 'Super Admin' && emp.id !== currentUser.id && (
                    <button
                      onClick={async () => {
                        await api.updateEmployeeStatus(emp.id, emp.status === 'Active' ? 'Suspended' : 'Active');
                        await loadEmployees();
                      }}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px]"
                    >
                      {emp.status === 'Active' ? 'Suspend' : 'Activate'}
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {invitations.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>Recent Invitations ({invitations.length})</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
            {invitations.slice(0, 6).map((inv) => (
              <div key={inv.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{inv.full_name} ({inv.role})</div>
                  <div className="text-slate-400 font-mono text-[11px]">{inv.email}</div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${inv.status === 'Accepted' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'}`}>
                  {inv.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
