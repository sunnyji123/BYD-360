import React, { useState, useEffect, useCallback } from 'react';
import {
  Activity,
  Server,
  Database,
  Cpu,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  LogOut,
  ShieldAlert,
  Lock,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  onNotify: (msg: string) => void;
}

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${h}h ${m}m ${s}s`;
}

export const SuperAdminMonitoringPanel: React.FC<Props> = ({ onNotify }) => {
  const [mon, setMon] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const loadMonitoring = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getSuperAdminMonitoring();
      setMon(res);
    } catch (err: any) {
      setError(err?.message || 'Unable to load real-time system monitoring telemetry.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMonitoring();
  }, [loadMonitoring]);

  const terminateSession = async (sessionId: string) => {
    try {
      const res = await api.terminateAdminVerificationSession(sessionId);
      onNotify(res.message);
      await loadMonitoring();
    } catch (err: any) {
      setError(err?.message || 'Unable to terminate session.');
    }
  };

  const server = mon?.server || {};
  const db = mon?.database || {};
  const apiMetrics = mon?.api || {};
  const security = mon?.security || {};
  const alerts = mon?.alerts || [];

  return (
    <div className="space-y-6 text-xs">
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Live Infrastructure &amp; Security Telemetry
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              Real-Time System Health, SQLite DB Latency, API Errors &amp; Session Monitor
            </h3>
            <p className="text-slate-400 mt-0.5">
              100% live process, SQLite WAL engine, measured HTTP latency, failed login &amp; security telemetry. Zero simulated counters.
            </p>
          </div>
          <div className="flex items-center gap-3">
            {mon?.checkedAt && (
              <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                Sampled: {mon.checkedAt.slice(0, 19).replace('T', ' ')} UTC
              </span>
            )}
            <button
              type="button"
              onClick={loadMonitoring}
              className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Poll Telemetry</span>
            </button>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>
        )}

        {/* System Threshold Alerts */}
        <div className="space-y-2">
          {alerts.map((al: any, idx: number) => (
            <div
              key={idx}
              className={`p-3 rounded-xl border flex items-center gap-2.5 ${
                al.severity === 'CRITICAL'
                  ? 'bg-rose-950/60 border-rose-700 text-rose-200'
                  : al.severity === 'WARNING'
                    ? 'bg-amber-950/50 border-amber-700 text-amber-200'
                    : 'bg-emerald-950/40 border-emerald-800 text-emerald-200'
              }`}
            >
              {al.severity === 'INFO' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              <span className="font-mono font-bold">[{al.code}]</span>
              <span>{al.message}</span>
            </div>
          ))}
        </div>

        {/* Core Health KPI Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center justify-between text-slate-400">
              <span>Backend API Health</span>
              <Server className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-lg font-black text-emerald-400">{server.status || 'Checking...'}</div>
            <div className="font-mono text-[11px] text-slate-400 tabular-nums">
              Uptime: {formatUptime(server.uptimeSeconds || 0)}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center justify-between text-slate-400">
              <span>SQLite DB Connection</span>
              <Database className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-lg font-black text-white font-mono tabular-nums">
              {db.connected ? `${db.pingLatencyMs} ms` : 'Disconnected'}
            </div>
            <div className="font-mono text-[11px] text-slate-400 tabular-nums">
              {String(db.journalMode || 'wal').toUpperCase()} · {db.fileSizeMb ?? 0} MB
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center justify-between text-slate-400">
              <span>API Latency &amp; Throughput</span>
              <Activity className="w-4 h-4 text-cyan-300" />
            </div>
            <div className="text-lg font-black text-white font-mono tabular-nums">
              Avg {apiMetrics.avgLatencyMs ?? 0} ms
            </div>
            <div className="font-mono text-[11px] text-slate-400 tabular-nums">
              P95: {apiMetrics.p95LatencyMs ?? 0} ms · {apiMetrics.totalApiRequests ?? 0} reqs
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center justify-between text-slate-400">
              <span>Node Memory &amp; CPU</span>
              <Cpu className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-lg font-black text-white font-mono tabular-nums">
              {server.processMemoryRssMb ?? 0} MB RSS
            </div>
            <div className="font-mono text-[11px] text-slate-400 tabular-nums">
              Heap {server.heapUsedMb ?? 0} MB · Load {server.loadAvg1m ?? 0} ({server.cpuCores ?? 1}c)
            </div>
          </div>
        </div>

        {/* Row Counts & Background Jobs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-white">Live Database Table Row Telemetry</h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {Object.entries(db.tableCounts || {}).map(([tbl, cnt]) => (
                <div key={tbl} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="text-[10px] text-slate-400 truncate">{tbl}</div>
                  <div className="font-mono font-black text-white text-sm tabular-nums">{String(cnt)}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-white">Background &amp; Persistence Subsystems</h4>
            <div className="space-y-2">
              {(mon?.backgroundJobs || []).map((job: any, i: number) => (
                <div key={i} className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-white">{job.jobName}</div>
                    <div className="text-slate-400 text-[11px]">{job.detail}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono text-[10px] font-bold shrink-0">
                    {job.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Active Sessions & Failed Login Attempts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-cyan-400" />
                <span>Active Scoped Sessions ({security.activeSessionsCount ?? 0})</span>
              </h4>
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(security.activeSessions || []).map((s: any) => (
                <div key={s.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-semibold text-white truncate">
                      {s.full_name || s.user_id} · <span className="text-cyan-300">{s.role}</span>
                    </div>
                    <div className="font-mono text-[10px] text-slate-400 truncate">
                      {s.email || s.user_id} · IP {s.ip_address} · {s.device_label || 'Browser'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => terminateSession(s.id)}
                    className="px-2.5 py-1 rounded bg-rose-950 border border-rose-800 text-rose-200 font-semibold flex items-center gap-1 shrink-0"
                  >
                    <LogOut className="w-3 h-3" />
                    <span>Revoke</span>
                  </button>
                </div>
              ))}
              {(!security.activeSessions || security.activeSessions.length === 0) && (
                <div className="py-4 text-center text-slate-500">No active non-Founder sessions currently open.</div>
              )}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>Failed Login Attempts (24h: {security.failedLogins24h ?? 0})</span>
              </h4>
              <span className="font-mono text-[11px] text-rose-300">
                API 5xx: {apiMetrics.total5xxResponses ?? 0} · 4xx: {apiMetrics.total4xxResponses ?? 0}
              </span>
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {(security.recentFailedLogins || []).map((l: any) => (
                <div key={l.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-rose-300 font-bold">{l.identifier}</span>
                    <span className="text-slate-500">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
                  </div>
                  <div className="text-slate-300 mt-0.5">
                    {l.failure_reason || 'Invalid Credentials'} · IP {l.ip_address} · {l.device_name || 'Client'}
                  </div>
                </div>
              ))}
              {(!security.recentFailedLogins || security.recentFailedLogins.length === 0) && (
                <div className="py-4 text-center text-slate-500">Zero failed login attempts recorded.</div>
              )}
            </div>
          </div>
        </div>

        {/* Recorded HTTP Errors & AI Usage Errors */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <h4 className="font-bold text-white">Recorded Application &amp; HTTP Error Log</h4>
          {(apiMetrics.recentErrors || []).length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] text-slate-400 uppercase">
                    <th className="py-2 px-3">Timestamp</th>
                    <th className="py-2 px-3">Method &amp; Endpoint</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Latency</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {apiMetrics.recentErrors.slice(0, 15).map((err: any, idx: number) => (
                    <tr key={idx} className="font-mono text-[11px]">
                      <td className="py-2 px-3 text-slate-400">{err.timestamp?.slice(0, 19).replace('T', ' ')}</td>
                      <td className="py-2 px-3 text-white">{err.method} {err.path}</td>
                      <td className="py-2 px-3 text-rose-400 font-bold">{err.statusCode}</td>
                      <td className="py-2 px-3 text-slate-300">{err.durationMs} ms</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-4 text-center text-emerald-300/80">
              No HTTP 4xx/5xx application errors observed since server startup.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
