import React, { useState } from 'react';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showDesktopGuide, setShowDesktopGuide] = useState(false);

  // If already running inside standalone PWA, hide install trigger
  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
        <span className="hidden sm:inline">PWA Installed</span>
      </div>
    );
  }

  // Chromium / Android / Desktop install trigger
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className={`flex items-center gap-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold shadow-lg shadow-cyan-500/20 hover:from-cyan-400 hover:to-blue-500 transition active:scale-95 ${
          compact ? 'px-2.5 py-1.5 text-xs' : 'px-3.5 py-1.5 text-xs sm:text-sm'
        }`}
        title="Install BYD Pakistan 360 App on device"
      >
        <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-bounce" />
        <span>Install App</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className={`flex items-center gap-1.5 rounded-lg border border-cyan-500/40 bg-slate-900/80 text-cyan-300 hover:bg-slate-800 transition ${
            compact ? 'px-2 py-1 text-xs' : 'px-3 py-1.5 text-xs'
          }`}
          title="Install on iOS"
        >
          <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
          <span>Install iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl text-slate-100 relative">
              <button
                onClick={() => setShowIOSGuide(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Install on iPhone / iPad</h3>
                  <p className="text-xs text-cyan-400">BYD Pakistan 360 Mobile Web App</p>
                </div>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-300 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold mt-0.5">1</span>
                  <p>In Safari, tap the <strong>Share</strong> icon (square with arrow up) at the bottom.</p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold mt-0.5">2</span>
                  <p>Scroll down and select <strong>Add to Home Screen</strong>.</p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold mt-0.5">3</span>
                  <p>Tap <strong>Add</strong> in the top right to launch standalone.</p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 py-2.5 text-xs font-semibold text-white hover:from-cyan-400 hover:to-blue-500"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Fallback desktop button for browsers that haven't fired beforeinstallprompt yet or offer manual shortcut
  return (
    <>
      <button
        onClick={() => setShowDesktopGuide(true)}
        className={`flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/60 text-slate-300 hover:text-white hover:border-slate-600 transition ${
          compact ? 'px-2 py-1 text-xs' : 'px-2.5 py-1.5 text-xs'
        }`}
      >
        <Download className="w-3.5 h-3.5 text-slate-400" />
        <span className="hidden sm:inline">Install PWA</span>
      </button>

      {showDesktopGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl text-slate-100 relative space-y-3">
            <button
              onClick={() => setShowDesktopGuide(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <Download className="w-4 h-4" />
              <span>Install BYD Pakistan 360 App</span>
            </div>
            <p className="text-xs text-slate-300">
              To install this Progressive Web App:
            </p>
            <div className="space-y-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-300">
              <p>• <strong>Chrome / Edge / Brave:</strong> Click the install icon in the URL address bar or select <em>Install BYD Pakistan 360</em> from the browser menu (⋮).</p>
              <p>• <strong>Mobile / Tablet:</strong> Tap the browser menu and select <em>Add to Home Screen</em>.</p>
            </div>
            <button
              onClick={() => setShowDesktopGuide(false)}
              className="w-full py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 font-bold text-xs text-slate-950"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
