import React, { useState, useEffect, useCallback } from 'react';
import { Car, Search, Eye, X, TrendingUp, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { api } from '../../services/api';

interface OwnerSalesOverviewProps {
  countries: Array<{ code: string; name: string }>;
}

function fmtMoney(val: number): string {
  return `₨ ${Math.round(val || 0).toLocaleString()}`;
}

export const OwnerSalesOverview: React.FC<OwnerSalesOverviewProps> = ({ countries }) => {
  const [countryId, setCountryId] = useState('ALL');
  const [status, setStatus] = useState<'all' | 'completed' | 'pending' | 'cancelled'>('all');
  const [search, setSearch] = useState('');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [selectedDetail, setSelectedDetail] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const loadSales = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.getOwnerSales({ countryId, status, search: search.trim() || undefined });
      setData(res);
    } catch {
      // handled cleanly by empty UI fallback
    } finally {
      setLoading(false);
    }
  }, [countryId, status, search]);

  useEffect(() => {
    loadSales();
  }, [loadSales]);

  const openDetail = async (id: string) => {
    setDetailLoading(true);
    try {
      const res = await api.getOwnerSaleDetail(id);
      setSelectedDetail(res);
    } finally {
      setDetailLoading(false);
    }
  };

  const s = data?.summary || {};
  const records = data?.records || [];

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Total Sales &amp; Orders</div>
          <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{s.totalRecords ?? 0}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">All verified database channels</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Completed Sales
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums mt-1">{s.completedCount ?? 0}</div>
          <div className="text-[10px] text-emerald-500/80 font-mono mt-0.5">{fmtMoney(s.totalPaidRevenue || 0)}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" /> Pending Orders
          </div>
          <div className="text-2xl font-black text-amber-300 font-mono tabular-nums mt-1">{s.pendingCount ?? 0}</div>
          <div className="text-[10px] text-amber-500/80 font-mono mt-0.5">{fmtMoney(s.pendingPipelineValue || 0)} pipeline</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <XCircle className="w-3.5 h-3.5 text-rose-400" /> Cancelled Orders
          </div>
          <div className="text-2xl font-black text-rose-400 font-mono tabular-nums mt-1">{s.cancelledCount ?? 0}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Excluded from revenue</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Contracted Completed Value</div>
          <div className="text-xl font-black text-cyan-300 font-mono tabular-nums mt-1">
            {fmtMoney(s.totalSalesValue || 0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Across {data?.byModel?.length || 0} BYD models</div>
        </div>
      </div>

      {/* Breakdown Grids: Model-Wise & Country-Wise + Monthly/Yearly Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Car className="w-4 h-4 text-amber-400" />
            <span>Model-Wise Vehicle Sales</span>
          </h4>
          {!(data?.byModel?.length) ? (
            <div className="py-6 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-2 text-xs">
              {data.byModel.map((m: any) => (
                <div key={m.model} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white">{m.model}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {m.completedUnits} Sold • {m.pendingUnits} Pending
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums font-bold text-emerald-400">
                    {fmtMoney(m.revenue)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white">Country-Wise Sales Distribution</h4>
          {!(data?.byCountry?.length) ? (
            <div className="py-6 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-2 text-xs">
              {data.byCountry.map((c: any) => (
                <div key={c.countryCode} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-mono font-bold text-white">{c.countryCode}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {c.completed} Completed • {c.pending} Pending • {c.cancelled} Cancelled
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums font-bold text-cyan-300">
                    {fmtMoney(c.revenue)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Monthly &amp; Yearly Sales Velocity</span>
          </h4>
          {!(data?.monthlyTrend?.length) ? (
            <div className="py-6 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="space-y-3 text-xs">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Yearly Summary</div>
                {data.yearlyTrend.map((y: any) => (
                  <div key={y.year} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between mb-1.5">
                    <span className="font-mono font-bold text-amber-300">{y.year}</span>
                    <span className="font-mono text-slate-200 tabular-nums">{y.units} units</span>
                    <span className="font-mono text-emerald-400 font-bold tabular-nums">{fmtMoney(y.revenue)}</span>
                  </div>
                ))}
              </div>
              <div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1.5">Monthly Breakdown</div>
                {data.monthlyTrend.map((m: any) => (
                  <div key={m.month} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between mb-1.5">
                    <span className="font-mono text-white">{m.month}</span>
                    <span className="font-mono text-slate-300 tabular-nums">{m.units} units</span>
                    <span className="font-mono text-cyan-300 tabular-nums">{fmtMoney(m.revenue)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Filter & Detailed Sales Records Table */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <h4 className="text-sm font-bold text-white">Detailed Vehicle Sales &amp; Orders Drill-Down ({records.length})</h4>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search Ref, Model, VIN, Dealer..."
                className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white w-56"
              />
            </div>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as any)}
              className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="all">All Statuses</option>
              <option value="completed">Completed Sales</option>
              <option value="pending">Pending Orders</option>
              <option value="cancelled">Cancelled Orders</option>
            </select>
            <select
              value={countryId}
              onChange={(e) => setCountryId(e.target.value)}
              className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Countries</option>
              {countries.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.name} ({c.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400">Loading verified sales records...</div>
        ) : records.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">No Data Available for the current filters.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Order Ref</th>
                  <th className="py-2.5 px-3">Model / VIN</th>
                  <th className="py-2.5 px-3">Country</th>
                  <th className="py-2.5 px-3">Dealership / Branch</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-right">Order Value</th>
                  <th className="py-2.5 px-3 text-right">Paid Cleared</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {records.map((r: any) => (
                  <tr key={`${r.source}-${r.id}`} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 font-mono text-slate-400 whitespace-nowrap">{String(r.createdAt || '').slice(0, 10)}</td>
                    <td className="py-2 px-3 font-mono font-bold text-cyan-300">{r.orderRef}</td>
                    <td className="py-2 px-3">
                      <div className="font-semibold text-white">{r.vehicleModel}</div>
                      <div className="text-[10px] font-mono text-slate-400">{r.vin}</div>
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-200">{r.countryCode}</td>
                    <td className="py-2 px-3">
                      <div className="text-white">{r.dealershipName}</div>
                      <div className="text-[10px] text-slate-400">{r.branchName}</div>
                    </td>
                    <td className="py-2 px-3 text-slate-200">{r.customerName}</td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-white">{fmtMoney(r.saleAmount)}</td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-emerald-400 font-bold">{fmtMoney(r.paidAmount)}</td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.statusCategory === 'completed'
                            ? 'bg-emerald-950 text-emerald-300'
                            : r.statusCategory === 'pending'
                            ? 'bg-amber-950 text-amber-300'
                            : 'bg-rose-950 text-rose-300'
                        }`}
                      >
                        {r.orderStatus} ({r.paymentStatus})
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right">
                      <button
                        type="button"
                        onClick={() => openDetail(r.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold inline-flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" /> Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Sale Drill-Down Modal */}
      {(selectedDetail || detailLoading) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-sm font-black text-white">Verified Vehicle Sale / Order Inspection</h4>
              <button
                type="button"
                onClick={() => setSelectedDetail(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {detailLoading ? (
              <div className="py-8 text-center text-xs text-slate-400">Loading record telemetry...</div>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-500">Source Table:</span>{' '}
                    <span className="font-mono text-cyan-300">{selectedDetail.source}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Record ID:</span>{' '}
                    <span className="font-mono text-white">{selectedDetail.record?.id}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Model:</span>{' '}
                    <span className="text-white font-bold">{selectedDetail.record?.vehicle_model}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Payment:</span>{' '}
                    <span className="text-emerald-300 font-bold">{selectedDetail.record?.payment_status}</span>
                  </div>
                </div>
                {selectedDetail.customer && (
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <div className="text-[10px] uppercase tracking-wider text-slate-500">Verified Buyer</div>
                    <div className="font-bold text-white">
                      {selectedDetail.customer.full_name} ({selectedDetail.customer.customer_code})
                    </div>
                    <div className="text-slate-400 font-mono">
                      {selectedDetail.customer.email} • {selectedDetail.customer.mobile} • {selectedDetail.customer.city}, {selectedDetail.customer.country}
                    </div>
                  </div>
                )}
                {selectedDetail.commission && (
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <div className="text-[10px] uppercase tracking-wider text-slate-500">Linked Dealer Commission</div>
                    <div className="font-mono text-amber-300 font-bold">
                      {fmtMoney(selectedDetail.commission.commission_amount_pkr)} ({selectedDetail.commission.commission_rate_pct}%) — {selectedDetail.commission.status}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
