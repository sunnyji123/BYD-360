import React from 'react';
import {
  Zap,
  ShieldCheck,
  TrendingUp,
  Cpu,
  Layers,
  Award,
  Globe,
  Smartphone,
  Server,
  Lock,
  ArrowRight,
  CheckCircle2,
  Building2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BusinessPitch: React.FC = () => {
  const { setActiveTab } = useApp();

  return (
    <div className="space-y-12 pb-16 max-w-6xl mx-auto">
      {/* Deck Title Header */}
      <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-cyan-500/30 p-8 sm:p-12 text-center space-y-4 shadow-2xl relative overflow-hidden">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/40 text-xs font-bold text-cyan-300">
          <Award className="w-3.5 h-3.5 text-cyan-400" />
          <span>Commercial Proposal & Architecture Deck (Target: PKR 20–25 Million / 2.0–2.5 Crore)</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          BYD GLOBAL MOBILITY & OPERATIONS PLATFORM
        </h1>
        <p className="text-base sm:text-lg text-cyan-300 font-semibold">
          Enterprise Automotive & Electric Vehicle Management Ecosystem
        </p>
        <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mx-auto leading-relaxed">
          An enterprise-grade independent software proposal connecting 17 specialized roles, multi-country jurisdictions (Pakistan, UAE, Saudi Arabia, UK, Germany), Native Flutter mobile applications (Android/iOS), Blade Battery laboratory diagnostics, and cloud-scale financial ledgers.
        </p>

        <div className="pt-4 flex justify-center gap-3">
          <button
            onClick={() => setActiveTab('architecture')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 font-bold text-xs text-white shadow-lg shadow-cyan-500/25"
          >
            Review Technical Architecture & APIs
          </button>
          <button
            onClick={() => setActiveTab('mobile-preview')}
            className="px-5 py-2.5 rounded-xl border border-slate-700 bg-slate-950 text-slate-300 hover:text-white font-semibold text-xs"
          >
            Launch Native Mobile Simulator
          </button>
        </div>
      </div>

      {/* Slide 1: The Core Problem & Strategic Opportunity */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Strategic Context</span>
          <h2 className="text-2xl font-extrabold text-white">The Opportunity for BYD in Pakistan</h2>
          <p className="text-xs sm:text-sm text-slate-400">Transforming high imported fuel burdens into clean, home-generated electric mobility.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="text-2xl font-black text-emerald-400">80% Cheaper</span>
            <h4 className="text-base font-bold text-white">Operating Running Costs</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              At ₨ 85/kWh on fast chargers (or ₨ 45/kWh off-peak solar home charging), driving a BYD Seal costs approximately <strong>₨ 6-8 per km</strong> compared to ₨ 35-45 per km for imported petrol luxury sedans.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="text-2xl font-black text-cyan-400">30% EV Policy</span>
            <h4 className="text-base font-bold text-white">National E-Mobility Target 2030</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Government incentives on lower CKD customs tariffs and sales tax concessions position BYD as the definitive market leader with e-Platform 3.0 and DM-i super hybrids.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <span className="text-2xl font-black text-blue-400">Zero Fear</span>
            <h4 className="text-base font-bold text-white">Blade Battery Reliability</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Proven resistance to severe 45°C+ summer ambient temperatures with zero thermal runaway and industry-leading 8-Year / 160,000 km manufacturer warranty protection.
            </p>
          </div>
        </div>
      </section>

      {/* Slide 2: 360 Ecosystem Architecture */}
      <section className="p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Solution Blueprint</span>
          <h2 className="text-2xl font-extrabold text-white">The 360 Unified Architecture</h2>
          <p className="text-xs text-slate-400">One integrated engine connecting every automotive stakeholder.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            <h5 className="text-sm font-bold text-white">1. Customer PWA Portal</h5>
            <p className="text-xs text-slate-400">Installable mobile web app, VIN lookup, appointment booking, digital job card tracker, and warranty history.</p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            <h5 className="text-sm font-bold text-white">2. Dealership 3S Hub</h5>
            <p className="text-xs text-slate-400">Lead management pipeline, test drive scheduling, delivery handover checklists, and sales quota monitoring.</p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <h5 className="text-sm font-bold text-white">3. Blade Battery Telemetry</h5>
            <p className="text-xs text-slate-400">Cell voltage balance scans, temperature sensors, State of Health (SoH) diagnostics, and AI interpretation.</p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h5 className="text-sm font-bold text-white">4. M-2 Fast Charging Grid</h5>
            <p className="text-xs text-slate-400">Interactive Pakistan motorway & city charging directory, plug reservation, and real-time navigation.</p>
          </div>
        </div>
      </section>

      {/* Slide 3: Technical Specifications & Security Readiness */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Enterprise Security</span>
          <h2 className="text-2xl font-extrabold text-white">Cybersecurity & Governance Framework</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300">
          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <Lock className="w-4 h-4 text-cyan-400" />
              <span>Role-Based Access Control (RBAC)</span>
            </div>
            <p>
              Strict separation between Customer, Technician, Service Manager, Dealer Manager, and Super Admin roles. Customers can never access internal workshop job cards or confidential dealer sales pipelines.
            </p>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] font-mono text-cyan-300">
              Validated against Cloud Firestore security rules with token role claims.
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-sm">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>Server-Side Gemini AI Pipeline</span>
            </div>
            <p>
              Gemini 3.8 Flash calls are executed exclusively on server-side endpoints with zero API key exposure in client bundles. Technical safety guardrails restrict advice to authorized EV engineering standards.
            </p>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] font-mono text-emerald-300">
              Full offline resilience with PWA service worker precaching.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
