import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { MobileNav } from './components/layout/MobileNav';
import { DemoNoticeBadge } from './components/common/DemoNoticeBadge';
import { OfflineIndicator } from './components/common/OfflineIndicator';
import { LandingPage } from './components/landing/LandingPage';
import { CustomerPortal } from './components/customer/CustomerPortal';
import { CompanyDashboard } from './components/company/CompanyDashboard';
import { CountryManagerPortal } from './components/country/CountryManagerPortal';
import { BranchManagerPortal } from './components/branch/BranchManagerPortal';
import { EmployeePortal } from './components/employee/EmployeePortal';
import { DealerPortal } from './components/dealer/DealerPortal';
import { ServicePortal } from './components/service/ServicePortal';
import { BatteryManagement } from './components/battery/BatteryManagement';
import { ChargingNetwork } from './components/charging/ChargingNetwork';
import { WarrantyPortal } from './components/warranty/WarrantyPortal';
import { AIAssistant } from './components/ai/AIAssistant';
import { NotificationCenter } from './components/notifications/NotificationCenter';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { AdminPortal } from './components/admin/AdminPortal';
import { InventoryPortal } from './components/inventory/InventoryPortal';
import { FinancePortal } from './components/finance/FinancePortal';
import { SalesPortal } from './components/sales/SalesPortal';
import { MobilePreview } from './components/mobile/MobilePreview';
import { ArchitecturePortal } from './components/architecture/ArchitecturePortal';
import { BusinessPitch } from './components/presentation/BusinessPitch';
import { AboutProject } from './components/about/AboutProject';
import { CorporateAuthModal } from './components/auth/CorporateAuthModal';
import { FounderPortal } from './components/owner/FounderPortal';
import { Sparkles, ExternalLink } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab, setActiveTab, isRTL } = useApp();

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-white pb-16 lg:pb-0"
    >
      {/* Top Legal Notice Badge */}
      <DemoNoticeBadge />

      {/* Main Enterprise Navigation */}
      <Navbar />

      {/* Content Body Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'landing' && <LandingPage />}
        {activeTab === 'customer' && <CustomerPortal />}
        {activeTab === 'company' && <CompanyDashboard />}
        {activeTab === 'country' && <CountryManagerPortal />}
        {activeTab === 'branch' && <BranchManagerPortal />}
        {activeTab === 'employee' && <EmployeePortal />}
        {activeTab === 'dealer' && <DealerPortal />}
        {activeTab === 'service' && <ServicePortal />}
        {activeTab === 'battery' && <BatteryManagement />}
        {activeTab === 'charging' && <ChargingNetwork />}
        {activeTab === 'warranty' && <WarrantyPortal />}
        {activeTab === 'inventory' && <InventoryPortal />}
        {activeTab === 'finance' && <FinancePortal />}
        {activeTab === 'sales' && <SalesPortal />}
        {activeTab === 'ai-assistant' && <AIAssistant />}
        {activeTab === 'mobile-preview' && <MobilePreview />}
        {activeTab === 'architecture' && <ArchitecturePortal />}
        {activeTab === 'notifications' && <NotificationCenter />}
        {activeTab === 'analytics' && <AnalyticsView />}
        {activeTab === 'admin' && <AdminPortal />}
        {activeTab === 'owner' && <FounderPortal />}
        {activeTab === 'presentation' && <BusinessPitch />}
        {activeTab === 'about' && <AboutProject />}
      </main>

      {/* Floating Quick BYD AI Button (when not already on AI tab) */}
      {activeTab !== 'ai-assistant' && (
        <button
          onClick={() => setActiveTab('ai-assistant')}
          className="fixed bottom-20 sm:bottom-6 right-5 z-40 flex items-center gap-2 px-4 py-2.5 rounded-full bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-600 text-slate-950 font-extrabold text-xs sm:text-sm shadow-xl shadow-cyan-500/30 hover:scale-105 transition active:scale-95 border border-cyan-300"
          title="Open BYD AI Intelligence Assistant"
        >
          <Sparkles className="w-4 h-4 text-slate-950" />
          <span>BYD AI</span>
        </button>
      )}

      {/* Corporate Authentication Modal */}
      <CorporateAuthModal />

      {/* Offline Connectivity Toast */}
      <OfflineIndicator />

      {/* Mobile Touch Bottom Nav */}
      <MobileNav />

      {/* Enterprise Global Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 mt-16 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black">
                  BYD
                </div>
                <span className="font-extrabold text-white text-sm tracking-wider">PAKISTAN 360</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">
                Independent Enterprise Automotive Management Platform proposal and functional working prototype designed for potential evaluation by authorized stakeholders in Pakistan.
              </p>
            </div>

            <div>
              <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">Ecosystem Modules</h5>
              <ul className="space-y-1.5 text-xs text-slate-400">
                <li><button onClick={() => setActiveTab('customer')} className="hover:text-cyan-300">Customer Web Portal</button></li>
                <li><button onClick={() => setActiveTab('battery')} className="hover:text-cyan-300">Blade Battery Lab</button></li>
                <li><button onClick={() => setActiveTab('charging')} className="hover:text-cyan-300">M-2 Fast Charging Grid</button></li>
                <li><button onClick={() => setActiveTab('dealer')} className="hover:text-cyan-300">3S Dealership Portal</button></li>
                <li><button onClick={() => setActiveTab('service')} className="hover:text-cyan-300">Workshop & Job Cards</button></li>
              <li><button onClick={() => setActiveTab('sales')} className="hover:text-cyan-300">Sales & Booking Mgmt</button></li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">3S Dealership Network</h5>
              <ul className="space-y-1.5 text-xs text-slate-400">
                <li>Karachi: Mega Motor Clifton 3S Flagship</li>
                <li>Karachi: Shahrah-e-Faisal Experience Studio</li>
                <li>Lahore: Gulberg III 3S Central & DHA 5</li>
                <li>Islamabad: Blue Area Capital 3S Hub</li>
                <li>Faisalabad: Canal Road Motors</li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">Compliance & Toll-Free</h5>
              <p className="text-xs text-slate-400">Toll-Free Customer Care: <strong className="text-white">0800-BYD-PK (0800-293-75)</strong></p>
              <div className="flex flex-col gap-1.5 mt-3">
                <button
                  onClick={() => setActiveTab('about')}
                  className="inline-flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 font-bold"
                >
                  <span>About This Project & Legal Notice</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setActiveTab('presentation')}
                  className="inline-flex items-center gap-1.5 text-slate-400 hover:text-white font-semibold"
                >
                  <span>View Business Evaluation Pitch</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
            <p>© 2026 BYD PAKISTAN 360 • Founder &amp; CEO: Intekhab Alam • Built with React, TypeScript, SQLite RBAC &amp; BYD AI.</p>
            <p className="text-slate-500">Independent Enterprise Proposal • Real Backend Authentication Active.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
