import React, { useState, useEffect, useCallback } from 'react';
import { Shield, Search, Download, Lock } from 'lucide-react';
import { api } from '../../services/api';

export const OwnerActivityLogsPanel: React.FC = () => {
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [data, setData] = useState<{ immutable: boolean; totalMatched: number; logs: any[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const loadLogs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.getOwnerActivityLogs({
        category,
        search: search.trim() || undefined,
        fromDate: fromDate || undefined,
        toDate: toDate || undefined,
        limit: 150,
      });
      setData(res);
    } finally {
      setLoading(false);
    }
  }, [category, search, fromDate, toDate]);

  useEffect(() => {
    loadLogs();
  }, [loadLogs]);

  const exportCsv = () => {
    if (!data?.logs?.length) return;
    const headers = ['Timestamp', 'Actor', 'Role', 'Action', 'Module', 'Target', 'IP Address', 'Device', 'Browser', 'Session ID', 'Status', 'Details'];
    const rows = data.logs.map((l) =>
      [l.createdAt, l.actorName, l.actorRole, l.action, l.module, l.targetId, l.ipAddress, l.deviceName, l.browserName, l.sessionId, l.status, l.details]
        .map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`)
        .join(',')
    );
    const blob = new Blob([[headers.join(','), ...rows].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BYD_360_Owner_Audit_Logs_${category}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>Immutable Owner &amp; Enterprise Activity Logs ({data?.totalMatched ?? 0})</span>
            </h3>
            <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>Append-only audit trail covering Founder logins, financial reports, permissions, Super Admins, employees, dealerships &amp; config updates.</span>
            </p>
          </div>
          <button
            type="button"
            onClick={exportCsv}
            disabled={!data?.logs?.length}
            className="px-3.5 py-2 rounded-xl border border-cyan-500/40 bg-cyan-950/40 text-xs font-bold text-cyan-300 hover:text-white disabled:opacity-40 flex items-center gap-1.5 shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Audit CSV</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {[
            { id: 'all', label: 'All Events' },
            { id: 'founder', label: 'Founder Actions' },
            { id: 'finance', label: 'Financial Access' },
            { id: 'permissions', label: 'Permission Changes' },
            { id: 'super_admin', label: 'Super Admins' },
            { id: 'employees', label: 'Employees' },
            { id: 'dealerships', label: 'Dealerships' },
            { id: 'logins', label: 'Login & Sessions' },
          ].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl font-bold border transition ${
                category === c.id
                  ? 'bg-amber-500 text-slate-950 border-amber-400'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search actor, action, IP, device, target..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
          />
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
          />
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5">
        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400">Loading verified audit ledger...</div>
        ) : !(data?.logs?.length) ? (
          <div className="py-8 text-center text-xs text-slate-500">No Data Available</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Date &amp; Time</th>
                  <th className="py-2.5 px-3">Actor &amp; Role</th>
                  <th className="py-2.5 px-3">Action / Module</th>
                  <th className="py-2.5 px-3">Target &amp; Details</th>
                  <th className="py-2.5 px-3">Device / Browser / Session</th>
                  <th className="py-2.5 px-3">IP</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {data.logs.map((l) => (
                  <tr key={`${l.source}-${l.id}`} className="hover:bg-slate-800/30">
                    <td className="py-2 px-3 font-mono text-slate-400 whitespace-nowrap">
                      {String(l.createdAt || '').slice(0, 19).replace('T', ' ')}
                    </td>
                    <td className="py-2 px-3">
                      <div className="font-semibold text-white">{l.actorName}</div>
                      <div className="text-[10px] text-cyan-300">{l.actorRole}</div>
                    </td>
                    <td className="py-2 px-3">
                      <div className="font-mono font-bold text-amber-300">{l.action}</div>
                      <div className="text-[10px] text-slate-400">{l.module}</div>
                    </td>
                    <td className="py-2 px-3 max-w-xs">
                      <div className="text-white truncate">{l.targetId || '—'}</div>
                      {l.details && <div className="text-[10px] text-slate-400 truncate">{l.details}</div>}
                    </td>
                    <td className="py-2 px-3">
                      <div className="text-slate-200">{l.deviceName} • {l.browserName}</div>
                      {l.sessionId && <div className="text-[10px] font-mono text-slate-500">Sess: {String(l.sessionId).slice(0, 12)}</div>}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-400">{l.ipAddress}</td>
                    <td className="py-2 px-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          l.status === 'ALERT'
                            ? 'bg-rose-950 text-rose-300'
                            : l.status === 'WARNING'
                            ? 'bg-amber-950 text-amber-300'
                            : 'bg-emerald-950 text-emerald-300'
                        }`}
                      >
                        {l.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
