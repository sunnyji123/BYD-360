import {
  Vehicle,
  ServiceJob,
  BatteryInspectionRecord,
  ChargingStation,
  WarrantyClaim,
  Dealership,
  SalesLead,
  NotificationItem,
  AuditLog,
  SparePart,
  UserProfile,
  Warehouse,
  InventoryTransaction,
  GlobalInvoice,
  OwnershipTransferRequest,
  Booking,
  SalesOrder,
  Payment,
  Installment,
  Refund,
  SalesCommission,
  DeliveryRecord,
  FinanceTransaction,
  BankTransaction,
  TaxRecord,
  DealerPayment,
  CustomerPayment,
  ProfitLossSummary,
  FinancialStatement,
  MaintenanceReminder,
  Technician,
} from '../types';
import {
  INITIAL_VEHICLES,
  INITIAL_SERVICE_JOBS,
  INITIAL_BATTERY_RECORDS,
  INITIAL_CHARGING_STATIONS,
  INITIAL_WARRANTY_CLAIMS,
  INITIAL_DEALERSHIPS,
  INITIAL_SALES_LEADS,
  INITIAL_NOTIFICATIONS,
  INITIAL_SPARE_PARTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_USERS,
  INITIAL_WAREHOUSES,
  INITIAL_INVENTORY_TRANSACTIONS,
  INITIAL_INVOICES,
  INITIAL_OWNERSHIP_TRANSFERS,
  INITIAL_BOOKINGS,
  INITIAL_SALES_ORDERS,
  INITIAL_PAYMENTS,
  INITIAL_INSTALLMENTS,
  INITIAL_REFUNDS,
  INITIAL_SALES_COMMISSIONS,
  INITIAL_DELIVERY_RECORDS,
  INITIAL_FINANCE_TRANSACTIONS,
  INITIAL_BANK_TRANSACTIONS,
  INITIAL_TAX_RECORDS,
  INITIAL_DEALER_PAYMENTS,
  INITIAL_CUSTOMER_PAYMENTS,
  INITIAL_FINANCIAL_STATEMENTS,
  INITIAL_MAINTENANCE_REMINDERS,
  INITIAL_TECHNICIANS,
} from '../data/mockData';

const STORAGE_PREFIX = 'byd_pk_360_v1_';

type Listener = () => void;

class DatabaseService {
  private listeners: Listener[] = [];

  constructor() {
    this.initIfEmpty();
  }

  private initIfEmpty() {
    if (typeof window === 'undefined') return;
    if (!localStorage.getItem(`${STORAGE_PREFIX}initialized_v2`)) {
      this.resetToDefaults();
    }
  }

  public resetToDefaults() {
    if (typeof window === 'undefined') return;
    localStorage.setItem(`${STORAGE_PREFIX}vehicles`, JSON.stringify(INITIAL_VEHICLES));
    localStorage.setItem(`${STORAGE_PREFIX}service_jobs`, JSON.stringify(INITIAL_SERVICE_JOBS));
    localStorage.setItem(`${STORAGE_PREFIX}battery_records`, JSON.stringify(INITIAL_BATTERY_RECORDS));
    localStorage.setItem(`${STORAGE_PREFIX}charging_stations`, JSON.stringify(INITIAL_CHARGING_STATIONS));
    localStorage.setItem(`${STORAGE_PREFIX}warranty_claims`, JSON.stringify(INITIAL_WARRANTY_CLAIMS));
    localStorage.setItem(`${STORAGE_PREFIX}dealerships`, JSON.stringify(INITIAL_DEALERSHIPS));
    localStorage.setItem(`${STORAGE_PREFIX}sales_leads`, JSON.stringify(INITIAL_SALES_LEADS));
    localStorage.setItem(`${STORAGE_PREFIX}notifications`, JSON.stringify(INITIAL_NOTIFICATIONS));
    localStorage.setItem(`${STORAGE_PREFIX}spare_parts`, JSON.stringify(INITIAL_SPARE_PARTS));
    localStorage.setItem(`${STORAGE_PREFIX}audit_logs`, JSON.stringify(INITIAL_AUDIT_LOGS));
    localStorage.setItem(`${STORAGE_PREFIX}users`, JSON.stringify(INITIAL_USERS));
    localStorage.setItem(`${STORAGE_PREFIX}warehouses`, JSON.stringify(INITIAL_WAREHOUSES));
    localStorage.setItem(`${STORAGE_PREFIX}inventory_transactions`, JSON.stringify(INITIAL_INVENTORY_TRANSACTIONS));
    localStorage.setItem(`${STORAGE_PREFIX}invoices`, JSON.stringify(INITIAL_INVOICES));
    localStorage.setItem(`${STORAGE_PREFIX}ownership_transfers`, JSON.stringify(INITIAL_OWNERSHIP_TRANSFERS));
    localStorage.setItem(`${STORAGE_PREFIX}initialized_v2`, 'true');
    this.notify();
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (err) {
        console.error('Database listener error:', err);
      }
    });
  }

  private getItem<T>(key: string, fallback: T): T {
    if (typeof window === 'undefined') return fallback;
    const raw = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
    if (!raw) return fallback;
    try {
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  }

  private setItem<T>(key: string, data: T) {
    if (typeof window === 'undefined') return;
    localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(data));
    this.notify();
  }

  // Vehicles
  public getVehicles(): Vehicle[] {
    return this.getItem<Vehicle[]>('vehicles', INITIAL_VEHICLES);
  }

  public addVehicle(vehicle: Vehicle) {
    const list = this.getVehicles();
    list.unshift(vehicle);
    this.setItem('vehicles', list);
    this.logAudit({
      userId: vehicle.ownerId,
      userName: vehicle.ownerName,
      role: 'Customer',
      action: 'VEHICLE_REGISTER',
      module: 'Vehicle Registry',
      targetId: vehicle.vin,
    });
  }

  public updateVehicle(updated: Vehicle) {
    const list = this.getVehicles().map((v) => (v.id === updated.id ? updated : v));
    this.setItem('vehicles', list);
  }

  // Service Jobs
  public getServiceJobs(): ServiceJob[] {
    return this.getItem<ServiceJob[]>('service_jobs', INITIAL_SERVICE_JOBS);
  }

  public addServiceJob(job: ServiceJob) {
    const list = this.getServiceJobs();
    list.unshift(job);
    this.setItem('service_jobs', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Service Appointment Confirmed',
      message: `Appointment ${job.ticketNumber} scheduled for ${job.model} (${job.licensePlate}) at ${job.dealershipName}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Service',
      read: false,
      actionUrl: 'service',
    });

    this.logAudit({
      userId: 'usr_cust_1',
      userName: job.customerName,
      role: 'Customer',
      action: 'APPOINTMENT_BOOKED',
      module: 'Service Management',
      targetId: job.ticketNumber,
    });
  }

  public updateServiceJob(updated: ServiceJob) {
    const list = this.getServiceJobs().map((j) => (j.id === updated.id ? updated : j));
    this.setItem('service_jobs', list);
    this.notify();
  }

  // Battery Records
  public getBatteryRecords(): BatteryInspectionRecord[] {
    return this.getItem<BatteryInspectionRecord[]>('battery_records', INITIAL_BATTERY_RECORDS);
  }

  public addBatteryRecord(record: BatteryInspectionRecord) {
    const list = this.getBatteryRecords();
    list.unshift(record);
    this.setItem('battery_records', list);

    // Update vehicle's battery health
    const vehicles = this.getVehicles();
    const target = vehicles.find((v) => v.id === record.vehicleId || v.vin === record.vin);
    if (target) {
      target.batteryHealthSoH = record.sohPercentage;
      target.batteryHealthSoC = record.socPercentage;
      this.updateVehicle(target);
    }
  }

  // Charging Stations
  public getChargingStations(): ChargingStation[] {
    return this.getItem<ChargingStation[]>('charging_stations', INITIAL_CHARGING_STATIONS);
  }

  public addChargingStation(station: ChargingStation) {
    const list = this.getChargingStations();
    list.unshift(station);
    this.setItem('charging_stations', list);
  }

  public updateChargingStation(updated: ChargingStation) {
    const list = this.getChargingStations().map((s) => (s.id === updated.id ? updated : s));
    this.setItem('charging_stations', list);
  }

  // Warranty Claims
  public getWarrantyClaims(): WarrantyClaim[] {
    return this.getItem<WarrantyClaim[]>('warranty_claims', INITIAL_WARRANTY_CLAIMS);
  }

  public addWarrantyClaim(claim: WarrantyClaim) {
    const list = this.getWarrantyClaims();
    list.unshift(claim);
    this.setItem('warranty_claims', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Warranty Claim Filed',
      message: `Claim ${claim.claimNumber} filed for ${claim.vehicleModel} (${claim.componentCategory}).`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Warranty',
      read: false,
      actionUrl: 'warranty',
    });

    this.logAudit({
      userId: 'usr_cust_1',
      userName: claim.customerName,
      role: 'Customer',
      action: 'WARRANTY_CLAIM_SUBMIT',
      module: 'Warranty Engine',
      targetId: claim.claimNumber,
    });
  }

  public updateWarrantyClaim(updated: WarrantyClaim) {
    const list = this.getWarrantyClaims().map((c) => (c.id === updated.id ? updated : c));
    this.setItem('warranty_claims', list);
  }

  // Dealerships
  public getDealerships(): Dealership[] {
    return this.getItem<Dealership[]>('dealerships', INITIAL_DEALERSHIPS);
  }

  // Sales Leads
  public getSalesLeads(): SalesLead[] {
    return this.getItem<SalesLead[]>('sales_leads', INITIAL_SALES_LEADS);
  }

  public addSalesLead(lead: SalesLead) {
    const list = this.getSalesLeads();
    list.unshift(lead);
    this.setItem('sales_leads', list);
  }

  public updateSalesLead(updated: SalesLead) {
    const list = this.getSalesLeads().map((l) => (l.id === updated.id ? updated : l));
    this.setItem('sales_leads', list);
  }

  // Spare Parts
  public getSpareParts(): SparePart[] {
    return this.getItem<SparePart[]>('spare_parts', INITIAL_SPARE_PARTS);
  }

  public updateSparePartStock(partId: string, quantityDelta: number) {
    const parts = this.getSpareParts();
    const target = parts.find((p) => p.id === partId);
    if (target) {
      target.stockQuantity = Math.max(0, target.stockQuantity + quantityDelta);
      this.setItem('spare_parts', parts);
    }
  }

  // Notifications
  public getNotifications(): NotificationItem[] {
    return this.getItem<NotificationItem[]>('notifications', INITIAL_NOTIFICATIONS);
  }

  public addNotification(notification: NotificationItem) {
    const list = this.getNotifications();
    list.unshift(notification);
    this.setItem('notifications', list);
  }

  public markNotificationAsRead(id: string) {
    const list = this.getNotifications().map((n) => (n.id === id ? { ...n, read: true } : n));
    this.setItem('notifications', list);
  }

  public markAllNotificationsAsRead() {
    const list = this.getNotifications().map((n) => ({ ...n, read: true }));
    this.setItem('notifications', list);
  }

  // Users
  public getUsers(): UserProfile[] {
    return this.getItem<UserProfile[]>('users', INITIAL_USERS);
  }

  public addUser(user: UserProfile) {
    const list = this.getUsers();
    list.push(user);
    this.setItem('users', list);
  }

  public updateUser(user: UserProfile) {
    const list = this.getUsers().map((u) => (u.id === user.id ? user : u));
    this.setItem('users', list);
  }

  // Audit Logs
  public getAuditLogs(): AuditLog[] {
    return this.getItem<AuditLog[]>('audit_logs', INITIAL_AUDIT_LOGS);
  }

  public logAudit(entry: {
    userId?: string;
    userName?: string;
    role?: string;
    action: string;
    module: string;
    targetId: string;
    status?: 'SUCCESS' | 'WARNING' | 'ALERT';
  }) {
    const logs = this.getAuditLogs();
    const newEntry: AuditLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      userId: entry.userId || 'system',
      userName: entry.userName || 'System Operator',
      role: entry.role || 'Super Admin',
      action: entry.action,
      module: entry.module,
      targetId: entry.targetId,
      ipAddress: '182.180.144.12 (Karachi Gateway)',
      status: entry.status || 'SUCCESS',
    };
    logs.unshift(newEntry);
    this.setItem('audit_logs', logs.slice(0, 100)); // retain last 100
  }

  // Warehouses
  public getWarehouses(): Warehouse[] {
    return this.getItem<Warehouse[]>('warehouses', INITIAL_WAREHOUSES);
  }

  public addWarehouse(warehouse: Warehouse) {
    const list = this.getWarehouses();
    list.push(warehouse);
    this.setItem('warehouses', list);
  }

  // Inventory Transactions
  public getInventoryTransactions(): InventoryTransaction[] {
    return this.getItem<InventoryTransaction[]>('inventory_transactions', INITIAL_INVENTORY_TRANSACTIONS);
  }

  public addInventoryTransaction(tx: InventoryTransaction) {
    const list = this.getInventoryTransactions();
    list.unshift(tx);
    this.setItem('inventory_transactions', list);
  }

  // Invoices & Global Finance
  public getInvoices(): GlobalInvoice[] {
    return this.getItem<GlobalInvoice[]>('invoices', INITIAL_INVOICES);
  }

  public addInvoice(invoice: GlobalInvoice) {
    const list = this.getInvoices();
    list.unshift(invoice);
    this.setItem('invoices', list);
  }

  public updateInvoiceStatus(id: string, status: GlobalInvoice['status']) {
    const list = this.getInvoices().map((inv) => (inv.id === id ? { ...inv, status } : inv));
    this.setItem('invoices', list);
  }

  // Vehicle Ownership Transfers
  public getOwnershipTransfers(): OwnershipTransferRequest[] {
    return this.getItem<OwnershipTransferRequest[]>('ownership_transfers', INITIAL_OWNERSHIP_TRANSFERS);
  }

  public addOwnershipTransfer(transfer: OwnershipTransferRequest) {
    const list = this.getOwnershipTransfers();
    list.unshift(transfer);
    this.setItem('ownership_transfers', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Ownership Transfer Submitted',
      message: `Transfer application ${transfer.transferRef} initiated for ${transfer.vehicleModel} (${transfer.licensePlate}) by ${transfer.dealershipName}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Security',
      read: false,
      actionUrl: 'admin',
    });

    this.logAudit({
      userName: transfer.requestedBy,
      role: 'Dealer Manager',
      action: 'OWNERSHIP_TRANSFER_REQUEST',
      module: 'Vehicle Title & Registration',
      targetId: transfer.vin,
    });
  }

  public updateOwnershipTransfer(updated: OwnershipTransferRequest) {
    const list = this.getOwnershipTransfers().map((t) => (t.id === updated.id ? updated : t));
    this.setItem('ownership_transfers', list);
  }

  /**
   * Atomic Vehicle Ownership Transfer Approval:
   * 1. Finds the transfer request.
   * 2. Checks/Creates new customer user account if not already in system.
   * 3. Updates the Vehicle's ownerId, ownerName, ownerPhone, ownerCity.
   *    (Crucial: Previous owner immediately loses access to this VIN in customer portal, but keeps other vehicles!)
   * 4. Updates transfer request status to 'Approved' & 'Completed'.
   * 5. Emits security audit log & sends notifications to both parties.
   */
  public approveOwnershipTransfer(transferId: string, reviewerName: string): { success: boolean; message: string } {
    const transfers = this.getOwnershipTransfers();
    const transferIndex = transfers.findIndex((t) => t.id === transferId);
    if (transferIndex === -1) {
      return { success: false, message: 'Transfer request not found.' };
    }

    const transfer = transfers[transferIndex];
    if (transfer.status === 'Approved' || transfer.status === 'Completed') {
      return { success: false, message: 'Transfer is already approved.' };
    }

    // 1. Locate vehicle
    const vehicles = this.getVehicles();
    const vehicle = vehicles.find((v) => v.vin === transfer.vin);
    if (!vehicle) {
      return { success: false, message: `Vehicle with VIN ${transfer.vin} not found in fleet registry.` };
    }

    // 2. Locate or provision new customer user profile
    const users = this.getUsers();
    let newCustomer = users.find((u) => u.email.toLowerCase() === transfer.newOwnerEmail.toLowerCase());
    if (!newCustomer) {
      const newUserId = `usr_cust_${Date.now()}`;
      newCustomer = {
        id: newUserId,
        name: transfer.newOwnerName,
        email: transfer.newOwnerEmail,
        phone: transfer.newOwnerPhone,
        role: 'Customer',
        city: transfer.newOwnerCity,
        country: 'PK',
        status: 'Active',
        verifiedIdentity: true,
        provisionedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
        provisionedBy: reviewerName,
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&q=80',
      };
      this.addUser(newCustomer);
    }

    // 3. Update Vehicle Ownership atomically
    const previousOwnerId = vehicle.ownerId;
    const previousOwnerName = vehicle.ownerName;

    const updatedVehicle: Vehicle = {
      ...vehicle,
      ownerId: newCustomer.id,
      ownerName: newCustomer.name,
      ownerPhone: newCustomer.phone,
      ownerCity: newCustomer.city,
    };
    this.updateVehicle(updatedVehicle);

    // 4. Update Transfer Request
    const updatedTransfer: OwnershipTransferRequest = {
      ...transfer,
      status: 'Approved',
      reviewedBy: reviewerName,
      reviewedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      notes: `${transfer.notes ? transfer.notes + ' | ' : ''}Approved by Head Office. Title transferred to ${newCustomer.name} (${newCustomer.id}).`,
    };
    transfers[transferIndex] = updatedTransfer;
    this.setItem('ownership_transfers', transfers);

    // 5. Notifications
    this.addNotification({
      id: `notif_${Date.now()}_prev`,
      title: 'Vehicle Ownership Transferred Out',
      message: `Your ${vehicle.model} (${vehicle.licensePlate}) ownership has been officially transferred to ${newCustomer.name}. The vehicle is no longer associated with your portal.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Security',
      read: false,
    });

    this.addNotification({
      id: `notif_${Date.now()}_new`,
      title: 'Vehicle Title Activated in Portal',
      message: `Congratulations ${newCustomer.name}! Your ${vehicle.model} (${vehicle.licensePlate}) is now officially active in your BYD 360 Customer Portal.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Delivery',
      read: false,
      actionUrl: 'customer',
    });

    // 6. Security Audit Log
    this.logAudit({
      userName: reviewerName,
      role: 'Global Super Admin',
      action: 'VEHICLE_TITLE_TRANSFER_APPROVED',
      module: 'Vehicle Title & Registration',
      targetId: `${vehicle.vin} [From: ${previousOwnerName} (${previousOwnerId}) -> To: ${newCustomer.name} (${newCustomer.id})]`,
      status: 'SUCCESS',
    });

    return { success: true, message: `Vehicle title successfully transferred to ${newCustomer.name}.` };
  }

  public rejectOwnershipTransfer(transferId: string, reviewerName: string, reason: string): { success: boolean; message: string } {
    const transfers = this.getOwnershipTransfers();
    const transfer = transfers.find((t) => t.id === transferId);
    if (!transfer) {
      return { success: false, message: 'Transfer request not found.' };
    }

    const updated: OwnershipTransferRequest = {
      ...transfer,
      status: 'Rejected',
      reviewedBy: reviewerName,
      reviewedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      rejectionReason: reason,
    };
    this.updateOwnershipTransfer(updated);

    this.logAudit({
      userName: reviewerName,
      role: 'Global Super Admin',
      action: 'VEHICLE_TITLE_TRANSFER_REJECTED',
      module: 'Vehicle Title & Registration',
      targetId: `${transfer.vin} [Reason: ${reason}]`,
      status: 'WARNING',
    });

    return { success: true, message: 'Transfer request rejected.' };
  }

  /**
   * Head Office Customer Account Provisioning
   */
  public provisionCustomerAccount(data: {
    name: string;
    email: string;
    phone: string;
    city: string;
    cnicOrId?: string;
    vin?: string;
    provisionedBy: string;
  }): { success: boolean; user?: UserProfile; message: string } {
    const users = this.getUsers();
    if (users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
      return { success: false, message: 'A user account with this email address already exists.' };
    }

    const newUserId = `usr_cust_${Date.now()}`;
    const newUser: UserProfile = {
      id: newUserId,
      name: data.name,
      email: data.email,
      phone: data.phone,
      role: 'Customer',
      city: data.city,
      country: 'PK',
      status: 'Active',
      verifiedIdentity: true,
      provisionedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      provisionedBy: data.provisionedBy,
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&q=80',
    };

    this.addUser(newUser);

    // If VIN specified, bind vehicle to this customer
    if (data.vin) {
      const vehicle = this.getVehicles().find((v) => v.vin === data.vin);
      if (vehicle) {
        this.updateVehicle({
          ...vehicle,
          ownerId: newUser.id,
          ownerName: newUser.name,
          ownerPhone: newUser.phone,
          ownerCity: newUser.city,
        });
      }
    }

    this.logAudit({
      userName: data.provisionedBy,
      role: 'Global Super Admin',
      action: 'CUSTOMER_ACCOUNT_PROVISIONED',
      module: 'User Management',
      targetId: `${newUser.name} (${newUser.email})`,
      status: 'SUCCESS',
    });

    return { success: true, user: newUser, message: 'Verified customer account provisioned successfully.' };
  }

  // ============================================================================
  // SALES & BOOKING MANAGEMENT (Phase 1)
  // ============================================================================

  // Bookings
  public getBookings(): Booking[] {
    return this.getItem<Booking[]>('bookings', INITIAL_BOOKINGS);
  }

  public addBooking(booking: Booking) {
    const list = this.getBookings();
    list.unshift(booking);
    this.setItem('bookings', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'New Booking Received',
      message: `Booking ${booking.bookingRef} for ${booking.vehicleModel} by ${booking.customerName}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Delivery',
      read: false,
      actionUrl: 'sales',
    });

    this.logAudit({
      userId: booking.customerId,
      userName: booking.customerName,
      role: 'Customer',
      action: 'BOOKING_CREATED',
      module: 'Sales & Booking Management',
      targetId: booking.bookingRef,
      status: 'SUCCESS',
    });
  }

  public updateBooking(updated: Booking) {
    const list = this.getBookings().map((b) => (b.id === updated.id ? updated : b));
    this.setItem('bookings', list);
    this.notify();
  }

  public deleteBooking(id: string) {
    const list = this.getBookings().filter((b) => b.id !== id);
    this.setItem('bookings', list);
    this.notify();
  }

  // Sales Orders
  public getSalesOrders(): SalesOrder[] {
    return this.getItem<SalesOrder[]>('sales_orders', INITIAL_SALES_ORDERS);
  }

  public addSalesOrder(order: SalesOrder) {
    const list = this.getSalesOrders();
    list.unshift(order);
    this.setItem('sales_orders', list);

    this.logAudit({
      userId: order.customerId,
      userName: order.customerName,
      role: 'Customer',
      action: 'SALES_ORDER_CREATED',
      module: 'Sales & Booking Management',
      targetId: order.saleRef,
      status: 'SUCCESS',
    });
  }

  public updateSalesOrder(updated: SalesOrder) {
    const list = this.getSalesOrders().map((o) => (o.id === updated.id ? updated : o));
    this.setItem('sales_orders', list);
    this.notify();
  }

  public deleteSalesOrder(id: string) {
    const list = this.getSalesOrders().filter((o) => o.id !== id);
    this.setItem('sales_orders', list);
    this.notify();
  }

  // Payments
  public getPayments(): Payment[] {
    return this.getItem<Payment[]>('payments', INITIAL_PAYMENTS);
  }

  public addPayment(payment: Payment) {
    const list = this.getPayments();
    list.unshift(payment);
    this.setItem('payments', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Payment Received',
      message: `Payment of ${payment.amountPkr.toLocaleString()} PKR received from ${payment.customerId}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Delivery',
      read: false,
      actionUrl: 'sales',
    });

    this.logAudit({
      userId: payment.customerId,
      userName: payment.customerId,
      role: 'Customer',
      action: 'PAYMENT_RECEIVED',
      module: 'Sales & Booking Management',
      targetId: payment.paymentRef,
      status: 'SUCCESS',
    });
  }

  public updatePayment(updated: Payment) {
    const list = this.getPayments().map((p) => (p.id === updated.id ? updated : p));
    this.setItem('payments', list);
    this.notify();
  }

  public deletePayment(id: string) {
    const list = this.getPayments().filter((p) => p.id !== id);
    this.setItem('payments', list);
    this.notify();
  }

  // Installments
  public getInstallments(): Installment[] {
    return this.getItem<Installment[]>('installments', INITIAL_INSTALLMENTS);
  }

  public addInstallment(installment: Installment) {
    const list = this.getInstallments();
    list.unshift(installment);
    this.setItem('installments', list);
  }

  public updateInstallment(updated: Installment) {
    const list = this.getInstallments().map((i) => (i.id === updated.id ? updated : i));
    this.setItem('installments', list);
    this.notify();
  }

  public deleteInstallment(id: string) {
    const list = this.getInstallments().filter((i) => i.id !== id);
    this.setItem('installments', list);
    this.notify();
  }

  // Refunds
  public getRefunds(): Refund[] {
    return this.getItem<Refund[]>('refunds', INITIAL_REFUNDS);
  }

  public addRefund(refund: Refund) {
    const list = this.getRefunds();
    list.unshift(refund);
    this.setItem('refunds', list);

    this.logAudit({
      userId: refund.customerId,
      userName: refund.customerName,
      role: 'Customer',
      action: 'REFUND_REQUESTED',
      module: 'Sales & Booking Management',
      targetId: refund.refundRef,
      status: 'WARNING',
    });
  }

  public updateRefund(updated: Refund) {
    const list = this.getRefunds().map((r) => (r.id === updated.id ? updated : r));
    this.setItem('refunds', list);
    this.notify();
  }

  public deleteRefund(id: string) {
    const list = this.getRefunds().filter((r) => r.id !== id);
    this.setItem('refunds', list);
    this.notify();
  }

  // Sales Commissions
  public getSalesCommissions(): SalesCommission[] {
    return this.getItem<SalesCommission[]>('sales_commissions', INITIAL_SALES_COMMISSIONS);
  }

  public addSalesCommission(commission: SalesCommission) {
    const list = this.getSalesCommissions();
    list.unshift(commission);
    this.setItem('sales_commissions', list);
  }

  public updateSalesCommission(updated: SalesCommission) {
    const list = this.getSalesCommissions().map((c) => (c.id === updated.id ? updated : c));
    this.setItem('sales_commissions', list);
    this.notify();
  }

  public deleteSalesCommission(id: string) {
    const list = this.getSalesCommissions().filter((c) => c.id !== id);
    this.setItem('sales_commissions', list);
    this.notify();
  }

  // Delivery Records
  public getDeliveryRecords(): DeliveryRecord[] {
    return this.getItem<DeliveryRecord[]>('delivery_records', INITIAL_DELIVERY_RECORDS);
  }

  public addDeliveryRecord(record: DeliveryRecord) {
    const list = this.getDeliveryRecords();
    list.unshift(record);
    this.setItem('delivery_records', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Vehicle Delivery Scheduled',
      message: `Delivery ${record.deliveryRef} for ${record.vehicleModel} scheduled on ${record.deliveryDate}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Delivery',
      read: false,
      actionUrl: 'sales',
    });

    this.logAudit({
      userId: record.customerId,
      userName: record.customerName,
      role: 'Customer',
      action: 'DELIVERY_SCHEDULED',
      module: 'Sales & Booking Management',
      targetId: record.deliveryRef,
      status: 'SUCCESS',
    });
  }

  public updateDeliveryRecord(updated: DeliveryRecord) {
    const list = this.getDeliveryRecords().map((d) => (d.id === updated.id ? updated : d));
    this.setItem('delivery_records', list);
    this.notify();
  }

  public deleteDeliveryRecord(id: string) {
    const list = this.getDeliveryRecords().filter((d) => d.id !== id);
    this.setItem('delivery_records', list);
    this.notify();
  }

  // ============================================================================
  // FINANCE & ACCOUNTING (Phase 2)
  // ============================================================================

  // Finance Transactions
  public getFinanceTransactions(): FinanceTransaction[] {
    return this.getItem<FinanceTransaction[]>('finance_transactions', INITIAL_FINANCE_TRANSACTIONS);
  }

  public addFinanceTransaction(tx: FinanceTransaction) {
    const list = this.getFinanceTransactions();
    list.unshift(tx);
    this.setItem('finance_transactions', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: `New ${tx.type === 'INCOME' ? 'Income' : 'Expense'} Recorded`,
      message: `${tx.category} — ${formatPrice(tx.amountPkr)} recorded by ${tx.recordedBy}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Announcement',
      read: false,
      actionUrl: 'finance',
    });

    this.logAudit({
      userId: tx.recordedBy,
      userName: tx.recordedBy,
      role: tx.recordedByRole,
      action: tx.type === 'INCOME' ? 'FINANCE_INCOME_RECORDED' : 'FINANCE_EXPENSE_RECORDED',
      module: 'Finance & Accounting',
      targetId: tx.transactionRef,
      status: 'SUCCESS',
    });
  }

  public updateFinanceTransaction(updated: FinanceTransaction) {
    const list = this.getFinanceTransactions().map((t) => (t.id === updated.id ? updated : t));
    this.setItem('finance_transactions', list);
    this.notify();
  }

  public deleteFinanceTransaction(id: string) {
    const list = this.getFinanceTransactions().filter((t) => t.id !== id);
    this.setItem('finance_transactions', list);
    this.notify();
  }

  // Bank Transactions
  public getBankTransactions(): BankTransaction[] {
    return this.getItem<BankTransaction[]>('bank_transactions', INITIAL_BANK_TRANSACTIONS);
  }

  public addBankTransaction(tx: BankTransaction) {
    const list = this.getBankTransactions();
    list.unshift(tx);
    this.setItem('bank_transactions', list);
  }

  public updateBankTransaction(updated: BankTransaction) {
    const list = this.getBankTransactions().map((t) => (t.id === updated.id ? updated : t));
    this.setItem('bank_transactions', list);
    this.notify();
  }

  public deleteBankTransaction(id: string) {
    const list = this.getBankTransactions().filter((t) => t.id !== id);
    this.setItem('bank_transactions', list);
    this.notify();
  }

  // Tax Records
  public getTaxRecords(): TaxRecord[] {
    return this.getItem<TaxRecord[]>('tax_records', INITIAL_TAX_RECORDS);
  }

  public addTaxRecord(record: TaxRecord) {
    const list = this.getTaxRecords();
    list.unshift(record);
    this.setItem('tax_records', list);
  }

  public updateTaxRecord(updated: TaxRecord) {
    const list = this.getTaxRecords().map((t) => (t.id === updated.id ? updated : t));
    this.setItem('tax_records', list);
    this.notify();
  }

  public deleteTaxRecord(id: string) {
    const list = this.getTaxRecords().filter((t) => t.id !== id);
    this.setItem('tax_records', list);
    this.notify();
  }

  // Dealer Payments
  public getDealerPayments(): DealerPayment[] {
    return this.getItem<DealerPayment[]>('dealer_payments', INITIAL_DEALER_PAYMENTS);
  }

  public addDealerPayment(payment: DealerPayment) {
    const list = this.getDealerPayments();
    list.unshift(payment);
    this.setItem('dealer_payments', list);
  }

  public updateDealerPayment(updated: DealerPayment) {
    const list = this.getDealerPayments().map((p) => (p.id === updated.id ? updated : p));
    this.setItem('dealer_payments', list);
    this.notify();
  }

  public deleteDealerPayment(id: string) {
    const list = this.getDealerPayments().filter((p) => p.id !== id);
    this.setItem('dealer_payments', list);
    this.notify();
  }

  // Customer Payments
  public getCustomerPayments(): CustomerPayment[] {
    return this.getItem<CustomerPayment[]>('customer_payments', INITIAL_CUSTOMER_PAYMENTS);
  }

  public addCustomerPayment(payment: CustomerPayment) {
    const list = this.getCustomerPayments();
    list.unshift(payment);
    this.setItem('customer_payments', list);
  }

  public updateCustomerPayment(updated: CustomerPayment) {
    const list = this.getCustomerPayments().map((p) => (p.id === updated.id ? updated : p));
    this.setItem('customer_payments', list);
    this.notify();
  }

  public deleteCustomerPayment(id: string) {
    const list = this.getCustomerPayments().filter((p) => p.id !== id);
    this.setItem('customer_payments', list);
    this.notify();
  }

  // Profit & Loss Summary
  public getProfitLossSummary(period: string): ProfitLossSummary {
    const transactions = this.getFinanceTransactions();
    const filtered = transactions.filter((t) => t.transactionDate.startsWith(period));

    const incomeByCategory: Record<string, number> = {};
    const expenseByCategory: Record<string, number> = {};
    let totalIncome = 0;
    let totalExpense = 0;

    for (const t of filtered) {
      if (t.type === 'INCOME') {
        incomeByCategory[t.category] = (incomeByCategory[t.category] || 0) + t.amountPkr;
        totalIncome += t.amountPkr;
      } else {
        expenseByCategory[t.category] = (expenseByCategory[t.category] || 0) + t.amountPkr;
        totalExpense += t.amountPkr;
      }
    }

    const netProfit = totalIncome - totalExpense;
    const profitMargin = totalIncome > 0 ? (netProfit / totalIncome) * 100 : 0;

    return {
      period,
      totalIncomePkr: totalIncome,
      totalExpensePkr: totalExpense,
      netProfitPkr: netProfit,
      profitMarginPercent: Math.round(profitMargin * 100) / 100,
      incomeByCategory: Object.entries(incomeByCategory).map(([category, amount]) => ({ category, amount })),
      expenseByCategory: Object.entries(expenseByCategory).map(([category, amount]) => ({ category, amount })),
      generatedAt: new Date().toISOString(),
    };
  }

  // Financial Statements
  public getFinancialStatements(): FinancialStatement[] {
    return this.getItem<FinancialStatement[]>('financial_statements', INITIAL_FINANCIAL_STATEMENTS);
  }

  public addFinancialStatement(statement: FinancialStatement) {
    const list = this.getFinancialStatements();
    list.unshift(statement);
    this.setItem('financial_statements', list);
  }

  public updateFinancialStatement(updated: FinancialStatement) {
    const list = this.getFinancialStatements().map((s) => (s.id === updated.id ? updated : s));
    this.setItem('financial_statements', list);
    this.notify();
  }

  public deleteFinancialStatement(id: string) {
    const list = this.getFinancialStatements().filter((s) => s.id !== id);
    this.setItem('financial_statements', list);
    this.notify();
  }

  // Maintenance Reminders
  public getMaintenanceReminders(): MaintenanceReminder[] {
    return this.getItem<MaintenanceReminder[]>('maintenance_reminders', INITIAL_MAINTENANCE_REMINDERS);
  }

  public addMaintenanceReminder(reminder: MaintenanceReminder) {
    const list = this.getMaintenanceReminders();
    list.unshift(reminder);
    this.setItem('maintenance_reminders', list);

    this.addNotification({
      id: `notif_${Date.now()}`,
      title: 'Maintenance Reminder',
      message: `${reminder.reminderType} due for ${reminder.vehicleModel} (${reminder.vin}) on ${reminder.dueDate}.`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
      category: 'Service',
      read: false,
      actionUrl: 'service',
    });

    this.logAudit({
      userId: reminder.customerId,
      userName: reminder.customerName,
      role: 'Customer',
      action: 'MAINTENANCE_REMINDER_CREATED',
      module: 'Service Management',
      targetId: reminder.reminderRef,
    });
  }

  public updateMaintenanceReminder(updated: MaintenanceReminder) {
    const list = this.getMaintenanceReminders().map((r) => (r.id === updated.id ? updated : r));
    this.setItem('maintenance_reminders', list);
    this.notify();
  }

  public deleteMaintenanceReminder(id: string) {
    const list = this.getMaintenanceReminders().filter((r) => r.id !== id);
    this.setItem('maintenance_reminders', list);
    this.notify();
  }

  // Technicians
  public getTechnicians(): Technician[] {
    return this.getItem<Technician[]>('technicians', INITIAL_TECHNICIANS);
  }

  public addTechnician(tech: Technician) {
    const list = this.getTechnicians();
    list.push(tech);
    this.setItem('technicians', list);
  }

  public updateTechnician(updated: Technician) {
    const list = this.getTechnicians().map((t) => (t.id === updated.id ? updated : t));
    this.setItem('technicians', list);
  }

  public deleteTechnician(id: string) {
    const list = this.getTechnicians().filter((t) => t.id !== id);
    this.setItem('technicians', list);
  }
}

// Helper for formatting price in db notifications
function formatPrice(amount: number): string {
  return new Intl.NumberFormat('en-PK', { style: 'currency', currency: 'PKR' }).format(amount);
}

export const db = new DatabaseService();
