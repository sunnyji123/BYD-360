import React, { useState, useEffect, useCallback } from 'react';
import {
  Layers,
  Shield,
  Lock,
  Mail,
  KeyRound,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Car,
  Users,
  Calendar,
  FileText,
  Upload,
  Download,
  DollarSign,
  Bell,
  HelpCircle,
  Building2,
  LogOut,
  Monitor,
  History,
  Trash2,
  Plus,
  FileCheck,
  Award,
  Activity,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { db } from '../../services/db';
import { Vehicle, OwnershipTransferRequest } from '../../types';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { DealershipManagementHub } from './DealershipManagementHub';

type DealerAuthStep = 'login' | 'register' | 'verify-email' | 'verify-2fa' | 'forgot-password';
type DealerDashTab =
  | 'overview'
  | 'dealership-hub'
  | 'profile'
  | 'inventory'
  | 'crm'
  | 'bookings'
  | 'commissions'
  | 'documents'
  | 'reports'
  | 'support'
  | 'security';

export const DealerPortal: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, formatPrice } = useApp();

  // ---------------- Auth Gate State ----------------
  const [authStep, setAuthStep] = useState<DealerAuthStep>('login');
  const [approvedCompanies, setApprovedCompanies] = useState<Array<{ id: string; name: string; country: string; city: string }>>([]);
  const [authError, setAuthError] = useState('');
  const [authNotice, setAuthNotice] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginDealerCodeCheck, setLoginDealerCodeCheck] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Registration application state
  const [regBusinessName, setRegBusinessName] = useState('');
  const [regOwnerName, setRegOwnerName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regMobile, setRegMobile] = useState('+92 300 ');
  const [regPassword, setRegPassword] = useState('');
  const [regCompanyId, setRegCompanyId] = useState('comp_byd_pk');
  const [regCountryId, setRegCountryId] = useState('PK');
  const [regCity, setRegCity] = useState('Karachi');
  const [regAddress, setRegAddress] = useState('');
  const [regCategory, setRegCategory] = useState('Authorized EV Reseller');
  const [regRegistrationNo, setRegRegistrationNo] = useState('');
  const [regTaxNtn, setRegTaxNtn] = useState('');
  const [reg2faProvision, setReg2faProvision] = useState<{ totpSecret: string; recoveryCodes: string[]; dealerCode: string } | null>(null);

  // Verification / 2FA state
  const [pendingEmail, setPendingEmail] = useState('');
  const [verifyOtpCode, setVerifyOtpCode] = useState('');
  const [devEmailOutbox, setDevEmailOutbox] = useState<string | null>(null);
  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [dev2faOutbox, setDev2faOutbox] = useState<string | null>(null);
  const [suspiciousBanner, setSuspiciousBanner] = useState(false);

  // Forgot / Reset password state
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [resetOtpCode, setResetOtpCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetOutboxHint, setResetOutboxHint] = useState<{ resetToken: string; otpCode: string } | null>(null);

  // ---------------- Authenticated Dealer Workspace State ----------------
  const [dashTab, setDashTab] = useState<DealerDashTab>('overview');
  const [loadingWorkspace, setLoadingWorkspace] = useState(false);
  const [workspaceError, setWorkspaceError] = useState('');
  const [workspaceSuccess, setWorkspaceSuccess] = useState('');

  const [dashboardData, setDashboardData] = useState<any>(null);
  const [profileData, setProfileData] = useState<any>(null);
  const [inventoryList, setInventoryList] = useState<any[]>([]);
  const [canViewVin, setCanViewVin] = useState(true);
  const [customersList, setCustomersList] = useState<any[]>([]);
  const [bookingsList, setBookingsList] = useState<any[]>([]);
  const [salesList, setSalesList] = useState<any[]>([]);
  const [commissionsData, setCommissionsData] = useState<{ commissions: any[]; summary: any }>({ commissions: [], summary: {} });
  const [documentsList, setDocumentsList] = useState<any[]>([]);
  const [notificationsList, setNotificationsList] = useState<any[]>([]);
  const [supportList, setSupportList] = useState<any[]>([]);
  const [reportData, setReportData] = useState<any>(null);
  const [sessionsList, setSessionsList] = useState<any[]>([]);
  const [loginHistoryList, setLoginHistoryList] = useState<any[]>([]);
  const [auditLogsList, setAuditLogsList] = useState<any[]>([]);

  // Profile edit form
  const [profBusinessName, setProfBusinessName] = useState('');
  const [profOwnerContact, setProfOwnerContact] = useState('');
  const [profMobile, setProfMobile] = useState('');
  const [profAddress, setProfAddress] = useState('');
  const [profCity, setProfCity] = useState('');
  const [profWebsite, setProfWebsite] = useState('');
  const [profNotes, setProfNotes] = useState('');
  const [profBankName, setProfBankName] = useState('');
  const [profBankTitle, setProfBankTitle] = useState('');
  const [profBankIban, setProfBankIban] = useState('');
  const [profLogoFile, setProfLogoFile] = useState<File | null>(null);

  // CRM form
  const [crmName, setCrmName] = useState('');
  const [crmPhone, setCrmPhone] = useState('+92 300 ');
  const [crmEmail, setCrmEmail] = useState('');
  const [crmModel, setCrmModel] = useState('BYD Sealion 6');
  const [crmRequirements, setCrmRequirements] = useState('');
  const [crmFollowUpDate, setCrmFollowUpDate] = useState('');
  const [crmAppointmentDate, setCrmAppointmentDate] = useState('');
  const [crmTestDrive, setCrmTestDrive] = useState(false);
  const [crmNoteCustomerId, setCrmNoteCustomerId] = useState<string | null>(null);
  const [crmNoteText, setCrmNoteText] = useState('');

  // Booking form
  const [bkCustomerId, setBkCustomerId] = useState('');
  const [bkInventoryId, setBkInventoryId] = useState('');
  const [bkNotes, setBkNotes] = useState('');
  const [bkFile, setBkFile] = useState<File | null>(null);

  // Document upload form
  const [docType, setDocType] = useState('Business Registration');
  const [docTitle, setDocTitle] = useState('');
  const [docFile, setDocFile] = useState<File | null>(null);

  // Support form
  const [supCategory, setSupCategory] = useState('Stock & Delivery');
  const [supPriority, setSupPriority] = useState('Medium');
  const [supSubject, setSupSubject] = useState('');
  const [supDescription, setSupDescription] = useState('');

  // Ownership transfer sub-panel (preserved inside Security & Transfers tab)
  const [transfers, setTransfers] = useState<OwnershipTransferRequest[]>([]);
  const [localVehicles, setLocalVehicles] = useState<Vehicle[]>([]);
  const [trfVin, setTrfVin] = useState('');
  const [trfBuyerName, setTrfBuyerName] = useState('');
  const [trfBuyerEmail, setTrfBuyerEmail] = useState('');
  const [trfBuyerPhone, setTrfBuyerPhone] = useState('+92 300 ');
  const [trfAmount, setTrfAmount] = useState(14500000);

  const isDealerSession = isAuthenticated && currentUser.subjectType === 'dealer';

  useEffect(() => {
    api
      .getDealerAuthStatus()
      .then((res) => {
        setApprovedCompanies(res.approvedCompanies || []);
        if (res.approvedCompanies?.[0]?.id) {
          setRegCompanyId(res.approvedCompanies[0].id);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const syncLocal = () => {
      setTransfers(db.getOwnershipTransfers());
      const vList = db.getVehicles();
      setLocalVehicles(vList);
      if (vList[0]?.vin && !trfVin) setTrfVin(vList[0].vin);
    };
    syncLocal();
    const unsub = db.subscribe(syncLocal);
    return () => unsub();
  }, [trfVin]);

  const loadWorkspaceTab = useCallback(
    async (tab: DealerDashTab) => {
      if (!isDealerSession) return;
      setLoadingWorkspace(true);
      setWorkspaceError('');
      try {
        if (tab === 'overview') {
          const d = await api.getDealerDashboard();
          setDashboardData(d);
        } else if (tab === 'profile') {
          const { profile } = await api.getDealerProfile();
          setProfileData(profile);
          setProfBusinessName(profile.businessName || '');
          setProfOwnerContact(profile.ownerContactName || '');
          setProfMobile(profile.mobile || '');
          setProfAddress(profile.businessAddress || '');
          setProfCity(profile.city || '');
          setProfWebsite(profile.website || '');
          setProfNotes(profile.notes || '');
          setProfBankName(profile.bankName || '');
          setProfBankTitle(profile.bankAccountTitle || '');
          setProfBankIban(profile.bankIbanMasked || '');
        } else if (tab === 'inventory') {
          const res = await api.getDealerInventory();
          setInventoryList(res.vehicles || []);
          setCanViewVin(res.canViewVin);
        } else if (tab === 'crm') {
          const res = await api.getDealerCustomers();
          setCustomersList(res.customers || []);
        } else if (tab === 'bookings') {
          const [bk, sl, cs, inv] = await Promise.all([
            api.getDealerBookings(),
            api.getDealerSales(),
            api.getDealerCustomers(),
            api.getDealerInventory(),
          ]);
          setBookingsList(bk.bookings || []);
          setSalesList(sl.sales || []);
          setCustomersList(cs.customers || []);
          setInventoryList(inv.vehicles || []);
        } else if (tab === 'commissions') {
          const res = await api.getDealerCommissions();
          setCommissionsData(res);
        } else if (tab === 'documents') {
          const res = await api.getDealerDocuments();
          setDocumentsList(res.documents || []);
        } else if (tab === 'reports') {
          const res = await api.getDealerReports();
          setReportData(res.report);
        } else if (tab === 'support') {
          const [cm, sp] = await Promise.all([api.getDealerCommunications(), api.getDealerSupportRequests()]);
          setNotificationsList(cm.notifications || []);
          setSupportList(sp.supportRequests || []);
        } else if (tab === 'security') {
          const [ss, al] = await Promise.all([api.getDealerSessions(), api.getDealerAuditLogs()]);
          setSessionsList(ss.sessions || []);
          setAuditLogsList(al.logs || []);
          setLoginHistoryList(al.loginHistory || []);
        }
      } catch (err: any) {
        setWorkspaceError(err?.message || 'Unable to load dealer module.');
      } finally {
        setLoadingWorkspace(false);
      }
    },
    [isDealerSession]
  );

  useEffect(() => {
    if (isDealerSession) {
      loadWorkspaceTab(dashTab);
    }
  }, [isDealerSession, dashTab, loadWorkspaceTab]);

  // ---------------- Auth Handlers ----------------
  const handleDealerSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthNotice('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerLogin({
        identifier: loginIdentifier.trim(),
        password: loginPassword,
        dealerCodeCheck: loginDealerCodeCheck.trim() || undefined,
      });
      setLoginPassword('');
      if (res.requiresEmailVerification) {
        setPendingEmail(res.email || loginIdentifier.trim());
        setDevEmailOutbox(res.verificationOutbox?.code || null);
        setAuthNotice(res.message || 'Email verification OTP sent.');
        setAuthStep('verify-email');
      } else if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setDev2faOutbox(res.otpOutbox?.code || null);
        setSuspiciousBanner(Boolean(res.suspiciousIpDetected));
        setAuthNotice(res.message || 'Enter your 6-digit Authenticator TOTP or Email OTP.');
        setAuthStep('verify-2fa');
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Dealer login failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleDealerApply = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthNotice('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerRegister({
        businessName: regBusinessName.trim(),
        ownerContactName: regOwnerName.trim(),
        email: regEmail.trim(),
        mobile: regMobile.trim(),
        password: regPassword,
        companyId: regCompanyId,
        countryId: regCountryId,
        city: regCity.trim(),
        businessAddress: regAddress.trim(),
        category: regCategory,
        registrationNo: regRegistrationNo.trim(),
        taxIdNtn: regTaxNtn.trim(),
      });
      setPendingEmail(res.dealer.email);
      setDevEmailOutbox(res.verificationOutbox?.code || null);
      if (res.twoFactorProvisioned) {
        setReg2faProvision({
          totpSecret: res.twoFactorProvisioned.totpSecret,
          recoveryCodes: res.twoFactorProvisioned.recoveryCodes,
          dealerCode: res.dealer.dealerCode,
        });
      }
      setAuthNotice(res.message);
      setAuthStep('verify-email');
      setRegPassword('');
    } catch (err: any) {
      setAuthError(err?.message || 'Dealer application submission failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleDealerVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerVerifyEmail({
        email: pendingEmail,
        code: verifyOtpCode.trim(),
      });
      setVerifyOtpCode('');
      if (res.requiresAdminApproval) {
        setAuthNotice(res.message);
        setAuthStep('login');
        setLoginIdentifier(res.email);
      } else if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setDev2faOutbox(res.otpOutbox?.code || null);
        setAuthNotice(res.message);
        setAuthStep('verify-2fa');
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Email verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleDealerVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerVerify2FA({
        challengeToken,
        code: twoFactorCode.trim(),
      });
      setTwoFactorCode('');
      setChallengeToken('');
      loginUser(res.user);
    } catch (err: any) {
      setAuthError(err?.message || '2FA verification failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgotPasswordRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerForgotPassword(forgotEmail.trim());
      setAuthNotice(res.message);
      if (res.resetOutbox) {
        setResetOutboxHint({ resetToken: res.resetOutbox.resetToken, otpCode: res.resetOutbox.otpCode });
        setResetToken(res.resetOutbox.resetToken);
      }
    } catch (err: any) {
      setAuthError(err?.message || 'Could not request dealer password reset.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const res = await api.dealerResetPassword({
        token: resetToken.trim() || undefined,
        email: forgotEmail.trim() || undefined,
        otpCode: resetOtpCode.trim() || undefined,
        newPassword: resetNewPassword,
      });
      setAuthNotice(res.message);
      setResetNewPassword('');
      setResetToken('');
      setResetOtpCode('');
      setResetOutboxHint(null);
      setAuthStep('login');
    } catch (err: any) {
      setAuthError(err?.message || 'Password reset failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const flashSuccess = (msg: string) => {
    setWorkspaceSuccess(msg);
    setTimeout(() => setWorkspaceSuccess(''), 5000);
  };

  // ---------------- Dedicated Unauthenticated / Non-Dealer Gate ----------------
  if (!isDealerSession) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4 space-y-6">
        <div className="rounded-2xl bg-slate-900 border border-blue-500/30 p-6 sm:p-8 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Layers className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-blue-400">
                  BYD PAKISTAN 360 • Separate Dealer Network Portal
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-white">Authorized Dealer Login Portal</h1>
                <p className="text-xs text-slate-400">
                  Isolated authentication for approved dealerships &amp; EV resellers • Founder &amp; CEO: Intekhab Alam
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'login', label: 'Dealer Sign In' },
                { id: 'register', label: 'Apply as Dealer' },
                { id: 'forgot-password', label: 'Reset Password' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setAuthStep(t.id as DealerAuthStep);
                    setAuthError('');
                    setAuthNotice('');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    authStep === t.id
                      ? 'bg-blue-500 text-slate-950'
                      : 'bg-slate-950 text-slate-300 border border-slate-800 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {isAuthenticated && currentUser.subjectType !== 'dealer' && (
            <div className="mt-4 p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between gap-3">
              <span>
                You are currently signed in as <strong>{currentUser.role}</strong> ({currentUser.email}). Dealer accounts are strictly separated from corporate &amp; customer sessions.
              </span>
              <button
                type="button"
                onClick={logoutUser}
                className="px-3 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold shrink-0"
              >
                Sign Out First
              </button>
            </div>
          )}

          {authError && (
            <div className="mt-4 p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}
          {authNotice && (
            <div className="mt-4 p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{authNotice}</span>
            </div>
          )}

          {authStep === 'login' && (
            <form onSubmit={handleDealerSignIn} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Registered Email or Unique Dealer ID
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="dealer@showroom.com or DLR-PK-KHI-01"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Confirm Dealer ID (Optional Extra Check)
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={loginDealerCodeCheck}
                      onChange={(e) => setLoginDealerCodeCheck(e.target.value)}
                      placeholder="e.g. DLR-PK-KHI-01"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">Dealer Account Password</label>
                  <button
                    type="button"
                    onClick={() => setAuthStep('forgot-password')}
                    className="text-xs text-blue-400 hover:text-blue-300"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter private dealer password"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:border-blue-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-blue-600/20 disabled:opacity-50"
              >
                {authSubmitting ? 'Verifying Dealer Credentials...' : 'Verify Credentials & Continue to 2FA'}
              </button>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="font-bold text-slate-300 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-blue-400" />
                  <span>Dealer Governance &amp; Security Policy</span>
                </div>
                <p>
                  Only administrator-approved dealers with verified email and mandatory Two-Factor Authentication may access inventory, private customer CRM, bookings, and commission statements. No hardcoded passwords are displayed.
                </p>
              </div>
            </form>
          )}

          {authStep === 'register' && (
            <form onSubmit={handleDealerApply} className="mt-6 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-800/40 text-blue-200">
                Public dealer applications remain locked as <strong>Pending Approval</strong> until reviewed and activated by an authorized BYD administrator.
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Dealership Business Name"
                  value={regBusinessName}
                  onChange={(e) => setRegBusinessName(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  required
                  placeholder="Authorized Owner / Contact Name"
                  value={regOwnerName}
                  onChange={(e) => setRegOwnerName(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="email"
                  required
                  placeholder="Official Business Email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="tel"
                  required
                  placeholder="Mobile (+92...)"
                  value={regMobile}
                  onChange={(e) => setRegMobile(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <select
                  value={regCategory}
                  onChange={(e) => setRegCategory(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="3S Flagship Centre">3S Flagship Centre</option>
                  <option value="2S Service Facility">2S Service Facility</option>
                  <option value="Retail Experience Studio">Retail Experience Studio</option>
                  <option value="Authorized EV Reseller">Authorized EV Reseller</option>
                </select>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select
                  value={regCompanyId}
                  onChange={(e) => setRegCompanyId(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  {approvedCompanies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.country})
                    </option>
                  ))}
                </select>
                <select
                  value={regCountryId}
                  onChange={(e) => setRegCountryId(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                >
                  <option value="PK">Pakistan (PK)</option>
                  <option value="AE">UAE (AE)</option>
                  <option value="SA">Saudi Arabia (SA)</option>
                  <option value="GB">United Kingdom (GB)</option>
                  <option value="DE">Germany (DE)</option>
                </select>
                <input
                  type="text"
                  required
                  placeholder="City"
                  value={regCity}
                  onChange={(e) => setRegCity(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="text"
                required
                placeholder="Showroom Street Address"
                value={regAddress}
                onChange={(e) => setRegAddress(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Business Registration Number"
                  value={regRegistrationNo}
                  onChange={(e) => setRegRegistrationNo(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Tax ID / NTN / TRN"
                  value={regTaxNtn}
                  onChange={(e) => setRegTaxNtn(e.target.value)}
                  className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
              </div>
              <input
                type="password"
                required
                placeholder="Create Strong Password (10+ chars, Upper/Lower/Digit/Symbol)"
                value={regPassword}
                onChange={(e) => setRegPassword(e.target.value)}
                className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
              />
              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
              >
                {authSubmitting ? 'Submitting Dealer Application...' : 'Submit Dealer Application for Admin Review'}
              </button>
            </form>
          )}

          {authStep === 'verify-email' && (
            <form onSubmit={handleDealerVerifyEmail} className="mt-6 space-y-4 text-xs">
              {reg2faProvision && (
                <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-2">
                  <div className="font-bold text-amber-300">
                    Assigned Dealer Application ID: {reg2faProvision.dealerCode}
                  </div>
                  <div className="text-slate-300">
                    Save your 2FA Authenticator TOTP Secret: <code className="font-mono text-cyan-300">{reg2faProvision.totpSecret}</code>
                  </div>
                  <div className="text-slate-400">
                    Recovery Codes: <span className="font-mono text-slate-200">{reg2faProvision.recoveryCodes.join(' • ')}</span>
                  </div>
                </div>
              )}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-bold text-white">Verify Email Address ({pendingEmail})</div>
                {devEmailOutbox && (
                  <p className="text-amber-300 font-mono">
                    Dev Mailer Outbox OTP: <strong>{devEmailOutbox}</strong>
                  </p>
                )}
              </div>
              <input
                type="text"
                required
                maxLength={6}
                value={verifyOtpCode}
                onChange={(e) => setVerifyOtpCode(e.target.value)}
                placeholder="Enter 6-digit Email Verification OTP"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
              />
              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
              >
                {authSubmitting ? 'Verifying Email...' : 'Verify Email Code'}
              </button>
            </form>
          )}

          {authStep === 'verify-2fa' && (
            <form onSubmit={handleDealerVerify2FA} className="mt-6 space-y-4 text-xs">
              {suspiciousBanner && (
                <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 text-amber-200">
                  Suspicious login alert: New client IP address detected for this Dealer ID. Complete mandatory 2FA to unlock session.
                </div>
              )}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-bold text-white">Mandatory Dealer Two-Factor Authentication</div>
                <p className="text-slate-400">Enter your 6-digit Authenticator TOTP, single-use Login OTP, or backup recovery code.</p>
                {dev2faOutbox && (
                  <p className="text-amber-300 font-mono pt-1">
                    Dev 2FA Email OTP Outbox: <strong>{dev2faOutbox}</strong>
                  </p>
                )}
              </div>
              <input
                type="text"
                required
                value={twoFactorCode}
                onChange={(e) => setTwoFactorCode(e.target.value)}
                placeholder="6-digit OTP / TOTP or XXXX-XXXX"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-blue-300"
              />
              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                {authSubmitting ? 'Unlocking Dealer Portal...' : 'Complete 2FA & Open Dealer Dashboard'}
              </button>
            </form>
          )}

          {authStep === 'forgot-password' && (
            <div className="mt-6 space-y-4 text-xs">
              <form onSubmit={handleForgotPasswordRequest} className="space-y-3">
                <label className="block font-semibold text-slate-300">Request Dealer Password Reset</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="Dealer Email or Dealer ID (DLR-...)"
                    className="flex-1 rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                  />
                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold whitespace-nowrap"
                  >
                    Send Reset Code
                  </button>
                </div>
              </form>

              {resetOutboxHint && (
                <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-amber-300 font-mono">
                  Dev Outbox — Reset Token: {resetOutboxHint.resetToken} | OTP: {resetOutboxHint.otpCode}
                </div>
              )}

              <form onSubmit={handleResetPasswordSubmit} className="space-y-3 pt-2 border-t border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    placeholder="Reset Token"
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                  <input
                    type="text"
                    value={resetOtpCode}
                    onChange={(e) => setResetOtpCode(e.target.value)}
                    placeholder="Or 6-digit OTP"
                    className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                </div>
                <input
                  type="password"
                  required
                  value={resetNewPassword}
                  onChange={(e) => setResetNewPassword(e.target.value)}
                  placeholder="New Strong Password (revokes all previous sessions)"
                  className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white"
                />
                <button
                  type="submit"
                  disabled={authSubmitting}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  Confirm Password Reset &amp; Revoke Old Sessions
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ---------------- Authenticated Private Dealer Workspace ----------------
  const dInfo = dashboardData?.dealer;
  const dSummary = dashboardData?.summary || {};
  const availableVehicles = inventoryList.filter((v) => v.availability_status === 'Available' || v.availability_status === 'Reserved');

  return (
    <div className="space-y-6 pb-12">
      {/* Dealer Workspace Header */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-blue-500/15 border border-blue-500/30 text-[10px] font-bold uppercase tracking-wider text-blue-300 font-mono">
              {currentUser.dealerCode || dInfo?.dealerCode}
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-[10px] font-bold uppercase text-emerald-300">
              {currentUser.verificationStatus || dInfo?.verificationStatus || 'Verified'}
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-semibold text-slate-300">
              {currentUser.dealerCategory || dInfo?.category || 'Authorized Dealer'}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            {dInfo?.businessName || currentUser.fullName}
          </h2>
          <p className="text-xs text-slate-400">
            {dInfo?.companyName || 'BYD Pakistan'} • {dInfo?.countryName || currentUser.country} • {dInfo?.branchName || currentUser.city} • Founder &amp; CEO: Intekhab Alam
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => loadWorkspaceTab(dashTab)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white"
          >
            Refresh Data
          </button>
          <button
            type="button"
            onClick={logoutUser}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-950/70 border border-rose-700/60 text-xs font-bold text-rose-200 hover:bg-rose-900"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-800 pb-3">
        {[
          { id: 'overview', label: 'Overview', icon: Layers },
          { id: 'dealership-hub', label: 'Showrooms, Targets & Invoices Hub', icon: Building2 },
          { id: 'profile', label: 'Profile & Bank', icon: Building2 },
          { id: 'inventory', label: 'Assigned Inventory', icon: Car },
          { id: 'crm', label: 'CRM & Test Drives', icon: Users },
          { id: 'bookings', label: 'Bookings & Sales', icon: Calendar },
          { id: 'commissions', label: 'Commissions', icon: DollarSign },
          { id: 'documents', label: 'Documents', icon: FileText },
          { id: 'reports', label: 'Reports (PDF/XLSX)', icon: Activity },
          { id: 'support', label: 'Notices & Support', icon: HelpCircle },
          { id: 'security', label: 'Security & Transfers', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = dashTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setDashTab(tab.id as DealerDashTab)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                active
                  ? 'bg-blue-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-300 border border-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {workspaceError && (
        <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{workspaceError}</span>
        </div>
      )}
      {workspaceSuccess && (
        <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{workspaceSuccess}</span>
        </div>
      )}

      {loadingWorkspace && (
        <div className="p-6 text-center text-xs text-slate-400">Loading private dealer workspace...</div>
      )}

      {/* TAB 1: OVERVIEW */}
      {dashTab === 'overview' && dInfo && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[11px] text-slate-400">Assigned Vehicles / Available</span>
              <p className="text-xl font-black text-white mt-1 tabular-nums">
                {dSummary.totalAssignedVehicles ?? 0} / <span className="text-emerald-400">{dSummary.availableStock ?? 0}</span>
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[11px] text-slate-400">Total Bookings (Pending)</span>
              <p className="text-xl font-black text-cyan-300 mt-1 tabular-nums">
                {dSummary.totalBookings ?? 0} ({dSummary.pendingBookings ?? 0})
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[11px] text-slate-400">Completed Sales / Inquiries</span>
              <p className="text-xl font-black text-white mt-1 tabular-nums">
                {dSummary.completedSales ?? 0} / {dSummary.customerInquiries ?? 0}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[11px] text-slate-400">Authorized Commissions (Paid)</span>
              <p className="text-xl font-black text-amber-300 mt-1 tabular-nums">
                {dSummary.paidCommissionPkr !== null ? formatPrice(dSummary.paidCommissionPkr) : 'Restricted'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-400" />
                <span>Announcements &amp; Operations Alerts ({dSummary.unreadNotifications || 0} unread)</span>
              </h3>
              <div className="space-y-2">
                {(dashboardData?.notifications || []).map((n: any) => (
                  <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-start justify-between gap-3">
                    <div>
                      <div className="font-bold text-white">{n.title}</div>
                      <p className="text-slate-400 mt-0.5">{n.message}</p>
                      <span className="text-[10px] text-slate-500">
                        From {n.sender_name} ({n.sender_role}) • {n.created_at?.slice(0, 16).replace('T', ' ')}
                      </span>
                    </div>
                    {!n.is_read && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.markDealerCommunicationRead(n.id);
                          loadWorkspaceTab('overview');
                        }}
                        className="px-2 py-1 rounded bg-slate-800 text-cyan-300 text-[10px] font-bold shrink-0"
                      >
                        Mark Read
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 text-xs">
              <h3 className="text-sm font-bold text-white">Dealer Registry Card</h3>
              <div className="space-y-2 text-slate-300">
                <div className="flex justify-between"><span className="text-slate-500">Dealer ID</span><span className="font-mono text-cyan-300">{dInfo.dealerCode}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Contact Owner</span><span>{dInfo.ownerContactName}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Assigned Manager</span><span>{dInfo.assignedManagerName}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Account Status</span><span className="text-emerald-400 font-bold">{dInfo.status}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Created</span><span className="tabular-nums">{dInfo.createdAt?.slice(0, 10)}</span></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PROFILE & BANK */}
      {dashTab === 'profile' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white">Dealership Profile &amp; Settlement Banking</h3>
              <p className="text-slate-400">
                Contact info updates immediately. Bank, NTN/registration, and category changes enter Pending Admin Approval.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(e) => setProfLogoFile(e.target.files?.[0] || null)}
                className="text-[11px] text-slate-400 max-w-[180px]"
              />
              <button
                type="button"
                onClick={async () => {
                  if (!profLogoFile) return;
                  await api.uploadDealerLogo(profLogoFile);
                  setProfLogoFile(null);
                  flashSuccess('Business logo stored in private vault.');
                  loadWorkspaceTab('profile');
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold"
              >
                Upload Logo
              </button>
            </div>
          </div>

          {profileData?.pendingChangeStatus === 'Pending Admin Approval' && (
            <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-amber-200">
              Pending Admin Approval: Requested sensitive updates ({Object.keys(profileData.pendingChanges || {}).join(', ')}) are queued for verification.
            </div>
          )}

          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.updateDealerProfile({
                  businessName: profBusinessName,
                  ownerContactName: profOwnerContact,
                  mobile: profMobile,
                  businessAddress: profAddress,
                  city: profCity,
                  website: profWebsite,
                  notes: profNotes,
                  bankName: profBankName,
                  bankAccountTitle: profBankTitle,
                  bankIbanMasked: profBankIban,
                });
                flashSuccess(res.message);
                loadWorkspaceTab('profile');
              } catch (err: any) {
                setWorkspaceError(err?.message || 'Profile update failed.');
              }
            }}
            className="space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">Business Name</label>
                <input value={profBusinessName} onChange={(e) => setProfBusinessName(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Owner / Contact Name</label>
                <input value={profOwnerContact} onChange={(e) => setProfOwnerContact(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Mobile Number</label>
                <input value={profMobile} onChange={(e) => setProfMobile(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 mb-1">City</label>
                <input value={profCity} onChange={(e) => setProfCity(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Showroom Address</label>
                <input value={profAddress} onChange={(e) => setProfAddress(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Website</label>
                <input value={profWebsite} onChange={(e) => setProfWebsite(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="font-bold text-amber-300">Settlement Banking (Changes require Admin Approval)</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input placeholder="Bank Name" value={profBankName} onChange={(e) => setProfBankName(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                <input placeholder="Account Title" value={profBankTitle} onChange={(e) => setProfBankTitle(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                <input placeholder="IBAN / Masked Account" value={profBankIban} onChange={(e) => setProfBankIban(e.target.value)} className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
              </div>
            </div>

            <button type="submit" className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Save Dealer Profile
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: ASSIGNED VEHICLE INVENTORY (READ-ONLY) */}
      {dashTab === 'inventory' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Assigned BYD Vehicle Stock</h3>
              <p className="text-slate-400">
                Read-only official allocation ({inventoryList.length} vehicles). Stock availability, VIN visibility ({canViewVin ? 'Authorized' : 'Redacted'}), and approved selling prices are controlled by HQ.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {inventoryList.map((v) => (
              <div key={v.id} className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col">
                {v.image_url && (
                  <img src={v.image_url} alt={v.model} className="w-full h-36 object-cover bg-slate-900" />
                )}
                <div className="p-4 space-y-2 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] text-cyan-300 font-bold">{v.stock_number}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        v.availability_status === 'Available'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : v.availability_status === 'Sold'
                          ? 'bg-slate-800 text-slate-300'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {v.availability_status}
                    </span>
                  </div>
                  <div className="text-sm font-black text-white">
                    {v.model} • {v.variant} ({v.model_year})
                  </div>
                  <div className="text-slate-400">
                    Ext: {v.exterior_color} | Int: {v.interior_color}
                  </div>
                  <div className="font-mono text-[11px] text-slate-300">VIN: {v.vin}</div>
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <span className="font-bold text-amber-300 tabular-nums">{formatPrice(v.approved_selling_price_pkr)}</span>
                    <span className="text-[10px] text-slate-400">{v.delivery_status}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: DEALER CRM */}
      {dashTab === 'crm' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await api.createDealerCustomer({
                  fullName: crmName,
                  phone: crmPhone,
                  email: crmEmail,
                  interestedModel: crmModel,
                  requirements: crmRequirements,
                  followUpDate: crmFollowUpDate || undefined,
                  appointmentDate: crmAppointmentDate || undefined,
                  requestTestDrive: crmTestDrive,
                });
                setCrmName('');
                setCrmEmail('');
                setCrmRequirements('');
                flashSuccess('Customer inquiry added to private Dealer CRM.');
                loadWorkspaceTab('crm');
              } catch (err: any) {
                setWorkspaceError(err?.message || 'Could not create customer inquiry.');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-400" />
              <span>Add Private Customer Inquiry</span>
            </h3>
            <input required placeholder="Customer Full Name" value={crmName} onChange={(e) => setCrmName(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <input required placeholder="Phone Number" value={crmPhone} onChange={(e) => setCrmPhone(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <input type="email" placeholder="Email Address" value={crmEmail} onChange={(e) => setCrmEmail(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <select value={crmModel} onChange={(e) => setCrmModel(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
              <option value="BYD Seal">BYD Seal</option>
              <option value="BYD Atto 3">BYD Atto 3</option>
              <option value="BYD Sealion 6">BYD Sealion 6</option>
              <option value="BYD Shark 6">BYD Shark 6</option>
              <option value="BYD Dolphin">BYD Dolphin</option>
            </select>
            <input placeholder="Requirements / Variant Notes" value={crmRequirements} onChange={(e) => setCrmRequirements(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400">Follow-Up Date</label>
                <input type="date" value={crmFollowUpDate} onChange={(e) => setCrmFollowUpDate(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-2 py-1.5 text-white" />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Appointment</label>
                <input type="date" value={crmAppointmentDate} onChange={(e) => setCrmAppointmentDate(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-2 py-1.5 text-white" />
              </div>
            </div>
            <label className="flex items-center gap-2 text-slate-300">
              <input type="checkbox" checked={crmTestDrive} onChange={(e) => setCrmTestDrive(e.target.checked)} />
              <span>Request Test Drive Session</span>
            </label>
            <button type="submit" className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Save Customer Inquiry
            </button>
          </form>

          <div className="lg:col-span-2 space-y-3">
            {customersList.map((c) => (
              <div key={c.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-sm font-bold text-white">{c.full_name}</span>{' '}
                    <span className="text-cyan-300 font-semibold">• {c.interested_model}</span>
                    <div className="text-slate-400">{c.phone} {c.email ? `• ${c.email}` : ''} • {c.city}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={c.inquiry_status}
                      onChange={async (e) => {
                        await api.updateDealerCustomer(c.id, { inquiryStatus: e.target.value });
                        loadWorkspaceTab('crm');
                      }}
                      className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-cyan-300 font-semibold"
                    >
                      <option value="New Inquiry">New Inquiry</option>
                      <option value="Contacted">Contacted</option>
                      <option value="Test Drive Requested">Test Drive Requested</option>
                      <option value="Appointment Scheduled">Appointment Scheduled</option>
                      <option value="Booking Submitted">Booking Submitted</option>
                      <option value="Closed">Closed</option>
                    </select>
                    <select
                      value={c.test_drive_status}
                      onChange={async (e) => {
                        await api.updateDealerCustomer(c.id, { testDriveStatus: e.target.value });
                        loadWorkspaceTab('crm');
                      }}
                      className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-emerald-300 font-semibold"
                    >
                      <option value="Not Requested">TD: None</option>
                      <option value="Requested">TD: Requested</option>
                      <option value="Scheduled">TD: Scheduled</option>
                      <option value="Completed">TD: Completed</option>
                    </select>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 space-y-1 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  {(c.communicationHistory || []).slice(-3).map((h: any, idx: number) => (
                    <div key={idx}>
                      <span className="text-slate-500">{h.at?.slice(0, 10)} [{h.channel}]:</span> {h.note}
                    </div>
                  ))}
                </div>

                {crmNoteCustomerId === c.id ? (
                  <div className="flex gap-2 pt-1">
                    <input
                      value={crmNoteText}
                      onChange={(e) => setCrmNoteText(e.target.value)}
                      placeholder="Add follow-up / call log note..."
                      className="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-2.5 py-1.5 text-white"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!crmNoteText.trim()) return;
                        await api.updateDealerCustomer(c.id, { communicationNote: crmNoteText });
                        setCrmNoteText('');
                        setCrmNoteCustomerId(null);
                        loadWorkspaceTab('crm');
                      }}
                      className="px-3 py-1 rounded-lg bg-blue-600 text-white font-bold"
                    >
                      Log Note
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setCrmNoteCustomerId(c.id)}
                    className="text-[11px] text-blue-400 hover:text-blue-300 font-semibold"
                  >
                    + Add Communication Log
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: BOOKINGS & VERIFIED SALES */}
      {dashTab === 'bookings' && (
        <div className="space-y-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await api.createDealerBooking({
                  customerId: bkCustomerId,
                  inventoryId: bkInventoryId,
                  notes: bkNotes,
                  file: bkFile,
                });
                setBkNotes('');
                setBkFile(null);
                flashSuccess('Customer booking submitted for Admin Approval & Payment Verification.');
                loadWorkspaceTab('bookings');
              } catch (err: any) {
                setWorkspaceError(err?.message || 'Booking submission failed.');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3"
          >
            <h3 className="text-sm font-bold text-white">Submit New Vehicle Booking Request</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <select required value={bkCustomerId} onChange={(e) => setBkCustomerId(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                <option value="">Select Private CRM Customer...</option>
                {customersList.map((c) => (
                  <option key={c.id} value={c.id}>{c.full_name} ({c.phone})</option>
                ))}
              </select>
              <select required value={bkInventoryId} onChange={(e) => setBkInventoryId(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
                <option value="">Select Available Assigned EV...</option>
                {availableVehicles.map((v) => (
                  <option key={v.id} value={v.id}>{v.stock_number} — {v.model} ({v.variant})</option>
                ))}
              </select>
              <input type="file" onChange={(e) => setBkFile(e.target.files?.[0] || null)} className="text-[11px] text-slate-300 py-1.5" />
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <input placeholder="Booking notes / customer token receipt ref..." value={bkNotes} onChange={(e) => setBkNotes(e.target.value)} className="flex-1 rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <button type="submit" className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
                Submit Booking Request
              </button>
            </div>
          </form>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Active Bookings ({bookingsList.length})</h3>
              {bookingsList.map((b) => (
                <div key={b.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-cyan-300">{b.booking_ref}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-amber-300">{b.booking_status}</span>
                  </div>
                  <div className="font-semibold text-white">{b.vehicle_model} • Customer: {b.customer_name}</div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="tabular-nums">{formatPrice(b.agreed_price_pkr)} • Payment: {b.payment_status}</span>
                    {b.booking_status === 'Pending Approval' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await api.cancelDealerBooking(b.id);
                          flashSuccess(`Cancelled booking ${b.booking_ref}.`);
                          loadWorkspaceTab('bookings');
                        }}
                        className="text-rose-300 hover:underline font-bold"
                      >
                        Cancel Pending
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white">Verified Completed Sales ({salesList.length})</h3>
              {salesList.map((s) => (
                <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-mono font-bold text-emerald-300">{s.sale_ref}</div>
                    <div className="font-semibold text-white">{s.vehicle_model} • {s.customer_name}</div>
                    <div className="text-slate-400 tabular-nums">
                      {formatPrice(s.sale_amount_pkr)} • {s.payment_status} • {s.delivery_status}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => api.downloadDealerSaleReceipt(s.id, s.sale_ref)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>PDF Receipt</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: COMMISSIONS & EARNINGS */}
      {dashTab === 'commissions' && (
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400">Authorized Rate</span>
              <p className="text-xl font-black text-white mt-1 tabular-nums">{commissionsData.summary?.assignedRatePct ?? 0}%</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400">Paid Commissions</span>
              <p className="text-xl font-black text-emerald-400 mt-1 tabular-nums">{formatPrice(commissionsData.summary?.paidPkr ?? 0)}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400">Approved (Unpaid)</span>
              <p className="text-xl font-black text-cyan-300 mt-1 tabular-nums">{formatPrice(commissionsData.summary?.approvedPkr ?? 0)}</p>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-400">Pending Approval</span>
              <p className="text-xl font-black text-amber-300 mt-1 tabular-nums">{formatPrice(commissionsData.summary?.pendingPkr ?? 0)}</p>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-x-auto">
            <table className="w-full text-left">
              <thead className="border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4">Sale Ref</th>
                  <th className="py-3 px-4">Vehicle</th>
                  <th className="py-3 px-4">Sale Value</th>
                  <th className="py-3 px-4">Rate</th>
                  <th className="py-3 px-4">Commission</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Payout Ref</th>
                </tr>
              </thead>
              <tbody>
                {commissionsData.commissions.map((c) => (
                  <tr key={c.id} className="border-b border-slate-800/60 text-slate-200">
                    <td className="py-3 px-4 font-mono text-cyan-300">{c.sale_ref || c.sale_id}</td>
                    <td className="py-3 px-4">{c.vehicle_model}</td>
                    <td className="py-3 px-4 tabular-nums">{formatPrice(c.sale_amount_pkr)}</td>
                    <td className="py-3 px-4 tabular-nums">{c.commission_rate_pct}%</td>
                    <td className="py-3 px-4 font-bold text-amber-300 tabular-nums">{formatPrice(c.commission_amount_pkr)}</td>
                    <td className="py-3 px-4 font-bold">{c.status}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{c.payout_reference || 'Pending Payout'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 7: PRIVATE DOCUMENTS VAULT */}
      {dashTab === 'documents' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!docFile) {
                setWorkspaceError('Please choose a file to upload.');
                return;
              }
              try {
                await api.uploadDealerDocument({ docType, title: docTitle || docFile.name, file: docFile });
                setDocTitle('');
                setDocFile(null);
                flashSuccess('Document stored in isolated dealer vault (Pending Verification).');
                loadWorkspaceTab('documents');
              } catch (err: any) {
                setWorkspaceError(err?.message || 'Document upload failed.');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-400" />
              <span>Upload Verification Document</span>
            </h3>
            <select value={docType} onChange={(e) => setDocType(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
              <option value="Business Registration">Business Registration</option>
              <option value="Tax Certificate">Tax Certificate</option>
              <option value="Bank Proof">Bank Settlement Proof</option>
              <option value="Agreement">Authorized Dealer Agreement</option>
              <option value="Booking Proof">Customer Booking Proof</option>
            </select>
            <input placeholder="Document Title" value={docTitle} onChange={(e) => setDocTitle(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <input type="file" onChange={(e) => setDocFile(e.target.files?.[0] || null)} className="w-full text-slate-300" />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Upload Secure Document
            </button>
          </form>

          <div className="lg:col-span-2 space-y-2.5">
            {documentsList.map((doc) => (
              <div key={doc.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                <div>
                  <div className="font-bold text-white">{doc.title}</div>
                  <div className="text-slate-400">
                    {doc.doc_type} • {doc.original_filename} • Status:{' '}
                    <span className={doc.verification_status === 'Verified' ? 'text-emerald-400 font-bold' : 'text-amber-300 font-bold'}>
                      {doc.verification_status}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => api.downloadDealerPrivateDoc(doc.id, doc.original_filename)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 8: REPORTS + REAL PDF / XLSX EXPORTS */}
      {dashTab === 'reports' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-bold text-white">Dealer Sales, Stock &amp; Commission Analytics</h3>
              <p className="text-slate-400">Real database aggregations with signed binary Excel (.xlsx) &amp; PDF (.pdf) reports.</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => api.downloadDealerReportExport('xlsx', currentUser.dealerCode || undefined)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Excel (.xlsx)</span>
              </button>
              <button
                type="button"
                onClick={() => api.downloadDealerReportExport('pdf', currentUser.dealerCode || undefined)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export PDF (.pdf)</span>
              </button>
            </div>
          </div>

          {reportData && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-bold text-white">Monthly Sales &amp; Delivery Summary</div>
                {(reportData.monthlySummary || []).map((m: any) => (
                  <div key={m.month} className="flex justify-between text-slate-300 tabular-nums">
                    <span>{m.month}</span>
                    <span>{m.salesCount} Sales ({m.deliveriesCount} Delivered)</span>
                    <span className="text-cyan-300 font-bold">{formatPrice(m.revenuePkr)}</span>
                  </div>
                ))}
              </div>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="font-bold text-white">Funnel &amp; Commission Totals</div>
                <div className="flex justify-between text-slate-300"><span>Customer Inquiries</span><span className="tabular-nums">{reportData.totals.customerInquiries}</span></div>
                <div className="flex justify-between text-slate-300"><span>Active Test Drives</span><span className="tabular-nums">{reportData.totals.activeTestDrives}</span></div>
                <div className="flex justify-between text-slate-300"><span>Completed Deliveries</span><span className="tabular-nums">{reportData.totals.completedDeliveries}</span></div>
                <div className="flex justify-between text-amber-300 font-bold"><span>Lifetime Commissions</span><span className="tabular-nums">{formatPrice(reportData.totals.lifetimeCommissionPkr)}</span></div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 9: COMMUNICATIONS & SUPPORT */}
      {dashTab === 'support' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await api.createDealerSupportRequest({
                  category: supCategory,
                  priority: supPriority,
                  subject: supSubject,
                  description: supDescription,
                });
                setSupSubject('');
                setSupDescription('');
                flashSuccess('Support request routed to assigned Manager.');
                loadWorkspaceTab('support');
              } catch (err: any) {
                setWorkspaceError(err?.message || 'Support request failed.');
              }
            }}
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 h-fit"
          >
            <h3 className="text-sm font-bold text-white">Submit Manager Support Ticket</h3>
            <select value={supCategory} onChange={(e) => setSupCategory(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
              <option value="Stock & Delivery">Stock &amp; Delivery Dispatch</option>
              <option value="Booking Approval">Booking / Payment Verification</option>
              <option value="Commission Query">Commission Statement</option>
              <option value="Technical Portal">Technical Support</option>
            </select>
            <select value={supPriority} onChange={(e) => setSupPriority(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white">
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
            <input required placeholder="Ticket Subject" value={supSubject} onChange={(e) => setSupSubject(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <textarea required rows={3} placeholder="Describe operational issue..." value={supDescription} onChange={(e) => setSupDescription(e.target.value)} className="w-full rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Send Request to Manager
            </button>
          </form>

          <div className="lg:col-span-2 space-y-4">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-2">
              <h3 className="text-sm font-bold text-white">Submitted Support Requests ({supportList.length})</h3>
              {supportList.map((sr) => (
                <div key={sr.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-cyan-300 font-bold">{sr.ticket_number}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-amber-300">{sr.status}</span>
                  </div>
                  <div className="font-bold text-white">{sr.subject}</div>
                  <div className="text-slate-400">{sr.description}</div>
                  <div className="text-[10px] text-slate-500">Assigned Manager: {sr.assigned_manager_name}</div>
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-2">
              <h3 className="text-sm font-bold text-white">Network Announcements ({notificationsList.length})</h3>
              {notificationsList.map((n) => (
                <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="font-bold text-white">{n.title}</div>
                  <div className="text-slate-400">{n.message}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 10: SECURITY, SESSIONS & OWNERSHIP TRANSFERS */}
      {dashTab === 'security' && (
        <div className="space-y-6 text-xs">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-blue-400" />
                <span>Active Dealer Sessions ({sessionsList.length})</span>
              </h3>
              {sessionsList.map((s) => (
                <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-white">
                      {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}
                    </div>
                    <div className="text-slate-400 font-mono text-[11px]">IP: {s.ip_address} • Expires: {s.expires_at?.slice(0, 19).replace('T', ' ')}</div>
                  </div>
                  {!s.is_current && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.revokeDealerSession(s.id);
                        loadWorkspaceTab('security');
                      }}
                      className="px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <span>Login History &amp; Audit Activity ({auditLogsList.length})</span>
              </h3>
              <div className="max-h-56 overflow-y-auto space-y-1.5">
                {loginHistoryList.map((h) => (
                  <div key={h.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-slate-300">{h.ip_address}</span>
                    <span className="text-slate-400">{h.created_at?.slice(0, 19).replace('T', ' ')}</span>
                    <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {h.success ? 'SUCCESS' : 'FAILED'}
                    </span>
                  </div>
                ))}
                {auditLogsList.slice(0, 12).map((l) => (
                  <div key={l.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="font-bold text-cyan-300">{l.action}</span>
                    <span className="text-slate-400 truncate max-w-[200px]">{l.details}</span>
                    <span className="text-slate-500">{l.created_at?.slice(11, 19)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <AccountSecurityCenter />

          {/* Preserved Vehicle Ownership Transfer Desk */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-cyan-400" />
              <span>Authorized Ownership Transfer Desk ({transfers.length} Applications)</span>
            </h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const veh = localVehicles.find((v) => v.vin === trfVin);
                if (!veh || !trfBuyerName || !trfBuyerEmail) return;
                db.addOwnershipTransfer({
                  id: `trf_${Date.now()}`,
                  transferRef: `TRF-PK-2026-${Math.floor(1000 + Math.random() * 9000)}`,
                  vin: veh.vin,
                  vehicleModel: veh.model,
                  licensePlate: veh.licensePlate,
                  dealershipId: currentUser.dealershipId || currentUser.dealerId || 'dlr_01',
                  dealershipName: currentUser.fullName || dashboardData?.dealer?.business_name || 'Authorized BYD Dealership',
                  previousOwnerId: veh.ownerId,
                  previousOwnerName: veh.ownerName,
                  previousOwnerPhone: veh.ownerPhone,
                  previousOwnerCnicOrId: '35202-*******-1',
                  newOwnerName: trfBuyerName,
                  newOwnerEmail: trfBuyerEmail,
                  newOwnerPhone: trfBuyerPhone,
                  newOwnerCnicOrId: '42101-*******-9',
                  newOwnerCity: currentUser.city || 'Karachi',
                  transferReason: 'Authorized Dealership Title Transfer',
                  saleAmountPkr: Number(trfAmount),
                  odometerAtTransferKm: veh.odometerKm,
                  documentsSubmitted: [
                    { docType: 'Invoice / Sale Deed', documentName: 'Transfer_Deed.pdf', verified: true },
                    { docType: 'Blade Battery Inspection Certificate', documentName: 'Battery_Scan.pdf', verified: true },
                  ],
                  status: 'Transfer Requested',
                  requestedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
                  requestedBy: `${currentUser.fullName} (${currentUser.dealerCode || 'Dealer'})`,
                  notes: 'Submitted via verified Dealer Portal.',
                });
                setTrfBuyerName('');
                setTrfBuyerEmail('');
                flashSuccess('Ownership transfer application submitted to Head Office.');
              }}
              className="grid grid-cols-1 md:grid-cols-5 gap-2"
            >
              <select value={trfVin} onChange={(e) => setTrfVin(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-2.5 py-2 text-white">
                {localVehicles.map((v) => (
                  <option key={v.id} value={v.vin}>{v.model} ({v.licensePlate})</option>
                ))}
              </select>
              <input required placeholder="Buyer Name" value={trfBuyerName} onChange={(e) => setTrfBuyerName(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <input required type="email" placeholder="Buyer Email" value={trfBuyerEmail} onChange={(e) => setTrfBuyerEmail(e.target.value)} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <input type="number" placeholder="Value PKR" value={trfAmount} onChange={(e) => setTrfAmount(Number(e.target.value))} className="rounded-xl bg-slate-950 border border-slate-700 px-3 py-2 text-white" />
              <button type="submit" className="rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 py-2">
                Submit Transfer
              </button>
            </form>
          </div>
        </div>
      )}

      {dashTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
