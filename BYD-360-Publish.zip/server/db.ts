import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export const PRIVATE_VERIFICATION_DOCS_DIR = path.resolve(DATA_DIR, 'private_verification_docs');
if (!fs.existsSync(PRIVATE_VERIFICATION_DOCS_DIR)) {
  fs.mkdirSync(PRIVATE_VERIFICATION_DOCS_DIR, { recursive: true, mode: 0o700 });
}

const DB_PATH = path.join(DATA_DIR, 'byd360.db');
export const sqlite = new Database(DB_PATH);
sqlite.pragma('journal_mode = WAL');
sqlite.pragma('foreign_keys = ON');

// ---------------------------------------------------------------------------
// Cryptographic Helpers (scrypt password hashing, tokens, HMAC, RFC-6238 TOTP)
// ---------------------------------------------------------------------------
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, keyHex] = storedHash.split(':');
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

export function sha256(input: string): string {
  return crypto.createHash('sha256').update(input).digest('hex');
}

export function generateSecureToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

export function generateNumericOtp(digits = 6): string {
  const max = Math.pow(10, digits);
  const min = Math.pow(10, digits - 1);
  return String(crypto.randomInt(min, max));
}

const COMMON_COMPROMISED_PASSWORDS = new Set([
  'password123!',
  'password@123',
  'p@ssw0rd123',
  'p@ssword123',
  'admin@1234',
  'admin@12345',
  'admin1234!',
  'welcome@123',
  'welcome123!',
  'qwerty@123',
  'qwerty123!',
  'qwerty@1234',
  'letmein@123',
  'letmein123!',
  'changeme@123',
  'changeme@1',
  '123456789a!',
  '1234567890a!',
  '12345678aa!',
  'test@123456',
  'pakistan@123',
]);

export function isCompromisedPassword(password: string): boolean {
  const lower = (password || '').trim().toLowerCase();
  if (!lower) return true;
  if (COMMON_COMPROMISED_PASSWORDS.has(lower)) return true;
  if (/(password|qwerty|12345678|87654321|admin123|letmein|iloveyou|p@ssw0rd|p@ssword)/i.test(lower)) {
    return true;
  }
  return false;
}

export function validatePasswordStrength(password: string): { valid: boolean; reason?: string } {
  if (!password || password.length < 10) {
    return { valid: false, reason: 'Password must be at least 10 characters long.' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one uppercase letter.' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one lowercase letter.' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one number.' };
  }
  if (!/[^A-Za-z0-9]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one special character.' };
  }
  if (isCompromisedPassword(password)) {
    return { valid: false, reason: 'This password appears on a common or compromised password list. Choose a unique passphrase.' };
  }
  return { valid: true };
}

export function normalizePhone(mobile: string): string {
  return String(mobile || '').replace(/[\s\-()]/g, '').trim();
}

// RFC-4648 Base32 encoding/decoding & RFC-6238 TOTP
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function generateTotpSecret(length = 20): string {
  const buf = crypto.randomBytes(length);
  let bits = 0;
  let value = 0;
  let output = '';
  for (let i = 0; i < buf.length; i++) {
    value = (value << 8) | buf[i];
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

function base32ToBuffer(base32: string): Buffer {
  const clean = base32.toUpperCase().replace(/=+$/, '').replace(/\s+/g, '');
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];
  for (const ch of clean) {
    const idx = BASE32_ALPHABET.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

export function generateTotpCode(secret: string, timeStepOffset = 0): string {
  const counter = Math.floor(Date.now() / 1000 / 30) + timeStepOffset;
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeBigUInt64BE(BigInt(counter), 0);
  const key = base32ToBuffer(secret);
  const hmac = crypto.createHmac('sha1', key).update(counterBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return String(code % 1000000).padStart(6, '0');
}

const MFA_KEY_FILE = path.join(DATA_DIR, '.mfa_key.hex');
let cachedMfaKey: Buffer | null = null;

function getMfaEncryptionKey(): Buffer {
  if (cachedMfaKey) return cachedMfaKey;
  const envKey = (process.env.MFA_ENCRYPTION_KEY || '').trim();
  if (envKey) {
    cachedMfaKey = crypto.createHash('sha256').update(envKey).digest();
    return cachedMfaKey;
  }
  try {
    if (fs.existsSync(MFA_KEY_FILE)) {
      const hex = fs.readFileSync(MFA_KEY_FILE, 'utf8').trim();
      if (/^[0-9a-f]{64}$/i.test(hex)) {
        cachedMfaKey = Buffer.from(hex, 'hex');
        return cachedMfaKey;
      }
    }
    const generated = crypto.randomBytes(32);
    fs.writeFileSync(MFA_KEY_FILE, generated.toString('hex'), { mode: 0o600 });
    cachedMfaKey = generated;
    return cachedMfaKey;
  } catch {
    cachedMfaKey = crypto.createHash('sha256').update(DB_PATH).digest();
    return cachedMfaKey;
  }
}

export function encrypt2faSecret(rawSecret: string): string {
  const trimmed = String(rawSecret || '').trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('enc:v1:')) return trimmed;
  const key = getMfaEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(trimmed, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

export function decrypt2faSecret(storedSecret: string): string {
  const trimmed = String(storedSecret || '').trim();
  if (!trimmed) return '';
  if (!trimmed.startsWith('enc:v1:')) {
    return trimmed;
  }
  const parts = trimmed.split(':');
  if (parts.length !== 5) return '';
  try {
    const iv = Buffer.from(parts[2], 'hex');
    const tag = Buffer.from(parts[3], 'hex');
    const ciphertext = Buffer.from(parts[4], 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', getMfaEncryptionKey(), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  } catch {
    return '';
  }
}

export function verifyTotpCode(secret: string, token: string): boolean {
  const clean = (token || '').trim();
  const plainSecret = decrypt2faSecret(secret);
  if (!/^\d{6}$/.test(clean) || !plainSecret) return false;
  for (let offset = -1; offset <= 1; offset++) {
    const expected = generateTotpCode(plainSecret, offset);
    if (crypto.timingSafeEqual(Buffer.from(clean), Buffer.from(expected))) {
      return true;
    }
  }
  return false;
}

export function parseUserAgentInfo(ua?: string | null): { deviceName: string; browserName: string } {
  const raw = String(ua || '').trim();
  if (!raw) return { deviceName: 'Desktop Workstation', browserName: 'Web Browser' };

  let browserName = 'Web Browser';
  if (/Edg\//i.test(raw)) browserName = 'Microsoft Edge';
  else if (/OPR\/|Opera/i.test(raw)) browserName = 'Opera';
  else if (/Chrome\//i.test(raw) && !/Chromium/i.test(raw)) browserName = 'Google Chrome';
  else if (/Firefox\//i.test(raw)) browserName = 'Mozilla Firefox';
  else if (/Safari\//i.test(raw) && !/Chrome\//i.test(raw)) browserName = 'Apple Safari';
  else if (/curl|node|undici|axios|fetch/i.test(raw)) browserName = 'API Client';

  let deviceName = 'Desktop Workstation';
  if (/iPhone/i.test(raw)) deviceName = 'iPhone (iOS)';
  else if (/iPad/i.test(raw)) deviceName = 'iPad (iPadOS)';
  else if (/Android/i.test(raw)) deviceName = 'Android Mobile';
  else if (/Macintosh|Mac OS X/i.test(raw)) deviceName = 'macOS Desktop';
  else if (/Windows NT/i.test(raw)) deviceName = 'Windows Desktop';
  else if (/Linux/i.test(raw)) deviceName = 'Linux Workstation';
  else if (/Mobile/i.test(raw)) deviceName = 'Mobile Device';

  return { deviceName, browserName };
}

export function nowIso(): string {
  return new Date().toISOString();
}

// ---------------------------------------------------------------------------
// Schema Creation
// ---------------------------------------------------------------------------
export function initializeDatabase() {
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS founder_accounts (
      id TEXT PRIMARY KEY,
      founder_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'Founder & CEO',
      account_type TEXT NOT NULL DEFAULT 'Primary Owner',
      access_level TEXT NOT NULL DEFAULT 'Global Owner',
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT NOT NULL,
      recovery_codes_json TEXT NOT NULL,
      is_verified INTEGER NOT NULL DEFAULT 1,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      last_login_at TEXT,
      last_login_ip TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS companies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      country TEXT NOT NULL,
      city TEXT NOT NULL,
      official_email TEXT NOT NULL UNIQUE,
      phone TEXT NOT NULL,
      address TEXT NOT NULL,
      registration_details TEXT NOT NULL,
      authorized_rep TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending Approval',
      ai_enabled INTEGER NOT NULL DEFAULT 1,
      ai_daily_limit INTEGER NOT NULL DEFAULT 250,
      approved_by TEXT,
      approved_at TEXT,
      rejection_reason TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS user_roles (
      id TEXT PRIMARY KEY,
      role_key TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      category TEXT NOT NULL,
      hierarchy_level INTEGER NOT NULL,
      permissions_json TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      company_id TEXT,
      username TEXT UNIQUE,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL DEFAULT 'Karachi',
      dealership_id TEXT,
      cnic_or_id TEXT,
      status TEXT NOT NULL DEFAULT 'Active',
      email_verified INTEGER NOT NULL DEFAULT 0,
      mobile_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 0,
      two_factor_secret TEXT,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      created_by TEXT,
      last_login_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS super_admin_accounts (
      id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL DEFAULT 'Karachi',
      status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Active' | 'Suspended'
      email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT NOT NULL,
      recovery_codes_json TEXT NOT NULL,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      authorized_by_founder_id TEXT NOT NULL,
      last_login_at TEXT,
      last_login_ip TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS role_permissions (
      id TEXT PRIMARY KEY,
      role_key TEXT NOT NULL,
      permission_key TEXT NOT NULL,
      description TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(role_key, permission_key)
    );

    CREATE TABLE IF NOT EXISTS company_admin_accounts (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      full_name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      designation TEXT NOT NULL DEFAULT 'Company Administrator',
      status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Active' | 'Suspended'
      email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT NOT NULL,
      recovery_codes_json TEXT NOT NULL,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      authorized_by TEXT NOT NULL,
      last_login_at TEXT,
      last_login_ip TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS company_user_roles (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      role_key TEXT NOT NULL,
      display_name TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT 'Head Office',
      permissions_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(company_id, role_key),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS company_permissions (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      subject_id TEXT NOT NULL,
      permissions_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, subject_id),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS company_branches (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL,
      address TEXT NOT NULL,
      manager_id TEXT,
      manager_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      monthly_target_units INTEGER NOT NULL DEFAULT 25,
      achieved_units INTEGER NOT NULL DEFAULT 0,
      monthly_revenue_pkr REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Active', -- 'Active' | 'Inactive'
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, code),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_accounts (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE,
      company_id TEXT NOT NULL,
      branch_id TEXT,
      employee_code TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL,
      department TEXT NOT NULL DEFAULT 'Operations',
      job_position TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active', -- 'Active' | 'Suspended' | 'On Leave'
      attendance_json TEXT NOT NULL DEFAULT '[]',
      leave_requests_json TEXT NOT NULL DEFAULT '[]',
      performance_score REAL NOT NULL DEFAULT 92.0,
      performance_notes TEXT,
      permissions_json TEXT NOT NULL DEFAULT '[]',
      joined_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, employee_code),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS company_activity_logs (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_crm_records (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      customer_id TEXT,
      customer_name TEXT NOT NULL,
      customer_email TEXT,
      customer_phone TEXT NOT NULL,
      record_type TEXT NOT NULL, -- 'Enquiry' | 'Complaint' | 'Feedback' | 'Follow-Up'
      subject TEXT NOT NULL,
      details TEXT NOT NULL,
      assigned_to TEXT,
      priority TEXT NOT NULL DEFAULT 'Medium',
      status TEXT NOT NULL DEFAULT 'Open', -- 'Open' | 'In Progress' | 'Resolved' | 'Closed'
      follow_up_date TEXT,
      resolution_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS user_permissions (
      user_id TEXT PRIMARY KEY,
      permissions_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS authentication_sessions (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL, -- 'founder' | 'super_admin' | 'user'
      company_id TEXT,
      role TEXT NOT NULL,
      ip_address TEXT,
      user_agent TEXT,
      device_label TEXT,
      two_factor_verified INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      last_activity_at TEXT NOT NULL,
      revoked INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS login_history (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      subject_type TEXT NOT NULL,
      identifier TEXT NOT NULL,
      role TEXT,
      company_id TEXT,
      success INTEGER NOT NULL,
      failure_reason TEXT,
      ip_address TEXT,
      user_agent TEXT,
      suspicious INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS security_events (
      id TEXT PRIMARY KEY,
      severity TEXT NOT NULL, -- 'INFO' | 'WARNING' | 'CRITICAL'
      event_type TEXT NOT NULL,
      user_id TEXT,
      identifier TEXT,
      company_id TEXT,
      details TEXT NOT NULL,
      ip_address TEXT,
      acknowledged INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS owner_audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      company_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_activity_logs (
      id TEXT PRIMARY KEY,
      admin_id TEXT NOT NULL,
      admin_name TEXT NOT NULL,
      admin_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS invitations (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      company_id TEXT NOT NULL,
      email TEXT NOT NULL,
      full_name TEXT NOT NULL,
      mobile TEXT,
      role TEXT NOT NULL,
      dealership_id TEXT,
      city TEXT NOT NULL DEFAULT 'Karachi',
      invited_by TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS otp_verifications (
      id TEXT PRIMARY KEY,
      identifier TEXT NOT NULL,
      purpose TEXT NOT NULL, -- 'email_verify' | '2fa_login' | 'founder_2fa' | 'password_reset'
      code_hash TEXT NOT NULL,
      subject_id TEXT,
      subject_type TEXT,
      expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      used_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS password_resets (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS super_admin_invitations (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      full_name TEXT NOT NULL,
      mobile TEXT,
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL DEFAULT 'Karachi',
      permissions_json TEXT NOT NULL,
      invited_by_founder_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL,
      updated_by TEXT,
      updated_at TEXT NOT NULL
    );

    -- Operational & Domain Tables (strictly company_id isolated)
    CREATE TABLE IF NOT EXISTS dealerships (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL,
      address TEXT NOT NULL,
      manager_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      facility_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Approved', -- 'Approved' | 'Pending Approval' | 'Rejected' | 'Suspended'
      active_techs INTEGER NOT NULL DEFAULT 6,
      service_bays INTEGER NOT NULL DEFAULT 4,
      monthly_target_units INTEGER NOT NULL DEFAULT 30,
      achieved_units INTEGER NOT NULL DEFAULT 22,
      monthly_revenue_pkr REAL NOT NULL DEFAULT 0,
      rating REAL NOT NULL DEFAULT 4.8,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vehicles (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      dealership_id TEXT,
      vin TEXT NOT NULL UNIQUE,
      chassis_number TEXT,
      model TEXT NOT NULL,
      variant TEXT NOT NULL,
      color TEXT NOT NULL,
      year INTEGER NOT NULL,
      license_plate TEXT NOT NULL,
      owner_id TEXT,
      owner_name TEXT,
      owner_phone TEXT,
      owner_city TEXT,
      registration_date TEXT,
      odometer_km INTEGER NOT NULL DEFAULT 0,
      battery_capacity_kwh REAL NOT NULL DEFAULT 82.5,
      battery_health_soh REAL NOT NULL DEFAULT 98.5,
      battery_health_soc REAL NOT NULL DEFAULT 82,
      battery_warranty_years INTEGER NOT NULL DEFAULT 8,
      vehicle_warranty_years INTEGER NOT NULL DEFAULT 6,
      warranty_expiry_date TEXT,
      last_service_date TEXT,
      next_service_due_km INTEGER NOT NULL DEFAULT 10000,
      status TEXT NOT NULL DEFAULT 'Active',
      dealership_purchased TEXT,
      sale_price_pkr REAL NOT NULL DEFAULT 14900000,
      sold_at TEXT,
      image_url TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      dealership_id TEXT,
      customer_id TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      booking_type TEXT NOT NULL, -- 'Test Drive' | 'Vehicle Reservation' | 'Service Appointment'
      vehicle_model TEXT NOT NULL,
      preferred_date TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      city TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      notes TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS service_jobs (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      ticket_number TEXT NOT NULL UNIQUE,
      vehicle_id TEXT NOT NULL,
      vin TEXT NOT NULL,
      model TEXT NOT NULL,
      license_plate TEXT NOT NULL,
      customer_id TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      dealership_id TEXT NOT NULL,
      dealership_name TEXT NOT NULL,
      service_type TEXT NOT NULL,
      scheduled_date TEXT NOT NULL,
      scheduled_time TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending Approval',
      technician_assigned TEXT,
      estimated_cost_pkr REAL NOT NULL DEFAULT 0,
      actual_cost_pkr REAL,
      customer_notes TEXT,
      technician_notes TEXT,
      checklist_json TEXT NOT NULL,
      parts_used_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS warranty_claims (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      claim_number TEXT NOT NULL UNIQUE,
      vin TEXT NOT NULL,
      vehicle_model TEXT NOT NULL,
      customer_id TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      dealership_name TEXT NOT NULL,
      component_category TEXT NOT NULL,
      issue_description TEXT NOT NULL,
      fault_code TEXT,
      submission_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Submitted',
      claim_amount_pkr REAL NOT NULL DEFAULT 0,
      approved_amount_pkr REAL,
      review_notes TEXT,
      attachments_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payments_invoices (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      invoice_number TEXT NOT NULL UNIQUE,
      customer_id TEXT,
      customer_name TEXT NOT NULL,
      country TEXT NOT NULL DEFAULT 'PK',
      currency TEXT NOT NULL DEFAULT 'PKR',
      dealership_name TEXT NOT NULL,
      item_category TEXT NOT NULL,
      subtotal REAL NOT NULL,
      tax_rate REAL NOT NULL,
      tax_amount REAL NOT NULL,
      total_amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'Paid',
      payment_gateway TEXT NOT NULL,
      transaction_ref TEXT NOT NULL,
      issued_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      company_id TEXT,
      user_id TEXT,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      category TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      action_url TEXT,
      created_at TEXT NOT NULL
    );

    -- BYD AI Persistence & Governance Tables
    CREATE TABLE IF NOT EXISTS ai_conversations (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      company_id TEXT,
      role TEXT NOT NULL,
      title TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      sender TEXT NOT NULL, -- 'user' | 'assistant'
      content TEXT NOT NULL,
      attachment_name TEXT,
      model_used TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ai_usage_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      company_id TEXT,
      role TEXT NOT NULL,
      endpoint TEXT NOT NULL,
      model TEXT NOT NULL,
      status TEXT NOT NULL, -- 'SUCCESS' | 'ERROR' | 'BLOCKED'
      error_message TEXT,
      prompt_chars INTEGER NOT NULL DEFAULT 0,
      response_chars INTEGER NOT NULL DEFAULT 0,
      estimated_cost_usd REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ai_pending_actions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      company_id TEXT,
      action_type TEXT NOT NULL,
      summary TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      confirmed INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS support_requests (
      id TEXT PRIMARY KEY,
      ticket_number TEXT NOT NULL UNIQUE,
      company_id TEXT,
      user_id TEXT,
      requester_name TEXT NOT NULL,
      requester_email TEXT NOT NULL,
      category TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Medium',
      subject TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Open', -- 'Open' | 'In Progress' | 'Resolved' | 'Closed'
      assigned_to TEXT,
      resolution_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    -- Country Management & Global Country Assignment Tables
    CREATE TABLE IF NOT EXISTS countries (
      id TEXT PRIMARY KEY, -- ISO code e.g. 'PK', 'AE', 'SA', 'GB', 'DE'
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      flag_emoji TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'PKR',
      legal_entity TEXT NOT NULL,
      timezone TEXT NOT NULL DEFAULT 'Asia/Karachi',
      headquarters_city TEXT NOT NULL,
      profile_json TEXT NOT NULL DEFAULT '{}',
      offices_json TEXT NOT NULL DEFAULT '[]',
      departments_json TEXT NOT NULL DEFAULT '[]',
      authorized_operations_json TEXT NOT NULL DEFAULT '[]',
      documents_json TEXT NOT NULL DEFAULT '[]',
      contacts_json TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS country_manager_accounts (
      id TEXT PRIMARY KEY,
      manager_code TEXT NOT NULL UNIQUE,
      country_id TEXT NOT NULL,
      full_name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      designation TEXT NOT NULL DEFAULT 'Country Manager',
      status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Active' | 'Suspended'
      email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT NOT NULL,
      recovery_codes_json TEXT NOT NULL,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      authorized_by TEXT NOT NULL,
      appointed_at TEXT NOT NULL,
      last_login_at TEXT,
      last_login_ip TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (country_id) REFERENCES countries(id)
    );

    CREATE TABLE IF NOT EXISTS country_assignments (
      id TEXT PRIMARY KEY,
      manager_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      country_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active', -- 'Active' | 'Reassigned' | 'Suspended' | 'Revoked'
      appointed_by TEXT NOT NULL,
      appointment_date TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (manager_id) REFERENCES country_manager_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (country_id) REFERENCES countries(id)
    );

    CREATE TABLE IF NOT EXISTS country_permissions (
      id TEXT PRIMARY KEY,
      manager_id TEXT NOT NULL UNIQUE,
      country_id TEXT NOT NULL,
      permissions_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (manager_id) REFERENCES country_manager_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS country_company_relationships (
      id TEXT PRIMARY KEY,
      country_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      relationship_type TEXT NOT NULL DEFAULT 'Authorized National Distributor',
      operational_status TEXT NOT NULL DEFAULT 'Active',
      performance_rating REAL NOT NULL DEFAULT 95.0,
      notes TEXT,
      updated_at TEXT NOT NULL,
      UNIQUE(country_id, company_id),
      FOREIGN KEY (country_id) REFERENCES countries(id),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS country_branches (
      id TEXT PRIMARY KEY,
      country_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      company_branch_id TEXT,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      city TEXT NOT NULL,
      address TEXT NOT NULL,
      manager_id TEXT,
      manager_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      monthly_target_units INTEGER NOT NULL DEFAULT 25,
      achieved_units INTEGER NOT NULL DEFAULT 0,
      monthly_revenue_pkr REAL NOT NULL DEFAULT 0,
      approval_status TEXT NOT NULL DEFAULT 'Approved', -- 'Approved' | 'Pending Approval' | 'Rejected'
      status TEXT NOT NULL DEFAULT 'Active',
      submitted_by TEXT,
      approved_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(country_id, code),
      FOREIGN KEY (country_id) REFERENCES countries(id),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS country_escalation_requests (
      id TEXT PRIMARY KEY,
      country_id TEXT NOT NULL,
      company_id TEXT,
      manager_id TEXT NOT NULL,
      manager_name TEXT NOT NULL,
      request_type TEXT NOT NULL,
      target_id TEXT,
      title TEXT NOT NULL,
      details TEXT NOT NULL,
      amount REAL,
      status TEXT NOT NULL DEFAULT 'Pending Founder Approval', -- 'Pending Founder Approval' | 'Approved' | 'Rejected'
      reviewed_by TEXT,
      review_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS country_activity_logs (
      id TEXT PRIMARY KEY,
      country_id TEXT NOT NULL,
      manager_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    -- Branch Manager & Branch Operations Architecture
    CREATE TABLE IF NOT EXISTS branches (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL DEFAULT 'PK',
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      city TEXT NOT NULL,
      address TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      manager_id TEXT,
      manager_name TEXT NOT NULL,
      working_hours_json TEXT NOT NULL DEFAULT '{}',
      departments_json TEXT NOT NULL DEFAULT '["Branch Management","Sales & Showroom","Aftersales & Workshop","Finance & Billing","Customer Relations"]',
      documents_json TEXT NOT NULL DEFAULT '[]',
      daily_operations_json TEXT NOT NULL DEFAULT '{}',
      announcements_json TEXT NOT NULL DEFAULT '[]',
      monthly_target_units INTEGER NOT NULL DEFAULT 25,
      achieved_units INTEGER NOT NULL DEFAULT 0,
      monthly_revenue_pkr REAL NOT NULL DEFAULT 0,
      approval_status TEXT NOT NULL DEFAULT 'Approved',
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, code),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (country_id) REFERENCES countries(id)
    );

    CREATE TABLE IF NOT EXISTS branch_manager_accounts (
      id TEXT PRIMARY KEY,
      manager_code TEXT NOT NULL UNIQUE,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT NOT NULL,
      full_name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      designation TEXT NOT NULL DEFAULT 'Branch Manager',
      status TEXT NOT NULL DEFAULT 'Pending Verification',
      email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT NOT NULL,
      recovery_codes_json TEXT NOT NULL,
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      authorized_by TEXT NOT NULL,
      appointed_at TEXT NOT NULL,
      last_login_at TEXT,
      last_login_ip TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (country_id) REFERENCES countries(id),
      FOREIGN KEY (branch_id) REFERENCES branches(id)
    );

    CREATE TABLE IF NOT EXISTS branch_assignments (
      id TEXT PRIMARY KEY,
      manager_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT NOT NULL,
      branch_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      appointed_by TEXT NOT NULL,
      appointment_date TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (manager_id) REFERENCES branch_manager_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (country_id) REFERENCES countries(id),
      FOREIGN KEY (branch_id) REFERENCES branches(id)
    );

    CREATE TABLE IF NOT EXISTS branch_permissions (
      id TEXT PRIMARY KEY,
      manager_id TEXT NOT NULL UNIQUE,
      branch_id TEXT NOT NULL,
      permissions_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (manager_id) REFERENCES branch_manager_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (branch_id) REFERENCES branches(id)
    );

    CREATE TABLE IF NOT EXISTS branch_employee_relationships (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      employee_id TEXT NOT NULL,
      employee_code TEXT NOT NULL,
      shift_schedule TEXT NOT NULL DEFAULT 'Mon-Sat 09:00-18:00',
      daily_task TEXT NOT NULL DEFAULT 'Branch daily EV customer & operational SLA duties',
      task_status TEXT NOT NULL DEFAULT 'In Progress',
      assigned_by TEXT,
      updated_at TEXT NOT NULL,
      UNIQUE(branch_id, employee_id),
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS branch_inventory (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      vehicle_id TEXT NOT NULL UNIQUE,
      vin TEXT NOT NULL,
      stock_state TEXT NOT NULL DEFAULT 'Available', -- 'Available' | 'Reserved' | 'Sold' | 'In Transit'
      condition_grade TEXT NOT NULL DEFAULT 'A+ Factory PDI Passed',
      condition_notes TEXT,
      reserved_customer_name TEXT,
      transfer_request_status TEXT NOT NULL DEFAULT 'None',
      transfer_target_branch_id TEXT,
      updated_by TEXT,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS branch_sales (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      order_number TEXT NOT NULL UNIQUE,
      booking_id TEXT,
      invoice_id TEXT,
      vehicle_id TEXT,
      vin TEXT,
      vehicle_model TEXT NOT NULL,
      customer_id TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      sales_exec_name TEXT NOT NULL,
      sale_amount_pkr REAL NOT NULL DEFAULT 0,
      paid_amount_pkr REAL NOT NULL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'Deposit Paid',
      delivery_status TEXT NOT NULL DEFAULT 'Pending PDI',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS branch_expenses (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      amount_pkr REAL NOT NULL DEFAULT 0,
      expense_date TEXT NOT NULL,
      recorded_by TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Recorded',
      created_at TEXT NOT NULL,
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS branch_escalations (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      manager_id TEXT NOT NULL,
      manager_name TEXT NOT NULL,
      request_type TEXT NOT NULL, -- 'Dealer Approval Request' | 'Vehicle Transfer Request' | 'Financial Refund Approval'
      target_id TEXT,
      title TEXT NOT NULL,
      details TEXT NOT NULL,
      amount REAL,
      status TEXT NOT NULL DEFAULT 'Pending Higher Approval',
      reviewed_by TEXT,
      review_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS spare_parts (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      sku TEXT NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      compatible_models TEXT NOT NULL,
      stock_quantity INTEGER NOT NULL DEFAULT 0,
      reorder_level INTEGER NOT NULL DEFAULT 5,
      unit_cost_pkr REAL NOT NULL DEFAULT 0,
      location_bin TEXT NOT NULL DEFAULT 'A-01',
      updated_at TEXT NOT NULL,
      UNIQUE(branch_id, sku),
      FOREIGN KEY (branch_id) REFERENCES branches(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS branch_activity_logs (
      id TEXT PRIMARY KEY,
      branch_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      manager_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS employee_departments (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      branch_id TEXT,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      head_name TEXT,
      description TEXT,
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, code),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_profiles (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL UNIQUE,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      department_id TEXT,
      reporting_manager_id TEXT,
      reporting_manager_name TEXT,
      bio TEXT NOT NULL DEFAULT '',
      date_of_birth TEXT,
      gender TEXT,
      cnic_or_id TEXT,
      address TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT 'Karachi',
      emergency_contact_name TEXT NOT NULL DEFAULT '',
      emergency_contact_phone TEXT NOT NULL DEFAULT '',
      emergency_contact_relation TEXT NOT NULL DEFAULT 'Family',
      work_location TEXT NOT NULL DEFAULT 'On-Site 3S Hub',
      employment_type TEXT NOT NULL DEFAULT 'Full-Time Permanent',
      responsibilities_json TEXT NOT NULL DEFAULT '[]',
      skills_json TEXT NOT NULL DEFAULT '[]',
      photo_doc_id TEXT,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_assignments (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      department_id TEXT,
      job_position TEXT NOT NULL,
      reporting_manager_id TEXT,
      reporting_manager_name TEXT,
      shift_schedule TEXT NOT NULL DEFAULT 'Mon-Sat 09:00-18:00',
      effective_from TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      assigned_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_attendance (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      attendance_date TEXT NOT NULL,
      check_in_at TEXT,
      check_out_at TEXT,
      working_hours REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Present',
      late_minutes INTEGER NOT NULL DEFAULT 0,
      early_leave_minutes INTEGER NOT NULL DEFAULT 0,
      work_mode TEXT NOT NULL DEFAULT 'On-Site',
      notes TEXT,
      correction_requested INTEGER NOT NULL DEFAULT 0,
      correction_reason TEXT,
      correction_status TEXT,
      correction_reviewed_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(employee_id, attendance_date),
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_leave_requests (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      leave_type TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      total_days INTEGER NOT NULL DEFAULT 1,
      reason TEXT NOT NULL,
      supporting_doc_id TEXT,
      status TEXT NOT NULL DEFAULT 'Pending',
      reviewed_by_id TEXT,
      reviewed_by_name TEXT,
      review_notes TEXT,
      reviewed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_tasks (
      id TEXT PRIMARY KEY,
      task_code TEXT NOT NULL UNIQUE,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Medium',
      due_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      assigned_by_id TEXT,
      assigned_by_name TEXT,
      manager_feedback TEXT,
      work_updates_json TEXT NOT NULL DEFAULT '[]',
      attachment_doc_ids_json TEXT NOT NULL DEFAULT '[]',
      started_at TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_salary_records (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      pay_period TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'PKR',
      base_salary REAL NOT NULL DEFAULT 0,
      allowances REAL NOT NULL DEFAULT 0,
      bonuses REAL NOT NULL DEFAULT 0,
      deductions REAL NOT NULL DEFAULT 0,
      tax_deduction REAL NOT NULL DEFAULT 0,
      net_salary REAL NOT NULL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'Paid',
      payment_date TEXT,
      bank_reference TEXT,
      slip_doc_id TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(employee_id, pay_period),
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_documents (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      storage_key TEXT NOT NULL UNIQUE,
      uploaded_by_id TEXT NOT NULL,
      uploaded_by_role TEXT NOT NULL,
      is_confidential INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_notifications (
      id TEXT PRIMARY KEY,
      employee_id TEXT,
      company_id TEXT NOT NULL,
      country_id TEXT,
      branch_id TEXT,
      category TEXT NOT NULL DEFAULT 'Announcement',
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      sender_name TEXT NOT NULL,
      sender_role TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Normal',
      is_read INTEGER NOT NULL DEFAULT 0,
      read_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS employee_performance_reviews (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      branch_id TEXT,
      period TEXT NOT NULL,
      rating REAL NOT NULL DEFAULT 92.0,
      attendance_score REAL NOT NULL DEFAULT 95.0,
      task_completion_score REAL NOT NULL DEFAULT 91.0,
      reviewer_name TEXT NOT NULL,
      reviewer_role TEXT NOT NULL,
      feedback TEXT NOT NULL,
      trainings_json TEXT NOT NULL DEFAULT '[]',
      goals_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_activity_logs (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      branch_id TEXT,
      country_id TEXT,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    -- =======================================================================
    -- DEDICATED DEALER LOGIN PORTAL & DEALER MANAGEMENT TABLES
    -- =======================================================================
    CREATE TABLE IF NOT EXISTS dealer_accounts (
      id TEXT PRIMARY KEY,
      dealer_code TEXT NOT NULL UNIQUE,
      dealership_id TEXT,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      business_name TEXT NOT NULL,
      owner_contact_name TEXT NOT NULL,
      username TEXT UNIQUE,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Authorized Dealer', -- '3S Flagship Centre' | '2S Service Facility' | 'Retail Experience Studio' | 'Authorized EV Reseller'
      verification_status TEXT NOT NULL DEFAULT 'Pending Approval', -- 'Pending Approval' | 'Verified' | 'Rejected'
      status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Active' | 'Suspended' | 'Rejected'
      email_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 1,
      two_factor_secret TEXT,
      recovery_codes_json TEXT NOT NULL DEFAULT '[]',
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      commission_rate_pct REAL NOT NULL DEFAULT 4.5,
      authorized_by TEXT,
      approved_by TEXT,
      approved_at TEXT,
      rejected_reason TEXT,
      last_login_at TEXT,
      last_login_ip TEXT,
      logo_doc_id TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealership_id) REFERENCES dealerships(id) ON DELETE SET NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
      FOREIGN KEY (country_id) REFERENCES countries(id),
      FOREIGN KEY (branch_id) REFERENCES branches(id)
    );

    CREATE TABLE IF NOT EXISTS dealer_profiles (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL UNIQUE,
      business_address TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT 'Karachi',
      country_id TEXT NOT NULL DEFAULT 'PK',
      tax_id_ntn TEXT NOT NULL DEFAULT '',
      registration_no TEXT NOT NULL DEFAULT '',
      website TEXT NOT NULL DEFAULT '',
      bank_name TEXT NOT NULL DEFAULT '',
      bank_account_title TEXT NOT NULL DEFAULT '',
      bank_iban_masked TEXT NOT NULL DEFAULT '',
      pending_changes_json TEXT,
      pending_change_status TEXT NOT NULL DEFAULT 'None', -- 'None' | 'Pending Admin Approval' | 'Approved' | 'Rejected'
      pending_change_submitted_at TEXT,
      pending_change_reviewed_by TEXT,
      notes TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_assignments (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      assigned_manager_id TEXT,
      assigned_manager_name TEXT,
      status TEXT NOT NULL DEFAULT 'Active', -- 'Active' | 'Reassigned' | 'Suspended'
      assigned_by TEXT NOT NULL,
      effective_from TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_permissions (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL UNIQUE,
      permissions_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_documents (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      doc_type TEXT NOT NULL, -- 'Business Registration' | 'Tax Certificate' | 'Bank Proof' | 'Booking Proof' | 'Logo' | 'Agreement'
      title TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      storage_key TEXT NOT NULL UNIQUE,
      verification_status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Verified' | 'Rejected'
      reviewed_by TEXT,
      review_notes TEXT,
      uploaded_by_id TEXT NOT NULL,
      uploaded_by_role TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_vehicle_inventory (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      vehicle_id TEXT,
      stock_number TEXT NOT NULL UNIQUE,
      model TEXT NOT NULL,
      variant TEXT NOT NULL,
      model_year INTEGER NOT NULL DEFAULT 2026,
      exterior_color TEXT NOT NULL,
      interior_color TEXT NOT NULL DEFAULT 'Eclipse Black Vegan Leather',
      vin TEXT NOT NULL,
      image_url TEXT NOT NULL DEFAULT '',
      availability_status TEXT NOT NULL DEFAULT 'Available', -- 'Available' | 'Reserved' | 'Booked' | 'Sold' | 'In Transit'
      approved_selling_price_pkr REAL NOT NULL DEFAULT 0,
      booking_status TEXT NOT NULL DEFAULT 'Unbooked', -- 'Unbooked' | 'Booking Requested' | 'Booking Approved' | 'Completed'
      delivery_status TEXT NOT NULL DEFAULT 'At Showroom', -- 'In Transit' | 'At Showroom' | 'Ready for Handover' | 'Delivered'
      assigned_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_customers (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Karachi',
      interested_model TEXT NOT NULL,
      requirements TEXT NOT NULL DEFAULT '',
      inquiry_status TEXT NOT NULL DEFAULT 'New Inquiry', -- 'New Inquiry' | 'Contacted' | 'Test Drive Requested' | 'Appointment Scheduled' | 'Booking Submitted' | 'Closed'
      follow_up_date TEXT,
      appointment_date TEXT,
      test_drive_status TEXT NOT NULL DEFAULT 'Not Requested', -- 'Not Requested' | 'Requested' | 'Scheduled' | 'Completed'
      communication_history_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_bookings (
      id TEXT PRIMARY KEY,
      booking_ref TEXT NOT NULL UNIQUE,
      dealer_id TEXT NOT NULL,
      customer_id TEXT NOT NULL,
      inventory_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      vehicle_model TEXT NOT NULL,
      variant TEXT NOT NULL,
      agreed_price_pkr REAL NOT NULL DEFAULT 0,
      booking_status TEXT NOT NULL DEFAULT 'Pending Approval', -- 'Pending Approval' | 'Approved' | 'Rejected' | 'Cancelled' | 'Converted to Sale'
      payment_status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Deposit Verified' | 'Fully Paid'
      delivery_status TEXT NOT NULL DEFAULT 'Pending PDI', -- 'Pending PDI' | 'In Transit' | 'Ready for Handover' | 'Delivered'
      supporting_doc_id TEXT,
      notes TEXT NOT NULL DEFAULT '',
      reviewed_by TEXT,
      reviewed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (customer_id) REFERENCES dealer_customers(id) ON DELETE CASCADE,
      FOREIGN KEY (inventory_id) REFERENCES dealer_vehicle_inventory(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_sales (
      id TEXT PRIMARY KEY,
      sale_ref TEXT NOT NULL UNIQUE,
      booking_id TEXT,
      dealer_id TEXT NOT NULL,
      customer_id TEXT NOT NULL,
      inventory_id TEXT,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      vehicle_model TEXT NOT NULL,
      vin TEXT NOT NULL,
      sale_amount_pkr REAL NOT NULL DEFAULT 0,
      paid_amount_pkr REAL NOT NULL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Payment Verified'
      payment_provider_ref TEXT,
      delivery_status TEXT NOT NULL DEFAULT 'Pending Handover', -- 'Pending Handover' | 'Delivered'
      delivered_at TEXT,
      receipt_doc_id TEXT,
      verified_by TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (customer_id) REFERENCES dealer_customers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_commissions (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      sale_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      sale_amount_pkr REAL NOT NULL DEFAULT 0,
      commission_rate_pct REAL NOT NULL DEFAULT 4.5,
      commission_amount_pkr REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Pending', -- 'Pending' | 'Approved' | 'Paid'
      approved_by TEXT,
      approved_at TEXT,
      paid_at TEXT,
      payout_reference TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (sale_id) REFERENCES dealer_sales(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_notifications (
      id TEXT PRIMARY KEY,
      dealer_id TEXT,
      company_id TEXT NOT NULL,
      country_id TEXT,
      branch_id TEXT,
      category TEXT NOT NULL DEFAULT 'Announcement',
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      sender_name TEXT NOT NULL,
      sender_role TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Normal',
      is_read INTEGER NOT NULL DEFAULT 0,
      read_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS dealer_support_requests (
      id TEXT PRIMARY KEY,
      ticket_number TEXT NOT NULL UNIQUE,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL,
      branch_id TEXT,
      category TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Medium',
      subject TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Open', -- 'Open' | 'In Progress' | 'Resolved'
      assigned_manager_name TEXT,
      resolution_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS dealer_activity_logs (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT,
      branch_id TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_dealer_accounts_email ON dealer_accounts(LOWER(email));
    CREATE INDEX IF NOT EXISTS idx_dealer_accounts_code ON dealer_accounts(dealer_code);
    CREATE INDEX IF NOT EXISTS idx_dealer_inventory_dealer ON dealer_vehicle_inventory(dealer_id, availability_status);
    CREATE INDEX IF NOT EXISTS idx_dealer_customers_dealer ON dealer_customers(dealer_id, inquiry_status);
    CREATE INDEX IF NOT EXISTS idx_dealer_bookings_dealer ON dealer_bookings(dealer_id, booking_status);
    CREATE INDEX IF NOT EXISTS idx_dealer_sales_dealer ON dealer_sales(dealer_id, payment_status);
    CREATE INDEX IF NOT EXISTS idx_dealer_commissions_dealer ON dealer_commissions(dealer_id, status);
    CREATE INDEX IF NOT EXISTS idx_dealer_docs_dealer ON dealer_documents(dealer_id, verification_status);
    CREATE INDEX IF NOT EXISTS idx_dealer_logs_dealer ON dealer_activity_logs(dealer_id, created_at);

    -- Dedicated Customer Login Portal & Customer Management System Tables (19 Tables)
    CREATE TABLE IF NOT EXISTS customer_accounts (
      id TEXT PRIMARY KEY,
      customer_code TEXT NOT NULL UNIQUE,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'Customer',
      account_type TEXT NOT NULL DEFAULT 'Individual Customer',
      country TEXT NOT NULL DEFAULT 'PK',
      city TEXT NOT NULL DEFAULT 'Karachi',
      address TEXT NOT NULL DEFAULT '',
      verification_status TEXT NOT NULL DEFAULT 'Unverified', -- 'Unverified' | 'Email Verified' | 'Verified' | 'Suspended'
      status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Active' | 'Suspended' | 'Deletion Requested'
      email_verified INTEGER NOT NULL DEFAULT 0,
      mobile_verified INTEGER NOT NULL DEFAULT 0,
      two_factor_enabled INTEGER NOT NULL DEFAULT 0,
      two_factor_secret TEXT,
      recovery_codes_json TEXT NOT NULL DEFAULT '[]',
      failed_login_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      last_login_at TEXT,
      last_login_ip TEXT,
      deletion_requested_at TEXT,
      deletion_reason TEXT,
      verified_by TEXT,
      verified_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_customer_accounts_email_lower ON customer_accounts(LOWER(email));
    CREATE INDEX IF NOT EXISTS idx_customer_accounts_mobile ON customer_accounts(mobile);

    CREATE TABLE IF NOT EXISTS customer_profiles (
      customer_id TEXT PRIMARY KEY,
      avatar_url TEXT NOT NULL DEFAULT '',
      cnic_or_id TEXT NOT NULL DEFAULT '',
      date_of_birth TEXT,
      preferred_language TEXT NOT NULL DEFAULT 'en',
      preferred_currency TEXT NOT NULL DEFAULT 'PKR',
      preferred_dealership_id TEXT,
      communication_prefs_json TEXT NOT NULL DEFAULT '{"emailUpdates":true,"serviceReminders":true,"warrantyAlerts":true,"promotionalOffers":false}',
      emergency_contact TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_verifications (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      channel TEXT NOT NULL, -- 'email' | 'mobile' | 'identity'
      target TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending', -- 'Pending' | 'Verified' | 'Provider Not Configured' | 'Failed'
      otp_ref TEXT,
      provider TEXT NOT NULL DEFAULT 'SMTP/Internal',
      verified_at TEXT,
      metadata_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_sessions (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      device_label TEXT,
      ip_address TEXT,
      user_agent TEXT,
      revoked INTEGER NOT NULL DEFAULT 0,
      last_activity_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_vehicles (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      vehicle_id TEXT,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealership_id TEXT,
      dealership_name TEXT NOT NULL DEFAULT '',
      vin TEXT NOT NULL UNIQUE,
      chassis_number TEXT NOT NULL DEFAULT '',
      model TEXT NOT NULL,
      variant TEXT NOT NULL DEFAULT 'Standard Edition',
      color TEXT NOT NULL DEFAULT 'Atlantis Grey',
      model_year INTEGER NOT NULL DEFAULT 2026,
      license_plate TEXT NOT NULL DEFAULT '',
      registration_date TEXT,
      odometer_km INTEGER NOT NULL DEFAULT 0,
      battery_capacity_kwh REAL NOT NULL DEFAULT 60.48,
      battery_health_soh REAL NOT NULL DEFAULT 100.0,
      battery_health_soc REAL NOT NULL DEFAULT 85.0,
      warranty_start_date TEXT,
      warranty_expiry_date TEXT,
      next_service_due_km INTEGER NOT NULL DEFAULT 10000,
      status TEXT NOT NULL DEFAULT 'Active',
      image_url TEXT NOT NULL DEFAULT '',
      ownership_verified INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_favorites (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      inventory_id TEXT NOT NULL,
      model TEXT NOT NULL,
      variant TEXT NOT NULL,
      dealer_id TEXT,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      UNIQUE(customer_id, inventory_id),
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_inquiries (
      id TEXT PRIMARY KEY,
      inquiry_ref TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealer_id TEXT,
      dealership_name TEXT NOT NULL DEFAULT '',
      inventory_id TEXT,
      vehicle_model TEXT NOT NULL,
      variant TEXT NOT NULL DEFAULT '',
      inquiry_type TEXT NOT NULL DEFAULT 'Vehicle Information', -- 'Vehicle Information' | 'Price & Variant' | 'Dealership Contact' | 'Fleet Inquiry'
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      preferred_contact TEXT NOT NULL DEFAULT 'Email',
      status TEXT NOT NULL DEFAULT 'Submitted', -- 'Submitted' | 'Under Review' | 'Assigned' | 'Replied' | 'Closed'
      assigned_to_name TEXT,
      reply_text TEXT,
      replied_by TEXT,
      replied_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_test_drive_requests (
      id TEXT PRIMARY KEY,
      request_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealer_id TEXT,
      dealership_name TEXT NOT NULL,
      inventory_id TEXT,
      vehicle_model TEXT NOT NULL,
      variant TEXT NOT NULL DEFAULT '',
      preferred_date TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT 'Karachi',
      notes TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending Showroom Confirmation', -- 'Pending Showroom Confirmation' | 'Confirmed' | 'Rescheduled' | 'Completed' | 'Cancelled'
      assigned_staff_name TEXT,
      showroom_notes TEXT,
      confirmed_by TEXT,
      confirmed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_bookings (
      id TEXT PRIMARY KEY,
      booking_ref TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealer_id TEXT,
      dealership_name TEXT NOT NULL,
      inventory_id TEXT NOT NULL,
      vehicle_model TEXT NOT NULL,
      variant TEXT NOT NULL,
      exterior_color TEXT NOT NULL,
      interior_color TEXT NOT NULL DEFAULT 'Eclipse Black',
      quoted_price_pkr REAL NOT NULL DEFAULT 0,
      booking_deposit_pkr REAL NOT NULL DEFAULT 0,
      booking_status TEXT NOT NULL DEFAULT 'Pending Review', -- 'Pending Review' | 'Approved' | 'Rejected' | 'Cancelled' | 'Completed'
      payment_status TEXT NOT NULL DEFAULT 'Awaiting Payment Verification', -- 'Awaiting Payment Verification' | 'Deposit Verified' | 'Fully Paid' | 'Refunded'
      delivery_status TEXT NOT NULL DEFAULT 'Awaiting Booking Approval', -- 'Awaiting Booking Approval' | 'In Allocation' | 'Pre-Delivery Inspection' | 'Ready for Delivery' | 'Delivered'
      payment_instructions TEXT NOT NULL DEFAULT '',
      customer_notes TEXT NOT NULL DEFAULT '',
      admin_notes TEXT,
      reviewed_by TEXT,
      reviewed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_booking_documents (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      booking_id TEXT,
      doc_category TEXT NOT NULL, -- 'Identity / CNIC' | 'Booking Form' | 'Payment Proof' | 'Invoice' | 'Receipt' | 'Purchase Deed' | 'Registration' | 'Warranty Certificate' | 'Service Record'
      doc_title TEXT NOT NULL,
      file_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size INTEGER NOT NULL DEFAULT 0,
      storage_path TEXT NOT NULL,
      verification_status TEXT NOT NULL DEFAULT 'Submitted', -- 'Submitted' | 'Verified' | 'Rejected'
      verified_by TEXT,
      verified_at TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_payments (
      id TEXT PRIMARY KEY,
      payment_ref TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      booking_id TEXT,
      invoice_id TEXT,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      currency TEXT NOT NULL DEFAULT 'PKR',
      amount_pkr REAL NOT NULL DEFAULT 0,
      amount_local REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL,
      gateway_name TEXT NOT NULL DEFAULT 'Verified Bank Transfer / Showroom Desk',
      transaction_ref TEXT NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'Pending Verification', -- 'Pending Verification' | 'Verified' | 'Paid' | 'Rejected' | 'Refunded'
      payment_date TEXT NOT NULL,
      verified_by TEXT,
      verified_at TEXT,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_invoices (
      id TEXT PRIMARY KEY,
      invoice_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      booking_id TEXT,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealership_name TEXT NOT NULL,
      item_category TEXT NOT NULL,
      vehicle_model TEXT NOT NULL DEFAULT '',
      currency TEXT NOT NULL DEFAULT 'PKR',
      subtotal_pkr REAL NOT NULL DEFAULT 0,
      tax_rate REAL NOT NULL DEFAULT 18.0,
      tax_amount_pkr REAL NOT NULL DEFAULT 0,
      total_amount_pkr REAL NOT NULL DEFAULT 0,
      amount_paid_pkr REAL NOT NULL DEFAULT 0,
      outstanding_balance_pkr REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Issued', -- 'Issued' | 'Partially Paid' | 'Paid' | 'Void'
      issued_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_service_requests (
      id TEXT PRIMARY KEY,
      request_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      customer_vehicle_id TEXT NOT NULL,
      vin TEXT NOT NULL,
      model TEXT NOT NULL,
      license_plate TEXT NOT NULL DEFAULT '',
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealership_id TEXT NOT NULL,
      dealership_name TEXT NOT NULL,
      service_type TEXT NOT NULL,
      preferred_date TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      complaint_details TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending Confirmation', -- 'Pending Confirmation' | 'Confirmed' | 'In Workshop' | 'Completed' | 'Cancelled'
      technician_assigned TEXT,
      estimated_cost_pkr REAL NOT NULL DEFAULT 0,
      actual_cost_pkr REAL,
      advisor_notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_service_history (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      customer_vehicle_id TEXT NOT NULL,
      service_request_id TEXT,
      vin TEXT NOT NULL,
      model TEXT NOT NULL,
      dealership_name TEXT NOT NULL,
      service_date TEXT NOT NULL,
      service_type TEXT NOT NULL,
      odometer_km INTEGER NOT NULL DEFAULT 0,
      summary TEXT NOT NULL,
      technician_name TEXT NOT NULL DEFAULT 'BYD Certified HV Technician',
      cost_pkr REAL NOT NULL DEFAULT 0,
      next_reminder_date TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_warranty_records (
      id TEXT PRIMARY KEY,
      warranty_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      customer_vehicle_id TEXT NOT NULL,
      vin TEXT NOT NULL,
      model TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      coverage_type TEXT NOT NULL DEFAULT 'Blade Battery (8 Yr / 160,000 km) & Vehicle (6 Yr / 150,000 km)',
      battery_warranty_years INTEGER NOT NULL DEFAULT 8,
      vehicle_warranty_years INTEGER NOT NULL DEFAULT 6,
      start_date TEXT NOT NULL,
      expiry_date TEXT NOT NULL,
      terms_summary TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active', -- 'Active' | 'Expiring Soon' | 'Expired' | 'Voided'
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_warranty_claims (
      id TEXT PRIMARY KEY,
      claim_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      warranty_record_id TEXT NOT NULL,
      vin TEXT NOT NULL,
      vehicle_model TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      dealership_name TEXT NOT NULL,
      component_category TEXT NOT NULL,
      issue_description TEXT NOT NULL,
      fault_code TEXT NOT NULL DEFAULT '',
      submission_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Submitted', -- 'Submitted' | 'Technical Review' | 'Approved' | 'Rejected' | 'Settled'
      claim_amount_pkr REAL NOT NULL DEFAULT 0,
      approved_amount_pkr REAL,
      review_notes TEXT,
      reviewed_by TEXT,
      reviewed_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_notifications (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      category TEXT NOT NULL, -- 'Booking' | 'Payment' | 'Test Drive' | 'Delivery' | 'Service' | 'Warranty' | 'Announcement' | 'Support' | 'Security'
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'Normal',
      action_tab TEXT NOT NULL DEFAULT 'overview',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_support_tickets (
      id TEXT PRIMARY KEY,
      ticket_number TEXT NOT NULL UNIQUE,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      category TEXT NOT NULL DEFAULT 'General Inquiry',
      priority TEXT NOT NULL DEFAULT 'Medium',
      subject TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Open', -- 'Open' | 'In Progress' | 'Resolved' | 'Closed'
      assigned_to_name TEXT,
      reply_text TEXT,
      replied_by TEXT,
      replied_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customer_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customer_activity_logs (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      company_id TEXT NOT NULL DEFAULT 'comp_byd_pk',
      country_id TEXT,
      branch_id TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      status TEXT NOT NULL DEFAULT 'SUCCESS',
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_cust_sess_cust ON customer_sessions(customer_id, revoked);
    CREATE INDEX IF NOT EXISTS idx_cust_veh_cust ON customer_vehicles(customer_id);
    CREATE INDEX IF NOT EXISTS idx_cust_inq_cust ON customer_inquiries(customer_id, status);
    CREATE INDEX IF NOT EXISTS idx_cust_td_cust ON customer_test_drive_requests(customer_id, status);
    CREATE INDEX IF NOT EXISTS idx_cust_bk_cust ON customer_bookings(customer_id, booking_status);
    CREATE INDEX IF NOT EXISTS idx_cust_pay_cust ON customer_payments(customer_id, payment_status);
    CREATE INDEX IF NOT EXISTS idx_cust_svc_cust ON customer_service_requests(customer_id, status);
    CREATE INDEX IF NOT EXISTS idx_cust_war_cust ON customer_warranty_claims(customer_id, status);
    CREATE INDEX IF NOT EXISTS idx_cust_notif_cust ON customer_notifications(customer_id, is_read);
    CREATE INDEX IF NOT EXISTS idx_cust_tkt_cust ON customer_support_tickets(customer_id, status);
    CREATE INDEX IF NOT EXISTS idx_cust_log_cust ON customer_activity_logs(customer_id, created_at);
  `);

  // Safe schema migrations for existing DB files (non-destructive)
  const ensureColumn = (table: string, colName: string, definition: string) => {
    try {
      const cols = sqlite.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
      if (!cols.some((c) => c.name === colName)) {
        sqlite.exec(`ALTER TABLE ${table} ADD COLUMN ${colName} ${definition}`);
      }
    } catch {
      // ignore if table freshly created
    }
  };

  ensureColumn('dealerships', 'status', "TEXT NOT NULL DEFAULT 'Approved'");
  ensureColumn('dealerships', 'branch_id', 'TEXT');
  ensureColumn('companies', 'logo_url', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('companies', 'website', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('companies', 'tax_id', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('companies', 'departments_json', "TEXT NOT NULL DEFAULT '[\"Executive\",\"Sales & Retail\",\"Aftersales & Workshop\",\"Finance\",\"Customer Care\"]'");
  ensureColumn('companies', 'documents_json', "TEXT NOT NULL DEFAULT '[]'");
  ensureColumn('companies', 'business_info_json', "TEXT NOT NULL DEFAULT '{}'");
  ensureColumn('vehicles', 'branch_id', 'TEXT');
  ensureColumn('vehicles', 'delivery_status', "TEXT NOT NULL DEFAULT 'Delivered'");
  ensureColumn('vehicles', 'reserved_by', 'TEXT');
  ensureColumn('bookings', 'branch_id', 'TEXT');
  ensureColumn('service_jobs', 'branch_id', 'TEXT');
  ensureColumn('service_jobs', 'reminder_date', 'TEXT');
  ensureColumn('warranty_claims', 'branch_id', 'TEXT');
  ensureColumn('payments_invoices', 'branch_id', 'TEXT');
  ensureColumn('users', 'branch_id', 'TEXT');
  ensureColumn('customer_crm_records', 'branch_id', 'TEXT');
  ensureColumn('notifications', 'branch_id', 'TEXT');

  // Dedicated Employee Login & Organization columns on employee_accounts (non-destructive)
  ensureColumn('employee_accounts', 'country_id', 'TEXT');
  ensureColumn('employee_accounts', 'department_id', 'TEXT');
  ensureColumn('employee_accounts', 'reporting_manager_id', 'TEXT');
  ensureColumn('employee_accounts', 'reporting_manager_name', 'TEXT');
  ensureColumn('employee_accounts', 'username', 'TEXT');
  ensureColumn('employee_accounts', 'password_hash', 'TEXT');
  ensureColumn('employee_accounts', 'email_verified', 'INTEGER NOT NULL DEFAULT 1');
  ensureColumn('employee_accounts', 'two_factor_enabled', 'INTEGER NOT NULL DEFAULT 1');
  ensureColumn('employee_accounts', 'two_factor_secret', 'TEXT');
  ensureColumn('employee_accounts', 'recovery_codes_json', "TEXT NOT NULL DEFAULT '[]'");
  ensureColumn('employee_accounts', 'failed_login_attempts', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('employee_accounts', 'locked_until', 'TEXT');
  ensureColumn('employee_accounts', 'last_login_at', 'TEXT');
  ensureColumn('employee_accounts', 'last_login_ip', 'TEXT');
  ensureColumn('employee_accounts', 'leave_balance_json', 'TEXT NOT NULL DEFAULT \'{"annual":18,"sick":10,"casual":8}\'');
  ensureColumn('employee_accounts', 'photo_doc_id', 'TEXT');

  ensureColumn('invitations', 'employee_code', 'TEXT');
  ensureColumn('invitations', 'country_id', 'TEXT');
  ensureColumn('invitations', 'branch_id', 'TEXT');
  ensureColumn('invitations', 'department_id', 'TEXT');
  ensureColumn('invitations', 'department', 'TEXT');
  ensureColumn('invitations', 'reporting_manager_id', 'TEXT');
  ensureColumn('invitations', 'reporting_manager_name', 'TEXT');
  ensureColumn('support_requests', 'employee_id', 'TEXT');

  // Session Idle Timeout & Security Metadata Migrations
  ensureColumn('authentication_sessions', 'idle_expires_at', 'TEXT');
  ensureColumn('authentication_sessions', 'device_fingerprint', 'TEXT');
  ensureColumn('authentication_sessions', 'revoked_reason', 'TEXT');
  ensureColumn('authentication_sessions', 'revoked_at', 'TEXT');

  // Consent & MFA fields on Customer & Standard Users
  ensureColumn('customer_accounts', 'terms_accepted', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('customer_accounts', 'terms_accepted_at', 'TEXT');
  ensureColumn('customer_accounts', 'privacy_accepted', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('customer_accounts', 'privacy_accepted_at', 'TEXT');
  ensureColumn('customer_accounts', 'two_factor_enabled', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('customer_accounts', 'two_factor_secret', 'TEXT');
  ensureColumn('customer_accounts', 'recovery_codes_json', "TEXT NOT NULL DEFAULT '[]'");

  ensureColumn('users', 'terms_accepted', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('users', 'terms_accepted_at', 'TEXT');
  ensureColumn('users', 'privacy_accepted', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('users', 'privacy_accepted_at', 'TEXT');
  ensureColumn('users', 'recovery_codes_json', "TEXT NOT NULL DEFAULT '[]'");

  // Company & Branch Management Enterprise Non-Destructive Schema Extensions
  ensureColumn('countries', 'dialing_code', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('countries', 'is_verified', 'INTEGER NOT NULL DEFAULT 1');
  ensureColumn('branches', 'regional_office_id', 'TEXT');
  ensureColumn('branches', 'state_province', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('branches', 'opening_date', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('branches', 'latitude', 'REAL');
  ensureColumn('branches', 'longitude', 'REAL');
  ensureColumn('employee_departments', 'office_id', 'TEXT');
  ensureColumn('employee_departments', 'office_type', "TEXT NOT NULL DEFAULT 'Company'");
  ensureColumn('employee_departments', 'head_employee_id', 'TEXT');
  ensureColumn('employee_accounts', 'office_id', 'TEXT');
  ensureColumn('employee_accounts', 'employment_type', "TEXT NOT NULL DEFAULT 'Full-Time'");
  ensureColumn('employee_accounts', 'personal_info_json', "TEXT NOT NULL DEFAULT '{}'");

  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS head_offices (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      office_name TEXT NOT NULL,
      address TEXT NOT NULL DEFAULT '',
      country_id TEXT NOT NULL,
      city_id TEXT,
      city TEXT NOT NULL DEFAULT '',
      state_province TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '',
      registration_info TEXT NOT NULL DEFAULT '',
      management_details TEXT NOT NULL DEFAULT '',
      departments_json TEXT NOT NULL DEFAULT '[]',
      documents_json TEXT NOT NULL DEFAULT '[]',
      latitude REAL,
      longitude REAL,
      status TEXT NOT NULL DEFAULT 'Active',
      authorized_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, office_name),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS regional_offices (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      head_office_id TEXT,
      country_id TEXT NOT NULL,
      city_id TEXT,
      city TEXT NOT NULL DEFAULT '',
      state_province TEXT NOT NULL DEFAULT '',
      office_name TEXT NOT NULL,
      office_code TEXT NOT NULL UNIQUE,
      address TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '',
      manager_id TEXT,
      manager_name TEXT NOT NULL DEFAULT '',
      departments_json TEXT NOT NULL DEFAULT '[]',
      documents_json TEXT NOT NULL DEFAULT '[]',
      latitude REAL,
      longitude REAL,
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(company_id, country_id, office_name),
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS cities (
      id TEXT PRIMARY KEY,
      country_id TEXT NOT NULL,
      city_code TEXT NOT NULL,
      name TEXT NOT NULL,
      normalized_name TEXT NOT NULL,
      state_province TEXT NOT NULL DEFAULT '',
      normalized_state TEXT NOT NULL DEFAULT '',
      latitude REAL,
      longitude REAL,
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(country_id, normalized_name, normalized_state),
      UNIQUE(country_id, city_code)
    );

    CREATE TABLE IF NOT EXISTS organization_activity_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      scope_company_id TEXT,
      scope_country_id TEXT,
      scope_regional_office_id TEXT,
      scope_branch_id TEXT,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      entity_name TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_oal_created ON organization_activity_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_oal_scope ON organization_activity_logs(scope_company_id, scope_country_id, scope_branch_id);
  `);

  // Synchronize dialing codes on existing verified ISO country rows without changing any custom values
  const knownDialCodes: Record<string, string> = {
    PK: '+92',
    AE: '+971',
    SA: '+966',
    GB: '+44',
    DE: '+49',
    US: '+1',
    CN: '+86',
  };
  for (const [code, dial] of Object.entries(knownDialCodes)) {
    sqlite.prepare("UPDATE countries SET dialing_code = ? WHERE code = ? AND (dialing_code IS NULL OR dialing_code = '')").run(dial, code);
  }

  // Register only real cities already referenced in verified DB tables (never fabricated)
  const syncCityIfReal = (countryId: string, cityName: string, stateProvince = '') => {
    const cCode = String(countryId || '').trim().toUpperCase();
    const cleanName = String(cityName || '').trim();
    if (!cCode || !cleanName || cleanName.toLowerCase() === 'all') return;
    const normName = cleanName.toLowerCase();
    const normState = String(stateProvince || '').trim().toLowerCase();
    const existing = sqlite
      .prepare('SELECT id FROM cities WHERE country_id = ? AND normalized_name = ? AND normalized_state = ?')
      .get(cCode, normName, normState);
    if (existing) return;
    const shortCity = cleanName.replace(/[^A-Za-z]/g, '').toUpperCase().slice(0, 3) || 'CTY';
    const cityCode = `${cCode}-${shortCity}-${Math.floor(10 + Math.random() * 89)}`;
    const id = `city_${cCode.toLowerCase()}_${normName.replace(/[^a-z0-9]/g, '_')}`;
    const ts = nowIso();
    sqlite
      .prepare(`
        INSERT OR IGNORE INTO cities (
          id, country_id, city_code, name, normalized_name, state_province, normalized_state, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
      `)
      .run(id, cCode, cityCode, cleanName, normName, stateProvince, normState, ts, ts);
  };

  for (const co of sqlite.prepare('SELECT id, headquarters_city FROM countries').all() as Array<{ id: string; headquarters_city: string }>) {
    if (co.headquarters_city) syncCityIfReal(co.id, co.headquarters_city);
  }
  for (const b of sqlite.prepare('SELECT country_id, city, state_province FROM branches').all() as Array<{ country_id: string; city: string; state_province: string }>) {
    if (b.city && b.country_id) syncCityIfReal(b.country_id, b.city, b.state_province || '');
  }
  for (const c of sqlite.prepare('SELECT country, city FROM companies').all() as Array<{ country: string; city: string }>) {
    const coMatch = sqlite.prepare('SELECT id FROM countries WHERE UPPER(code) = UPPER(?) OR LOWER(name) = LOWER(?) LIMIT 1').get(c.country, c.country) as any;
    if (coMatch && c.city) syncCityIfReal(coMatch.id, c.city);
  }

  // Employee Management Module Enterprise Non-Destructive Extensions & Tables
  ensureColumn('employee_accounts', 'father_name', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'date_of_birth', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'gender', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'cnic_number', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'residential_address', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'city', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'basic_salary', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_accounts', 'emergency_contact_name', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'emergency_contact_phone', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'bank_name', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'bank_account_title', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('employee_accounts', 'bank_iban', "TEXT NOT NULL DEFAULT ''");

  ensureColumn('employee_attendance', 'overtime_hours', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_attendance', 'marked_by_id', 'TEXT');
  ensureColumn('employee_attendance', 'marked_by_name', 'TEXT');

  ensureColumn('employee_salary_records', 'basic_salary', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'house_allowance', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'medical_allowance', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'transport_allowance', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'other_allowances', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'overtime_payment', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'other_deductions', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'advance_salary', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('employee_salary_records', 'approval_status', "TEXT NOT NULL DEFAULT 'Approved'");
  ensureColumn('employee_salary_records', 'approved_by_id', 'TEXT');
  ensureColumn('employee_salary_records', 'approved_by_name', 'TEXT');
  ensureColumn('employee_salary_records', 'approved_at', 'TEXT');
  ensureColumn('employee_salary_records', 'paid_by_name', 'TEXT');
  ensureColumn('employee_salary_records', 'verified_payment_ref', 'TEXT');

  ensureColumn('employee_documents', 'issue_date', 'TEXT');
  ensureColumn('employee_documents', 'expiry_date', 'TEXT');
  ensureColumn('employee_documents', 'verification_status', "TEXT NOT NULL DEFAULT 'Pending Verification'");
  ensureColumn('employee_documents', 'verified_by', 'TEXT');
  ensureColumn('employee_documents', 'verified_at', 'TEXT');
  ensureColumn('employee_documents', 'document_notes', 'TEXT');

  ensureColumn('employee_performance_reviews', 'review_cycle', "TEXT NOT NULL DEFAULT 'Monthly'");
  ensureColumn('employee_performance_reviews', 'productivity_score', 'REAL NOT NULL DEFAULT 90.0');
  ensureColumn('employee_performance_reviews', 'work_quality_score', 'REAL NOT NULL DEFAULT 90.0');
  ensureColumn('employee_performance_reviews', 'improvement_plan', 'TEXT');
  ensureColumn('employee_performance_reviews', 'reviewer_id', 'TEXT');
  ensureColumn('employee_performance_reviews', 'visibility', "TEXT NOT NULL DEFAULT 'EmployeeVisible'");

  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS employee_positions (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      branch_id TEXT,
      department_id TEXT,
      title TEXT NOT NULL,
      designation TEXT NOT NULL,
      employment_type TEXT NOT NULL DEFAULT 'Full-Time Permanent',
      reporting_manager_id TEXT,
      reporting_manager_name TEXT,
      responsibilities TEXT NOT NULL DEFAULT '',
      min_salary REAL NOT NULL DEFAULT 0,
      max_salary REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_emp_pos_comp ON employee_positions(company_id, department_id);

    CREATE TABLE IF NOT EXISTS employee_salary_structures (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL UNIQUE,
      company_id TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'PKR',
      basic_salary REAL NOT NULL DEFAULT 0,
      house_allowance REAL NOT NULL DEFAULT 0,
      medical_allowance REAL NOT NULL DEFAULT 0,
      transport_allowance REAL NOT NULL DEFAULT 0,
      other_allowances REAL NOT NULL DEFAULT 0,
      tax_deduction REAL NOT NULL DEFAULT 0,
      other_deductions REAL NOT NULL DEFAULT 0,
      bank_name TEXT NOT NULL DEFAULT '',
      bank_account_title TEXT NOT NULL DEFAULT '',
      bank_iban TEXT NOT NULL DEFAULT '',
      effective_from TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS payroll_items (
      id TEXT PRIMARY KEY,
      payroll_record_id TEXT NOT NULL,
      employee_id TEXT NOT NULL,
      item_type TEXT NOT NULL, -- 'earning' | 'deduction'
      label TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      FOREIGN KEY (payroll_record_id) REFERENCES employee_salary_records(id) ON DELETE CASCADE,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_targets (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      period TEXT NOT NULL,
      title TEXT NOT NULL,
      metric_name TEXT NOT NULL,
      target_value REAL NOT NULL DEFAULT 0,
      achieved_value REAL NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT '%',
      status TEXT NOT NULL DEFAULT 'In Progress',
      assigned_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS employee_history (
      id TEXT PRIMARY KEY,
      employee_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      change_type TEXT NOT NULL, -- 'Profile' | 'Position' | 'Promotion' | 'Transfer' | 'Salary' | 'Status'
      previous_value TEXT,
      new_value TEXT,
      effective_date TEXT NOT NULL,
      notes TEXT,
      changed_by_id TEXT NOT NULL,
      changed_by_name TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (employee_id) REFERENCES employee_accounts(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_emp_hist_emp ON employee_history(employee_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS employee_audit_logs (
      id TEXT PRIMARY KEY,
      employee_id TEXT,
      company_id TEXT,
      branch_id TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_emp_audit_created ON employee_audit_logs(created_at DESC);

    CREATE TABLE IF NOT EXISTS employee_module_settings (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL UNIQUE,
      employee_id_prefix TEXT NOT NULL DEFAULT 'BYD-PAK-EMP-',
      work_start_time TEXT NOT NULL DEFAULT '09:00',
      work_end_time TEXT NOT NULL DEFAULT '18:00',
      late_grace_minutes INTEGER NOT NULL DEFAULT 15,
      annual_leave_default INTEGER NOT NULL DEFAULT 18,
      sick_leave_default INTEGER NOT NULL DEFAULT 10,
      casual_leave_default INTEGER NOT NULL DEFAULT 8,
      overtime_hourly_rate REAL NOT NULL DEFAULT 1200,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
  `);

  // =========================================================================
  // DEALERSHIP MANAGEMENT MODULE EXTENSIONS (Non-destructive)
  // =========================================================================
  ensureColumn('dealer_accounts', 'cnic_number', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('dealer_accounts', 'province', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('dealer_accounts', 'mobile_verified', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('dealer_accounts', 'mobile_otp_hash', 'TEXT');
  ensureColumn('dealer_accounts', 'email_otp_hash', 'TEXT');
  ensureColumn('dealer_accounts', 'verification_notes', "TEXT NOT NULL DEFAULT ''");

  ensureColumn('dealer_documents', 'showroom_id', 'TEXT');
  ensureColumn('dealer_documents', 'issue_date', 'TEXT');
  ensureColumn('dealer_documents', 'expiry_date', 'TEXT');

  ensureColumn('dealer_vehicle_inventory', 'showroom_id', 'TEXT');
  ensureColumn('dealer_vehicle_inventory', 'chassis_number', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('dealer_vehicle_inventory', 'motor_power_kw', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('dealer_vehicle_inventory', 'battery_kwh', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('dealer_vehicle_inventory', 'range_km', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('dealer_vehicle_inventory', 'stock_qty', 'INTEGER NOT NULL DEFAULT 1');
  ensureColumn('dealer_vehicle_inventory', 'arrival_date', 'TEXT');
  ensureColumn('dealer_vehicle_inventory', 'delivery_date', 'TEXT');
  ensureColumn('dealer_vehicle_inventory', 'specs_json', "TEXT NOT NULL DEFAULT '{}'");

  ensureColumn('dealer_sales', 'showroom_id', 'TEXT');
  ensureColumn('dealer_sales', 'sales_date', 'TEXT');
  ensureColumn('dealer_sales', 'list_price_pkr', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('dealer_sales', 'discount_pkr', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('dealer_sales', 'discount_status', "TEXT NOT NULL DEFAULT 'None'");
  ensureColumn('dealer_sales', 'discount_approved_by', 'TEXT');
  ensureColumn('dealer_sales', 'invoice_number', 'TEXT');
  ensureColumn('dealer_sales', 'refund_amount_pkr', 'REAL NOT NULL DEFAULT 0');
  ensureColumn('dealer_sales', 'cancellation_reason', 'TEXT');
  ensureColumn('dealer_sales', 'cancelled_by', 'TEXT');
  ensureColumn('dealer_sales', 'cancelled_at', 'TEXT');
  ensureColumn('dealer_sales', 'refund_status', "TEXT NOT NULL DEFAULT 'None'");
  ensureColumn('dealer_sales', 'notes', "TEXT NOT NULL DEFAULT ''");

  ensureColumn('dealer_commissions', 'rule_id', 'TEXT');
  ensureColumn('dealer_commissions', 'rule_type', "TEXT NOT NULL DEFAULT 'Percentage'");
  ensureColumn('dealer_commissions', 'fixed_amount_pkr', 'REAL NOT NULL DEFAULT 0');

  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS dealer_showrooms (
      id TEXT PRIMARY KEY,
      showroom_code TEXT NOT NULL UNIQUE,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      country_id TEXT NOT NULL DEFAULT 'PK',
      branch_id TEXT,
      name TEXT NOT NULL,
      address TEXT NOT NULL DEFAULT '',
      country TEXT NOT NULL DEFAULT 'PK',
      province TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL DEFAULT 'Karachi',
      phone TEXT NOT NULL DEFAULT '',
      email TEXT NOT NULL DEFAULT '',
      opening_hours TEXT NOT NULL DEFAULT '09:00',
      closing_hours TEXT NOT NULL DEFAULT '20:00',
      manager_name TEXT NOT NULL DEFAULT '',
      manager_phone TEXT NOT NULL DEFAULT '',
      manager_email TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Active',
      verification_status TEXT NOT NULL DEFAULT 'Pending Approval',
      photo_doc_ids_json TEXT NOT NULL DEFAULT '[]',
      doc_ids_json TEXT NOT NULL DEFAULT '[]',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_showrooms_dealer ON dealer_showrooms(dealer_id, status);

    CREATE TABLE IF NOT EXISTS dealer_verification_history (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      showroom_id TEXT,
      target_type TEXT NOT NULL DEFAULT 'Dealer',
      target_id TEXT,
      previous_status TEXT,
      new_status TEXT NOT NULL,
      rejection_reason TEXT,
      notes TEXT,
      reviewed_by_id TEXT NOT NULL,
      reviewed_by_name TEXT NOT NULL,
      reviewed_by_role TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_ver_hist_dealer ON dealer_verification_history(dealer_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS dealer_inventory_history (
      id TEXT PRIMARY KEY,
      inventory_id TEXT NOT NULL,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      action_type TEXT NOT NULL,
      from_dealer_id TEXT,
      to_dealer_id TEXT,
      from_branch_id TEXT,
      to_branch_id TEXT,
      previous_status TEXT,
      new_status TEXT,
      notes TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (inventory_id) REFERENCES dealer_vehicle_inventory(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_inv_hist_inv ON dealer_inventory_history(inventory_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS dealer_commission_rules (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      dealer_id TEXT,
      vehicle_model TEXT NOT NULL DEFAULT 'ALL',
      rule_name TEXT NOT NULL,
      rule_type TEXT NOT NULL DEFAULT 'Percentage',
      rate_pct REAL NOT NULL DEFAULT 4.5,
      fixed_amount_pkr REAL NOT NULL DEFAULT 0,
      min_sale_pkr REAL NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_comm_rules_comp ON dealer_commission_rules(company_id, is_active);

    CREATE TABLE IF NOT EXISTS dealer_targets (
      id TEXT PRIMARY KEY,
      dealer_id TEXT NOT NULL,
      company_id TEXT NOT NULL,
      period_type TEXT NOT NULL DEFAULT 'Monthly',
      period_key TEXT NOT NULL,
      vehicle_model TEXT NOT NULL DEFAULT 'ALL',
      target_units INTEGER NOT NULL DEFAULT 10,
      target_revenue_pkr REAL NOT NULL DEFAULT 0,
      assigned_by TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (dealer_id) REFERENCES dealer_accounts(id) ON DELETE CASCADE,
      FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_targets_dealer ON dealer_targets(dealer_id, period_type, period_key);

    CREATE TABLE IF NOT EXISTS dealer_audit_logs (
      id TEXT PRIMARY KEY,
      dealer_id TEXT,
      company_id TEXT,
      branch_id TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      target_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_dealer_audit_created ON dealer_audit_logs(created_at DESC);
  `);

  // Synchronize initial showrooms & default commission rules non-destructively for existing dealers
  try {
    const existingDealers = sqlite
      .prepare(`
        SELECT d.*, p.business_address, p.city
        FROM dealer_accounts d
        LEFT JOIN dealer_profiles p ON p.dealer_id = d.id
      `)
      .all() as any[];

    const tsSync = nowIso();
    for (const d of existingDealers) {
      const hasShowroom = sqlite.prepare('SELECT id FROM dealer_showrooms WHERE dealer_id = ?').get(d.id);
      if (!hasShowroom) {
        const cityStr = String(d.city || 'Karachi').trim();
        const cityPrefix = cityStr.replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase() || 'HQX';
        const ctry = String(d.country_id || 'PK').toUpperCase();
        const shwCode = `SHW-${ctry}-${cityPrefix}-${String(d.dealer_code || '').slice(-2) || '01'}`.toUpperCase();
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO dealer_showrooms (
              id, showroom_code, dealer_id, company_id, country_id, branch_id,
              name, address, country, province, city, phone, email,
              opening_hours, closing_hours, manager_name, manager_phone, manager_email,
              status, verification_status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '09:00', '20:00', ?, ?, ?, ?, ?, ?, ?, ?)
          `)
          .run(
            `shw_${d.id}`,
            shwCode,
            d.id,
            d.company_id,
            ctry,
            d.branch_id || null,
            `${d.business_name} Main Showroom`,
            d.business_address || `${cityStr} EV Corridor`,
            ctry,
            ctry === 'PK' ? (cityStr.toLowerCase().includes('karachi') ? 'Sindh' : cityStr.toLowerCase().includes('lahore') || cityStr.toLowerCase().includes('multan') ? 'Punjab' : 'ICT') : 'Dubai',
            cityStr,
            d.mobile || '',
            d.email || '',
            d.owner_contact_name || d.business_name,
            d.mobile || '',
            d.email || '',
            d.status === 'Active' ? 'Active' : 'Inactive',
            d.verification_status === 'Verified' ? 'Verified' : 'Pending Approval',
            'Synchronized primary showroom from verified dealer registry.',
            tsSync,
            tsSync
          );
      }
      // Backfill sales_date & invoice_number if null on existing sales
      sqlite
        .prepare("UPDATE dealer_sales SET sales_date = COALESCE(sales_date, substr(created_at, 1, 10)), invoice_number = COALESCE(invoice_number, 'INV-' || sale_ref), list_price_pkr = CASE WHEN list_price_pkr = 0 THEN sale_amount_pkr ELSE list_price_pkr END WHERE dealer_id = ?")
        .run(d.id);
    }

    // Seed company-wide default commission rule if none exists
    const ruleCount = (sqlite.prepare('SELECT COUNT(*) as c FROM dealer_commission_rules').get() as any)?.c || 0;
    if (ruleCount === 0) {
      const comps = sqlite.prepare("SELECT id FROM companies WHERE status = 'Approved'").all() as Array<{ id: string }>;
      for (const comp of comps) {
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO dealer_commission_rules (
              id, company_id, dealer_id, vehicle_model, rule_name, rule_type,
              rate_pct, fixed_amount_pkr, min_sale_pkr, is_active, created_by, created_at, updated_at
            ) VALUES (?, ?, NULL, 'ALL', 'Standard BYD Authorized Dealer Commission', 'Percentage', 4.5, 0, 0, 1, 'System Sync', ?, ?)
          `)
          .run(`dcr_std_${comp.id}`, comp.id, tsSync, tsSync);
      }
    }
  } catch {
    // non-fatal sync
  }

  // Synchronize existing employee salary structures non-destructively from existing salary records
  const existingEmpRows = sqlite.prepare('SELECT id, company_id, basic_salary FROM employee_accounts').all() as Array<{ id: string; company_id: string; basic_salary: number }>;
  for (const er of existingEmpRows) {
    const hasStruct = sqlite.prepare('SELECT id FROM employee_salary_structures WHERE employee_id = ?').get(er.id);
    if (!hasStruct) {
      const latestSal = sqlite
        .prepare('SELECT * FROM employee_salary_records WHERE employee_id = ? ORDER BY pay_period DESC LIMIT 1')
        .get(er.id) as any;
      if (latestSal) {
        const basic = Number(latestSal.basic_salary || latestSal.base_salary || er.basic_salary || 0);
        const ts = nowIso();
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO employee_salary_structures (
              id, employee_id, company_id, currency, basic_salary, house_allowance, medical_allowance,
              transport_allowance, other_allowances, tax_deduction, other_deductions,
              effective_from, updated_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, 'System Sync', ?, ?)
          `)
          .run(
            `ess_${er.id}`,
            er.id,
            er.company_id,
            latestSal.currency || 'PKR',
            basic,
            Math.round(Number(latestSal.allowances || 0) * 0.6),
            Math.round(Number(latestSal.allowances || 0) * 0.4),
            Number(latestSal.tax_deduction || 0),
            Number(latestSal.deductions || 0),
            ts.slice(0, 10),
            ts,
            ts
          );
        if (!er.basic_salary && basic > 0) {
          sqlite.prepare('UPDATE employee_accounts SET basic_salary = ? WHERE id = ?').run(basic, er.id);
        }
      }
    }
  }

  // Enterprise Registration, Identity Verification & Account Protection Canonical Tables
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS user_accounts (
      id TEXT PRIMARY KEY,
      subject_type TEXT NOT NULL,
      source_table TEXT NOT NULL,
      role TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      mobile TEXT,
      verified_phone TEXT,
      company_id TEXT,
      country_id TEXT,
      branch_id TEXT,
      account_code TEXT,
      status TEXT NOT NULL DEFAULT 'Pending Verification',
      verification_status TEXT NOT NULL DEFAULT 'Not Submitted',
      email_verified INTEGER NOT NULL DEFAULT 0,
      mobile_verified INTEGER NOT NULL DEFAULT 0,
      mfa_required INTEGER NOT NULL DEFAULT 0,
      mfa_enabled INTEGER NOT NULL DEFAULT 0,
      terms_accepted INTEGER NOT NULL DEFAULT 0,
      terms_accepted_at TEXT,
      privacy_accepted INTEGER NOT NULL DEFAULT 0,
      privacy_accepted_at TEXT,
      approved_by TEXT,
      approved_at TEXT,
      rejection_reason TEXT,
      last_login_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_user_accounts_verified_phone
      ON user_accounts(verified_phone)
      WHERE mobile_verified = 1 AND verified_phone IS NOT NULL AND verified_phone != '';
    CREATE INDEX IF NOT EXISTS idx_user_accounts_scope ON user_accounts(role, status, verification_status, company_id, country_id, branch_id);

    CREATE TABLE IF NOT EXISTS user_profiles (
      user_id TEXT PRIMARY KEY,
      full_name TEXT NOT NULL,
      phone TEXT,
      country TEXT,
      city TEXT,
      address TEXT,
      cnic_or_id TEXT,
      employee_code TEXT,
      dealer_code TEXT,
      customer_code TEXT,
      manager_code TEXT,
      job_title TEXT,
      department TEXT,
      company_name TEXT,
      preferred_language TEXT NOT NULL DEFAULT 'en',
      preferred_currency TEXT NOT NULL DEFAULT 'PKR',
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES user_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS user_role_assignments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      role_key TEXT NOT NULL,
      company_id TEXT,
      country_id TEXT,
      branch_id TEXT,
      scope_type TEXT NOT NULL DEFAULT 'user',
      assigned_by TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(user_id, role_key),
      FOREIGN KEY (user_id) REFERENCES user_accounts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS email_verification_tokens (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      email TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_ip TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_evt_user_created ON email_verification_tokens(user_id, created_at);

    CREATE TABLE IF NOT EXISTS mobile_verification_otps (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      phone TEXT NOT NULL,
      otp_hash TEXT NOT NULL,
      provider TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      max_attempts INTEGER NOT NULL DEFAULT 5,
      locked_until TEXT,
      used_at TEXT,
      created_ip TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mvo_user_phone ON mobile_verification_otps(user_id, phone, created_at);

    CREATE TABLE IF NOT EXISTS password_reset_tokens (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      email TEXT NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      used_at TEXT,
      created_ip TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_prt_user ON password_reset_tokens(user_id, created_at);

    CREATE TABLE IF NOT EXISTS identity_verification_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL UNIQUE,
      subject_type TEXT NOT NULL,
      role TEXT NOT NULL,
      company_id TEXT,
      country_id TEXT,
      branch_id TEXT,
      verification_status TEXT NOT NULL DEFAULT 'Not Submitted',
      email_verified INTEGER NOT NULL DEFAULT 0,
      mobile_verified INTEGER NOT NULL DEFAULT 0,
      document_count INTEGER NOT NULL DEFAULT 0,
      submitted_at TEXT,
      reviewed_by TEXT,
      reviewed_by_name TEXT,
      reviewed_by_role TEXT,
      reviewed_at TEXT,
      expires_at TEXT,
      decision_notes TEXT,
      rejection_reason TEXT,
      additional_docs_requested TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES user_accounts(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_ivr_status ON identity_verification_records(verification_status, company_id, country_id, branch_id);

    CREATE TABLE IF NOT EXISTS verification_documents (
      id TEXT PRIMARY KEY,
      verification_record_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      doc_type TEXT NOT NULL,
      title TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      storage_key TEXT NOT NULL UNIQUE,
      sha256_checksum TEXT NOT NULL,
      review_status TEXT NOT NULL DEFAULT 'Pending Review',
      reviewer_notes TEXT,
      uploaded_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (verification_record_id) REFERENCES identity_verification_records(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_vdoc_user ON verification_documents(user_id, created_at);

    CREATE TABLE IF NOT EXISTS account_approval_history (
      id TEXT PRIMARY KEY,
      target_user_id TEXT NOT NULL,
      target_subject_type TEXT NOT NULL,
      target_role TEXT NOT NULL,
      target_email TEXT NOT NULL,
      action TEXT NOT NULL,
      previous_status TEXT NOT NULL,
      new_status TEXT NOT NULL,
      reason TEXT,
      notes TEXT,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_aah_target ON account_approval_history(target_user_id, created_at);

    CREATE TABLE IF NOT EXISTS mfa_settings (
      user_id TEXT PRIMARY KEY,
      subject_type TEXT NOT NULL,
      totp_enabled INTEGER NOT NULL DEFAULT 0,
      email_otp_enabled INTEGER NOT NULL DEFAULT 0,
      sms_otp_enabled INTEGER NOT NULL DEFAULT 0,
      totp_secret TEXT,
      pending_totp_secret TEXT,
      mfa_required INTEGER NOT NULL DEFAULT 0,
      enrolled_at TEXT,
      last_verified_at TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS mfa_recovery_codes (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      code_hash TEXT NOT NULL,
      used_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mrc_user ON mfa_recovery_codes(user_id, used_at);

    CREATE TABLE IF NOT EXISTS login_activity_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      subject_type TEXT NOT NULL,
      identifier TEXT NOT NULL,
      role TEXT,
      company_id TEXT,
      country_id TEXT,
      branch_id TEXT,
      success INTEGER NOT NULL,
      failure_reason TEXT,
      mfa_method TEXT,
      ip_address TEXT,
      user_agent TEXT,
      device_fingerprint TEXT,
      suspicious INTEGER NOT NULL DEFAULT 0,
      suspicious_reason TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_lal_user ON login_activity_logs(user_id, created_at);

    CREATE TABLE IF NOT EXISTS security_audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      target_user_id TEXT,
      company_id TEXT,
      country_id TEXT,
      branch_id TEXT,
      action TEXT NOT NULL,
      category TEXT NOT NULL,
      severity TEXT NOT NULL DEFAULT 'INFO',
      details TEXT NOT NULL,
      metadata_json TEXT NOT NULL DEFAULT '{}',
      ip_address TEXT,
      user_agent TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sal_created ON security_audit_logs(created_at);
    CREATE INDEX IF NOT EXISTS idx_sal_scope ON security_audit_logs(company_id, country_id, branch_id);

    CREATE TABLE IF NOT EXISTS password_history (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      subject_type TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_pwh_user ON password_history(user_id, created_at);

    CREATE TABLE IF NOT EXISTS rbac_role_action_permissions (
      id TEXT PRIMARY KEY,
      role_key TEXT NOT NULL,
      module_key TEXT NOT NULL,
      can_view INTEGER NOT NULL DEFAULT 0,
      can_create INTEGER NOT NULL DEFAULT 0,
      can_edit INTEGER NOT NULL DEFAULT 0,
      can_delete INTEGER NOT NULL DEFAULT 0,
      can_approve INTEGER NOT NULL DEFAULT 0,
      is_locked INTEGER NOT NULL DEFAULT 0,
      updated_by TEXT,
      updated_at TEXT NOT NULL,
      UNIQUE(role_key, module_key)
    );
  `);

  ensureColumn('login_activity_logs', 'account_name', 'TEXT');
  ensureColumn('login_activity_logs', 'device_name', 'TEXT');
  ensureColumn('login_activity_logs', 'browser_name', 'TEXT');
  ensureColumn('login_activity_logs', 'session_id', 'TEXT');
  ensureColumn('login_activity_logs', 'logout_at', 'TEXT');
  ensureColumn('login_activity_logs', 'termination_reason', 'TEXT');

  ensureColumn('owner_audit_logs', 'device_name', 'TEXT');
  ensureColumn('owner_audit_logs', 'browser_name', 'TEXT');
  ensureColumn('owner_audit_logs', 'session_id', 'TEXT');
  ensureColumn('owner_audit_logs', 'user_agent', 'TEXT');

  ensureColumn('admin_activity_logs', 'device_name', 'TEXT');
  ensureColumn('admin_activity_logs', 'browser_name', 'TEXT');
  ensureColumn('admin_activity_logs', 'session_id', 'TEXT');
  ensureColumn('admin_activity_logs', 'user_agent', 'TEXT');

  seedInitialData();
  syncUnifiedSecurityRegistry();
}

function seedInitialData() {
  const now = nowIso();

  // Seed default system & AI settings if absent
  const ensureSetting = (key: string, value: unknown) => {
    const row = sqlite.prepare('SELECT key FROM system_settings WHERE key = ?').get(key);
    if (!row) {
      sqlite
        .prepare('INSERT INTO system_settings (key, value_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
        .run(key, JSON.stringify(value), 'system_bootstrap', now);
    }
  };

  ensureSetting('ai_config', {
    globalEnabled: true,
    defaultModel: 'gemini-4-hydrogen',
    allowedModels: ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'],
    dailyLimitPerCompany: 250,
    dailyLimitPerUser: 60,
    allowDocumentAnalysis: true,
    allowVoiceAssistant: true,
    requireConfirmationForSensitiveActions: true,
  });

  ensureSetting('security_policy', {
    sessionTimeoutMinutes: 120,
    idleTimeoutMinutes: Number(process.env.SESSION_IDLE_MINUTES) || 45,
    maxFailedLoginAttempts: 5,
    lockoutMinutes: 15,
    otpExpiryMinutes: 10,
    otpMaxAttempts: 5,
    otpCooldownSeconds: 60,
    passwordReuseLimit: 5,
    forgotPasswordCooldownSeconds: 60,
    require2FAForFounder: true,
    require2FAForSuperAdmin: true,
    enforce2FAForAdmins: true,
    allowMfaRecoveryCodes: true,
    requireCompanyApproval: true,
    backupSchedule: 'Daily 02:00 UTC',
    lastBackupAt: now,
  });

  // Non-destructively backfill any new security policy defaults on existing installations
  try {
    const curSecRow = sqlite.prepare("SELECT value_json FROM system_settings WHERE key = 'security_policy'").get() as { value_json?: string } | undefined;
    if (curSecRow?.value_json) {
      const parsed = JSON.parse(curSecRow.value_json);
      let dirty = false;
      const defaults: Record<string, any> = {
        otpExpiryMinutes: 10,
        otpMaxAttempts: 5,
        otpCooldownSeconds: 60,
        passwordReuseLimit: 5,
        forgotPasswordCooldownSeconds: 60,
        enforce2FAForAdmins: true,
        allowMfaRecoveryCodes: true,
      };
      for (const [k, v] of Object.entries(defaults)) {
        if (parsed[k] === undefined) {
          parsed[k] = v;
          dirty = true;
        }
      }
      if (dirty) {
        sqlite.prepare("UPDATE system_settings SET value_json = ? WHERE key = 'security_policy'").run(JSON.stringify(parsed));
      }
    }
  } catch {
    // ignore malformed json
  }

  // Seed canonical 6-Role x 10-Module RBAC Action Matrix (Founder permissions immutable/locked)
  const matrixSeed: Array<{
    role: string;
    locked?: boolean;
    modules: Record<string, [number, number, number, number, number]>;
  }> = [
    {
      role: 'Founder / CEO',
      locked: true,
      modules: Object.fromEntries(RBAC_MODULES.map((m) => [m, [1, 1, 1, 1, 1]])),
    },
    {
      role: 'Super Admin',
      modules: {
        'Vehicles & Inventory': [1, 1, 1, 0, 1],
        'Bookings & Service': [1, 1, 1, 0, 1],
        'Companies & Branches': [1, 1, 1, 0, 1],
        Dealerships: [1, 1, 1, 0, 1],
        'Customers & CRM': [1, 1, 1, 0, 1],
        'Employees & HR': [1, 1, 1, 0, 1],
        'Finance & Invoices': [1, 1, 1, 0, 1],
        'RBAC & Roles': [1, 0, 1, 0, 0],
        'Security & Audit Logs': [1, 0, 0, 0, 1],
        'System & Backup': [1, 0, 1, 0, 0],
      },
    },
    {
      role: 'Admin',
      modules: {
        'Vehicles & Inventory': [1, 1, 1, 0, 1],
        'Bookings & Service': [1, 1, 1, 0, 1],
        'Companies & Branches': [1, 0, 1, 0, 0],
        Dealerships: [1, 1, 1, 0, 1],
        'Customers & CRM': [1, 1, 1, 0, 1],
        'Employees & HR': [1, 1, 1, 0, 1],
        'Finance & Invoices': [1, 1, 1, 0, 1],
        'RBAC & Roles': [1, 0, 0, 0, 0],
        'Security & Audit Logs': [1, 0, 0, 0, 0],
        'System & Backup': [0, 0, 0, 0, 0],
      },
    },
    {
      role: 'Employees',
      modules: {
        'Vehicles & Inventory': [1, 0, 1, 0, 0],
        'Bookings & Service': [1, 1, 1, 0, 0],
        'Companies & Branches': [1, 0, 0, 0, 0],
        Dealerships: [1, 0, 0, 0, 0],
        'Customers & CRM': [1, 1, 1, 0, 0],
        'Employees & HR': [1, 0, 0, 0, 0],
        'Finance & Invoices': [1, 0, 0, 0, 0],
        'RBAC & Roles': [0, 0, 0, 0, 0],
        'Security & Audit Logs': [0, 0, 0, 0, 0],
        'System & Backup': [0, 0, 0, 0, 0],
      },
    },
    {
      role: 'Dealers',
      modules: {
        'Vehicles & Inventory': [1, 0, 1, 0, 0],
        'Bookings & Service': [1, 1, 1, 0, 0],
        'Companies & Branches': [0, 0, 0, 0, 0],
        Dealerships: [1, 0, 0, 0, 0],
        'Customers & CRM': [1, 1, 1, 0, 0],
        'Employees & HR': [0, 0, 0, 0, 0],
        'Finance & Invoices': [1, 1, 0, 0, 0],
        'RBAC & Roles': [0, 0, 0, 0, 0],
        'Security & Audit Logs': [0, 0, 0, 0, 0],
        'System & Backup': [0, 0, 0, 0, 0],
      },
    },
    {
      role: 'Customers',
      modules: {
        'Vehicles & Inventory': [1, 0, 0, 0, 0],
        'Bookings & Service': [1, 1, 0, 0, 0],
        'Companies & Branches': [0, 0, 0, 0, 0],
        Dealerships: [1, 0, 0, 0, 0],
        'Customers & CRM': [1, 0, 1, 0, 0],
        'Employees & HR': [0, 0, 0, 0, 0],
        'Finance & Invoices': [1, 0, 0, 0, 0],
        'RBAC & Roles': [0, 0, 0, 0, 0],
        'Security & Audit Logs': [0, 0, 0, 0, 0],
        'System & Backup': [0, 0, 0, 0, 0],
      },
    },
  ];

  const insRbac = sqlite.prepare(`
    INSERT OR IGNORE INTO rbac_role_action_permissions (
      id, role_key, module_key, can_view, can_create, can_edit, can_delete, can_approve, is_locked, updated_by, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'system_bootstrap', ?)
  `);
  for (const r of matrixSeed) {
    for (const mod of RBAC_MODULES) {
      const [v, c, e, d, a] = r.modules[mod] || [0, 0, 0, 0, 0];
      const cleanId = `rbac_${r.role.replace(/[^a-z0-9]+/gi, '_').toLowerCase()}_${mod.replace(/[^a-z0-9]+/gi, '_').toLowerCase()}`;
      insRbac.run(cleanId, r.role, mod, v, c, e, d, a, r.locked ? 1 : 0, now);
    }
  }

  ensureSetting('app_operational_settings', {
    defaultSupportEmail: 'support@bydpakistan360.demo',
    tollFreeHelpline: '0800-293-75',
    bookingAutoConfirm: true,
    maintenanceBannerEnabled: false,
    maintenanceBannerText: '',
    serviceSlaHours: 24,
    warrantyReviewSlaHours: 48,
    defaultDisplayCurrency: 'PKR',
  });

  // Canonical 14 Super Admin Permissions in role_permissions
  const canonicalPermissions: Array<{ key: string; desc: string }> = [
    { key: 'users.view', desc: 'View registered users, companies, and operational profiles' },
    { key: 'users.create', desc: 'Provision authorized non-admin employee, dealer, and customer accounts' },
    { key: 'users.update', desc: 'Update user details, verification status, and non-admin roles' },
    { key: 'users.suspend', desc: 'Suspend or reactivate non-admin user accounts and revoke sessions' },
    { key: 'employees.manage', desc: 'Create and manage company/branch employee accounts' },
    { key: 'dealers.manage', desc: 'Manage 3S/2S dealerships, branches, and approve/reject dealer registrations' },
    { key: 'customers.manage', desc: 'Verify, support, and manage customer accounts' },
    { key: 'vehicles.manage', desc: 'Register and manage national vehicle inventory' },
    { key: 'bookings.manage', desc: 'Monitor and update test drives, reservations, and service bookings' },
    { key: 'sales.view', desc: 'View vehicle sales and payment transaction records' },
    { key: 'reports.view', desc: 'Access executive operational and regional performance reports' },
    { key: 'notifications.manage', desc: 'Send and manage system announcements and notifications' },
    { key: 'settings.manage', desc: 'Manage permitted non-Founder application operational settings' },
    { key: 'audit_logs.view', desc: 'View admin activity logs, login history, and security events' },
  ];

  const insertRolePerm = sqlite.prepare(`
    INSERT OR IGNORE INTO role_permissions (id, role_key, permission_key, description, created_at)
    VALUES (?, ?, ?, ?, ?)
  `);
  for (const p of canonicalPermissions) {
    insertRolePerm.run(`rp_sa_${p.key}`, 'Super Admin', p.key, p.desc, now);
  }

  // Seed 12 Core Account Types + Mapped Enterprise Roles
  const allSaPermKeys = canonicalPermissions.map((p) => p.key);
  const roles = [
    { id: 'role_founder', key: 'Founder / Owner', name: 'Founder / Owner (Primary Owner)', cat: 'Global Owner', lvl: 100, perms: ['*'] },
    { id: 'role_super_admin', key: 'Super Admin', name: 'Super Admin', cat: 'Platform Governance', lvl: 90, perms: allSaPermKeys },
    { id: 'role_company_admin', key: 'Company Admin', name: 'Company Admin', cat: 'Company Management', lvl: 80, perms: ['manage_company_staff', 'manage_dealerships', 'view_company_reports', 'manage_vehicles', 'manage_finance'] },
    { id: 'role_hq_staff', key: 'Head Office Staff', name: 'Head Office Staff', cat: 'Head Office', lvl: 70, perms: ['view_company_ops', 'manage_inventory', 'view_reports'] },
    { id: 'role_dealer_mgr', key: 'Dealership Manager', name: 'Dealership Manager', cat: 'Dealership', lvl: 60, perms: ['manage_branch_staff', 'manage_sales', 'manage_service', 'manage_transfers'] },
    { id: 'role_dealer_staff', key: 'Dealership Staff', name: 'Dealership Staff', cat: 'Dealership', lvl: 50, perms: ['view_branch_ops', 'assist_customers'] },
    { id: 'role_sales_mgr', key: 'Sales Manager', name: 'Sales Manager', cat: 'Sales', lvl: 55, perms: ['manage_sales_pipeline', 'approve_bookings', 'view_sales_reports'] },
    { id: 'role_sales_exec', key: 'Sales Executive', name: 'Sales Executive', cat: 'Sales', lvl: 40, perms: ['manage_own_leads', 'schedule_test_drives'] },
    { id: 'role_finance_mgr', key: 'Finance Manager', name: 'Finance Manager', cat: 'Finance', lvl: 65, perms: ['manage_invoices', 'reconcile_payments', 'view_financials'] },
    { id: 'role_service_mgr', key: 'Service Manager', name: 'Service Manager', cat: 'Aftersales', lvl: 60, perms: ['manage_job_cards', 'assign_technicians', 'approve_warranty'] },
    { id: 'role_tech_support', key: 'Technical Support', name: 'Technical Support', cat: 'Technical', lvl: 45, perms: ['update_job_cards', 'upload_battery_diagnostics', 'view_support_tickets'] },
    { id: 'role_customer', key: 'Customer', name: 'Customer', cat: 'Customer', lvl: 10, perms: ['view_own_vehicles', 'book_service', 'view_own_invoices', 'submit_warranty'] },
  ];

  const insertRole = sqlite.prepare(`
    INSERT OR IGNORE INTO user_roles (id, role_key, display_name, category, hierarchy_level, permissions_json)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  for (const r of roles) {
    insertRole.run(r.id, r.key, r.name, r.cat, r.lvl, JSON.stringify(r.perms));
  }

  // Optional env-based initial Founder provisioning (ONLY when explicit env vars exist; never hardcoded!)
  const existingFounderCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM founder_accounts').get() as { cnt: number }).cnt;
  if (existingFounderCount === 0 && process.env.FOUNDER_INIT_EMAIL && process.env.FOUNDER_INIT_PASSWORD) {
    const envEmail = process.env.FOUNDER_INIT_EMAIL.trim().toLowerCase();
    const envMobile = (process.env.FOUNDER_INIT_MOBILE || '+92-300-0000001').trim();
    const strength = validatePasswordStrength(process.env.FOUNDER_INIT_PASSWORD);
    if (strength.valid) {
      const secret = process.env.FOUNDER_INIT_TOTP_SECRET || generateTotpSecret();
      sqlite
        .prepare(`
          INSERT INTO founder_accounts (
            id, founder_name, role, account_type, access_level, email, mobile,
            password_hash, two_factor_enabled, two_factor_secret, recovery_codes_json,
            is_verified, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 1, ?)
        `)
        .run(
          'founder_intekhab_alam',
          'Intekhab Alam',
          'Founder & CEO',
          'Primary Owner',
          'Global Owner',
          envEmail,
          envMobile,
          hashPassword(process.env.FOUNDER_INIT_PASSWORD),
          secret,
          JSON.stringify([]),
          now
        );
    }
  }

  // Optional env-based initial Super Admin provisioning (ONLY when explicit env vars exist; never hardcoded!)
  const existingSaCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM super_admin_accounts').get() as { cnt: number }).cnt;
  if (existingSaCount === 0 && process.env.SUPER_ADMIN_INIT_EMAIL && process.env.SUPER_ADMIN_INIT_PASSWORD) {
    const saEnvEmail = process.env.SUPER_ADMIN_INIT_EMAIL.trim().toLowerCase();
    const saEnvMobile = (process.env.SUPER_ADMIN_INIT_MOBILE || '+92-300-0000002').trim();
    const saStrength = validatePasswordStrength(process.env.SUPER_ADMIN_INIT_PASSWORD);
    if (saStrength.valid) {
      const saId = 'sa_env_initial';
      const saSecret = process.env.SUPER_ADMIN_INIT_TOTP_SECRET || generateTotpSecret();
      sqlite
        .prepare(`
          INSERT INTO super_admin_accounts (
            id, full_name, email, mobile, password_hash, country, city, status,
            email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
            authorized_by_founder_id, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, 'PK', 'Karachi', 'Active', 1, 1, ?, ?, 'env_bootstrap', ?, ?)
        `)
        .run(saId, process.env.SUPER_ADMIN_INIT_NAME || 'Initial Super Admin', saEnvEmail, saEnvMobile, hashPassword(process.env.SUPER_ADMIN_INIT_PASSWORD), saSecret, JSON.stringify([]), now, now);

      sqlite
        .prepare('INSERT OR IGNORE INTO user_permissions (user_id, permissions_json, updated_by, updated_at) VALUES (?, ?, ?, ?)')
        .run(saId, JSON.stringify(allSaPermKeys), 'env_bootstrap', now);
    }
  }

  // Seed baseline Enterprise Companies if empty (never touches founder_accounts)
  const compCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM companies').get() as { cnt: number }).cnt;
  if (compCount === 0) {
    const insertComp = sqlite.prepare(`
      INSERT INTO companies (
        id, name, country, city, official_email, phone, address, registration_details,
        authorized_rep, status, ai_enabled, ai_daily_limit, approved_by, approved_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 250, ?, ?, ?)
    `);

    insertComp.run(
      'comp_byd_pk',
      'Mega Motor Company (BYD Pakistan Evaluation)',
      'PK',
      'Karachi',
      'hq@megamotor.demo',
      '+92 21 111 293 750',
      'Clifton Block 4, Shahrah-e-Faisal EV Corridor, Karachi',
      'SECP-REG-PK-2025-88412',
      'Sarmad Khawaja',
      'Approved',
      'System Bootstrap',
      now,
      now
    );

    insertComp.run(
      'comp_byd_ae',
      'Al-Futtaim Electric Mobility UAE (Demo)',
      'AE',
      'Dubai',
      'ops@byduae.demo',
      '+971 4 800 293',
      'Dubai Festival City Automotive Zone, UAE',
      'DED-UAE-992104',
      'Rashid Al-Nuaimi',
      'Approved',
      'System Bootstrap',
      now,
      now
    );

    insertComp.run(
      'comp_lahore_fleet',
      'Punjab Green Transit Corp (Pending Evaluation)',
      'PK',
      'Lahore',
      'fleet@punjabgreen.demo',
      '+92 42 35789100',
      'Gulberg III Commercial Zone, Lahore',
      'SECP-LHR-2026-44109',
      'Kamran Cheema',
      'Pending Approval',
      null,
      null,
      now
    );
  }

  // Seed baseline Demo Dealerships if empty
  const dlrCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM dealerships').get() as { cnt: number }).cnt;
  if (dlrCount === 0) {
    const insDlr = sqlite.prepare(`
      INSERT INTO dealerships (
        id, company_id, name, code, country, city, address, manager_name, phone, email,
        facility_type, status, active_techs, service_bays, monthly_target_units, achieved_units,
        monthly_revenue_pkr, rating, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insDlr.run('dlr_khi_clifton', 'comp_byd_pk', 'Mega Motor Flagship 3S — Clifton', 'BYD-KHI-01', 'PK', 'Karachi', 'Plot 14-C, Marine Drive, Clifton Block 2', 'Farhan Zaidi', '+92 21 35291000', 'clifton@megamotor.demo', '3S Flagship Centre', 'Approved', 14, 10, 45, 39, 585000000, 4.9, now);
    insDlr.run('dlr_lhr_gulberg', 'comp_byd_pk', 'BYD Lahore Central 3S — Gulberg III', 'BYD-LHR-01', 'PK', 'Lahore', '88-Main Boulevard, Gulberg III, Lahore', 'Zainab Tariq', '+92 42 35771200', 'lahore@megamotor.demo', '3S Flagship Centre', 'Approved', 12, 8, 40, 34, 492000000, 4.8, now);
    insDlr.run('dlr_isb_bluearea', 'comp_byd_pk', 'BYD Capital Hub 3S — Blue Area', 'BYD-ISB-01', 'PK', 'Islamabad', 'Jinnah Avenue Sector F-7, Islamabad', 'Engr. Bilal Hashmi', '+92 51 2801400', 'islamabad@megamotor.demo', '3S Flagship Centre', 'Approved', 10, 6, 30, 27, 395000000, 4.9, now);
    insDlr.run('dlr_dxb_dfc', 'comp_byd_ae', 'BYD Dubai Flagship Discovery Centre', 'BYD-AE-01', 'AE', 'Dubai', 'Festival City Boulevard, Dubai', 'Rashid Al-Nuaimi', '+971 4 2066000', 'dubai@byduae.demo', '3S Flagship Centre', 'Approved', 18, 14, 70, 66, 980000000, 4.9, now);
    insDlr.run('dlr_mlt_pending', 'comp_byd_pk', 'BYD Multan Southern EV 3S (Applicant)', 'BYD-MLT-P1', 'PK', 'Multan', 'Boson Road Automotive Corridor, Multan', 'Salman Gillani', '+92 61 6521100', 'multan.applicant@evdealer.demo', '3S Flagship Centre', 'Pending Approval', 6, 4, 20, 0, 0, 4.7, now);
  }

  // Seed baseline non-Founder, non-SuperAdmin evaluation users (never hardcodes Founder or Super Admin!)
  const usrCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number }).cnt;
  if (usrCount === 0) {
    const demoPassHash = hashPassword('BYD-Enterprise-2026!');
    const insUsr = sqlite.prepare(`
      INSERT INTO users (
        id, company_id, username, full_name, email, mobile, password_hash, role,
        country, city, dealership_id, status, email_verified, mobile_verified,
        two_factor_enabled, created_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, 0, 'system_seed', ?, ?)
    `);

    insUsr.run('usr_comp_pk', 'comp_byd_pk', 'sarmad_md', 'Sarmad Khawaja', 'sarmad.khawaja@megamotor.demo', '+92 321 4509922', demoPassHash, 'Company Admin', 'PK', 'Islamabad', null, now, now);
    insUsr.run('usr_comp_ae', 'comp_byd_ae', 'rashid_uae', 'Rashid Al-Nuaimi', 'rashid.nuaimi@byduae.demo', '+971 50 1234567', demoPassHash, 'Company Admin', 'AE', 'Dubai', 'dlr_dxb_dfc', now, now);
    insUsr.run('usr_dealer_1', 'comp_byd_pk', 'farhan_zaidi', 'Farhan Zaidi', 'farhan.zaidi@megamotor.demo', '+92 333 2198844', demoPassHash, 'Dealership Manager', 'PK', 'Karachi', 'dlr_khi_clifton', now, now);
    insUsr.run('usr_sales_mgr', 'comp_byd_pk', 'mansoor_sales', 'Mansoor Akhtar', 'mansoor.sales@megamotor.demo', '+92 301 7766554', demoPassHash, 'Sales Manager', 'PK', 'Karachi', 'dlr_khi_clifton', now, now);
    insUsr.run('usr_svc_1', 'comp_byd_pk', 'bilal_hashmi', 'Engr. Bilal Hashmi', 'bilal.hashmi@bydisb.demo', '+92 345 8899123', demoPassHash, 'Service Manager', 'PK', 'Islamabad', 'dlr_isb_bluearea', now, now);
    insUsr.run('usr_tech_1', 'comp_byd_pk', 'hamza_tech', 'Hamza Rafiq', 'hamza.tech@bydworkshop.demo', '+92 312 9944321', demoPassHash, 'Technical Support', 'PK', 'Karachi', 'dlr_khi_clifton', now, now);
    insUsr.run('usr_finance_1', 'comp_byd_pk', 'shahida_cfo', 'Shahida Parveen', 'shahida.parveen@bydfinance.demo', '+92 302 6677889', demoPassHash, 'Finance Manager', 'PK', 'Karachi', null, now, now);
    insUsr.run('usr_cust_1', 'comp_byd_pk', 'zubair_qureshi', 'Zubair Ahmed Qureshi', 'zubair.qureshi@techpk.demo', '+92 302 8561234', demoPassHash, 'Customer', 'PK', 'Karachi', 'dlr_khi_clifton', now, now);
    insUsr.run('usr_cust_ae', 'comp_byd_ae', 'omar_mansoor', 'Omar Al-Mansoor', 'omar.mansoor@byduae.demo', '+971 52 9981122', demoPassHash, 'Customer', 'AE', 'Dubai', 'dlr_dxb_dfc', now, now);
  }

  // Seed Vehicles if empty
  const vehCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM vehicles').get() as { cnt: number }).cnt;
  if (vehCount === 0) {
    const insVeh = sqlite.prepare(`
      INSERT INTO vehicles (
        id, company_id, dealership_id, vin, chassis_number, model, variant, color, year,
        license_plate, owner_id, owner_name, owner_phone, owner_city, registration_date,
        odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
        warranty_expiry_date, last_service_date, next_service_due_km, status,
        dealership_purchased, sale_price_pkr, sold_at, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insVeh.run('veh_pk_01', 'comp_byd_pk', 'dlr_khi_clifton', 'BYD-PK-2026-100001', 'CH-PK-2026-100001', 'BYD ATTO 3', 'Electric SUV', 'Surf Blue', 2026, 'KHI-EV-001', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Karachi', '2026-01-15', 0, 60.48, 98.5, 85, '2034-01-15', now, 10000, 'Active', 'Mega Motor Flagship 3S — Clifton', 8990000, null, now);
    insVeh.run('veh_pk_02', 'comp_byd_pk', 'dlr_khi_clifton', 'BYD-PK-2026-100002', 'CH-PK-2026-100002', 'BYD ATTO 2', 'Electric SUV', 'Atlantis Grey', 2026, 'KHI-EV-002', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Karachi', '2026-02-10', 0, 45.1, 98.5, 85, '2034-02-10', now, 10000, 'Active', 'Mega Motor Flagship 3S — Clifton', 7490000, null, now);
    insVeh.run('veh_pk_03', 'comp_byd_pk', 'dlr_lhr_gulberg', 'BYD-PK-2026-100003', 'CH-PK-2026-100003', 'BYD SEAL', 'Electric Sedan', 'Shark Grey', 2026, 'LHR-EV-001', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Lahore', '2026-03-05', 0, 82.5, 98.5, 85, '2034-03-05', now, 10000, 'Active', 'BYD Lahore Central 3S — Gulberg III', 16990000, null, now);
    insVeh.run('veh_pk_04', 'comp_byd_pk', 'dlr_isb_bluearea', 'BYD-PK-2026-100004', 'CH-PK-2026-100004', 'BYD SEALION 6', 'Plug-in Hybrid SUV', 'Harbour Blue', 2026, 'ISB-EV-001', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Islamabad', '2026-04-20', 0, 18.3, 98.5, 85, '2034-04-20', now, 10000, 'Active', 'BYD Capital Hub 3S — Blue Area', 12490000, null, now);
    insVeh.run('veh_pk_05', 'comp_byd_pk', 'dlr_isb_bluearea', 'BYD-PK-2026-100005', 'CH-PK-2026-100005', 'BYD SEALION 7', 'Electric SUV', 'Aurora White', 2026, 'ISB-EV-002', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Islamabad', '2026-05-12', 0, 82.5, 98.5, 85, '2034-05-12', now, 10000, 'Active', 'BYD Capital Hub 3S — Blue Area', 18750000, null, now);
    insVeh.run('veh_pk_06', 'comp_byd_pk', 'dlr_khi_clifton', 'BYD-PK-2026-100006', 'CH-PK-2026-100006', 'BYD SHARK 6', 'Plug-in Hybrid Pickup', 'Ski Grey', 2026, 'KHI-EV-003', null, 'Mega Motor Fleet Inventory', '+92 111 111 293', 'Karachi', '2026-06-01', 0, 18.3, 98.5, 85, '2034-06-01', now, 10000, 'Active', 'Mega Motor Flagship 3S — Clifton', 15250000, null, now);
  }

  // Seed Service Jobs if empty
  const jobCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM service_jobs').get() as { cnt: number }).cnt;
  if (jobCount === 0) {
    sqlite
      .prepare(`
        INSERT INTO service_jobs (
          id, company_id, ticket_number, vehicle_id, vin, model, license_plate,
          customer_id, customer_name, customer_phone, dealership_id, dealership_name,
          service_type, scheduled_date, scheduled_time, status, technician_assigned,
          estimated_cost_pkr, checklist_json, parts_used_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        'svc_job_1',
        'comp_byd_pk',
        'BYD-SVC-2026-841',
        'veh_01',
        'LGXCE43C5R0108924',
        'BYD Seal',
        'KHI-EV-902',
        'usr_cust_1',
        'Zubair Ahmed Qureshi',
        '+92 302 8561234',
        'dlr_khi_clifton',
        'Mega Motor Flagship 3S — Clifton',
        'Blade Battery Health Diagnostic',
        '2026-11-18',
        '10:30 AM',
        'In Progress',
        'Hamza Rafiq',
        12500,
        JSON.stringify({
          hvLockChecked: true,
          bladeBatteryScanned: true,
          coolantLevelInspected: true,
          brakePadThicknessMm: 10.2,
          tirePressurePsi: 36,
          firmwareVersion: 'BYD-OS-14.2.1-PK',
          roadTestCompleted: false,
        }),
        '[]',
        now
      );
  }

  // Seed Invoices if empty
  const invCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM payments_invoices').get() as { cnt: number }).cnt;
  if (invCount === 0) {
    const insInv = sqlite.prepare(`
      INSERT INTO payments_invoices (
        id, company_id, invoice_number, customer_id, customer_name, country, currency,
        dealership_name, item_category, subtotal, tax_rate, tax_amount, total_amount,
        status, payment_gateway, transaction_ref, issued_date, due_date, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insInv.run('inv_pk_1', 'comp_byd_pk', 'INV-BYD-PK-2026-10421', 'usr_cust_1', 'Zubair Ahmed Qureshi', 'PK', 'PKR', 'Mega Motor Flagship 3S — Clifton', 'Vehicle Purchase', 14400000, 18, 2592000, 16992000, 'Paid', '1LINK PayPak', 'AUTH-PK-884120', '2026-02-15', '2026-02-15', now);
    insInv.run('inv_ae_1', 'comp_byd_ae', 'INV-BYD-AE-2026-20911', 'usr_cust_ae', 'Omar Al-Mansoor', 'AE', 'AED', 'BYD Dubai Flagship Discovery Centre', 'Vehicle Purchase', 180000, 5, 9000, 189000, 'Paid', 'FAB UAE Direct', 'AUTH-AE-552104', '2026-03-18', '2026-03-18', now);
  }

  // Seed Warranty Claim if empty
  const warCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM warranty_claims').get() as { cnt: number }).cnt;
  if (warCount === 0) {
    sqlite
      .prepare(`
        INSERT INTO warranty_claims (
          id, company_id, claim_number, vin, vehicle_model, customer_id, customer_name,
          customer_phone, dealership_name, component_category, issue_description, fault_code,
          submission_date, status, claim_amount_pkr, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        'war_pk_1',
        'comp_byd_pk',
        'CLM-BYD-2026-309',
        'LGXCE43C5R0108924',
        'BYD Seal',
        'usr_cust_1',
        'Zubair Ahmed Qureshi',
        '+92 302 8561234',
        'Mega Motor Flagship 3S — Clifton',
        'Infotainment System',
        'Scheduled screen rotation calibration & telemetry antenna check.',
        'INFO-CAL-102',
        '2026-11-01',
        'Approved',
        45000,
        now
      );
  }

  // Seed initial Support Requests if empty
  const supCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM support_requests').get() as { cnt: number }).cnt;
  if (supCount === 0) {
    const insSup = sqlite.prepare(`
      INSERT INTO support_requests (
        id, ticket_number, company_id, user_id, requester_name, requester_email,
        category, priority, subject, description, status, assigned_to, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insSup.run('sup_1', 'SUP-2026-101', 'comp_byd_pk', 'usr_cust_1', 'Zubair Ahmed Qureshi', 'zubair.qureshi@techpk.demo', 'Home Wallbox Installation', 'High', 'Schedule 7kW AC Wallbox inspection at Clifton residence', 'Requested certified electrical survey prior to charger mounting.', 'Open', 'Engr. Bilal Hashmi', now, now);
    insSup.run('sup_2', 'SUP-2026-102', 'comp_byd_pk', 'usr_dealer_1', 'Farhan Zaidi', 'farhan.zaidi@megamotor.demo', 'DMS Access & Fleet Sync', 'Medium', 'Enable batch VIN registration for November shipment', 'Preparing 18 BYD Seal & Atto 3 units for PDI.', 'In Progress', 'Super Admin Desk', now, now);
  }

  // Seed baseline System Notification if empty
  const notifCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM notifications').get() as { cnt: number }).cnt;
  if (notifCount === 0) {
    sqlite
      .prepare('INSERT INTO notifications (id, company_id, user_id, title, message, category, is_read, created_at) VALUES (?, NULL, NULL, ?, ?, ?, 0, ?)')
      .run('ntf_sys_1', 'Q4 Blade Battery Diagnostic Protocol Active', 'All 3S centres must attach BMS cell-balance telemetry during routine 10,000 km inspections.', 'Announcement', now);
  }

  // Seed & Sync Company Branches, Company Admin Accounts, Company Permissions, Roles, Employee Accounts & CRM
  const branchCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM company_branches').get() as { cnt: number }).cnt;
  if (branchCount === 0) {
    const insBr = sqlite.prepare(`
      INSERT INTO company_branches (
        id, company_id, name, code, country, city, address, manager_id, manager_name,
        phone, email, monthly_target_units, achieved_units, monthly_revenue_pkr, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
    `);
    insBr.run('br_pk_khi', 'comp_byd_pk', 'Karachi Southern HQ & Clifton Flagship', 'BR-KHI-01', 'PK', 'Karachi', 'Clifton Block 4, Shahrah-e-Faisal EV Corridor', 'usr_dealer_1', 'Farhan Zaidi', '+92 21 35291000', 'khi.branch@megamotor.demo', 45, 39, 585000000, now, now);
    insBr.run('br_pk_lhr', 'comp_byd_pk', 'Lahore Central Hub — Gulberg III', 'BR-LHR-01', 'PK', 'Lahore', '88-Main Boulevard, Gulberg III, Lahore', 'usr_sales_mgr', 'Zainab Tariq', '+92 42 35771200', 'lhr.branch@megamotor.demo', 40, 34, 492000000, now, now);
    insBr.run('br_pk_isb', 'comp_byd_pk', 'Islamabad Capital Branch — Blue Area', 'BR-ISB-01', 'PK', 'Islamabad', 'Jinnah Avenue Sector F-7, Islamabad', 'usr_svc_1', 'Engr. Bilal Hashmi', '+92 51 2801400', 'isb.branch@megamotor.demo', 30, 27, 395000000, now, now);
    insBr.run('br_ae_dxb', 'comp_byd_ae', 'Dubai Discovery Flagship Branch', 'BR-DXB-01', 'AE', 'Dubai', 'Festival City Boulevard, Dubai', null, 'Rashid Al-Nuaimi', '+971 4 2066000', 'dxb.branch@byduae.demo', 70, 66, 980000000, now, now);

    // Link existing vehicles to primary branches cleanly
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_khi' WHERE id = 'veh_pk_01' AND branch_id IS NULL").run();
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_khi' WHERE id = 'veh_pk_02' AND branch_id IS NULL").run();
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_lhr' WHERE id = 'veh_pk_03' AND branch_id IS NULL").run();
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_isb', delivery_status = 'In Stock' WHERE id = 'veh_pk_04' AND branch_id IS NULL").run();
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_isb', delivery_status = 'In Stock' WHERE id = 'veh_pk_05' AND branch_id IS NULL").run();
    sqlite.prepare("UPDATE vehicles SET branch_id = 'br_pk_khi' WHERE id = 'veh_pk_06' AND branch_id IS NULL").run();
  }

  // Enrich company profile metadata with real BYD data
  sqlite
    .prepare("UPDATE companies SET website = 'https://www.byd.com/', tax_id = 'HKEX-01211 • SZSE-002594', business_info_json = ? WHERE id = 'comp_byd_global' AND (business_info_json = '{}' OR business_info_json IS NULL)")
    .run(JSON.stringify({ industry: 'Automotive & Technology — Electric Vehicles, Batteries, Renewable Energy', founded: 1994, automotiveSince: 2003, founder: 'Wang Chuanfu', chairman: 'Wang Chuanfu', hq: 'Shenzhen, Guangdong, China', stockExchanges: ['Hong Kong: 01211.HK', 'Shenzhen: 002594.SZ'], operatingHours: '09:00 - 18:00 CST', globalPresence: '120+ countries and regions', source: 'https://www.byd.com/', verified: true }));
  sqlite
    .prepare("UPDATE companies SET website = 'https://byd-mega.com/', tax_id = 'PACRA-Registered 6 May 2024', business_info_json = ? WHERE id = 'comp_byd_pk' AND (business_info_json = '{}' OR business_info_json IS NULL)")
    .run(JSON.stringify({ industry: 'Electric Vehicle Import, Retail & 3S Aftersales — BYD Authorized Distributor Pakistan', founded: 2024, authorizedPartner: 'BYD Auto Industry Company Limited, China', ceo: 'Aly Khan', cfo: 'Abdus Salam Bawany', hq: '9th Floor, Ocean Tower, Block 9, Main Clifton Road, Karachi, Pakistan', customerContact: '+92 111 111 293', operatingHours: 'Monday to Friday, 9:00 AM–6:00 PM PKT', fleetCapacity: 25000, serviceSlaHours: 24, gharoFactory: 'Gharo, District Thatta, Sindh — Under Construction', source: 'https://byd-mega.com/ • https://www.pacra.com/', verified: true }));

  const defaultCompanyAdminPerms = [
    'company.profile.manage',
    'employees.manage',
    'employees.permissions.manage',
    'branches.manage',
    'dealers.manage',
    'vehicles.manage',
    'customers.manage',
    'sales.manage',
    'finance.manage',
    'reports.view',
    'reports.export',
  ];

  // Seed company_user_roles per approved company
  const curCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM company_user_roles').get() as { cnt: number }).cnt;
  if (curCount === 0) {
    const insCur = sqlite.prepare(`
      INSERT OR IGNORE INTO company_user_roles (id, company_id, role_key, display_name, department, permissions_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const baseCompanyRoles = [
      { key: 'Head Office Staff', dept: 'Head Office', perms: ['employees.manage', 'vehicles.manage', 'reports.view'] },
      { key: 'Dealership Manager', dept: 'Dealership Operations', perms: ['branches.manage', 'vehicles.manage', 'sales.manage'] },
      { key: 'Dealership Staff', dept: 'Dealership Operations', perms: ['vehicles.manage', 'customers.manage'] },
      { key: 'Sales Manager', dept: 'Sales & Retail', perms: ['sales.manage', 'customers.manage', 'reports.view'] },
      { key: 'Sales Executive', dept: 'Sales & Retail', perms: ['customers.manage'] },
      { key: 'Finance Manager', dept: 'Finance', perms: ['finance.manage', 'sales.manage', 'reports.view', 'reports.export'] },
      { key: 'Service Manager', dept: 'Aftersales & Workshop', perms: ['vehicles.manage', 'customers.manage'] },
      { key: 'Technical Support', dept: 'Aftersales & Workshop', perms: ['vehicles.manage'] },
    ];
    for (const compId of ['comp_byd_pk', 'comp_byd_ae']) {
      for (const r of baseCompanyRoles) {
        insCur.run(`cur_${compId}_${r.key.toLowerCase().replace(/\s+/g, '_')}`, compId, r.key, r.key, r.dept, JSON.stringify(r.perms), now);
      }
    }
  }

  // Provision separate Company Admin accounts into company_admin_accounts non-destructively
  const caCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM company_admin_accounts').get() as { cnt: number }).cnt;
  if (caCount === 0) {
    const insCa = sqlite.prepare(`
      INSERT OR IGNORE INTO company_admin_accounts (
        id, company_id, full_name, username, email, mobile, password_hash, designation,
        status, email_verified, two_factor_enabled, two_factor_secret, recovery_codes_json,
        authorized_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, ?, ?, 'system_seed', ?, ?)
    `);

    const pkPass = process.env.COMPANY_ADMIN_INIT_PASSWORD
      ? hashPassword(process.env.COMPANY_ADMIN_INIT_PASSWORD)
      : hashPassword('BYD-Enterprise-2026!');
    const pkSecret = generateTotpSecret();
    const aeSecret = generateTotpSecret();

    insCa.run('ca_byd_pk', 'comp_byd_pk', 'Sarmad Khawaja', 'sarmad_company_admin', 'sarmad.khawaja@megamotor.demo', '+92 321 4509922', pkPass, 'Managing Director & Company Admin', pkSecret, JSON.stringify([]), now, now);
    insCa.run('ca_byd_ae', 'comp_byd_ae', 'Rashid Al-Nuaimi', 'rashid_company_admin', 'rashid.nuaimi@byduae.demo', '+971 50 1234567', pkPass, 'UAE Country & Company Admin', aeSecret, JSON.stringify([]), now, now);

    const insCp = sqlite.prepare(`
      INSERT OR IGNORE INTO company_permissions (id, company_id, subject_id, permissions_json, updated_by, updated_at)
      VALUES (?, ?, ?, ?, 'system_seed', ?)
    `);
    insCp.run('cp_ca_byd_pk', 'comp_byd_pk', 'ca_byd_pk', JSON.stringify(defaultCompanyAdminPerms), now);
    insCp.run('cp_ca_byd_ae', 'comp_byd_ae', 'ca_byd_ae', JSON.stringify(defaultCompanyAdminPerms), now);
  }

  // Seed employee_accounts linked to existing non-Customer/non-Company-Admin company staff in users
  const empCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_accounts').get() as { cnt: number }).cnt;
  if (empCount === 0) {
    const staffUsers = sqlite
      .prepare("SELECT * FROM users WHERE role NOT IN ('Customer', 'Company Admin', 'Founder / Owner', 'Super Admin') AND company_id IS NOT NULL")
      .all() as any[];
    const insEmp = sqlite.prepare(`
      INSERT OR IGNORE INTO employee_accounts (
        id, user_id, company_id, branch_id, employee_code, full_name, email, mobile,
        department, job_position, status, attendance_json, leave_requests_json,
        performance_score, performance_notes, permissions_json, joined_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const deptForRole = (role: string) => {
      if (role.includes('Sales')) return 'Sales & Retail';
      if (role.includes('Finance')) return 'Finance';
      if (role.includes('Service') || role.includes('Technical')) return 'Aftersales & Workshop';
      return 'Dealership Operations';
    };

    staffUsers.forEach((u, idx) => {
      const branchId = u.company_id === 'comp_byd_pk'
        ? u.city === 'Islamabad'
          ? 'br_pk_isb'
          : u.city === 'Lahore'
          ? 'br_pk_lhr'
          : 'br_pk_khi'
        : 'br_ae_dxb';
      insEmp.run(
        `emp_${u.id}`,
        u.id,
        u.company_id,
        branchId,
        `EMP-${u.company_id === 'comp_byd_pk' ? 'PK' : 'AE'}-${String(101 + idx)}`,
        u.full_name,
        u.email,
        u.mobile,
        deptForRole(u.role),
        u.role,
        u.status || 'Active',
        JSON.stringify([{ date: now.slice(0, 10), status: 'Present', checkIn: '09:02', checkOut: '18:05' }]),
        idx === 0
          ? JSON.stringify([{ id: 'lv_seed_1', type: 'Annual Leave', startDate: '2026-12-05', endDate: '2026-12-07', reason: 'Family travel', status: 'Pending' }])
          : '[]',
        94.5,
        'Consistently meets quarterly EV SLA targets.',
        JSON.stringify(defaultCompanyAdminPerms.slice(0, 3)),
        now.slice(0, 10),
        now,
        now
      );
    });
  }

  // Seed Customer CRM records if empty
  const crmCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM customer_crm_records').get() as { cnt: number }).cnt;
  if (crmCount === 0) {
    const insCrm = sqlite.prepare(`
      INSERT INTO customer_crm_records (
        id, company_id, customer_id, customer_name, customer_email, customer_phone,
        record_type, subject, details, assigned_to, priority, status, follow_up_date, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insCrm.run('crm_pk_1', 'comp_byd_pk', 'usr_cust_1', 'Zubair Ahmed Qureshi', 'zubair.qureshi@techpk.demo', '+92 302 8561234', 'Enquiry', 'BYD Shark 6 DMO Fleet Pricing Inquiry', 'Requested corporate leasing terms for 3 units in Karachi.', 'Mansoor Akhtar', 'High', 'Open', '2026-11-20', now, now);
    insCrm.run('crm_pk_2', 'comp_byd_pk', 'usr_cust_1', 'Zubair Ahmed Qureshi', 'zubair.qureshi@techpk.demo', '+92 302 8561234', 'Feedback', 'Post-Service CSAT 5/5 Rating', 'Praised quick Blade Battery diagnostic turnaround at Clifton 3S.', 'Engr. Bilal Hashmi', 'Low', 'Closed', '2026-11-12', now, now);
    insCrm.run('crm_ae_1', 'comp_byd_ae', 'usr_cust_ae', 'Omar Al-Mansoor', 'omar.mansoor@byduae.demo', '+971 52 9981122', 'Follow-Up', 'Annual OTA Telemetry Renewal', 'Confirm UAE GCC roadside assistance renewal before winter travel.', 'Rashid Al-Nuaimi', 'Medium', 'In Progress', '2026-11-22', now, now);
  }

  // Seed Countries Registry if empty (non-destructive)
  const countryCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM countries').get() as { cnt: number }).cnt;
  if (countryCount === 0) {
    const insCountry = sqlite.prepare(`
      INSERT OR IGNORE INTO countries (
        id, code, name, flag_emoji, currency, legal_entity, timezone, headquarters_city,
        profile_json, offices_json, departments_json, authorized_operations_json,
        documents_json, contacts_json, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
    `);

    insCountry.run(
      'PK',
      'PK',
      'Pakistan',
      '🇵🇰',
      'PKR',
      'BYD Pakistan / Mega Motor Company Operations (Prototype)',
      'Asia/Karachi',
      'Karachi',
      JSON.stringify({
        overview: 'Primary South Asia New Energy Vehicle (NEV) territory covering Karachi, Lahore, Islamabad, Faisalabad & Multan.',
        helpline: '0800-293-75',
        regulatoryFramework: 'SECP / Engineering Development Board EV Policy 2025-2030',
        officialWebsite: 'https://pk.byd360.demo',
      }),
      JSON.stringify([
        { id: 'off_pk_khi', name: 'Pakistan National Headquarters', type: 'Country Office', city: 'Karachi', address: 'Plot 14-C, Marine Drive, Clifton Block 4', head: 'Tariq Mahmood' },
        { id: 'off_pk_lhr', name: 'Punjab Regional Operations Office', type: 'Regional Office', city: 'Lahore', address: '88-Main Boulevard, Gulberg III', head: 'Zainab Tariq' },
        { id: 'off_pk_isb', name: 'Northern Territory Compliance Desk', type: 'Regional Office', city: 'Islamabad', address: 'Jinnah Avenue Sector F-7', head: 'Engr. Bilal Hashmi' },
      ]),
      JSON.stringify(['Country Executive Office', 'National Sales & Fleet', '3S Network Expansion', 'Blade Battery Technical Lab', 'NEV Regulatory & Customs', 'Customer Experience & CRM']),
      JSON.stringify(['CKD & CBU EV Distribution', '3S Dealership Supervision', 'High-Voltage Battery Warranty Governance', 'M-2 DC Fast Charging Corridor Oversight']),
      JSON.stringify([
        { id: 'doc_pk_1', title: 'EDB New Energy Vehicle Import Authorization 2026', category: 'Regulatory License', ref: 'EDB-PK-2026-091', updatedAt: now.slice(0, 10) },
        { id: 'doc_pk_2', title: 'National Blade Battery High-Voltage Safety SOP', category: 'Safety Compliance', ref: 'SOP-HV-PK-14', updatedAt: now.slice(0, 10) },
      ]),
      JSON.stringify([
        { name: 'Tariq Mahmood', title: 'Country Manager Pakistan', email: 'country.pk@byd360.demo', phone: '+92 300 8112201' },
        { name: 'Sarmad Khawaja', title: 'Managing Director — Mega Motor Demo', email: 'sarmad.khawaja@megamotor.demo', phone: '+92 321 4509922' },
      ]),
      now,
      now
    );

    insCountry.run(
      'AE',
      'AE',
      'United Arab Emirates',
      '🇦🇪',
      'AED',
      'BYD UAE / GCC Mobility Operations (Prototype)',
      'Asia/Dubai',
      'Dubai',
      JSON.stringify({
        overview: 'GCC flagship New Energy Vehicle market covering Dubai, Abu Dhabi & Sharjah.',
        helpline: '800-293-823',
        regulatoryFramework: 'UAE Ministry of Energy & Infrastructure EV Standards',
        officialWebsite: 'https://ae.byd360.demo',
      }),
      JSON.stringify([
        { id: 'off_ae_dxb', name: 'UAE National Headquarters', type: 'Country Office', city: 'Dubai', address: 'Dubai Festival City Automotive Zone', head: 'Khalid Al-Maktoum' },
        { id: 'off_ae_auh', name: 'Abu Dhabi Capital Regional Office', type: 'Regional Office', city: 'Abu Dhabi', address: 'Yas Island Mobility Hub', head: 'Rashid Al-Nuaimi' },
      ]),
      JSON.stringify(['GCC Executive Desk', 'UAE Retail & Fleet', 'Luxury EV Delivery Ops', 'Thermal Battery Diagnostics', 'Customer Experience']),
      JSON.stringify(['CBU EV Retail & Corporate Fleet', 'GCC High-Speed Charging Network', 'RTA Fleet Electrification Compliance']),
      JSON.stringify([
        { id: 'doc_ae_1', title: 'ESMA EV High-Voltage Homologation Certificate', category: 'Regulatory License', ref: 'ESMA-UAE-2026-441', updatedAt: now.slice(0, 10) },
      ]),
      JSON.stringify([
        { name: 'Khalid Al-Maktoum', title: 'Country Manager UAE', email: 'country.ae@byd360.demo', phone: '+971 50 8112202' },
        { name: 'Rashid Al-Nuaimi', title: 'UAE Partner Operations Lead', email: 'rashid.nuaimi@byduae.demo', phone: '+971 50 1234567' },
      ]),
      now,
      now
    );

    insCountry.run('SA', 'SA', 'Saudi Arabia', '🇸🇦', 'SAR', 'BYD KSA Mobility Operations (Prototype)', 'Asia/Riyadh', 'Riyadh', JSON.stringify({ overview: 'Vision 2030 Electric Mobility Operations', helpline: '800-293-72', regulatoryFramework: 'SASO EV Compliance', officialWebsite: 'https://sa.byd360.demo' }), JSON.stringify([]), JSON.stringify(['Country Executive Office', 'Riyadh Fleet Operations']), JSON.stringify(['Vision 2030 EV Retail']), JSON.stringify([]), JSON.stringify([]), now, now);
    insCountry.run('GB', 'GB', 'United Kingdom', '🇬🇧', 'GBP', 'BYD UK Mobility Operations (Prototype)', 'Europe/London', 'London', JSON.stringify({ overview: 'UK Zero-Emission Fleet & Retail Territory', helpline: '0800-293-85', regulatoryFramework: 'DVSA / UK ZEV Mandate', officialWebsite: 'https://gb.byd360.demo' }), JSON.stringify([]), JSON.stringify(['UK Country Office', 'Retail & Fleet']), JSON.stringify(['UK ZEV Mandate Distribution']), JSON.stringify([]), JSON.stringify([]), now, now);
    insCountry.run('DE', 'DE', 'Germany', '🇩🇪', 'EUR', 'BYD Germany Mobility Operations (Prototype)', 'Europe/Berlin', 'Munich', JSON.stringify({ overview: 'Central Europe EV Network', helpline: '0800-293-33', regulatoryFramework: 'KBA EU Type Approval', officialWebsite: 'https://de.byd360.demo' }), JSON.stringify([]), JSON.stringify(['Germany Executive Desk', 'Dealer Network']), JSON.stringify(['EU EV Homologation & Retail']), JSON.stringify([]), JSON.stringify([]), now, now);
  }

  // Sync Country-Company Relationships cleanly
  const companiesAll = sqlite.prepare('SELECT id, country, status FROM companies').all() as any[];
  const insRel = sqlite.prepare(`
    INSERT OR IGNORE INTO country_company_relationships (
      id, country_id, company_id, relationship_type, operational_status, performance_rating, notes, updated_at
    ) VALUES (?, ?, ?, ?, ?, 96.4, ?, ?)
  `);
  for (const c of companiesAll) {
    try {
      insRel.run(
        `ccr_${c.country}_${c.id}`,
        c.country,
        c.id,
        'Authorized National Partner',
        c.status === 'Approved' ? 'Active' : c.status,
        'Auto-linked national operating company',
        now
      );
    } catch {
      // Country may not exist in countries table yet — relationship will be synced later
    }
  }

  // Sync Country Branches from company_branches cleanly
  const cbAll = sqlite.prepare('SELECT * FROM company_branches').all() as any[];
  const insCountryBr = sqlite.prepare(`
    INSERT OR IGNORE INTO country_branches (
      id, country_id, company_id, company_branch_id, name, code, city, address,
      manager_id, manager_name, phone, email, monthly_target_units, achieved_units,
      monthly_revenue_pkr, approval_status, status, submitted_by, approved_by, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?, 'system_sync', 'Founder / Owner', ?, ?)
  `);
  for (const b of cbAll) {
    insCountryBr.run(
      `cbr_${b.id}`,
      b.country || 'PK',
      b.company_id,
      b.id,
      b.name,
      b.code,
      b.city,
      b.address,
      b.manager_id,
      b.manager_name,
      b.phone,
      b.email,
      b.monthly_target_units,
      b.achieved_units,
      b.monthly_revenue_pkr,
      b.status || 'Active',
      b.created_at || now,
      b.updated_at || now
    );
  }

  // Seed default Country Manager accounts into country_manager_accounts if empty
  const cmCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM country_manager_accounts').get() as { cnt: number }).cnt;
  if (cmCount === 0) {
    const defaultCountryPerms = [
      'country.profile.manage',
      'companies.view',
      'companies.operations.manage',
      'branches.view',
      'branches.manage',
      'dealers.manage',
      'employees.view',
      'employees.manage',
      'vehicles.manage',
      'customers.view',
      'customers.pii.reveal',
      'sales.view',
      'reports.view',
      'reports.export',
    ];
    const cmPass = process.env.COUNTRY_MANAGER_INIT_PASSWORD
      ? hashPassword(process.env.COUNTRY_MANAGER_INIT_PASSWORD)
      : hashPassword('BYD-Enterprise-2026!');

    const insCm = sqlite.prepare(`
      INSERT OR IGNORE INTO country_manager_accounts (
        id, manager_code, country_id, full_name, username, email, mobile, password_hash,
        designation, status, email_verified, two_factor_enabled, two_factor_secret,
        recovery_codes_json, authorized_by, appointed_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, ?, ?, 'system_seed', ?, ?, ?)
    `);
    const insAssign = sqlite.prepare(`
      INSERT OR IGNORE INTO country_assignments (
        id, manager_id, country_id, country_name, status, appointed_by, appointment_date, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'Active', 'Intekhab Alam (Founder & CEO)', ?, ?, ?, ?)
    `);
    const insCmPerm = sqlite.prepare(`
      INSERT OR IGNORE INTO country_permissions (
        id, manager_id, country_id, permissions_json, updated_by, updated_at
      ) VALUES (?, ?, ?, ?, 'system_seed', ?)
    `);

    const pkCmSecret = generateTotpSecret();
    insCm.run('cm_pk_001', 'CM-PK-001', 'PK', 'Tariq Mahmood', 'tariq_cm_pk', 'country.pk@byd360.demo', '+92 300 8112201', cmPass, 'Country Manager — Pakistan', pkCmSecret, JSON.stringify([]), now.slice(0, 10), now, now);
    insAssign.run('ca_assign_pk', 'cm_pk_001', 'PK', 'Pakistan', now.slice(0, 10), 'Primary Country Operations Mandate for Pakistan', now, now);
    insCmPerm.run('cp_cm_pk_001', 'cm_pk_001', 'PK', JSON.stringify(defaultCountryPerms), now);

    const aeCmSecret = generateTotpSecret();
    insCm.run('cm_ae_001', 'CM-AE-001', 'AE', 'Khalid Al-Maktoum', 'khalid_cm_ae', 'country.ae@byd360.demo', '+971 50 8112202', cmPass, 'Country Manager — United Arab Emirates', aeCmSecret, JSON.stringify([]), now.slice(0, 10), now, now);
    insAssign.run('ca_assign_ae', 'cm_ae_001', 'AE', 'United Arab Emirates', now.slice(0, 10), 'Primary Country Operations Mandate for UAE', now, now);
    insCmPerm.run('cp_cm_ae_001', 'cm_ae_001', 'AE', JSON.stringify(defaultCountryPerms), now);
  }

  // Sync canonical `branches` table from `company_branches`
  const compBranchesAll = sqlite.prepare('SELECT * FROM company_branches').all() as any[];
  const insBranch = sqlite.prepare(`
    INSERT OR IGNORE INTO branches (
      id, company_id, country_id, code, name, city, address, phone, email, manager_id, manager_name,
      working_hours_json, departments_json, documents_json, daily_operations_json, announcements_json,
      monthly_target_units, achieved_units, monthly_revenue_pkr, approval_status, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Approved', ?, ?, ?)
  `);
  for (const b of compBranchesAll) {
    insBranch.run(
      b.id,
      b.company_id,
      b.country || 'PK',
      b.code,
      b.name,
      b.city,
      b.address,
      b.phone,
      b.email,
      b.manager_id,
      b.manager_name,
      JSON.stringify({ weekdays: '09:00 AM - 07:00 PM', saturday: '10:00 AM - 06:00 PM', sunday: 'Closed (Emergency EV Support Active)' }),
      JSON.stringify(['Branch Management', 'Sales & Showroom', 'Aftersales & Workshop', 'Finance & Billing', 'Customer Relations']),
      JSON.stringify([
        { id: `bdoc_${b.id}_1`, title: `${b.code} 3S Facility Operating License`, category: 'Compliance', refNo: `LIC-${b.code}-2026`, updatedAt: now.slice(0, 10) },
        { id: `bdoc_${b.id}_2`, title: 'High-Voltage Blade Battery Bay Safety SOP', category: 'Safety', refNo: `HV-SOP-${b.code}`, updatedAt: now.slice(0, 10) },
      ]),
      JSON.stringify({ pdiQueue: 4, testDriveFleetReady: 5, fastChargersOnline: 4, dailyBriefingNote: 'Morning EV showroom & workshop handover completed.' }),
      JSON.stringify([
        { id: `bann_${b.id}_1`, title: 'Q4 EV Delivery & PDI SLA Target', body: 'All test-drive & Blade Battery pre-delivery inspections must complete within 24 hours.', postedAt: now.slice(0, 10) },
      ]),
      b.monthly_target_units,
      b.achieved_units,
      b.monthly_revenue_pkr,
      b.status || 'Active',
      b.created_at || now,
      b.updated_at || now
    );
  }

  // Link operational records to branches cleanly where missing (non-destructive)
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_pk_khi' WHERE id = 'dlr_khi_clifton' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_pk_lhr' WHERE id = 'dlr_lhr_gulberg' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_pk_isb' WHERE id = 'dlr_isb_bluearea' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_ae_dxb' WHERE id = 'dlr_dxb_dfc' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE dealerships SET branch_id = 'br_ae_dxb' WHERE company_id = 'comp_byd_ae' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE users SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND city = 'Karachi' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE users SET branch_id = 'br_pk_lhr' WHERE company_id = 'comp_byd_pk' AND city = 'Lahore' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE users SET branch_id = 'br_pk_isb' WHERE company_id = 'comp_byd_pk' AND city = 'Islamabad' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE users SET branch_id = 'br_ae_dxb' WHERE company_id = 'comp_byd_ae' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE service_jobs SET branch_id = 'br_pk_khi' WHERE dealership_id = 'dlr_khi_clifton' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE service_jobs SET branch_id = 'br_pk_lhr' WHERE dealership_id = 'dlr_lhr_gulberg' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE service_jobs SET branch_id = 'br_pk_isb' WHERE dealership_id = 'dlr_isb_bluearea' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE service_jobs SET branch_id = 'br_ae_dxb' WHERE dealership_id = 'dlr_dxb_dfc' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE warranty_claims SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE warranty_claims SET branch_id = 'br_ae_dxb' WHERE company_id = 'comp_byd_ae' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE payments_invoices SET branch_id = 'br_pk_khi' WHERE id = 'inv_pk_1' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE payments_invoices SET branch_id = 'br_ae_dxb' WHERE id = 'inv_ae_1' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE payments_invoices SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE bookings SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE bookings SET branch_id = 'br_ae_dxb' WHERE company_id = 'comp_byd_ae' AND branch_id IS NULL").run();

  sqlite.prepare("UPDATE customer_crm_records SET branch_id = 'br_pk_khi' WHERE company_id = 'comp_byd_pk' AND branch_id IS NULL").run();
  sqlite.prepare("UPDATE customer_crm_records SET branch_id = 'br_ae_dxb' WHERE company_id = 'comp_byd_ae' AND branch_id IS NULL").run();

  // Seed Branch Manager accounts cleanly if empty
  const bmCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM branch_manager_accounts').get() as { cnt: number }).cnt;
  if (bmCount === 0) {
    const defaultBranchPerms = [
      'branch.profile.manage',
      'employees.view',
      'employees.manage',
      'vehicles.view',
      'vehicles.manage',
      'sales.view',
      'sales.manage',
      'customers.view',
      'customers.manage',
      'customers.pii.reveal',
      'dealers.manage',
      'finance.view',
      'service.manage',
      'reports.view',
      'reports.export',
    ];
    const bmPass = process.env.BRANCH_MANAGER_INIT_PASSWORD
      ? hashPassword(process.env.BRANCH_MANAGER_INIT_PASSWORD)
      : hashPassword('BYD-Enterprise-2026!');

    const insBm = sqlite.prepare(`
      INSERT OR IGNORE INTO branch_manager_accounts (
        id, manager_code, company_id, country_id, branch_id, full_name, username, email, mobile,
        password_hash, designation, status, email_verified, two_factor_enabled, two_factor_secret,
        recovery_codes_json, authorized_by, appointed_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 1, ?, ?, 'system_seed', ?, ?, ?)
    `);
    const insBmAssign = sqlite.prepare(`
      INSERT OR IGNORE INTO branch_assignments (
        id, manager_id, company_id, country_id, branch_id, branch_name, status, appointed_by, appointment_date, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'Active', 'Intekhab Alam (Founder & CEO)', ?, ?, ?, ?)
    `);
    const insBmPerm = sqlite.prepare(`
      INSERT OR IGNORE INTO branch_permissions (
        id, manager_id, branch_id, permissions_json, updated_by, updated_at
      ) VALUES (?, ?, ?, ?, 'system_seed', ?)
    `);

    const khiBmSecret = generateTotpSecret();
    insBm.run('bm_pk_khi_01', 'BM-PK-KHI-01', 'comp_byd_pk', 'PK', 'br_pk_khi', 'Usman Tariq Qazi', 'usman_bm_khi', 'branch.khi@byd360.demo', '+92 300 9112201', bmPass, 'Branch Manager — Karachi Clifton HQ', khiBmSecret, JSON.stringify([]), now.slice(0, 10), now, now);
    insBmAssign.run('ba_khi_01', 'bm_pk_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', 'Karachi Southern HQ & Clifton Flagship', now.slice(0, 10), 'Initial Branch Operations Mandate for Karachi Flagship', now, now);
    insBmPerm.run('bp_bm_pk_khi_01', 'bm_pk_khi_01', 'br_pk_khi', JSON.stringify(defaultBranchPerms), now);

    const lhrBmSecret = generateTotpSecret();
    insBm.run('bm_pk_lhr_01', 'BM-PK-LHR-01', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'Ayesha Siddiqui', 'ayesha_bm_lhr', 'branch.lhr@byd360.demo', '+92 300 9112202', bmPass, 'Branch Manager — Lahore Central Hub', lhrBmSecret, JSON.stringify([]), now.slice(0, 10), now, now);
    insBmAssign.run('ba_lhr_01', 'bm_pk_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'Lahore Central Hub — Gulberg III', now.slice(0, 10), 'Initial Branch Operations Mandate for Lahore Hub', now, now);
    insBmPerm.run('bp_bm_pk_lhr_01', 'bm_pk_lhr_01', 'br_pk_lhr', JSON.stringify(defaultBranchPerms), now);

    const dxbBmSecret = generateTotpSecret();
    insBm.run('bm_ae_dxb_01', 'BM-AE-DXB-01', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'Saeed Al-Habtoor', 'saeed_bm_dxb', 'branch.dxb@byd360.demo', '+971 50 9112203', bmPass, 'Branch Manager — Dubai Discovery Centre', dxbBmSecret, JSON.stringify([]), now.slice(0, 10), now, now);
    insBmAssign.run('ba_dxb_01', 'bm_ae_dxb_01', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'Dubai Discovery Flagship Branch', now.slice(0, 10), 'Initial Branch Operations Mandate for Dubai Flagship', now, now);
    insBmPerm.run('bp_bm_ae_dxb_01', 'bm_ae_dxb_01', 'br_ae_dxb', JSON.stringify(defaultBranchPerms), now);
  }

  // Sync branch_employee_relationships from employee_accounts
  const allEmpsForBr = sqlite.prepare('SELECT id, company_id, branch_id, employee_code FROM employee_accounts WHERE branch_id IS NOT NULL').all() as any[];
  const insBrEmp = sqlite.prepare(`
    INSERT OR IGNORE INTO branch_employee_relationships (
      id, branch_id, company_id, employee_id, employee_code, shift_schedule, daily_task, task_status, assigned_by, updated_at
    ) VALUES (?, ?, ?, ?, ?, 'Mon-Sat 09:00-18:00', 'Lead daily showroom, test drive & Blade Battery service operations', 'In Progress', 'Branch Manager', ?)
  `);
  for (const e of allEmpsForBr) {
    insBrEmp.run(`ber_${e.branch_id}_${e.id}`, e.branch_id, e.company_id, e.id, e.employee_code, now);
  }

  // Sync branch_inventory from vehicles
  const allVehsForBr = sqlite.prepare('SELECT id, company_id, branch_id, vin, owner_id, delivery_status, owner_name FROM vehicles WHERE branch_id IS NOT NULL').all() as any[];
  const insBrInv = sqlite.prepare(`
    INSERT OR IGNORE INTO branch_inventory (
      id, branch_id, company_id, vehicle_id, vin, stock_state, condition_grade, condition_notes, reserved_customer_name, transfer_request_status, updated_by, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'A+ Factory PDI Passed', 'Validated Blade Battery Pack & OTA Firmware', ?, 'None', 'system_seed', ?)
  `);
  for (const v of allVehsForBr) {
    const state = v.owner_id ? 'Sold' : v.delivery_status === 'Reserved' ? 'Reserved' : v.delivery_status === 'In Transit' ? 'In Transit' : 'Available';
    insBrInv.run(`binv_${v.id}`, v.branch_id, v.company_id, v.id, v.vin, state, v.owner_id ? v.owner_name : null, now);
  }

  // Seed branch_sales, branch_expenses & spare_parts if empty
  const bsCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM branch_sales').get() as { cnt: number }).cnt;
  if (bsCount === 0) {
    const insBs = sqlite.prepare(`
      INSERT OR IGNORE INTO branch_sales (
        id, branch_id, company_id, country_id, order_number, invoice_id, vehicle_id, vin, vehicle_model,
        customer_id, customer_name, customer_phone, sales_exec_name, sale_amount_pkr, paid_amount_pkr,
        payment_status, delivery_status, created_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'system_seed', ?, ?)
    `);
    insBs.run('bs_khi_1', 'br_pk_khi', 'comp_byd_pk', 'PK', 'ORD-KHI-2026-101', 'inv_pk_1', 'veh_01', 'LGXCE43C5R0108924', 'BYD Seal Performance AWD', 'usr_cust_1', 'Zubair Ahmed Qureshi', '+92 302 8561234', 'Mansoor Akhtar', 16992000, 16992000, 'Paid', 'Delivered', now, now);
    insBs.run('bs_ae_1', 'br_ae_dxb', 'comp_byd_ae', 'AE', 'ORD-DXB-2026-201', 'inv_ae_1', 'veh_04', 'LGXAE99C5R0201122', 'BYD Seal Excellence RWD', 'usr_cust_ae', 'Omar Al-Mansoor', '+971 52 9981122', 'Rashid Al-Nuaimi', 189000, 189000, 'Paid', 'Delivered', now, now);
  }

  const bexpCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM branch_expenses').get() as { cnt: number }).cnt;
  if (bexpCount === 0) {
    const insBexp = sqlite.prepare(`
      INSERT OR IGNORE INTO branch_expenses (
        id, branch_id, company_id, category, title, amount_pkr, expense_date, recorded_by, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Usman Tariq Qazi', 'Recorded', ?)
    `);
    insBexp.run('bexp_khi_1', 'br_pk_khi', 'comp_byd_pk', 'Facility & EV Charging Power', 'Monthly 180kW DC Charger Utility & Cooling Audit', 285000, now.slice(0, 10), now);
    insBexp.run('bexp_lhr_1', 'br_pk_lhr', 'comp_byd_pk', 'Showroom Operations', 'Gulberg III Test-Drive Fleet Insurance & Detailing', 195000, now.slice(0, 10), now);
  }

  const spCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM spare_parts').get() as { cnt: number }).cnt;
  if (spCount === 0) {
    const insSp = sqlite.prepare(`
      INSERT OR IGNORE INTO spare_parts (
        id, branch_id, company_id, sku, name, category, compatible_models, stock_quantity, reorder_level, unit_cost_pkr, location_bin, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insSp.run('sp_khi_1', 'br_pk_khi', 'comp_byd_pk', 'BYD-BMS-401', 'Blade Battery Thermal Sensor Module', 'Battery & High Voltage', 'BYD Seal, BYD Atto 3', 14, 5, 42000, 'HV-A02', now);
    insSp.run('sp_khi_2', 'br_pk_khi', 'comp_byd_pk', 'BYD-BRK-118', 'Regenerative Ceramic Brake Pad Kit', 'Braking & Tires', 'BYD Seal, BYD Sealion 6', 22, 6, 28500, 'BRK-B04', now);
    insSp.run('sp_lhr_1', 'br_pk_lhr', 'comp_byd_pk', 'BYD-CHG-770', 'GB/T DC Charge Port Actuator', 'Battery & High Voltage', 'BYD Atto 3, BYD Dolphin', 8, 4, 65000, 'CHG-C01', now);
  }

  // Seed & backfill normalized Employee Portal tables (non-destructive)
  const deptCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_departments').get() as { cnt: number }).cnt;
  if (deptCount === 0) {
    const insDept = sqlite.prepare(`
      INSERT OR IGNORE INTO employee_departments (id, company_id, branch_id, name, code, head_name, description, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
    `);
    const deptDefs = [
      { id: 'dept_pk_sales', comp: 'comp_byd_pk', br: 'br_pk_khi', name: 'Sales & Retail', code: 'PK-SLS', head: 'Mansoor Akhtar', desc: 'NEV showroom sales, corporate fleet & customer handover' },
      { id: 'dept_pk_workshop', comp: 'comp_byd_pk', br: 'br_pk_khi', name: 'Aftersales & Workshop', code: 'PK-SVC', head: 'Engr. Bilal Hashmi', desc: '3S EV maintenance, Blade Battery diagnostics & HV warranty service' },
      { id: 'dept_pk_finance', comp: 'comp_byd_pk', br: 'br_pk_khi', name: 'Finance', code: 'PK-FIN', head: 'Shahida Parveen', desc: 'Payroll, dealership invoicing, customer leasing & compliance' },
      { id: 'dept_pk_dealer', comp: 'comp_byd_pk', br: 'br_pk_khi', name: 'Dealership Operations', code: 'PK-OPS', head: 'Farhan Zaidi', desc: 'Branch showroom inventory, test-drive fleet & customer experience' },
      { id: 'dept_pk_branch', comp: 'comp_byd_pk', br: 'br_pk_lhr', name: 'Branch Operations', code: 'PK-BRN', head: 'Usman Tariq Qazi', desc: 'Regional branch coordination & DC charging hub operations' },
      { id: 'dept_ae_ops', comp: 'comp_byd_ae', br: 'br_ae_dxb', name: 'Dealership Operations', code: 'AE-OPS', head: 'Khalid Al-Maktoum', desc: 'UAE flagship EV showroom & GCC fleet delivery' },
    ];
    for (const d of deptDefs) {
      insDept.run(d.id, d.comp, d.br, d.name, d.code, d.head, d.desc, now, now);
    }
  }

  // Ensure a seeded UAE employee exists for cross-company verification & UAE operations
  const uaeEmpExists = sqlite.prepare("SELECT id FROM employee_accounts WHERE id = 'emp_uae_1'").get();
  if (!uaeEmpExists) {
    const defaultEmpPass = hashPassword(process.env.EMPLOYEE_INIT_PASSWORD || 'BYD-Enterprise-2026!');
    sqlite
      .prepare(`
        INSERT OR IGNORE INTO users (
          id, company_id, branch_id, username, full_name, email, mobile, password_hash,
          role, country, city, status, email_verified, mobile_verified, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Sales Executive', 'AE', 'Dubai', 'Active', 1, 1, 'system_seed', ?, ?)
      `)
      .run('usr_emp_uae_1', 'comp_byd_ae', 'br_ae_dxb', 'fatima_uae', 'Fatima Al-Zahra', 'fatima.alzahra@byduae.demo', '+971 50 7788990', defaultEmpPass, now, now);

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_accounts (
          id, user_id, company_id, country_id, branch_id, department_id, employee_code, full_name, username, email, mobile,
          department, job_position, reporting_manager_id, reporting_manager_name, password_hash, email_verified, two_factor_enabled, two_factor_secret,
          status, attendance_json, leave_requests_json, performance_score, performance_notes, permissions_json, joined_at, created_at, updated_at
        ) VALUES (?, ?, ?, 'AE', 'br_ae_dxb', 'dept_ae_ops', 'EMP-AE-106', 'Fatima Al-Zahra', 'fatima_uae', 'fatima.alzahra@byduae.demo', '+971 50 7788990',
          'Dealership Operations', 'Sales Executive', 'bm_ae_dxb', 'Khalid Al-Maktoum', ?, 1, 1, ?,
          'Active', '[]', '[]', 95.0, 'Top UAE EV delivery advisor.', ?, ?, ?, ?)
      `)
      .run(
        'emp_uae_1',
        'usr_emp_uae_1',
        'comp_byd_ae',
        defaultEmpPass,
        generateTotpSecret(),
        JSON.stringify([
          'employee.profile.manage',
          'employee.attendance.manage',
          'employee.leave.manage',
          'employee.tasks.manage',
          'employee.salary.view',
          'employee.documents.manage',
          'employee.performance.view',
          'employee.support.manage',
        ]),
        '2025-09-01',
        now,
        now
      );
  }

  // Backfill auth + assignment columns on all existing employee_accounts rows idempotently
  const defaultEmployeePerms = [
    'employee.profile.manage',
    'employee.attendance.manage',
    'employee.leave.manage',
    'employee.tasks.manage',
    'employee.salary.view',
    'employee.documents.manage',
    'employee.performance.view',
    'employee.support.manage',
  ];
  const privateDocsDir = path.join(path.dirname(DB_PATH), 'private_employee_docs');
  if (!fs.existsSync(privateDocsDir)) {
    fs.mkdirSync(privateDocsDir, { recursive: true });
  }

  const allEmps = sqlite.prepare('SELECT * FROM employee_accounts').all() as any[];
  for (const emp of allEmps) {
    const linkedUser = emp.user_id
      ? (sqlite.prepare('SELECT * FROM users WHERE id = ?').get(emp.user_id) as any)
      : null;
    const comp = sqlite.prepare('SELECT country, city FROM companies WHERE id = ?').get(emp.company_id) as any;
    const countryId = emp.country_id || comp?.country || 'PK';
    const bm = emp.branch_id
      ? (sqlite.prepare("SELECT id, full_name FROM branch_manager_accounts WHERE branch_id = ? AND status = 'Active' LIMIT 1").get(emp.branch_id) as any)
      : null;
    const deptRow = sqlite
      .prepare('SELECT id FROM employee_departments WHERE company_id = ? AND LOWER(name) = LOWER(?) LIMIT 1')
      .get(emp.company_id, emp.department || '') as any;

    const existingPerms = (() => {
      try {
        return JSON.parse(emp.permissions_json || '[]') as string[];
      } catch {
        return [];
      }
    })();
    const mergedPerms = existingPerms.some((p) => p.startsWith('employee.'))
      ? existingPerms
      : Array.from(new Set([...existingPerms, ...defaultEmployeePerms]));

    const nextPassHash = emp.password_hash || linkedUser?.password_hash || hashPassword(process.env.EMPLOYEE_INIT_PASSWORD || 'BYD-Enterprise-2026!');
    const nextUsername = emp.username || linkedUser?.username || `${String(emp.email).split('@')[0]}_${emp.employee_code.toLowerCase()}`;
    const nextSecret = emp.two_factor_secret || generateTotpSecret();
    const nextMgrId = emp.reporting_manager_id || bm?.id || null;
    const nextMgrName = emp.reporting_manager_name || bm?.full_name || (emp.company_id === 'comp_byd_pk' ? 'Usman Tariq Qazi' : 'Khalid Al-Maktoum');
    const nextDeptId = emp.department_id || deptRow?.id || (emp.company_id === 'comp_byd_pk' ? 'dept_pk_dealer' : 'dept_ae_ops');

    sqlite
      .prepare(`
        UPDATE employee_accounts
        SET country_id = COALESCE(country_id, ?),
            department_id = COALESCE(department_id, ?),
            reporting_manager_id = COALESCE(reporting_manager_id, ?),
            reporting_manager_name = COALESCE(reporting_manager_name, ?),
            username = COALESCE(username, ?),
            password_hash = COALESCE(password_hash, ?),
            two_factor_secret = COALESCE(two_factor_secret, ?),
            permissions_json = ?
        WHERE id = ?
      `)
      .run(countryId, nextDeptId, nextMgrId, nextMgrName, nextUsername, nextPassHash, nextSecret, JSON.stringify(mergedPerms), emp.id);

    // Ensure normalized employee_profiles row exists
    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_profiles (
          id, employee_id, company_id, country_id, branch_id, department_id, reporting_manager_id, reporting_manager_name,
          bio, city, emergency_contact_name, emergency_contact_phone, emergency_contact_relation,
          work_location, employment_type, responsibilities_json, skills_json, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Family', ?, 'Full-Time Permanent', ?, ?, ?)
      `)
      .run(
        `ep_${emp.id}`,
        emp.id,
        emp.company_id,
        countryId,
        emp.branch_id || null,
        nextDeptId,
        nextMgrId,
        nextMgrName,
        `${emp.job_position} in ${emp.department} supporting BYD PAKISTAN 360 NEV operations.`,
        comp?.city || (countryId === 'AE' ? 'Dubai' : 'Karachi'),
        'Next-of-Kin Emergency Contact',
        countryId === 'AE' ? '+971 50 9001122' : '+92 300 9001122',
        emp.branch_id === 'br_pk_isb'
          ? 'Islamabad Blue Area 3S Hub'
          : emp.branch_id === 'br_pk_lhr'
          ? 'Lahore Gulberg III 3S Central'
          : emp.branch_id === 'br_ae_dxb'
          ? 'Dubai Festival City Flagship'
          : 'Karachi Clifton 3S Flagship',
        JSON.stringify([
          `Execute daily ${emp.department} SLA deliverables`,
          'Maintain customer & EV telemetry compliance standards',
          `Coordinate with ${nextMgrName} on branch KPIs`,
        ]),
        JSON.stringify(['BYD Blade Battery Systems', 'NEV Customer Excellence', 'CRM & ERP Operations']),
        now
      );

    // Ensure active employee_assignments row exists
    const assignExists = sqlite.prepare("SELECT id FROM employee_assignments WHERE employee_id = ? AND status = 'Active'").get(emp.id);
    if (!assignExists) {
      sqlite
        .prepare(`
          INSERT INTO employee_assignments (
            id, employee_id, company_id, country_id, branch_id, department_id, job_position,
            reporting_manager_id, reporting_manager_name, shift_schedule, effective_from, status, assigned_by, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Mon-Sat 09:00-18:00', ?, 'Active', 'system_seed', ?, ?)
        `)
        .run(
          `ea_${emp.id}`,
          emp.id,
          emp.company_id,
          countryId,
          emp.branch_id || null,
          nextDeptId,
          emp.job_position,
          nextMgrId,
          nextMgrName,
          emp.joined_at || now.slice(0, 10),
          now,
          now
        );
    }

    // Seed past-days attendance history (prior 3 days, NOT today so live Check-In works freshly!)
    const attCountForEmp = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_attendance WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (attCountForEmp === 0) {
      for (let d = 1; d <= 3; d++) {
        const dt = new Date(Date.now() - d * 86400_000).toISOString().slice(0, 10);
        const checkInIso = `${dt}T09:0${d + 1}:00.000Z`;
        const checkOutIso = `${dt}T18:05:00.000Z`;
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO employee_attendance (
              id, employee_id, company_id, country_id, branch_id, attendance_date, check_in_at, check_out_at,
              working_hours, status, late_minutes, early_leave_minutes, work_mode, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 9.05, 'Present', 0, 0, 'On-Site', 'Verified standard shift', ?, ?)
          `)
          .run(`att_${emp.id}_${d}`, emp.id, emp.company_id, countryId, emp.branch_id || null, dt, checkInIso, checkOutIso, now, now);
      }
    }

    // Sync any JSON leave requests into employee_leave_requests
    const empLeaveCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_leave_requests WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (empLeaveCnt === 0) {
      let jsonLeaves: any[] = [];
      try {
        jsonLeaves = JSON.parse(emp.leave_requests_json || '[]');
      } catch {
        jsonLeaves = [];
      }
      for (const lv of jsonLeaves) {
        sqlite
          .prepare(`
            INSERT OR IGNORE INTO employee_leave_requests (
              id, employee_id, company_id, country_id, branch_id, leave_type, start_date, end_date, total_days,
              reason, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 3, ?, ?, ?, ?)
          `)
          .run(lv.id || `lv_${crypto.randomBytes(4).toString('hex')}`, emp.id, emp.company_id, countryId, emp.branch_id || null, lv.type || 'Annual Leave', lv.startDate || '2026-12-05', lv.endDate || '2026-12-07', lv.reason || 'Personal commitment', lv.status || 'Pending', now, now);
      }
    }

    // Seed assigned tasks per employee
    const taskCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_tasks WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (taskCnt === 0) {
      const insTask = sqlite.prepare(`
        INSERT OR IGNORE INTO employee_tasks (
          id, task_code, employee_id, company_id, country_id, branch_id, title, description,
          priority, due_date, status, assigned_by_id, assigned_by_name, manager_feedback,
          work_updates_json, attachment_doc_ids_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?)
      `);
      const tomorrow = new Date(Date.now() + 2 * 86400_000).toISOString().slice(0, 10);
      const nextWeek = new Date(Date.now() + 5 * 86400_000).toISOString().slice(0, 10);
      insTask.run(
        `tsk_${emp.id}_1`,
        `TSK-${emp.employee_code}-01`,
        emp.id,
        emp.company_id,
        countryId,
        emp.branch_id || null,
        `Weekly ${emp.department} EV Audit & SLA Checklist`,
        `Complete the branch ${emp.department.toLowerCase()} quality verification log and upload supporting sign-off notes.`,
        'High',
        tomorrow,
        'Pending',
        nextMgrId,
        nextMgrName,
        'Please prioritize completion before weekly branch review.',
        JSON.stringify([{ by: nextMgrName, role: 'Branch Manager', text: 'Task assigned for this week.', at: now }]),
        now,
        now
      );
      insTask.run(
        `tsk_${emp.id}_2`,
        `TSK-${emp.employee_code}-02`,
        emp.id,
        emp.company_id,
        countryId,
        emp.branch_id || null,
        'BYD Blade Battery Safety & Customer Handover Protocol',
        'Review updated high-voltage handover checklist and acknowledge compliance guidelines.',
        'Medium',
        nextWeek,
        'In Progress',
        nextMgrId,
        nextMgrName,
        'On track.',
        JSON.stringify([{ by: emp.full_name, role: emp.job_position, text: 'Started checklist verification.', at: now }]),
        now,
        now
      );
    }

    // Seed private appointment letter document & salary records + salary slip per employee
    const docCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_documents WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    let slipDocId: string | null = null;
    if (docCnt === 0) {
      const apptKey = `${emp.id}_appointment_letter.txt`;
      const apptPath = path.join(privateDocsDir, apptKey);
      const apptBody = `BYD PAKISTAN 360 - CONFIDENTIAL APPOINTMENT LETTER\nEmployee: ${emp.full_name}\nEmployee ID: ${emp.employee_code}\nPosition: ${emp.job_position}\nDepartment: ${emp.department}\nReporting Manager: ${nextMgrName}\nJoining Date: ${emp.joined_at || now.slice(0, 10)}\nFounder & CEO: Intekhab Alam\n`;
      if (!fs.existsSync(apptPath)) fs.writeFileSync(apptPath, apptBody, 'utf8');

      sqlite
        .prepare(`
          INSERT INTO employee_documents (
            id, employee_id, company_id, country_id, branch_id, category, title,
            original_filename, mime_type, size_bytes, storage_key, uploaded_by_id, uploaded_by_role, is_confidential, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Appointment Letter', ?, 'appointment-letter.txt', 'text/plain', ?, ?, 'system_hr', 'HR Administration', 1, ?)
        `)
        .run(`edoc_${emp.id}_appt`, emp.id, emp.company_id, countryId, emp.branch_id || null, `Official Appointment Letter — ${emp.employee_code}`, Buffer.byteLength(apptBody), apptKey, now);

      slipDocId = `edoc_${emp.id}_slip1`;
      const slipKey = `${emp.id}_payslip_2026_10.txt`;
      const slipPath = path.join(privateDocsDir, slipKey);
      const currency = countryId === 'AE' ? 'AED' : 'PKR';
      const baseSal = countryId === 'AE' ? 14500 : 185000;
      const allowSal = countryId === 'AE' ? 2500 : 35000;
      const bonusSal = countryId === 'AE' ? 1000 : 15000;
      const dedSal = countryId === 'AE' ? 0 : 4500;
      const taxSal = countryId === 'AE' ? 0 : 8500;
      const netSal = baseSal + allowSal + bonusSal - dedSal - taxSal;
      const slipBody = `BYD PAKISTAN 360 - PRIVATE SALARY SLIP (2026-10)\nEmployee: ${emp.full_name} (${emp.employee_code})\nDepartment: ${emp.department}\nCurrency: ${currency}\nBase Salary: ${baseSal}\nAllowances: ${allowSal}\nPerformance Bonus: ${bonusSal}\nDeductions: ${dedSal}\nIncome Tax: ${taxSal}\nNET PAYABLE: ${netSal} ${currency}\nStatus: Paid\n`;
      if (!fs.existsSync(slipPath)) fs.writeFileSync(slipPath, slipBody, 'utf8');

      sqlite
        .prepare(`
          INSERT INTO employee_documents (
            id, employee_id, company_id, country_id, branch_id, category, title,
            original_filename, mime_type, size_bytes, storage_key, uploaded_by_id, uploaded_by_role, is_confidential, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Salary Slip', ?, 'payslip-2026-10.txt', 'text/plain', ?, ?, 'system_payroll', 'Payroll Admin', 1, ?)
        `)
        .run(slipDocId, emp.id, emp.company_id, countryId, emp.branch_id || null, 'October 2026 Certified Salary Slip', Buffer.byteLength(slipBody), slipKey, now);
    }

    const salCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_salary_records WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (salCnt === 0) {
      const currency = countryId === 'AE' ? 'AED' : 'PKR';
      const baseSal = countryId === 'AE' ? 14500 : 185000;
      const allowSal = countryId === 'AE' ? 2500 : 35000;
      const bonusSal = countryId === 'AE' ? 1000 : 15000;
      const dedSal = countryId === 'AE' ? 0 : 4500;
      const taxSal = countryId === 'AE' ? 0 : 8500;
      const netSal = baseSal + allowSal + bonusSal - dedSal - taxSal;

      sqlite
        .prepare(`
          INSERT OR IGNORE INTO employee_salary_records (
            id, employee_id, company_id, country_id, branch_id, pay_period, currency,
            base_salary, allowances, bonuses, deductions, tax_deduction, net_salary,
            payment_status, payment_date, bank_reference, slip_doc_id, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, '2026-10', ?, ?, ?, ?, ?, ?, ?, 'Paid', '2026-11-01', ?, ?, 'Monthly payroll disbursed via corporate direct deposit.', ?, ?)
        `)
        .run(`sal_${emp.id}_2026_10`, emp.id, emp.company_id, countryId, emp.branch_id || null, currency, baseSal, allowSal, bonusSal, dedSal, taxSal, netSal, `PAY-${emp.employee_code}-10`, slipDocId, now, now);

      sqlite
        .prepare(`
          INSERT OR IGNORE INTO employee_salary_records (
            id, employee_id, company_id, country_id, branch_id, pay_period, currency,
            base_salary, allowances, bonuses, deductions, tax_deduction, net_salary,
            payment_status, payment_date, bank_reference, slip_doc_id, notes, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, '2026-09', ?, ?, ?, 0, ?, ?, ?, 'Paid', '2026-10-01', ?, NULL, 'Regular monthly payroll settled.', ?, ?)
        `)
        .run(`sal_${emp.id}_2026_09`, emp.id, emp.company_id, countryId, emp.branch_id || null, currency, baseSal, allowSal, dedSal, taxSal, netSal - bonusSal, `PAY-${emp.employee_code}-09`, now, now);
    }

    // Seed Performance & Development Review
    const perfCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_performance_reviews WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (perfCnt === 0) {
      sqlite
        .prepare(`
          INSERT INTO employee_performance_reviews (
            id, employee_id, company_id, branch_id, period, rating, attendance_score, task_completion_score,
            reviewer_name, reviewer_role, feedback, trainings_json, goals_json, created_at, updated_at
          ) VALUES (?, ?, ?, ?, 'Q4 2026', ?, 96.5, 93.0, ?, 'Branch Manager', ?, ?, ?, ?, ?)
        `)
        .run(
          `perf_${emp.id}_q4`,
          emp.id,
          emp.company_id,
          emp.branch_id || null,
          emp.performance_score || 94.0,
          nextMgrName,
          emp.performance_notes || 'Strong adherence to BYD PAKISTAN 360 NEV standards and customer response SLA.',
          JSON.stringify([
            { id: 'trn_1', title: 'High-Voltage Blade Battery Safety Certification', status: 'Completed', completedAt: '2026-09-18', score: '98%' },
            { id: 'trn_2', title: 'BYD DiLink Telemetry & EV Handover Excellence', status: 'In Progress', completedAt: null, score: 'Pending' },
          ]),
          JSON.stringify([
            { id: 'goal_1', title: 'Achieve 98% on-time task SLA in Q4', progress: 82, targetDate: '2026-12-31' },
            { id: 'goal_2', title: 'Complete Level-2 EV Advisory Specialization', progress: 65, targetDate: '2026-12-15' },
          ]),
          now,
          now
        );
    }

    // Seed Personal Notification
    const notifCnt = (sqlite.prepare('SELECT COUNT(*) as cnt FROM employee_notifications WHERE employee_id = ?').get(emp.id) as { cnt: number }).cnt;
    if (notifCnt === 0) {
      sqlite
        .prepare(`
          INSERT INTO employee_notifications (
            id, employee_id, company_id, country_id, branch_id, category, title, message,
            sender_name, sender_role, priority, is_read, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Manager Message', ?, ?, ?, 'Branch Manager', 'Normal', 0, ?)
        `)
        .run(
          `enot_${emp.id}_1`,
          emp.id,
          emp.company_id,
          countryId,
          emp.branch_id || null,
          `Welcome to BYD 360 Employee Workspace — ${emp.employee_code}`,
          `Hello ${emp.full_name}, please remember to record your daily check-in and review your assigned Q4 tasks in your private portal.`,
          nextMgrName,
          now
        );
    }
  }

  // Seed company-wide / branch-wide announcements in employee_notifications if absent
  const annCount = (sqlite.prepare("SELECT COUNT(*) as cnt FROM employee_notifications WHERE employee_id IS NULL").get() as { cnt: number }).cnt;
  if (annCount === 0) {
    const insAnn = sqlite.prepare(`
      INSERT INTO employee_notifications (
        id, employee_id, company_id, country_id, branch_id, category, title, message, sender_name, sender_role, priority, is_read, created_at
      ) VALUES (?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `);
    insAnn.run('eann_pk_1', 'comp_byd_pk', 'PK', null, 'Company Announcement', 'Q4 2026 National EV Readiness & Attendance Policy', 'All Mega Motor / BYD Pakistan employees are reminded to complete daily check-in prior to 09:15 PKT.', 'Intekhab Alam', 'Founder & CEO', 'High', now);
    insAnn.run('eann_pk_khi', 'comp_byd_pk', 'PK', 'br_pk_khi', 'Branch Announcement', 'Clifton 3S Hub Weekend Blade Battery Inspection Camp', 'Clifton Flagship staff will run extended customer EV diagnostic slots this Saturday 10:00-16:00.', 'Usman Tariq Qazi', 'Branch Manager', 'Normal', now);
    insAnn.run('eann_ae_1', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'Company Announcement', 'UAE Winter EV Charging Readiness Briefing', 'All Dubai Festival City team members must verify CCS2 & GB/T charger telemetry logs weekly.', 'Khalid Al-Maktoum', 'Branch Manager', 'Normal', now);
  }

  seedDealerPortalData(now);
  seedCustomerPortalData(now);
}

function seedDealerPortalData(now: string) {
  const existingDealers = (sqlite.prepare('SELECT COUNT(*) as cnt FROM dealer_accounts').get() as { cnt: number }).cnt;
  const privateDealerDir = path.join(path.dirname(DB_PATH), 'private_dealer_docs');
  if (!fs.existsSync(privateDealerDir)) {
    fs.mkdirSync(privateDealerDir, { recursive: true });
  }

  const defaultDealerPerms = [
    'dealer.dashboard.view',
    'dealer.profile.manage',
    'dealer.inventory.view',
    'dealer.vin.view',
    'dealer.crm.manage',
    'dealer.bookings.manage',
    'dealer.sales.view',
    'dealer.commissions.view',
    'dealer.documents.manage',
    'dealer.reports.view',
    'dealer.reports.export',
    'dealer.support.manage',
  ];

  if (existingDealers === 0) {
    const dealerSeedPass = process.env.DEALER_INIT_PASSWORD
      ? hashPassword(process.env.DEALER_INIT_PASSWORD)
      : hashPassword('BYD-Enterprise-2026!');

    const insDealer = sqlite.prepare(`
      INSERT INTO dealer_accounts (
        id, dealer_code, dealership_id, company_id, country_id, branch_id,
        business_name, owner_contact_name, username, email, mobile, password_hash,
        category, verification_status, status, email_verified, two_factor_enabled,
        two_factor_secret, recovery_codes_json, commission_rate_pct, authorized_by,
        approved_by, approved_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, '[]', ?, 'system_seed', ?, ?, ?, ?)
    `);

    const insProfile = sqlite.prepare(`
      INSERT INTO dealer_profiles (
        id, dealer_id, business_address, city, country_id, tax_id_ntn, registration_no,
        website, bank_name, bank_account_title, bank_iban_masked, pending_change_status, notes, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'None', ?, ?)
    `);

    const insAssign = sqlite.prepare(`
      INSERT INTO dealer_assignments (
        id, dealer_id, company_id, country_id, branch_id, assigned_manager_id,
        assigned_manager_name, status, assigned_by, effective_from, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active', 'Intekhab Alam (Founder & CEO)', ?, ?, ?, ?)
    `);

    const insPerm = sqlite.prepare(`
      INSERT INTO dealer_permissions (id, dealer_id, permissions_json, updated_by, updated_at)
      VALUES (?, ?, ?, 'system_seed', ?)
    `);

    const seedDealers = [
      {
        id: 'dlr_acc_khi_01',
        code: 'DLR-PK-KHI-01',
        dealershipId: 'dlr_khi_clifton',
        companyId: 'comp_byd_pk',
        countryId: 'PK',
        branchId: 'br_pk_khi',
        businessName: 'Mega Motor Flagship 3S — Clifton',
        contactName: 'Kamran Siddiqui',
        username: 'dealer_khi_01',
        email: 'dealer.khi@byd360.demo',
        mobile: '+92 300 4118821',
        category: '3S Flagship Centre',
        verificationStatus: 'Verified',
        status: 'Active',
        emailVerified: 1,
        rate: 4.5,
        approvedBy: 'Intekhab Alam',
        approvedAt: now,
        address: 'Plot 14-C, Marine Drive, Clifton Block 2',
        city: 'Karachi',
        taxId: 'NTN-4198204-7',
        regNo: 'SECP-DLR-PK-001',
        website: 'https://clifton.byd360.demo',
        bankName: 'Meezan Bank Limited',
        bankTitle: 'Mega Motor Clifton 3S Motors Pvt Ltd',
        ibanMasked: 'PK88MEZN************4412',
        mgrId: 'bm_pk_khi_01',
        mgrName: 'Usman Tariq Qazi',
      },
      {
        id: 'dlr_acc_lhr_01',
        code: 'DLR-PK-LHR-01',
        dealershipId: 'dlr_lhr_gulberg',
        companyId: 'comp_byd_pk',
        countryId: 'PK',
        branchId: 'br_pk_lhr',
        businessName: 'BYD Lahore Central 3S — Gulberg III',
        contactName: 'Faisal Humayun',
        username: 'dealer_lhr_01',
        email: 'dealer.lhr@byd360.demo',
        mobile: '+92 300 4118822',
        category: '3S Flagship Centre',
        verificationStatus: 'Verified',
        status: 'Active',
        emailVerified: 1,
        rate: 4.25,
        approvedBy: 'Intekhab Alam',
        approvedAt: now,
        address: '88-Main Boulevard, Gulberg III, Lahore',
        city: 'Lahore',
        taxId: 'NTN-5529103-1',
        regNo: 'SECP-DLR-PK-002',
        website: 'https://gulberg.byd360.demo',
        bankName: 'HBL Corporate Bank',
        bankTitle: 'BYD Lahore Central Motors Pvt Ltd',
        ibanMasked: 'PK41HABB************8819',
        mgrId: 'bm_pk_lhr_01',
        mgrName: 'Ayesha Siddiqui',
      },
      {
        id: 'dlr_acc_isb_01',
        code: 'DLR-PK-ISB-01',
        dealershipId: 'dlr_isb_bluearea',
        companyId: 'comp_byd_pk',
        countryId: 'PK',
        branchId: 'br_pk_isb',
        businessName: 'BYD Capital Hub 3S — Blue Area',
        contactName: 'Nadeem Qureshi',
        username: 'dealer_isb_01',
        email: 'dealer.isb@byd360.demo',
        mobile: '+92 300 4118823',
        category: '3S Flagship Centre',
        verificationStatus: 'Verified',
        status: 'Active',
        emailVerified: 1,
        rate: 4.5,
        approvedBy: 'Intekhab Alam',
        approvedAt: now,
        address: 'Jinnah Avenue Sector F-7, Islamabad',
        city: 'Islamabad',
        taxId: 'NTN-6640219-3',
        regNo: 'SECP-DLR-PK-003',
        website: 'https://capital.byd360.demo',
        bankName: 'UBL Islamic Corporate',
        bankTitle: 'Capital EV Mobility Center',
        ibanMasked: 'PK19UNIL************3190',
        mgrId: 'cm_pk_001',
        mgrName: 'Tariq Mahmood',
      },
      {
        id: 'dlr_acc_ae_01',
        code: 'DLR-AE-DXB-01',
        dealershipId: 'dlr_dxb_dfc',
        companyId: 'comp_byd_ae',
        countryId: 'AE',
        branchId: 'br_ae_dxb',
        businessName: 'BYD Dubai Flagship Discovery Centre',
        contactName: 'Tariq Al-Qasimi',
        username: 'dealer_ae_01',
        email: 'dealer.ae@byd360.demo',
        mobile: '+971 50 4118824',
        category: '3S Flagship Centre',
        verificationStatus: 'Verified',
        status: 'Active',
        emailVerified: 1,
        rate: 5.0,
        approvedBy: 'Intekhab Alam',
        approvedAt: now,
        address: 'Festival City Boulevard, Dubai',
        city: 'Dubai',
        taxId: 'TRN-1002948102',
        regNo: 'DED-DLR-AE-001',
        website: 'https://dubai.byd360.demo',
        bankName: 'First Abu Dhabi Bank',
        bankTitle: 'Al-Futtaim EV Discovery Centre LLC',
        ibanMasked: 'AE33FAB0************7091',
        mgrId: 'bm_ae_dxb_01',
        mgrName: 'Saeed Al-Habtoor',
      },
      {
        id: 'dlr_acc_mlt_p1',
        code: 'DLR-PK-MLT-P1',
        dealershipId: 'dlr_mlt_pending',
        companyId: 'comp_byd_pk',
        countryId: 'PK',
        branchId: 'br_pk_khi',
        businessName: 'BYD Multan Southern EV 3S (Applicant)',
        contactName: 'Salman Gillani',
        username: 'dealer_mlt_p1',
        email: 'dealer.mlt@byd360.demo',
        mobile: '+92 300 4118899',
        category: '3S Flagship Centre',
        verificationStatus: 'Pending Approval',
        status: 'Pending Verification',
        emailVerified: 0,
        rate: 4.0,
        approvedBy: null,
        approvedAt: null,
        address: 'Boson Road Automotive Corridor, Multan',
        city: 'Multan',
        taxId: 'NTN-8821044-9',
        regNo: 'SECP-DLR-PK-P05',
        website: 'https://multan-ev.demo',
        bankName: 'Bank Alfalah',
        bankTitle: 'Southern EV Motors',
        ibanMasked: 'PK12ALFH************2208',
        mgrId: 'bm_pk_khi_01',
        mgrName: 'Usman Tariq Qazi',
      },
    ];

    for (const d of seedDealers) {
      const secret = generateTotpSecret();
      insDealer.run(
        d.id, d.code, d.dealershipId, d.companyId, d.countryId, d.branchId,
        d.businessName, d.contactName, d.username, d.email, d.mobile, dealerSeedPass,
        d.category, d.verificationStatus, d.status, d.emailVerified,
        secret, d.rate, d.approvedBy, d.approvedAt, now, now
      );
      insProfile.run(
        `dp_${d.id}`, d.id, d.address, d.city, d.countryId, d.taxId, d.regNo,
        d.website, d.bankName, d.bankTitle, d.ibanMasked,
        `Authorized BYD ${d.category} operating in ${d.city}.`, now
      );
      insAssign.run(
        `da_${d.id}`, d.id, d.companyId, d.countryId, d.branchId, d.mgrId, d.mgrName,
        now.slice(0, 10), `Assigned to ${d.city} operations under ${d.mgrName}.`, now, now
      );
      insPerm.run(`dperm_${d.id}`, d.id, JSON.stringify(defaultDealerPerms), now);

      // Seed confidential dealer registration & tax verification documents on private disk
      const regKey = `${d.id}_registration.txt`;
      const regBody = `BYD PAKISTAN 360 - AUTHORIZED DEALER CERTIFICATE\nDealer ID: ${d.code}\nBusiness Name: ${d.businessName}\nCategory: ${d.category}\nTax ID: ${d.taxId}\nRegistration No: ${d.regNo}\nVerification Status: ${d.verificationStatus}\nFounder & CEO: Intekhab Alam\n`;
      if (!fs.existsSync(path.join(privateDealerDir, regKey))) {
        fs.writeFileSync(path.join(privateDealerDir, regKey), regBody, 'utf8');
      }
      sqlite
        .prepare(`
          INSERT OR IGNORE INTO dealer_documents (
            id, dealer_id, company_id, doc_type, title, original_filename, mime_type,
            size_bytes, storage_key, verification_status, reviewed_by, review_notes,
            uploaded_by_id, uploaded_by_role, created_at, updated_at
          ) VALUES (?, ?, ?, 'Business Registration', ?, 'dealer-registration-cert.txt', 'text/plain', ?, ?, ?, ?, ?, ?, 'Dealer Applicant', ?, ?)
        `)
        .run(
          `ddoc_${d.id}_reg`,
          d.id,
          d.companyId,
          `${d.code} Commercial Dealership License`,
          Buffer.byteLength(regBody),
          regKey,
          d.verificationStatus === 'Verified' ? 'Verified' : 'Pending Verification',
          d.verificationStatus === 'Verified' ? 'Intekhab Alam' : null,
          d.verificationStatus === 'Verified' ? 'Corporate registration and facility audit verified.' : 'Awaiting admin compliance review.',
          d.id,
          now,
          now
        );
    }

    // Seed Dealer Vehicle Inventory (Available, Reserved & Sold EV units across Karachi, Lahore, Islamabad & Dubai)
    const insInv = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_vehicle_inventory (
        id, dealer_id, company_id, country_id, branch_id, vehicle_id, stock_number,
        model, variant, model_year, exterior_color, interior_color, vin, image_url,
        availability_status, approved_selling_price_pkr, booking_status, delivery_status,
        assigned_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 2026, ?, ?, ?, ?, ?, ?, ?, ?, 'Mega Motor Fleet Allocation', ?, ?)
    `);

    insInv.run('dinv_khi_1', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', null, 'STK-KHI-2601', 'BYD Seal', 'Performance AWD 82.5 kWh', 'Cosmos Black', 'Tahiti Blue Alcantara', 'LGXCE43C5R0109901', 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=900&q=80', 'Available', 16990000, 'Unbooked', 'At Showroom', now, now);
    insInv.run('dinv_khi_2', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', null, 'STK-KHI-2602', 'BYD Atto 3', 'Advance 60.48 kWh', 'Surf Blue', 'Eclipse Black & Cyan', 'LGXCE43C5R0109902', 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&w=900&q=80', 'Available', 8990000, 'Unbooked', 'At Showroom', now, now);
    insInv.run('dinv_khi_3', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', null, 'STK-KHI-2603', 'BYD Shark 6', 'DMO Off-Road PHEV Pickup', 'Boulder Grey', 'Obsidian Red Trim', 'LGXCE43C5R0109903', 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=900&q=80', 'Booked', 18490000, 'Booking Requested', 'Ready for Handover', now, now);
    insInv.run('dinv_khi_4', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', 'veh_01', 'STK-KHI-2600', 'BYD Seal', 'Performance AWD 82.5 kWh', 'Atlantis Grey', 'Eclipse Black', 'LGXCE43C5R0108924', 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=900&q=80', 'Sold', 16990000, 'Completed', 'Delivered', now, now);

    insInv.run('dinv_lhr_1', 'dlr_acc_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr', null, 'STK-LHR-2601', 'BYD Sealion 6', 'DM-i Super Hybrid AWD', 'Harbour Blue', 'Pebble Grey Leather', 'LGXCE43C5R0204401', 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=900&q=80', 'Available', 12490000, 'Unbooked', 'At Showroom', now, now);
    insInv.run('dinv_lhr_2', 'dlr_acc_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'veh_02', 'STK-LHR-2600', 'BYD Atto 3', 'Advance 60.48 kWh', 'Surf Blue', 'Eclipse Black', 'LGXCE43C5R0104411', 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&w=900&q=80', 'Sold', 8990000, 'Completed', 'Delivered', now, now);

    insInv.run('dinv_isb_1', 'dlr_acc_isb_01', 'comp_byd_pk', 'PK', 'br_pk_isb', 'veh_03', 'STK-ISB-2601', 'BYD Sealion 6', 'DM-i Super Hybrid AWD', 'Harbour Blue', 'Eclipse Black', 'LGXCE43C5R0107780', 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=900&q=80', 'Available', 12490000, 'Unbooked', 'At Showroom', now, now);
    insInv.run('dinv_ae_1', 'dlr_acc_ae_01', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'veh_04', 'STK-DXB-2600', 'BYD Seal', 'Excellence RWD UAE Spec', 'Arctic White', 'Tahiti Blue', 'LGXAE99C5R0201122', 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=900&q=80', 'Sold', 15800000, 'Completed', 'Delivered', now, now);
    insInv.run('dinv_ae_2', 'dlr_acc_ae_01', 'comp_byd_ae', 'AE', 'br_ae_dxb', null, 'STK-DXB-2601', 'BYD Han', 'EV Flagship AWD 85.4 kWh', 'Emperor Red', 'Nappa Tan Leather', 'LGXAE99C5R0209911', 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=900&q=80', 'Available', 21500000, 'Unbooked', 'At Showroom', now, now);

    // Seed Private Dealer Customers (strictly dealer-isolated CRM)
    const insCust = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_customers (
        id, dealer_id, company_id, country_id, branch_id, full_name, email, phone, city,
        interested_model, requirements, inquiry_status, follow_up_date, appointment_date,
        test_drive_status, communication_history_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insCust.run(
      'dcust_khi_1', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi',
      'Saad bin Tariq', 'saad.tariq@corp-khi.demo', '+92 321 8201144', 'Karachi',
      'BYD Shark 6', 'Corporate utility fleet evaluation with home & office 7kW charger bundle.',
      'Booking Submitted', '2026-11-18', '2026-11-16 15:00', 'Completed',
      JSON.stringify([
        { at: now, by: 'Kamran Siddiqui', channel: 'Showroom Visit', note: 'Completed 25 km Shark 6 DMO test drive in Clifton. Customer submitted booking request.' },
      ]),
      now, now
    );
    insCust.run(
      'dcust_khi_2', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi',
      'Hira Mansoor', 'hira.mansoor@design-khi.demo', '+92 333 9124450', 'Karachi',
      'BYD Seal', 'Looking for Cosmos Black BYD Seal Performance AWD with home wallbox survey.',
      'Test Drive Requested', '2026-11-19', '2026-11-17 11:30', 'Scheduled',
      JSON.stringify([
        { at: now, by: 'Kamran Siddiqui', channel: 'Phone Call', note: 'Scheduled test drive slot at Clifton Marine Drive.' },
      ]),
      now, now
    );
    insCust.run(
      'dcust_khi_3', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi',
      'Zubair Ahmed Qureshi', 'zubair.qureshi@techpk.demo', '+92 302 8561234', 'Karachi',
      'BYD Seal', 'VIP repeat EV buyer — delivered Atlantis Grey BYD Seal Performance AWD.',
      'Closed', null, '2026-02-15 14:00', 'Completed',
      JSON.stringify([
        { at: now, by: 'Kamran Siddiqui', channel: 'Handover', note: 'Vehicle delivered with Blade Battery certificate.' },
      ]),
      now, now
    );

    insCust.run(
      'dcust_lhr_1', 'dlr_acc_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr',
      'Bilal Mahmood Chaudhry', 'bilal.chaudhry@lhr-holdings.demo', '+92 300 4412980', 'Lahore',
      'BYD Sealion 6', 'Interested in Harbour Blue DM-i Super Hybrid for Lahore-Islamabad M-2 commute.',
      'Appointment Scheduled', '2026-11-20', '2026-11-18 16:00', 'Requested',
      JSON.stringify([
        { at: now, by: 'Faisal Humayun', channel: 'WhatsApp Advisory', note: 'Sent official M-2 Supercharger corridor range brochure.' },
      ]),
      now, now
    );
    insCust.run(
      'dcust_lhr_2', 'dlr_acc_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr',
      'Amina Nawaz', 'amina.nawaz@lhr-med.demo', '+92 322 4019932', 'Lahore',
      'BYD Atto 3', 'Completed BYD Atto 3 Advance delivery at Gulberg III.',
      'Closed', null, '2026-04-10 12:00', 'Completed',
      JSON.stringify([{ at: now, by: 'Faisal Humayun', channel: 'Handover', note: 'Delivered BYD Atto 3 Surf Blue.' }]),
      now, now
    );

    insCust.run(
      'dcust_ae_1', 'dlr_acc_ae_01', 'comp_byd_ae', 'AE', 'br_ae_dxb',
      'Omar Al-Mansoor', 'omar.mansoor@byduae.demo', '+971 52 9981122', 'Dubai',
      'BYD Seal', 'Dubai Festival City VIP delivery.',
      'Closed', null, '2026-03-18 11:00', 'Completed',
      JSON.stringify([{ at: now, by: 'Tariq Al-Qasimi', channel: 'Handover', note: 'Completed UAE spec BYD Seal handover.' }]),
      now, now
    );

    // Seed Dealer Bookings & Sales + Commissions
    const insBk = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_bookings (
        id, booking_ref, dealer_id, customer_id, inventory_id, company_id, country_id, branch_id,
        vehicle_model, variant, agreed_price_pkr, booking_status, payment_status, delivery_status,
        notes, reviewed_by, reviewed_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insBk.run('dbk_khi_1', 'DBK-KHI-2026-101', 'dlr_acc_khi_01', 'dcust_khi_1', 'dinv_khi_3', 'comp_byd_pk', 'PK', 'br_pk_khi', 'BYD Shark 6', 'DMO Off-Road PHEV Pickup', 18490000, 'Pending Approval', 'Pending Verification', 'Pending PDI', 'Corporate deposit slip uploaded; awaiting branch finance verification.', null, null, now, now);
    insBk.run('dbk_khi_2', 'DBK-KHI-2026-100', 'dlr_acc_khi_01', 'dcust_khi_3', 'dinv_khi_4', 'comp_byd_pk', 'PK', 'br_pk_khi', 'BYD Seal', 'Performance AWD 82.5 kWh', 16990000, 'Converted to Sale', 'Fully Paid', 'Delivered', 'VIP corporate handover completed with full warranty pack.', 'Intekhab Alam', now, now, now);
    insBk.run('dbk_lhr_1', 'DBK-LHR-2026-100', 'dlr_acc_lhr_01', 'dcust_lhr_2', 'dinv_lhr_2', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'BYD Atto 3', 'Advance 60.48 kWh', 8990000, 'Converted to Sale', 'Fully Paid', 'Delivered', 'Delivered in Gulberg III showroom.', 'Sarmad Khawaja', now, now, now);
    insBk.run('dbk_ae_1', 'DBK-DXB-2026-100', 'dlr_acc_ae_01', 'dcust_ae_1', 'dinv_ae_1', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'BYD Seal', 'Excellence RWD UAE Spec', 15800000, 'Converted to Sale', 'Fully Paid', 'Delivered', 'GCC compliance certificate verified.', 'Rashid Al-Nuaimi', now, now, now);

    // Generate real receipt documents on private disk for completed sales
    const khiReceiptKey = 'dlr_acc_khi_01_receipt_100.txt';
    const khiReceiptBody = `BYD PAKISTAN 360 - AUTHORIZED DEALER SALE RECEIPT\nSale Ref: DSALE-KHI-2026-100\nDealer: Mega Motor Flagship 3S — Clifton (DLR-PK-KHI-01)\nCustomer: Zubair Ahmed Qureshi\nVehicle: BYD Seal Performance AWD 82.5 kWh\nVIN: LGXCE43C5R0108924\nSale Amount: PKR 16,990,000\nPayment Status: Payment Verified (1LINK-PAY-884120)\nDelivery Status: Delivered\n`;
    if (!fs.existsSync(path.join(privateDealerDir, khiReceiptKey))) {
      fs.writeFileSync(path.join(privateDealerDir, khiReceiptKey), khiReceiptBody, 'utf8');
    }
    sqlite
      .prepare(`
        INSERT OR IGNORE INTO dealer_documents (
          id, dealer_id, company_id, doc_type, title, original_filename, mime_type,
          size_bytes, storage_key, verification_status, reviewed_by, review_notes,
          uploaded_by_id, uploaded_by_role, created_at, updated_at
        ) VALUES ('ddoc_khi_rcpt1', 'dlr_acc_khi_01', 'comp_byd_pk', 'Agreement', 'Verified Sale Receipt DSALE-KHI-2026-100', 'sale-receipt-100.txt', 'text/plain', ?, ?, 'Verified', 'Intekhab Alam', 'Reconciled with corporate ledger.', 'system_finance', 'Finance Admin', ?, ?)
      `)
      .run(Buffer.byteLength(khiReceiptBody), khiReceiptKey, now, now);

    const insSale = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_sales (
        id, sale_ref, booking_id, dealer_id, customer_id, inventory_id, company_id, country_id, branch_id,
        vehicle_model, vin, sale_amount_pkr, paid_amount_pkr, payment_status, payment_provider_ref,
        delivery_status, delivered_at, receipt_doc_id, verified_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Payment Verified', ?, 'Delivered', ?, ?, ?, ?, ?)
    `);
    insSale.run('dsale_khi_1', 'DSALE-KHI-2026-100', 'dbk_khi_2', 'dlr_acc_khi_01', 'dcust_khi_3', 'dinv_khi_4', 'comp_byd_pk', 'PK', 'br_pk_khi', 'BYD Seal', 'LGXCE43C5R0108924', 16990000, 16990000, '1LINK-PAY-884120', now.slice(0, 10), 'ddoc_khi_rcpt1', 'Sarmad Khawaja', now, now);
    insSale.run('dsale_lhr_1', 'DSALE-LHR-2026-100', 'dbk_lhr_1', 'dlr_acc_lhr_01', 'dcust_lhr_2', 'dinv_lhr_2', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'BYD Atto 3', 'LGXCE43C5R0104411', 8990000, 8990000, '1LINK-PAY-884291', now.slice(0, 10), null, 'Sarmad Khawaja', now, now);
    insSale.run('dsale_ae_1', 'DSALE-DXB-2026-100', 'dbk_ae_1', 'dlr_acc_ae_01', 'dcust_ae_1', 'dinv_ae_1', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'BYD Seal', 'LGXAE99C5R0201122', 15800000, 15800000, 'FAB-UAE-552104', now.slice(0, 10), null, 'Rashid Al-Nuaimi', now, now);

    // Seed Dealer Commissions (Paid, Approved & Pending states)
    const insComm = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_commissions (
        id, dealer_id, sale_id, company_id, country_id, branch_id, sale_amount_pkr,
        commission_rate_pct, commission_amount_pkr, status, approved_by, approved_at,
        paid_at, payout_reference, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insComm.run('dcomm_khi_1', 'dlr_acc_khi_01', 'dsale_khi_1', 'comp_byd_pk', 'PK', 'br_pk_khi', 16990000, 4.5, 764550, 'Paid', 'Intekhab Alam', now, now.slice(0, 10), 'IBFT-PK-2026-9910', 'Q4 flagship dealer commission settled via corporate IBFT.', now, now);
    insComm.run('dcomm_lhr_1', 'dlr_acc_lhr_01', 'dsale_lhr_1', 'comp_byd_pk', 'PK', 'br_pk_lhr', 8990000, 4.25, 382075, 'Approved', 'Sarmad Khawaja', now, null, null, 'Approved for next bi-weekly settlement batch.', now, now);
    insComm.run('dcomm_ae_1', 'dlr_acc_ae_01', 'dsale_ae_1', 'comp_byd_ae', 'AE', 'br_ae_dxb', 15800000, 5.0, 790000, 'Paid', 'Rashid Al-Nuaimi', now, now.slice(0, 10), 'UAE-WIRE-44812', 'Settled via FAB corporate settlement.', now, now);

    // Seed Dealer Notifications & Support Requests
    const insNotif = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_notifications (
        id, dealer_id, company_id, country_id, branch_id, category, title, message,
        sender_name, sender_role, priority, is_read, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `);
    insNotif.run('dnot_khi_1', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', 'Allocation Notice', 'New BYD Seal Performance AWD Stock Assigned', 'Your showroom has been allocated Cosmos Black BYD Seal (STK-KHI-2601) at official ex-showroom pricing.', 'Usman Tariq Qazi', 'Branch Manager', 'High', now);
    insNotif.run('dnot_all_pk', null, 'comp_byd_pk', 'PK', null, 'Company Directive', 'November 2026 EV Financing & Blade Battery PDI Protocol', 'All verified BYD Pakistan dealers must submit payment proofs through the Bookings module for finance sign-off prior to handover.', 'Intekhab Alam', 'Founder & CEO', 'High', now);
    insNotif.run('dnot_ae_1', 'dlr_acc_ae_01', 'comp_byd_ae', 'AE', 'br_ae_dxb', 'Allocation Notice', 'BYD Han Flagship Unit Allocated', 'Emperor Red BYD Han EV (STK-DXB-2601) ready in Dubai Discovery Centre.', 'Saeed Al-Habtoor', 'Branch Manager', 'Normal', now);

    const insSup = sqlite.prepare(`
      INSERT OR IGNORE INTO dealer_support_requests (
        id, ticket_number, dealer_id, company_id, country_id, branch_id, category, priority,
        subject, description, status, assigned_manager_name, resolution_notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insSup.run('dsup_khi_1', 'DSUP-2026-101', 'dlr_acc_khi_01', 'comp_byd_pk', 'PK', 'br_pk_khi', 'Allocation & PDI', 'Medium', 'Request 2 additional BYD Atto 3 demo vehicles for weekend test drive camp', 'Clifton promenade EV showcase expected to bring 40+ prospect bookings.', 'In Progress', 'Usman Tariq Qazi', 'Reviewing regional transit availability from Port Qasim depot.', now, now);
    insSup.run('dsup_lhr_1', 'DSUP-2026-102', 'dlr_acc_lhr_01', 'comp_byd_pk', 'PK', 'br_pk_lhr', 'Commission Statement', 'Low', 'Clarify payout batch date for DSALE-LHR-2026-100', 'Commission approved; requesting exact IBFT value date.', 'Open', 'Ayesha Siddiqui', null, now, now);

    logDealerActivity({
      dealerId: 'dlr_acc_khi_01',
      companyId: 'comp_byd_pk',
      countryId: 'PK',
      branchId: 'br_pk_khi',
      actorId: 'system_seed',
      actorName: 'Intekhab Alam',
      actorRole: 'Founder & CEO',
      action: 'DEALER_ACCOUNT_VERIFIED',
      module: 'Dealer Governance',
      targetId: 'DLR-PK-KHI-01',
      details: 'Verified dealership portal credentials and assigned Clifton 3S showroom inventory.',
    });
  }
}

export function logBranchActivity(entry: {
  branchId: string;
  companyId: string;
  countryId: string;
  managerId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO branch_activity_logs (
        id, branch_id, company_id, country_id, manager_id, actor_name, actor_role, action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `bml_${crypto.randomBytes(8).toString('hex')}`,
      entry.branchId,
      entry.companyId,
      entry.countryId,
      entry.managerId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

export const PRIVATE_EMPLOYEE_DOCS_DIR = path.join(path.dirname(DB_PATH), 'private_employee_docs');
export const PRIVATE_DEALER_DOCS_DIR = path.join(path.dirname(DB_PATH), 'private_dealer_docs');
export const PRIVATE_CUSTOMER_DOCS_DIR = path.join(path.dirname(DB_PATH), 'private_customer_docs');

export function logCustomerActivity(entry: {
  customerId: string;
  companyId?: string | null;
  countryId?: string | null;
  branchId?: string | null;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO customer_activity_logs (
        id, customer_id, company_id, country_id, branch_id, actor_id, actor_name, actor_role,
        action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `cal_cus_${crypto.randomBytes(8).toString('hex')}`,
      entry.customerId,
      entry.companyId || 'comp_byd_pk',
      entry.countryId || null,
      entry.branchId || null,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

function seedCustomerPortalData(now: string) {
  const existingCustCount = (sqlite.prepare('SELECT COUNT(*) as cnt FROM customer_accounts').get() as { cnt: number }).cnt;
  if (existingCustCount > 0) return;

  const fallbackPassHash = hashPassword('BYD-Enterprise-2026!');
  const legacyCust1 = sqlite.prepare('SELECT * FROM users WHERE id = ?').get('usr_cust_1') as any;
  const legacyCustAe = sqlite.prepare('SELECT * FROM users WHERE id = ?').get('usr_cust_ae') as any;

  const insCust = sqlite.prepare(`
    INSERT OR IGNORE INTO customer_accounts (
      id, customer_code, company_id, country_id, branch_id, full_name, email, mobile,
      password_hash, role, account_type, country, city, address, verification_status,
      status, email_verified, mobile_verified, two_factor_enabled, verified_by, verified_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Customer', 'Individual Customer', ?, ?, ?, ?, 'Active', 1, ?, 0, 'system_seed', ?, ?, ?)
  `);

  insCust.run(
    'cust_pk_001',
    'CUS-PK-2026-001',
    legacyCust1?.company_id || 'comp_byd_pk',
    'PK',
    legacyCust1?.branch_id || 'br_pk_khi',
    legacyCust1?.full_name || 'Zubair Ahmed Qureshi',
    (legacyCust1?.email || 'zubair.qureshi@techpk.demo').toLowerCase(),
    legacyCust1?.mobile || '+92 302 8561234',
    legacyCust1?.password_hash || fallbackPassHash,
    'PK',
    legacyCust1?.city || 'Karachi',
    'House 42-B, Khayaban-e-Shahbaz, DHA Phase 6, Karachi',
    'Verified',
    1,
    now,
    now,
    now
  );

  insCust.run(
    'cust_ae_002',
    'CUS-AE-2026-002',
    legacyCustAe?.company_id || 'comp_byd_ae',
    'AE',
    legacyCustAe?.branch_id || 'br_ae_dxb',
    legacyCustAe?.full_name || 'Omar Al-Mansoor',
    (legacyCustAe?.email || 'omar.mansoor@byduae.demo').toLowerCase(),
    legacyCustAe?.mobile || '+971 52 9981122',
    legacyCustAe?.password_hash || fallbackPassHash,
    'AE',
    legacyCustAe?.city || 'Dubai',
    'Villa 18, Emirates Hills Sector E, Dubai, UAE',
    'Verified',
    1,
    now,
    now,
    now
  );

  const insProf = sqlite.prepare(`
    INSERT OR IGNORE INTO customer_profiles (
      customer_id, avatar_url, cnic_or_id, preferred_language, preferred_currency,
      preferred_dealership_id, communication_prefs_json, emergency_contact, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insProf.run(
    'cust_pk_001',
    'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=256&q=80',
    '42301-8849201-7',
    'en',
    'PKR',
    'dlr_khi_clifton',
    JSON.stringify({ emailUpdates: true, serviceReminders: true, warrantyAlerts: true, promotionalOffers: true }),
    '+92 300 2119044 (Sana Qureshi)',
    now
  );
  insProf.run(
    'cust_ae_002',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
    '784-1988-4429102-1',
    'en',
    'AED',
    'dlr_dxb_dfc',
    JSON.stringify({ emailUpdates: true, serviceReminders: true, warrantyAlerts: true, promotionalOffers: false }),
    '+971 50 9980011',
    now
  );

  const insVer = sqlite.prepare(`
    INSERT OR IGNORE INTO customer_verifications (
      id, customer_id, channel, target, status, provider, verified_at, created_at
    ) VALUES (?, ?, ?, ?, 'Verified', ?, ?, ?)
  `);
  insVer.run('cver_pk_email', 'cust_pk_001', 'email', 'zubair.qureshi@techpk.demo', 'Verified Identity Seed', now, now);
  insVer.run('cver_ae_email', 'cust_ae_002', 'email', 'omar.mansoor@byduae.demo', 'Verified Identity Seed', now, now);

  // Sync owned customer vehicles cleanly from vehicles table
  const insCustVeh = sqlite.prepare(`
    INSERT OR IGNORE INTO customer_vehicles (
      id, customer_id, vehicle_id, company_id, country_id, branch_id, dealership_id, dealership_name,
      vin, chassis_number, model, variant, color, model_year, license_plate, registration_date,
      odometer_km, battery_capacity_kwh, battery_health_soh, battery_health_soc,
      warranty_start_date, warranty_expiry_date, next_service_due_km, status, image_url, ownership_verified, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 2026, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
  `);

  insCustVeh.run(
    'cveh_pk_1',
    'cust_pk_001',
    'veh_01',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'dlr_khi_clifton',
    'Mega Motor Flagship 3S — Clifton',
    'LGXCE43C5R0108924',
    'BYD-PK-2026-08924',
    'BYD Seal',
    'Performance AWD 82.5 kWh',
    'Atlantis Grey',
    'KHI-EV-902',
    '2026-02-15',
    8420,
    82.5,
    98.8,
    84,
    '2026-02-15',
    '2034-02-15',
    15000,
    'Active',
    'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80',
    now,
    now
  );

  insCustVeh.run(
    'cveh_pk_2',
    'cust_pk_001',
    'veh_02',
    'comp_byd_pk',
    'PK',
    'br_pk_lhr',
    'dlr_lhr_gulberg',
    'BYD Lahore Central 3S — Gulberg III',
    'LGXCE43C5R0104411',
    'BYD-PK-2026-04411',
    'BYD Atto 3',
    'Advance 60.48 kWh',
    'Surf Blue',
    'LHR-EV-411',
    '2026-04-10',
    4150,
    60.48,
    99.3,
    76,
    '2026-04-10',
    '2034-04-10',
    10000,
    'Active',
    'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80',
    now,
    now
  );

  insCustVeh.run(
    'cveh_ae_1',
    'cust_ae_002',
    'veh_04',
    'comp_byd_ae',
    'AE',
    'br_ae_dxb',
    'dlr_dxb_dfc',
    'BYD Dubai Flagship Discovery Centre',
    'LGXAE99C5R0201122',
    'BYD-AE-2026-01122',
    'BYD Seal',
    'Excellence RWD UAE Spec',
    'Arctic White',
    'DXB-EV-7741',
    '2026-03-18',
    11200,
    82.5,
    98.1,
    79,
    '2026-03-18',
    '2034-03-18',
    20000,
    'Active',
    'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=800&q=80',
    now,
    now
  );

  // Seed Favorites
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_favorites (id, customer_id, inventory_id, model, variant, dealer_id, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run('cfav_1', 'cust_pk_001', 'dinv_khi_2', 'BYD Atto 3', 'Extended Range Superior 60.48 kWh', 'dlr_acc_khi_01', 'Considering second family EV for Lahore commute', now);

  // Seed Inquiries
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_inquiries (
      id, inquiry_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
      inventory_id, vehicle_model, variant, inquiry_type, subject, message, preferred_contact,
      status, assigned_to_name, reply_text, replied_by, replied_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cinq_pk_1',
    'INQ-CUS-2026-101',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'dlr_acc_khi_01',
    'Mega Motor Flagship 3S — Clifton',
    'dinv_khi_1',
    'BYD Seal',
    'Performance AWD 82.5 kWh',
    'Price & Variant',
    '7kW Home Wallbox Installation with Sealion 6 / Seal Order',
    'Please confirm home wallbox charger installation lead time in DHA Phase 6 Karachi and warranty coverage.',
    'Email',
    'Replied',
    'Farhan Zaidi',
    'Official 7kW BYD AC Wallbox installation takes 48 hours after electrical load survey at DHA Phase 6. Covered under 2-year accessory warranty.',
    'Farhan Zaidi (Clifton 3S)',
    now,
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_inquiries (
      id, inquiry_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
      inventory_id, vehicle_model, variant, inquiry_type, subject, message, preferred_contact,
      status, assigned_to_name, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cinq_ae_1',
    'INQ-CUS-2026-201',
    'cust_ae_002',
    'comp_byd_ae',
    'AE',
    'br_ae_dxb',
    'dlr_acc_ae_01',
    'BYD Dubai Flagship Discovery Centre',
    'dinv_dxb_1',
    'BYD Han EV',
    'Flagship 85.4 kWh AWD',
    'Vehicle Information',
    'Corporate Fleet Specification for BYD Han EV',
    'Requesting GCC cooling package telemetry and 3-year fleet maintenance plan details.',
    'Email',
    'Under Review',
    'Al-Futtaim Dubai Mobility Team',
    now,
    now
  );

  // Seed Test Drive Requests
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_test_drive_requests (
      id, request_number, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
      inventory_id, vehicle_model, variant, preferred_date, preferred_time, city, notes,
      status, assigned_staff_name, showroom_notes, confirmed_by, confirmed_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'ctd_pk_1',
    'TD-CUS-2026-301',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'br_pk_isb',
    'dlr_acc_isb_01',
    'BYD Capital Hub 3S — Blue Area',
    'dinv_isb_1',
    'BYD Sealion 6',
    'Design DM-i Super Hybrid AWD',
    '2026-11-28',
    '03:00 PM',
    'Islamabad',
    'Interested in evaluating DM-i hybrid range for Islamabad-Lahore motorway travel.',
    'Confirmed',
    'Engr. Bilal Hashmi',
    'Demo vehicle prepared at Blue Area VIP bay. Please bring valid driver license.',
    'Engr. Bilal Hashmi',
    now,
    now,
    now
  );

  // Seed Customer Bookings + Invoices + Payments + Documents
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_bookings (
      id, booking_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
      inventory_id, vehicle_model, variant, exterior_color, interior_color,
      quoted_price_pkr, booking_deposit_pkr, booking_status, payment_status, delivery_status,
      payment_instructions, customer_notes, admin_notes, reviewed_by, reviewed_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cbk_pk_1',
    'BK-CUS-2026-001',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'dlr_acc_khi_01',
    'Mega Motor Flagship 3S — Clifton',
    'dinv_khi_1',
    'BYD Seal',
    'Performance AWD 82.5 kWh',
    'Atlantis Grey',
    'Tahiti Blue Leather',
    16990000,
    16990000,
    'Completed',
    'Fully Paid',
    'Delivered',
    'Settled via verified 1LINK / IBFT Corporate Clearing.',
    'Deliver with 7kW Home Wallbox kit.',
    'Full payment cleared and vehicle handed over on 2026-02-15.',
    'Intekhab Alam',
    '2026-02-15T10:00:00Z',
    '2026-02-10T09:00:00Z',
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_bookings (
      id, booking_ref, customer_id, company_id, country_id, branch_id, dealer_id, dealership_name,
      inventory_id, vehicle_model, variant, exterior_color, interior_color,
      quoted_price_pkr, booking_deposit_pkr, booking_status, payment_status, delivery_status,
      payment_instructions, customer_notes, admin_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cbk_ae_1',
    'BK-CUS-2026-002',
    'cust_ae_002',
    'comp_byd_ae',
    'AE',
    'br_ae_dxb',
    'dlr_acc_ae_01',
    'BYD Dubai Flagship Discovery Centre',
    'dinv_dxb_1',
    'BYD Seal',
    'Excellence RWD UAE Spec',
    'Arctic White',
    'Eclipse Black Vegan Leather',
    15800000,
    15800000,
    'Completed',
    'Fully Paid',
    'Delivered',
    'Settled via FAB UAE Corporate Direct.',
    'VIP Dubai delivery.',
    'Delivered at Dubai Festival City showroom.',
    '2026-03-10T09:00:00Z',
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_invoices (
      id, invoice_number, customer_id, booking_id, company_id, country_id, branch_id, dealership_name,
      item_category, vehicle_model, currency, subtotal_pkr, tax_rate, tax_amount_pkr, total_amount_pkr,
      amount_paid_pkr, outstanding_balance_pkr, status, issued_date, due_date, notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cinv_pk_1',
    'INV-BYD-PK-2026-10421',
    'cust_pk_001',
    'cbk_pk_1',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'Mega Motor Flagship 3S — Clifton',
    'Vehicle Purchase',
    'BYD Seal Performance AWD',
    'PKR',
    14398305,
    18.0,
    2591695,
    16990000,
    16990000,
    0,
    'Paid',
    '2026-02-15',
    '2026-02-15',
    'Official tax invoice for BYD Seal VIN LGXCE43C5R0108924.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_invoices (
      id, invoice_number, customer_id, booking_id, company_id, country_id, branch_id, dealership_name,
      item_category, vehicle_model, currency, subtotal_pkr, tax_rate, tax_amount_pkr, total_amount_pkr,
      amount_paid_pkr, outstanding_balance_pkr, status, issued_date, due_date, notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cinv_ae_1',
    'INV-BYD-AE-2026-20911',
    'cust_ae_002',
    'cbk_ae_1',
    'comp_byd_ae',
    'AE',
    'br_ae_dxb',
    'BYD Dubai Flagship Discovery Centre',
    'Vehicle Purchase',
    'BYD Seal Excellence RWD',
    'AED',
    15047619,
    5.0,
    752381,
    15800000,
    15800000,
    0,
    'Paid',
    '2026-03-18',
    '2026-03-18',
    'Official UAE tax invoice for BYD Seal VIN LGXAE99C5R0201122.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_payments (
      id, payment_ref, customer_id, booking_id, invoice_id, company_id, country_id, branch_id,
      currency, amount_pkr, amount_local, payment_method, gateway_name, transaction_ref,
      payment_status, payment_date, verified_by, verified_at, notes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Paid', ?, 'Shahida Parveen (Finance Manager)', ?, ?, ?)
  `).run(
    'cpay_pk_1',
    'PAY-CUS-PK-9841',
    'cust_pk_001',
    'cbk_pk_1',
    'cinv_pk_1',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'PKR',
    16990000,
    16990000,
    'Verified Bank IBFT',
    '1LINK Corporate Clearing',
    'AUTH-PK-884120',
    '2026-02-15',
    '2026-02-15T11:30:00Z',
    'Full vehicle invoice settlement verified by BYD Pakistan Finance.',
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_payments (
      id, payment_ref, customer_id, booking_id, invoice_id, company_id, country_id, branch_id,
      currency, amount_pkr, amount_local, payment_method, gateway_name, transaction_ref,
      payment_status, payment_date, verified_by, verified_at, notes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Paid', ?, 'UAE Finance Desk', ?, ?, ?)
  `).run(
    'cpay_ae_1',
    'PAY-CUS-AE-5521',
    'cust_ae_002',
    'cbk_ae_1',
    'cinv_ae_1',
    'comp_byd_ae',
    'AE',
    'br_ae_dxb',
    'AED',
    15800000,
    189000,
    'UAE Wire Transfer',
    'FAB UAE Direct',
    'AUTH-AE-552104',
    '2026-03-18',
    '2026-03-18T14:00:00Z',
    'UAE showroom settlement verified.',
    now
  );

  // Seed Customer Service Requests & Service History
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_service_requests (
      id, request_number, customer_id, customer_vehicle_id, vin, model, license_plate,
      company_id, country_id, branch_id, dealership_id, dealership_name, service_type,
      preferred_date, preferred_time, complaint_details, status, technician_assigned,
      estimated_cost_pkr, advisor_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'csvc_pk_1',
    'BYD-SVC-2026-841',
    'cust_pk_001',
    'cveh_pk_1',
    'LGXCE43C5R0108924',
    'BYD Seal',
    'KHI-EV-902',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'dlr_khi_clifton',
    'Mega Motor Flagship 3S — Clifton',
    'Blade Battery Health Diagnostic',
    '2026-11-18',
    '10:30 AM',
    'Scheduled 6-month high-voltage isolation & Blade Battery cell balance verification.',
    'In Workshop',
    'Hamza Rafiq (EV Master Tech)',
    12500,
    'HV safety lock engaged; BMS cell delta measured at 0.011V.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_service_history (
      id, customer_id, customer_vehicle_id, service_request_id, vin, model, dealership_name,
      service_date, service_type, odometer_km, summary, technician_name, cost_pkr, next_reminder_date, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'chist_pk_1',
    'cust_pk_001',
    'cveh_pk_1',
    null,
    'LGXCE43C5R0108924',
    'BYD Seal',
    'Mega Motor Flagship 3S — Clifton',
    '2026-09-20',
    'Routine Maintenance (5,000 km Inspection)',
    5120,
    'Battery SoH verified at 99.1%. Cabin HEPA filter inspected. OTA firmware updated to BYD-OS-14.2.1-PK.',
    'Hamza Rafiq (EV Master Tech)',
    12000,
    '2027-03-20',
    now
  );

  // Seed Warranty Records & Claims
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_warranty_records (
      id, warranty_number, customer_id, customer_vehicle_id, vin, model, company_id,
      coverage_type, battery_warranty_years, vehicle_warranty_years, start_date, expiry_date,
      terms_summary, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 8, 6, ?, ?, ?, 'Active', ?, ?)
  `).run(
    'cwar_pk_1',
    'WAR-BYD-PK-8924',
    'cust_pk_001',
    'cveh_pk_1',
    'LGXCE43C5R0108924',
    'BYD Seal',
    'comp_byd_pk',
    'Blade Battery (8 Yr / 160,000 km) & Vehicle Bumper-to-Bumper (6 Yr / 150,000 km)',
    '2026-02-15',
    '2034-02-15',
    'Covers LFP Blade Battery pack against >30% capacity loss for 8 years / 160,000 km and traction motor, BMS, DiLink hardware for 6 years / 150,000 km subject to periodic 3S inspections.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_warranty_records (
      id, warranty_number, customer_id, customer_vehicle_id, vin, model, company_id,
      coverage_type, battery_warranty_years, vehicle_warranty_years, start_date, expiry_date,
      terms_summary, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 8, 6, ?, ?, ?, 'Active', ?, ?)
  `).run(
    'cwar_pk_2',
    'WAR-BYD-PK-4411',
    'cust_pk_001',
    'cveh_pk_2',
    'LGXCE43C5R0104411',
    'BYD Atto 3',
    'comp_byd_pk',
    'Blade Battery (8 Yr / 160,000 km) & Vehicle Bumper-to-Bumper (6 Yr / 150,000 km)',
    '2026-04-10',
    '2034-04-10',
    'Official manufacturer LFP Blade Battery & drivetrain protection under Mega Motor Pakistan service compliance.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_warranty_records (
      id, warranty_number, customer_id, customer_vehicle_id, vin, model, company_id,
      coverage_type, battery_warranty_years, vehicle_warranty_years, start_date, expiry_date,
      terms_summary, status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 8, 6, ?, ?, ?, 'Active', ?, ?)
  `).run(
    'cwar_ae_1',
    'WAR-BYD-AE-1122',
    'cust_ae_002',
    'cveh_ae_1',
    'LGXAE99C5R0201122',
    'BYD Seal',
    'comp_byd_ae',
    'GCC Blade Battery (8 Yr / 200,000 km) & Vehicle (6 Yr)',
    '2026-03-18',
    '2034-03-18',
    'Al-Futtaim / BYD Middle East GCC EV warranty protection.',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_warranty_claims (
      id, claim_number, customer_id, warranty_record_id, vin, vehicle_model, company_id, country_id, branch_id,
      dealership_name, component_category, issue_description, fault_code, submission_date,
      status, claim_amount_pkr, approved_amount_pkr, review_notes, reviewed_by, reviewed_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'cwclm_pk_1',
    'BYD-WAR-2026-0041',
    'cust_pk_001',
    'cwar_pk_1',
    'LGXCE43C5R0108924',
    'BYD Seal',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'Mega Motor Flagship 3S — Clifton',
    'Infotainment System',
    '15.6-inch rotating DiLink display motor actuator emitting clicking sound during orientation switch.',
    'DILINK_ROT_MTR_WARN',
    '2026-10-14',
    'Approved',
    85000,
    85000,
    'Approved 100% under official 6-year vehicle warranty. Zero customer liability.',
    'Dr. Asim Raza (Warranty Manager)',
    '2026-10-16T12:00:00Z',
    now,
    now
  );

  // Seed Private Customer Vault Document Record (synthesizes verified PDF on download if file not uploaded manually)
  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_booking_documents (
      id, customer_id, booking_id, doc_category, doc_title, file_name, mime_type,
      file_size, storage_path, verification_status, verified_by, verified_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'application/pdf', ?, ?, 'Verified', 'Mega Motor Clifton 3S', ?, ?)
  `).run(
    'cdoc_pk_1',
    'cust_pk_001',
    'cbk_pk_1',
    'Warranty Certificate',
    'Official 8-Year Blade Battery & Vehicle Warranty Certificate (LGXCE43C5R0108924)',
    'BYD_Warranty_Cert_LGXCE43C5R0108924.pdf',
    2048,
    'virtual:warranty:cwar_pk_1',
    now,
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_booking_documents (
      id, customer_id, booking_id, doc_category, doc_title, file_name, mime_type,
      file_size, storage_path, verification_status, verified_by, verified_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'application/pdf', ?, ?, 'Verified', 'Dubai Festival City 3S', ?, ?)
  `).run(
    'cdoc_ae_1',
    'cust_ae_002',
    'cbk_ae_1',
    'Invoice',
    'Official UAE Vehicle Tax Invoice (INV-BYD-AE-2026-20911)',
    'INV-BYD-AE-2026-20911.pdf',
    2048,
    'virtual:invoice:cinv_ae_1',
    now,
    now
  );

  // Seed Notifications & Support Tickets
  const insCustNotif = sqlite.prepare(`
    INSERT OR IGNORE INTO customer_notifications (
      id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
  `);
  insCustNotif.run(
    'cnot_pk_1',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'Service',
    'Service Ticket BYD-SVC-2026-841 In Workshop',
    'Mega Motor Flagship Clifton workshop has completed HV battery lock inspection on your BYD Seal (KHI-EV-902).',
    'Normal',
    'service',
    now
  );
  insCustNotif.run(
    'cnot_pk_2',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'Test Drive',
    'Test Drive Confirmed — BYD Sealion 6 (Islamabad)',
    'Your test drive TD-CUS-2026-301 at BYD Capital Hub Blue Area is confirmed for 2026-11-28 at 03:00 PM.',
    'High',
    'test-drives',
    now
  );
  insCustNotif.run(
    'cnot_ae_1',
    'cust_ae_002',
    'comp_byd_ae',
    'AE',
    'Announcement',
    'BYD UAE GCC Winter Thermal Diagnostic Program',
    'Complimentary Blade Battery cell balance diagnostic available at Dubai Festival City.',
    'Normal',
    'overview',
    now
  );

  sqlite.prepare(`
    INSERT OR IGNORE INTO customer_support_tickets (
      id, ticket_number, customer_id, company_id, country_id, branch_id, category, priority,
      subject, description, status, assigned_to_name, reply_text, replied_by, replied_at, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    'csup_pk_1',
    'SUP-CUS-2026-771',
    'cust_pk_001',
    'comp_byd_pk',
    'PK',
    'br_pk_khi',
    'Charging & Wallbox',
    'Medium',
    'Confirm CCS2 fast charger compatibility card for M-2 Motorway Bhera Hub',
    'Requesting RFID fast-charging activation linked to VIN LGXCE43C5R0108924.',
    'Resolved',
    'Daniyal Sheikh (Customer Care)',
    'Your RFID Hubco Green / BYD priority card has been activated for M-2 Bhera and Clifton ultra-fast terminals.',
    'Daniyal Sheikh',
    now,
    now,
    now
  );

  logCustomerActivity({
    customerId: 'cust_pk_001',
    companyId: 'comp_byd_pk',
    countryId: 'PK',
    branchId: 'br_pk_khi',
    actorId: 'system_seed',
    actorName: 'Intekhab Alam',
    actorRole: 'Founder & CEO',
    action: 'CUSTOMER_ACCOUNT_VERIFIED',
    module: 'Customer Governance',
    targetId: 'CUS-PK-2026-001',
    details: 'Synced verified BYD Pakistan customer account, vehicles, warranties, and invoices.',
  });
}

export function logDealerActivity(entry: {
  dealerId: string;
  companyId: string;
  countryId?: string | null;
  branchId?: string | null;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO dealer_activity_logs (
        id, dealer_id, company_id, country_id, branch_id, actor_id, actor_name, actor_role,
        action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `dal_${crypto.randomBytes(8).toString('hex')}`,
      entry.dealerId,
      entry.companyId,
      entry.countryId || null,
      entry.branchId || null,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

export function logEmployeeActivity(entry: {
  employeeId: string;
  companyId: string;
  branchId?: string | null;
  countryId?: string | null;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO employee_activity_logs (
        id, employee_id, company_id, branch_id, country_id, actor_name, actor_role, action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `eal_${crypto.randomBytes(8).toString('hex')}`,
      entry.employeeId,
      entry.companyId,
      entry.branchId || null,
      entry.countryId || null,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

export function logCountryActivity(entry: {
  countryId: string;
  managerId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO country_activity_logs (
        id, country_id, manager_id, actor_name, actor_role, action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `cml_${crypto.randomBytes(8).toString('hex')}`,
      entry.countryId,
      entry.managerId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

export function logCompanyActivity(entry: {
  companyId: string;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  sqlite
    .prepare(`
      INSERT INTO company_activity_logs (
        id, company_id, actor_id, actor_name, actor_role, action, module, target_id, details, ip_address, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `cal_${crypto.randomBytes(8).toString('hex')}`,
      entry.companyId,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      nowIso()
    );
}

export function logAdminActivity(entry: {
  adminId: string;
  adminName: string;
  adminRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
  userAgent?: string | null;
  sessionId?: string | null;
}) {
  const { deviceName, browserName } = parseUserAgentInfo(entry.userAgent || null);
  sqlite
    .prepare(`
      INSERT INTO admin_activity_logs (
        id, admin_id, admin_name, admin_role, action, module, target_id, details, ip_address, status, device_name, browser_name, session_id, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `adm_${crypto.randomBytes(8).toString('hex')}`,
      entry.adminId,
      entry.adminName,
      entry.adminRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      deviceName,
      browserName,
      entry.sessionId || null,
      entry.userAgent ? String(entry.userAgent).slice(0, 240) : null,
      nowIso()
    );
}

export function logOwnerAudit(entry: {
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  companyId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
  userAgent?: string | null;
  sessionId?: string | null;
}) {
  const { deviceName, browserName } = parseUserAgentInfo(entry.userAgent || null);
  sqlite
    .prepare(`
      INSERT INTO owner_audit_logs (
        id, actor_id, actor_name, actor_role, action, module, target_id, company_id, details, ip_address, status, device_name, browser_name, session_id, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `aud_${crypto.randomBytes(8).toString('hex')}`,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.companyId || null,
      entry.details || null,
      entry.ipAddress || 'server',
      entry.status || 'SUCCESS',
      entry.userAgent ? deviceName : null,
      entry.userAgent ? browserName : null,
      entry.sessionId || null,
      entry.userAgent || null,
      nowIso()
    );
}

export function logSecurityEvent(entry: {
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  eventType: string;
  userId?: string | null;
  identifier?: string | null;
  companyId?: string | null;
  details: string;
  ipAddress?: string | null;
}) {
  sqlite
    .prepare(`
      INSERT INTO security_events (
        id, severity, event_type, user_id, identifier, company_id, details, ip_address, acknowledged, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `)
    .run(
      `sec_${crypto.randomBytes(8).toString('hex')}`,
      entry.severity,
      entry.eventType,
      entry.userId || null,
      entry.identifier || null,
      entry.companyId || null,
      entry.details,
      entry.ipAddress || 'unknown',
      nowIso()
    );
}

export function getSystemSetting<T>(key: string, fallback: T): T {
  const row = sqlite.prepare('SELECT value_json FROM system_settings WHERE key = ?').get(key) as { value_json: string } | undefined;
  if (!row) return fallback;
  try {
    return JSON.parse(row.value_json) as T;
  } catch {
    return fallback;
  }
}

export function setSystemSetting(key: string, value: unknown, updatedBy: string) {
  sqlite
    .prepare(`
      INSERT INTO system_settings (key, value_json, updated_by, updated_at)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET
        value_json = excluded.value_json,
        updated_by = excluded.updated_by,
        updated_at = excluded.updated_at
    `)
    .run(key, JSON.stringify(value), updatedBy, nowIso());
}

const SENSITIVE_META_KEY_RE = /(password|passhash|token|otp|secret|code|recovery|auth|cookie)/i;

function sanitizeAuditMeta(input: Record<string, unknown> | undefined): Record<string, unknown> {
  if (!input) return {};
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(input)) {
    if (SENSITIVE_META_KEY_RE.test(k)) {
      out[k] = '[REDACTED]';
    } else if (v && typeof v === 'object' && !Array.isArray(v)) {
      out[k] = sanitizeAuditMeta(v as Record<string, unknown>);
    } else {
      out[k] = v;
    }
  }
  return out;
}

export function logSecurityAudit(entry: {
  actorId: string;
  actorName: string;
  actorRole: string;
  targetUserId?: string | null;
  companyId?: string | null;
  countryId?: string | null;
  branchId?: string | null;
  action: string;
  category: string;
  severity?: 'INFO' | 'WARNING' | 'CRITICAL';
  details: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string | null;
  userAgent?: string | null;
}) {
  const safeMeta = sanitizeAuditMeta(entry.metadata);
  sqlite
    .prepare(`
      INSERT INTO security_audit_logs (
        id, actor_id, actor_name, actor_role, target_user_id, company_id, country_id, branch_id,
        action, category, severity, details, metadata_json, ip_address, user_agent, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `sal_${crypto.randomBytes(8).toString('hex')}`,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.targetUserId || null,
      entry.companyId || null,
      entry.countryId || null,
      entry.branchId || null,
      entry.action,
      entry.category,
      entry.severity || 'INFO',
      entry.details,
      JSON.stringify(safeMeta),
      entry.ipAddress || 'server',
      (entry.userAgent || '').slice(0, 220),
      nowIso()
    );
}

export const RBAC_ROLES = ['Founder / CEO', 'Super Admin', 'Admin', 'Employees', 'Dealers', 'Customers'] as const;
export const RBAC_MODULES = [
  'Vehicles & Inventory',
  'Bookings & Service',
  'Companies & Branches',
  'Dealerships',
  'Customers & CRM',
  'Employees & HR',
  'Finance & Invoices',
  'RBAC & Roles',
  'Security & Audit Logs',
  'System & Backup',
] as const;

export type RbacAction = 'view' | 'create' | 'edit' | 'delete' | 'approve';

export function mapSubjectToRbacRole(subjectType: string, rawRole?: string | null): (typeof RBAC_ROLES)[number] {
  if (subjectType === 'founder' || rawRole === 'Founder / Owner' || rawRole === 'Founder & CEO') return 'Founder / CEO';
  if (subjectType === 'super_admin' || rawRole === 'Super Admin') return 'Super Admin';
  if (['company_admin', 'country_manager', 'branch_manager'].includes(subjectType)) return 'Admin';
  if (subjectType === 'dealer') return 'Dealers';
  if (subjectType === 'customer') return 'Customers';
  return 'Employees';
}

export function checkRbacAction(
  subjectType: string,
  rawRole: string,
  moduleKey: string,
  action: RbacAction
): boolean {
  if (subjectType === 'founder' || rawRole === 'Founder / Owner' || rawRole === 'Founder & CEO') {
    return true;
  }
  const mappedRole = mapSubjectToRbacRole(subjectType, rawRole);
  const col =
    action === 'view'
      ? 'can_view'
      : action === 'create'
        ? 'can_create'
        : action === 'edit'
          ? 'can_edit'
          : action === 'delete'
            ? 'can_delete'
            : 'can_approve';
  const row = sqlite
    .prepare(`SELECT ${col} as allowed FROM rbac_role_action_permissions WHERE role_key = ? AND module_key = ?`)
    .get(mappedRole, moduleKey) as { allowed?: number } | undefined;
  return Boolean(row?.allowed);
}

export function recordPasswordHistory(userId: string, subjectType: string, passwordHash: string): void {
  if (!userId || !passwordHash) return;
  sqlite
    .prepare('INSERT INTO password_history (id, user_id, subject_type, password_hash, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(`pwh_${crypto.randomBytes(6).toString('hex')}`, userId, subjectType, passwordHash, nowIso());
}

export function isPasswordReused(userId: string, plainPassword: string, limit = 5): boolean {
  if (!userId || !plainPassword) return false;
  const rows = sqlite
    .prepare('SELECT password_hash FROM password_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(userId, Math.max(1, limit)) as Array<{ password_hash: string }>;
  for (const r of rows) {
    if (verifyPassword(plainPassword, r.password_hash)) return true;
  }
  return false;
}

export function logLoginActivity(entry: {
  userId?: string | null;
  subjectType: string;
  identifier: string;
  accountName?: string | null;
  role?: string | null;
  companyId?: string | null;
  countryId?: string | null;
  branchId?: string | null;
  sessionId?: string | null;
  success: boolean;
  failureReason?: string | null;
  mfaMethod?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  deviceFingerprint?: string | null;
  suspicious?: boolean;
  suspiciousReason?: string | null;
}) {
  const { deviceName, browserName } = parseUserAgentInfo(entry.userAgent);
  sqlite
    .prepare(`
      INSERT INTO login_activity_logs (
        id, user_id, subject_type, identifier, account_name, role, company_id, country_id, branch_id,
        session_id, success, failure_reason, mfa_method, ip_address, user_agent, device_name, browser_name,
        device_fingerprint, suspicious, suspicious_reason, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `lal_${crypto.randomBytes(8).toString('hex')}`,
      entry.userId || null,
      entry.subjectType,
      entry.identifier,
      entry.accountName || null,
      entry.role || null,
      entry.companyId || null,
      entry.countryId || null,
      entry.branchId || null,
      entry.sessionId || null,
      entry.success ? 1 : 0,
      entry.failureReason || null,
      entry.mfaMethod || null,
      entry.ipAddress || 'unknown',
      (entry.userAgent || '').slice(0, 220),
      deviceName,
      browserName,
      entry.deviceFingerprint || null,
      entry.suspicious ? 1 : 0,
      entry.suspiciousReason || null,
      nowIso()
    );
}

export function markLoginSessionTerminated(sessionIdOrUserId: string, reason: string, byUserId = false): void {
  if (!sessionIdOrUserId) return;
  const now = nowIso();
  if (byUserId) {
    sqlite
      .prepare('UPDATE login_activity_logs SET logout_at = ?, termination_reason = ? WHERE user_id = ? AND success = 1 AND logout_at IS NULL')
      .run(now, reason, sessionIdOrUserId);
  } else {
    sqlite
      .prepare('UPDATE login_activity_logs SET logout_at = ?, termination_reason = ? WHERE session_id = ? AND success = 1 AND logout_at IS NULL')
      .run(now, reason, sessionIdOrUserId);
  }
}

function mapVerificationStatus(rawStatus: string | null | undefined, emailVerified: boolean): string {
  const s = (rawStatus || '').trim();
  if (s === 'Verified' || s === 'Active') return 'Verified';
  if (s === 'Rejected') return 'Rejected';
  if (s === 'Suspended') return 'Suspended';
  if (s === 'Expired') return 'Expired';
  if (s === 'Under Review') return 'Under Review';
  if (s === 'Pending Verification' || s === 'Pending Approval' || s === 'Email Verified' || emailVerified) {
    return 'Pending Verification';
  }
  return 'Not Submitted';
}

export function syncUnifiedSecurityRegistry() {
  const now = nowIso();

  const upsertUnified = (row: {
    id: string;
    subjectType: string;
    sourceTable: string;
    role: string;
    fullName: string;
    email: string;
    mobile?: string | null;
    companyId?: string | null;
    countryId?: string | null;
    branchId?: string | null;
    accountCode?: string | null;
    status: string;
    verificationStatus: string;
    emailVerified: boolean;
    mobileVerified: boolean;
    mfaRequired: boolean;
    mfaEnabled: boolean;
    totpSecret?: string | null;
    recoveryCodesJson?: string | null;
    termsAccepted?: boolean;
    termsAcceptedAt?: string | null;
    privacyAccepted?: boolean;
    privacyAcceptedAt?: string | null;
    approvedBy?: string | null;
    approvedAt?: string | null;
    rejectionReason?: string | null;
    lastLoginAt?: string | null;
    createdAt?: string | null;
    city?: string | null;
    address?: string | null;
    cnicOrId?: string | null;
    employeeCode?: string | null;
    dealerCode?: string | null;
    customerCode?: string | null;
    managerCode?: string | null;
    jobTitle?: string | null;
    department?: string | null;
  }) => {
    const cleanEmail = String(row.email || '').trim().toLowerCase();
    if (!cleanEmail) return;
    const normMob = normalizePhone(row.mobile || '');
    const verifiedPhone = row.mobileVerified && normMob ? normMob : null;
    const compNameRow = row.companyId
      ? (sqlite.prepare('SELECT name FROM companies WHERE id = ?').get(row.companyId) as any)
      : null;

    sqlite
      .prepare(`
        INSERT INTO user_accounts (
          id, subject_type, source_table, role, full_name, email, mobile, verified_phone,
          company_id, country_id, branch_id, account_code, status, verification_status,
          email_verified, mobile_verified, mfa_required, mfa_enabled,
          terms_accepted, terms_accepted_at, privacy_accepted, privacy_accepted_at,
          approved_by, approved_at, rejection_reason, last_login_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          role = excluded.role,
          full_name = excluded.full_name,
          email = excluded.email,
          mobile = excluded.mobile,
          verified_phone = excluded.verified_phone,
          company_id = excluded.company_id,
          country_id = excluded.country_id,
          branch_id = excluded.branch_id,
          account_code = excluded.account_code,
          status = excluded.status,
          verification_status = CASE
            WHEN user_accounts.verification_status IN ('Under Review', 'Verified', 'Rejected', 'Suspended', 'Expired')
             AND excluded.verification_status = 'Pending Verification'
            THEN user_accounts.verification_status
            ELSE excluded.verification_status
          END,
          email_verified = excluded.email_verified,
          mobile_verified = excluded.mobile_verified,
          mfa_required = excluded.mfa_required,
          mfa_enabled = excluded.mfa_enabled,
          terms_accepted = MAX(user_accounts.terms_accepted, excluded.terms_accepted),
          terms_accepted_at = COALESCE(user_accounts.terms_accepted_at, excluded.terms_accepted_at),
          privacy_accepted = MAX(user_accounts.privacy_accepted, excluded.privacy_accepted),
          privacy_accepted_at = COALESCE(user_accounts.privacy_accepted_at, excluded.privacy_accepted_at),
          approved_by = COALESCE(excluded.approved_by, user_accounts.approved_by),
          approved_at = COALESCE(excluded.approved_at, user_accounts.approved_at),
          rejection_reason = COALESCE(excluded.rejection_reason, user_accounts.rejection_reason),
          last_login_at = COALESCE(excluded.last_login_at, user_accounts.last_login_at),
          updated_at = excluded.updated_at
      `)
      .run(
        row.id,
        row.subjectType,
        row.sourceTable,
        row.role,
        row.fullName,
        cleanEmail,
        row.mobile || null,
        verifiedPhone,
        row.companyId || null,
        row.countryId || null,
        row.branchId || null,
        row.accountCode || null,
        row.status,
        row.verificationStatus,
        row.emailVerified ? 1 : 0,
        row.mobileVerified ? 1 : 0,
        row.mfaRequired ? 1 : 0,
        row.mfaEnabled ? 1 : 0,
        row.termsAccepted ? 1 : 0,
        row.termsAcceptedAt || null,
        row.privacyAccepted ? 1 : 0,
        row.privacyAcceptedAt || null,
        row.approvedBy || null,
        row.approvedAt || null,
        row.rejectionReason || null,
        row.lastLoginAt || null,
        row.createdAt || now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO user_profiles (
          user_id, full_name, phone, country, city, address, cnic_or_id,
          employee_code, dealer_code, customer_code, manager_code, job_title, department,
          company_name, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          full_name = excluded.full_name,
          phone = excluded.phone,
          country = excluded.country,
          city = excluded.city,
          address = excluded.address,
          cnic_or_id = COALESCE(excluded.cnic_or_id, user_profiles.cnic_or_id),
          company_name = COALESCE(excluded.company_name, user_profiles.company_name),
          updated_at = excluded.updated_at
      `)
      .run(
        row.id,
        row.fullName,
        row.mobile || null,
        row.countryId || 'PK',
        row.city || 'Karachi',
        row.address || null,
        row.cnicOrId || null,
        row.employeeCode || null,
        row.dealerCode || null,
        row.customerCode || null,
        row.managerCode || null,
        row.jobTitle || row.role,
        row.department || null,
        compNameRow?.name || null,
        now
      );

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO user_role_assignments (
          id, user_id, role_key, company_id, country_id, branch_id, scope_type, assigned_by, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'system_sync', 'Active', ?, ?)
      `)
      .run(
        `ura_${row.id}`,
        row.id,
        row.role,
        row.companyId || null,
        row.countryId || null,
        row.branchId || null,
        row.subjectType,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO identity_verification_records (
          id, user_id, subject_type, role, company_id, country_id, branch_id,
          verification_status, email_verified, mobile_verified, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          email_verified = excluded.email_verified,
          mobile_verified = excluded.mobile_verified,
          company_id = excluded.company_id,
          country_id = excluded.country_id,
          branch_id = excluded.branch_id,
          verification_status = CASE
            WHEN identity_verification_records.verification_status IN ('Verified', 'Rejected', 'Suspended', 'Expired', 'Under Review')
             AND excluded.verification_status = 'Pending Verification'
            THEN identity_verification_records.verification_status
            WHEN excluded.verification_status = 'Verified'
            THEN 'Verified'
            ELSE identity_verification_records.verification_status
          END,
          updated_at = excluded.updated_at
      `)
      .run(
        `ivr_${row.id}`,
        row.id,
        row.subjectType,
        row.role,
        row.companyId || null,
        row.countryId || null,
        row.branchId || null,
        row.verificationStatus,
        row.emailVerified ? 1 : 0,
        row.mobileVerified ? 1 : 0,
        row.createdAt || now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO mfa_settings (
          user_id, subject_type, totp_enabled, email_otp_enabled, sms_otp_enabled,
          totp_secret, mfa_required, enrolled_at, updated_at
        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
          mfa_required = excluded.mfa_required,
          totp_enabled = CASE WHEN mfa_settings.enrolled_at IS NOT NULL THEN mfa_settings.totp_enabled ELSE excluded.totp_enabled END,
          totp_secret = COALESCE(mfa_settings.totp_secret, excluded.totp_secret),
          updated_at = excluded.updated_at
      `)
      .run(
        row.id,
        row.subjectType,
        row.mfaEnabled ? 1 : 0,
        row.mfaEnabled ? 1 : 0,
        row.totpSecret || null,
        row.mfaRequired ? 1 : 0,
        row.mfaEnabled ? (row.createdAt || now) : null,
        now
      );

    // Sync recovery hashes if present and table has none yet
    if (row.recoveryCodesJson) {
      try {
        const existingRc = sqlite.prepare('SELECT COUNT(*) as c FROM mfa_recovery_codes WHERE user_id = ?').get(row.id) as any;
        if ((existingRc?.c || 0) === 0) {
          const codes = JSON.parse(row.recoveryCodesJson);
          if (Array.isArray(codes)) {
            const insRc = sqlite.prepare(
              'INSERT INTO mfa_recovery_codes (id, user_id, subject_type, code_hash, created_at) VALUES (?, ?, ?, ?, ?)'
            );
            for (const codeHash of codes) {
              if (typeof codeHash === 'string' && codeHash.length >= 16) {
                insRc.run(`mrc_${crypto.randomBytes(6).toString('hex')}`, row.id, row.subjectType, codeHash, now);
              }
            }
          }
        }
      } catch {
        // ignore invalid recovery codes json
      }
    }
  };

  try {
    // 1. Founders
    for (const f of sqlite.prepare('SELECT * FROM founder_accounts').all() as any[]) {
      upsertUnified({
        id: f.id,
        subjectType: 'founder',
        sourceTable: 'founder_accounts',
        role: 'Founder / Owner',
        fullName: f.founder_name,
        email: f.email,
        mobile: f.mobile,
        countryId: 'GLOBAL',
        city: 'Karachi HQ',
        status: f.is_verified ? 'Active' : 'Pending Verification',
        verificationStatus: f.is_verified ? 'Verified' : 'Pending Verification',
        emailVerified: Boolean(f.is_verified),
        mobileVerified: false,
        mfaRequired: true,
        mfaEnabled: Boolean(f.two_factor_enabled),
        totpSecret: f.two_factor_secret,
        recoveryCodesJson: f.recovery_codes_json,
        termsAccepted: true,
        termsAcceptedAt: f.created_at,
        privacyAccepted: true,
        privacyAcceptedAt: f.created_at,
        approvedBy: 'Primary Founder Provisioning',
        approvedAt: f.created_at,
        lastLoginAt: f.last_login_at,
        createdAt: f.created_at,
      });
    }

    // 2. Super Admins
    for (const sa of sqlite.prepare('SELECT * FROM super_admin_accounts').all() as any[]) {
      upsertUnified({
        id: sa.id,
        subjectType: 'super_admin',
        sourceTable: 'super_admin_accounts',
        role: 'Super Admin',
        fullName: sa.full_name,
        email: sa.email,
        mobile: sa.mobile,
        countryId: sa.country || 'PK',
        city: sa.city || 'Karachi',
        status: sa.status,
        verificationStatus: sa.status === 'Active' ? 'Verified' : sa.status,
        emailVerified: Boolean(sa.email_verified),
        mobileVerified: false,
        mfaRequired: true,
        mfaEnabled: Boolean(sa.two_factor_enabled),
        totpSecret: sa.two_factor_secret,
        recoveryCodesJson: sa.recovery_codes_json,
        termsAccepted: true,
        termsAcceptedAt: sa.created_at,
        privacyAccepted: true,
        privacyAcceptedAt: sa.created_at,
        approvedBy: sa.authorized_by_founder_id,
        approvedAt: sa.status === 'Active' ? sa.created_at : null,
        lastLoginAt: sa.last_login_at,
        createdAt: sa.created_at,
      });
    }

    // 3. Company Admins
    for (const ca of sqlite.prepare('SELECT * FROM company_admin_accounts').all() as any[]) {
      upsertUnified({
        id: ca.id,
        subjectType: 'company_admin',
        sourceTable: 'company_admin_accounts',
        role: 'Company Admin',
        fullName: ca.full_name,
        email: ca.email,
        mobile: ca.mobile,
        companyId: ca.company_id,
        status: ca.status,
        verificationStatus: ca.status === 'Active' ? 'Verified' : ca.status,
        emailVerified: Boolean(ca.email_verified),
        mobileVerified: false,
        mfaRequired: true,
        mfaEnabled: Boolean(ca.two_factor_enabled),
        totpSecret: ca.two_factor_secret,
        recoveryCodesJson: ca.recovery_codes_json,
        jobTitle: ca.designation || 'Company Admin',
        approvedBy: ca.authorized_by,
        lastLoginAt: ca.last_login_at,
        createdAt: ca.created_at,
      });
    }

    // 4. Country Managers
    for (const cm of sqlite.prepare('SELECT * FROM country_manager_accounts').all() as any[]) {
      upsertUnified({
        id: cm.id,
        subjectType: 'country_manager',
        sourceTable: 'country_manager_accounts',
        role: 'Country Manager',
        fullName: cm.full_name,
        email: cm.email,
        mobile: cm.mobile,
        countryId: cm.country_id,
        accountCode: cm.manager_code,
        managerCode: cm.manager_code,
        status: cm.status,
        verificationStatus: cm.status === 'Active' ? 'Verified' : cm.status,
        emailVerified: Boolean(cm.email_verified),
        mobileVerified: false,
        mfaRequired: true,
        mfaEnabled: Boolean(cm.two_factor_enabled),
        totpSecret: cm.two_factor_secret,
        recoveryCodesJson: cm.recovery_codes_json,
        jobTitle: cm.designation || 'Country Manager',
        approvedBy: cm.authorized_by,
        lastLoginAt: cm.last_login_at,
        createdAt: cm.created_at,
      });
    }

    // 5. Branch Managers
    for (const bm of sqlite.prepare('SELECT * FROM branch_manager_accounts').all() as any[]) {
      upsertUnified({
        id: bm.id,
        subjectType: 'branch_manager',
        sourceTable: 'branch_manager_accounts',
        role: 'Branch Manager',
        fullName: bm.full_name,
        email: bm.email,
        mobile: bm.mobile,
        companyId: bm.company_id,
        countryId: bm.country_id,
        branchId: bm.branch_id,
        accountCode: bm.manager_code,
        managerCode: bm.manager_code,
        status: bm.status,
        verificationStatus: bm.status === 'Active' ? 'Verified' : bm.status,
        emailVerified: Boolean(bm.email_verified),
        mobileVerified: false,
        mfaRequired: true,
        mfaEnabled: Boolean(bm.two_factor_enabled),
        totpSecret: bm.two_factor_secret,
        recoveryCodesJson: bm.recovery_codes_json,
        jobTitle: bm.designation || 'Branch Manager',
        approvedBy: bm.authorized_by,
        lastLoginAt: bm.last_login_at,
        createdAt: bm.created_at,
      });
    }

    // 6. Employees
    for (const emp of sqlite.prepare('SELECT * FROM employee_accounts').all() as any[]) {
      upsertUnified({
        id: emp.id,
        subjectType: 'employee',
        sourceTable: 'employee_accounts',
        role: 'Employee',
        fullName: emp.full_name,
        email: emp.email,
        mobile: emp.mobile,
        companyId: emp.company_id,
        countryId: emp.country_id || 'PK',
        branchId: emp.branch_id,
        accountCode: emp.employee_code,
        employeeCode: emp.employee_code,
        jobTitle: emp.job_position,
        department: emp.department,
        status: emp.status,
        verificationStatus: emp.status === 'Active' ? 'Verified' : mapVerificationStatus(emp.status, Boolean(emp.email_verified)),
        emailVerified: Boolean(emp.email_verified),
        mobileVerified: false,
        mfaRequired: false,
        mfaEnabled: Boolean(emp.two_factor_enabled),
        totpSecret: emp.two_factor_secret,
        recoveryCodesJson: emp.recovery_codes_json,
        lastLoginAt: emp.last_login_at,
        createdAt: emp.created_at,
      });
    }

    // 7. Dealers
    for (const d of sqlite.prepare('SELECT * FROM dealer_accounts').all() as any[]) {
      upsertUnified({
        id: d.id,
        subjectType: 'dealer',
        sourceTable: 'dealer_accounts',
        role: 'Dealer',
        fullName: d.business_name,
        email: d.email,
        mobile: d.mobile,
        companyId: d.company_id,
        countryId: d.country_id,
        branchId: d.branch_id,
        accountCode: d.dealer_code,
        dealerCode: d.dealer_code,
        status: d.status,
        verificationStatus: mapVerificationStatus(d.verification_status, Boolean(d.email_verified)),
        emailVerified: Boolean(d.email_verified),
        mobileVerified: false,
        mfaRequired: false,
        mfaEnabled: Boolean(d.two_factor_enabled),
        totpSecret: d.two_factor_secret,
        recoveryCodesJson: d.recovery_codes_json,
        approvedBy: d.approved_by,
        approvedAt: d.approved_at,
        rejectionReason: d.rejection_reason,
        lastLoginAt: d.last_login_at,
        createdAt: d.created_at,
      });
    }

    // 8. Customers
    for (const c of sqlite.prepare('SELECT * FROM customer_accounts').all() as any[]) {
      const cp = sqlite.prepare('SELECT cnic_or_id FROM customer_profiles WHERE customer_id = ?').get(c.id) as any;
      upsertUnified({
        id: c.id,
        subjectType: 'customer',
        sourceTable: 'customer_accounts',
        role: 'Customer',
        fullName: c.full_name,
        email: c.email,
        mobile: c.mobile,
        companyId: c.company_id,
        countryId: c.country_id || c.country || 'PK',
        branchId: c.branch_id,
        accountCode: c.customer_code,
        customerCode: c.customer_code,
        city: c.city,
        address: c.address,
        cnicOrId: cp?.cnic_or_id || null,
        status: c.status,
        verificationStatus: c.verification_status === 'Verified' ? 'Verified' : mapVerificationStatus(c.verification_status, Boolean(c.email_verified)),
        emailVerified: Boolean(c.email_verified),
        mobileVerified: Boolean(c.mobile_verified),
        mfaRequired: false,
        mfaEnabled: Boolean(c.two_factor_enabled),
        totpSecret: c.two_factor_secret,
        recoveryCodesJson: c.recovery_codes_json,
        termsAccepted: Boolean(c.terms_accepted),
        termsAcceptedAt: c.terms_accepted_at,
        privacyAccepted: Boolean(c.privacy_accepted),
        privacyAcceptedAt: c.privacy_accepted_at,
        lastLoginAt: c.last_login_at,
        createdAt: c.created_at,
      });
    }

    // Seed initial password_history entries only when none exist yet (preserves all passwords)
    const tablesForHistory: Array<{ table: string; subj: string }> = [
      { table: 'founder_accounts', subj: 'founder' },
      { table: 'super_admin_accounts', subj: 'super_admin' },
      { table: 'company_admin_accounts', subj: 'company_admin' },
      { table: 'country_manager_accounts', subj: 'country_manager' },
      { table: 'branch_manager_accounts', subj: 'branch_manager' },
      { table: 'employee_accounts', subj: 'employee' },
      { table: 'dealer_accounts', subj: 'dealer' },
      { table: 'customer_accounts', subj: 'customer' },
    ];
    for (const t of tablesForHistory) {
      const rows = sqlite.prepare(`SELECT id, password_hash FROM ${t.table} WHERE password_hash IS NOT NULL`).all() as Array<{ id: string; password_hash: string }>;
      for (const r of rows) {
        if (!r.password_hash) continue;
        const hasHist = sqlite.prepare('SELECT 1 FROM password_history WHERE user_id = ? LIMIT 1').get(r.id);
        if (!hasHist) {
          recordPasswordHistory(r.id, t.subj, r.password_hash);
        }
      }
    }
  } catch (err) {
    console.error('[syncUnifiedSecurityRegistry] error:', (err as Error)?.message);
  }
}

export function logOrganizationActivity(entry: {
  actorId: string;
  actorName: string;
  actorRole: string;
  scopeCompanyId?: string | null;
  scopeCountryId?: string | null;
  scopeRegionalOfficeId?: string | null;
  scopeBranchId?: string | null;
  action: string;
  module: string;
  entityType: string;
  entityId?: string | null;
  entityName?: string | null;
  details?: string | null;
  ipAddress?: string | null;
}) {
  sqlite
    .prepare(`
      INSERT INTO organization_activity_logs (
        id, actor_id, actor_name, actor_role, scope_company_id, scope_country_id,
        scope_regional_office_id, scope_branch_id, action, module, entity_type,
        entity_id, entity_name, details, ip_address, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `oal_${crypto.randomBytes(8).toString('hex')}`,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.scopeCompanyId || null,
      entry.scopeCountryId || null,
      entry.scopeRegionalOfficeId || null,
      entry.scopeBranchId || null,
      entry.action,
      entry.module,
      entry.entityType,
      entry.entityId || null,
      entry.entityName || null,
      entry.details || null,
      entry.ipAddress || 'unknown',
      nowIso()
    );
}

export function generateNextEmployeeCode(companyId: string, countryId = 'PK'): string {
  const settings = sqlite
    .prepare('SELECT employee_id_prefix FROM employee_module_settings WHERE company_id = ?')
    .get(companyId) as { employee_id_prefix?: string } | undefined;
  const iso = String(countryId || 'PK').toUpperCase();
  const defaultPrefix = iso === 'PK' ? 'BYD-PAK-EMP-' : `BYD-${iso}-EMP-`;
  const prefix = settings?.employee_id_prefix || defaultPrefix;

  const existingCodes = sqlite
    .prepare('SELECT employee_code FROM employee_accounts')
    .all() as Array<{ employee_code: string }>;

  let maxNum = 0;
  for (const row of existingCodes) {
    const m = String(row.employee_code || '').match(/(\d+)$/);
    if (m) {
      const n = parseInt(m[1], 10);
      if (Number.isFinite(n) && n > maxNum) maxNum = n;
    }
  }

  let seq = maxNum + 1;
  while (true) {
    const candidate = `${prefix}${String(seq).padStart(4, '0')}`;
    const taken = sqlite
      .prepare('SELECT id FROM employee_accounts WHERE UPPER(employee_code) = UPPER(?)')
      .get(candidate);
    if (!taken) return candidate;
    seq += 1;
  }
}

export function recordEmployeeHistory(entry: {
  employeeId: string;
  companyId: string;
  changeType: 'Profile' | 'Position' | 'Promotion' | 'Transfer' | 'Salary' | 'Status';
  previousValue?: string | null;
  newValue?: string | null;
  effectiveDate?: string;
  notes?: string | null;
  changedById: string;
  changedByName: string;
}) {
  const ts = nowIso();
  sqlite
    .prepare(`
      INSERT INTO employee_history (
        id, employee_id, company_id, change_type, previous_value, new_value,
        effective_date, notes, changed_by_id, changed_by_name, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `eh_${crypto.randomBytes(6).toString('hex')}`,
      entry.employeeId,
      entry.companyId,
      entry.changeType,
      entry.previousValue || null,
      entry.newValue || null,
      entry.effectiveDate || ts.slice(0, 10),
      entry.notes || null,
      entry.changedById,
      entry.changedByName,
      ts
    );
}

export function logEmployeeAudit(entry: {
  employeeId?: string | null;
  companyId?: string | null;
  branchId?: string | null;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
}) {
  const ts = nowIso();
  sqlite
    .prepare(`
      INSERT INTO employee_audit_logs (
        id, employee_id, company_id, branch_id, actor_id, actor_name, actor_role,
        action, module, target_id, details, ip_address, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `eal_${crypto.randomBytes(8).toString('hex')}`,
      entry.employeeId || null,
      entry.companyId || null,
      entry.branchId || null,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'unknown',
      ts
    );

  if (entry.employeeId && entry.companyId) {
    logEmployeeActivity({
      employeeId: entry.employeeId,
      companyId: entry.companyId,
      branchId: entry.branchId || null,
      actorName: entry.actorName,
      actorRole: entry.actorRole,
      action: entry.action,
      module: entry.module,
      targetId: entry.targetId || null,
      details: entry.details || null,
      ipAddress: entry.ipAddress || 'unknown',
    });
  }
}

export function generateNextDealerCode(countryId = 'PK', city = 'Karachi'): string {
  const ctry = String(countryId || 'PK').replace(/[^a-zA-Z]/g, '').slice(0, 2).toUpperCase() || 'PK';
  const cityPrefix = String(city || 'KHI').replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase() || 'HQX';
  const prefix = `DLR-${ctry}-${cityPrefix}-`;

  const existingCodes = sqlite
    .prepare('SELECT dealer_code FROM dealer_accounts')
    .all() as Array<{ dealer_code: string }>;

  let maxNum = 0;
  for (const row of existingCodes) {
    const code = String(row.dealer_code || '').toUpperCase();
    if (code.startsWith(prefix)) {
      const m = code.match(/(\d+)$/);
      if (m) {
        const n = parseInt(m[1], 10);
        if (Number.isFinite(n) && n > maxNum) maxNum = n;
      }
    }
  }

  let seq = maxNum + 1;
  while (true) {
    const candidate = `${prefix}${String(seq).padStart(2, '0')}`;
    const taken = sqlite
      .prepare('SELECT id FROM dealer_accounts WHERE UPPER(dealer_code) = UPPER(?)')
      .get(candidate);
    if (!taken) return candidate;
    seq += 1;
  }
}

export function generateNextShowroomCode(countryId = 'PK', city = 'Karachi'): string {
  const ctry = String(countryId || 'PK').replace(/[^a-zA-Z]/g, '').slice(0, 2).toUpperCase() || 'PK';
  const cityPrefix = String(city || 'KHI').replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase() || 'HQX';
  const prefix = `SHW-${ctry}-${cityPrefix}-`;

  const existingCodes = sqlite
    .prepare('SELECT showroom_code FROM dealer_showrooms')
    .all() as Array<{ showroom_code: string }>;

  let maxNum = 0;
  for (const row of existingCodes) {
    const code = String(row.showroom_code || '').toUpperCase();
    if (code.startsWith(prefix)) {
      const m = code.match(/(\d+)$/);
      if (m) {
        const n = parseInt(m[1], 10);
        if (Number.isFinite(n) && n > maxNum) maxNum = n;
      }
    }
  }

  let seq = maxNum + 1;
  while (true) {
    const candidate = `${prefix}${String(seq).padStart(2, '0')}`;
    const taken = sqlite
      .prepare('SELECT id FROM dealer_showrooms WHERE UPPER(showroom_code) = UPPER(?)')
      .get(candidate);
    if (!taken) return candidate;
    seq += 1;
  }
}

export function logDealerModuleAudit(entry: {
  dealerId?: string | null;
  companyId?: string | null;
  branchId?: string | null;
  countryId?: string | null;
  actorId: string;
  actorName: string;
  actorRole: string;
  action: string;
  module: string;
  targetId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
  status?: 'SUCCESS' | 'WARNING' | 'ALERT';
}) {
  const ts = nowIso();
  sqlite
    .prepare(`
      INSERT INTO dealer_audit_logs (
        id, dealer_id, company_id, branch_id, actor_id, actor_name, actor_role,
        action, module, target_id, details, ip_address, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      `dlral_${crypto.randomBytes(8).toString('hex')}`,
      entry.dealerId || null,
      entry.companyId || null,
      entry.branchId || null,
      entry.actorId,
      entry.actorName,
      entry.actorRole,
      entry.action,
      entry.module,
      entry.targetId || null,
      entry.details || null,
      entry.ipAddress || 'unknown',
      ts
    );

  if (entry.dealerId && entry.companyId) {
    logDealerActivity({
      dealerId: entry.dealerId,
      companyId: entry.companyId,
      countryId: entry.countryId || null,
      branchId: entry.branchId || null,
      actorId: entry.actorId,
      actorName: entry.actorName,
      actorRole: entry.actorRole,
      action: entry.action,
      module: entry.module,
      targetId: entry.targetId || null,
      details: entry.details || null,
      ipAddress: entry.ipAddress || 'unknown',
      status: entry.status || 'SUCCESS',
    });
  }
}

