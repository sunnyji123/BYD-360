import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import multer from 'multer';
import {
  sqlite,
  PRIVATE_VERIFICATION_DOCS_DIR,
  hashPassword,
  verifyPassword,
  sha256,
  generateSecureToken,
  generateNumericOtp,
  validatePasswordStrength,
  generateTotpSecret,
  verifyTotpCode,
  encrypt2faSecret,
  isPasswordReused,
  recordPasswordHistory,
  markLoginSessionTerminated,
  parseUserAgentInfo,
  RBAC_ROLES,
  RBAC_MODULES,
  checkRbacAction,
  normalizePhone,
  logSecurityAudit,
  logOwnerAudit,
  syncUnifiedSecurityRegistry,
  getSystemSetting,
  setSystemSetting,
  nowIso,
} from './db';
import { requireAuth } from './auth';
import { dispatchVerificationEmail, dispatchSmsOtp, isSmtpConfigured, isSmsGatewayConfigured } from './mailer';

const ALLOWED_DOC_MIMES = new Set([
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
]);

const MANDATORY_MFA_ROLES = new Set([
  'Founder / Owner',
  'Super Admin',
  'Company Admin',
  'Country Manager',
  'Branch Manager',
]);

const ADMIN_GOVERNANCE_SUBJECTS = new Set([
  'founder',
  'super_admin',
  'company_admin',
  'country_manager',
  'branch_manager',
]);

const ROLE_SENSITIVITY_RANK: Record<string, number> = {
  'Founder / Owner': 100,
  'Super Admin': 90,
  'Country Manager': 80,
  'Company Admin': 70,
  'Branch Manager': 60,
  Employee: 40,
  Dealer: 35,
  Customer: 10,
};

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.trim()) {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
}

const verificationBuckets = new Map<string, number[]>();
function rateLimitEndpoint(bucketPrefix: string, maxRequests: number, windowMs: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = getClientIp(req);
    const key = `${bucketPrefix}:${ip}`;
    const now = Date.now();
    const recent = (verificationBuckets.get(key) || []).filter((ts) => now - ts < windowMs);
    if (recent.length >= maxRequests) {
      res.status(429).json({
        error: 'Too many verification or security requests from this IP. Please wait before retrying.',
      });
      return;
    }
    recent.push(now);
    verificationBuckets.set(key, recent);
    next();
  };
}

function getSourceTableForSubject(subjectType: string): string | null {
  switch (subjectType) {
    case 'founder':
      return 'founder_accounts';
    case 'super_admin':
      return 'super_admin_accounts';
    case 'company_admin':
      return 'company_admin_accounts';
    case 'country_manager':
      return 'country_manager_accounts';
    case 'branch_manager':
      return 'branch_manager_accounts';
    case 'employee':
      return 'employee_accounts';
    case 'dealer':
      return 'dealer_accounts';
    case 'customer':
      return 'customer_accounts';
    case 'user':
      return 'users';
    default:
      return null;
  }
}

function canAdminAccessTarget(actor: NonNullable<Request['auth']>, targetAccount: any): boolean {
  if (!actor || !targetAccount) return false;
  if (!ADMIN_GOVERNANCE_SUBJECTS.has(actor.subjectType)) return false;
  if (actor.subjectType === 'founder') return true;

  if (actor.subjectType === 'super_admin') {
    if (targetAccount.subject_type === 'founder' || targetAccount.subject_type === 'super_admin') {
      return false;
    }
    return true;
  }

  if (actor.subjectType === 'company_admin') {
    if (!actor.companyId || targetAccount.company_id !== actor.companyId) return false;
    return ['branch_manager', 'employee', 'dealer', 'customer', 'user'].includes(targetAccount.subject_type);
  }

  if (actor.subjectType === 'country_manager') {
    if (!actor.country || targetAccount.country_id !== actor.country) return false;
    return ['company_admin', 'branch_manager', 'employee', 'dealer', 'customer', 'user'].includes(targetAccount.subject_type);
  }

  if (actor.subjectType === 'branch_manager') {
    if (!actor.branchId) return false;
    if (targetAccount.branch_id === actor.branchId) {
      return ['employee', 'dealer', 'customer', 'user'].includes(targetAccount.subject_type);
    }
    if (
      targetAccount.subject_type === 'customer' &&
      actor.companyId &&
      targetAccount.company_id === actor.companyId &&
      (!actor.country || targetAccount.country_id === actor.country)
    ) {
      return true;
    }
    return false;
  }

  return false;
}

const privateDocStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    if (!fs.existsSync(PRIVATE_VERIFICATION_DOCS_DIR)) {
      fs.mkdirSync(PRIVATE_VERIFICATION_DOCS_DIR, { recursive: true, mode: 0o700 });
    }
    cb(null, PRIVATE_VERIFICATION_DOCS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase().replace(/[^a-z0-9.]/g, '') || '.bin';
    cb(null, `vdoc_${generateSecureToken(16)}${ext}`);
  },
});

const uploadPrivateDoc = multer({
  storage: privateDocStorage,
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED_DOC_MIMES.has(file.mimetype.toLowerCase())) {
      cb(new Error('Unsupported file type. Allowed formats: PDF, PNG, JPG, WEBP.'));
      return;
    }
    cb(null, true);
  },
});

function getUserAuthRecord(userId: string) {
  let ua = sqlite.prepare('SELECT * FROM user_accounts WHERE id = ?').get(userId) as any;
  if (!ua) {
    syncUnifiedSecurityRegistry();
    ua = sqlite.prepare('SELECT * FROM user_accounts WHERE id = ?').get(userId) as any;
  }
  return ua;
}

export function createVerificationSecurityRouter() {
  const router = express.Router();

  // -------------------------------------------------------------------------
  // 1. Capabilities Discovery
  // -------------------------------------------------------------------------
  router.get('/capabilities', (_req: Request, res: Response) => {
    const policy = getSystemSetting('security_policy', {
      sessionTimeoutMinutes: 120,
      idleTimeoutMinutes: 45,
      maxFailedLoginAttempts: 5,
      lockoutMinutes: 15,
      otpExpiryMinutes: 10,
      otpMaxAttempts: 5,
      otpCooldownSeconds: 60,
      passwordReuseLimit: 5,
      forgotPasswordCooldownSeconds: 60,
    });
    res.json({
      smtpConfigured: isSmtpConfigured(),
      smsConfigured: isSmsGatewayConfigured(),
      sessionTimeoutMinutes: policy.sessionTimeoutMinutes || 120,
      idleTimeoutMinutes: policy.idleTimeoutMinutes || 45,
      otpExpiryMinutes: policy.otpExpiryMinutes || 10,
      otpMaxAttempts: policy.otpMaxAttempts || 5,
      otpCooldownSeconds: policy.otpCooldownSeconds || 60,
      passwordReuseLimit: policy.passwordReuseLimit || 5,
      mandatoryMfaRoles: Array.from(MANDATORY_MFA_ROLES),
    });
  });

  // -------------------------------------------------------------------------
  // 2. Cryptographic Token Email Verification & Resend with Cooldown
  // -------------------------------------------------------------------------
  const handleVerifyEmailToken = (req: Request, res: Response) => {
    const token = String(req.body?.token || req.query?.token || '').trim();
    if (!token || token.length < 16) {
      res.status(400).json({ error: 'A valid verification token is required.' });
      return;
    }

    const tokenHash = sha256(token);
    const tokenRow = sqlite
      .prepare('SELECT * FROM email_verification_tokens WHERE token_hash = ?')
      .get(tokenHash) as any;

    if (!tokenRow) {
      res.status(400).json({ error: 'Invalid verification token.' });
      return;
    }
    if (tokenRow.used_at) {
      res.status(400).json({ error: 'This verification token has already been used.' });
      return;
    }
    if (new Date(tokenRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'This verification token has expired. Please request a new verification email.' });
      return;
    }

    const now = nowIso();
    const srcTable = getSourceTableForSubject(tokenRow.subject_type);

    sqlite.transaction(() => {
      sqlite.prepare('UPDATE email_verification_tokens SET used_at = ? WHERE id = ?').run(now, tokenRow.id);
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE LOWER(identifier) = LOWER(?) AND used_at IS NULL').run(now, tokenRow.email);

      if (srcTable === 'customer_accounts') {
        sqlite
          .prepare(`
            UPDATE customer_accounts
            SET email_verified = 1,
                status = CASE WHEN status = 'Suspended' THEN 'Suspended' ELSE 'Active' END,
                verification_status = CASE WHEN verification_status = 'Verified' THEN 'Verified' ELSE 'Email Verified' END,
                updated_at = ?
            WHERE id = ?
          `)
          .run(now, tokenRow.user_id);
        sqlite
          .prepare(`
            UPDATE customer_verifications
            SET status = 'Verified', verified_at = ?
            WHERE customer_id = ? AND channel = 'email' AND status = 'Pending'
          `)
          .run(now, tokenRow.user_id);
      } else if (srcTable === 'users') {
        sqlite
          .prepare(`
            UPDATE users
            SET email_verified = 1,
                status = CASE WHEN status = 'Pending Verification' THEN 'Active' ELSE status END,
                updated_at = ?
            WHERE id = ?
          `)
          .run(now, tokenRow.user_id);
      } else if (srcTable && srcTable !== 'founder_accounts') {
        sqlite
          .prepare(`UPDATE ${srcTable} SET email_verified = 1, updated_at = ? WHERE id = ?`)
          .run(now, tokenRow.user_id);
      }
    })();

    syncUnifiedSecurityRegistry();

    logSecurityAudit({
      actorId: tokenRow.user_id,
      actorName: tokenRow.email,
      actorRole: tokenRow.subject_type,
      targetUserId: tokenRow.user_id,
      action: 'EMAIL_VERIFIED_TOKEN',
      category: 'Registration & Verification',
      details: `Email verified via single-use cryptographic token (${tokenRow.email}).`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      email: tokenRow.email,
      subjectType: tokenRow.subject_type,
      message: 'Email verification succeeded. Verification status has been updated.',
    });
  };

  router.post('/email/verify-token', rateLimitEndpoint('evt_verify', 30, 60_000), handleVerifyEmailToken);
  router.get('/email/verify-token', rateLimitEndpoint('evt_verify_get', 30, 60_000), handleVerifyEmailToken);

  router.post('/email/resend', rateLimitEndpoint('evt_resend', 12, 60_000), async (req: Request, res: Response) => {
    const email = String(req.body?.email || req.auth?.email || '').trim().toLowerCase();
    if (!email) {
      res.status(400).json({ error: 'Email address is required.' });
      return;
    }

    syncUnifiedSecurityRegistry();
    const account = sqlite.prepare('SELECT * FROM user_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!account) {
      res.json({
        success: true,
        message: 'If the email belongs to an unverified account, a fresh verification token has been issued.',
      });
      return;
    }

    if (account.email_verified) {
      res.status(400).json({ error: 'This email address is already verified.' });
      return;
    }

    // 60-second per-account resend cooldown
    const latestToken = sqlite
      .prepare('SELECT created_at FROM email_verification_tokens WHERE user_id = ? ORDER BY created_at DESC LIMIT 1')
      .get(account.id) as { created_at: string } | undefined;
    if (latestToken) {
      const elapsedMs = Date.now() - new Date(latestToken.created_at).getTime();
      if (elapsedMs < 60_000) {
        const waitSec = Math.ceil((60_000 - elapsedMs) / 1000);
        res.status(429).json({
          error: `Verification email cooldown active. Please wait ${waitSec} seconds before resending.`,
          retryAfterSeconds: waitSec,
        });
        return;
      }
    }

    const now = nowIso();
    const rawToken = generateSecureToken(32);
    const otpCode = generateNumericOtp(6);
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE email_verification_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL')
        .run(now, account.id);
      sqlite
        .prepare(`
          INSERT INTO email_verification_tokens (id, user_id, subject_type, email, token_hash, expires_at, created_ip, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(`evt_${generateSecureToken(6)}`, account.id, account.subject_type, email, sha256(rawToken), expiresAt, getClientIp(req), now);

      if (account.subject_type === 'customer') {
        sqlite
          .prepare("UPDATE otp_verifications SET used_at = ? WHERE LOWER(identifier) = ? AND purpose = 'cus_email_verify' AND used_at IS NULL")
          .run(now, email);
        sqlite
          .prepare(`
            INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
            VALUES (?, ?, 'cus_email_verify', ?, ?, 'customer', ?, 0, ?)
          `)
          .run(`otp_${generateSecureToken(6)}`, email, sha256(otpCode), account.id, expiresAt, now);
      }
    })();

    const dispatchRes = await dispatchVerificationEmail({
      to: email,
      subject: 'BYD PAKISTAN 360 — Fresh Email Verification',
      text: `Verify your BYD PAKISTAN 360 account (${account.role}) using OTP ${otpCode} or verification token ${rawToken}.`,
    });

    logSecurityAudit({
      actorId: account.id,
      actorName: account.full_name,
      actorRole: account.role,
      targetUserId: account.id,
      companyId: account.company_id,
      action: 'EMAIL_VERIFICATION_RESENT',
      category: 'Registration & Verification',
      details: `Issued new single-use verification token for ${email}.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      expiresAt,
      message: 'A new single-use email verification token has been issued.',
      verificationOutbox:
        dispatchRes.mode === 'dev_outbox'
          ? {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              code: otpCode,
              verificationToken: rawToken,
            }
          : undefined,
    });
  });

  // -------------------------------------------------------------------------
  // 3. Mobile SMS OTP Verification (Real Provider Only — Honest 503 if Unconfigured)
  // -------------------------------------------------------------------------
  router.post('/mobile/request-otp', requireAuth, rateLimitEndpoint('mobile_req_otp', 10, 60_000), async (req: Request, res: Response) => {
    const phone = String(req.body?.phone || req.auth!.mobile || '').trim();
    if (!phone || !/^\+\d[\d\s-]{7,18}$/.test(phone)) {
      res.status(400).json({ error: 'A valid phone number with country code (e.g. +92 300 1234567) is required.' });
      return;
    }

    if (!isSmsGatewayConfigured()) {
      res.status(503).json({
        error: 'External SMS OTP provider is not configured. Phone numbers cannot be verified without a configured Twilio or SMS webhook gateway.',
        smsConfigured: false,
      });
      return;
    }

    const normMob = normalizePhone(phone);
    const conflict = sqlite
      .prepare('SELECT id FROM user_accounts WHERE verified_phone = ? AND mobile_verified = 1 AND id != ?')
      .get(normMob, req.auth!.userId);
    if (conflict) {
      res.status(409).json({ error: 'This mobile number is already verified on another account.' });
      return;
    }

    const recent = sqlite
      .prepare('SELECT created_at FROM mobile_verification_otps WHERE user_id = ? AND phone = ? ORDER BY created_at DESC LIMIT 1')
      .get(req.auth!.userId, normMob) as { created_at: string } | undefined;
    if (recent && Date.now() - new Date(recent.created_at).getTime() < 60_000) {
      res.status(429).json({ error: 'Mobile OTP resend cooldown active. Wait 60 seconds before requesting another SMS OTP.' });
      return;
    }

    const otpCode = generateNumericOtp(6);
    const now = nowIso();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    const smsResult = await dispatchSmsOtp({
      toPhone: normMob,
      message: `BYD PAKISTAN 360 verification OTP: ${otpCode}. Valid for 10 minutes.`,
    });
    if (!smsResult.delivered) {
      res.status(502).json({
        error: `SMS gateway delivery failed (${smsResult.provider}): ${smsResult.error || 'Unknown error'}`,
      });
      return;
    }

    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE mobile_verification_otps SET used_at = ? WHERE user_id = ? AND used_at IS NULL')
        .run(now, req.auth!.userId);
      sqlite
        .prepare(`
          INSERT INTO mobile_verification_otps (
            id, user_id, subject_type, phone, otp_hash, provider, expires_at, attempts, max_attempts, created_ip, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 5, ?, ?)
        `)
        .run(`mvo_${generateSecureToken(6)}`, req.auth!.userId, req.auth!.subjectType, normMob, sha256(otpCode), smsResult.provider, expiresAt, getClientIp(req), now);
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      action: 'MOBILE_OTP_SENT',
      category: 'Registration & Verification',
      details: `Dispatched SMS OTP via ${smsResult.provider}`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      provider: smsResult.provider,
      expiresAt,
      message: '6-digit SMS OTP dispatched to your registered mobile number.',
    });
  });

  router.post('/mobile/verify-otp', requireAuth, rateLimitEndpoint('mobile_ver_otp', 20, 60_000), (req: Request, res: Response) => {
    const code = String(req.body?.code || '').trim();
    const phoneInput = String(req.body?.phone || req.auth!.mobile || '').trim();
    const normMob = normalizePhone(phoneInput);

    if (!code || !normMob) {
      res.status(400).json({ error: 'Mobile number and 6-digit SMS OTP code are required.' });
      return;
    }

    const row = sqlite
      .prepare('SELECT * FROM mobile_verification_otps WHERE user_id = ? AND phone = ? AND used_at IS NULL ORDER BY created_at DESC LIMIT 1')
      .get(req.auth!.userId, normMob) as any;

    if (!row) {
      res.status(400).json({ error: 'No pending SMS verification OTP found for this phone number.' });
      return;
    }
    if (row.locked_until && new Date(row.locked_until).getTime() > Date.now()) {
      res.status(429).json({ error: 'Too many invalid OTP attempts. OTP verification temporarily locked.' });
      return;
    }
    if (new Date(row.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'SMS OTP has expired.' });
      return;
    }
    if (row.otp_hash !== sha256(code)) {
      const nextAttempts = (row.attempts || 0) + 1;
      const shouldLock = nextAttempts >= (row.max_attempts || 5);
      const lockedUntil = shouldLock ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : null;
      sqlite
        .prepare('UPDATE mobile_verification_otps SET attempts = ?, locked_until = ? WHERE id = ?')
        .run(nextAttempts, lockedUntil, row.id);
      res.status(shouldLock ? 429 : 400).json({
        error: shouldLock ? 'Maximum OTP attempts exceeded. Locked for 15 minutes.' : 'Incorrect SMS OTP code.',
      });
      return;
    }

    const duplicate = sqlite
      .prepare('SELECT id FROM user_accounts WHERE verified_phone = ? AND mobile_verified = 1 AND id != ?')
      .get(normMob, req.auth!.userId);
    if (duplicate) {
      res.status(409).json({ error: 'This mobile number is already verified on another account.' });
      return;
    }

    const now = nowIso();
    const srcTable = getSourceTableForSubject(req.auth!.subjectType);

    sqlite.transaction(() => {
      sqlite.prepare('UPDATE mobile_verification_otps SET used_at = ? WHERE id = ?').run(now, row.id);
      sqlite
        .prepare('UPDATE user_accounts SET mobile_verified = 1, verified_phone = ?, updated_at = ? WHERE id = ?')
        .run(normMob, now, req.auth!.userId);
      sqlite
        .prepare('UPDATE identity_verification_records SET mobile_verified = 1, updated_at = ? WHERE user_id = ?')
        .run(now, req.auth!.userId);

      if (srcTable === 'customer_accounts') {
        sqlite.prepare('UPDATE customer_accounts SET mobile_verified = 1, updated_at = ? WHERE id = ?').run(now, req.auth!.userId);
        sqlite
          .prepare("UPDATE customer_verifications SET status = 'Verified', verified_at = ? WHERE customer_id = ? AND channel = 'mobile'")
          .run(now, req.auth!.userId);
      } else if (srcTable === 'users') {
        sqlite.prepare('UPDATE users SET mobile_verified = 1, updated_at = ? WHERE id = ?').run(now, req.auth!.userId);
      }
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      action: 'MOBILE_PHONE_VERIFIED',
      category: 'Registration & Verification',
      details: `Verified mobile number via ${row.provider}.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, message: 'Mobile number verified successfully.' });
  });

  // -------------------------------------------------------------------------
  // 4. Unified Forgot / Reset / Change Password Across All Non-Founder Accounts
  // -------------------------------------------------------------------------
  router.post('/password/forgot', rateLimitEndpoint('uni_forgot_pw', 10, 60_000), async (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (!email) {
      res.status(400).json({ error: 'Registered email address is required.' });
      return;
    }

    syncUnifiedSecurityRegistry();
    const account = sqlite.prepare('SELECT * FROM user_accounts WHERE LOWER(email) = ?').get(email) as any;

    if (!account) {
      res.json({
        success: true,
        message: 'If a matching account exists, password reset instructions have been issued.',
      });
      return;
    }

    if (account.subject_type === 'founder') {
      res.status(403).json({
        error: 'Primary Owner password recovery cannot be requested through public endpoints.',
      });
      return;
    }

    const policy = getSystemSetting('security_policy', { forgotPasswordCooldownSeconds: 60 });
    const cooldownSec = Math.max(30, Number(policy.forgotPasswordCooldownSeconds) || 60);
    const latestReset = sqlite
      .prepare('SELECT created_at FROM password_reset_tokens WHERE user_id = ? ORDER BY created_at DESC LIMIT 1')
      .get(account.id) as { created_at: string } | undefined;
    if (latestReset) {
      const elapsedMs = Date.now() - new Date(latestReset.created_at).getTime();
      if (elapsedMs < cooldownSec * 1000) {
        const waitSec = Math.ceil((cooldownSec * 1000 - elapsedMs) / 1000);
        res.status(429).json({
          error: `Password recovery cooldown active. Wait ${waitSec}s before requesting another reset.`,
          retryAfterSeconds: waitSec,
        });
        return;
      }
    }

    const rawToken = generateSecureToken(32);
    const now = nowIso();
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL')
        .run(now, account.id);
      sqlite
        .prepare(`
          INSERT INTO password_reset_tokens (id, user_id, subject_type, email, token_hash, expires_at, created_ip, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(`prt_${generateSecureToken(6)}`, account.id, account.subject_type, email, sha256(rawToken), expiresAt, getClientIp(req), now);
    })();

    const dispatchRes = await dispatchVerificationEmail({
      to: email,
      subject: 'BYD PAKISTAN 360 — Secure Password Reset',
      text: `Use this single-use password reset token within 30 minutes: ${rawToken}`,
    });

    logSecurityAudit({
      actorId: account.id,
      actorName: account.full_name,
      actorRole: account.role,
      targetUserId: account.id,
      companyId: account.company_id,
      action: 'PASSWORD_RESET_REQUESTED',
      category: 'Password Security',
      details: `Issued expiring password reset token for ${email}.`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      expiresAt,
      message: 'If a matching account exists, password reset instructions have been issued.',
      resetOutbox:
        dispatchRes.mode === 'dev_outbox'
          ? {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              resetToken: rawToken,
            }
          : undefined,
    });
  });

  router.post('/password/forgot-otp', rateLimitEndpoint('uni_forgot_otp', 10, 60_000), async (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const channel = String(req.body?.channel || 'email').trim().toLowerCase();
    if (!email) {
      res.status(400).json({ error: 'Registered email address is required.' });
      return;
    }

    if (channel === 'sms' && !isSmsGatewayConfigured()) {
      res.status(503).json({
        error: 'External SMS provider is not configured. Please use email OTP recovery or configure Twilio/SMS gateway.',
        smsConfigured: false,
      });
      return;
    }

    syncUnifiedSecurityRegistry();
    const account = sqlite.prepare('SELECT * FROM user_accounts WHERE LOWER(email) = ?').get(email) as any;
    if (!account) {
      res.json({
        success: true,
        message: 'If a matching account exists, a password recovery OTP has been dispatched.',
      });
      return;
    }

    if (account.subject_type === 'founder') {
      res.status(403).json({
        error: 'Primary Owner password recovery cannot be requested through public endpoints.',
      });
      return;
    }

    const policy = getSystemSetting('security_policy', {
      otpExpiryMinutes: 10,
      forgotPasswordCooldownSeconds: 60,
    });
    const cooldownSec = Math.max(30, Number(policy.forgotPasswordCooldownSeconds) || 60);
    const expiryMins = Math.max(2, Number(policy.otpExpiryMinutes) || 10);

    const latestOtp = sqlite
      .prepare("SELECT created_at FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'unified_password_reset_otp' ORDER BY created_at DESC LIMIT 1")
      .get(email) as { created_at: string } | undefined;
    if (latestOtp) {
      const elapsedMs = Date.now() - new Date(latestOtp.created_at).getTime();
      if (elapsedMs < cooldownSec * 1000) {
        const waitSec = Math.ceil((cooldownSec * 1000 - elapsedMs) / 1000);
        res.status(429).json({
          error: `OTP resend cooldown active. Please wait ${waitSec} seconds before requesting a new code.`,
          retryAfterSeconds: waitSec,
        });
        return;
      }
    }

    const otpCode = generateNumericOtp(6);
    const now = nowIso();
    const expiresAt = new Date(Date.now() + expiryMins * 60 * 1000).toISOString();

    sqlite.transaction(() => {
      sqlite
        .prepare("UPDATE otp_verifications SET used_at = ? WHERE LOWER(identifier) = ? AND purpose = 'unified_password_reset_otp' AND used_at IS NULL")
        .run(now, email);
      sqlite
        .prepare(`
          INSERT INTO otp_verifications (id, identifier, purpose, code_hash, subject_id, subject_type, expires_at, attempts, created_at)
          VALUES (?, ?, 'unified_password_reset_otp', ?, ?, ?, ?, 0, ?)
        `)
        .run(`otp_${generateSecureToken(6)}`, email, sha256(otpCode), account.id, account.subject_type, expiresAt, now);
    })();

    let deliveryMode = 'smtp';
    if (channel === 'sms' && account.mobile_verified && account.verified_phone) {
      const smsRes = await dispatchSmsOtp({
        toPhone: account.verified_phone,
        message: `BYD PAKISTAN 360 Password Recovery OTP: ${otpCode}. Expires in ${expiryMins} minutes.`,
      });
      if (!smsRes.delivered) {
        res.status(502).json({ error: `SMS OTP delivery failed: ${smsRes.error || 'Provider error'}` });
        return;
      }
      deliveryMode = smsRes.provider;
    } else {
      const mailRes = await dispatchVerificationEmail({
        to: email,
        subject: 'BYD PAKISTAN 360 — Password Recovery OTP',
        text: `Your BYD PAKISTAN 360 6-digit password recovery OTP is ${otpCode}. It expires in ${expiryMins} minutes. Do not share this code.`,
      });
      deliveryMode = mailRes.mode;
    }

    logSecurityAudit({
      actorId: account.id,
      actorName: account.full_name,
      actorRole: account.role,
      targetUserId: account.id,
      companyId: account.company_id,
      action: 'PASSWORD_RESET_OTP_ISSUED',
      category: 'Password Security',
      details: `Issued ${expiryMins}-minute single-use password reset OTP (${deliveryMode}).`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      expiresAt,
      expiryMinutes: expiryMins,
      message: `If a matching account exists, a 6-digit recovery OTP (valid ${expiryMins} min) has been issued.`,
      resetOutbox:
        deliveryMode === 'dev_outbox'
          ? {
              notice: 'Development Mailer Outbox (SMTP not configured)',
              otpCode,
            }
          : undefined,
    });
  });

  router.post('/password/reset-otp', rateLimitEndpoint('uni_reset_otp', 15, 60_000), async (req: Request, res: Response) => {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const otpCode = String(req.body?.otpCode || '').trim();
    const newPassword = String(req.body?.newPassword || '');
    const confirmPassword = String(req.body?.confirmPassword || newPassword);

    if (!email || !/^\d{6}$/.test(otpCode)) {
      res.status(400).json({ error: 'Registered email address and 6-digit numeric OTP code are required.' });
      return;
    }
    if (confirmPassword !== newPassword) {
      res.status(400).json({ error: 'New password and confirmation do not match.' });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const otpRow = sqlite
      .prepare("SELECT * FROM otp_verifications WHERE LOWER(identifier) = ? AND purpose = 'unified_password_reset_otp' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1")
      .get(email) as any;

    if (!otpRow) {
      res.status(400).json({ error: 'No active password recovery OTP found. Request a new code.' });
      return;
    }
    if (new Date(otpRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Password recovery OTP has expired. Request a new code.' });
      return;
    }

    const policy = getSystemSetting('security_policy', { otpMaxAttempts: 5, passwordReuseLimit: 5 });
    const maxAttempts = Math.max(3, Number(policy.otpMaxAttempts) || 5);
    const reuseLimit = Math.max(1, Number(policy.passwordReuseLimit) || 5);

    if ((otpRow.attempts || 0) >= maxAttempts) {
      res.status(429).json({ error: 'Maximum OTP verification attempts exceeded. Request a fresh OTP.' });
      return;
    }

    if (otpRow.code_hash !== sha256(otpCode)) {
      const nextAttempts = (otpRow.attempts || 0) + 1;
      sqlite.prepare('UPDATE otp_verifications SET attempts = ? WHERE id = ?').run(nextAttempts, otpRow.id);
      const locked = nextAttempts >= maxAttempts;
      if (locked) {
        sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(nowIso(), otpRow.id);
      }
      res.status(locked ? 429 : 400).json({
        error: locked ? 'Maximum OTP attempts reached. Code invalidated; request a new OTP.' : 'Incorrect recovery OTP code.',
      });
      return;
    }

    const srcTable = getSourceTableForSubject(otpRow.subject_type);
    if (!srcTable || srcTable === 'founder_accounts') {
      res.status(403).json({ error: 'Password recovery via OTP is not permitted for this account type.' });
      return;
    }

    const currentRec = sqlite.prepare(`SELECT id, password_hash FROM ${srcTable} WHERE id = ?`).get(otpRow.subject_id) as any;
    if (!currentRec) {
      res.status(404).json({ error: 'Account record not found.' });
      return;
    }

    if (verifyPassword(newPassword, currentRec.password_hash) || isPasswordReused(otpRow.subject_id, newPassword, reuseLimit)) {
      res.status(400).json({
        error: `Password reuse is prohibited. Choose a new password not used in your last ${reuseLimit} passwords.`,
      });
      return;
    }

    const now = nowIso();
    const nextHash = hashPassword(newPassword);

    sqlite.transaction(() => {
      sqlite.prepare('UPDATE otp_verifications SET used_at = ? WHERE id = ?').run(now, otpRow.id);
      sqlite
        .prepare(`UPDATE ${srcTable} SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?`)
        .run(nextHash, now, otpRow.subject_id);
      recordPasswordHistory(otpRow.subject_id, otpRow.subject_type, nextHash);
      sqlite
        .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'password_reset_otp', revoked_at = ? WHERE user_id = ? AND revoked = 0")
        .run(now, otpRow.subject_id);
      sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(otpRow.subject_id);
      markLoginSessionTerminated(otpRow.subject_id, 'password_reset_otp', true);
    })();

    await dispatchVerificationEmail({
      to: email,
      subject: 'BYD PAKISTAN 360 — Password Reset Confirmation',
      text: `Your BYD PAKISTAN 360 account password was reset via verified OTP at ${now}. All active sessions were revoked.`,
    });

    logSecurityAudit({
      actorId: otpRow.subject_id,
      actorName: email,
      actorRole: otpRow.subject_type,
      targetUserId: otpRow.subject_id,
      action: 'PASSWORD_RESET_OTP_COMPLETED',
      category: 'Password Security',
      severity: 'WARNING',
      details: 'Password reset verified via single-use OTP and all active sessions revoked.',
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      message: 'Password reset via OTP completed. All active sessions have been revoked.',
    });
  });

  router.post('/password/reset', rateLimitEndpoint('uni_reset_pw', 15, 60_000), async (req: Request, res: Response) => {
    const token = String(req.body?.token || '').trim();
    const newPassword = String(req.body?.newPassword || '');
    const confirmPassword = String(req.body?.confirmPassword || newPassword);

    if (!token) {
      res.status(400).json({ error: 'Password reset token is required.' });
      return;
    }
    if (confirmPassword !== newPassword) {
      res.status(400).json({ error: 'New password and confirmation do not match.' });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const row = sqlite
      .prepare('SELECT * FROM password_reset_tokens WHERE token_hash = ?')
      .get(sha256(token)) as any;

    if (!row || row.used_at || new Date(row.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'Password reset token is invalid, expired, or already used.' });
      return;
    }

    const srcTable = getSourceTableForSubject(row.subject_type);
    if (!srcTable || srcTable === 'founder_accounts') {
      res.status(403).json({ error: 'Reset not permitted for this account type.' });
      return;
    }

    const currentRec = sqlite.prepare(`SELECT id, password_hash FROM ${srcTable} WHERE id = ?`).get(row.user_id) as any;
    const policy = getSystemSetting('security_policy', { passwordReuseLimit: 5 });
    const reuseLimit = Math.max(1, Number(policy.passwordReuseLimit) || 5);
    if ((currentRec?.password_hash && verifyPassword(newPassword, currentRec.password_hash)) || isPasswordReused(row.user_id, newPassword, reuseLimit)) {
      res.status(400).json({
        error: `Password reuse is prohibited. Choose a new password not used in your last ${reuseLimit} passwords.`,
      });
      return;
    }

    const now = nowIso();
    const nextHash = hashPassword(newPassword);

    sqlite.transaction(() => {
      sqlite.prepare('UPDATE password_reset_tokens SET used_at = ? WHERE id = ?').run(now, row.id);
      sqlite
        .prepare(`UPDATE ${srcTable} SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?`)
        .run(nextHash, now, row.user_id);
      recordPasswordHistory(row.user_id, row.subject_type, nextHash);
      sqlite
        .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'password_reset', revoked_at = ? WHERE user_id = ? AND revoked = 0")
        .run(now, row.user_id);
      sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(row.user_id);
      markLoginSessionTerminated(row.user_id, 'password_reset', true);
    })();

    await dispatchVerificationEmail({
      to: row.email,
      subject: 'BYD PAKISTAN 360 — Password Reset Confirmation',
      text: `Your BYD PAKISTAN 360 password was reset at ${now}. All existing device sessions have been revoked.`,
    });

    logSecurityAudit({
      actorId: row.user_id,
      actorName: row.email,
      actorRole: row.subject_type,
      targetUserId: row.user_id,
      action: 'PASSWORD_RESET_COMPLETED',
      category: 'Password Security',
      severity: 'WARNING',
      details: 'Password reset completed and all active sessions revoked.',
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      message: 'Password updated successfully. All active sessions have been revoked.',
    });
  });

  router.post('/password/change', requireAuth, rateLimitEndpoint('uni_chg_pw', 15, 60_000), (req: Request, res: Response) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const newPassword = String(req.body?.newPassword || '');
    const confirmPassword = String(req.body?.confirmPassword || '');
    const revokeOtherSessions = req.body?.revokeOtherSessions !== false;

    if (!currentPassword || !newPassword || !confirmPassword) {
      res.status(400).json({ error: 'Current password, new password, and confirm password are required.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'New password and confirmation do not match.' });
      return;
    }
    if (currentPassword === newPassword) {
      res.status(400).json({ error: 'New password must differ from current password.' });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ error: strength.reason });
      return;
    }

    const srcTable = getSourceTableForSubject(req.auth!.subjectType);
    if (!srcTable) {
      res.status(400).json({ error: 'Unsupported account table.' });
      return;
    }

    const rec = sqlite.prepare(`SELECT id, password_hash FROM ${srcTable} WHERE id = ?`).get(req.auth!.userId) as any;
    if (!rec || !verifyPassword(currentPassword, rec.password_hash)) {
      res.status(401).json({ error: 'Current password verification failed.' });
      return;
    }

    const policy = getSystemSetting('security_policy', { passwordReuseLimit: 5 });
    const reuseLimit = Math.max(1, Number(policy.passwordReuseLimit) || 5);
    if (isPasswordReused(req.auth!.userId, newPassword, reuseLimit)) {
      res.status(400).json({
        error: `Password reuse is prohibited. Choose a new password not used in your last ${reuseLimit} passwords.`,
      });
      return;
    }

    const now = nowIso();
    const nextHash = hashPassword(newPassword);

    sqlite.transaction(() => {
      if (srcTable === 'founder_accounts') {
        sqlite.prepare('UPDATE founder_accounts SET password_hash = ? WHERE id = ?').run(nextHash, req.auth!.userId);
      } else {
        sqlite.prepare(`UPDATE ${srcTable} SET password_hash = ?, updated_at = ? WHERE id = ?`).run(nextHash, now, req.auth!.userId);
      }
      recordPasswordHistory(req.auth!.userId, req.auth!.subjectType, nextHash);

      if (revokeOtherSessions) {
        sqlite
          .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'password_changed', revoked_at = ? WHERE user_id = ? AND id != ? AND revoked = 0")
          .run(now, req.auth!.userId, req.auth!.sessionId);
      }
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      companyId: req.auth!.companyId,
      action: 'PASSWORD_CHANGED',
      category: 'Password Security',
      details: revokeOtherSessions ? 'Password updated and other device sessions revoked.' : 'Password updated.',
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, message: 'Password updated successfully.' });
  });

  // -------------------------------------------------------------------------
  // 5. Self-Service Account Security & Verification Profile
  // -------------------------------------------------------------------------
  router.get('/me/security-profile', requireAuth, (req: Request, res: Response) => {
    const account = getUserAuthRecord(req.auth!.userId);
    const profile = sqlite.prepare('SELECT * FROM user_profiles WHERE user_id = ?').get(req.auth!.userId) as any;
    const verificationRecord = sqlite
      .prepare('SELECT * FROM identity_verification_records WHERE user_id = ?')
      .get(req.auth!.userId) as any;
    const documents = sqlite
      .prepare(`
        SELECT id, doc_type, title, original_filename, mime_type, file_size, sha256_checksum,
               review_status, reviewer_notes, created_at
        FROM verification_documents
        WHERE user_id = ?
        ORDER BY created_at DESC
      `)
      .all(req.auth!.userId);

    const mfaRow = sqlite.prepare('SELECT * FROM mfa_settings WHERE user_id = ?').get(req.auth!.userId) as any;
    const recoveryRemaining = (
      sqlite
        .prepare('SELECT COUNT(*) as c FROM mfa_recovery_codes WHERE user_id = ? AND used_at IS NULL')
        .get(req.auth!.userId) as any
    )?.c || 0;

    const sessions = sqlite
      .prepare(`
        SELECT id, device_label, ip_address, user_agent, device_fingerprint,
               last_activity_at, idle_expires_at, expires_at, created_at,
               CASE WHEN id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions
        WHERE user_id = ? AND revoked = 0 AND expires_at > ?
        ORDER BY last_activity_at DESC
      `)
      .all(req.auth!.sessionId, req.auth!.userId, nowIso());

    const loginActivity = sqlite
      .prepare(`
        SELECT id, identifier, success, failure_reason, mfa_method, ip_address, user_agent,
               suspicious, suspicious_reason, created_at
        FROM login_activity_logs
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 25
      `)
      .all(req.auth!.userId);

    const approvalHistory = sqlite
      .prepare(`
        SELECT id, action, previous_status, new_status, reason, notes, actor_name, actor_role, created_at
        FROM account_approval_history
        WHERE target_user_id = ?
        ORDER BY created_at DESC
        LIMIT 20
      `)
      .all(req.auth!.userId);

    res.json({
      account,
      profile,
      verificationRecord,
      documents,
      mfa: {
        totpEnabled: Boolean(mfaRow?.totp_enabled),
        emailOtpEnabled: Boolean(mfaRow?.email_otp_enabled),
        smsOtpEnabled: Boolean(mfaRow?.sms_otp_enabled),
        mfaRequired: Boolean(mfaRow?.mfa_required),
        pendingEnrollment: Boolean(mfaRow?.pending_totp_secret),
        enrolledAt: mfaRow?.enrolled_at || null,
        remainingRecoveryCodes: recoveryRemaining,
      },
      sessions,
      loginActivity,
      approvalHistory,
      capabilities: {
        smtpConfigured: isSmtpConfigured(),
        smsConfigured: isSmsGatewayConfigured(),
      },
    });
  });

  // -------------------------------------------------------------------------
  // 6. Private Identity Verification Document Upload & Protected Download
  // -------------------------------------------------------------------------
  router.post(
    '/documents',
    requireAuth,
    rateLimitEndpoint('doc_upload', 20, 60_000),
    (req: Request, res: Response) => {
      uploadPrivateDoc.single('document')(req, res, (err: any) => {
        if (err) {
          res.status(400).json({ error: err.message || 'Document upload failed.' });
          return;
        }
        if (!req.file) {
          res.status(400).json({ error: 'Verification document file (PDF, PNG, JPG, or WEBP) is required.' });
          return;
        }

        const docType = String(req.body?.docType || 'National ID / CNIC').trim();
        const title = String(req.body?.title || req.file.originalname || docType).trim();
        const account = getUserAuthRecord(req.auth!.userId);
        if (!account) {
          fs.unlink(req.file.path, () => {});
          res.status(404).json({ error: 'Unified account record not found.' });
          return;
        }

        const fileBuf = fs.readFileSync(req.file.path);
        const checksum = crypto.createHash('sha256').update(fileBuf).digest('hex');
        const docId = `vdoc_${generateSecureToken(8)}`;
        const now = nowIso();
        const ivr = sqlite
          .prepare('SELECT * FROM identity_verification_records WHERE user_id = ?')
          .get(req.auth!.userId) as any;
        const ivrId = ivr?.id || `ivr_${req.auth!.userId}`;

        sqlite.transaction(() => {
          if (!ivr) {
            sqlite
              .prepare(`
                INSERT INTO identity_verification_records (
                  id, user_id, subject_type, role, company_id, country_id, branch_id,
                  verification_status, email_verified, mobile_verified, document_count, submitted_at, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending Verification', ?, ?, 1, ?, ?, ?)
              `)
              .run(
                ivrId,
                req.auth!.userId,
                account.subject_type,
                account.role,
                account.company_id,
                account.country_id,
                account.branch_id,
                account.email_verified,
                account.mobile_verified,
                now,
                now,
                now
              );
          }

          sqlite
            .prepare(`
              INSERT INTO verification_documents (
                id, verification_record_id, user_id, subject_type, doc_type, title,
                original_filename, mime_type, file_size, storage_key, sha256_checksum,
                review_status, uploaded_by, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Review', ?, ?)
            `)
            .run(
              docId,
              ivrId,
              req.auth!.userId,
              account.subject_type,
              docType,
              title,
              path.basename(req.file!.originalname || req.file!.filename),
              req.file!.mimetype,
              req.file!.size,
              req.file!.filename,
              checksum,
              req.auth!.userId,
              now
            );

          sqlite
            .prepare(`
              UPDATE identity_verification_records
              SET document_count = (SELECT COUNT(*) FROM verification_documents WHERE user_id = ?),
                  submitted_at = COALESCE(submitted_at, ?),
                  verification_status = CASE
                    WHEN verification_status IN ('Not Submitted', 'Rejected') THEN 'Pending Verification'
                    ELSE verification_status
                  END,
                  updated_at = ?
              WHERE id = ?
            `)
            .run(req.auth!.userId, now, now, ivrId);

          sqlite
            .prepare(`
              UPDATE user_accounts
              SET verification_status = CASE
                    WHEN verification_status IN ('Not Submitted', 'Rejected') THEN 'Pending Verification'
                    ELSE verification_status
                  END,
                  updated_at = ?
              WHERE id = ?
            `)
            .run(now, req.auth!.userId);
        })();

        logSecurityAudit({
          actorId: req.auth!.userId,
          actorName: req.auth!.fullName,
          actorRole: req.auth!.role,
          targetUserId: req.auth!.userId,
          companyId: req.auth!.companyId,
          action: 'VERIFICATION_DOCUMENT_UPLOADED',
          category: 'Identity Verification',
          details: `Uploaded private KYC document "${docType}" (${req.file.size} bytes).`,
          ipAddress: getClientIp(req),
        });

        res.status(201).json({
          success: true,
          document: {
            id: docId,
            docType,
            title,
            originalFilename: req.file.originalname,
            mimeType: req.file.mimetype,
            fileSize: req.file.size,
            sha256Checksum: checksum,
            reviewStatus: 'Pending Review',
            createdAt: now,
          },
          message: 'Document uploaded cleanly into private identity verification storage.',
        });
      });
    }
  );

  router.get('/documents/:docId/download', requireAuth, (req: Request, res: Response) => {
    const doc = sqlite.prepare('SELECT * FROM verification_documents WHERE id = ?').get(req.params.docId) as any;
    if (!doc) {
      res.status(404).json({ error: 'Verification document not found.' });
      return;
    }

    const isOwner = doc.user_id === req.auth!.userId;
    let isScopedAdmin = false;
    if (!isOwner && ADMIN_GOVERNANCE_SUBJECTS.has(req.auth!.subjectType)) {
      const targetAcc = getUserAuthRecord(doc.user_id);
      if (req.auth!.subjectType === 'super_admin') {
        const hasPerm = req.auth!.permissions.includes('users.view') || req.auth!.permissions.includes('customers.manage') || req.auth!.permissions.includes('dealers.manage');
        isScopedAdmin = hasPerm && canAdminAccessTarget(req.auth!, targetAcc);
      } else {
        isScopedAdmin = canAdminAccessTarget(req.auth!, targetAcc);
      }
    }

    if (!isOwner && !isScopedAdmin) {
      logSecurityAudit({
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        targetUserId: doc.user_id,
        action: 'UNAUTHORIZED_DOCUMENT_ACCESS_BLOCKED',
        category: 'Document Security',
        severity: 'CRITICAL',
        details: `Blocked unauthorized access attempt to private verification document ${doc.id}.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access denied: you are not authorized to download this private verification document.' });
      return;
    }

    const resolvedPath = path.resolve(PRIVATE_VERIFICATION_DOCS_DIR, path.basename(doc.storage_key));
    if (!resolvedPath.startsWith(PRIVATE_VERIFICATION_DOCS_DIR + path.sep) || !fs.existsSync(resolvedPath)) {
      res.status(404).json({ error: 'Stored private document file not found.' });
      return;
    }

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: doc.user_id,
      action: 'VERIFICATION_DOCUMENT_ACCESSED',
      category: 'Document Security',
      details: `Downloaded private verification document ${doc.id} (${doc.doc_type}).`,
      ipAddress: getClientIp(req),
    });

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(doc.original_filename || 'verification-doc')}"`);
    fs.createReadStream(resolvedPath).pipe(res);
  });

  // -------------------------------------------------------------------------
  // 7. MFA Enrollment, Disable & Recovery Code Management (Password Reauth Required)
  // -------------------------------------------------------------------------
  router.post('/mfa/enroll', requireAuth, (req: Request, res: Response) => {
    if (req.auth!.subjectType === 'founder') {
      const f = sqlite.prepare('SELECT two_factor_enabled, two_factor_secret FROM founder_accounts WHERE id = ?').get(req.auth!.userId) as any;
      if (f?.two_factor_enabled && f?.two_factor_secret) {
        res.status(403).json({
          error: 'Primary Owner 2FA secret is permanently protected and cannot be overwritten or reset via MFA re-enrollment. Use Recovery Code regeneration if needed.',
        });
        return;
      }
    }

    const currentPassword = String(req.body?.currentPassword || '');
    if (!currentPassword) {
      res.status(400).json({ error: 'Current password re-authentication is required to enroll MFA.' });
      return;
    }
    const srcTable = getSourceTableForSubject(req.auth!.subjectType);
    if (!srcTable) {
      res.status(400).json({ error: 'Unsupported account type.' });
      return;
    }
    const rec = sqlite.prepare(`SELECT password_hash FROM ${srcTable} WHERE id = ?`).get(req.auth!.userId) as any;
    if (!rec || !verifyPassword(currentPassword, rec.password_hash)) {
      res.status(401).json({ error: 'Current password verification failed.' });
      return;
    }

    const secret = generateTotpSecret();
    const encryptedPending = encrypt2faSecret(secret);
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO mfa_settings (user_id, subject_type, pending_totp_secret, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET pending_totp_secret = excluded.pending_totp_secret, updated_at = excluded.updated_at
      `)
      .run(req.auth!.userId, req.auth!.subjectType, encryptedPending, now);

    const otpAuthUri = `otpauth://totp/BYD%20PAKISTAN%20360:${encodeURIComponent(req.auth!.email)}?secret=${secret}&issuer=BYD%20PAKISTAN%20360`;

    res.json({
      success: true,
      secret,
      otpAuthUri,
      message: 'Scan or enter this secret key in your authenticator app and confirm with a 6-digit TOTP code.',
    });
  });

  router.post('/mfa/confirm', requireAuth, (req: Request, res: Response) => {
    if (req.auth!.subjectType === 'founder') {
      const f = sqlite.prepare('SELECT two_factor_enabled, two_factor_secret FROM founder_accounts WHERE id = ?').get(req.auth!.userId) as any;
      if (f?.two_factor_enabled && f?.two_factor_secret) {
        res.status(403).json({
          error: 'Primary Owner 2FA secret is protected and immutable.',
        });
        return;
      }
    }

    const code = String(req.body?.code || '').trim();
    const mfaRow = sqlite.prepare('SELECT * FROM mfa_settings WHERE user_id = ?').get(req.auth!.userId) as any;
    const storedSecret = mfaRow?.pending_totp_secret || mfaRow?.totp_secret;
    if (!storedSecret || !verifyTotpCode(storedSecret, code)) {
      res.status(400).json({ error: 'Invalid 6-digit authenticator verification code.' });
      return;
    }

    const encryptedSecret = encrypt2faSecret(storedSecret);
    const recoveryCodes = Array.from({ length: 8 }, () => `${generateNumericOtp(4)}-${generateNumericOtp(4)}`);
    const recoveryHashes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();
    const srcTable = getSourceTableForSubject(req.auth!.subjectType);

    sqlite.transaction(() => {
      sqlite
        .prepare(`
          UPDATE mfa_settings
          SET totp_enabled = 1,
              totp_secret = ?,
              pending_totp_secret = NULL,
              enrolled_at = COALESCE(enrolled_at, ?),
              last_verified_at = ?,
              updated_at = ?
          WHERE user_id = ?
        `)
        .run(encryptedSecret, now, now, now, req.auth!.userId);

      sqlite.prepare('DELETE FROM mfa_recovery_codes WHERE user_id = ?').run(req.auth!.userId);
      const insRc = sqlite.prepare(
        'INSERT INTO mfa_recovery_codes (id, user_id, subject_type, code_hash, created_at) VALUES (?, ?, ?, ?, ?)'
      );
      for (const h of recoveryHashes) {
        insRc.run(`mrc_${generateSecureToken(6)}`, req.auth!.userId, req.auth!.subjectType, h, now);
      }

      sqlite.prepare('UPDATE user_accounts SET mfa_enabled = 1, updated_at = ? WHERE id = ?').run(now, req.auth!.userId);

      if (srcTable && srcTable !== 'users' && srcTable !== 'founder_accounts') {
        try {
          sqlite
            .prepare(`UPDATE ${srcTable} SET two_factor_enabled = 1, two_factor_secret = ?, recovery_codes_json = ?, updated_at = ? WHERE id = ?`)
            .run(encryptedSecret, JSON.stringify(recoveryHashes), now, req.auth!.userId);
        } catch {
          sqlite
            .prepare(`UPDATE ${srcTable} SET two_factor_enabled = 1, two_factor_secret = ? WHERE id = ?`)
            .run(encryptedSecret, req.auth!.userId);
        }
      } else if (srcTable === 'users') {
        sqlite
          .prepare('UPDATE users SET two_factor_enabled = 1, two_factor_secret = ?, recovery_codes_json = ?, updated_at = ? WHERE id = ?')
          .run(encryptedSecret, JSON.stringify(recoveryHashes), now, req.auth!.userId);
      }
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      companyId: req.auth!.companyId,
      action: 'MFA_ENROLLED',
      category: 'MFA Security',
      details: 'Two-factor TOTP authentication enabled (AES-256-GCM protected) and 8 recovery codes issued.',
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      recoveryCodes,
      message: 'Two-factor authentication activated. Save your 8 single-use recovery codes securely.',
    });
  });

  router.post('/mfa/disable', requireAuth, (req: Request, res: Response) => {
    if (MANDATORY_MFA_ROLES.has(req.auth!.role) || ADMIN_GOVERNANCE_SUBJECTS.has(req.auth!.subjectType)) {
      res.status(403).json({
        error: `MFA is mandatory for ${req.auth!.role} accounts and cannot be disabled.`,
      });
      return;
    }

    const currentPassword = String(req.body?.currentPassword || '');
    const code = String(req.body?.code || '').trim();
    const srcTable = getSourceTableForSubject(req.auth!.subjectType);
    if (!srcTable) {
      res.status(400).json({ error: 'Unsupported account type.' });
      return;
    }

    const rec = sqlite.prepare(`SELECT password_hash FROM ${srcTable} WHERE id = ?`).get(req.auth!.userId) as any;
    if (!rec || !verifyPassword(currentPassword, rec.password_hash)) {
      res.status(401).json({ error: 'Current password verification failed.' });
      return;
    }

    const mfaRow = sqlite.prepare('SELECT * FROM mfa_settings WHERE user_id = ?').get(req.auth!.userId) as any;
    if (mfaRow?.totp_enabled && mfaRow?.totp_secret && !verifyTotpCode(mfaRow.totp_secret, code)) {
      res.status(401).json({ error: 'Valid 6-digit TOTP code is required to disable MFA.' });
      return;
    }

    const now = nowIso();
    sqlite.transaction(() => {
      sqlite
        .prepare('UPDATE mfa_settings SET totp_enabled = 0, totp_secret = NULL, pending_totp_secret = NULL, updated_at = ? WHERE user_id = ?')
        .run(now, req.auth!.userId);
      sqlite.prepare('DELETE FROM mfa_recovery_codes WHERE user_id = ?').run(req.auth!.userId);
      sqlite.prepare('UPDATE user_accounts SET mfa_enabled = 0, updated_at = ? WHERE id = ?').run(now, req.auth!.userId);
      sqlite
        .prepare(`UPDATE ${srcTable} SET two_factor_enabled = 0, two_factor_secret = NULL, recovery_codes_json = '[]', updated_at = ? WHERE id = ?`)
        .run(now, req.auth!.userId);
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      action: 'MFA_DISABLED',
      category: 'MFA Security',
      severity: 'WARNING',
      details: 'MFA was disabled after password and TOTP verification.',
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, message: 'MFA disabled for this account.' });
  });

  router.post('/mfa/recovery-codes/regenerate', requireAuth, (req: Request, res: Response) => {
    const currentPassword = String(req.body?.currentPassword || '');
    const code = String(req.body?.code || '').trim();
    const srcTable = getSourceTableForSubject(req.auth!.subjectType);
    if (!srcTable) {
      res.status(400).json({ error: 'Unsupported account type.' });
      return;
    }

    const rec = sqlite.prepare(`SELECT password_hash FROM ${srcTable} WHERE id = ?`).get(req.auth!.userId) as any;
    if (!rec || !verifyPassword(currentPassword, rec.password_hash)) {
      res.status(401).json({ error: 'Current password verification failed.' });
      return;
    }

    const mfaRow = sqlite.prepare('SELECT * FROM mfa_settings WHERE user_id = ?').get(req.auth!.userId) as any;
    if (!mfaRow?.totp_enabled || !mfaRow?.totp_secret || !verifyTotpCode(mfaRow.totp_secret, code)) {
      res.status(401).json({ error: 'Valid 6-digit TOTP code is required to regenerate recovery codes.' });
      return;
    }

    const recoveryCodes = Array.from({ length: 8 }, () => `${generateNumericOtp(4)}-${generateNumericOtp(4)}`);
    const recoveryHashes = recoveryCodes.map((c) => sha256(c));
    const now = nowIso();

    sqlite.transaction(() => {
      sqlite.prepare('DELETE FROM mfa_recovery_codes WHERE user_id = ?').run(req.auth!.userId);
      const insRc = sqlite.prepare(
        'INSERT INTO mfa_recovery_codes (id, user_id, subject_type, code_hash, created_at) VALUES (?, ?, ?, ?, ?)'
      );
      for (const h of recoveryHashes) {
        insRc.run(`mrc_${generateSecureToken(6)}`, req.auth!.userId, req.auth!.subjectType, h, now);
      }
      if (srcTable !== 'founder_accounts') {
        try {
          sqlite
            .prepare(`UPDATE ${srcTable} SET recovery_codes_json = ?, updated_at = ? WHERE id = ?`)
            .run(JSON.stringify(recoveryHashes), now, req.auth!.userId);
        } catch {
          // table without updated_at handled cleanly
        }
      } else {
        sqlite.prepare('UPDATE founder_accounts SET recovery_codes_json = ? WHERE id = ?').run(JSON.stringify(recoveryHashes), req.auth!.userId);
      }
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: req.auth!.userId,
      action: 'MFA_RECOVERY_CODES_REGENERATED',
      category: 'MFA Security',
      details: 'Regenerated 8 single-use MFA recovery codes.',
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      recoveryCodes,
      message: '8 new recovery codes generated. Previous recovery codes have been invalidated.',
    });
  });

  router.post('/sessions/revoke/:sessionId', requireAuth, (req: Request, res: Response) => {
    const target = sqlite.prepare('SELECT * FROM authentication_sessions WHERE id = ?').get(req.params.sessionId) as any;
    if (!target) {
      res.status(404).json({ error: 'Session not found.' });
      return;
    }
    const isOwner = target.user_id === req.auth!.userId;
    const isFounder = req.auth!.subjectType === 'founder';
    if (!isOwner && !isFounder) {
      res.status(403).json({ error: 'You cannot revoke another user session.' });
      return;
    }
    const now = nowIso();
    sqlite
      .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'user_revoked', revoked_at = ? WHERE id = ?")
      .run(now, target.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(target.id);
    markLoginSessionTerminated(target.id, 'user_revoked');
    res.json({ success: true, message: 'Session revoked.' });
  });

  return router;
}

export function createAdminVerificationRouter() {
  const router = express.Router();

  const requireGovernanceRole = (requiredSaPerm?: string) => (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    if (!ADMIN_GOVERNANCE_SUBJECTS.has(req.auth.subjectType)) {
      logSecurityAudit({
        actorId: req.auth.userId,
        actorName: req.auth.fullName,
        actorRole: req.auth.role,
        action: 'UNAUTHORIZED_ADMIN_VERIFICATION_ACCESS',
        category: 'RBAC Enforcement',
        severity: 'CRITICAL',
        details: `Non-admin role (${req.auth.role}) attempted access to ${req.originalUrl}`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Access denied: Administrative Verification & Approval Governance requires authorized admin role.' });
      return;
    }
    if (req.auth.subjectType === 'super_admin' && requiredSaPerm) {
      const perms = req.auth.permissions || [];
      if (!perms.includes(requiredSaPerm) && !perms.includes('users.update') && !perms.includes('customers.manage') && !perms.includes('dealers.manage')) {
        res.status(403).json({ error: `Permission denied: requires "${requiredSaPerm}".` });
        return;
      }
    }
    next();
  };

  router.get('/accounts', requireGovernanceRole('users.view'), (req: Request, res: Response) => {
    syncUnifiedSecurityRegistry();
    const roleFilter = String(req.query.role || '').trim();
    const statusFilter = String(req.query.status || '').trim();
    const verFilter = String(req.query.verificationStatus || '').trim();
    const q = String(req.query.q || '').trim().toLowerCase();

    const rows = sqlite
      .prepare(`
        SELECT ua.*, up.city, up.country as profile_country, up.company_name, up.cnic_or_id,
               ivr.id as verification_record_id, ivr.verification_status as ivr_status,
               ivr.document_count, ivr.submitted_at, ivr.reviewed_by_name, ivr.reviewed_at,
               ivr.additional_docs_requested, ivr.decision_notes
        FROM user_accounts ua
        LEFT JOIN user_profiles up ON up.user_id = ua.id
        LEFT JOIN identity_verification_records ivr ON ivr.user_id = ua.id
        ORDER BY ua.updated_at DESC
      `)
      .all() as any[];

    const scoped = rows.filter((r) => {
      if (!canAdminAccessTarget(req.auth!, r) && r.id !== req.auth!.userId) return false;
      if (req.auth!.subjectType !== 'founder' && r.subject_type === 'founder') return false;
      if (roleFilter && r.role !== roleFilter) return false;
      if (statusFilter && r.status !== statusFilter) return false;
      if (verFilter && r.verification_status !== verFilter && r.ivr_status !== verFilter) return false;
      if (q) {
        const hay = `${r.full_name} ${r.email} ${r.account_code || ''} ${r.role} ${r.city || ''} ${r.company_name || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const summary = {
      totalAccounts: scoped.length,
      pendingVerification: scoped.filter((x) => ['Not Submitted', 'Pending Verification'].includes(x.verification_status)).length,
      underReview: scoped.filter((x) => x.verification_status === 'Under Review').length,
      verifiedAccounts: scoped.filter((x) => x.verification_status === 'Verified').length,
      rejectedOrSuspended: scoped.filter((x) => ['Rejected', 'Suspended'].includes(x.verification_status) || x.status === 'Suspended').length,
      totalDocuments: scoped.reduce((sum, x) => sum + (Number(x.document_count) || 0), 0),
    };

    res.json({ accounts: scoped, summary });
  });

  router.get('/accounts/:userId', requireGovernanceRole('users.view'), (req: Request, res: Response) => {
    const target = getUserAuthRecord(req.params.userId);
    if (!target) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }
    if (!canAdminAccessTarget(req.auth!, target) && target.id !== req.auth!.userId) {
      res.status(403).json({ error: 'Cross-scope account inspection is prohibited.' });
      return;
    }

    const profile = sqlite.prepare('SELECT * FROM user_profiles WHERE user_id = ?').get(target.id);
    const verificationRecord = sqlite.prepare('SELECT * FROM identity_verification_records WHERE user_id = ?').get(target.id);
    const documents = sqlite
      .prepare('SELECT id, doc_type, title, original_filename, mime_type, file_size, sha256_checksum, review_status, reviewer_notes, created_at FROM verification_documents WHERE user_id = ? ORDER BY created_at DESC')
      .all(target.id);
    const approvalHistory = sqlite
      .prepare('SELECT * FROM account_approval_history WHERE target_user_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(target.id);
    const loginActivity = sqlite
      .prepare('SELECT id, identifier, success, failure_reason, ip_address, suspicious, suspicious_reason, created_at FROM login_activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(target.id);
    const mfaRow = sqlite
      .prepare('SELECT totp_enabled, email_otp_enabled, sms_otp_enabled, mfa_required, enrolled_at FROM mfa_settings WHERE user_id = ?')
      .get(target.id);

    res.json({
      account: target,
      profile,
      verificationRecord,
      documents,
      approvalHistory,
      loginActivity,
      mfa: mfaRow,
    });
  });

  router.post('/accounts/:userId/decision', requireGovernanceRole('users.update'), (req: Request, res: Response) => {
    const target = getUserAuthRecord(req.params.userId);
    if (!target) {
      res.status(404).json({ error: 'Target account not found.' });
      return;
    }

    if (target.id === req.auth!.userId) {
      res.status(403).json({ error: 'Self-approval or self-modification of verification status is strictly prohibited.' });
      return;
    }

    if (!canAdminAccessTarget(req.auth!, target)) {
      logSecurityAudit({
        actorId: req.auth!.userId,
        actorName: req.auth!.fullName,
        actorRole: req.auth!.role,
        targetUserId: target.id,
        action: 'CROSS_SCOPE_APPROVAL_BLOCKED',
        category: 'RBAC Enforcement',
        severity: 'CRITICAL',
        details: `Blocked out-of-scope approval decision on ${target.email} (${target.role}).`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({ error: 'Permission denied: target account lies outside your organizational scope or hierarchy level.' });
      return;
    }

    const actorRank = ROLE_SENSITIVITY_RANK[req.auth!.role] || 0;
    const targetRank = ROLE_SENSITIVITY_RANK[target.role] || 0;
    if (req.auth!.subjectType !== 'founder' && actorRank <= targetRank) {
      res.status(403).json({ error: `Hierarchy violation: ${req.auth!.role} cannot modify ${target.role}.` });
      return;
    }

    const action = String(req.body?.action || '').trim();
    const reason = String(req.body?.reason || '').trim();
    const notes = String(req.body?.notes || '').trim();
    const documentId = req.body?.documentId ? String(req.body.documentId).trim() : null;

    if (!['mark_under_review', 'approve', 'reject', 'request_documents', 'suspend', 'reactivate', 'verify_email_manual'].includes(action)) {
      res.status(400).json({ error: 'Invalid verification decision action.' });
      return;
    }
    if (['reject', 'request_documents', 'suspend'].includes(action) && reason.length < 4) {
      res.status(400).json({ error: 'A clear reason (at least 4 characters) is required for rejection, suspension, or document requests.' });
      return;
    }

    const prevStatus = `${target.status} / ${target.verification_status}`;
    const now = nowIso();
    const srcTable = target.source_table;

    let nextAccountStatus = target.status;
    let nextVerStatus = target.verification_status;
    let revokeSessions = false;

    if (action === 'mark_under_review') {
      nextVerStatus = 'Under Review';
    } else if (action === 'approve') {
      nextAccountStatus = 'Active';
      nextVerStatus = 'Verified';
    } else if (action === 'reject') {
      nextAccountStatus = 'Suspended';
      nextVerStatus = 'Rejected';
      revokeSessions = true;
    } else if (action === 'request_documents') {
      nextVerStatus = 'Pending Verification';
    } else if (action === 'suspend') {
      nextAccountStatus = 'Suspended';
      nextVerStatus = 'Suspended';
      revokeSessions = true;
    } else if (action === 'reactivate') {
      nextAccountStatus = 'Active';
      nextVerStatus = target.verification_status === 'Suspended' ? 'Verified' : target.verification_status;
    } else if (action === 'verify_email_manual') {
      if (target.subject_type === 'customer') {
        nextAccountStatus = target.status === 'Suspended' ? 'Suspended' : 'Active';
      }
      nextVerStatus = target.verification_status === 'Not Submitted' ? 'Pending Verification' : target.verification_status;
    }

    sqlite.transaction(() => {
      if (action === 'verify_email_manual') {
        sqlite.prepare('UPDATE user_accounts SET email_verified = 1, status = ?, verification_status = ?, updated_at = ? WHERE id = ?').run(nextAccountStatus, nextVerStatus, now, target.id);
        sqlite.prepare('UPDATE identity_verification_records SET email_verified = 1, verification_status = ?, reviewed_by = ?, reviewed_by_name = ?, reviewed_by_role = ?, reviewed_at = ?, updated_at = ? WHERE user_id = ?')
          .run(nextVerStatus, req.auth!.userId, req.auth!.fullName, req.auth!.role, now, now, target.id);
        if (srcTable && srcTable !== 'founder_accounts') {
          sqlite.prepare(`UPDATE ${srcTable} SET email_verified = 1, status = ?, updated_at = ? WHERE id = ?`).run(nextAccountStatus, now, target.id);
        }
      } else {
        sqlite
          .prepare(`
            UPDATE user_accounts
            SET status = ?,
                verification_status = ?,
                approved_by = CASE WHEN ? = 'approve' THEN ? ELSE approved_by END,
                approved_at = CASE WHEN ? = 'approve' THEN ? ELSE approved_at END,
                rejection_reason = CASE WHEN ? IN ('reject', 'suspend') THEN ? WHEN ? = 'approve' THEN NULL ELSE rejection_reason END,
                updated_at = ?
            WHERE id = ?
          `)
          .run(
            nextAccountStatus,
            nextVerStatus,
            action,
            req.auth!.fullName,
            action,
            now,
            action,
            reason,
            action,
            now,
            target.id
          );

        sqlite
          .prepare(`
            UPDATE identity_verification_records
            SET verification_status = ?,
                reviewed_by = ?,
                reviewed_by_name = ?,
                reviewed_by_role = ?,
                reviewed_at = ?,
                decision_notes = COALESCE(NULLIF(?, ''), decision_notes),
                rejection_reason = CASE WHEN ? IN ('reject', 'suspend') THEN ? WHEN ? = 'approve' THEN NULL ELSE rejection_reason END,
                additional_docs_requested = CASE WHEN ? = 'request_documents' THEN ? WHEN ? = 'approve' THEN NULL ELSE additional_docs_requested END,
                updated_at = ?
            WHERE user_id = ?
          `)
          .run(
            nextVerStatus,
            req.auth!.userId,
            req.auth!.fullName,
            req.auth!.role,
            now,
            notes || reason,
            action,
            reason,
            action,
            action,
            reason,
            action,
            now,
            target.id
          );

        if (documentId) {
          const docStatus = action === 'approve' ? 'Verified' : action === 'reject' ? 'Rejected' : 'Under Review';
          sqlite
            .prepare('UPDATE verification_documents SET review_status = ?, reviewer_notes = ? WHERE id = ? AND user_id = ?')
            .run(docStatus, reason || notes || docStatus, documentId, target.id);
        } else if (action === 'approve') {
          sqlite
            .prepare("UPDATE verification_documents SET review_status = 'Verified' WHERE user_id = ? AND review_status IN ('Pending Review', 'Under Review')")
            .run(target.id);
        }

        // Sync back into source portal table cleanly
        if (srcTable === 'dealer_accounts') {
          sqlite
            .prepare(`
              UPDATE dealer_accounts
              SET status = ?,
                  verification_status = ?,
                  approved_by = CASE WHEN ? = 'approve' THEN ? ELSE approved_by END,
                  approved_at = CASE WHEN ? = 'approve' THEN ? ELSE approved_at END,
                  rejection_reason = CASE WHEN ? IN ('reject', 'suspend') THEN ? ELSE rejection_reason END,
                  updated_at = ?
              WHERE id = ?
            `)
            .run(
              nextAccountStatus,
              nextVerStatus === 'Verified' ? 'Verified' : nextVerStatus === 'Rejected' ? 'Rejected' : nextVerStatus === 'Suspended' ? 'Suspended' : 'Pending Verification',
              action,
              req.auth!.fullName,
              action,
              now,
              action,
              reason,
              now,
              target.id
            );
        } else if (srcTable === 'customer_accounts') {
          sqlite
            .prepare(`
              UPDATE customer_accounts
              SET status = ?,
                  verification_status = ?,
                  updated_at = ?
              WHERE id = ?
            `)
            .run(nextAccountStatus, nextVerStatus, now, target.id);
        } else if (srcTable && srcTable !== 'founder_accounts') {
          sqlite
            .prepare(`UPDATE ${srcTable} SET status = ?, updated_at = ? WHERE id = ?`)
            .run(nextAccountStatus, now, target.id);
        }
      }

      if (revokeSessions) {
        sqlite
          .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'admin_decision', revoked_at = ? WHERE user_id = ? AND revoked = 0")
          .run(now, target.id);
        sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(target.id);
      }

      sqlite
        .prepare(`
          INSERT INTO account_approval_history (
            id, target_user_id, target_subject_type, target_role, target_email,
            action, previous_status, new_status, reason, notes, actor_id, actor_name, actor_role, ip_address, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          `aah_${generateSecureToken(6)}`,
          target.id,
          target.subject_type,
          target.role,
          target.email,
          action.toUpperCase(),
          prevStatus,
          `${nextAccountStatus} / ${nextVerStatus}`,
          reason || null,
          notes || null,
          req.auth!.userId,
          req.auth!.fullName,
          req.auth!.role,
          getClientIp(req),
          now
        );
    })();

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: `VERIFICATION_${action.toUpperCase()}`,
      module: 'Identity Verification & Approval',
      targetId: `${target.email} (${target.role})`,
      companyId: target.company_id,
      details: reason || notes || undefined,
      ipAddress: getClientIp(req),
    });

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: target.id,
      companyId: target.company_id,
      countryId: target.country_id,
      branchId: target.branch_id,
      action: `ACCOUNT_VERIFICATION_${action.toUpperCase()}`,
      category: 'Admin Approval Governance',
      severity: revokeSessions ? 'WARNING' : 'INFO',
      details: `${req.auth!.role} applied "${action}" on ${target.email}: ${nextAccountStatus} / ${nextVerStatus}`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      newStatus: nextAccountStatus,
      newVerificationStatus: nextVerStatus,
      message: `Account verification updated to ${nextAccountStatus} (${nextVerStatus}).`,
    });
  });

  router.get('/audit-logs', requireGovernanceRole('audit_logs.view'), (req: Request, res: Response) => {
    const logs = sqlite
      .prepare('SELECT * FROM security_audit_logs ORDER BY created_at DESC LIMIT 120')
      .all() as any[];

    const scoped = logs.filter((l) => {
      if (req.auth!.subjectType === 'founder' || req.auth!.subjectType === 'super_admin') return true;
      if (req.auth!.subjectType === 'company_admin') return !l.company_id || l.company_id === req.auth!.companyId;
      if (req.auth!.subjectType === 'country_manager') return !l.country_id || l.country_id === req.auth!.country;
      if (req.auth!.subjectType === 'branch_manager') return !l.branch_id || l.branch_id === req.auth!.branchId;
      return false;
    });

    res.json({ logs: scoped.slice(0, 80) });
  });

  router.get('/login-activity', requireGovernanceRole('audit_logs.view'), (req: Request, res: Response) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const roleFilter = String(req.query.role || '').trim();
    const statusFilter = String(req.query.status || '').trim().toLowerCase();
    const fromDate = String(req.query.fromDate || '').trim();
    const toDate = String(req.query.toDate || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT lal.*, ua.full_name as resolved_name, ua.email as resolved_email
        FROM login_activity_logs lal
        LEFT JOIN user_accounts ua ON ua.id = lal.user_id
        ORDER BY lal.created_at DESC
        LIMIT 300
      `)
      .all() as any[];

    const scopedAll = rows
      .filter((l) => {
        if (req.auth!.subjectType === 'founder' || req.auth!.subjectType === 'super_admin') return true;
        if (req.auth!.subjectType === 'company_admin') return !l.company_id || l.company_id === req.auth!.companyId;
        if (req.auth!.subjectType === 'country_manager') return !l.country_id || l.country_id === req.auth!.country;
        if (req.auth!.subjectType === 'branch_manager') return !l.branch_id || l.branch_id === req.auth!.branchId;
        return false;
      })
      .map((l) => {
        const uaParsed = parseUserAgentInfo(l.user_agent);
        return {
          ...l,
          account_name: l.account_name || l.resolved_name || l.identifier,
          resolved_email: l.resolved_email || (String(l.identifier || '').includes('@') ? l.identifier : null),
          device_name: l.device_name || uaParsed.deviceName,
          browser_name: l.browser_name || uaParsed.browserName,
        };
      });

    const filtered = scopedAll.filter((l) => {
      if (roleFilter && l.role !== roleFilter && l.subject_type !== roleFilter) return false;
      if (statusFilter === 'success' && !l.success) return false;
      if (statusFilter === 'failed' && l.success) return false;
      if (statusFilter === 'suspicious' && !l.suspicious) return false;
      if (fromDate && l.created_at.slice(0, 10) < fromDate) return false;
      if (toDate && l.created_at.slice(0, 10) > toDate) return false;
      if (q) {
        const hay = `${l.account_name || ''} ${l.identifier || ''} ${l.resolved_email || ''} ${l.user_id || ''} ${l.role || ''} ${l.ip_address || ''} ${l.device_name || ''} ${l.browser_name || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const activeSessionsCount = (
      sqlite
        .prepare('SELECT COUNT(*) as c FROM authentication_sessions WHERE revoked = 0 AND expires_at > ?')
        .get(nowIso()) as { c: number }
    )?.c || 0;

    res.json({
      logs: filtered.slice(0, 120),
      stats: {
        totalAttempts: scopedAll.length,
        successfulLogins: scopedAll.filter((l) => Boolean(l.success)).length,
        failedLogins: scopedAll.filter((l) => !l.success).length,
        suspiciousAlerts: scopedAll.filter((l) => Boolean(l.suspicious)).length,
        activeSessions: activeSessionsCount,
      },
    });
  });

  // Active Sessions Listing & Scoped Admin Termination
  router.get('/sessions', requireGovernanceRole('audit_logs.view'), (req: Request, res: Response) => {
    const rows = sqlite
      .prepare(`
        SELECT s.id, s.user_id, s.subject_type, s.company_id, s.role, s.ip_address, s.user_agent,
               s.device_label, s.last_activity_at, s.idle_expires_at, s.expires_at, s.created_at,
               ua.full_name, ua.email, ua.country_id, ua.branch_id,
               CASE WHEN s.id = ? THEN 1 ELSE 0 END as is_current
        FROM authentication_sessions s
        LEFT JOIN user_accounts ua ON ua.id = s.user_id
        WHERE s.revoked = 0 AND s.expires_at > ?
        ORDER BY s.last_activity_at DESC
        LIMIT 150
      `)
      .all(req.auth!.sessionId, nowIso()) as any[];

    const scoped = rows
      .filter((s) => {
        if (req.auth!.subjectType === 'founder') return true;
        if (s.subject_type === 'founder') return false;
        if (req.auth!.subjectType === 'super_admin') return true;
        if (req.auth!.subjectType === 'company_admin') return s.company_id === req.auth!.companyId;
        if (req.auth!.subjectType === 'country_manager') return s.country_id === req.auth!.country;
        if (req.auth!.subjectType === 'branch_manager') return s.branch_id === req.auth!.branchId;
        return false;
      })
      .map((s) => {
        const uaParsed = parseUserAgentInfo(s.user_agent);
        return {
          ...s,
          device_name: uaParsed.deviceName,
          browser_name: uaParsed.browserName,
        };
      });

    res.json({ sessions: scoped });
  });

  router.post('/sessions/:sessionId/terminate', requireGovernanceRole('users.suspend'), (req: Request, res: Response) => {
    const sess = sqlite.prepare('SELECT * FROM authentication_sessions WHERE id = ?').get(req.params.sessionId) as any;
    if (!sess) {
      res.status(404).json({ error: 'Session not found.' });
      return;
    }

    const targetAcc = getUserAuthRecord(sess.user_id);
    if (req.auth!.subjectType !== 'founder' && sess.subject_type === 'founder') {
      res.status(403).json({ error: 'Only the Primary Owner can manage Founder sessions.' });
      return;
    }
    if (targetAcc && !canAdminAccessTarget(req.auth!, targetAcc) && sess.user_id !== req.auth!.userId) {
      res.status(403).json({ error: 'Cross-scope session termination is prohibited.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare("UPDATE authentication_sessions SET revoked = 1, revoked_reason = 'admin_terminated', revoked_at = ? WHERE id = ?")
      .run(now, sess.id);
    sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE id = ?').run(sess.id);
    markLoginSessionTerminated(sess.id, 'admin_terminated');

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      targetUserId: sess.user_id,
      companyId: sess.company_id,
      action: 'SESSION_TERMINATED_BY_ADMIN',
      category: 'Session Security',
      severity: 'WARNING',
      details: `Terminated session ${sess.id} (${sess.role}) by ${req.auth!.role}.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, message: 'Active session terminated and logged.' });
  });

  // RBAC 6-Role x Module x Action Matrix Management
  router.get('/rbac-matrix', requireGovernanceRole('users.view'), (req: Request, res: Response) => {
    const rows = sqlite
      .prepare('SELECT role_key, module_key, can_view, can_create, can_edit, can_delete, can_approve, is_locked, updated_by, updated_at FROM rbac_role_action_permissions')
      .all() as any[];

    const canEditMatrix =
      req.auth!.subjectType === 'founder' ||
      (req.auth!.subjectType === 'super_admin' && checkRbacAction(req.auth!.subjectType, req.auth!.role, 'RBAC & Roles', 'edit'));

    res.json({
      roles: [...RBAC_ROLES],
      modules: [...RBAC_MODULES],
      matrix: rows,
      canEditFounder: false,
      canEditMatrix,
    });
  });

  router.put('/rbac-matrix', requireGovernanceRole('settings.manage'), (req: Request, res: Response) => {
    if (req.auth!.subjectType !== 'founder' && req.auth!.subjectType !== 'super_admin') {
      res.status(403).json({ error: 'Only Founder / CEO or authorized Super Admin can modify global RBAC policies.' });
      return;
    }
    if (req.auth!.subjectType === 'super_admin' && !checkRbacAction(req.auth!.subjectType, req.auth!.role, 'RBAC & Roles', 'edit')) {
      res.status(403).json({ error: 'Super Admin lacks "RBAC & Roles" edit privilege.' });
      return;
    }

    const updates = Array.isArray(req.body?.updates) ? req.body.updates : [];
    if (updates.length === 0) {
      res.status(400).json({ error: 'At least one RBAC permission update is required.' });
      return;
    }

    const validRoles = new Set<string>(RBAC_ROLES as unknown as string[]);
    const validModules = new Set<string>(RBAC_MODULES as unknown as string[]);

    for (const u of updates) {
      if (!validRoles.has(String(u.roleKey)) || !validModules.has(String(u.moduleKey))) {
        res.status(400).json({ error: `Invalid RBAC role (${u.roleKey}) or module (${u.moduleKey}).` });
        return;
      }
      if (u.roleKey === 'Founder / CEO') {
        logSecurityAudit({
          actorId: req.auth!.userId,
          actorName: req.auth!.fullName,
          actorRole: req.auth!.role,
          action: 'FOUNDER_RBAC_MODIFICATION_BLOCKED',
          category: 'RBAC Enforcement',
          severity: 'CRITICAL',
          details: `Blocked attempt to alter immutable Founder / CEO permission on ${u.moduleKey}.`,
          ipAddress: getClientIp(req),
        });
        res.status(403).json({
          error: 'Founder / CEO permissions are immutable and protected against modification or revocation.',
        });
        return;
      }
      if (req.auth!.subjectType === 'super_admin' && u.roleKey === 'Super Admin') {
        res.status(403).json({
          error: 'Super Admin cannot self-modify Super Admin RBAC privileges. Only the Founder / CEO can manage Super Admin RBAC.',
        });
        return;
      }
      if (req.auth!.subjectType === 'super_admin' && u.moduleKey === 'RBAC & Roles' && u.canEdit) {
        if (!checkRbacAction(req.auth!.subjectType, req.auth!.role, 'RBAC & Roles', 'edit')) {
          res.status(403).json({ error: 'Cannot grant RBAC editing privilege above current authorization.' });
          return;
        }
      }
    }

    const now = nowIso();
    const updStmt = sqlite.prepare(`
      UPDATE rbac_role_action_permissions
      SET can_view = ?, can_create = ?, can_edit = ?, can_delete = ?, can_approve = ?, updated_by = ?, updated_at = ?
      WHERE role_key = ? AND module_key = ? AND is_locked = 0
    `);

    sqlite.transaction(() => {
      for (const u of updates) {
        updStmt.run(
          u.canView ? 1 : 0,
          u.canCreate ? 1 : 0,
          u.canEdit ? 1 : 0,
          u.canDelete ? 1 : 0,
          u.canApprove ? 1 : 0,
          req.auth!.fullName,
          now,
          u.roleKey,
          u.moduleKey
        );
      }
    })();

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'RBAC_MATRIX_UPDATED',
      category: 'RBAC Enforcement',
      severity: 'WARNING',
      details: `Updated ${updates.length} role-module permission entries.`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, updatedCount: updates.length, message: 'RBAC permission matrix updated and enforced on backend.' });
  });

  // Security Policy & Recovery Settings Management
  router.get('/security-settings', requireGovernanceRole('audit_logs.view'), (req: Request, res: Response) => {
    const policy = getSystemSetting('security_policy', {
      sessionTimeoutMinutes: 120,
      idleTimeoutMinutes: 45,
      maxFailedLoginAttempts: 5,
      lockoutMinutes: 15,
      otpExpiryMinutes: 10,
      otpMaxAttempts: 5,
      otpCooldownSeconds: 60,
      passwordReuseLimit: 5,
      forgotPasswordCooldownSeconds: 60,
      require2FAForFounder: true,
      require2FAForSuperAdmin: true,
      enforce2FAForAdmins: true,
      allowMfaRecoveryCodes: true,
    });
    const canEdit =
      req.auth!.subjectType === 'founder' ||
      (req.auth!.subjectType === 'super_admin' && req.auth!.permissions.includes('settings.manage'));
    res.json({
      securityPolicy: policy,
      smtpConfigured: isSmtpConfigured(),
      smsConfigured: isSmsGatewayConfigured(),
      canEdit,
    });
  });

  router.put('/security-settings', requireGovernanceRole('settings.manage'), (req: Request, res: Response) => {
    if (req.auth!.subjectType !== 'founder' && (req.auth!.subjectType !== 'super_admin' || !req.auth!.permissions.includes('settings.manage'))) {
      res.status(403).json({ error: 'Only Founder / CEO or authorized Super Admin can modify enterprise security policy.' });
      return;
    }

    const current = getSystemSetting('security_policy', {
      sessionTimeoutMinutes: 120,
      idleTimeoutMinutes: 45,
      maxFailedLoginAttempts: 5,
      lockoutMinutes: 15,
      otpExpiryMinutes: 10,
      otpMaxAttempts: 5,
      otpCooldownSeconds: 60,
      passwordReuseLimit: 5,
      forgotPasswordCooldownSeconds: 60,
      require2FAForFounder: true,
      require2FAForSuperAdmin: true,
      enforce2FAForAdmins: true,
      allowMfaRecoveryCodes: true,
    });

    const clamp = (val: any, min: number, max: number, fallback: number) => {
      const n = Number(val);
      return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : fallback;
    };

    const incoming = req.body?.securityPolicy || req.body || {};
    const nextPolicy = {
      ...current,
      sessionTimeoutMinutes: clamp(incoming.sessionTimeoutMinutes, 15, 1440, current.sessionTimeoutMinutes || 120),
      idleTimeoutMinutes: clamp(incoming.idleTimeoutMinutes, 5, 240, current.idleTimeoutMinutes || 45),
      maxFailedLoginAttempts: clamp(incoming.maxFailedLoginAttempts, 3, 15, current.maxFailedLoginAttempts || 5),
      lockoutMinutes: clamp(incoming.lockoutMinutes, 5, 120, current.lockoutMinutes || 15),
      otpExpiryMinutes: clamp(incoming.otpExpiryMinutes, 2, 60, current.otpExpiryMinutes || 10),
      otpMaxAttempts: clamp(incoming.otpMaxAttempts, 3, 10, current.otpMaxAttempts || 5),
      otpCooldownSeconds: clamp(incoming.otpCooldownSeconds, 30, 600, current.otpCooldownSeconds || 60),
      passwordReuseLimit: clamp(incoming.passwordReuseLimit, 1, 12, current.passwordReuseLimit || 5),
      forgotPasswordCooldownSeconds: clamp(incoming.forgotPasswordCooldownSeconds, 30, 600, current.forgotPasswordCooldownSeconds || 60),
      require2FAForFounder: true,
      require2FAForSuperAdmin: true,
      enforce2FAForAdmins: incoming.enforce2FAForAdmins !== false,
      allowMfaRecoveryCodes: incoming.allowMfaRecoveryCodes !== false,
    };

    setSystemSetting('security_policy', nextPolicy, req.auth!.fullName);

    logSecurityAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SECURITY_POLICY_UPDATED',
      category: 'Security Settings',
      severity: 'WARNING',
      details: `Updated OTP/2FA/Password Recovery policy (OTP expiry ${nextPolicy.otpExpiryMinutes}m, reuse limit ${nextPolicy.passwordReuseLimit}, idle ${nextPolicy.idleTimeoutMinutes}m).`,
      ipAddress: getClientIp(req),
    });

    res.json({
      success: true,
      securityPolicy: nextPolicy,
      message: 'Enterprise OTP, 2FA, and password recovery security policy saved.',
    });
  });

  return router;
}
