import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Eye,
  Edit3,
  FileText,
  Store,
  Users,
  Car,
  CheckCircle2,
  Search,
} from 'lucide-react';
import { api } from '../../services/api';

interface Props {
  companies: any[];
  formatPrice: (n: number) => string;
  onRefresh: () => Promise<void>;
  onNotify: (msg: string) => void;
}

export const SuperAdminCompaniesPanel: React.FC<Props> = ({ companies, formatPrice, onRefresh, onNotify }) => {
  const [search, setSearch] = useState('');
  const [countryFilter, setCountryFilter] = useState('ALL');
  const [error, setError] = useState('');

  const [showAddForm, setShowAddForm] = useState(false);
  const [newComp, setNewComp] = useState({
    name: '',
    country: 'Pakistan',
    city: 'Karachi',
    officialEmail: '',
    phone: '+92 ',
    address: '',
    registrationDetails: '',
    authorizedRep: '',
    website: '',
    taxId: '',
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ phone: '', city: '', address: '', authorizedRep: '' });

  const [detail, setDetail] = useState<any>(null);
  const [docForm, setDocForm] = useState({ title: '', docType: 'Corporate Registration', referenceNo: '' });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.createSuperAdminCompany(newComp);
      onNotify(`Company submitted (${res.status}). Primary Owner holds final workspace activation.`);
      setShowAddForm(false);
      setNewComp({
        name: '',
        country: 'Pakistan',
        city: 'Karachi',
        officialEmail: '',
        phone: '+92 ',
        address: '',
        registrationDetails: '',
        authorizedRep: '',
        website: '',
        taxId: '',
      });
      await onRefresh();
    } catch (err: any) {
      setError(err?.message || 'Unable to register company.');
    }
  };

  const handleSaveEdit = async (id: string) => {
    setError('');
    try {
      await api.updateSuperAdminCompany(id, editForm);
      onNotify('Company operational contact metadata updated.');
      setEditingId(null);
      await onRefresh();
    } catch (err: any) {
      setError(err?.message || 'Failed to update company metadata.');
    }
  };

  const inspectCompany = async (id: string) => {
    setError('');
    try {
      const res = await api.getSuperAdminCompanyDetail(id);
      setDetail(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to load company profile details.');
    }
  };

  const handleAttachDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!detail?.company || !docForm.title.trim()) return;
    setError('');
    try {
      await api.updateSuperAdminCompanyDocuments(detail.company.id, {
        newDocument: { ...docForm, status: 'Submitted' },
      });
      onNotify('Corporate document record attached to company dossier.');
      setDocForm({ title: '', docType: 'Corporate Registration', referenceNo: '' });
      await inspectCompany(detail.company.id);
    } catch (err: any) {
      setError(err?.message || 'Failed to update company documents.');
    }
  };

  const countries = Array.from(new Set(companies.map((c) => c.country).filter(Boolean))).sort();
  const filtered = companies.filter((c) => {
    if (countryFilter !== 'ALL' && c.country !== countryFilter) return false;
    if (search.trim()) {
      const hay = `${c.name} ${c.city} ${c.country} ${c.official_email} ${c.authorized_rep}`.toLowerCase();
      if (!hay.includes(search.toLowerCase())) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6 text-xs">
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              Corporate Registry &amp; Subsidiaries
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              Company Management, Branches, Performance &amp; Corporate Filings
            </h3>
            <p className="text-slate-400 mt-0.5">
              Manage company details, corporate documents, and branch performance. Company workspace activation/suspension remains reserved exclusively for the Founder / CEO.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold flex items-center gap-1.5 self-start shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Register Company</span>
          </button>
        </div>

        {error && <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-700 text-rose-200">{error}</div>}

        {showAddForm && (
          <form onSubmit={handleCreate} className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/40 space-y-3">
            <h4 className="text-sm font-bold text-white">Submit New Subsidiary / Operating Company</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input required placeholder="Legal Company Name" value={newComp.name} onChange={(e) => setNewComp({ ...newComp, name: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="Country (e.g. Pakistan, UAE)" value={newComp.country} onChange={(e) => setNewComp({ ...newComp, country: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="HQ City" value={newComp.city} onChange={(e) => setNewComp({ ...newComp, city: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required type="email" placeholder="Official Corporate Email" value={newComp.officialEmail} onChange={(e) => setNewComp({ ...newComp, officialEmail: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="Corporate Phone" value={newComp.phone} onChange={(e) => setNewComp({ ...newComp, phone: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="Authorized Representative" value={newComp.authorizedRep} onChange={(e) => setNewComp({ ...newComp, authorizedRep: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="Registered HQ Address" value={newComp.address} onChange={(e) => setNewComp({ ...newComp, address: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input required placeholder="Registration / SECP Details" value={newComp.registrationDetails} onChange={(e) => setNewComp({ ...newComp, registrationDetails: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
              <input placeholder="Tax ID / NTN / TRN" value={newComp.taxId} onChange={(e) => setNewComp({ ...newComp, taxId: e.target.value })} className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-white" />
            </div>
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold">Cancel</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold">Register Company</button>
            </div>
          </form>
        )}

        {/* Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="relative sm:col-span-2">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search company name, email, city, rep..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white"
            />
          </div>
          <select
            value={countryFilter}
            onChange={(e) => setCountryFilter(e.target.value)}
            className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
          >
            <option value="ALL">All Countries ({companies.length})</option>
            {countries.map((co) => (
              <option key={co} value={co}>{co}</option>
            ))}
          </select>
        </div>

        {/* Company Cards */}
        <div className="space-y-3">
          {filtered.map((c) => (
            <div key={c.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Building2 className="w-4 h-4 text-cyan-400" />
                    <span className="text-sm font-black text-white">{c.name}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        c.status === 'Approved'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : c.status === 'Suspended'
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : 'bg-amber-950 text-amber-300 border-amber-800'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>
                  <p className="text-slate-400">
                    {c.city}, {c.country} · Rep: <span className="text-white">{c.authorized_rep}</span> · {c.official_email} · {c.phone}
                  </p>
                  <p className="text-[11px] font-mono text-slate-500">
                    Reg: {c.registration_details} · Branches/Showrooms: {c.branch_count} · Staff: {c.employee_count} · Fleet: {c.vehicle_count}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start shrink-0">
                  <button
                    type="button"
                    onClick={() => inspectCompany(c.id)}
                    className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-500 text-cyan-300 font-bold flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Profile &amp; Docs</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingId(editingId === c.id ? null : c.id);
                      setEditForm({ phone: c.phone || '', city: c.city || '', address: c.address || '', authorizedRep: c.authorized_rep || '' });
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-slate-200 flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{editingId === c.id ? 'Cancel' : 'Edit Info'}</span>
                  </button>
                </div>
              </div>

              {editingId === c.id && (
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 pt-3 border-t border-slate-800">
                  <input value={editForm.authorizedRep} onChange={(e) => setEditForm({ ...editForm, authorizedRep: e.target.value })} placeholder="Authorized Rep" className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  <input value={editForm.city} onChange={(e) => setEditForm({ ...editForm, city: e.target.value })} placeholder="City" className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  <input value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} placeholder="Phone" className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  <input value={editForm.address} onChange={(e) => setEditForm({ ...editForm, address: e.target.value })} placeholder="Address" className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
                  <button type="button" onClick={() => handleSaveEdit(c.id)} className="rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2">
                    Save Changes
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Company Detailed Profile, Branches, Performance & Document Vault */}
      {detail?.company && (
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="text-[11px] font-mono text-cyan-400">
                {detail.company.id} · Tax ID {detail.company.tax_id || 'Pending'} · {detail.company.website || 'No website'}
              </div>
              <h4 className="text-base font-black text-white">{detail.company.name} — Full Corporate Dossier</h4>
            </div>
            <button type="button" onClick={() => setDetail(null)} className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-300 hover:text-white">
              Close Dossier
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
            {[
              { label: 'Branches', val: detail.performance?.branchesCount ?? 0, Icon: Store },
              { label: 'Employees', val: detail.performance?.employeesCount ?? 0, Icon: Users },
              { label: 'Dealers', val: detail.performance?.dealersCount ?? 0, Icon: CheckCircle2 },
              { label: 'Total Vehicles', val: detail.performance?.totalVehicles ?? 0, Icon: Car },
              { label: 'Paid Revenue', val: formatPrice(detail.performance?.paidRevenuePkr ?? 0), Icon: FileText },
              { label: 'Pending Rev', val: formatPrice(detail.performance?.pendingRevenuePkr ?? 0), Icon: FileText },
            ].map((k) => {
              const Icon = k.Icon;
              return (
                <div key={k.label} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-slate-400 text-[11px]">
                    <span>{k.label}</span>
                    <Icon className="w-3.5 h-3.5 text-cyan-400" />
                  </div>
                  <div className="font-mono font-black text-white text-sm mt-1 tabular-nums">{k.val}</div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Branches */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <h5 className="font-bold text-white">Company Branches ({detail.branches?.length || 0})</h5>
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {(detail.branches || []).map((b: any) => (
                  <div key={b.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">{b.name} ({b.code})</div>
                      <div className="text-[11px] text-slate-400">{b.city}, {b.country_name || b.country_id} · Mgr: {b.manager_name}</div>
                    </div>
                    <span className="font-mono text-emerald-400 font-bold tabular-nums">{b.achieved_units}/{b.monthly_target_units}</span>
                  </div>
                ))}
                {(!detail.branches || detail.branches.length === 0) && <div className="text-slate-500">No branches registered.</div>}
              </div>
            </div>

            {/* Corporate Documents + Attach Form */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <h5 className="font-bold text-white">Corporate Documents &amp; Registrations ({detail.company.documents?.length || 0})</h5>
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {(detail.company.documents || []).map((d: any, i: number) => (
                  <div key={d.id || i} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white">{d.title || d.name}</div>
                      <div className="font-mono text-[10px] text-slate-400">{d.docType || 'Corporate Filing'} {d.referenceNo ? `· Ref ${d.referenceNo}` : ''}</div>
                    </div>
                    <span className="text-cyan-300 font-mono text-[10px]">{d.status || 'On File'}</span>
                  </div>
                ))}
              </div>
              <form onSubmit={handleAttachDocument} className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
                <input required placeholder="Document Title (e.g. SECP Form-A)" value={docForm.title} onChange={(e) => setDocForm({ ...docForm, title: e.target.value })} className="flex-1 min-w-[140px] rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-white" />
                <input placeholder="Ref No." value={docForm.referenceNo} onChange={(e) => setDocForm({ ...docForm, referenceNo: e.target.value })} className="w-28 rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-white font-mono" />
                <button type="submit" className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold">Add Doc Record</button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
