import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Mail,
  Smartphone,
  Upload,
  FileText,
  Download,
  KeyRound,
  Lock,
  Monitor,
  LogOut,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { api } from '../../services/api';
import { useApp } from '../../context/AppContext';

const DOC_TYPES = [
  'National ID / CNIC (Front & Back)',
  'Passport / Driving License',
  'SECP / Corporate Registration',
  'Dealership Authorization Certificate',
  'Employment Appointment Letter',
  'Proof of Residence / Utility Bill',
];

export const AccountSecurityCenter: React.FC = () => {
  const { logoutUser, refreshSession } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState<{ text: string; ok: boolean } | null>(null);

  // Email verification token / resend state
  const [emailTokenInput, setEmailTokenInput] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [outboxTokenHint, setOutboxTokenHint] = useState<string | null>(null);

  // Mobile OTP state
  const [mobilePhoneInput, setMobilePhoneInput] = useState('');
  const [mobileOtpCode, setMobileOtpCode] = useState('');

  // Document upload state
  const [docType, setDocType] = useState(DOC_TYPES[0]);
  const [docTitle, setDocTitle] = useState('');
  const [docFile, setDocFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  // MFA enrollment / recovery state
  const [mfaPassword, setMfaPassword] = useState('');
  const [pendingSecret, setPendingSecret] = useState<{ secret: string; otpAuthUri: string } | null>(null);
  const [mfaConfirmCode, setMfaConfirmCode] = useState('');
  const [freshRecoveryCodes, setFreshRecoveryCodes] = useState<string[] | null>(null);
  const [disableMfaForm, setDisableMfaForm] = useState({ password: '', code: '' });

  // Password change state
  const [pwForm, setPwForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    revokeOtherSessions: true,
  });

  const flash = (text: string, ok = true) => {
    setNotice({ text, ok });
    setTimeout(() => setNotice(null), 6000);
  };

  const loadSecurityProfile = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.getMySecurityProfile();
      setData(res);
      if (res.account?.mobile && !mobilePhoneInput) {
        setMobilePhoneInput(res.account.mobile);
      }
    } catch (err: any) {
      flash(err?.message || 'Unable to load account security profile.', false);
    } finally {
      setLoading(false);
    }
  }, [mobilePhoneInput]);

  useEffect(() => {
    loadSecurityProfile();
  }, [loadSecurityProfile]);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  const handleDownloadDocument = async (docId: string, fallbackName: string) => {
    try {
      const res = await fetch(`/api/verification/documents/${docId}/download`, { credentials: 'include' });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error || `Download failed (${res.status})`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fallbackName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      flash(err?.message || 'Unable to download verification document.', false);
    }
  };

  const acc = data?.account;
  const ivr = data?.verificationRecord;
  const mfa = data?.mfa;
  const caps = data?.capabilities;

  return (
    <div className="rounded-xl bg-slate-900 border border-slate-800 p-5 sm:p-6 space-y-6 text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400">
            Account Protection &amp; Verification Center
          </div>
          <h3 className="text-base font-bold text-white flex items-center gap-2 mt-0.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Identity Status, MFA Security, KYC Vault &amp; Active Sessions</span>
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadSecurityProfile}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            type="button"
            onClick={async () => {
              try {
                await api.logoutAllDevices();
                logoutUser();
              } catch (err: any) {
                flash(err?.message || 'Unable to revoke all device sessions.', false);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950 border border-rose-800 text-rose-200 hover:text-white font-semibold"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out All Devices</span>
          </button>
        </div>
      </div>

      {notice && (
        <div
          className={`p-3 rounded-lg border flex items-center gap-2 ${
            notice.ok
              ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
              : 'bg-rose-950/40 border-rose-700/60 text-rose-200'
          }`}
        >
          {notice.ok ? <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" /> : <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
          <span>{notice.text}</span>
        </div>
      )}

      {acc && (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400">Account Status</div>
            <div className="text-sm font-bold text-white mt-0.5">{acc.status}</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400">Identity Verification</div>
            <div
              className={`text-sm font-bold mt-0.5 ${
                ivr?.verification_status === 'Verified'
                  ? 'text-emerald-400'
                  : ivr?.verification_status === 'Rejected' || ivr?.verification_status === 'Suspended'
                    ? 'text-rose-400'
                    : 'text-amber-300'
              }`}
            >
              {ivr?.verification_status || acc.verification_status}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400">Email Verification</div>
            <div className={`text-sm font-bold mt-0.5 ${acc.email_verified ? 'text-emerald-400' : 'text-amber-300'}`}>
              {acc.email_verified ? 'Verified' : 'Pending'}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400">Mobile SMS Verification</div>
            <div className={`text-sm font-bold mt-0.5 ${acc.mobile_verified ? 'text-emerald-400' : 'text-slate-300'}`}>
              {acc.mobile_verified ? 'Verified' : caps?.smsConfigured ? 'Pending OTP' : 'Gateway Unconfigured'}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400">MFA Protection</div>
            <div className={`text-sm font-bold mt-0.5 ${mfa?.totpEnabled ? 'text-emerald-400' : 'text-amber-300'}`}>
              {mfa?.totpEnabled ? 'TOTP Active' : mfa?.mfaRequired ? 'Required' : 'Optional'}
            </div>
          </div>
        </div>
      )}

      {ivr?.additional_docs_requested && (
        <div className="p-3.5 rounded-lg bg-amber-950/30 border border-amber-700/50 text-amber-200">
          <div className="font-bold">Additional Verification Documents Requested by Administrator</div>
          <p className="mt-1 text-amber-100">{ivr.additional_docs_requested}</p>
        </div>
      )}

      {/* Email & Mobile Verification + KYC Vault */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="space-y-4">
          {/* Email Verification Block */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-bold text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-cyan-400" />
                <span>Email Verification ({acc?.email || '—'})</span>
              </div>
              <span className="font-mono text-[11px] text-slate-400">
                {acc?.email_verified ? 'Confirmed' : 'Action Needed'}
              </span>
            </div>
            {!acc?.email_verified && (
              <>
                {outboxTokenHint && (
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700 font-mono text-[11px] text-amber-300 break-all">
                    Dev Outbox Token (SMTP unconfigured): {outboxTokenHint}
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={emailTokenInput}
                    onChange={(e) => setEmailTokenInput(e.target.value)}
                    placeholder="Paste verification token"
                    className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const res = await api.verifyEmailToken(emailTokenInput.trim());
                        flash(res.message);
                        setEmailTokenInput('');
                        setOutboxTokenHint(null);
                        await loadSecurityProfile();
                        await refreshSession();
                      } catch (err: any) {
                        flash(err?.message || 'Verification token rejected.', false);
                      }
                    }}
                    className="px-3.5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold"
                  >
                    Verify
                  </button>
                  <button
                    type="button"
                    disabled={resendCooldown > 0}
                    onClick={async () => {
                      try {
                        const res = await api.resendEmailVerification(acc?.email);
                        setResendCooldown(60);
                        setOutboxTokenHint(res.verificationOutbox?.verificationToken || null);
                        flash(res.message);
                      } catch (err: any) {
                        flash(err?.message || 'Resend cooldown active.', false);
                      }
                    }}
                    className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 font-semibold disabled:opacity-50"
                  >
                    {resendCooldown > 0 ? `${resendCooldown}s` : 'Resend'}
                  </button>
                </div>
              </>
            )}

            {/* Mobile SMS Verification */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>Mobile SMS OTP Verification</span>
                </div>
                <span className="font-mono text-[11px] text-slate-400">
                  {caps?.smsConfigured ? 'Provider Configured' : 'Provider Not Configured'}
                </span>
              </div>
              {!acc?.mobile_verified && (
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="tel"
                      value={mobilePhoneInput}
                      onChange={(e) => setMobilePhoneInput(e.target.value)}
                      placeholder="+92 300 1234567"
                      className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await api.requestMobileOtp(mobilePhoneInput.trim());
                          flash(res.message);
                        } catch (err: any) {
                          flash(err?.message || 'SMS provider unavailable.', false);
                        }
                      }}
                      className="px-3.5 py-2 rounded-lg bg-cyan-500 text-slate-950 font-bold"
                    >
                      Send SMS OTP
                    </button>
                  </div>
                  {caps?.smsConfigured && (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={6}
                        value={mobileOtpCode}
                        onChange={(e) => setMobileOtpCode(e.target.value)}
                        placeholder="6-digit SMS OTP"
                        className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const res = await api.verifyMobileOtp({ phone: mobilePhoneInput.trim(), code: mobileOtpCode.trim() });
                            flash(res.message);
                            setMobileOtpCode('');
                            await loadSecurityProfile();
                          } catch (err: any) {
                            flash(err?.message || 'SMS OTP invalid.', false);
                          }
                        }}
                        className="px-3.5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold"
                      >
                        Confirm OTP
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Private Identity / KYC Document Upload */}
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!docFile) {
                flash('Select a PDF, PNG, JPG, or WEBP file to upload.', false);
                return;
              }
              setUploading(true);
              try {
                const fd = new FormData();
                fd.append('docType', docType);
                fd.append('title', docTitle || docType);
                fd.append('document', docFile);
                const res = await api.uploadVerificationDocument(fd);
                flash(res.message);
                setDocTitle('');
                setDocFile(null);
                await loadSecurityProfile();
              } catch (err: any) {
                flash(err?.message || 'Document upload failed.', false);
              } finally {
                setUploading(false);
              }
            }}
            className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3"
          >
            <div className="font-bold text-white flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>Private Identity Verification Documents ({data?.documents?.length || 0})</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
              >
                {DOC_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={docTitle}
                onChange={(e) => setDocTitle(e.target.value)}
                placeholder="Document reference title"
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.webp"
              onChange={(e) => setDocFile(e.target.files?.[0] || null)}
              className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-300"
            />
            <button
              type="submit"
              disabled={uploading}
              className="w-full py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold disabled:opacity-50"
            >
              {uploading ? 'Uploading to Private Vault...' : 'Upload Verification Document'}
            </button>

            <div className="space-y-1.5 max-h-40 overflow-y-auto pt-2 border-t border-slate-800">
              {(data?.documents || []).map((doc: any) => (
                <div key={doc.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-semibold text-white truncate flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{doc.title}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {doc.doc_type} · {doc.review_status} · {(doc.file_size / 1024).toFixed(1)} KB
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDownloadDocument(doc.id, doc.original_filename)}
                    className="px-2.5 py-1 rounded bg-slate-950 border border-slate-700 text-cyan-300 font-semibold flex items-center gap-1 shrink-0"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </button>
                </div>
              ))}
              {(!data?.documents || data.documents.length === 0) && (
                <div className="text-slate-500 text-center py-2">No identity verification documents uploaded yet.</div>
              )}
            </div>
          </form>
        </div>

        {/* Right Column: TOTP MFA & Password Management + Sessions */}
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-bold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400" />
                <span>Two-Factor Authentication (TOTP) &amp; Recovery Codes</span>
              </div>
              <span className="font-mono text-[11px] text-slate-400 tabular-nums">
                Codes left: {mfa?.remainingRecoveryCodes ?? 0}
              </span>
            </div>

            {acc?.subject_type === 'founder' && (
              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-800/60 text-emerald-200 text-[11px]">
                Primary Owner 2FA secret is permanently protected and locked. Existing configuration cannot be overwritten or disabled.
              </div>
            )}

            {!mfa?.totpEnabled ? (
              <div className="space-y-2.5">
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={mfaPassword}
                    onChange={(e) => setMfaPassword(e.target.value)}
                    placeholder="Current password to start MFA enrollment"
                    className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const res = await api.enrollMfaTotp(mfaPassword);
                        setPendingSecret({ secret: res.secret, otpAuthUri: res.otpAuthUri });
                        flash(res.message);
                      } catch (err: any) {
                        flash(err?.message || 'Unable to start MFA enrollment.', false);
                      }
                    }}
                    className="px-3.5 py-2 rounded-lg bg-amber-500 text-slate-950 font-bold"
                  >
                    Enroll TOTP
                  </button>
                </div>

                {pendingSecret && (
                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-700 space-y-2">
                    <div className="text-slate-300 font-semibold">Authenticator Setup Key</div>
                    <div className="font-mono text-xs text-emerald-300 break-all">{pendingSecret.secret}</div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={6}
                        value={mfaConfirmCode}
                        onChange={(e) => setMfaConfirmCode(e.target.value)}
                        placeholder="Enter 6-digit TOTP code"
                        className="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-3 py-2 text-white font-mono"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            const res = await api.confirmMfaTotp(mfaConfirmCode.trim());
                            setFreshRecoveryCodes(res.recoveryCodes);
                            setPendingSecret(null);
                            setMfaPassword('');
                            setMfaConfirmCode('');
                            flash(res.message);
                            await loadSecurityProfile();
                          } catch (err: any) {
                            flash(err?.message || 'TOTP verification failed.', false);
                          }
                        }}
                        className="px-3.5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold"
                      >
                        Activate 2FA
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                <div className="text-slate-300">
                  Re-authenticate with your current password and 6-digit TOTP code to regenerate recovery codes{mfa?.mfaRequired ? ' (MFA mandatory for this role)' : ' or disable MFA'}.
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="password"
                    value={disableMfaForm.password}
                    onChange={(e) => setDisableMfaForm({ ...disableMfaForm, password: e.target.value })}
                    placeholder="Current Password"
                    className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                  />
                  <input
                    type="text"
                    maxLength={6}
                    value={disableMfaForm.code}
                    onChange={(e) => setDisableMfaForm({ ...disableMfaForm, code: e.target.value })}
                    placeholder="6-Digit TOTP Code"
                    className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      try {
                        const res = await api.regenerateMfaRecoveryCodes({
                          currentPassword: disableMfaForm.password,
                          code: disableMfaForm.code.trim(),
                        });
                        setFreshRecoveryCodes(res.recoveryCodes);
                        setDisableMfaForm({ password: '', code: '' });
                        flash(res.message);
                        await loadSecurityProfile();
                      } catch (err: any) {
                        flash(err?.message || 'Unable to regenerate recovery codes.', false);
                      }
                    }}
                    className="px-3.5 py-2 rounded-lg bg-cyan-500 text-slate-950 font-bold"
                  >
                    Regenerate Recovery Codes
                  </button>
                  {!mfa?.mfaRequired && (
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await api.disableMfaTotp({
                            currentPassword: disableMfaForm.password,
                            code: disableMfaForm.code.trim(),
                          });
                          setDisableMfaForm({ password: '', code: '' });
                          flash(res.message);
                          await loadSecurityProfile();
                        } catch (err: any) {
                          flash(err?.message || 'Unable to disable MFA.', false);
                        }
                      }}
                      className="px-3.5 py-2 rounded-lg bg-rose-950 border border-rose-800 text-rose-200 font-bold"
                    >
                      Disable MFA
                    </button>
                  )}
                </div>
              </div>
            )}

            {freshRecoveryCodes && (
              <div className="p-3 rounded-lg bg-amber-950/30 border border-amber-700/50 space-y-1.5">
                <div className="font-bold text-amber-200">Save Single-Use Recovery Codes (Shown Once)</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 font-mono text-[11px] text-amber-100">
                  {freshRecoveryCodes.map((c) => (
                    <div key={c} className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-center">
                      {c}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Unified Change Password */}
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                const res = await api.changeUnifiedPassword(pwForm);
                flash(res.message);
                setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '', revokeOtherSessions: true });
                await loadSecurityProfile();
              } catch (err: any) {
                flash(err?.message || 'Password update failed.', false);
              }
            }}
            className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5"
          >
            <div className="font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-cyan-400" />
              <span>Change Account Password</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="password"
                required
                value={pwForm.currentPassword}
                onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
                placeholder="Current Password"
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="password"
                required
                value={pwForm.newPassword}
                onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
                placeholder="New Strong Password"
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
              />
              <input
                type="password"
                required
                value={pwForm.confirmPassword}
                onChange={(e) => setPwForm({ ...pwForm, confirmPassword: e.target.value })}
                placeholder="Confirm Password"
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
              />
            </div>
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-slate-300">
                <input
                  type="checkbox"
                  checked={pwForm.revokeOtherSessions}
                  onChange={(e) => setPwForm({ ...pwForm, revokeOtherSessions: e.target.checked })}
                />
                <span>Revoke other device sessions</span>
              </label>
              <button type="submit" className="px-4 py-2 rounded-lg bg-cyan-500 text-slate-950 font-bold">
                Update Password
              </button>
            </div>
          </form>

          {/* Active Sessions & Login Activity */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="font-bold text-white flex items-center gap-2">
              <Monitor className="w-4 h-4 text-emerald-400" />
              <span>Active Sessions ({data?.sessions?.length || 0})</span>
            </div>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {(data?.sessions || []).map((s: any) => (
                <div key={s.id} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-semibold text-white">
                      {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}
                    </div>
                    <div className="font-mono text-[10px] text-slate-400 tabular-nums">
                      IP {s.ip_address} · Idle Exp {s.idle_expires_at?.slice(0, 16) || s.expires_at?.slice(0, 16)}
                    </div>
                  </div>
                  {!s.is_current && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.revokeUnifiedSession(s.id);
                        await loadSecurityProfile();
                      }}
                      className="px-2 py-1 rounded bg-rose-950 border border-rose-800 text-rose-300 flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Revoke</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
