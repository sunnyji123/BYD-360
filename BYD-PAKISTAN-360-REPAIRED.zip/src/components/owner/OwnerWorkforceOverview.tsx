import React, { useState } from 'react';
import { Users, Store, Eye, X, Search, ShieldCheck } from 'lucide-react';
import { api } from '../../services/api';

interface OwnerWorkforceOverviewProps {
  mode: 'employees' | 'dealerships';
  data: {
    employeesOverview: { summary: any; byCountry: any[]; byDepartment: any[]; employees: any[] };
    dealershipsOverview: { summary: any; byCountry: any[]; dealerships: any[] };
  } | null;
  loading?: boolean;
}

function fmtMoney(val: number): string {
  return `₨ ${Math.round(val || 0).toLocaleString()}`;
}

export const OwnerWorkforceOverview: React.FC<OwnerWorkforceOverviewProps> = ({ mode, data, loading }) => {
  const [search, setSearch] = useState('');
  const [countryFilter, setCountryFilter] = useState('ALL');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [empDetail, setEmpDetail] = useState<any>(null);
  const [dlrDetail, setDlrDetail] = useState<any>(null);
  const [modalLoading, setModalLoading] = useState(false);

  const inspectEmployee = async (id: string) => {
    setModalLoading(true);
    try {
      const res = await api.getOwnerEmployeeDetail(id);
      setEmpDetail(res);
    } finally {
      setModalLoading(false);
    }
  };

  const inspectDealership = async (id: string) => {
    setModalLoading(true);
    try {
      const res = await api.getOwnerDealershipDetail(id);
      setDlrDetail(res);
    } finally {
      setModalLoading(false);
    }
  };

  if (loading && !data) {
    return (
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-8 text-center text-xs text-slate-400">
        Loading verified {mode} records...
      </div>
    );
  }

  if (mode === 'employees') {
    const eo = data?.employeesOverview;
    const s = eo?.summary || {};
    const employees = (eo?.employees || []).filter((e) => {
      if (countryFilter !== 'ALL' && e.countryCode !== countryFilter) return false;
      if (deptFilter !== 'ALL' && e.department !== deptFilter) return false;
      if (search) {
        const hay = `${e.employeeCode} ${e.fullName} ${e.email} ${e.jobPosition} ${e.department} ${e.branchName}`.toLowerCase();
        if (!hay.includes(search.toLowerCase())) return false;
      }
      return true;
    });

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">Total Employees</div>
            <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{s.total ?? 0}</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">Active Workforce</div>
            <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums mt-1">{s.active ?? 0}</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">Inactive / Suspended</div>
            <div className="text-2xl font-black text-rose-400 font-mono tabular-nums mt-1">{s.inactive ?? 0}</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">New Registrations (30d)</div>
            <div className="text-2xl font-black text-cyan-300 font-mono tabular-nums mt-1">{s.newRegistrations30d ?? 0}</div>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
            <div className="text-[11px] text-slate-400">Global Avg Performance</div>
            <div className="text-2xl font-black text-amber-300 font-mono tabular-nums mt-1">{s.avgPerformanceScore ?? 0}%</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h4 className="text-sm font-bold text-white">Country-Wise Workforce Distribution</h4>
            {(eo?.byCountry || []).map((c: any) => (
              <div key={c.countryCode} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-white">{c.countryCode}</span>
                  <span className="text-slate-400 ml-2">{c.active}/{c.total} Active</span>
                </div>
                <span className="font-mono font-bold text-cyan-300">Avg KPI {c.avgScore}%</span>
              </div>
            ))}
          </div>
          <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
            <h4 className="text-sm font-bold text-white">Department-Wise Breakdown</h4>
            {(eo?.byDepartment || []).map((d: any) => (
              <div key={d.department} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-white">{d.department}</span>
                  <span className="text-slate-400 ml-2">{d.active}/{d.total} Active</span>
                </div>
                <span className="font-mono font-bold text-amber-300">Avg KPI {d.avgScore}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-400" />
              <span>Employee Directory &amp; Founder Inspection ({employees.length})</span>
            </h4>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search ID, name, role..."
                  className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white w-52"
                />
              </div>
              <select
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
              >
                <option value="ALL">All Countries</option>
                {(eo?.byCountry || []).map((c: any) => (
                  <option key={c.countryCode} value={c.countryCode}>{c.countryCode}</option>
                ))}
              </select>
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
              >
                <option value="ALL">All Departments</option>
                {(eo?.byDepartment || []).map((d: any) => (
                  <option key={d.department} value={d.department}>{d.department}</option>
                ))}
              </select>
            </div>
          </div>

          {employees.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">No Data Available</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Emp ID</th>
                    <th className="py-2.5 px-3">Employee</th>
                    <th className="py-2.5 px-3">Position &amp; Dept</th>
                    <th className="py-2.5 px-3">Country / Branch</th>
                    <th className="py-2.5 px-3">Manager</th>
                    <th className="py-2.5 px-3 text-right">KPI Score</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Inspect</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {employees.map((e) => (
                    <tr key={e.id} className="hover:bg-slate-800/30">
                      <td className="py-2 px-3 font-mono text-amber-300 font-bold">{e.employeeCode}</td>
                      <td className="py-2 px-3">
                        <div className="font-semibold text-white">{e.fullName}</div>
                        <div className="text-[11px] font-mono text-slate-400">{e.email}</div>
                      </td>
                      <td className="py-2 px-3">
                        <div className="text-slate-200">{e.jobPosition}</div>
                        <div className="text-[10px] text-slate-400">{e.department}</div>
                      </td>
                      <td className="py-2 px-3">
                        <div className="font-mono text-cyan-300">{e.countryCode}</div>
                        <div className="text-[10px] text-slate-400">{e.branchName}</div>
                      </td>
                      <td className="py-2 px-3 text-slate-300">{e.reportingManagerName}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-emerald-400 tabular-nums">{e.performanceScore}%</td>
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${e.status === 'Active' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                          {e.status}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <button
                          type="button"
                          onClick={() => inspectEmployee(e.id)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold inline-flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" /> Profile
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {(empDetail || (modalLoading && !dlrDetail)) && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h4 className="text-sm font-black text-white">Founder Employee Inspection (Audit Logged)</h4>
                <button type="button" onClick={() => setEmpDetail(null)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
              {modalLoading ? (
                <div className="py-8 text-center text-xs text-slate-400">Loading employee HR &amp; payroll telemetry...</div>
              ) : (
                <div className="space-y-4 text-xs">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
                    <div><span className="text-slate-500">Full Name:</span> <strong className="text-white">{empDetail.employee?.full_name}</strong></div>
                    <div><span className="text-slate-500">Employee ID:</span> <span className="font-mono text-amber-300">{empDetail.employee?.employee_code}</span></div>
                    <div><span className="text-slate-500">Department:</span> <span className="text-white">{empDetail.employee?.department}</span></div>
                    <div><span className="text-slate-500">Position:</span> <span className="text-white">{empDetail.employee?.job_position}</span></div>
                    <div><span className="text-slate-500">Performance:</span> <span className="font-mono text-emerald-400 font-bold">{empDetail.employee?.performance_score}%</span></div>
                    <div><span className="text-slate-500">2FA Verified:</span> <span className="text-cyan-300">{empDetail.employee?.two_factor_enabled ? 'Enabled' : 'Disabled'}</span></div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Authorized Payroll History ({empDetail.salaryHistory?.length || 0})</div>
                    {(empDetail.salaryHistory || []).slice(0, 6).map((sal: any) => (
                      <div key={sal.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                        <span className="font-mono text-white">{sal.pay_period}</span>
                        <span className="font-mono text-emerald-400 font-bold">{sal.currency} {Number(sal.net_salary).toLocaleString()}</span>
                        <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px]">{sal.payment_status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // DEALERSHIPS OVERVIEW
  const doObj = data?.dealershipsOverview;
  const ds = doObj?.summary || {};
  const dealerships = (doObj?.dealerships || []).filter((d) => {
    if (countryFilter !== 'ALL' && d.countryCode !== countryFilter) return false;
    if (search) {
      const hay = `${d.dealerCode} ${d.name} ${d.city} ${d.managerName} ${d.countryCode}`.toLowerCase();
      if (!hay.includes(search.toLowerCase())) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Total Dealerships</div>
          <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">{ds.total ?? 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Active Approved</div>
          <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums mt-1">{ds.active ?? 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Pending / Inactive</div>
          <div className="text-2xl font-black text-amber-300 font-mono tabular-nums mt-1">
            {(ds.pendingApproval ?? 0) + (ds.inactive ?? 0)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Units Achieved / Target</div>
          <div className="text-2xl font-black text-cyan-300 font-mono tabular-nums mt-1">
            {ds.totalAchievedUnits ?? 0} / {ds.totalTargetUnits ?? 0}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Verified Sales Revenue</div>
          <div className="text-xl font-black text-emerald-400 font-mono tabular-nums mt-1">
            {fmtMoney(ds.totalVerifiedSalesRevenue || 0)}
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Store className="w-4 h-4 text-cyan-400" />
            <span>Dealership Sales, Targets &amp; Performance Comparison ({dealerships.length})</span>
          </h4>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search dealer, city, manager..."
                className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white w-56"
              />
            </div>
            <select
              value={countryFilter}
              onChange={(e) => setCountryFilter(e.target.value)}
              className="rounded-xl bg-slate-950 border border-slate-800 px-3 py-1.5 text-white"
            >
              <option value="ALL">All Countries</option>
              {(doObj?.byCountry || []).map((c: any) => (
                <option key={c.countryCode} value={c.countryCode}>{c.countryCode}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Dealership</th>
                <th className="py-2.5 px-3">Country / City</th>
                <th className="py-2.5 px-3 text-right">Target / Achieved</th>
                <th className="py-2.5 px-3 text-right">Verified Sales</th>
                <th className="py-2.5 px-3 text-right">Reported Rev.</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {dealerships.map((d) => (
                <tr key={d.id} className="hover:bg-slate-800/30">
                  <td className="py-2 px-3">
                    <div className="font-bold text-white">{d.name}</div>
                    <div className="text-[10px] font-mono text-slate-400">{d.dealerCode} • {d.managerName}</div>
                  </td>
                  <td className="py-2 px-3 font-mono text-slate-200">{d.countryCode} • {d.city}</td>
                  <td className="py-2 px-3 text-right font-mono tabular-nums text-cyan-300">
                    {d.achievedUnits}/{d.monthlyTargetUnits} ({d.targetAttainmentPct}%)
                  </td>
                  <td className="py-2 px-3 text-right font-mono tabular-nums text-emerald-400 font-bold">
                    {fmtMoney(d.verifiedSalesRevenue)} ({d.verifiedSalesCount})
                  </td>
                  <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-300">
                    {fmtMoney(d.monthlyReportedRevenue)}
                  </td>
                  <td className="py-2 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${d.status === 'Approved' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'}`}>
                      {d.status}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-right">
                    <button
                      type="button"
                      onClick={() => inspectDealership(d.id)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold inline-flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" /> Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {(dlrDetail || (modalLoading && !empDetail)) && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Dealership Operations &amp; Ledger Inspection</span>
              </h4>
              <button type="button" onClick={() => setDlrDetail(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            {modalLoading ? (
              <div className="py-8 text-center text-xs text-slate-400">Loading dealership data...</div>
            ) : (
              <div className="space-y-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-2">
                  <div><span className="text-slate-500">Dealership:</span> <strong className="text-white">{dlrDetail.dealership?.name}</strong></div>
                  <div><span className="text-slate-500">Code:</span> <span className="font-mono text-amber-300">{dlrDetail.dealerAccount?.dealer_code || dlrDetail.dealership?.code}</span></div>
                  <div><span className="text-slate-500">Sales Logged:</span> <span className="font-mono text-emerald-400 font-bold">{dlrDetail.sales?.length || 0}</span></div>
                  <div><span className="text-slate-500">Assigned Fleet:</span> <span className="font-mono text-cyan-300">{dlrDetail.vehicles?.length || 0} Vehicles</span></div>
                </div>
                {(dlrDetail.commissions || []).length > 0 && (
                  <div className="space-y-1.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Dealer Commissions</div>
                    {dlrDetail.commissions.map((c: any) => (
                      <div key={c.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                        <span className="font-mono text-white">{c.sale_id}</span>
                        <span className="font-mono text-amber-300 font-bold">{fmtMoney(c.commission_amount_pkr)} ({c.commission_rate_pct}%)</span>
                        <span className="text-emerald-300 font-bold">{c.status}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
