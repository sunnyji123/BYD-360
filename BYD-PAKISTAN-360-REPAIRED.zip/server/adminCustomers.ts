import express, { Request, Response, NextFunction } from 'express';
import {
  sqlite,
  generateSecureToken,
  generateNumericOtp,
  logCustomerActivity,
  logOwnerAudit,
  nowIso,
} from './db';
import { getClientIp } from './auth';

export type AdminCustomerScope =
  | 'founder'
  | 'super_admin'
  | 'company_admin'
  | 'country_manager'
  | 'branch_manager';

interface ScopeFilterResult {
  sql: string;
  params: any[];
}

function buildScopeFilter(scope: AdminCustomerScope, req: Request, alias = 'c'): ScopeFilterResult {
  const prefix = alias ? `${alias}.` : '';
  if (scope === 'founder' || scope === 'super_admin') {
    return { sql: '1=1', params: [] };
  }
  if (scope === 'company_admin') {
    return { sql: `${prefix}company_id = ?`, params: [req.auth!.companyId] };
  }
  if (scope === 'country_manager') {
    return { sql: `${prefix}country_id = ?`, params: [req.auth!.country] };
  }
  if (scope === 'branch_manager') {
    return {
      sql: `${prefix}company_id = ? AND (${prefix}branch_id = ? OR LOWER(${prefix}city) = LOWER(?))`,
      params: [req.auth!.companyId, req.auth!.branchId, req.auth!.city || 'Karachi'],
    };
  }
  return { sql: '1=0', params: [] };
}

function assertCustomerInScope(scope: AdminCustomerScope, req: Request, customerId: string): any | null {
  const sf = buildScopeFilter(scope, req, 'c');
  return sqlite
    .prepare(`SELECT c.* FROM customer_accounts c WHERE c.id = ? AND (${sf.sql})`)
    .get(customerId, ...sf.params) as any;
}

export function createAdminCustomersRouter(config: {
  scope: AdminCustomerScope;
  middlewares: Array<(req: Request, res: Response, next: NextFunction) => void>;
}) {
  const router = express.Router();
  for (const mw of config.middlewares) {
    router.use(mw);
  }

  // 1. Overview & Customer Directory
  router.get('/', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'c');
    const q = String(req.query.q || '').trim().toLowerCase();
    const statusFilter = String(req.query.status || '').trim();
    const verificationFilter = String(req.query.verification || '').trim();

    const rows = sqlite
      .prepare(`
        SELECT c.id, c.customer_code, c.company_id, c.country_id, c.branch_id, c.full_name, c.email, c.mobile,
               c.role, c.account_type, c.country, c.city, c.address, c.verification_status, c.status,
               c.email_verified, c.mobile_verified, c.last_login_at, c.deletion_requested_at, c.created_at,
               comp.name as company_name,
               (SELECT COUNT(*) FROM customer_vehicles cv WHERE cv.customer_id = c.id) as vehicle_count,
               (SELECT COUNT(*) FROM customer_inquiries ci WHERE ci.customer_id = c.id) as inquiry_count,
               (SELECT COUNT(*) FROM customer_test_drive_requests td WHERE td.customer_id = c.id) as test_drive_count,
               (SELECT COUNT(*) FROM customer_bookings cb WHERE cb.customer_id = c.id) as booking_count,
               (SELECT COUNT(*) FROM customer_support_tickets st WHERE st.customer_id = c.id AND st.status IN ('Open','In Progress')) as open_tickets_count
        FROM customer_accounts c
        LEFT JOIN companies comp ON c.company_id = comp.id
        WHERE (${sf.sql})
        ORDER BY c.created_at DESC
      `)
      .all(...sf.params) as any[];

    const customers = rows.filter((r) => {
      if (statusFilter && statusFilter !== 'All' && r.status !== statusFilter) return false;
      if (verificationFilter && verificationFilter !== 'All' && r.verification_status !== verificationFilter) return false;
      if (q) {
        const hay = `${r.full_name} ${r.email} ${r.customer_code} ${r.mobile} ${r.city} ${r.country}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const sfTable = buildScopeFilter(config.scope, req, 'x');
    const inquiries = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_inquiries x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const testDrives = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_test_drive_requests x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const bookings = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_bookings x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const payments = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_payments x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const serviceRequests = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_service_requests x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const warrantyClaims = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_warranty_claims x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);
    const supportTickets = sqlite
      .prepare(`SELECT x.*, c.full_name as customer_name, c.customer_code FROM customer_support_tickets x JOIN customer_accounts c ON x.customer_id = c.id WHERE (${sfTable.sql}) ORDER BY x.created_at DESC LIMIT 60`)
      .all(...sfTable.params);

    const summary = {
      totalCustomers: rows.length,
      verifiedCustomers: rows.filter((r) => r.verification_status === 'Verified').length,
      activeCustomers: rows.filter((r) => r.status === 'Active').length,
      suspendedCustomers: rows.filter((r) => r.status === 'Suspended').length,
      pendingBookings: (bookings as any[]).filter((b) => b.booking_status === 'Pending Review').length,
      pendingTestDrives: (testDrives as any[]).filter((t) => t.status === 'Pending Showroom Confirmation').length,
      openTickets: (supportTickets as any[]).filter((t) => t.status === 'Open' || t.status === 'In Progress').length,
      pendingWarrantyClaims: (warrantyClaims as any[]).filter((w) => w.status === 'Submitted' || w.status === 'Technical Review').length,
    };

    res.json({
      scope: config.scope,
      summary,
      customers,
      inquiries,
      testDrives,
      bookings,
      payments,
      serviceRequests,
      warrantyClaims,
      supportTickets,
    });
  });

  // 2. Audit / Customer Activity Logs
  router.get('/audit-logs', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'l');
    const logs = sqlite
      .prepare(`SELECT l.*, c.customer_code, c.full_name as customer_name FROM customer_activity_logs l LEFT JOIN customer_accounts c ON l.customer_id = c.id WHERE (${sf.sql}) ORDER BY l.created_at DESC LIMIT 100`)
      .all(...sf.params);
    res.json({ logs });
  });

  // 3. Single Customer Detailed Inspection
  router.get('/:id', (req: Request, res: Response) => {
    const cust = assertCustomerInScope(config.scope, req, req.params.id);
    if (!cust) {
      res.status(404).json({ error: 'Customer account not found in your scope.' });
      return;
    }
    const profile = sqlite.prepare('SELECT * FROM customer_profiles WHERE customer_id = ?').get(cust.id);
    const vehicles = sqlite.prepare('SELECT * FROM customer_vehicles WHERE customer_id = ?').all(cust.id);
    const bookings = sqlite.prepare('SELECT * FROM customer_bookings WHERE customer_id = ? ORDER BY created_at DESC').all(cust.id);
    const invoices = sqlite.prepare('SELECT * FROM customer_invoices WHERE customer_id = ? ORDER BY created_at DESC').all(cust.id);
    const payments = sqlite.prepare('SELECT * FROM customer_payments WHERE customer_id = ? ORDER BY created_at DESC').all(cust.id);
    const documents = sqlite.prepare('SELECT id, doc_category, doc_title, file_name, mime_type, file_size, verification_status, created_at FROM customer_booking_documents WHERE customer_id = ? ORDER BY created_at DESC').all(cust.id);
    const activity = sqlite.prepare('SELECT * FROM customer_activity_logs WHERE customer_id = ? ORDER BY created_at DESC LIMIT 40').all(cust.id);
    res.json({ customer: cust, profile, vehicles, bookings, invoices, payments, documents, activity });
  });

  // 4. Verify Customer Account
  router.patch('/:id/verify', (req: Request, res: Response) => {
    const cust = assertCustomerInScope(config.scope, req, req.params.id);
    if (!cust) {
      res.status(404).json({ error: 'Customer account not found in your scope.' });
      return;
    }
    const now = nowIso();
    sqlite
      .prepare(`
        UPDATE customer_accounts
        SET verification_status = 'Verified',
            status = CASE WHEN status = 'Pending Verification' THEN 'Active' ELSE status END,
            email_verified = 1,
            verified_by = ?,
            verified_at = ?,
            updated_at = ?
        WHERE id = ?
      `)
      .run(req.auth!.fullName, now, now, cust.id);

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Announcement', 'Customer Account Verified', 'Your BYD PAKISTAN 360 customer profile has been officially verified.', 'High', 'profile', 0, ?)
      `)
      .run(`cnot_${generateSecureToken(6)}`, cust.id, cust.company_id, cust.country_id, now);

    logCustomerActivity({
      customerId: cust.id,
      companyId: cust.company_id,
      countryId: cust.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'CUSTOMER_VERIFIED_BY_ADMIN',
      module: 'Customer Governance',
      targetId: cust.customer_code,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, verificationStatus: 'Verified' });
  });

  // 5. Suspend or Reactivate Customer Account (revokes active customer sessions)
  router.patch('/:id/status', (req: Request, res: Response) => {
    const cust = assertCustomerInScope(config.scope, req, req.params.id);
    if (!cust) {
      res.status(404).json({ error: 'Customer account not found in your scope.' });
      return;
    }
    const nextStatus = String(req.body.status || '').trim();
    if (!['Active', 'Suspended'].includes(nextStatus)) {
      res.status(400).json({ error: 'Status must be Active or Suspended.' });
      return;
    }

    const now = nowIso();
    sqlite
      .prepare(`
        UPDATE customer_accounts
        SET status = ?,
            verification_status = CASE WHEN ? = 'Suspended' THEN 'Suspended' WHEN verification_status = 'Suspended' THEN 'Verified' ELSE verification_status END,
            updated_at = ?
        WHERE id = ?
      `)
      .run(nextStatus, nextStatus, now, cust.id);

    if (nextStatus === 'Suspended') {
      sqlite.prepare("UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ? AND subject_type = 'customer'").run(cust.id);
      sqlite.prepare('UPDATE customer_sessions SET revoked = 1 WHERE customer_id = ?').run(cust.id);
    }

    logCustomerActivity({
      customerId: cust.id,
      companyId: cust.company_id,
      countryId: cust.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: nextStatus === 'Suspended' ? 'CUSTOMER_SUSPENDED' : 'CUSTOMER_REACTIVATED',
      module: 'Customer Governance',
      targetId: cust.customer_code,
      details: String(req.body.reason || ''),
      ipAddress: getClientIp(req),
      status: nextStatus === 'Suspended' ? 'WARNING' : 'SUCCESS',
    });

    logOwnerAudit({
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: nextStatus === 'Suspended' ? 'CUSTOMER_SUSPENDED' : 'CUSTOMER_REACTIVATED',
      module: 'Customer Governance',
      targetId: `${cust.email} (${cust.customer_code})`,
      companyId: cust.company_id,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status: nextStatus });
  });

  // 6. Review Customer Inquiries & Assign to Dealers/Staff
  router.patch('/inquiries/:inqId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'i');
    const inq = sqlite
      .prepare(`SELECT i.* FROM customer_inquiries i WHERE i.id = ? AND (${sf.sql})`)
      .get(req.params.inqId, ...sf.params) as any;
    if (!inq) {
      res.status(404).json({ error: 'Customer inquiry not found in your scope.' });
      return;
    }

    const status = req.body.status ? String(req.body.status).trim() : inq.status;
    const assignedToName = req.body.assignedToName !== undefined ? String(req.body.assignedToName).trim() : inq.assigned_to_name;
    const replyText = req.body.replyText !== undefined ? String(req.body.replyText).trim() : inq.reply_text;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE customer_inquiries
        SET status = ?, assigned_to_name = ?, reply_text = ?,
            replied_by = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE replied_by END,
            replied_at = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE replied_at END,
            updated_at = ?
        WHERE id = ?
      `)
      .run(status, assignedToName, replyText, replyText, replyText, req.auth!.fullName, replyText, replyText, now, now, inq.id);

    if (replyText) {
      sqlite
        .prepare(`
          INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
          VALUES (?, ?, ?, ?, 'Announcement', ?, ?, 'Normal', 'inquiries', 0, ?)
        `)
        .run(
          `cnot_${generateSecureToken(6)}`,
          inq.customer_id,
          inq.company_id,
          inq.country_id,
          `Reply on Inquiry ${inq.inquiry_ref}`,
          replyText.slice(0, 220),
          now
        );
    }

    logCustomerActivity({
      customerId: inq.customer_id,
      companyId: inq.company_id,
      countryId: inq.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'INQUIRY_REVIEWED',
      module: 'Customer Inquiries',
      targetId: inq.inquiry_ref,
      details: `Status: ${status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status });
  });

  // 7. Confirm / Update Test Drive Requests
  router.patch('/test-drives/:tdId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'td');
    const td = sqlite
      .prepare(`SELECT td.* FROM customer_test_drive_requests td WHERE td.id = ? AND (${sf.sql})`)
      .get(req.params.tdId, ...sf.params) as any;
    if (!td) {
      res.status(404).json({ error: 'Test drive request not found in your scope.' });
      return;
    }

    const status = String(req.body.status || 'Confirmed').trim();
    const assignedStaffName = req.body.assignedStaffName !== undefined ? String(req.body.assignedStaffName).trim() : td.assigned_staff_name || req.auth!.fullName;
    const showroomNotes = req.body.showroomNotes !== undefined ? String(req.body.showroomNotes).trim() : td.showroom_notes;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE customer_test_drive_requests
        SET status = ?, assigned_staff_name = ?, showroom_notes = ?,
            confirmed_by = CASE WHEN ? = 'Confirmed' THEN ? ELSE confirmed_by END,
            confirmed_at = CASE WHEN ? = 'Confirmed' THEN ? ELSE confirmed_at END,
            updated_at = ?
        WHERE id = ?
      `)
      .run(status, assignedStaffName, showroomNotes, status, req.auth!.fullName, status, now, now, td.id);

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Test Drive', ?, ?, 'High', 'test-drives', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        td.customer_id,
        td.company_id,
        td.country_id,
        `Test Drive ${td.request_number} — ${status}`,
        `Your test drive for ${td.vehicle_model} at ${td.dealership_name} (${td.preferred_date} ${td.preferred_time}) is now ${status}.`,
        now
      );

    logCustomerActivity({
      customerId: td.customer_id,
      companyId: td.company_id,
      countryId: td.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'TEST_DRIVE_STATUS_UPDATED',
      module: 'Test Drives',
      targetId: td.request_number,
      details: `Updated to ${status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status });
  });

  // 8. Approve Bookings, Verify Customer Payments & Track Delivery
  router.patch('/bookings/:bookingId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'b');
    const bk = sqlite
      .prepare(`SELECT b.* FROM customer_bookings b WHERE b.id = ? AND (${sf.sql})`)
      .get(req.params.bookingId, ...sf.params) as any;
    if (!bk) {
      res.status(404).json({ error: 'Customer booking not found in your scope.' });
      return;
    }

    const bookingStatus = req.body.bookingStatus ? String(req.body.bookingStatus).trim() : bk.booking_status;
    const paymentStatus = req.body.paymentStatus ? String(req.body.paymentStatus).trim() : bk.payment_status;
    const deliveryStatus = req.body.deliveryStatus ? String(req.body.deliveryStatus).trim() : bk.delivery_status;
    const adminNotes = req.body.adminNotes !== undefined ? String(req.body.adminNotes).trim() : bk.admin_notes;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE customer_bookings
        SET booking_status = ?, payment_status = ?, delivery_status = ?, admin_notes = ?,
            reviewed_by = ?, reviewed_at = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(bookingStatus, paymentStatus, deliveryStatus, adminNotes, req.auth!.fullName, now, now, bk.id);

    // Verify or record payment against invoice when admin confirms Deposit Verified / Fully Paid
    if (paymentStatus === 'Deposit Verified' || paymentStatus === 'Fully Paid') {
      const inv = sqlite.prepare('SELECT * FROM customer_invoices WHERE booking_id = ?').get(bk.id) as any;
      const existingPaid = (sqlite.prepare("SELECT COALESCE(SUM(amount_pkr), 0) as total FROM customer_payments WHERE booking_id = ? AND payment_status IN ('Verified', 'Paid')").get(bk.id) as any).total;
      const targetPaid = paymentStatus === 'Fully Paid' ? Number(bk.quoted_price_pkr || bk.booking_deposit_pkr) : Number(bk.booking_deposit_pkr || 1000000);
      const delta = Math.max(0, targetPaid - Number(existingPaid || 0));

      if (delta > 0) {
        sqlite
          .prepare(`
            INSERT INTO customer_payments (
              id, payment_ref, customer_id, booking_id, invoice_id, company_id, country_id, branch_id,
              currency, amount_pkr, amount_local, payment_method, gateway_name, transaction_ref,
              payment_status, payment_date, verified_by, verified_at, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PKR', ?, ?, ?, 'Verified Showroom Finance', ?, ?, ?, ?, ?, ?, ?)
          `)
          .run(
            `cpay_${generateSecureToken(6)}`,
            `PAY-CUS-${generateNumericOtp(5)}`,
            bk.customer_id,
            bk.id,
            inv?.id || null,
            bk.company_id,
            bk.country_id,
            bk.branch_id,
            delta,
            delta,
            String(req.body.paymentMethod || 'Verified Bank IBFT'),
            String(req.body.transactionRef || `FIN-VER-${generateNumericOtp(6)}`),
            paymentStatus === 'Fully Paid' ? 'Paid' : 'Verified',
            now.slice(0, 10),
            req.auth!.fullName,
            now,
            adminNotes || `Payment verified for booking ${bk.booking_ref}.`,
            now
          );
      }

      if (inv) {
        const totalPaidNow = (sqlite.prepare("SELECT COALESCE(SUM(amount_pkr), 0) as total FROM customer_payments WHERE booking_id = ? AND payment_status IN ('Verified', 'Paid')").get(bk.id) as any).total;
        const outstanding = Math.max(0, Number(inv.total_amount_pkr) - Number(totalPaidNow));
        const invStatus = outstanding <= 0 ? 'Paid' : totalPaidNow > 0 ? 'Partially Paid' : 'Issued';
        sqlite
          .prepare('UPDATE customer_invoices SET amount_paid_pkr = ?, outstanding_balance_pkr = ?, status = ?, updated_at = ? WHERE id = ?')
          .run(totalPaidNow, outstanding, invStatus, now, inv.id);
      }
    }

    // Reserve or complete inventory unit cleanly
    if (bk.inventory_id) {
      if (bookingStatus === 'Approved') {
        sqlite.prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Booked', booking_status = 'Booking Approved', updated_at = ? WHERE id = ?").run(now, bk.inventory_id);
      } else if (bookingStatus === 'Completed' || deliveryStatus === 'Delivered') {
        sqlite.prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Sold', booking_status = 'Completed', delivery_status = 'Delivered', updated_at = ? WHERE id = ?").run(now, bk.inventory_id);
      } else if (bookingStatus === 'Rejected' || bookingStatus === 'Cancelled') {
        sqlite.prepare("UPDATE dealer_vehicle_inventory SET availability_status = 'Available', booking_status = 'Unbooked', updated_at = ? WHERE id = ?").run(now, bk.inventory_id);
      }
    }

    // Provision owned vehicle + warranty if delivered/completed
    if (bookingStatus === 'Completed' || deliveryStatus === 'Delivered') {
      const invItem = sqlite.prepare('SELECT vin, model_year FROM dealer_vehicle_inventory WHERE id = ?').get(bk.inventory_id) as any;
      if (invItem?.vin) {
        const alreadyVeh = sqlite.prepare('SELECT id FROM customer_vehicles WHERE vin = ?').get(invItem.vin);
        if (!alreadyVeh) {
          const cvehId = `cveh_${generateSecureToken(6)}`;
          const warEndYear = Number(now.slice(0, 4)) + 8;
          const warExpiry = `${warEndYear}${now.slice(4, 10)}`;
          sqlite
            .prepare(`
              INSERT INTO customer_vehicles (
                id, customer_id, company_id, country_id, branch_id, dealership_id, dealership_name,
                vin, model, variant, color, model_year, license_plate, registration_date,
                battery_capacity_kwh, battery_health_soh, battery_health_soc,
                warranty_start_date, warranty_expiry_date, status, ownership_verified, created_at, updated_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'NEW-REG-2026', ?, 82.5, 100.0, 95.0, ?, ?, 'Active', 1, ?, ?)
            `)
            .run(
              cvehId,
              bk.customer_id,
              bk.company_id,
              bk.country_id,
              bk.branch_id,
              bk.dealer_id,
              bk.dealership_name,
              invItem.vin,
              bk.vehicle_model,
              bk.variant,
              bk.exterior_color,
              invItem.model_year || 2026,
              now.slice(0, 10),
              now.slice(0, 10),
              warExpiry,
              now,
              now
            );

          sqlite
            .prepare(`
              INSERT OR IGNORE INTO customer_warranty_records (
                id, warranty_number, customer_id, customer_vehicle_id, vin, model, company_id,
                start_date, expiry_date, terms_summary, status, created_at, updated_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Official manufacturer Blade Battery & vehicle warranty issued on handover.', 'Active', ?, ?)
            `)
            .run(`cwar_${generateSecureToken(6)}`, `WAR-BYD-${generateNumericOtp(5)}`, bk.customer_id, cvehId, invItem.vin, bk.vehicle_model, bk.company_id, now.slice(0, 10), warExpiry, now, now);
        }
      }
    }

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Booking', ?, ?, 'High', 'bookings', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        bk.customer_id,
        bk.company_id,
        bk.country_id,
        `Booking ${bk.booking_ref} Updated`,
        `Booking Status: ${bookingStatus} | Payment: ${paymentStatus} | Delivery: ${deliveryStatus}.`,
        now
      );

    logCustomerActivity({
      customerId: bk.customer_id,
      companyId: bk.company_id,
      countryId: bk.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'CUSTOMER_BOOKING_UPDATED',
      module: 'Vehicle Bookings',
      targetId: bk.booking_ref,
      details: `${bookingStatus} / ${paymentStatus} / ${deliveryStatus}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, bookingStatus, paymentStatus, deliveryStatus });
  });

  // 9. Manage Service Requests
  router.patch('/service-requests/:svcId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 's');
    const svc = sqlite
      .prepare(`SELECT s.* FROM customer_service_requests s WHERE s.id = ? AND (${sf.sql})`)
      .get(req.params.svcId, ...sf.params) as any;
    if (!svc) {
      res.status(404).json({ error: 'Service request not found in your scope.' });
      return;
    }

    const status = req.body.status ? String(req.body.status).trim() : svc.status;
    const technicianAssigned = req.body.technicianAssigned !== undefined ? String(req.body.technicianAssigned).trim() : svc.technician_assigned;
    const advisorNotes = req.body.advisorNotes !== undefined ? String(req.body.advisorNotes).trim() : svc.advisor_notes;
    const actualCostPkr = req.body.actualCostPkr !== undefined ? Number(req.body.actualCostPkr) : svc.actual_cost_pkr;
    const now = nowIso();

    sqlite
      .prepare('UPDATE customer_service_requests SET status = ?, technician_assigned = ?, advisor_notes = ?, actual_cost_pkr = ?, updated_at = ? WHERE id = ?')
      .run(status, technicianAssigned, advisorNotes, actualCostPkr, now, svc.id);

    if (status === 'Completed') {
      sqlite
        .prepare(`
          INSERT INTO customer_service_history (
            id, customer_id, customer_vehicle_id, service_request_id, vin, model, dealership_name,
            service_date, service_type, odometer_km, summary, technician_name, cost_pkr, next_reminder_date, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 10000, ?, ?, ?, ?, ?)
        `)
        .run(
          `chist_${generateSecureToken(6)}`,
          svc.customer_id,
          svc.customer_vehicle_id,
          svc.id,
          svc.vin,
          svc.model,
          svc.dealership_name,
          now.slice(0, 10),
          svc.service_type,
          advisorNotes || 'Scheduled maintenance completed and HV diagnostic checks passed.',
          technicianAssigned || 'BYD Certified HV Technician',
          actualCostPkr ?? svc.estimated_cost_pkr,
          new Date(Date.now() + 180 * 86400 * 1000).toISOString().slice(0, 10),
          now
        );
    }

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Service', ?, ?, 'Normal', 'service', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        svc.customer_id,
        svc.company_id,
        svc.country_id,
        `Service Request ${svc.request_number} — ${status}`,
        `${svc.service_type} for ${svc.model} is now ${status}.`,
        now
      );

    logCustomerActivity({
      customerId: svc.customer_id,
      companyId: svc.company_id,
      countryId: svc.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SERVICE_REQUEST_UPDATED',
      module: 'Service & Maintenance',
      targetId: svc.request_number,
      details: `Updated to ${status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status });
  });

  // 10. Review / Approve / Reject Warranty Claims
  router.patch('/warranty-claims/:claimId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 'w');
    const clm = sqlite
      .prepare(`SELECT w.* FROM customer_warranty_claims w WHERE w.id = ? AND (${sf.sql})`)
      .get(req.params.claimId, ...sf.params) as any;
    if (!clm) {
      res.status(404).json({ error: 'Warranty claim not found in your scope.' });
      return;
    }

    const status = String(req.body.status || 'Approved').trim();
    const approvedAmountPkr = req.body.approvedAmountPkr !== undefined ? Number(req.body.approvedAmountPkr) : clm.approved_amount_pkr;
    const reviewNotes = req.body.reviewNotes !== undefined ? String(req.body.reviewNotes).trim() : clm.review_notes;
    const now = nowIso();

    sqlite
      .prepare('UPDATE customer_warranty_claims SET status = ?, approved_amount_pkr = ?, review_notes = ?, reviewed_by = ?, reviewed_at = ?, updated_at = ? WHERE id = ?')
      .run(status, approvedAmountPkr, reviewNotes, req.auth!.fullName, now, now, clm.id);

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Warranty', ?, ?, 'High', 'warranty', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        clm.customer_id,
        clm.company_id,
        clm.country_id,
        `Warranty Claim ${clm.claim_number} — ${status}`,
        reviewNotes || `Your warranty claim for ${clm.vehicle_model} (${clm.component_category}) has been updated to ${status}.`,
        now
      );

    logCustomerActivity({
      customerId: clm.customer_id,
      companyId: clm.company_id,
      countryId: clm.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'WARRANTY_CLAIM_REVIEWED',
      module: 'Warranty Governance',
      targetId: clm.claim_number,
      details: `${status} (${reviewNotes || ''})`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status });
  });

  // 11. Respond to Support Tickets
  router.patch('/support-tickets/:ticketId', (req: Request, res: Response) => {
    const sf = buildScopeFilter(config.scope, req, 't');
    const tkt = sqlite
      .prepare(`SELECT t.* FROM customer_support_tickets t WHERE t.id = ? AND (${sf.sql})`)
      .get(req.params.ticketId, ...sf.params) as any;
    if (!tkt) {
      res.status(404).json({ error: 'Support ticket not found in your scope.' });
      return;
    }

    const status = req.body.status ? String(req.body.status).trim() : 'Resolved';
    const replyText = req.body.replyText !== undefined ? String(req.body.replyText).trim() : tkt.reply_text;
    const now = nowIso();

    sqlite
      .prepare('UPDATE customer_support_tickets SET status = ?, assigned_to_name = ?, reply_text = ?, replied_by = ?, replied_at = ?, updated_at = ? WHERE id = ?')
      .run(status, req.auth!.fullName, replyText, req.auth!.fullName, now, now, tkt.id);

    sqlite
      .prepare(`
        INSERT INTO customer_notifications (id, customer_id, company_id, country_id, category, title, message, priority, action_tab, is_read, created_at)
        VALUES (?, ?, ?, ?, 'Support', ?, ?, 'Normal', 'support', 0, ?)
      `)
      .run(
        `cnot_${generateSecureToken(6)}`,
        tkt.customer_id,
        tkt.company_id,
        tkt.country_id,
        `Support Ticket ${tkt.ticket_number} Updated`,
        replyText ? replyText.slice(0, 220) : `Ticket status changed to ${status}.`,
        now
      );

    logCustomerActivity({
      customerId: tkt.customer_id,
      companyId: tkt.company_id,
      countryId: tkt.country_id,
      actorId: req.auth!.userId,
      actorName: req.auth!.fullName,
      actorRole: req.auth!.role,
      action: 'SUPPORT_TICKET_RESPONDED',
      module: 'Customer Support',
      targetId: tkt.ticket_number,
      details: `Status: ${status}`,
      ipAddress: getClientIp(req),
    });

    res.json({ success: true, status });
  });

  return router;
}
