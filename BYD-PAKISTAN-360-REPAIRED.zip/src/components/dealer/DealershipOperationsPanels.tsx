import React, { useState, useEffect, useCallback } from 'react';
import {
  Building2,
  Car,
  Plus,
  Search,
  ArrowLeftRight,
  Receipt,
  CheckCircle2,
  XCircle,
  Download,
  RefreshCw,
  Clock,
  Truck,
  Ban,
} from 'lucide-react';
import { api } from '../../services/api';

interface PanelCommonProps {
  scope: any;
  dealersCatalog: any[];
  onRefreshParent?: () => void;
}

const fmtPkr = (n: number | string | undefined) =>
  `PKR ${Number(n || 0).toLocaleString('en-PK')}`;

const triggerBlobDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

// ============================================================================
// 1. SHOWROOMS PANEL (MULTI-SHOWROOM SUPPORT)
// ============================================================================
export const ShowroomsPanel: React.FC<PanelCommonProps> = ({ scope, dealersCatalog, onRefreshParent }) => {
  const [showrooms, setShowrooms] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [dealerFilter, setDealerFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [fDealerId, setFDealerId] = useState(scope?.selfOnly ? scope.selfDealerId : dealersCatalog[0]?.id || '');
  const [fName, setFName] = useState('');
  const [fAddress, setFAddress] = useState('');
  const [fCountry, setFCountry] = useState('PK');
  const [fProvince, setFProvince] = useState('Sindh');
  const [fCity, setFCity] = useState('Karachi');
  const [fPhone, setFPhone] = useState('');
  const [fEmail, setFEmail] = useState('');
  const [fOpenHours, setFOpenHours] = useState('09:00');
  const [fCloseHours, setFCloseHours] = useState('20:00');
  const [fManagerName, setFManagerName] = useState('');
  const [fManagerPhone, setFManagerPhone] = useState('');
  const [fManagerEmail, setFManagerEmail] = useState('');
  const [fStatus, setFStatus] = useState('Active');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.getDealershipShowrooms({
        dealerId: dealerFilter || undefined,
        status: statusFilter || undefined,
      });
      setShowrooms(res.showrooms || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load showrooms.');
    } finally {
      setLoading(false);
    }
  }, [dealerFilter, statusFilter]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!fDealerId && dealersCatalog[0]?.id) {
      setFDealerId(dealersCatalog[0].id);
    }
  }, [dealersCatalog, fDealerId]);

  const openCreate = () => {
    setEditing(null);
    setFName('');
    setFAddress('');
    setFPhone('');
    setFEmail('');
    setFManagerName('');
    setFManagerPhone('');
    setFManagerEmail('');
    setFStatus('Active');
    setShowForm(true);
  };

  const openEdit = (sh: any) => {
    setEditing(sh);
    setFDealerId(sh.dealer_id);
    setFName(sh.name || '');
    setFAddress(sh.address || '');
    setFCountry(sh.country || 'PK');
    setFProvince(sh.province || '');
    setFCity(sh.city || 'Karachi');
    setFPhone(sh.phone || '');
    setFEmail(sh.email || '');
    setFOpenHours(sh.opening_hours || '09:00');
    setFCloseHours(sh.closing_hours || '20:00');
    setFManagerName(sh.manager_name || '');
    setFManagerPhone(sh.manager_phone || '');
    setFManagerEmail(sh.manager_email || '');
    setFStatus(sh.status || 'Active');
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      if (editing) {
        await api.updateDealershipShowroom(editing.id, {
          name: fName,
          address: fAddress,
          country: fCountry,
          province: fProvince,
          city: fCity,
          phone: fPhone,
          email: fEmail,
          openingHours: fOpenHours,
          closingHours: fCloseHours,
          managerName: fManagerName,
          managerPhone: fManagerPhone,
          managerEmail: fManagerEmail,
          status: fStatus,
        });
        setNotice(`Updated showroom ${editing.showroom_code}.`);
      } else {
        const res = await api.createDealershipShowroom({
          dealerId: fDealerId,
          name: fName,
          address: fAddress,
          country: fCountry,
          province: fProvince,
          city: fCity,
          phone: fPhone,
          email: fEmail,
          openingHours: fOpenHours,
          closingHours: fCloseHours,
          managerName: fManagerName,
          managerPhone: fManagerPhone,
          managerEmail: fManagerEmail,
          status: fStatus,
        });
        setNotice(`Added showroom ${res.showroom?.showroom_code || ''}.`);
      }
      setShowForm(false);
      await load();
      onRefreshParent?.();
    } catch (err: any) {
      setError(err?.message || 'Unable to save showroom.');
    }
  };

  const filtered = showrooms.filter((s) =>
    `${s.showroom_code} ${s.name} ${s.dealer_name} ${s.city} ${s.manager_name} ${s.address}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-amber-400" />
            Showroom Network & Facility Locations
          </h3>
          <p className="text-xs text-slate-400">
            Manage multiple showrooms per dealer with verified managers, operating hours, and facility statuses.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scope?.canManageShowrooms && (
            <button
              type="button"
              onClick={openCreate}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> Add Showroom
            </button>
          )}
          <button
            type="button"
            onClick={load}
            className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white"
            title="Refresh Showrooms"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      {showForm && (
        <form onSubmit={handleSubmit} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-amber-300">
              {editing ? `Edit Showroom (${editing.showroom_code})` : 'Register New Dealer Showroom'}
            </span>
            <button type="button" onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white">
              Close
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {!scope?.selfOnly && (
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Dealer Ownership</label>
                <select
                  disabled={Boolean(editing)}
                  value={fDealerId}
                  onChange={(e) => setFDealerId(e.target.value)}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white"
                >
                  {dealersCatalog.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.dealerCode} — {d.businessName}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Showroom Name *</label>
              <input required value={fName} onChange={(e) => setFName(e.target.value)} placeholder="e.g. BYD Shahrah-e-Faisal 3S" className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Operational Status</label>
              <select value={fStatus} onChange={(e) => setFStatus(e.target.value)} className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <label className="text-[11px] text-slate-400 block mb-1">Street Address *</label>
              <input required value={fAddress} onChange={(e) => setFAddress(e.target.value)} placeholder="Full showroom street address" className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">City *</label>
              <input required value={fCity} onChange={(e) => setFCity(e.target.value)} className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Province / Region</label>
              <input value={fProvince} onChange={(e) => setFProvince(e.target.value)} className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Showroom Manager</label>
              <input value={fManagerName} onChange={(e) => setFManagerName(e.target.value)} placeholder="Manager Full Name" className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Showroom Phone</label>
              <input value={fPhone} onChange={(e) => setFPhone(e.target.value)} placeholder="+92 21 ..." className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Opening Hours</label>
              <input type="time" value={fOpenHours} onChange={(e) => setFOpenHours(e.target.value)} className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Closing Hours</label>
              <input type="time" value={fCloseHours} onChange={(e) => setFCloseHours(e.target.value)} className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">
              {editing ? 'Save Changes' : 'Create Showroom'}
            </button>
          </div>
        </form>
      )}

      <div className="flex flex-wrap items-center gap-2 text-xs">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search showroom code, name, city, manager..."
            className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white"
          />
        </div>
        {!scope?.selfOnly && (
          <select value={dealerFilter} onChange={(e) => setDealerFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
            <option value="">All Dealers</option>
            {dealersCatalog.map((d) => (
              <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
            ))}
          </select>
        )}
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
          <option value="">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Code</th>
              <th className="px-3 py-2.5">Showroom Name &amp; Address</th>
              <th className="px-3 py-2.5">Dealer</th>
              <th className="px-3 py-2.5">Manager &amp; Contact</th>
              <th className="px-3 py-2.5">Hours</th>
              <th className="px-3 py-2.5">Status</th>
              <th className="px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {filtered.map((sh) => (
              <tr key={sh.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5 font-mono text-amber-300 whitespace-nowrap">{sh.showroom_code}</td>
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{sh.name}</div>
                  <div className="text-[11px] text-slate-400">{sh.address}, {sh.city} {sh.province ? `(${sh.province})` : ''}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className="text-slate-200">{sh.dealer_name}</div>
                  <div className="font-mono text-[10px] text-slate-500">{sh.dealer_code}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className="text-slate-200">{sh.manager_name || 'Unassigned'}</div>
                  <div className="text-[11px] text-slate-400">{sh.phone}</div>
                </td>
                <td className="px-3 py-2.5 font-mono text-slate-300 whitespace-nowrap">
                  <Clock className="w-3 h-3 inline mr-1 text-slate-500" />
                  {sh.opening_hours}–{sh.closing_hours}
                </td>
                <td className="px-3 py-2.5">
                  <div className={sh.status === 'Active' ? 'text-emerald-400 font-semibold' : 'text-slate-400'}>
                    {sh.status}
                  </div>
                  <div className="text-[10px] text-slate-400">{sh.verification_status}</div>
                </td>
                <td className="px-3 py-2.5 text-right space-x-1.5 whitespace-nowrap">
                  {scope?.canManageShowrooms && (
                    <button
                      type="button"
                      onClick={() => openEdit(sh)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                    >
                      Edit
                    </button>
                  )}
                  {scope?.canVerifyDealers && sh.verification_status !== 'Verified' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.updateDealershipShowroom(sh.id, { verificationStatus: 'Verified', status: 'Active' });
                        setNotice(`Verified showroom ${sh.showroom_code}.`);
                        load();
                      }}
                      className="px-2.5 py-1 rounded bg-emerald-600/80 hover:bg-emerald-500 text-white font-semibold"
                    >
                      Verify
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                  No showrooms matched your filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================================================
// 2. DEALER VEHICLE INVENTORY & TRANSFERS PANEL
// ============================================================================
export const DealerInventoryPanel: React.FC<PanelCommonProps> = ({ scope, dealersCatalog, onRefreshParent }) => {
  const [inventory, setInventory] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [showrooms, setShowrooms] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState('');
  const [dealerFilter, setDealerFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [transferItem, setTransferItem] = useState<any | null>(null);
  const [transferToDealer, setTransferToDealer] = useState('');
  const [transferNotes, setTransferNotes] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [vDealerId, setVDealerId] = useState(scope?.selfOnly ? scope.selfDealerId : dealersCatalog[0]?.id || '');
  const [vShowroomId, setVShowroomId] = useState('');
  const [vModel, setVModel] = useState('BYD Sealion 6');
  const [vVariant, setVVariant] = useState('DM-i Super Hybrid AWD');
  const [vColor, setVColor] = useState('Arctic White');
  const [vVin, setVVin] = useState('');
  const [vChassis, setVChassis] = useState('');
  const [vPrice, setVPrice] = useState(14990000);
  const [vBattery, setVBattery] = useState(82.5);
  const [vRange, setVRange] = useState(570);
  const [vStatus, setVStatus] = useState('Available');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [invRes, shRes] = await Promise.all([
        api.getDealershipInventory({ dealerId: dealerFilter || undefined, status: statusFilter || undefined, q: q || undefined }),
        api.getDealershipShowrooms(),
      ]);
      setInventory(invRes.inventory || []);
      setHistory(invRes.history || []);
      setShowrooms(shRes.showrooms || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load inventory.');
    } finally {
      setLoading(false);
    }
  }, [dealerFilter, statusFilter, q]);

  useEffect(() => {
    load();
  }, [load]);

  const handleAddVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.addDealershipInventory({
        dealerId: vDealerId,
        showroomId: vShowroomId || undefined,
        model: vModel,
        variant: vVariant,
        exteriorColor: vColor,
        vin: vVin,
        chassisNumber: vChassis,
        approvedSellingPricePkr: Number(vPrice),
        batteryKwh: Number(vBattery),
        rangeKm: Number(vRange),
        availabilityStatus: vStatus,
      });
      setNotice(`Added vehicle ${res.vehicle?.stock_number} (${res.vehicle?.vin}).`);
      setVVin('');
      setVChassis('');
      setShowAdd(false);
      await load();
      onRefreshParent?.();
    } catch (err: any) {
      setError(err?.message || 'Failed to add inventory vehicle.');
    }
  };

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferItem) return;
    setError('');
    try {
      await api.transferDealershipInventory(transferItem.id, {
        toDealerId: transferToDealer,
        notes: transferNotes,
      });
      setNotice(`Transferred stock ${transferItem.stock_number} (${transferItem.vin}).`);
      setTransferItem(null);
      setTransferNotes('');
      await load();
      onRefreshParent?.();
    } catch (err: any) {
      setError(err?.message || 'Transfer failed.');
    }
  };

  const dealerShowrooms = showrooms.filter((s) => s.dealer_id === vDealerId);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Car className="w-4 h-4 text-amber-400" />
            Dealer Vehicle Inventory &amp; VIN Tracking
          </h3>
          <p className="text-xs text-slate-400">
            Dealer-wise BYD EV stock with duplicate VIN/Chassis enforcement, arrival tracking, and stock transfers.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scope?.canManageInventory && (
            <button
              type="button"
              onClick={() => setShowAdd(!showAdd)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> Add Vehicle Stock
            </button>
          )}
          <button
            type="button"
            onClick={load}
            className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      {showAdd && (
        <form onSubmit={handleAddVehicle} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
          <div className="font-bold text-amber-300">Allocate / Add Vehicle Unit to Dealer Stock</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {!scope?.selfOnly && (
              <select value={vDealerId} onChange={(e) => setVDealerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                {dealersCatalog.map((d) => (
                  <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
                ))}
              </select>
            )}
            <select value={vShowroomId} onChange={(e) => setVShowroomId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="">Primary Dealer Showroom</option>
              {dealerShowrooms.map((s) => (
                <option key={s.id} value={s.id}>{s.showroom_code} — {s.name}</option>
              ))}
            </select>
            <select value={vStatus} onChange={(e) => setVStatus(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="Available">Available</option>
              <option value="In-Transit">In-Transit</option>
              <option value="Reserved">Reserved</option>
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input required value={vModel} onChange={(e) => setVModel(e.target.value)} placeholder="Model (e.g. BYD Seal)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required value={vVariant} onChange={(e) => setVVariant(e.target.value)} placeholder="Variant" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required value={vColor} onChange={(e) => setVColor(e.target.value)} placeholder="Exterior Color" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input required type="number" min="100000" value={vPrice} onChange={(e) => setVPrice(Number(e.target.value))} placeholder="Price PKR" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input required value={vVin} onChange={(e) => setVVin(e.target.value.toUpperCase())} placeholder="Unique VIN *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input value={vChassis} onChange={(e) => setVChassis(e.target.value.toUpperCase())} placeholder="Unique Chassis No" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input type="number" step="0.1" value={vBattery} onChange={(e) => setVBattery(Number(e.target.value))} placeholder="Battery kWh" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input type="number" value={vRange} onChange={(e) => setVRange(Number(e.target.value))} placeholder="Range km" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Add Unit</button>
          </div>
        </form>
      )}

      {transferItem && (
        <form onSubmit={handleTransfer} className="p-4 rounded-xl bg-slate-950 border border-blue-500/40 space-y-3 text-xs">
          <div className="font-bold text-blue-300">
            Transfer Vehicle Stock: {transferItem.stock_number} ({transferItem.model} | VIN: {transferItem.vin})
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <select required value={transferToDealer} onChange={(e) => setTransferToDealer(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="">Select Destination Dealership</option>
              {dealersCatalog
                .filter((d) => d.id !== transferItem.dealer_id)
                .map((d) => (
                  <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName} ({d.city})</option>
                ))}
            </select>
            <input value={transferNotes} onChange={(e) => setTransferNotes(e.target.value)} placeholder="Transfer authorization notes" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setTransferItem(null)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold">Confirm Transfer</button>
          </div>
        </form>
      )}

      <div className="flex flex-wrap gap-2 text-xs">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search VIN, chassis, stock #, model..." className="w-full pl-8 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white" />
        </div>
        {!scope?.selfOnly && (
          <select value={dealerFilter} onChange={(e) => setDealerFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
            <option value="">All Dealers</option>
            {dealersCatalog.map((d) => (
              <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
            ))}
          </select>
        )}
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-slate-200">
          <option value="">All Stock Statuses</option>
          <option value="Available">Available</option>
          <option value="Reserved">Reserved</option>
          <option value="Booked">Booked</option>
          <option value="In-Transit">In-Transit</option>
          <option value="Sold">Sold</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Stock #</th>
              <th className="px-3 py-2.5">Vehicle &amp; Specs</th>
              <th className="px-3 py-2.5">VIN / Chassis</th>
              <th className="px-3 py-2.5">Dealer / Showroom</th>
              <th className="px-3 py-2.5">Selling Price</th>
              <th className="px-3 py-2.5">Status</th>
              <th className="px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {inventory.map((v) => (
              <tr key={v.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5 font-mono text-amber-300 whitespace-nowrap">{v.stock_number}</td>
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{v.model} — {v.variant}</div>
                  <div className="text-[11px] text-slate-400">{v.exterior_color} • {v.model_year}{v.battery_kwh ? ` • ${v.battery_kwh} kWh` : ''}</div>
                </td>
                <td className="px-3 py-2.5 font-mono text-[11px]">
                  <div className="text-slate-200">{v.vin}</div>
                  {v.chassis_number && <div className="text-slate-500">{v.chassis_number}</div>}
                </td>
                <td className="px-3 py-2.5">
                  <div className="text-slate-200">{v.dealer_name}</div>
                  <div className="text-[11px] text-slate-400">{v.showroom_name || v.dealer_code}</div>
                </td>
                <td className="px-3 py-2.5 font-mono text-emerald-300 whitespace-nowrap">{fmtPkr(v.approved_selling_price_pkr)}</td>
                <td className="px-3 py-2.5">
                  <div className={v.availability_status === 'Available' ? 'text-emerald-400 font-semibold' : v.availability_status === 'Sold' ? 'text-slate-400' : 'text-amber-300 font-semibold'}>
                    {v.availability_status}
                  </div>
                  <div className="text-[10px] text-slate-500">{v.delivery_status}</div>
                </td>
                <td className="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
                  {scope?.canTransferInventory && v.availability_status !== 'Sold' && (
                    <button
                      type="button"
                      onClick={() => {
                        setTransferItem(v);
                        setTransferToDealer('');
                      }}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-blue-600/80 text-slate-200 hover:text-white inline-flex items-center gap-1"
                    >
                      <ArrowLeftRight className="w-3 h-3" /> Transfer
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {inventory.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-500">No vehicle inventory records matched your filters.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {history.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-2">
          <div className="text-xs font-bold text-slate-200">Recent Inventory Movement &amp; Transfer History</div>
          <div className="space-y-1.5 max-h-48 overflow-y-auto text-[11px]">
            {history.slice(0, 15).map((h) => (
              <div key={h.id} className="flex items-center justify-between gap-2 py-1 border-b border-slate-800/60 text-slate-300">
                <div>
                  <span className="font-mono text-amber-300">{h.stock_number}</span> ({h.action_type}): {h.notes}
                </div>
                <div className="text-slate-500 font-mono whitespace-nowrap">
                  {h.actor_name} • {String(h.created_at).slice(0, 16).replace('T', ' ')}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// 3. DEALER SALES, INVOICES, DISCOUNTS & REFUNDS PANEL
// ============================================================================
export const DealerSalesPanel: React.FC<PanelCommonProps> = ({ scope, dealersCatalog, onRefreshParent }) => {
  const [sales, setSales] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [availableInv, setAvailableInv] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showNewSale, setShowNewSale] = useState(false);
  const [payModalSale, setPayModalSale] = useState<any | null>(null);
  const [payRef, setPayRef] = useState('');
  const [payAmount, setPayAmount] = useState(0);
  const [cancelSale, setCancelSale] = useState<any | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelRefundAmt, setCancelRefundAmt] = useState(0);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Sale Form
  const [sDealerId, setSDealerId] = useState(scope?.selfOnly ? scope.selfDealerId : dealersCatalog[0]?.id || '');
  const [sInventoryId, setSInventoryId] = useState('');
  const [sCustomerId, setSCustomerId] = useState('');
  const [sCustomerName, setSCustomerName] = useState('');
  const [sCustomerPhone, setSCustomerPhone] = useState('+92 300 ');
  const [sDiscount, setSDiscount] = useState(0);
  const [sPaymentRef, setSPaymentRef] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [sRes, invRes] = await Promise.all([
        api.getDealershipSales(),
        api.getDealershipInventory({ status: 'Available' }),
      ]);
      setSales(sRes.sales || []);
      setCustomers(sRes.customers || []);
      setAvailableInv(invRes.inventory || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load sales records.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const dealerStock = availableInv.filter((i) => i.dealer_id === sDealerId);
  const dealerCustomers = customers.filter((c) => c.dealer_id === sDealerId);

  const handleRecordSale = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await api.recordDealershipSale({
        dealerId: sDealerId,
        inventoryId: sInventoryId,
        customerId: sCustomerId || undefined,
        customerName: sCustomerId ? undefined : sCustomerName,
        customerPhone: sCustomerId ? undefined : sCustomerPhone,
        discountPkr: Number(sDiscount || 0),
        approveDiscount: scope?.canApproveDiscounts && Number(sDiscount) > 0,
        paymentProviderRef: sPaymentRef.trim() || undefined,
      });
      setNotice(`Recorded sale ${res.sale?.sale_ref} (${res.sale?.invoice_number}).`);
      setShowNewSale(false);
      setSInventoryId('');
      setSCustomerName('');
      setSDiscount(0);
      setSPaymentRef('');
      await load();
      onRefreshParent?.();
    } catch (err: any) {
      setError(err?.message || 'Unable to record sale.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Receipt className="w-4 h-4 text-amber-400" />
            Dealer Sales, Invoices, Discounts &amp; Settlement Verification
          </h3>
          <p className="text-xs text-slate-400">
            Transactional sales linked to inventory &amp; commission calculation, PDF invoices, verified bank settlement, and refunds.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {scope?.canRecordSales && (
            <button
              type="button"
              onClick={() => setShowNewSale(!showNewSale)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" /> Record Sale
            </button>
          )}
          <button type="button" onClick={load} className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs">{error}</div>}
      {notice && <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs">{notice}</div>}

      {showNewSale && (
        <form onSubmit={handleRecordSale} className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 text-xs">
          <div className="font-bold text-amber-300">Create Dealership Vehicle Sale &amp; Tax Invoice</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {!scope?.selfOnly && (
              <select value={sDealerId} onChange={(e) => { setSDealerId(e.target.value); setSInventoryId(''); }} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
                {dealersCatalog.map((d) => (
                  <option key={d.id} value={d.id}>{d.dealerCode} — {d.businessName}</option>
                ))}
              </select>
            )}
            <select required value={sInventoryId} onChange={(e) => setSInventoryId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="">Select Available Vehicle Unit *</option>
              {dealerStock.map((v) => (
                <option key={v.id} value={v.id}>{v.stock_number} — {v.model} ({v.vin}) • {fmtPkr(v.approved_selling_price_pkr)}</option>
              ))}
            </select>
            <select value={sCustomerId} onChange={(e) => setSCustomerId(e.target.value)} className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white">
              <option value="">+ New Walk-In / CRM Customer</option>
              {dealerCustomers.map((c) => (
                <option key={c.id} value={c.id}>{c.full_name} ({c.phone})</option>
              ))}
            </select>
          </div>
          {!sCustomerId && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input required value={sCustomerName} onChange={(e) => setSCustomerName(e.target.value)} placeholder="Customer Full Name *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
              <input required value={sCustomerPhone} onChange={(e) => setSCustomerPhone(e.target.value)} placeholder="Customer Phone *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input type="number" min="0" value={sDiscount} onChange={(e) => setSDiscount(Number(e.target.value))} placeholder="Requested Discount PKR (optional)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input value={sPaymentRef} onChange={(e) => setSPaymentRef(e.target.value)} placeholder="Verified Bank / IBFT Reference (leave blank if unpaid)" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowNewSale(false)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold">Generate Sale &amp; Invoice</button>
          </div>
        </form>
      )}

      {payModalSale && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setError('');
            try {
              await api.verifyDealershipSalePayment(payModalSale.id, {
                paymentProviderRef: payRef,
                paidAmountPkr: Number(payAmount),
              });
              setNotice(`Verified payment settlement on ${payModalSale.sale_ref}.`);
              setPayModalSale(null);
              load();
              onRefreshParent?.();
            } catch (err: any) {
              setError(err?.message || 'Payment verification failed.');
            }
          }}
          className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-3 text-xs"
        >
          <div className="font-bold text-emerald-300">Verify Settlement for {payModalSale.sale_ref}</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input required minLength={4} value={payRef} onChange={(e) => setPayRef(e.target.value)} placeholder="Verified Bank / 1Link Reference *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
            <input required type="number" min="1" value={payAmount} onChange={(e) => setPayAmount(Number(e.target.value))} placeholder="Verified Amount PKR *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setPayModalSale(null)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold">Confirm Settlement</button>
          </div>
        </form>
      )}

      {cancelSale && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setError('');
            try {
              await api.cancelRefundDealershipSale(cancelSale.id, {
                reason: cancelReason,
                refundAmountPkr: Number(cancelRefundAmt),
              });
              setNotice(`Cancelled sale ${cancelSale.sale_ref} and restored vehicle stock.`);
              setCancelSale(null);
              load();
              onRefreshParent?.();
            } catch (err: any) {
              setError(err?.message || 'Cancellation failed.');
            }
          }}
          className="p-4 rounded-xl bg-slate-950 border border-rose-500/40 space-y-3 text-xs"
        >
          <div className="font-bold text-rose-300">Cancel Sale &amp; Process Refund: {cancelSale.sale_ref}</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input required value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} placeholder="Formal cancellation / refund reason *" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white" />
            <input type="number" min="0" max={Number(cancelSale.paid_amount_pkr || 0)} value={cancelRefundAmt} onChange={(e) => setCancelRefundAmt(Number(e.target.value))} placeholder="Refund Amount PKR" className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-white font-mono" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setCancelSale(null)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300">Close</button>
            <button type="submit" className="px-5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold">Execute Cancel &amp; Refund</button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
            <tr>
              <th className="px-3 py-2.5">Invoice / Ref</th>
              <th className="px-3 py-2.5">Customer &amp; Vehicle</th>
              <th className="px-3 py-2.5">Dealer</th>
              <th className="px-3 py-2.5">Net Amount / Discount</th>
              <th className="px-3 py-2.5">Payment Status</th>
              <th className="px-3 py-2.5">Delivery</th>
              <th className="px-3 py-2.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {sales.map((s) => (
              <tr key={s.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2.5 whitespace-nowrap">
                  <div className="font-mono text-amber-300 font-semibold">{s.invoice_number || s.sale_ref}</div>
                  <div className="text-[10px] text-slate-500">{s.sales_date || String(s.created_at).slice(0, 10)}</div>
                </td>
                <td className="px-3 py-2.5">
                  <div className="font-semibold text-white">{s.customer_name || 'Verified Buyer'}</div>
                  <div className="text-[11px] text-slate-400">{s.vehicle_model} • <span className="font-mono">{s.vin}</span></div>
                </td>
                <td className="px-3 py-2.5 text-slate-300">{s.dealer_name}</td>
                <td className="px-3 py-2.5 font-mono">
                  <div className="text-white font-semibold">{fmtPkr(s.sale_amount_pkr)}</div>
                  {Number(s.discount_pkr) > 0 && (
                    <div className="text-[10px] text-amber-300">
                      Disc: {fmtPkr(s.discount_pkr)} ({s.discount_status})
                    </div>
                  )}
                </td>
                <td className="px-3 py-2.5">
                  <div className={s.payment_status === 'Payment Verified' ? 'text-emerald-400 font-semibold' : s.payment_status === 'Refunded' ? 'text-rose-400' : 'text-amber-300'}>
                    {s.payment_status}
                  </div>
                  {s.payment_provider_ref && <div className="text-[10px] font-mono text-slate-400">{s.payment_provider_ref}</div>}
                </td>
                <td className="px-3 py-2.5">
                  <div className="text-slate-200">{s.delivery_status}</div>
                </td>
                <td className="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={async () => {
                      const { blob, filename } = await api.downloadDealershipBlob(`/api/dealership-management/sales/${encodeURIComponent(s.id)}/invoice.pdf`);
                      triggerBlobDownload(blob, filename);
                    }}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 inline-flex items-center gap-1"
                    title="Download PDF Invoice"
                  >
                    <Download className="w-3 h-3" /> PDF
                  </button>
                  {scope?.canApproveDiscounts && s.discount_status === 'Pending Approval' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.decideDealershipSaleDiscount(s.id, 'approve');
                        setNotice(`Discount approved on ${s.sale_ref}.`);
                        load();
                      }}
                      className="px-2 py-1 rounded bg-emerald-600/80 text-white"
                    >
                      Approve Disc
                    </button>
                  )}
                  {scope?.canVerifyPayments && s.payment_status !== 'Payment Verified' && s.delivery_status !== 'Cancelled' && (
                    <button
                      type="button"
                      onClick={() => {
                        setPayModalSale(s);
                        setPayRef('');
                        setPayAmount(Number(s.sale_amount_pkr || 0));
                      }}
                      className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white"
                    >
                      Verify Pay
                    </button>
                  )}
                  {s.delivery_status !== 'Delivered' && s.delivery_status !== 'Cancelled' && (
                    <button
                      type="button"
                      onClick={async () => {
                        await api.updateDealershipSaleDelivery(s.id, 'Delivered');
                        setNotice(`Marked ${s.sale_ref} Delivered.`);
                        load();
                      }}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white inline-flex items-center gap-1"
                    >
                      <Truck className="w-3 h-3" /> Deliver
                    </button>
                  )}
                  {scope?.canCancelRefund && s.delivery_status !== 'Cancelled' && (
                    <button
                      type="button"
                      onClick={() => {
                        setCancelSale(s);
                        setCancelReason('');
                        setCancelRefundAmt(Number(s.paid_amount_pkr || 0));
                      }}
                      className="px-2 py-1 rounded bg-rose-900/70 hover:bg-rose-700 text-rose-200 inline-flex items-center gap-1"
                    >
                      <Ban className="w-3 h-3" /> Cancel
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {sales.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-slate-500">No sales records found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
