import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  KeyRound,
  Mail,
  Users,
  Building2,
  Car,
  Wrench,
  BarChart3,
  LifeBuoy,
  Bell,
  Settings,
  FileText,
  RefreshCw,
  LogOut,
  Plus,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Eye,
  EyeOff,
  Copy,
  Check,
  DollarSign,
  CalendarCheck,
  Activity,
  Store,
  UserCheck,
  Briefcase,
  Search,
  ArrowLeft,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AdminDealerGovernancePanel } from '../dealer/AdminDealerGovernancePanel';
import { AdminVerificationApprovalPanel } from './AdminVerificationApprovalPanel';
import { SuperAdminCompaniesPanel } from './SuperAdminCompaniesPanel';
import { SuperAdminUsersPanel } from './SuperAdminUsersPanel';
import { SuperAdminEmployeesPanel } from './SuperAdminEmployeesPanel';
import { SuperAdminDealersAnalyticsPanel } from './SuperAdminDealersAnalyticsPanel';
import { SuperAdminCustomersHubPanel } from './SuperAdminCustomersHubPanel';
import { SuperAdminVerificationHubPanel } from './SuperAdminVerificationHubPanel';
import { SuperAdminMonitoringPanel } from './SuperAdminMonitoringPanel';
import { SuperAdminReportsPanel } from './SuperAdminReportsPanel';
import { SuperAdminActivityLogsPanel } from './SuperAdminActivityLogsPanel';
import { EmployeeManagementHub } from '../employee/EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type AdminAuthView = 'login' | 'verify-email' | 'verify-2fa' | 'accept-invite' | 'forgot-password';
type AdminDashTab =
  | 'overview'
  | 'users'
  | 'companies'
  | 'employees'
  | 'employee-hub'
  | 'dealerships'
  | 'dealership-hub'
  | 'customers'
  | 'verification'
  | 'permissions'
  | 'monitoring'
  | 'reports'
  | 'vehicles'
  | 'bookings-sales'
  | 'support'
  | 'notifications'
  | 'settings'
  | 'audit-logs';

const NON_ADMIN_ROLES = [
  'Company Admin',
  'Head Office Staff',
  'Dealership Manager',
  'Dealership Staff',
  'Sales Manager',
  'Sales Executive',
  'Finance Manager',
  'Service Manager',
  'Technical Support',
  'Customer',
];

export const AdminPortal: React.FC = () => {
  const {
    currentUser,
    isAuthenticated,
    loginUser,
    logoutUser,
    setActiveTab,
    saInviteTokenParam,
    formatPrice,
  } = useApp();

  const hasAdminSession =
    isAuthenticated &&
    (currentUser.subjectType === 'super_admin' || currentUser.subjectType === 'founder');

  // Portal Status & Auth State
  const [saStatus, setSaStatus] = useState<{
    hasSuperAdmin: boolean;
    founderProvisioned: boolean;
    twoFactorRequired: boolean;
    inviteOnly: boolean;
  } | null>(null);
  const [authView, setAuthView] = useState<AdminAuthView>(
    saInviteTokenParam ? 'accept-invite' : 'login'
  );
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authInfo, setAuthInfo] = useState('');

  // Login Form
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Email OTP Verification
  const [verifyEmailAddr, setVerifyEmailAddr] = useState('');
  const [emailOtpCode, setEmailOtpCode] = useState('');
  const [devEmailOtp, setDevEmailOtp] = useState('');

  // 2FA Verification
  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [dev2faOtp, setDev2faOtp] = useState('');
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);

  // Accept Invite State
  const [inviteToken, setInviteToken] = useState(saInviteTokenParam || '');
  const [inviteDetails, setInviteDetails] = useState<any>(null);
  const [inviteMobile, setInviteMobile] = useState('+92 300 ');
  const [invitePassword, setInvitePassword] = useState('');
  const [inviteConfirm, setInviteConfirm] = useState('');
  const [inviteTwoFactorSetup, setInviteTwoFactorSetup] = useState<{
    secret: string;
    otpAuthUri: string;
    recoveryCodes: string[];
  } | null>(null);

  // Forgot / Reset Password State
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [resetNewPass, setResetNewPass] = useState('');
  const [resetOutbox, setResetOutbox] = useState<{ resetToken: string; otpCode: string } | null>(null);

  // Dashboard State
  const [dashTab, setDashTab] = useState<AdminDashTab>('overview');
  const [dashLoading, setDashLoading] = useState(false);
  const [tabError, setTabError] = useState('');
  const [actionBanner, setActionBanner] = useState('');
  const [dashboard, setDashboard] = useState<any>(null);

  // Tab Datasets
  const [companies, setCompanies] = useState<any[]>([]);
  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  const [compEditForm, setCompEditForm] = useState({ phone: '', city: '', address: '', authorizedRep: '' });

  const [dealerships, setDealerships] = useState<any[]>([]);
  const [showNewDealerForm, setShowNewDealerForm] = useState(false);
  const [newDealer, setNewDealer] = useState({
    companyId: 'comp_byd_pk',
    name: '',
    code: '',
    country: 'PK',
    city: 'Karachi',
    address: '',
    managerName: '',
    phone: '+92 ',
    email: '',
    facilityType: '3S Flagship Centre',
    status: 'Approved',
  });

  const [users, setUsers] = useState<any[]>([]);
  const [userCategory, setUserCategory] = useState<'all' | 'employees' | 'dealers' | 'customers'>('all');
  const [userSearch, setUserSearch] = useState('');
  const [showNewUserForm, setShowNewUserForm] = useState(false);
  const [newUserForm, setNewUserForm] = useState({
    fullName: '',
    email: '',
    mobile: '+92 300 ',
    password: '',
    role: 'Customer',
    companyId: 'comp_byd_pk',
    country: 'PK',
    city: 'Karachi',
  });

  const [vehicles, setVehicles] = useState<any[]>([]);
  const [showNewVehicleForm, setShowNewVehicleForm] = useState(false);
  const [newVehicleForm, setNewVehicleForm] = useState({
    companyId: 'comp_byd_pk',
    vin: '',
    model: 'BYD Seal',
    variant: 'Performance AWD',
    color: 'Atlantis Grey',
    licensePlate: '',
    ownerName: 'Dealership Stock',
    ownerCity: 'Karachi',
    salePricePkr: 14990000,
    batteryCapacityKwh: 82.5,
  });

  const [opsData, setOpsData] = useState<{
    bookings: any[];
    serviceJobs: any[];
    warrantyClaims: any[];
    invoices: any[];
    soldVehicles: any[];
  } | null>(null);

  const [reports, setReports] = useState<any>(null);
  const [tickets, setTickets] = useState<any[]>([]);
  const [showNewTicketForm, setShowNewTicketForm] = useState(false);
  const [newTicket, setNewTicket] = useState({
    subject: '',
    category: 'Enterprise Support',
    priority: 'Medium',
    description: '',
  });

  const [notifications, setNotifications] = useState<any[]>([]);
  const [newNotif, setNewNotif] = useState({
    title: '',
    message: '',
    category: 'Announcement',
    companyId: '',
  });

  const [opSettings, setOpSettings] = useState<any>(null);
  const [auditData, setAuditData] = useState<{
    adminActivities: any[];
    loginHistory: any[];
    securityEvents: any[];
  } | null>(null);

  const [copiedText, setCopiedText] = useState('');

  const flashBanner = (msg: string) => {
    setActionBanner(msg);
    setTimeout(() => setActionBanner(''), 5500);
  };

  const copyValue = (text: string, label: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
      setCopiedText(label);
      setTimeout(() => setCopiedText(''), 2000);
    }
  };

  // Load Super Admin provisioning status
  useEffect(() => {
    api
      .getSuperAdminStatus()
      .then((res) => setSaStatus(res))
      .catch(() => {});
  }, []);

  // Auto-lookup invite token from URL if present
  useEffect(() => {
    if (saInviteTokenParam) {
      setAuthView('accept-invite');
      setInviteToken(saInviteTokenParam);
      api
        .lookupSuperAdminInvite(saInviteTokenParam)
        .then((res) => {
          setInviteDetails(res);
          setInviteMobile(res.mobile || '+92 300 ');
        })
        .catch((err: any) => {
          setAuthError(err.message || 'Invitation token is invalid or expired.');
        });
    }
  }, [saInviteTokenParam]);

  // Dashboard Loaders
  const loadDashboardOverview = useCallback(async () => {
    if (!hasAdminSession) return;
    setDashLoading(true);
    setTabError('');
    try {
      const data = await api.getSuperAdminDashboard();
      setDashboard(data);
    } catch (err: any) {
      setTabError(err.message || 'Unable to load Super Admin dashboard metrics.');
    } finally {
      setDashLoading(false);
    }
  }, [hasAdminSession]);

  const loadActiveTabData = useCallback(
    async (tab: AdminDashTab) => {
      if (!hasAdminSession) return;
      setTabError('');
      try {
        if (tab === 'overview') {
          await loadDashboardOverview();
        } else if (tab === 'companies' || tab === 'employees') {
          const res = await api.getSuperAdminCompanies();
          setCompanies(res.companies || []);
        } else if (tab === 'dealerships') {
          const [dlrRes, compRes] = await Promise.all([
            api.getSuperAdminDealerships(),
            api.getSuperAdminCompanies().catch(() => ({ companies: [] })),
          ]);
          setDealerships(dlrRes.dealerships || []);
          if (compRes.companies?.length) setCompanies(compRes.companies);
        } else if (tab === 'users') {
          const [usrRes, compRes] = await Promise.all([
            api.getSuperAdminUsers(userCategory),
            api.getSuperAdminCompanies().catch(() => ({ companies: [] })),
          ]);
          setUsers(usrRes.users || []);
          if (compRes.companies?.length) setCompanies(compRes.companies);
        } else if (tab === 'vehicles') {
          const [vehRes, compRes] = await Promise.all([
            api.getSuperAdminVehicles(),
            api.getSuperAdminCompanies().catch(() => ({ companies: [] })),
          ]);
          setVehicles(vehRes.vehicles || []);
          if (compRes.companies?.length) setCompanies(compRes.companies);
        } else if (tab === 'bookings-sales') {
          const res = await api.getSuperAdminBookingsSales();
          setOpsData(res);
        } else if (tab === 'reports') {
          const res = await api.getSuperAdminReports();
          setReports(res);
        } else if (tab === 'support') {
          const res = await api.getSuperAdminSupportRequests();
          setTickets(res.tickets || []);
        } else if (tab === 'notifications') {
          const [ntfRes, compRes] = await Promise.all([
            api.getSuperAdminNotifications(),
            api.getSuperAdminCompanies().catch(() => ({ companies: [] })),
          ]);
          setNotifications(ntfRes.notifications || []);
          if (compRes.companies?.length) setCompanies(compRes.companies);
        } else if (tab === 'settings') {
          const res = await api.getSuperAdminSettings();
          setOpSettings(res.operationalSettings || {});
        } else if (tab === 'audit-logs') {
          const res = await api.getSuperAdminAuditLogs();
          setAuditData(res);
        }
      } catch (err: any) {
        setTabError(err.message || 'Permission denied or failed to load tab records.');
      }
    },
    [hasAdminSession, loadDashboardOverview, userCategory]
  );

  useEffect(() => {
    if (hasAdminSession) {
      loadActiveTabData(dashTab);
    }
  }, [hasAdminSession, dashTab, loadActiveTabData]);

  // ============================================================================
  // SUPER ADMIN AUTH HANDLERS
  // ============================================================================
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthInfo('');
    setAuthLoading(true);
    try {
      const res = await api.superAdminLogin({ identifier: identifier.trim(), password });
      if (res.requiresEmailVerification) {
        setVerifyEmailAddr(res.email);
        setDevEmailOtp(res.verificationOutbox?.code || '');
        setAuthInfo(res.message);
        setAuthView('verify-email');
      } else if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setDev2faOtp(res.otpOutbox?.code || '');
        setSuspiciousAlert(Boolean(res.suspiciousIpDetected));
        setAuthInfo(res.message);
        setAuthView('verify-2fa');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Super Admin login failed.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleVerifyEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      const res = await api.superAdminVerifyEmail({
        email: verifyEmailAddr.trim(),
        code: emailOtpCode.trim(),
      });
      if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setDev2faOtp(res.otpOutbox?.code || '');
        setAuthInfo(res.message);
        setAuthView('verify-2fa');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Invalid email verification OTP.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleVerify2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      const res = await api.superAdminVerify2FA({
        challengeToken,
        code: twoFactorCode.trim(),
      });
      if (res.success && res.user) {
        setPassword('');
        setTwoFactorCode('');
        setChallengeToken('');
        loginUser(res.user);
      }
    } catch (err: any) {
      setAuthError(err.message || '2FA verification failed.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLookupInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      const res = await api.lookupSuperAdminInvite(inviteToken.trim());
      setInviteDetails(res);
      setInviteMobile(res.mobile || '+92 300 ');
    } catch (err: any) {
      setInviteDetails(null);
      setAuthError(err.message || 'Invalid or expired Founder invitation token.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleAcceptInviteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (invitePassword !== inviteConfirm) {
      setAuthError('Passwords do not match.');
      return;
    }
    setAuthLoading(true);
    try {
      const res = await api.acceptSuperAdminInvite({
        token: inviteToken.trim(),
        password: invitePassword,
        mobile: inviteMobile.trim(),
      });
      setInviteTwoFactorSetup(res.twoFactorSetup);
      setVerifyEmailAddr(res.email);
      setDevEmailOtp(res.verificationOutbox?.code || '');
      setAuthInfo(res.message);
      api.getSuperAdminStatus().then(setSaStatus).catch(() => {});
    } catch (err: any) {
      setAuthError(err.message || 'Failed to activate Super Admin account.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      const res = await api.superAdminForgotPassword(forgotEmail.trim());
      setAuthInfo(res.message);
      if (res.resetOutbox) {
        setResetOutbox({ resetToken: res.resetOutbox.resetToken, otpCode: res.resetOutbox.otpCode });
        setResetToken(res.resetOutbox.resetToken);
        setResetOtp(res.resetOutbox.otpCode);
      }
    } catch (err: any) {
      setAuthError(err.message || 'Failed to initiate password reset.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);
    try {
      const res = await api.superAdminResetPassword({
        token: resetToken.trim() || undefined,
        email: forgotEmail.trim() || undefined,
        otpCode: resetOtp.trim() || undefined,
        newPassword: resetNewPass,
      });
      setAuthInfo(res.message);
      setResetOutbox(null);
      setResetNewPass('');
      setAuthView('login');
    } catch (err: any) {
      setAuthError(err.message || 'Failed to reset password.');
    } finally {
      setAuthLoading(false);
    }
  };

  // ============================================================================
  // DASHBOARD MUTATION HANDLERS
  // ============================================================================
  const handleDealershipStatus = async (
    id: string,
    status: 'Approved' | 'Pending Approval' | 'Rejected' | 'Suspended'
  ) => {
    setTabError('');
    try {
      await api.updateSuperAdminDealershipStatus(id, status);
      flashBanner(`Dealership status updated to "${status}".`);
      await Promise.all([
        loadDashboardOverview(),
        dashTab === 'dealerships' ? loadActiveTabData('dealerships') : Promise.resolve(),
      ]);
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleCreateDealer = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      await api.createSuperAdminDealership(newDealer);
      setShowNewDealerForm(false);
      setNewDealer({ ...newDealer, name: '', code: '', address: '', managerName: '', email: '' });
      flashBanner('New dealership / branch registered in SQLite database.');
      await loadActiveTabData('dealerships');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleSaveCompany = async (id: string) => {
    setTabError('');
    try {
      await api.updateSuperAdminCompany(id, compEditForm);
      setEditingCompanyId(null);
      flashBanner('Company operational contact metadata updated.');
      await loadActiveTabData('companies');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      const res = await api.createSuperAdminUser(newUserForm);
      setShowNewUserForm(false);
      setNewUserForm({ ...newUserForm, fullName: '', email: '', password: '' });
      flashBanner(`Created verified ${res.role} account (${res.id}).`);
      await loadActiveTabData('users');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleUpdateUser = async (
    id: string,
    payload: { status?: 'Active' | 'Suspended'; role?: string; emailVerified?: boolean }
  ) => {
    setTabError('');
    try {
      await api.updateSuperAdminUser(id, payload);
      flashBanner('User account updated and audit-logged.');
      await loadActiveTabData('users');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleCreateVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      const res = await api.createSuperAdminVehicle(newVehicleForm);
      setShowNewVehicleForm(false);
      setNewVehicleForm({ ...newVehicleForm, vin: '', licensePlate: '' });
      flashBanner(`Vehicle ${res.vin} added to master fleet registry.`);
      await loadActiveTabData('vehicles');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleUpdateVehicle = async (
    id: string,
    payload: { status?: string; batteryHealthSoh?: number; markAsSold?: boolean }
  ) => {
    setTabError('');
    try {
      await api.updateSuperAdminVehicle(id, payload);
      flashBanner('Vehicle record updated.');
      await loadActiveTabData('vehicles');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      const res = await api.createSuperAdminSupportRequest(newTicket);
      setShowNewTicketForm(false);
      setNewTicket({ subject: '', category: 'Enterprise Support', priority: 'Medium', description: '' });
      flashBanner(`Support ticket ${res.ticketNumber} created.`);
      await loadActiveTabData('support');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleUpdateTicket = async (
    id: string,
    payload: { status?: string; resolutionNotes?: string }
  ) => {
    setTabError('');
    try {
      await api.updateSuperAdminSupportRequest(id, payload);
      flashBanner('Support ticket updated.');
      await loadActiveTabData('support');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleCreateNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      await api.createSuperAdminNotification({
        title: newNotif.title,
        message: newNotif.message,
        category: newNotif.category,
        companyId: newNotif.companyId || undefined,
      });
      setNewNotif({ title: '', message: '', category: 'Announcement', companyId: '' });
      flashBanner('System announcement broadcasted.');
      await loadActiveTabData('notifications');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setTabError('');
    try {
      const res = await api.updateSuperAdminSettings(opSettings);
      setOpSettings(res.operationalSettings);
      flashBanner('Permitted application operational settings saved.');
    } catch (err: any) {
      setTabError(err.message);
    }
  };

  // ============================================================================
  // GATE 1: WRONG ROLE SIGNED IN (NON-SUPER-ADMIN / NON-FOUNDER)
  // ============================================================================
  if (isAuthenticated && !hasAdminSession) {
    return (
      <div className="max-w-xl mx-auto py-12 px-4">
        <div className="rounded-3xl bg-slate-900 border border-rose-500/40 p-8 text-center space-y-5 shadow-2xl">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center">
            <ShieldAlert className="w-7 h-7 text-rose-400" />
          </div>
          <div className="space-y-2">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-rose-400">
              Strict Portal Isolation Active
            </span>
            <h2 className="text-xl font-black text-white">Super Admin Portal Access Restricted</h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              You are currently authenticated as{' '}
              <span className="text-cyan-300 font-bold">{currentUser.fullName}</span> (
              <span className="font-mono">{currentUser.role}</span>). Standard company, dealership,
              and customer accounts are isolated from the Super Admin Portal.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => setActiveTab('landing')}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition"
            >
              Return to Public Fleet
            </button>
            <button
              onClick={logoutUser}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white transition flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out & Switch to Super Admin Login</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // GATE 2: DEDICATED SUPER ADMIN LOGIN & PROVISIONING PORTAL
  // ============================================================================
  if (!hasAdminSession) {
    return (
      <div className="max-w-2xl mx-auto py-8 px-4 space-y-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveTab('landing')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-cyan-400 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Public Platform</span>
          </button>
          <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400">
            /super-admin-login
          </span>
        </div>

        <div className="rounded-3xl bg-slate-900/95 border border-cyan-500/30 shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-6 sm:p-8 bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/30 border-b border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center">
                  <ShieldCheck className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-cyan-400 block">
                    BYD PAKISTAN 360 • Dedicated Gateway
                  </span>
                  <h2 className="text-xl font-black text-white">Super Admin Authentication Portal</h2>
                </div>
              </div>
              <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-emerald-400">
                2FA + Email OTP Enforced
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Independent operational control portal authorized solely by Founder / Primary Owner{' '}
              <span className="text-white font-semibold">Intekhab Alam</span>. Public self-registration
              and Founder governance override are permanently disabled.
            </p>

            {/* Provisioning status chips */}
            {saStatus && (
              <div className="flex flex-wrap gap-2 pt-1">
                <span
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border ${
                    saStatus.founderProvisioned
                      ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                      : 'bg-amber-950/60 border-amber-800 text-amber-300'
                  }`}
                >
                  Founder Authority: {saStatus.founderProvisioned ? 'Initialized' : 'Awaiting Founder Setup'}
                </span>
                <span
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border ${
                    saStatus.hasSuperAdmin
                      ? 'bg-cyan-950/60 border-cyan-800 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Super Admin Accounts: {saStatus.hasSuperAdmin ? 'Active in Database' : 'Invite Required'}
                </span>
              </div>
            )}

            {/* Auth Mode Switcher */}
            <div className="flex flex-wrap gap-2 pt-2">
              {[
                { id: 'login', label: 'Sign In' },
                { id: 'accept-invite', label: 'Activate Founder Invite' },
                { id: 'verify-email', label: 'Verify Email OTP' },
                { id: 'forgot-password', label: 'Forgot / Reset Password' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setAuthError('');
                    setAuthView(m.id as AdminAuthView);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                    authView === m.id
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Body */}
          <div className="p-6 sm:p-8 space-y-5">
            {authError && (
              <div className="p-3.5 rounded-xl bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}
            {authInfo && (
              <div className="p-3.5 rounded-xl bg-cyan-950/60 border border-cyan-500/40 text-xs text-cyan-200 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>{authInfo}</span>
              </div>
            )}

            {/* VIEW 1: STEP 1 SIGN IN */}
            {authView === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {saStatus && !saStatus.hasSuperAdmin && (
                  <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200 space-y-1.5">
                    <p className="font-bold text-amber-300">No Super Admin Provisioned Yet</p>
                    <p className="text-slate-300 leading-relaxed">
                      Zero hardcoded Super Admin credentials exist. Sign in as Founder{' '}
                      <span className="text-white font-semibold">Intekhab Alam</span> in the{' '}
                      <button
                        type="button"
                        onClick={() => setActiveTab('owner')}
                        className="underline text-cyan-400 font-bold"
                      >
                        Founder Portal
                      </button>{' '}
                      to issue a single-use Super Admin invitation link or provision an account directly.
                    </p>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Authorized Super Admin Email or Mobile
                  </label>
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="superadmin@company.com or +92300..."
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none px-4 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your Super Admin password"
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none px-4 py-2.5 pr-10 text-sm text-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-sm shadow-lg shadow-cyan-500/20 disabled:opacity-60 transition flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>{authLoading ? 'Verifying Credentials...' : 'Continue to 2FA Verification'}</span>
                </button>
              </form>
            )}

            {/* VIEW 2: EMAIL OTP VERIFICATION */}
            {authView === 'verify-email' && (
              <form onSubmit={handleVerifyEmailSubmit} className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
                    <Mail className="w-4 h-4" />
                    <span>Mandatory Email Verification Before First Session</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Enter your Super Admin email and the 6-digit verification OTP generated for your account.
                  </p>
                  {devEmailOtp && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-700/60 flex items-center justify-between text-xs">
                      <span className="text-emerald-200">
                        Verification Outbox OTP: <strong className="font-mono text-white text-sm">{devEmailOtp}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => setEmailOtpCode(devEmailOtp)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px]"
                      >
                        Auto-Fill
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Super Admin Email</label>
                  <input
                    type="email"
                    required
                    value={verifyEmailAddr}
                    onChange={(e) => setVerifyEmailAddr(e.target.value)}
                    placeholder="superadmin@company.com"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-4 py-2.5 text-sm text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">6-Digit Email OTP</label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={emailOtpCode}
                    onChange={(e) => setEmailOtpCode(e.target.value)}
                    placeholder="123456"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 px-4 py-2.5 text-sm font-mono tracking-widest text-white"
                  />
                </div>

                <button
                  type="submit"
                  disabled={authLoading}
                  className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-sm transition"
                >
                  {authLoading ? 'Confirming Email OTP...' : 'Verify Email & Proceed to 2FA'}
                </button>
              </form>
            )}

            {/* VIEW 3: STEP 2 TWO-FACTOR AUTHENTICATION */}
            {authView === 'verify-2fa' && (
              <form onSubmit={handleVerify2FASubmit} className="space-y-4">
                {suspiciousAlert && (
                  <div className="p-3.5 rounded-xl bg-amber-950/70 border border-amber-500/40 text-xs text-amber-200 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>New IP or device signature detected. Security event logged for Founder review.</span>
                  </div>
                )}

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                    <KeyRound className="w-4 h-4" />
                    <span>Two-Factor Authentication Challenge</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Enter a 6-digit Authenticator TOTP code, your single-use Email Login OTP, or an 8-character Backup Recovery Code.
                  </p>
                  {dev2faOtp && (
                    <div className="p-2.5 rounded-xl bg-cyan-950/60 border border-cyan-700/60 flex items-center justify-between text-xs">
                      <span className="text-cyan-200">
                        Single-Use Login OTP (Dev Outbox):{' '}
                        <strong className="font-mono text-white text-sm">{dev2faOtp}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => setTwoFactorCode(dev2faOtp)}
                        className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[11px]"
                      >
                        Auto-Fill
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    2FA / OTP / Recovery Code
                  </label>
                  <input
                    type="text"
                    required
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value)}
                    placeholder="Enter 6-digit code or backup code"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 outline-none px-4 py-3 text-center text-lg font-mono tracking-widest text-white"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setChallengeToken('');
                      setTwoFactorCode('');
                      setAuthView('login');
                    }}
                    className="px-4 py-3 rounded-xl bg-slate-800 text-xs font-bold text-slate-300 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm transition"
                  >
                    {authLoading ? 'Authorizing Session...' : 'Complete 2FA & Open Super Admin Dashboard'}
                  </button>
                </div>
              </form>
            )}

            {/* VIEW 4: ACTIVATE FOUNDER INVITATION */}
            {authView === 'accept-invite' && (
              <div className="space-y-4">
                {!inviteTwoFactorSetup ? (
                  <>
                    <form onSubmit={handleLookupInvite} className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        required
                        value={inviteToken}
                        onChange={(e) => setInviteToken(e.target.value)}
                        placeholder="Paste single-use Founder Super Admin invite token"
                        className="flex-1 rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs font-mono text-white"
                      />
                      <button
                        type="submit"
                        disabled={authLoading}
                        className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-cyan-300"
                      >
                        Validate Token
                      </button>
                    </form>

                    {inviteDetails && (
                      <form onSubmit={handleAcceptInviteSubmit} className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-4">
                        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-800 pb-3">
                          <div>
                            <p className="text-sm font-black text-white">{inviteDetails.fullName}</p>
                            <p className="text-xs font-mono text-cyan-300">{inviteDetails.email}</p>
                          </div>
                          <span className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-800">
                            {inviteDetails.city}, {inviteDetails.country}
                          </span>
                        </div>

                        <div className="space-y-1">
                          <span className="text-[10px] font-bold uppercase text-slate-400">
                            Founder-Assigned Permissions ({inviteDetails.permissions?.length || 0})
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {(inviteDetails.permissions || []).map((p: string) => (
                              <span key={p} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">
                                {p}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Mobile</label>
                            <input
                              type="tel"
                              required
                              value={inviteMobile}
                              onChange={(e) => setInviteMobile(e.target.value)}
                              className="w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Set Password (12+ chars)</label>
                            <input
                              type="password"
                              required
                              value={invitePassword}
                              onChange={(e) => setInvitePassword(e.target.value)}
                              placeholder="Upper, lower, digit, symbol"
                              className="w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-300 mb-1">Confirm Password</label>
                            <input
                              type="password"
                              required
                              value={inviteConfirm}
                              onChange={(e) => setInviteConfirm(e.target.value)}
                              className="w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={authLoading}
                          className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs transition"
                        >
                          {authLoading ? 'Activating Account...' : 'Activate Super Admin & Generate 2FA Credentials'}
                        </button>
                      </form>
                    )}
                  </>
                ) : (
                  <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-4">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5" />
                      <span>Save Your Authenticator TOTP Secret & Recovery Codes</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                      <div className="text-xs">
                        <span className="text-slate-400 block text-[10px]">TOTP Base32 Secret</span>
                        <code className="font-mono text-cyan-300 font-bold">{inviteTwoFactorSetup.secret}</code>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyValue(inviteTwoFactorSetup.secret, 'totp')}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-xs text-white flex items-center gap-1"
                      >
                        {copiedText === 'totp' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Copy</span>
                      </button>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">
                        Single-Use Backup Recovery Codes
                      </span>
                      <div className="grid grid-cols-3 gap-2">
                        {inviteTwoFactorSetup.recoveryCodes.map((c) => (
                          <div key={c} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-center font-mono text-xs text-amber-300">
                            {c}
                          </div>
                        ))}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAuthView('verify-email')}
                      className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs"
                    >
                      Proceed to Email OTP Verification ({verifyEmailAddr})
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* VIEW 5: FORGOT / RESET PASSWORD */}
            {authView === 'forgot-password' && (
              <div className="space-y-4">
                <form onSubmit={handleForgotRequest} className="space-y-3">
                  <label className="block text-xs font-semibold text-slate-300">
                    Super Admin Registered Email
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      required
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="superadmin@company.com"
                      className="flex-1 rounded-xl bg-slate-950 border border-slate-800 px-3.5 py-2 text-xs text-white"
                    />
                    <button
                      type="submit"
                      disabled={authLoading}
                      className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
                    >
                      Request Reset
                    </button>
                  </div>
                </form>

                {resetOutbox && (
                  <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-600/40 text-xs text-amber-200 space-y-1">
                    <p className="font-bold">Password Reset Outbox (Dev Mode)</p>
                    <p className="font-mono text-[11px] break-all">Token: {resetOutbox.resetToken}</p>
                    <p className="font-mono text-[11px]">OTP: {resetOutbox.otpCode}</p>
                  </div>
                )}

                <form onSubmit={handleResetPasswordSubmit} className="space-y-3 pt-2 border-t border-slate-800">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">Reset Token</label>
                      <input
                        type="text"
                        value={resetToken}
                        onChange={(e) => setResetToken(e.target.value)}
                        placeholder="Paste reset token"
                        className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs font-mono text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">Or 6-Digit Reset OTP</label>
                      <input
                        type="text"
                        value={resetOtp}
                        onChange={(e) => setResetOtp(e.target.value)}
                        placeholder="6-digit OTP"
                        className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      New Strong Password (revokes all active sessions)
                    </label>
                    <input
                      type="password"
                      required
                      value={resetNewPass}
                      onChange={(e) => setResetNewPass(e.target.value)}
                      placeholder="12+ chars with upper, lower, number, symbol"
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs"
                  >
                    Reset Super Admin Password & Invalidate Old Sessions
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // AUTHENTICATED SUPER ADMIN MANAGEMENT DASHBOARD
  // ============================================================================
  const metrics = dashboard?.metrics || {};
  const activePermissions: string[] =
    dashboard?.actor?.permissions || currentUser.permissions || [];

  const filteredUsers = users.filter((u) => {
    if (!userSearch.trim()) return true;
    const q = userSearch.toLowerCase();
    return (
      u.full_name?.toLowerCase().includes(q) ||
      u.email?.toLowerCase().includes(q) ||
      u.role?.toLowerCase().includes(q) ||
      u.city?.toLowerCase().includes(q)
    );
  });

  const kpiCards = [
    { label: 'Total Registered Users', value: metrics.totalRegisteredUsers ?? 0, icon: Users, color: 'text-cyan-400' },
    { label: 'Total Companies', value: metrics.totalCompanies ?? 0, icon: Building2, color: 'text-blue-400' },
    { label: 'Total Branches', value: metrics.totalBranches ?? 0, icon: Store, color: 'text-indigo-400' },
    { label: 'Total Employees', value: metrics.totalEmployees ?? 0, icon: Briefcase, color: 'text-sky-400' },
    { label: 'Total Dealerships', value: metrics.totalDealerships ?? 0, icon: Building2, color: 'text-teal-400' },
    { label: 'Total Customers', value: metrics.totalCustomers ?? 0, icon: UserCheck, color: 'text-emerald-400' },
    { label: 'Total Vehicles', value: metrics.totalVehicles ?? 0, icon: Car, color: 'text-cyan-300' },
    { label: 'Total Vehicle Sales', value: metrics.totalVehicleSales ?? 0, icon: CheckCircle2, color: 'text-emerald-300' },
    { label: 'Total Bookings', value: metrics.totalBookings ?? 0, icon: CalendarCheck, color: 'text-blue-300' },
    { label: 'Total Revenue', value: formatPrice(metrics.totalRevenue ?? 0), icon: DollarSign, color: 'text-emerald-400' },
    { label: 'Pending Approvals', value: metrics.pendingApprovals ?? 0, icon: AlertTriangle, color: 'text-amber-400' },
    { label: 'System Notifications', value: metrics.systemNotifications ?? 0, icon: Bell, color: 'text-indigo-300' },
    { label: 'Recent Activities', value: metrics.recentActivities ?? 0, icon: Activity, color: 'text-cyan-400' },
    { label: 'Security Alerts', value: metrics.securityAlerts ?? 0, icon: ShieldAlert, color: 'text-rose-400' },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="rounded-3xl bg-slate-900 border border-cyan-500/30 p-6 space-y-5 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-lg bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                {currentUser.subjectType === 'founder'
                  ? 'FOUNDER OVERRIDE VIEW'
                  : 'SUPER ADMIN • EMAIL & 2FA VERIFIED'}
              </span>
              <span className="text-[11px] font-mono text-slate-400">{currentUser.email}</span>
            </div>
            <h2 className="text-2xl font-black text-white">
              Super Admin Operations & Management Center
            </h2>
            <p className="text-xs text-slate-400">
              Live SQLite governance for non-admin users, dealerships, vehicles, sales, support & operational settings.
              Founder / Owner authority remains strictly isolated.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => loadActiveTabData(dashTab)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 flex items-center gap-1.5 transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${dashLoading ? 'animate-spin' : ''}`} />
              <span>Refresh DB</span>
            </button>
            <button
              onClick={logoutUser}
              className="px-3.5 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 border border-rose-700/60 text-xs font-bold text-rose-200 flex items-center gap-1.5 transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Secure Logout</span>
            </button>
          </div>
        </div>

        {/* Active Granular Permissions Bar */}
        <div className="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 mr-1">
            Active RBAC Grants ({currentUser.subjectType === 'founder' ? 'ALL' : activePermissions.length}):
          </span>
          {(currentUser.subjectType === 'founder' ? ['FOUNDER_GLOBAL_ACCESS'] : activePermissions).map((p) => (
            <span
              key={p}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/70"
            >
              {p}
            </span>
          ))}
        </div>

        {/* Sub-Navigation */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'users', label: 'Users', icon: Users },
            { id: 'companies', label: 'Companies', icon: Building2 },
            { id: 'employees', label: 'Employees', icon: Briefcase },
            { id: 'employee-hub', label: 'Employee Management', icon: Users },
            { id: 'dealerships', label: 'Dealers', icon: Store },
            { id: 'dealership-hub', label: 'Dealership Hub', icon: Store },
            { id: 'customers', label: 'Customers', icon: UserCheck },
            { id: 'verification', label: 'Verification', icon: ShieldCheck },
            { id: 'permissions', label: 'Permissions', icon: KeyRound },
            { id: 'monitoring', label: 'Monitoring', icon: Activity },
            { id: 'reports', label: 'Reports & Export', icon: FileText },
            { id: 'vehicles', label: 'Vehicles', icon: Car },
            { id: 'bookings-sales', label: 'Bookings & Sales', icon: Wrench },
            { id: 'support', label: 'Support', icon: LifeBuoy },
            { id: 'notifications', label: 'Announcements', icon: Bell },
            { id: 'settings', label: 'Settings', icon: Settings },
            { id: 'audit-logs', label: 'Activity Logs', icon: Shield },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setDashTab(t.id as AdminDashTab)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition border whitespace-nowrap shrink-0 ${
                  dashTab === t.id
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-sm'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Banners */}
      {actionBanner && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionBanner}</span>
        </div>
      )}
      {tabError && (
        <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{tabError}</span>
        </div>
      )}

      {/* TAB 1: OVERVIEW (14 METRICS + QUEUES) */}
      {dashTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-7 gap-3">
            {kpiCards.map((k) => {
              const Icon = k.icon;
              return (
                <div
                  key={k.label}
                  className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase text-slate-400 leading-tight">
                      {k.label}
                    </span>
                    <Icon className={`w-4 h-4 shrink-0 ${k.color}`} />
                  </div>
                  <p className="text-lg font-black text-white">{k.value}</p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pending Dealership Approvals */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Store className="w-4 h-4 text-amber-400" />
                  <span>Pending Dealership / Branch Approvals</span>
                </h3>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                  {dashboard?.pendingDealerships?.length || 0} Pending
                </span>
              </div>
              {(!dashboard?.pendingDealerships || dashboard.pendingDealerships.length === 0) ? (
                <p className="text-xs text-slate-500 py-4 text-center">No pending dealership approvals.</p>
              ) : (
                <div className="space-y-3">
                  {dashboard.pendingDealerships.map((d: any) => (
                    <div key={d.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="text-xs space-y-0.5">
                        <p className="font-bold text-white">{d.name} ({d.code})</p>
                        <p className="text-slate-400">{d.city}, {d.country} • Manager: {d.manager_name}</p>
                        <p className="text-[11px] text-slate-500 font-mono">{d.email}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleDealershipStatus(d.id, 'Approved')}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleDealershipStatus(d.id, 'Rejected')}
                          className="px-3 py-1.5 rounded-lg bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-[11px] font-bold"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Super Admin Activity */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Recent Admin Activity Log</span>
              </h3>
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {(dashboard?.recentActivitiesList || []).map((act: any) => (
                  <div key={act.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-start justify-between gap-3">
                    <div>
                      <p className="font-bold text-cyan-300 font-mono text-[11px]">{act.action}</p>
                      <p className="text-slate-300">{act.details || act.target_id || act.module}</p>
                      <p className="text-[10px] text-slate-500">By {act.admin_name} ({act.ip_address})</p>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono shrink-0">
                      {act.created_at?.slice(11, 19)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: COMPANIES */}
      {dashTab === 'companies' && (
        <SuperAdminCompaniesPanel
          companies={companies}
          formatPrice={formatPrice}
          onRefresh={() => loadActiveTabData('companies')}
          onNotify={flashBanner}
        />
      )}

      {/* TAB 2B: EMPLOYEES */}
      {dashTab === 'employees' && (
        <SuperAdminEmployeesPanel companies={companies} onNotify={flashBanner} />
      )}

      {/* TAB 3: DEALERSHIPS & BRANCHES */}
      {dashTab === 'dealerships' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white">Dealerships, Branches & Pending Approvals</h3>
              <p className="text-xs text-slate-400">Approve pending dealer applications, suspend non-compliant branches, or register new facilities.</p>
            </div>
            <button
              onClick={() => setShowNewDealerForm(!showNewDealerForm)}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Register Dealership</span>
            </button>
          </div>

          {showNewDealerForm && (
            <form onSubmit={handleCreateDealer} className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <select
                value={newDealer.companyId}
                onChange={(e) => setNewDealer({ ...newDealer, companyId: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              >
                {(companies.length ? companies : [{ id: 'comp_byd_pk', name: 'Mega Motor Company (BYD Pakistan)' }]).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <input
                required
                placeholder="Dealership Name"
                value={newDealer.name}
                onChange={(e) => setNewDealer({ ...newDealer, name: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                placeholder="Code (e.g. RWP-01)"
                value={newDealer.code}
                onChange={(e) => setNewDealer({ ...newDealer, code: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white font-mono"
              />
              <input
                required
                placeholder="City"
                value={newDealer.city}
                onChange={(e) => setNewDealer({ ...newDealer, city: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                placeholder="Address"
                value={newDealer.address}
                onChange={(e) => setNewDealer({ ...newDealer, address: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                placeholder="Manager Name"
                value={newDealer.managerName}
                onChange={(e) => setNewDealer({ ...newDealer, managerName: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                placeholder="Phone"
                value={newDealer.phone}
                onChange={(e) => setNewDealer({ ...newDealer, phone: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                type="email"
                placeholder="Official Branch Email"
                value={newDealer.email}
                onChange={(e) => setNewDealer({ ...newDealer, email: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <button type="submit" className="rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs py-2">
                Save Dealership
              </button>
            </form>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Dealership</th>
                  <th className="py-3 px-4">City / Country</th>
                  <th className="py-3 px-4">Manager</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {dealerships.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-950/60">
                    <td className="py-3 px-4 font-mono font-bold text-cyan-300">{d.code}</td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-white">{d.name}</p>
                      <p className="text-[10px] text-slate-500">{d.company_name}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{d.city}, {d.country}</td>
                    <td className="py-3 px-4 text-slate-300">{d.manager_name}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        d.status === 'Approved'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                          : d.status === 'Pending Approval'
                          ? 'bg-amber-950 text-amber-300 border-amber-800'
                          : 'bg-rose-950 text-rose-300 border-rose-800'
                      }`}>
                        {d.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1.5">
                        {d.status !== 'Approved' && (
                          <button
                            onClick={() => handleDealershipStatus(d.id, 'Approved')}
                            className="px-2.5 py-1 rounded bg-emerald-600 text-white text-[10px] font-bold"
                          >
                            Approve
                          </button>
                        )}
                        {d.status === 'Pending Approval' && (
                          <button
                            onClick={() => handleDealershipStatus(d.id, 'Rejected')}
                            className="px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold"
                          >
                            Reject
                          </button>
                        )}
                        {d.status === 'Approved' && (
                          <button
                            onClick={() => handleDealershipStatus(d.id, 'Suspended')}
                            className="px-2.5 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-bold"
                          >
                            Suspend
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-4 border-t border-slate-800 space-y-6">
            <SuperAdminDealersAnalyticsPanel formatPrice={formatPrice} />
            <AdminDealerGovernancePanel scope="super-admin" />
          </div>
        </div>
      )}

      {/* TAB 3B: CUSTOMERS HUB (PRIVACY PROTECTED) */}
      {dashTab === 'customers' && (
        <SuperAdminCustomersHubPanel formatPrice={formatPrice} />
      )}

      {/* TAB 3C: ACCOUNT & COMPANY VERIFICATION HUB */}
      {dashTab === 'verification' && (
        <SuperAdminVerificationHubPanel onNotify={flashBanner} />
      )}

      {/* TAB 3D: ACCESS PERMISSIONS (6-ROLE RBAC MATRIX) */}
      {dashTab === 'permissions' && (
        <AdminVerificationApprovalPanel portalLabel="Super Admin" initialSubTab="rbac" />
      )}

      {/* TAB 3E: REAL-TIME SYSTEM MONITORING */}
      {dashTab === 'monitoring' && (
        <SuperAdminMonitoringPanel onNotify={flashBanner} />
      )}

      {/* TAB 4: UNIFIED USER MANAGEMENT (NON-ADMIN ONLY) */}
      {dashTab === 'users' && (
        <SuperAdminUsersPanel
          companies={companies}
          legacyUsers={users}
          userCategory={userCategory}
          onCategoryChange={setUserCategory}
          onRefreshLegacy={() => loadActiveTabData('users')}
          onNotify={flashBanner}
        />
      )}

      {/* TAB 5: VEHICLES REGISTRY */}
      {dashTab === 'vehicles' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h3 className="text-base font-bold text-white">Vehicle Master Inventory ({vehicles.length})</h3>
              <p className="text-xs text-slate-400">SQLite VIN registry, Blade Battery SoH monitoring, and sales completion status.</p>
            </div>
            <button
              onClick={() => setShowNewVehicleForm(!showNewVehicleForm)}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Vehicle</span>
            </button>
          </div>

          {showNewVehicleForm && (
            <form onSubmit={handleCreateVehicle} className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 grid grid-cols-1 sm:grid-cols-4 gap-3">
              <input
                required
                placeholder="VIN (min 8 chars)"
                value={newVehicleForm.vin}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, vin: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs font-mono text-white"
              />
              <input
                required
                placeholder="Model (e.g. BYD Seal)"
                value={newVehicleForm.model}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, model: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                required
                placeholder="Variant"
                value={newVehicleForm.variant}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, variant: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                placeholder="License Plate"
                value={newVehicleForm.licensePlate}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, licensePlate: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs font-mono text-white"
              />
              <input
                placeholder="Owner Name"
                value={newVehicleForm.ownerName}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, ownerName: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                placeholder="City"
                value={newVehicleForm.ownerCity}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, ownerCity: e.target.value })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <input
                type="number"
                placeholder="Price (PKR)"
                value={newVehicleForm.salePricePkr}
                onChange={(e) => setNewVehicleForm({ ...newVehicleForm, salePricePkr: Number(e.target.value) })}
                className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <button type="submit" className="rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs py-2">
                Register VIN
              </button>
            </form>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">VIN & Plate</th>
                  <th className="py-3 px-4">Model</th>
                  <th className="py-3 px-4">Owner & City</th>
                  <th className="py-3 px-4">SoH %</th>
                  <th className="py-3 px-4">Sale Price</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {vehicles.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-950/60">
                    <td className="py-3 px-4 font-mono">
                      <p className="text-cyan-300 font-bold">{v.license_plate}</p>
                      <p className="text-[10px] text-slate-500">{v.vin}</p>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-white">{v.model}</p>
                      <p className="text-[10px] text-slate-400">{v.variant}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{v.owner_name} ({v.owner_city})</td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{v.battery_health_soh}%</td>
                    <td className="py-3 px-4 text-white font-mono">{formatPrice(v.sale_price_pkr || 0)}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-[10px] font-bold">
                        {v.status} {v.sold_at ? '• Sold' : '• Stock'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {!v.sold_at && (
                        <button
                          onClick={() => handleUpdateVehicle(v.id, { markAsSold: true })}
                          className="px-2.5 py-1 rounded bg-emerald-600 text-white text-[10px] font-bold"
                        >
                          Mark Sold
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: BOOKINGS, SERVICE, WARRANTY & SALES */}
      {dashTab === 'bookings-sales' && (
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-white">Bookings Queue ({opsData?.bookings?.length || 0})</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Model / City</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {(opsData?.bookings || []).map((b) => (
                    <tr key={b.id}>
                      <td className="py-2.5 px-3 font-bold text-white">{b.customer_name}</td>
                      <td className="py-2.5 px-3 text-cyan-300">{b.booking_type}</td>
                      <td className="py-2.5 px-3 text-slate-300">{b.vehicle_model} • {b.city}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-400">{b.preferred_date}</td>
                      <td className="py-2.5 px-3">
                        <select
                          value={b.status}
                          onChange={(e) =>
                            api
                              .updateSuperAdminBookingStatus(b.id, e.target.value)
                              .then(() => {
                                flashBanner('Booking status updated.');
                                loadActiveTabData('bookings-sales');
                              })
                              .catch((err) => setTabError(err.message))
                          }
                          className="rounded-lg bg-slate-950 border border-slate-700 px-2 py-1 text-[11px] text-white"
                        >
                          <option value="Confirmed">Confirmed</option>
                          <option value="Pending">Pending</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Warranty Claims */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-white">Warranty Claims ({opsData?.warrantyClaims?.length || 0})</h3>
              <div className="space-y-3">
                {(opsData?.warrantyClaims || []).map((c) => (
                  <div key={c.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <p className="font-mono font-bold text-cyan-300">{c.claim_number}</p>
                      <p className="text-white font-semibold">{c.vehicle_model} — {c.component_category}</p>
                      <p className="text-slate-400">{formatPrice(c.claim_amount_pkr || 0)} • Status: {c.status}</p>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() =>
                          api
                            .updateSuperAdminWarrantyClaim(c.id, { status: 'Approved', reviewNotes: 'Approved by Super Admin' })
                            .then(() => {
                              flashBanner(`Claim ${c.claim_number} approved.`);
                              loadActiveTabData('bookings-sales');
                            })
                            .catch((err) => setTabError(err.message))
                        }
                        className="px-2.5 py-1 rounded bg-emerald-600 text-white text-[10px] font-bold"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() =>
                          api
                            .updateSuperAdminWarrantyClaim(c.id, { status: 'Rejected', reviewNotes: 'Rejected after review' })
                            .then(() => {
                              flashBanner(`Claim ${c.claim_number} rejected.`);
                              loadActiveTabData('bookings-sales');
                            })
                            .catch((err) => setTabError(err.message))
                        }
                        className="px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Invoices & Vehicle Sales */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
              <h3 className="text-sm font-bold text-white">Invoices & Sales ({opsData?.invoices?.length || 0})</h3>
              <div className="space-y-2.5">
                {(opsData?.invoices || []).map((inv) => (
                  <div key={inv.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-mono font-bold text-white">{inv.invoice_number}</p>
                      <p className="text-slate-400">{inv.customer_name} • {inv.payment_gateway}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-emerald-400">{formatPrice(inv.total_amount || 0)}</p>
                      <span className="text-[10px] text-slate-400">{inv.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: ENTERPRISE REPORTS & ANALYTICS (WITH DAILY/WEEKLY/MONTHLY/YEARLY/CUSTOM & EXPORT) */}
      {dashTab === 'reports' && (
        <div className="space-y-6">
          <SuperAdminReportsPanel formatPrice={formatPrice} />
          {reports && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
                <h3 className="text-sm font-bold text-white">Regional Dealership Targets vs Achieved</h3>
                <div className="space-y-2">
                  {(reports.regionalDealerships || []).map((r: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-white">{r.city}, {r.country}</p>
                        <p className="text-slate-400">{r.branches} branches • {r.achievedUnits}/{r.targetUnits} units</p>
                      </div>
                      <p className="font-bold text-emerald-400">{formatPrice(r.monthlyRevenuePkr || 0)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
                <h3 className="text-sm font-bold text-white">Fleet Breakdown by Model &amp; SoH</h3>
                <div className="space-y-2">
                  {(reports.vehiclesByModel || []).map((m: any) => (
                    <div key={m.model} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-white">{m.model}</p>
                        <p className="text-slate-400">Total: {m.totalUnits} • Sold: {m.soldUnits}</p>
                      </div>
                      <span className="font-bold text-cyan-400">Avg SoH: {m.avgSoh}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 8: SUPPORT REQUESTS */}
      {dashTab === 'support' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h3 className="text-base font-bold text-white">Support Requests & Escalations ({tickets.length})</h3>
            <button
              onClick={() => setShowNewTicketForm(!showNewTicketForm)}
              className="px-3.5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Ticket</span>
            </button>
          </div>

          {showNewTicketForm && (
            <form onSubmit={handleCreateTicket} className="p-4 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  required
                  placeholder="Subject"
                  value={newTicket.subject}
                  onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                />
                <input
                  placeholder="Category"
                  value={newTicket.category}
                  onChange={(e) => setNewTicket({ ...newTicket, category: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                />
                <select
                  value={newTicket.priority}
                  onChange={(e) => setNewTicket({ ...newTicket, priority: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>
              <textarea
                required
                rows={2}
                placeholder="Ticket details..."
                value={newTicket.description}
                onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                className="w-full rounded-xl bg-slate-900 border border-slate-800 px-3 py-2 text-xs text-white"
              />
              <button type="submit" className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs">
                Create Support Ticket
              </button>
            </form>
          )}

          <div className="space-y-3">
            {tickets.map((t) => (
              <div key={t.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-cyan-300">{t.ticket_number}</span>
                    <span className="font-bold text-white">{t.subject}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300 text-[10px] font-bold">{t.priority}</span>
                  </div>
                  <p className="text-slate-400">{t.description}</p>
                  <p className="text-[11px] text-slate-500">Requester: {t.requester_name} ({t.requester_email}) • Assigned: {t.assigned_to}</p>
                </div>
                <select
                  value={t.status}
                  onChange={(e) => handleUpdateTicket(t.id, { status: e.target.value })}
                  className="rounded-xl bg-slate-900 border border-slate-700 px-3 py-1.5 text-xs text-white self-start"
                >
                  <option value="Open">Open</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Closed">Closed</option>
                </select>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 9: SYSTEM NOTIFICATIONS */}
      {dashTab === 'notifications' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleCreateNotification} className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-3">
            <h3 className="text-sm font-bold text-white">Broadcast Announcement</h3>
            <input
              required
              placeholder="Title"
              value={newNotif.title}
              onChange={(e) => setNewNotif({ ...newNotif, title: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white"
            />
            <select
              value={newNotif.category}
              onChange={(e) => setNewNotif({ ...newNotif, category: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white"
            >
              <option value="Announcement">Announcement</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Policy">Policy</option>
            </select>
            <textarea
              required
              rows={3}
              placeholder="Announcement message..."
              value={newNotif.message}
              onChange={(e) => setNewNotif({ ...newNotif, message: e.target.value })}
              className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-xs text-white"
            />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs">
              Publish System Notification
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-3">
            <h3 className="text-sm font-bold text-white">Published System Notifications ({notifications.length})</h3>
            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {notifications.map((n) => (
                <div key={n.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{n.title}</span>
                    <span className="text-[10px] font-mono text-cyan-400">{n.category}</span>
                  </div>
                  <p className="text-slate-300">{n.message}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 10: PERMITTED APPLICATION SETTINGS */}
      {dashTab === 'settings' && opSettings && (
        <form onSubmit={handleSaveSettings} className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 max-w-3xl">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Permitted Operational Application Settings</h3>
            <p className="text-xs text-slate-400">
              Founder-level <span className="font-mono text-amber-300">security_policy</span> and{' '}
              <span className="font-mono text-amber-300">ai_config</span> are locked exclusively in the Founder / Owner Portal.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Default Support Email</label>
              <input
                value={opSettings.defaultSupportEmail || ''}
                onChange={(e) => setOpSettings({ ...opSettings, defaultSupportEmail: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Toll-Free Helpline</label>
              <input
                value={opSettings.tollFreeHelpline || ''}
                onChange={(e) => setOpSettings({ ...opSettings, tollFreeHelpline: e.target.value })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Service Booking SLA (Hours)</label>
              <input
                type="number"
                value={opSettings.serviceSlaHours ?? 24}
                onChange={(e) => setOpSettings({ ...opSettings, serviceSlaHours: Number(e.target.value) })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">Warranty Review SLA (Hours)</label>
              <input
                type="number"
                value={opSettings.warrantyReviewSlaHours ?? 48}
                onChange={(e) => setOpSettings({ ...opSettings, warrantyReviewSlaHours: Number(e.target.value) })}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 px-3 py-2 text-white"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-6 text-xs text-slate-200">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={Boolean(opSettings.bookingAutoConfirm)}
                onChange={(e) => setOpSettings({ ...opSettings, bookingAutoConfirm: e.target.checked })}
              />
              <span>Auto-confirm Standard Service Bookings</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={Boolean(opSettings.maintenanceBannerEnabled)}
                onChange={(e) => setOpSettings({ ...opSettings, maintenanceBannerEnabled: e.target.checked })}
              />
              <span>Show Scheduled Maintenance Banner</span>
            </label>
          </div>

          <button type="submit" className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs">
            Save Operational Settings
          </button>
        </form>
      )}

      {/* TAB 11: IMMUTABLE ACTIVITY LOGS & SECURITY AUDIT */}
      {dashTab === 'audit-logs' && (
        <SuperAdminActivityLogsPanel />
      )}

      {dashTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {dashTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
