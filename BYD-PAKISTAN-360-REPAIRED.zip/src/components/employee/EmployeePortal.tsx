import React, { useState, useEffect, useCallback } from 'react';
import {
  BadgeCheck,
  Shield,
  Lock,
  KeyRound,
  Mail,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  LogOut,
  RefreshCw,
  User,
  Clock,
  Calendar,
  ClipboardList,
  DollarSign,
  FileText,
  TrendingUp,
  Bell,
  LifeBuoy,
  Monitor,
  History,
  Trash2,
  Upload,
  Download,
  Camera,
  Play,
  Check,
  XCircle,
  MessageSquarePlus,
  Building2,
  Printer,
  Send,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AccountSecurityCenter } from '../auth/AccountSecurityCenter';
import { EmployeeManagementHub } from './EmployeeManagementHub';
import { DealershipManagementHub } from '../dealer/DealershipManagementHub';

type EmployeeSubTab =
  | 'overview'
  | 'profile'
  | 'employee-hub'
  | 'dealership-hub'
  | 'attendance'
  | 'leaves'
  | 'tasks'
  | 'salary'
  | 'documents'
  | 'performance'
  | 'communications'
  | 'support'
  | 'security';

type AuthStep = 'login' | 'verify-email' | '2fa' | 'forgot-password';

export const EmployeePortal: React.FC = () => {
  const { currentUser, isAuthenticated, loginUser, logoutUser, setActiveTab } = useApp();
  const isEmployeeSession = isAuthenticated && currentUser.subjectType === 'employee';

  // ---------------- All React Hooks Declared Unconditionally at Top ----------------
  const [statusLoading, setStatusLoading] = useState(true);
  const [portalStatus, setPortalStatus] = useState<{
    hasEmployees: boolean;
    twoFactorRequired: boolean;
    emailVerificationRequired: boolean;
    portalIsolated: boolean;
  } | null>(null);

  // Auth Flow State
  const [authStep, setAuthStep] = useState<AuthStep>('login');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [identifier, setIdentifier] = useState('');
  const [employeeCodeCheck, setEmployeeCodeCheck] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [pendingEmail, setPendingEmail] = useState('');
  const [pendingEmpMeta, setPendingEmpMeta] = useState<{ fullName?: string; employeeCode?: string; department?: string }>({});
  const [emailOtpCode, setEmailOtpCode] = useState('');
  const [devEmailOtpHint, setDevEmailOtpHint] = useState<string | null>(null);

  const [challengeToken, setChallengeToken] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [devLoginOtpHint, setDevLoginOtpHint] = useState<string | null>(null);
  const [suspiciousAlert, setSuspiciousAlert] = useState(false);

  const [forgotEmail, setForgotEmail] = useState('');
  const [resetStage, setResetStage] = useState<'request' | 'confirm'>('request');
  const [resetToken, setResetToken] = useState('');
  const [resetOtpCode, setResetOtpCode] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [devResetHint, setDevResetHint] = useState<{ resetToken?: string; otpCode?: string } | null>(null);

  // Authenticated Workspace State
  const [empTab, setEmpTab] = useState<EmployeeSubTab>('overview');
  const [banner, setBanner] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [loadingDash, setLoadingDash] = useState(false);
  const [dashboard, setDashboard] = useState<any>(null);

  // Module 2: Profile
  const [profileData, setProfileData] = useState<any>(null);
  const [profileForm, setProfileForm] = useState({
    mobile: '',
    bio: '',
    address: '',
    city: 'Karachi',
    dateOfBirth: '',
    gender: '',
    cnicOrId: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelation: 'Family',
    skillsText: '',
  });
  const [photoFile, setPhotoFile] = useState<File | null>(null);

  // Module 3: Attendance
  const [attendanceData, setAttendanceData] = useState<any>(null);
  const [workMode, setWorkMode] = useState<'On-Site' | 'Remote' | 'Field Duty'>('On-Site');
  const [punchNotes, setPunchNotes] = useState('');
  const [corrDate, setCorrDate] = useState(new Date().toISOString().slice(0, 10));
  const [corrReason, setCorrReason] = useState('');

  // Module 4: Leaves
  const [leaveData, setLeaveData] = useState<any>(null);
  const [leaveForm, setLeaveForm] = useState({
    leaveType: 'Annual Leave',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    reason: '',
  });
  const [leaveFile, setLeaveFile] = useState<File | null>(null);

  // Module 5: Tasks
  const [tasks, setTasks] = useState<any[]>([]);
  const [taskFilter, setTaskFilter] = useState<'All' | 'Pending' | 'In Progress' | 'Completed'>('All');
  const [taskNoteDrafts, setTaskNoteDrafts] = useState<Record<string, string>>({});
  const [taskFiles, setTaskFiles] = useState<Record<string, File | null>>({});

  // Module 6: Salary
  const [salaryData, setSalaryData] = useState<any>(null);
  const [salaryLockedMsg, setSalaryLockedMsg] = useState('');
  const [activeSlip, setActiveSlip] = useState<any>(null);

  // Module 7: Documents
  const [documents, setDocuments] = useState<any[]>([]);
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState('Employment Document');
  const [docFile, setDocFile] = useState<File | null>(null);

  // Module 8: Performance
  const [perfData, setPerfData] = useState<any>(null);

  // Module 9: Communications
  const [comms, setComms] = useState<any[]>([]);

  // Module 10: Support
  const [tickets, setTickets] = useState<any[]>([]);
  const [supportForm, setSupportForm] = useState({
    category: 'HR Query',
    priority: 'Medium',
    subject: '',
    description: '',
  });

  // Module 11: Security & Sessions
  const [sessions, setSessions] = useState<any[]>([]);
  const [loginHistory, setLoginHistory] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  // ---------------- Data Loaders ----------------
  const loadPortalStatus = useCallback(async () => {
    setStatusLoading(true);
    try {
      const s = await api.getEmployeeAuthStatus();
      setPortalStatus(s);
    } catch {
      // ignore
    } finally {
      setStatusLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPortalStatus();
  }, [loadPortalStatus]);

  const loadWorkspaceTab = useCallback(
    async (tabToLoad: EmployeeSubTab) => {
      if (!isEmployeeSession) return;
      setLoadingDash(true);
      try {
        const dash = await api.getEmployeeDashboard();
        setDashboard(dash);

        if (tabToLoad === 'profile') {
          const p = await api.getEmployeeProfile();
          setProfileData(p);
          setProfileForm({
            mobile: p.employee?.mobile || '',
            bio: p.profile?.bio || '',
            address: p.profile?.address || '',
            city: p.profile?.city || 'Karachi',
            dateOfBirth: p.profile?.dateOfBirth || '',
            gender: p.profile?.gender || '',
            cnicOrId: p.profile?.cnicOrId || '',
            emergencyContactName: p.profile?.emergencyContactName || '',
            emergencyContactPhone: p.profile?.emergencyContactPhone || '',
            emergencyContactRelation: p.profile?.emergencyContactRelation || 'Family',
            skillsText: Array.isArray(p.profile?.skills) ? p.profile.skills.join(', ') : '',
          });
        } else if (tabToLoad === 'attendance') {
          const a = await api.getEmployeeAttendance();
          setAttendanceData(a);
        } else if (tabToLoad === 'leaves') {
          const l = await api.getEmployeeLeaves();
          setLeaveData(l);
        } else if (tabToLoad === 'tasks') {
          const t = await api.getEmployeeTasks();
          setTasks(t.tasks || []);
        } else if (tabToLoad === 'salary') {
          try {
            setSalaryLockedMsg('');
            const sal = await api.getEmployeeSalary();
            setSalaryData(sal);
          } catch (err: any) {
            setSalaryData(null);
            setSalaryLockedMsg(err.message || 'Salary viewing permission not assigned to this account.');
          }
        } else if (tabToLoad === 'documents') {
          const d = await api.getEmployeeDocuments();
          setDocuments(d.documents || []);
        } else if (tabToLoad === 'performance') {
          const pf = await api.getEmployeePerformance();
          setPerfData(pf);
        } else if (tabToLoad === 'communications') {
          const cm = await api.getEmployeeCommunications();
          setComms(cm.notifications || []);
        } else if (tabToLoad === 'support') {
          const sp = await api.getEmployeeSupportTickets();
          setTickets(sp.tickets || []);
        } else if (tabToLoad === 'security') {
          const [s, h, l] = await Promise.all([
            api.getEmployeeSessions(),
            api.getEmployeeLoginHistory(),
            api.getEmployeeAuditLogs(),
          ]);
          setSessions(s.sessions || []);
          setLoginHistory(h.history || []);
          setAuditLogs(l.logs || []);
        }
      } catch (err: any) {
        setBanner({ type: 'err', text: err.message || 'Unable to load Employee Portal data.' });
      } finally {
        setLoadingDash(false);
      }
    },
    [isEmployeeSession]
  );

  useEffect(() => {
    if (isEmployeeSession) {
      loadWorkspaceTab(empTab);
    }
  }, [isEmployeeSession, empTab, loadWorkspaceTab]);

  // ---------------- Auth Action Handlers ----------------
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.employeeLogin({
        identifier: identifier.trim(),
        password,
        employeeCodeCheck: employeeCodeCheck.trim() || undefined,
      });
      setPassword('');
      setPendingEmpMeta({
        fullName: res.fullName,
        employeeCode: res.employeeCode,
        department: res.department,
      });

      if (res.requiresEmailVerification && res.email) {
        setPendingEmail(res.email);
        setDevEmailOtpHint(res.verificationOutbox?.code || null);
        setAuthStep('verify-email');
        setAuthSuccess(res.message || 'Email verification required before entering Employee Workspace.');
        return;
      }

      if (res.requires2FA && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setSuspiciousAlert(Boolean(res.suspiciousIpDetected));
        setDevLoginOtpHint(res.otpOutbox?.code || null);
        setAuthStep('2fa');
        setAuthSuccess(res.message || 'Enter your 2FA code to complete Employee Portal sign-in.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Employee authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.employeeVerifyEmail({ email: pendingEmail, code: emailOtpCode.trim() });
      setEmailOtpCode('');
      setChallengeToken(res.challengeToken);
      setDevLoginOtpHint(res.otpOutbox?.code || null);
      setAuthStep('2fa');
      setAuthSuccess('Email verified. Complete Two-Factor Authentication below.');
    } catch (err: any) {
      setAuthError(err.message || 'Invalid verification code.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.employeeVerify2FA({ challengeToken, code: twoFactorCode.trim() });
      setTwoFactorCode('');
      loginUser(res.user);
    } catch (err: any) {
      setAuthError(err.message || 'Invalid 2FA verification code.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.employeeForgotPassword(forgotEmail.trim());
      setDevResetHint(res.resetOutbox ? { resetToken: res.resetOutbox.resetToken, otpCode: res.resetOutbox.otpCode } : null);
      setResetStage('confirm');
      setAuthSuccess(res.message);
    } catch (err: any) {
      setAuthError(err.message || 'Unable to process password reset request.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setAuthSubmitting(true);
    try {
      const res = await api.employeeResetPassword({
        token: resetToken.trim(),
        otpCode: resetOtpCode.trim() || undefined,
        newPassword: resetNewPassword,
      });
      setResetNewPassword('');
      setResetToken('');
      setResetOtpCode('');
      setResetStage('request');
      setAuthStep('login');
      setAuthSuccess(res.message || 'Password updated. All previous employee sessions revoked.');
    } catch (err: any) {
      setAuthError(err.message || 'Password reset failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  // ---------------- Workspace Mutation Handlers ----------------
  const handleCheckIn = async () => {
    setBanner(null);
    try {
      const res = await api.employeeCheckIn({ workMode, notes: punchNotes.trim() || undefined });
      setPunchNotes('');
      setBanner({ type: 'ok', text: `Checked in (${res.record?.status}) at ${String(res.record?.check_in_at).slice(11, 19)} UTC.` });
      await loadWorkspaceTab(empTab);
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleCheckOut = async () => {
    setBanner(null);
    try {
      const res = await api.employeeCheckOut({ notes: punchNotes.trim() || undefined });
      setPunchNotes('');
      setBanner({ type: 'ok', text: `Checked out cleanly. Total hours worked today: ${res.workingHours}h.` });
      await loadWorkspaceTab(empTab);
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setBanner(null);
    try {
      await api.updateEmployeeProfile({
        mobile: profileForm.mobile,
        bio: profileForm.bio,
        address: profileForm.address,
        city: profileForm.city,
        dateOfBirth: profileForm.dateOfBirth || undefined,
        gender: profileForm.gender || undefined,
        cnicOrId: profileForm.cnicOrId || undefined,
        emergencyContactName: profileForm.emergencyContactName,
        emergencyContactPhone: profileForm.emergencyContactPhone,
        emergencyContactRelation: profileForm.emergencyContactRelation,
        skills: profileForm.skillsText.split(',').map((s) => s.trim()).filter(Boolean),
      });
      setBanner({ type: 'ok', text: 'Personal profile and emergency contacts saved.' });
      await loadWorkspaceTab('profile');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handlePhotoUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoFile) return;
    setBanner(null);
    try {
      await api.uploadEmployeePhoto(photoFile);
      setPhotoFile(null);
      setBanner({ type: 'ok', text: 'Private employee photograph updated securely.' });
      await loadWorkspaceTab('profile');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleCorrectionRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setBanner(null);
    try {
      const res = await api.employeeCorrectionRequest({ attendanceDate: corrDate, reason: corrReason });
      setCorrReason('');
      setBanner({ type: 'ok', text: res.message });
      await loadWorkspaceTab('attendance');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleApplyLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    setBanner(null);
    try {
      await api.applyEmployeeLeave({
        ...leaveForm,
        supportingDocument: leaveFile,
      });
      setLeaveForm({ ...leaveForm, reason: '' });
      setLeaveFile(null);
      setBanner({ type: 'ok', text: 'Leave request submitted for Branch Manager / HR approval.' });
      await loadWorkspaceTab('leaves');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleCancelLeave = async (id: string) => {
    setBanner(null);
    try {
      await api.cancelEmployeeLeave(id);
      setBanner({ type: 'ok', text: 'Pending leave request cancelled.' });
      await loadWorkspaceTab('leaves');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleUploadDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docFile || !docTitle.trim()) return;
    setBanner(null);
    try {
      await api.uploadEmployeeDocument({ title: docTitle.trim(), category: docCategory, file: docFile });
      setDocTitle('');
      setDocFile(null);
      setBanner({ type: 'ok', text: 'Document encrypted and stored in your private Employee Vault.' });
      await loadWorkspaceTab('documents');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBanner(null);
    try {
      const res = await api.createEmployeeSupportTicket(supportForm);
      setSupportForm({ category: 'HR Query', priority: 'Medium', subject: '', description: '' });
      setBanner({ type: 'ok', text: `Support ticket ${res.ticketNumber} opened with HR / IT Help Desk.` });
      await loadWorkspaceTab('support');
    } catch (err: any) {
      setBanner({ type: 'err', text: err.message });
    }
  };

  // ---------------- AUTHENTICATION GATE (UNAUTHENTICATED OR NON-EMPLOYEE) ----------------
  if (!isEmployeeSession) {
    return (
      <div className="max-w-3xl mx-auto py-6 space-y-6">
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center">
                <BadgeCheck className="w-6 h-6 text-teal-400" />
              </div>
              <div>
                <h1 className="text-xl font-extrabold text-white tracking-tight">
                  Dedicated Employee Login Portal
                </h1>
                <p className="text-xs text-slate-400">
                  BYD PAKISTAN 360 • Founder &amp; CEO: Intekhab Alam • Personal Staff Workspace
                </p>
              </div>
            </div>
            <span className="self-start sm:self-auto px-3 py-1 rounded-lg bg-teal-950/60 border border-teal-500/30 text-[11px] font-bold text-teal-300 uppercase tracking-wider whitespace-nowrap">
              2FA + Individual Account
            </span>
          </div>

          {/* Segregated Non-Employee Session Notice */}
          {isAuthenticated && currentUser.subjectType !== 'employee' && (
            <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-start gap-2.5 text-amber-200">
                <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Portal Isolation Active</div>
                  <p className="text-amber-200/80">
                    Currently authenticated as <strong>{currentUser.name}</strong> ({currentUser.role}). Employee workspaces require an individual Employee Login.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => logoutUser()}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-semibold whitespace-nowrap"
                >
                  Sign Out First
                </button>
                <button
                  onClick={() => setActiveTab('landing')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-semibold whitespace-nowrap"
                >
                  Return
                </button>
              </div>
            </div>
          )}

          {authError && (
            <div className="p-3.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-xs text-rose-200 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{authError}</span>
            </div>
          )}

          {authSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs text-emerald-200 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>{authSuccess}</span>
            </div>
          )}

          {statusLoading ? (
            <div className="py-10 text-center text-xs text-slate-400">Verifying Employee Authentication Gateway...</div>
          ) : (
            <>
              {authStep === 'login' && (
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Employee Email, ID, Username, or Mobile
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          required
                          value={identifier}
                          onChange={(e) => setIdentifier(e.target.value)}
                          placeholder="EMP-PK-102 or name@byd.demo"
                          className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-teal-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Employee ID Verification <span className="text-slate-500">(Optional)</span>
                      </label>
                      <div className="relative">
                        <BadgeCheck className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                        <input
                          type="text"
                          value={employeeCodeCheck}
                          onChange={(e) => setEmployeeCodeCheck(e.target.value)}
                          placeholder="e.g. EMP-PK-102"
                          className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white focus:border-teal-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-slate-300">Employee Password</label>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthError('');
                          setAuthSuccess('');
                          setAuthStep('forgot-password');
                        }}
                        className="text-xs text-teal-400 hover:text-teal-300"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your individual password"
                        className="w-full pl-9 pr-10 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:border-teal-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={authSubmitting}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-teal-600/20 disabled:opacity-50"
                  >
                    {authSubmitting ? 'Verifying Employee Credentials...' : 'Authenticate Employee Account'}
                  </button>

                  {/* Employee Directory Hint Bar (Autofills Employee ID & Email ONLY — No Passwords) */}
                  <div className="pt-4 border-t border-slate-800 space-y-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Registered Employee Directory (Password &amp; 2FA Required)
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {[
                        { code: 'EMP-PK-102', name: 'Mansoor Akhtar (PK Sales)', email: 'mansoor.sales@megamotor.demo' },
                        { code: 'EMP-PK-103', name: 'Bilal Hashmi (PK Service)', email: 'bilal.hashmi@bydisb.demo' },
                        { code: 'EMP-AE-106', name: 'Fatima Al-Zahra (UAE Ops)', email: 'fatima.alzahra@byduae.demo' },
                      ].map((emp) => (
                        <button
                          key={emp.code}
                          type="button"
                          onClick={() => {
                            setIdentifier(emp.email);
                            setEmployeeCodeCheck(emp.code);
                          }}
                          className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-teal-500/40 text-left text-[11px]"
                        >
                          <div className="font-mono font-bold text-teal-300">{emp.code}</div>
                          <div className="font-semibold text-white truncate">{emp.name}</div>
                          <div className="text-[10px] text-slate-400 truncate">{emp.email}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                </form>
              )}

              {authStep === 'verify-email' && (
                <form onSubmit={handleVerifyEmail} className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-teal-500/30 space-y-1.5 text-xs">
                    <div className="font-bold text-teal-300">Employee Email Verification Required</div>
                    <p className="text-slate-300">
                      Enter the 6-digit verification code sent to <strong>{pendingEmail}</strong>.
                    </p>
                    {devEmailOtpHint && (
                      <p className="text-amber-300 font-mono">
                        Simulated Mailer Outbox: <strong>{devEmailOtpHint}</strong>
                      </p>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={emailOtpCode}
                    onChange={(e) => setEmailOtpCode(e.target.value)}
                    placeholder="Enter 6-digit verification OTP"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-teal-300"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs"
                    >
                      {authSubmitting ? 'Verifying...' : 'Verify Email & Continue to 2FA'}
                    </button>
                  </div>
                </form>
              )}

              {authStep === '2fa' && (
                <form onSubmit={handleVerify2FA} className="space-y-4">
                  {suspiciousAlert && (
                    <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-500/40 text-xs text-amber-200">
                      New login IP detected for <strong>{pendingEmpMeta.employeeCode}</strong>. Two-Factor Authentication is mandatory.
                    </div>
                  )}
                  <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-1.5 text-xs">
                    <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                      <KeyRound className="w-4 h-4" />
                      <span>Two-Factor Authentication ({pendingEmpMeta.employeeCode || 'Employee'})</span>
                    </div>
                    <p className="text-slate-300">
                      Enter your 6-digit Authenticator TOTP code, single-use Email OTP, or Recovery Code.
                    </p>
                    {devLoginOtpHint && (
                      <p className="text-amber-300 font-mono">
                        Simulated Mailer Outbox OTP: <strong>{devLoginOtpHint}</strong>
                      </p>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    value={twoFactorCode}
                    onChange={(e) => setTwoFactorCode(e.target.value)}
                    placeholder="Enter 6-digit 2FA or Recovery Code"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-center text-lg font-mono tracking-widest text-cyan-300"
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAuthStep('login')}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={authSubmitting}
                      className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 text-white font-bold text-xs"
                    >
                      {authSubmitting ? 'Establishing Employee Session...' : 'Complete Sign In'}
                    </button>
                  </div>
                </form>
              )}

              {authStep === 'forgot-password' && (
                <div className="space-y-4">
                  {resetStage === 'request' ? (
                    <form onSubmit={handleForgotPassword} className="space-y-4">
                      <div className="text-xs text-slate-300">
                        Request a secure password reset token and OTP for your individual Employee account.
                      </div>
                      <input
                        type="email"
                        required
                        value={forgotEmail}
                        onChange={(e) => setForgotEmail(e.target.value)}
                        placeholder="employee@byd.demo"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setAuthStep('login')}
                          className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                        >
                          Back
                        </button>
                        <button
                          type="submit"
                          disabled={authSubmitting}
                          className="flex-1 py-2.5 rounded-xl bg-teal-600 text-white font-bold text-xs"
                        >
                          {authSubmitting ? 'Dispatching...' : 'Send Reset Token & OTP'}
                        </button>
                      </div>
                    </form>
                  ) : (
                    <form onSubmit={handleResetPassword} className="space-y-3">
                      {devResetHint && (
                        <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 text-[11px] font-mono text-amber-300 space-y-1">
                          <div>Simulated Mailer Reset Token: {devResetHint.resetToken}</div>
                          <div>OTP Code: {devResetHint.otpCode}</div>
                        </div>
                      )}
                      <input
                        type="text"
                        required
                        value={resetToken}
                        onChange={(e) => setResetToken(e.target.value)}
                        placeholder="Reset Token"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white"
                      />
                      <input
                        type="text"
                        value={resetOtpCode}
                        onChange={(e) => setResetOtpCode(e.target.value)}
                        placeholder="6-Digit OTP Code"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white"
                      />
                      <input
                        type="password"
                        required
                        minLength={8}
                        value={resetNewPassword}
                        onChange={(e) => setResetNewPassword(e.target.value)}
                        placeholder="New Password (min 8 chars, mixed case + number)"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setResetStage('request');
                            setAuthStep('login');
                          }}
                          className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={authSubmitting}
                          className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs"
                        >
                          Reset Password &amp; Revoke Sessions
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </>
          )}

          <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
            <span>Provisioned Accounts: {portalStatus?.hasEmployees ? 'Active in DB' : 'None'}</span>
            <span>Security: Individual Identity • Server RBAC • Private Document Vault</span>
          </div>
        </div>
      </div>
    );
  }

  // ---------------- AUTHENTICATED PERSONAL EMPLOYEE WORKSPACE ----------------
  const emp = dashboard?.employee;
  const metrics = dashboard?.metrics || {};
  const todayAtt = dashboard?.todayAttendance;
  const unreadComms = metrics.unreadNotificationsCount ?? 0;

  const navTabs: { id: EmployeeSubTab; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'overview', label: 'Overview', icon: BadgeCheck },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'employee-hub', label: 'Employee Hub', icon: Building2 },
    { id: 'dealership-hub', label: 'Dealership Ops', icon: Building2 },
    { id: 'attendance', label: 'Attendance', icon: Clock },
    { id: 'leaves', label: 'Leaves', icon: Calendar },
    { id: 'tasks', label: 'My Tasks', icon: ClipboardList, badge: metrics.pendingTasksCount },
    { id: 'salary', label: 'Salary & Slips', icon: DollarSign },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'performance', label: 'Performance', icon: TrendingUp },
    { id: 'communications', label: 'Inbox', icon: Bell, badge: unreadComms },
    { id: 'support', label: 'HR Support', icon: LifeBuoy },
    { id: 'security', label: 'Security', icon: Shield },
  ];

  const filteredTasks = tasks.filter((t) => (taskFilter === 'All' ? true : t.status === taskFilter));

  return (
    <div className="space-y-6 pb-10">
      {/* Personal Employee Identity Header */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-slate-950 border border-slate-700 overflow-hidden flex items-center justify-center shrink-0">
              {emp?.photoUrl ? (
                <img
                  src={`${emp.photoUrl}?inline=1`}
                  alt={emp.fullName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-lg font-extrabold text-teal-400">
                  {(emp?.fullName || currentUser.name || 'E').slice(0, 2).toUpperCase()}
                </span>
              )}
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-lg sm:text-xl font-extrabold text-white">
                  {emp?.fullName || currentUser.name}
                </h1>
                <span className="px-2 py-0.5 rounded bg-teal-950 border border-teal-500/30 text-[11px] font-mono font-bold text-teal-300">
                  {emp?.employeeCode || currentUser.employeeCode}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/30 text-[11px] font-semibold text-emerald-300">
                  {emp?.status || 'Active'}
                </span>
              </div>
              <div className="text-xs text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span>{emp?.jobPosition || currentUser.role}</span>
                <span className="text-slate-600">•</span>
                <span>{emp?.department || currentUser.department}</span>
                <span className="text-slate-600">•</span>
                <span>{emp?.branchName || currentUser.branchName}</span>
                <span className="text-slate-600">•</span>
                <span>{emp?.companyName} ({emp?.countryName})</span>
              </div>
              <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1 tabular-nums">
                <span>Reporting Manager: <strong className="text-slate-200">{emp?.reportingManagerName}</strong></span>
                <span className="text-slate-600">•</span>
                <span>Joined: {emp?.joiningDate?.slice(0, 10) || '—'}</span>
                <span className="text-slate-600">•</span>
                <span>Shift: {emp?.shiftSchedule || 'Mon-Sat 09:00-18:00'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => loadWorkspaceTab(empTab)}
              disabled={loadingDash}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs font-semibold text-slate-300 whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingDash ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <button
              onClick={() => logoutUser()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-950/50 border border-rose-500/30 hover:bg-rose-900/60 text-xs font-bold text-rose-300 whitespace-nowrap"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Bar */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto pb-1">
          {navTabs.map((item) => {
            const Icon = item.icon;
            const active = empTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setBanner(null);
                  setEmpTab(item.id);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition ${
                  active
                    ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
                {typeof item.badge === 'number' && item.badge > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-teal-500 text-slate-950 text-[10px] font-bold tabular-nums">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {banner && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-2 ${
            banner.type === 'ok'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/50 border-rose-500/40 text-rose-200'
          }`}
        >
          <span>{banner.text}</span>
          <button onClick={() => setBanner(null)} className="text-slate-400 hover:text-white text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* ---------------- MODULE 1: PERSONAL OVERVIEW ---------------- */}
      {empTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-1">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Today&apos;s Attendance</div>
              <div className="text-xl font-extrabold text-white">{metrics.todayStatus || 'Not Checked In'}</div>
              <div className="text-xs text-slate-400 font-mono tabular-nums">
                {todayAtt?.check_in_at ? `In: ${String(todayAtt.check_in_at).slice(11, 19)} UTC` : 'No daily punch logged'}
                {todayAtt?.check_out_at ? ` • Out: ${String(todayAtt.check_out_at).slice(11, 19)} UTC` : ''}
              </div>
            </div>

            <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-1">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Monthly Hours Logged</div>
              <div className="text-xl font-extrabold text-cyan-300 font-mono tabular-nums">
                {metrics.monthlyHoursWorked ?? 0} hrs
              </div>
              <div className="text-xs text-slate-400 tabular-nums">
                {metrics.monthlyDaysLogged ?? 0} days recorded this month
              </div>
            </div>

            <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-1">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Assigned Tasks</div>
              <div className="text-xl font-extrabold text-white font-mono tabular-nums">
                {metrics.pendingTasksCount ?? 0} Active / {metrics.completedTasksCount ?? 0} Done
              </div>
              <div className="text-xs text-slate-400 tabular-nums">
                {metrics.assignedTasksCount ?? 0} total assigned items
              </div>
            </div>

            <div className="rounded-xl bg-slate-900 border border-slate-800 p-4 space-y-1">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Leave Balance</div>
              <div className="text-xl font-extrabold text-emerald-300 font-mono tabular-nums">
                {metrics.leaveRemainingDays ?? 0} Days Left
              </div>
              <div className="text-xs text-slate-400 tabular-nums">
                {metrics.pendingLeavesCount ?? 0} pending request(s)
              </div>
            </div>
          </div>

          {/* Quick Attendance Punch Widget & Conditional Salary Card */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-bold text-white">Daily Attendance &amp; Shift Check-In</h2>
                  <p className="text-xs text-slate-400">
                    One check-in and check-out allowed per day; server calculates exact working hours.
                  </p>
                </div>
                <select
                  value={workMode}
                  onChange={(e) => setWorkMode(e.target.value as any)}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white"
                >
                  <option value="On-Site">On-Site</option>
                  <option value="Remote">Remote</option>
                  <option value="Field Duty">Field Duty</option>
                </select>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={punchNotes}
                  onChange={(e) => setPunchNotes(e.target.value)}
                  placeholder="Optional shift note or field location..."
                  className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                />
                {!todayAtt?.check_in_at ? (
                  <button
                    onClick={handleCheckIn}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs whitespace-nowrap"
                  >
                    Check In Now
                  </button>
                ) : !todayAtt?.check_out_at ? (
                  <button
                    onClick={handleCheckOut}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs whitespace-nowrap"
                  >
                    Check Out Now
                  </button>
                ) : (
                  <span className="px-4 py-2.5 rounded-xl bg-slate-950 border border-emerald-500/30 text-xs font-bold text-emerald-300 font-mono tabular-nums whitespace-nowrap">
                    Shift Closed ({todayAtt.working_hours}h)
                  </span>
                )}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Latest Payroll</span>
                <DollarSign className="w-4 h-4 text-teal-400" />
              </div>
              {dashboard?.salarySummary?.authorized ? (
                <>
                  <div className="text-2xl font-extrabold text-white font-mono tabular-nums">
                    {dashboard.salarySummary.currency} {Number(dashboard.salarySummary.netSalary || 0).toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-400">
                    Period: <span className="font-mono text-slate-200">{dashboard.salarySummary.latestPayPeriod || '—'}</span> •{' '}
                    <span className="text-emerald-300">{dashboard.salarySummary.paymentStatus}</span>
                  </div>
                  <button
                    onClick={() => setEmpTab('salary')}
                    className="mt-2 text-xs font-bold text-teal-400 hover:text-teal-300"
                  >
                    Open Pay Slips &rarr;
                  </button>
                </>
              ) : (
                <div className="text-xs text-slate-400 pt-2">
                  Salary visibility is restricted for your role permissions.
                </div>
              )}
            </div>
          </div>

          {/* Pending Tasks & Recent Notifications */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white">Pending &amp; Active Tasks</h3>
                <button onClick={() => setEmpTab('tasks')} className="text-xs text-teal-400 hover:text-teal-300 font-semibold">
                  View All
                </button>
              </div>
              {(dashboard?.pendingTasks || []).length === 0 ? (
                <p className="text-xs text-slate-400 py-4">No open tasks pending.</p>
              ) : (
                <div className="space-y-2">
                  {dashboard.pendingTasks.map((t: any) => (
                    <div key={t.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate">{t.title}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {t.task_code} • Due {t.due_date || 'TBD'} • {t.priority}
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-cyan-300 whitespace-nowrap">
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white">Recent Notifications &amp; Activity</h3>
                <button onClick={() => setEmpTab('communications')} className="text-xs text-teal-400 hover:text-teal-300 font-semibold">
                  Open Inbox
                </button>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {(dashboard?.notifications || []).slice(0, 6).map((n: any) => (
                  <div key={n.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-white">{n.title}</span>
                      {!n.is_read && <span className="text-[10px] font-bold text-teal-300">UNREAD</span>}
                    </div>
                    <p className="text-slate-400 text-[11px]">{n.message}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MODULE 2: PROFILE MANAGEMENT ---------------- */}
      {empTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h2 className="text-sm font-bold text-white">Immutable Employment Record</h2>
            <div className="space-y-2 text-xs">
              {[
                ['Employee ID', profileData?.employee?.employeeCode],
                ['Official Email', profileData?.employee?.email],
                ['Job Position', profileData?.employee?.jobPosition],
                ['Department', profileData?.employee?.department],
                ['Company', profileData?.employee?.companyName],
                ['Country', profileData?.employee?.countryName],
                ['Assigned Branch', profileData?.employee?.branchName],
                ['Reporting Manager', profileData?.employee?.reportingManagerName],
                ['Joining Date', profileData?.employee?.joiningDate?.slice(0, 10)],
                ['Account Status', profileData?.employee?.status],
              ].map(([k, v]) => (
                <div key={String(k)} className="flex items-center justify-between py-1.5 border-b border-slate-800/80 gap-2">
                  <span className="text-slate-400">{k}</span>
                  <span className="font-semibold text-white text-right">{v || '—'}</span>
                </div>
              ))}
            </div>

            <form onSubmit={handlePhotoUpload} className="pt-3 border-t border-slate-800 space-y-2">
              <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-teal-400" />
                <span>Update Private Profile Photo</span>
              </label>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                className="w-full text-[11px] text-slate-300 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-slate-800 file:text-teal-300"
              />
              <button
                type="submit"
                disabled={!photoFile}
                className="w-full py-2 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white text-xs font-bold"
              >
                Upload Profile Photograph
              </button>
            </form>
          </div>

          <form onSubmit={handleProfileSave} className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h2 className="text-sm font-bold text-white">Editable Personal &amp; Emergency Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Mobile Number</label>
                <input
                  type="text"
                  value={profileForm.mobile}
                  onChange={(e) => setProfileForm({ ...profileForm, mobile: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">City</label>
                <input
                  type="text"
                  value={profileForm.city}
                  onChange={(e) => setProfileForm({ ...profileForm, city: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1">Residential Address</label>
                <input
                  type="text"
                  value={profileForm.address}
                  onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Emergency Contact Name</label>
                <input
                  type="text"
                  value={profileForm.emergencyContactName}
                  onChange={(e) => setProfileForm({ ...profileForm, emergencyContactName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Emergency Contact Phone</label>
                <input
                  type="text"
                  value={profileForm.emergencyContactPhone}
                  onChange={(e) => setProfileForm({ ...profileForm, emergencyContactPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Relationship</label>
                <input
                  type="text"
                  value={profileForm.emergencyContactRelation}
                  onChange={(e) => setProfileForm({ ...profileForm, emergencyContactRelation: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Skills (Comma-separated)</label>
                <input
                  type="text"
                  value={profileForm.skillsText}
                  onChange={(e) => setProfileForm({ ...profileForm, skillsText: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1">Professional Bio</label>
                <textarea
                  rows={3}
                  value={profileForm.bio}
                  onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs"
            >
              Save Personal Information
            </button>
          </form>

          <AccountSecurityCenter />
        </div>
      )}

      {/* ---------------- MODULE 3: ATTENDANCE MANAGEMENT ---------------- */}
      {empTab === 'attendance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              ['Logged Days', attendanceData?.summary?.totalDays ?? 0],
              ['Present / Remote', attendanceData?.summary?.presentDays ?? 0],
              ['Late Days', attendanceData?.summary?.lateDays ?? 0],
              ['Total Hours', `${attendanceData?.summary?.totalHours ?? 0}h`],
            ].map(([label, val]) => (
              <div key={String(label)} className="rounded-xl bg-slate-900 border border-slate-800 p-4">
                <div className="text-[11px] font-bold uppercase text-slate-400">{label}</div>
                <div className="text-xl font-extrabold text-white font-mono tabular-nums mt-1">{val}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 overflow-x-auto">
              <h2 className="text-sm font-bold text-white mb-3">Attendance History</h2>
              <table className="w-full text-xs text-left">
                <thead className="text-[11px] text-slate-400 border-b border-slate-800 uppercase">
                  <tr>
                    <th className="py-2 pr-3">Date</th>
                    <th className="py-2 pr-3">Status</th>
                    <th className="py-2 pr-3">Mode</th>
                    <th className="py-2 pr-3">Check-In</th>
                    <th className="py-2 pr-3">Check-Out</th>
                    <th className="py-2">Hours</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
                  {(attendanceData?.records || []).map((r: any) => (
                    <tr key={r.id}>
                      <td className="py-2.5 pr-3 text-white">{r.attendance_date}</td>
                      <td className="py-2.5 pr-3 text-teal-300">{r.status}</td>
                      <td className="py-2.5 pr-3 text-slate-300 font-sans">{r.work_mode || 'On-Site'}</td>
                      <td className="py-2.5 pr-3 text-slate-300">{r.check_in_at ? String(r.check_in_at).slice(11, 19) : '—'}</td>
                      <td className="py-2.5 pr-3 text-slate-300">{r.check_out_at ? String(r.check_out_at).slice(11, 19) : '—'}</td>
                      <td className="py-2.5 text-white">{r.working_hours ?? 0}h</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <form onSubmit={handleCorrectionRequest} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 text-xs">
              <h2 className="text-sm font-bold text-white">Request Attendance Correction</h2>
              <p className="text-slate-400">
                Official logs cannot be directly edited by staff. Submit a reason for Branch Manager review.
              </p>
              <div>
                <label className="block text-slate-400 mb-1">Attendance Date</label>
                <input
                  type="date"
                  required
                  value={corrDate}
                  onChange={(e) => setCorrDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Correction Reason</label>
                <textarea
                  rows={3}
                  required
                  value={corrReason}
                  onChange={(e) => setCorrReason(e.target.value)}
                  placeholder="Describe missed punch or field shift verification..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <button type="submit" className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold">
                Submit Correction Request
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ---------------- MODULE 4: LEAVE MANAGEMENT ---------------- */}
      {empTab === 'leaves' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {(['annual', 'sick', 'casual'] as const).map((k) => {
              const b = leaveData?.balance?.[k] || { total: 0, used: 0, remaining: 0 };
              return (
                <div key={k} className="rounded-xl bg-slate-900 border border-slate-800 p-4">
                  <div className="text-[11px] font-bold uppercase text-slate-400">{k} Leave Balance</div>
                  <div className="text-xl font-extrabold text-emerald-300 font-mono tabular-nums mt-1">
                    {b.remaining} / {b.total} Days Left
                  </div>
                  <div className="text-xs text-slate-400 tabular-nums">Used: {b.used} days</div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <form onSubmit={handleApplyLeave} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 text-xs">
              <h2 className="text-sm font-bold text-white">Apply for Leave</h2>
              <div>
                <label className="block text-slate-400 mb-1">Leave Type</label>
                <select
                  value={leaveForm.leaveType}
                  onChange={(e) => setLeaveForm({ ...leaveForm, leaveType: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                >
                  <option value="Annual Leave">Annual Leave</option>
                  <option value="Sick Leave">Sick Leave</option>
                  <option value="Casual Leave">Casual Leave</option>
                  <option value="Emergency Leave">Emergency Leave</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={leaveForm.startDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={leaveForm.endDate}
                    onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Reason</label>
                <textarea
                  rows={3}
                  required
                  value={leaveForm.reason}
                  onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                  placeholder="Provide reason for leave application..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Supporting Document (Optional)</label>
                <input
                  type="file"
                  onChange={(e) => setLeaveFile(e.target.files?.[0] || null)}
                  className="w-full text-[11px] text-slate-300"
                />
              </div>
              <button type="submit" className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold">
                Submit Leave Application
              </button>
            </form>

            <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 overflow-x-auto">
              <h2 className="text-sm font-bold text-white mb-3">My Leave Requests</h2>
              <table className="w-full text-xs text-left">
                <thead className="text-[11px] text-slate-400 border-b border-slate-800 uppercase">
                  <tr>
                    <th className="py-2 pr-3">Type</th>
                    <th className="py-2 pr-3">Dates</th>
                    <th className="py-2 pr-3">Days</th>
                    <th className="py-2 pr-3">Status</th>
                    <th className="py-2">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {(leaveData?.requests || []).map((lv: any) => (
                    <tr key={lv.id}>
                      <td className="py-2.5 pr-3 text-white font-semibold">{lv.leave_type}</td>
                      <td className="py-2.5 pr-3 text-slate-300 font-mono tabular-nums">
                        {lv.start_date} &rarr; {lv.end_date}
                      </td>
                      <td className="py-2.5 pr-3 text-slate-200 font-mono tabular-nums">{lv.total_days}</td>
                      <td className="py-2.5 pr-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            lv.status === 'Approved'
                              ? 'bg-emerald-950 text-emerald-300'
                              : lv.status === 'Rejected'
                              ? 'bg-rose-950 text-rose-300'
                              : lv.status === 'Cancelled'
                              ? 'bg-slate-800 text-slate-400'
                              : 'bg-amber-950 text-amber-300'
                          }`}
                        >
                          {lv.status}
                        </span>
                      </td>
                      <td className="py-2.5">
                        {lv.status === 'Pending' && (
                          <button
                            onClick={() => handleCancelLeave(lv.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-950/60 border border-rose-500/30 text-rose-300 hover:text-white text-[11px]"
                          >
                            <XCircle className="w-3 h-3" /> Cancel
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MODULE 5: TASK & WORK MANAGEMENT ---------------- */}
      {empTab === 'tasks' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-sm font-bold text-white">Assigned Tasks &amp; Deliverables</h2>
            <div className="flex items-center gap-1.5">
              {(['All', 'Pending', 'In Progress', 'Completed'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setTaskFilter(f)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                    taskFilter === f ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30' : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            {filteredTasks.map((task) => (
              <div key={task.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[11px] font-bold text-teal-300">{task.task_code}</span>
                      <span className="text-sm font-bold text-white">{task.title}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-amber-300">{task.priority}</span>
                    </div>
                    <p className="text-xs text-slate-300">{task.description}</p>
                    <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                      Assigned by {task.assigned_by_name} • Due: {task.due_date || 'TBD'} • Status: {task.status}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {task.status === 'Pending' && (
                      <button
                        onClick={async () => {
                          await api.startEmployeeTask(task.id);
                          setBanner({ type: 'ok', text: `Started ${task.task_code}.` });
                          await loadWorkspaceTab('tasks');
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold"
                      >
                        <Play className="w-3 h-3" /> Start
                      </button>
                    )}
                    {task.status !== 'Completed' && (
                      <button
                        onClick={async () => {
                          await api.completeEmployeeTask(task.id, taskNoteDrafts[task.id]);
                          setBanner({ type: 'ok', text: `Completed ${task.task_code}.` });
                          await loadWorkspaceTab('tasks');
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                      >
                        <Check className="w-3 h-3" /> Complete
                      </button>
                    )}
                  </div>
                </div>

                {task.status !== 'Completed' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800 text-xs">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={taskNoteDrafts[task.id] || ''}
                        onChange={(e) => setTaskNoteDrafts({ ...taskNoteDrafts, [task.id]: e.target.value })}
                        placeholder="Add work progress note..."
                        className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                      />
                      <button
                        onClick={async () => {
                          const txt = (taskNoteDrafts[task.id] || '').trim();
                          if (!txt) return;
                          await api.addEmployeeTaskUpdate(task.id, txt);
                          setTaskNoteDrafts({ ...taskNoteDrafts, [task.id]: '' });
                          await loadWorkspaceTab('tasks');
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-semibold flex items-center gap-1 whitespace-nowrap"
                      >
                        <MessageSquarePlus className="w-3.5 h-3.5" /> Update
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="file"
                        onChange={(e) => setTaskFiles({ ...taskFiles, [task.id]: e.target.files?.[0] || null })}
                        className="flex-1 text-[11px] text-slate-300"
                      />
                      <button
                        disabled={!taskFiles[task.id]}
                        onClick={async () => {
                          const f = taskFiles[task.id];
                          if (!f) return;
                          await api.uploadEmployeeTaskDocument(task.id, f);
                          setTaskFiles({ ...taskFiles, [task.id]: null });
                          setBanner({ type: 'ok', text: `Uploaded deliverable to ${task.task_code}.` });
                          await loadWorkspaceTab('tasks');
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-cyan-300 font-semibold flex items-center gap-1 whitespace-nowrap"
                      >
                        <Upload className="w-3.5 h-3.5" /> Attach File
                      </button>
                    </div>
                  </div>
                )}

                {Array.isArray(task.workUpdates) && task.workUpdates.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-slate-800/70">
                    <div className="text-[11px] font-bold uppercase text-slate-400">Work Timeline</div>
                    {task.workUpdates.map((u: any, idx: number) => (
                      <div key={idx} className="text-xs text-slate-300 flex items-center justify-between gap-2">
                        <span><strong>{u.by}:</strong> {u.text}</span>
                        <span className="text-[10px] font-mono text-slate-500">{String(u.at).slice(0, 16).replace('T', ' ')}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- MODULE 6: SALARY & PAYROLL ---------------- */}
      {empTab === 'salary' && (
        <div className="space-y-6">
          {salaryLockedMsg ? (
            <div className="rounded-2xl bg-slate-900 border border-amber-500/30 p-6 text-xs text-amber-200 flex items-center gap-3">
              <Lock className="w-5 h-5 text-amber-400 shrink-0" />
              <span>{salaryLockedMsg}</span>
            </div>
          ) : (
            <>
              {salaryData?.structure && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {[
                    ['Base Salary', salaryData.structure.baseSalary],
                    ['Allowances & Bonuses', Number(salaryData.structure.allowances || 0) + Number(salaryData.structure.bonuses || 0)],
                    ['Deductions & Tax', Number(salaryData.structure.deductions || 0) + Number(salaryData.structure.taxDeduction || 0)],
                    ['Net Monthly Pay', salaryData.structure.netSalary],
                  ].map(([label, amount]) => (
                    <div key={String(label)} className="rounded-xl bg-slate-900 border border-slate-800 p-4">
                      <div className="text-[11px] font-bold uppercase text-slate-400">{label}</div>
                      <div className="text-lg font-extrabold text-white font-mono tabular-nums mt-1">
                        {salaryData.structure.currency} {Number(amount || 0).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 overflow-x-auto">
                <h2 className="text-sm font-bold text-white mb-3">Monthly Payroll History (Read-Only)</h2>
                <table className="w-full text-xs text-left">
                  <thead className="text-[11px] text-slate-400 border-b border-slate-800 uppercase">
                    <tr>
                      <th className="py-2 pr-3">Pay Period</th>
                      <th className="py-2 pr-3">Base</th>
                      <th className="py-2 pr-3">Bonuses</th>
                      <th className="py-2 pr-3">Tax + Ded.</th>
                      <th className="py-2 pr-3">Net Salary</th>
                      <th className="py-2 pr-3">Status</th>
                      <th className="py-2">Pay Slip</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
                    {(salaryData?.records || []).map((sal: any) => (
                      <tr key={sal.id}>
                        <td className="py-2.5 pr-3 text-white font-bold">{sal.pay_period}</td>
                        <td className="py-2.5 pr-3 text-slate-300">{sal.currency} {Number(sal.base_salary).toLocaleString()}</td>
                        <td className="py-2.5 pr-3 text-emerald-300">{sal.currency} {Number(sal.bonuses).toLocaleString()}</td>
                        <td className="py-2.5 pr-3 text-rose-300">{sal.currency} {(Number(sal.tax_deduction) + Number(sal.deductions)).toLocaleString()}</td>
                        <td className="py-2.5 pr-3 text-white font-bold">{sal.currency} {Number(sal.net_salary).toLocaleString()}</td>
                        <td className="py-2.5 pr-3 font-sans text-emerald-300">{sal.payment_status}</td>
                        <td className="py-2.5 font-sans">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={async () => {
                                const res = await api.getEmployeeSalarySlip(sal.id);
                                setActiveSlip(res.slip);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 text-[11px] font-semibold"
                            >
                              View Slip
                            </button>
                            {sal.slip_doc_id && (
                              <button
                                onClick={() => api.downloadEmployeePrivateFile(sal.slip_doc_id, `payslip-${sal.pay_period}.txt`)}
                                className="px-2.5 py-1 rounded-lg bg-teal-950 border border-teal-500/30 text-teal-300 text-[11px] font-semibold inline-flex items-center gap-1"
                              >
                                <Download className="w-3 h-3" /> File
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {activeSlip && (
                <div className="rounded-2xl bg-slate-950 border border-teal-500/40 p-6 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <h3 className="text-sm font-bold text-white">Official Employee Pay Slip — {activeSlip.pay_period}</h3>
                      <p className="text-xs text-slate-400">
                        {activeSlip.employeeName} ({activeSlip.employeeCode}) • {activeSlip.jobPosition} • {activeSlip.department}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => window.print()}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold inline-flex items-center gap-1"
                      >
                        <Printer className="w-3.5 h-3.5" /> Print
                      </button>
                      <button
                        onClick={() => setActiveSlip(null)}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 text-xs"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-mono tabular-nums">
                    <div>Base: <strong className="text-white">{activeSlip.currency} {Number(activeSlip.base_salary).toLocaleString()}</strong></div>
                    <div>Allowances: <strong className="text-white">{activeSlip.currency} {Number(activeSlip.allowances).toLocaleString()}</strong></div>
                    <div>Bonuses: <strong className="text-emerald-300">{activeSlip.currency} {Number(activeSlip.bonuses).toLocaleString()}</strong></div>
                    <div>Deductions: <strong className="text-rose-300">{activeSlip.currency} {Number(activeSlip.deductions).toLocaleString()}</strong></div>
                    <div>Tax: <strong className="text-rose-300">{activeSlip.currency} {Number(activeSlip.tax_deduction).toLocaleString()}</strong></div>
                    <div>Net Paid: <strong className="text-teal-300">{activeSlip.currency} {Number(activeSlip.net_salary).toLocaleString()}</strong></div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ---------------- MODULE 7: PRIVATE DOCUMENTS VAULT ---------------- */}
      {empTab === 'documents' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleUploadDoc} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 text-xs">
            <h2 className="text-sm font-bold text-white">Upload Personal Document</h2>
            <div>
              <label className="block text-slate-400 mb-1">Document Title</label>
              <input
                type="text"
                required
                value={docTitle}
                onChange={(e) => setDocTitle(e.target.value)}
                placeholder="e.g. EV Safety Certificate"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Category</label>
              <select
                value={docCategory}
                onChange={(e) => setDocCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              >
                <option value="Employment Document">Employment Document</option>
                <option value="ID Verification">ID Verification</option>
                <option value="Training Certificate">Training Certificate</option>
                <option value="Expense / Tax Receipt">Expense / Tax Receipt</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Select File (PDF, PNG, JPG, DOCX, TXT)</label>
              <input
                type="file"
                required
                onChange={(e) => setDocFile(e.target.files?.[0] || null)}
                className="w-full text-[11px] text-slate-300"
              />
            </div>
            <button type="submit" className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold">
              Upload to Private Vault
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h2 className="text-sm font-bold text-white">My Confidential Documents ({documents.length})</h2>
            <div className="space-y-2">
              {documents.map((d) => (
                <div key={d.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate">{d.title}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {d.category} • {d.original_filename} • {Math.round(Number(d.size_bytes || 0) / 1024)} KB
                    </div>
                  </div>
                  <button
                    onClick={() => api.downloadEmployeePrivateFile(d.id, d.original_filename)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-semibold inline-flex items-center gap-1 shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" /> Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MODULE 8: PERFORMANCE & DEVELOPMENT ---------------- */}
      {empTab === 'performance' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              ['Performance Score', `${perfData?.currentScore ?? 0}/100`],
              ['Task Completion', `${perfData?.taskCompletionRate ?? 0}%`],
              ['Attendance Rate', `${perfData?.attendanceRate ?? 0}%`],
              ['Logged Hours', `${perfData?.totalHoursLogged ?? 0}h`],
            ].map(([label, val]) => (
              <div key={String(label)} className="rounded-xl bg-slate-900 border border-slate-800 p-4">
                <div className="text-[11px] font-bold uppercase text-slate-400">{label}</div>
                <div className="text-xl font-extrabold text-teal-300 font-mono tabular-nums mt-1">{val}</div>
              </div>
            ))}
          </div>

          <div className="space-y-4">
            {(perfData?.reviews || []).map((rev: any) => (
              <div key={rev.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-sm font-bold text-white">Review Period: {rev.review_period}</div>
                    <div className="text-xs text-slate-400">Reviewer: {rev.reviewer_name}</div>
                  </div>
                  <span className="px-3 py-1 rounded-lg bg-teal-950 border border-teal-500/30 text-xs font-mono font-bold text-teal-300">
                    Score: {rev.score}/100
                  </span>
                </div>
                <p className="text-xs text-slate-300">{rev.feedback}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <div className="font-bold text-slate-300">Trainings &amp; Certifications</div>
                    {(rev.trainings || []).map((tr: any, i: number) => (
                      <div key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                        <span className="text-white">{tr.name}</span>
                        <span className="text-emerald-300 font-semibold">{tr.status}</span>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <div className="font-bold text-slate-300">Development Goals</div>
                    {(rev.goals || []).map((g: any, i: number) => (
                      <div key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-white">{g.title}</span>
                          <span className="font-mono text-teal-300">{g.progress}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-slate-800 overflow-hidden">
                          <div className="h-full bg-teal-500" style={{ width: `${Math.min(100, Number(g.progress || 0))}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- MODULE 9: COMMUNICATIONS & ANNOUNCEMENTS ---------------- */}
      {empTab === 'communications' && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
          <h2 className="text-sm font-bold text-white">Company, Branch &amp; Manager Communications</h2>
          <div className="space-y-2.5">
            {comms.map((n) => (
              <div key={n.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{n.title}</span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-cyan-300">{n.category}</span>
                    {!n.is_read && <span className="text-[10px] font-bold text-teal-300">NEW</span>}
                  </div>
                  <p className="text-xs text-slate-300">{n.message}</p>
                  <div className="text-[10px] text-slate-500 font-mono">
                    From: {n.sender_name} ({n.sender_role}) • {String(n.created_at).slice(0, 16).replace('T', ' ')}
                  </div>
                </div>
                {!n.is_read && (
                  <button
                    onClick={async () => {
                      await api.markEmployeeCommunicationRead(n.id);
                      await loadWorkspaceTab('communications');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-semibold shrink-0"
                  >
                    Mark as Read
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------- MODULE 10: HR & WORKPLACE SUPPORT DESK ---------------- */}
      {empTab === 'support' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <form onSubmit={handleSupportSubmit} className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3 text-xs">
            <h2 className="text-sm font-bold text-white">Submit Workplace / HR Ticket</h2>
            <div className="grid grid-cols-2 gap-2">
              <select
                value={supportForm.category}
                onChange={(e) => setSupportForm({ ...supportForm, category: e.target.value })}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              >
                <option value="HR Query">HR Query</option>
                <option value="Payroll Question">Payroll Question</option>
                <option value="IT / Portal Issue">IT / Portal Issue</option>
                <option value="Branch Operations">Branch Operations</option>
              </select>
              <select
                value={supportForm.priority}
                onChange={(e) => setSupportForm({ ...supportForm, priority: e.target.value })}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>
            <input
              type="text"
              required
              value={supportForm.subject}
              onChange={(e) => setSupportForm({ ...supportForm, subject: e.target.value })}
              placeholder="Ticket Subject"
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
            />
            <textarea
              rows={4}
              required
              value={supportForm.description}
              onChange={(e) => setSupportForm({ ...supportForm, description: e.target.value })}
              placeholder="Describe your HR, payroll, or operational support request..."
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
            />
            <button type="submit" className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold inline-flex items-center justify-center gap-1.5">
              <Send className="w-3.5 h-3.5" /> Submit Ticket
            </button>
          </form>

          <div className="lg:col-span-2 rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h2 className="text-sm font-bold text-white">My Support Tickets ({tickets.length})</h2>
            <div className="space-y-2.5">
              {tickets.map((tk) => (
                <div key={tk.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-white">
                      <span className="font-mono text-teal-300 mr-2">{tk.ticket_number}</span>
                      {tk.subject}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-cyan-300">{tk.status}</span>
                  </div>
                  <p className="text-xs text-slate-400">{tk.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- MODULE 11: SECURITY, SESSIONS & AUDIT LOGS ---------------- */}
      {empTab === 'security' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Monitor className="w-4 h-4 text-teal-400" />
                <span>Active Employee Sessions ({sessions.length})</span>
              </h2>
              <div className="space-y-2 text-xs">
                {sessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-white">
                        {s.device_label} {s.is_current ? <span className="text-emerald-400">(Current)</span> : null}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        IP: {s.ip_address} • Expires: {String(s.expires_at).slice(0, 19).replace('T', ' ')}
                      </div>
                    </div>
                    {!s.is_current && (
                      <button
                        onClick={async () => {
                          await api.revokeEmployeeSession(s.id);
                          setSessions((prev) => prev.filter((x) => x.id !== s.id));
                        }}
                        className="px-2.5 py-1 rounded-lg bg-rose-950 border border-rose-500/30 text-rose-300 inline-flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <span>Employee Login History</span>
              </h2>
              <div className="space-y-1.5 max-h-64 overflow-y-auto text-xs font-mono">
                {loginHistory.map((h) => (
                  <div key={h.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
                    <span className="text-slate-300">{h.ip_address}</span>
                    <span className="text-slate-400">{String(h.created_at).slice(0, 19).replace('T', ' ')}</span>
                    <span className={h.success ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                      {h.success ? 'SUCCESS' : 'FAILED'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Building2 className="w-4 h-4 text-cyan-400" />
                <span>Personal Activity Audit Trail</span>
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {(emp?.permissions || []).map((perm: string) => (
                  <span key={perm} className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 font-mono text-[10px] text-teal-300">
                    {perm}
                  </span>
                ))}
              </div>
            </div>
            <div className="space-y-1.5 max-h-64 overflow-y-auto text-xs">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-cyan-300 mr-2">{log.action}</span>
                    <span className="text-slate-300">{log.details}</span>
                  </div>
                  <span className="font-mono text-[11px] text-slate-500">
                    {log.ip_address} • {String(log.created_at).slice(0, 19).replace('T', ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {empTab === 'employee-hub' && (
        <EmployeeManagementHub />
      )}

      {empTab === 'dealership-hub' && (
        <DealershipManagementHub />
      )}
    </div>
  );
};
