import React, { useState } from 'react';
import { Globe, Building2, Store, Users, Car, DollarSign, TrendingUp, AlertCircle } from 'lucide-react';

interface CountryRecord {
  id: string;
  code: string;
  name: string;
  flagEmoji: string;
  currency: string;
  headquartersCity: string | null;
  status: string;
  hasOperations: boolean;
  geo: { lat: number; lng: number; mapX: number; mapY: number; region: string };
  companiesCount: number;
  companies: Array<{ id: string; name: string; status: string; city: string }>;
  branchesCount: number;
  dealershipsCount: number;
  activeDealershipsCount: number;
  employeesCount: number;
  customersCount: number;
  inventoryTotal: number;
  inventoryAvailable: number;
  inventorySold: number;
  vehicleSalesCount: number;
  pendingOrdersCount: number;
  revenue: number;
  vehicleSalesValue: number;
  pendingPayments: number;
  expenses: number;
  operatingExpenses: number;
  commissionExpenses: number;
  payrollExpenses: number;
  netProfit: number;
  targetUnits: number;
  achievedUnits: number;
  performancePct: number | null;
  avgEmployeeScore: number | null;
}

interface OwnerGlobalMapProps {
  data: {
    totalRegisteredCountries: number;
    activeOperationalCountries: number;
    countries: CountryRecord[];
  } | null;
  loading?: boolean;
}

function formatPkr(val: number): string {
  return `₨ ${Math.round(val || 0).toLocaleString()}`;
}

export const OwnerGlobalMap: React.FC<OwnerGlobalMapProps> = ({ data, loading }) => {
  const countries = data?.countries || [];
  const defaultSelected = countries.find((c) => c.hasOperations)?.code || countries[0]?.code || null;
  const [selectedCode, setSelectedCode] = useState<string | null>(defaultSelected);

  const selected =
    countries.find((c) => c.code === selectedCode) ||
    countries.find((c) => c.hasOperations) ||
    countries[0] ||
    null;

  if (loading && !data) {
    return (
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-8 text-center text-xs text-slate-400">
        Loading verified country registry and operational metrics...
      </div>
    );
  }

  if (countries.length === 0) {
    return (
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-8 text-center text-xs text-slate-400">
        No Data Available — No countries are registered in the database.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Registered Countries</div>
          <div className="text-2xl font-black text-white font-mono tabular-nums mt-1">
            {data?.totalRegisteredCountries ?? countries.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Verified database country registry</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Active Operational Markets</div>
          <div className="text-2xl font-black text-emerald-400 font-mono tabular-nums mt-1">
            {data?.activeOperationalCountries ?? 0}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Countries with live branches or dealers</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Global Registered Fleet</div>
          <div className="text-2xl font-black text-cyan-400 font-mono tabular-nums mt-1">
            {countries.reduce((s, c) => s + c.inventoryTotal, 0)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {countries.reduce((s, c) => s + c.inventorySold, 0)} Delivered / {countries.reduce((s, c) => s + c.inventoryAvailable, 0)} Available
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800">
          <div className="text-[11px] text-slate-400">Global Net Profit (Verified)</div>
          <div className="text-2xl font-black text-amber-400 font-mono tabular-nums mt-1">
            {formatPkr(countries.reduce((s, c) => s + c.netProfit, 0))}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">Cleared revenue less verified expenses</div>
        </div>
      </div>

      {/* Interactive Global Map + Country Detail Inspector */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Globe className="w-4 h-4 text-amber-400" />
                <span>Interactive Global Operations Map</span>
              </h3>
              <p className="text-xs text-slate-400">
                Click any registered country marker to inspect verified local companies, sales, workforce, revenue &amp; profit. Unregistered territories hold zero invented operations.
              </p>
            </div>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-300">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" /> Active Operations
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-500 inline-block" /> Registered (No Ops Yet)
              </span>
            </div>
          </div>

          <div className="relative rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
            <svg viewBox="0 0 1000 460" className="w-full h-auto block select-none" role="img" aria-label="Interactive Global Company Map">
              {/* Subtle Coordinate Grid */}
              <defs>
                <pattern id="ownerMapGrid" width="50" height="50" patternUnits="userSpaceOnUse">
                  <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#1e293b" strokeWidth="0.6" />
                </pattern>
              </defs>
              <rect width="1000" height="460" fill="#020617" />
              <rect width="1000" height="460" fill="url(#ownerMapGrid)" />

              {/* Equator & Tropics */}
              <line x1="0" y1="230" x2="1000" y2="230" stroke="#1e293b" strokeDasharray="4 4" strokeWidth="1" />
              <line x1="500" y1="0" x2="500" y2="460" stroke="#1e293b" strokeDasharray="4 4" strokeWidth="1" />

              {/* Simplified Geographic Continental Silhouettes (Cartographic Reference) */}
              <g fill="#0f172a" stroke="#334155" strokeWidth="1">
                {/* North America */}
                <path d="M 95 75 L 250 55 L 305 110 L 265 185 L 205 210 L 160 190 L 125 140 Z" />
                {/* South America */}
                <path d="M 245 235 L 320 250 L 345 315 L 295 405 L 255 390 L 245 310 Z" />
                {/* Europe */}
                <path d="M 455 70 L 560 55 L 585 115 L 545 140 L 470 135 Z" />
                {/* Africa */}
                <path d="M 465 155 L 565 155 L 605 220 L 565 340 L 505 345 L 475 250 Z" />
                {/* Middle East & Asia */}
                <path d="M 565 130 L 665 130 L 745 120 L 855 95 L 875 185 L 795 235 L 710 230 L 650 205 L 590 195 Z" />
                {/* Maritime SE Asia & Oceania */}
                <path d="M 785 280 L 895 295 L 910 365 L 820 370 Z" />
              </g>

              {/* Connection Lines from Pakistan Global HQ to Operational Markets */}
              {countries
                .filter((c) => c.hasOperations && c.code !== 'PK')
                .map((c) => {
                  const hq = countries.find((x) => x.code === 'PK');
                  if (!hq) return null;
                  return (
                    <line
                      key={`link-${c.code}`}
                      x1={hq.geo.mapX}
                      y1={hq.geo.mapY}
                      x2={c.geo.mapX}
                      y2={c.geo.mapY}
                      stroke="#f59e0b"
                      strokeOpacity="0.35"
                      strokeWidth="1.5"
                      strokeDasharray="4 3"
                    />
                  );
                })}

              {/* Country Markers */}
              {countries.map((c) => {
                const isSelected = selected?.code === c.code;
                const active = c.hasOperations;
                const r = isSelected ? 11 : active ? 8 : 6;
                return (
                  <g
                    key={c.code}
                    transform={`translate(${c.geo.mapX}, ${c.geo.mapY})`}
                    onClick={() => setSelectedCode(c.code)}
                    className="cursor-pointer"
                  >
                    {isSelected && (
                      <circle r={18} fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeOpacity="0.7" />
                    )}
                    <circle
                      r={r}
                      fill={isSelected ? '#f59e0b' : active ? '#10b981' : '#64748b'}
                      stroke="#020617"
                      strokeWidth="2"
                    />
                    <rect
                      x={12}
                      y={-12}
                      width={76}
                      height={22}
                      rx={6}
                      fill={isSelected ? '#451a03' : '#0f172a'}
                      stroke={isSelected ? '#f59e0b' : '#334155'}
                      strokeWidth="1"
                    />
                    <text x={18} y={3} fill="#f8fafc" fontSize="10" fontWeight="700" fontFamily="monospace">
                      {c.code} {c.hasOperations ? `• ${c.vehicleSalesCount}s` : '• 0'}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Quick Country Selector Pills */}
          <div className="flex flex-wrap gap-2">
            {countries.map((c) => {
              const isSelected = selected?.code === c.code;
              return (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => setSelectedCode(c.code)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition flex items-center gap-2 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                      : c.hasOperations
                      ? 'bg-slate-950 text-slate-200 border-emerald-500/40 hover:border-emerald-400'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <span>{c.flagEmoji || c.code}</span>
                  <span>{c.name}</span>
                  <span className="font-mono text-[10px] opacity-80">({c.code})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Country Deep Inspection Panel */}
        <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-4">
          {selected ? (
            <>
              <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{selected.flagEmoji || '🌐'}</span>
                    <h4 className="text-base font-black text-white">{selected.name}</h4>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-amber-300">
                      {selected.code} • {selected.currency}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {selected.geo.region} {selected.headquartersCity ? `• Hub: ${selected.headquartersCity}` : ''}
                  </p>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    selected.hasOperations
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {selected.hasOperations ? 'Operational' : 'Registered Only'}
                </span>
              </div>

              {!selected.hasOperations ? (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-2">
                  <div className="flex items-center gap-2 text-slate-300 font-semibold">
                    <AlertCircle className="w-4 h-4 text-slate-400" />
                    <span>No Data Available</span>
                  </div>
                  <p>
                    {selected.name} is registered in the country master table, but zero companies, branches, dealerships, employees, or sales exist in the database for this market.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-amber-400" /> Companies / Branches
                      </div>
                      <div className="text-sm font-black text-white font-mono tabular-nums mt-0.5">
                        {selected.companiesCount} / {selected.branchesCount}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Store className="w-3 h-3 text-cyan-400" /> Dealerships
                      </div>
                      <div className="text-sm font-black text-white font-mono tabular-nums mt-0.5">
                        {selected.dealershipsCount} ({selected.activeDealershipsCount} Active)
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Users className="w-3 h-3 text-blue-400" /> Staff / Customers
                      </div>
                      <div className="text-sm font-black text-white font-mono tabular-nums mt-0.5">
                        {selected.employeesCount} / {selected.customersCount}
                      </div>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Car className="w-3 h-3 text-emerald-400" /> Fleet / Sales
                      </div>
                      <div className="text-sm font-black text-white font-mono tabular-nums mt-0.5">
                        {selected.inventoryTotal} EVs / {selected.vehicleSalesCount} Sold
                      </div>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Cleared Revenue
                      </span>
                      <span className="font-mono font-bold text-emerald-400 tabular-nums">
                        {formatPkr(selected.revenue)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Verified Expenses</span>
                      <span className="font-mono font-bold text-rose-300 tabular-nums">
                        {formatPkr(selected.expenses)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between border-t border-slate-800 pt-2">
                      <span className="text-slate-200 font-semibold">Net Profit</span>
                      <span className={`font-mono font-black tabular-nums ${selected.netProfit >= 0 ? 'text-amber-300' : 'text-rose-400'}`}>
                        {formatPkr(selected.netProfit)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Pending Receivables</span>
                      <span className="font-mono text-amber-200 tabular-nums">
                        {formatPkr(selected.pendingPayments)}
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5 text-cyan-400" /> Target Attainment
                      </span>
                      <span className="font-mono font-bold text-cyan-300 tabular-nums">
                        {selected.performancePct !== null ? `${selected.performancePct}% (${selected.achievedUnits}/${selected.targetUnits} units)` : 'No Data Available'}
                      </span>
                    </div>
                    {selected.companies.length > 0 && (
                      <div className="pt-1">
                        <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">Registered Entities</div>
                        {selected.companies.map((co) => (
                          <div key={co.id} className="flex items-center justify-between text-[11px] py-0.5">
                            <span className="text-slate-200 truncate">{co.name}</span>
                            <span className="text-emerald-300 font-mono">{co.status}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>

      {/* Country-Wise Comparison Table */}
      <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-5 space-y-3">
        <h3 className="text-sm font-bold text-white">Country-Wise Enterprise Operations &amp; Financial Ledger</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Country</th>
                <th className="py-2.5 px-3 text-right">Companies</th>
                <th className="py-2.5 px-3 text-right">Branches</th>
                <th className="py-2.5 px-3 text-right">Dealers</th>
                <th className="py-2.5 px-3 text-right">Employees</th>
                <th className="py-2.5 px-3 text-right">Customers</th>
                <th className="py-2.5 px-3 text-right">Inventory</th>
                <th className="py-2.5 px-3 text-right">Sales</th>
                <th className="py-2.5 px-3 text-right">Revenue</th>
                <th className="py-2.5 px-3 text-right">Expenses</th>
                <th className="py-2.5 px-3 text-right">Net Profit</th>
                <th className="py-2.5 px-3 text-right">Target Perf.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {countries.map((c) => (
                <tr
                  key={c.code}
                  onClick={() => setSelectedCode(c.code)}
                  className={`cursor-pointer transition hover:bg-slate-800/40 ${
                    selected?.code === c.code ? 'bg-amber-500/5' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-semibold text-white whitespace-nowrap">
                    {c.flagEmoji} {c.name} <span className="text-slate-500 font-mono">({c.code})</span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{c.companiesCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{c.branchesCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{c.dealershipsCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{c.employeesCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-200">{c.customersCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-cyan-300">{c.inventoryTotal}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-white">{c.vehicleSalesCount}</td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-emerald-400">
                    {c.hasOperations ? formatPkr(c.revenue) : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-rose-300">
                    {c.hasOperations ? formatPkr(c.expenses) : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-amber-300">
                    {c.hasOperations ? formatPkr(c.netProfit) : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono tabular-nums text-cyan-300">
                    {c.performancePct !== null ? `${c.performancePct}%` : 'No Ops'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
