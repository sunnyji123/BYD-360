import express, { Request, Response } from 'express';
import * as XLSX from 'xlsx';
import {
  sqlite,
  generateSecureToken,
  hashPassword,
  generateTotpSecret,
  validatePasswordStrength,
  logBranchActivity,
  logSecurityEvent,
  nowIso,
} from './db';
import {
  requireBranchManager,
  requireBranchPermission,
  CANONICAL_BRANCH_MANAGER_PERMISSIONS,
  CANONICAL_EMPLOYEE_PERMISSIONS,
  getClientIp,
} from './auth';

const FORBIDDEN_PRIVILEGED_ROLES = [
  'Founder / Owner',
  'Super Admin',
  'Company Admin',
  'Country Manager',
  'Branch Manager',
];

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function maskNationalId(raw?: string | null): string {
  if (!raw) return 'Not Provided';
  const clean = String(raw).trim();
  if (clean.length <= 6) return '******';
  return `${clean.slice(0, 3)}••••••${clean.slice(-3)}`;
}

function maskPhone(raw?: string | null): string {
  if (!raw) return 'Not Provided';
  const clean = String(raw).trim();
  if (clean.length <= 6) return '******';
  return `${clean.slice(0, 5)}••••${clean.slice(-3)}`;
}

function recordBranchAction(
  req: Request,
  action: string,
  module: string,
  targetId?: string | null,
  details?: string | null,
  status: 'SUCCESS' | 'WARNING' | 'ALERT' = 'SUCCESS'
) {
  if (!req.auth?.branchId || !req.auth?.companyId) return;
  logBranchActivity({
    branchId: req.auth.branchId,
    companyId: req.auth.companyId,
    countryId: req.auth.country || 'PK',
    managerId: req.auth.userId,
    actorName: req.auth.fullName,
    actorRole: req.auth.role,
    action,
    module,
    targetId: targetId || null,
    details: details || null,
    ipAddress: getClientIp(req),
    status,
  });
}

function rejectCrossBranchAccess(
  req: Request,
  res: Response,
  attemptedTarget: string,
  targetScope?: string | null
) {
  const ip = getClientIp(req);
  const msg = `Branch Manager (${req.auth?.email}, assignedBranch=${req.auth?.branchId}, company=${req.auth?.companyId}, country=${req.auth?.country}) attempted cross-scope access on "${attemptedTarget}" (targetScope=${targetScope || 'unknown'}).`;
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'CROSS_BRANCH_ACCESS_ATTEMPT',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId || null,
    details: msg,
    ipAddress: ip,
  });
  recordBranchAction(req, 'CROSS_BRANCH_ACCESS_BLOCKED', 'Security Isolation', attemptedTarget, msg, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Cross-branch, cross-company, or cross-country data access is strictly prohibited.',
  });
}

function rejectGovernanceViolation(req: Request, res: Response, reason: string, targetId?: string) {
  const ip = getClientIp(req);
  logSecurityEvent({
    severity: 'CRITICAL',
    eventType: 'BRANCH_MANAGER_PRIVILEGE_VIOLATION',
    userId: req.auth?.userId,
    identifier: req.auth?.email,
    companyId: req.auth?.companyId || null,
    details: reason,
    ipAddress: ip,
  });
  recordBranchAction(req, 'PRIVILEGE_ESCALATION_BLOCKED', 'Security Isolation', targetId || null, reason, 'ALERT');
  res.status(403).json({
    error: 'Forbidden: Branch Managers cannot modify privileged roles, change their assigned branch, or alter global settings.',
  });
}

function getAssignedBranch(req: Request) {
  const branchId = req.auth!.branchId!;
  return sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(branchId) as any;
}

function assertBranchQueryNotSpoofed(req: Request, res: Response): boolean {
  const assignedBranchId = req.auth!.branchId!;
  const assignedCompanyId = req.auth!.companyId!;
  const assignedCountry = (req.auth!.country || '').toUpperCase();
  const branch = getAssignedBranch(req);
  const assignedBranchCode = branch ? String(branch.code).toUpperCase() : '';

  const qBranchId = req.query.branchId ? String(req.query.branchId).trim() : null;
  const bBranchId = req.body && req.body.branchId ? String(req.body.branchId).trim() : null;
  const bBranchIdSnake = req.body && req.body.branch_id ? String(req.body.branch_id).trim() : null;
  const reqBranchId = qBranchId || bBranchId || bBranchIdSnake;
  if (reqBranchId && reqBranchId !== assignedBranchId) {
    rejectCrossBranchAccess(req, res, req.originalUrl, `branchId=${reqBranchId}`);
    return false;
  }

  const qBranchCode = req.query.branchCode ? String(req.query.branchCode).trim().toUpperCase() : null;
  const bBranchCode = req.body && req.body.branchCode ? String(req.body.branchCode).trim().toUpperCase() : null;
  const reqBranchCode = qBranchCode || bBranchCode;
  if (reqBranchCode && assignedBranchCode && reqBranchCode !== assignedBranchCode) {
    rejectCrossBranchAccess(req, res, req.originalUrl, `branchCode=${reqBranchCode}`);
    return false;
  }

  const qCompanyId = req.query.companyId ? String(req.query.companyId).trim() : null;
  const bCompanyId = req.body && req.body.companyId ? String(req.body.companyId).trim() : null;
  const bCompanyIdSnake = req.body && req.body.company_id ? String(req.body.company_id).trim() : null;
  const reqCompanyId = qCompanyId || bCompanyId || bCompanyIdSnake;
  if (reqCompanyId && reqCompanyId !== assignedCompanyId) {
    rejectCrossBranchAccess(req, res, req.originalUrl, `companyId=${reqCompanyId}`);
    return false;
  }

  const qCountry = req.query.country ? String(req.query.country).trim().toUpperCase() : null;
  const qCountryId = req.query.countryId ? String(req.query.countryId).trim().toUpperCase() : null;
  const bCountry = req.body && req.body.country ? String(req.body.country).trim().toUpperCase() : null;
  const bCountryId = req.body && req.body.countryId ? String(req.body.countryId).trim().toUpperCase() : null;
  const reqCountry = qCountry || qCountryId || bCountry || bCountryId;
  if (reqCountry && assignedCountry && reqCountry !== assignedCountry) {
    rejectCrossBranchAccess(req, res, req.originalUrl, `country=${reqCountry}`);
    return false;
  }

  return true;
}

function hasEmailConflict(email: string): boolean {
  const e = email.trim().toLowerCase();
  const tables = [
    'founder_accounts',
    'super_admin_accounts',
    'company_admin_accounts',
    'country_manager_accounts',
    'branch_manager_accounts',
    'users',
    'employee_accounts',
  ];
  for (const tbl of tables) {
    const found = sqlite.prepare(`SELECT id FROM ${tbl} WHERE lower(email) = ?`).get(e);
    if (found) return true;
  }
  return false;
}

export function createBranchManagerRouter() {
  const router = express.Router();

  // Strictly enforce verified Branch Manager authentication across every endpoint
  router.use(requireBranchManager);

  // =========================================================================
  // 1. REAL-TIME BRANCH MANAGER DASHBOARD (STRICTLY BRANCH-ISOLATED)
  // =========================================================================
  router.get('/dashboard', (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const branch = sqlite.prepare('SELECT * FROM branches WHERE id = ? AND company_id = ?').get(branchId, companyId) as any;
    if (!branch) {
      res.status(404).json({ error: 'Assigned branch record not found.' });
      return;
    }

    const company = sqlite.prepare('SELECT id, name, city, country, official_email FROM companies WHERE id = ?').get(companyId) as any;
    const country = sqlite.prepare('SELECT id, code, name, flag_emoji, currency FROM countries WHERE id = ?').get(branch.country_id) as any;
    const assignment = sqlite
      .prepare("SELECT * FROM branch_assignments WHERE manager_id = ? AND branch_id = ? AND status = 'Active' ORDER BY created_at DESC LIMIT 1")
      .get(req.auth!.userId, branchId) as any;

    const totalEmployees = (
      sqlite.prepare('SELECT COUNT(*) as c FROM employee_accounts WHERE branch_id = ? AND company_id = ?').get(branchId, companyId) as any
    ).c;

    const totalDealers = (
      sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE branch_id = ? AND company_id = ? AND status = 'Approved'").get(branchId, companyId) as any
    ).c;

    const pendingDealerApplications = (
      sqlite.prepare("SELECT COUNT(*) as c FROM dealerships WHERE branch_id = ? AND company_id = ? AND status = 'Pending Approval'").get(branchId, companyId) as any
    ).c;

    const totalCustomers = (
      sqlite.prepare("SELECT COUNT(*) as c FROM users WHERE branch_id = ? AND company_id = ? AND role = 'Customer'").get(branchId, companyId) as any
    ).c;

    const totalVehicles = (
      sqlite.prepare('SELECT COUNT(*) as c FROM vehicles WHERE branch_id = ? AND company_id = ?').get(branchId, companyId) as any
    ).c;

    const invCounts = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN bi.stock_state = 'Available' THEN 1 ELSE 0 END), 0) as availableCount,
          COALESCE(SUM(CASE WHEN bi.stock_state = 'Reserved' THEN 1 ELSE 0 END), 0) as reservedCount,
          COALESCE(SUM(CASE WHEN bi.stock_state = 'Sold' THEN 1 ELSE 0 END), 0) as soldCount
        FROM vehicles v
        LEFT JOIN branch_inventory bi ON bi.vehicle_id = v.id
        WHERE v.branch_id = ? AND v.company_id = ?
      `)
      .get(branchId, companyId) as any;

    const totalBookings = (
      sqlite.prepare('SELECT COUNT(*) as c FROM bookings WHERE branch_id = ? AND company_id = ?').get(branchId, companyId) as any
    ).c;

    const pendingBookings = (
      sqlite.prepare("SELECT COUNT(*) as c FROM bookings WHERE branch_id = ? AND company_id = ? AND status = 'Pending'").get(branchId, companyId) as any
    ).c;

    const salesRow = sqlite
      .prepare('SELECT COUNT(*) as c, COALESCE(SUM(sale_amount_pkr), 0) as salesValue, COALESCE(SUM(paid_amount_pkr), 0) as collectedValue FROM branch_sales WHERE branch_id = ? AND company_id = ?')
      .get(branchId, companyId) as any;

    const invRev = sqlite
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'Paid' THEN total_amount ELSE 0 END), 0) as paidTotal,
          COALESCE(SUM(CASE WHEN status = 'Pending Payment' THEN total_amount ELSE 0 END), 0) as pendingTotal
        FROM payments_invoices
        WHERE branch_id = ? AND company_id = ?
      `)
      .get(branchId, companyId) as any;

    const expRow = sqlite
      .prepare('SELECT COALESCE(SUM(amount_pkr), 0) as totalExpenses FROM branch_expenses WHERE branch_id = ? AND company_id = ?')
      .get(branchId, companyId) as any;

    const openServiceJobs = (
      sqlite.prepare("SELECT COUNT(*) as c FROM service_jobs WHERE branch_id = ? AND company_id = ? AND status != 'Completed'").get(branchId, companyId) as any
    ).c;

    const openCrm = (
      sqlite.prepare("SELECT COUNT(*) as c FROM customer_crm_records WHERE branch_id = ? AND company_id = ? AND status IN ('Open', 'In Progress')").get(branchId, companyId) as any
    ).c;

    const pendingEscalations = (
      sqlite.prepare("SELECT COUNT(*) as c FROM branch_escalations WHERE branch_id = ? AND status = 'Pending Higher Approval'").get(branchId) as any
    ).c;

    const pendingTasks = pendingBookings + pendingDealerApplications + openServiceJobs + openCrm + pendingEscalations;

    const recentActivities = sqlite
      .prepare('SELECT * FROM branch_activity_logs WHERE branch_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(branchId);

    const notifications = sqlite
      .prepare(`
        SELECT * FROM notifications
        WHERE (branch_id = ? OR (branch_id IS NULL AND company_id = ?))
        ORDER BY created_at DESC
        LIMIT 15
      `)
      .all(branchId, companyId);

    res.json({
      branch: {
        ...branch,
        working_hours: safeJsonParse(branch.working_hours_json, {}),
        departments: safeJsonParse(branch.departments_json, []),
        documents: safeJsonParse(branch.documents_json, []),
        daily_operations: safeJsonParse(branch.daily_operations_json, {}),
        announcements: safeJsonParse(branch.announcements_json, []),
      },
      company,
      country,
      assignment,
      permissions: req.auth!.permissions,
      canonicalPermissions: [...CANONICAL_BRANCH_MANAGER_PERMISSIONS],
      metrics: {
        totalEmployees,
        totalDealers,
        pendingDealerApplications,
        totalCustomers,
        totalVehicles,
        availableVehicles: Number(invCounts.availableCount || 0),
        reservedVehicles: Number(invCounts.reservedCount || 0),
        soldVehicles: Number(invCounts.soldCount || 0),
        totalBookings,
        pendingBookings,
        totalSalesOrders: Number(salesRow.c || 0),
        branchSalesVolumePkr: Number(salesRow.salesValue || 0),
        branchRevenuePkr: Math.max(Number(invRev.paidTotal || 0), Number(salesRow.collectedValue || 0)),
        pendingRevenuePkr: Number(invRev.pendingTotal || 0),
        totalExpensesPkr: Number(expRow.totalExpenses || 0),
        openServiceJobs,
        openCrm,
        pendingEscalations,
        pendingTasks,
      },
      recentActivities,
      notifications,
    });
  });

  // =========================================================================
  // 2. BRANCH PROFILE & DAILY OPERATIONS
  // =========================================================================
  router.get('/branch', (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const branch = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(branchId) as any;
    if (!branch) {
      res.status(404).json({ error: 'Branch record not found.' });
      return;
    }
    const company = sqlite.prepare('SELECT id, name, city, country FROM companies WHERE id = ?').get(branch.company_id) as any;
    const country = sqlite.prepare('SELECT id, code, name, flag_emoji, currency FROM countries WHERE id = ?').get(branch.country_id) as any;
    res.json({
      branch: {
        ...branch,
        working_hours: safeJsonParse(branch.working_hours_json, {}),
        departments: safeJsonParse(branch.departments_json, []),
        documents: safeJsonParse(branch.documents_json, []),
        daily_operations: safeJsonParse(branch.daily_operations_json, {}),
        announcements: safeJsonParse(branch.announcements_json, []),
      },
      company,
      country,
    });
  });

  router.put('/branch', requireBranchPermission('branch.profile.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const body = req.body || {};

    // Prevent Branch Manager from altering immutable structural identifiers or assigned branch ID
    if (
      (body.id && String(body.id) !== branchId) ||
      (body.managerId && String(body.managerId) !== req.auth!.userId) ||
      (body.manager_id && String(body.manager_id) !== req.auth!.userId) ||
      body.code !== undefined
    ) {
      rejectGovernanceViolation(
        req,
        res,
        `Branch Manager attempted to tamper with immutable branch identity or manager assignment fields.`,
        branchId
      );
      return;
    }

    const existing = sqlite.prepare('SELECT * FROM branches WHERE id = ?').get(branchId) as any;
    if (!existing) {
      res.status(404).json({ error: 'Branch not found.' });
      return;
    }

    const address = body.address !== undefined ? String(body.address).trim() : existing.address;
    const phone = body.phone !== undefined ? String(body.phone).trim() : existing.phone;
    const email = body.email !== undefined ? String(body.email).trim() : existing.email;
    const workingHoursJson = body.workingHours !== undefined ? JSON.stringify(body.workingHours) : existing.working_hours_json;
    const departmentsJson = body.departments !== undefined ? JSON.stringify(body.departments) : existing.departments_json;
    const documentsJson = body.documents !== undefined ? JSON.stringify(body.documents) : existing.documents_json;
    const dailyOpsJson = body.dailyOperations !== undefined ? JSON.stringify(body.dailyOperations) : existing.daily_operations_json;
    const announcementsJson = body.announcements !== undefined ? JSON.stringify(body.announcements) : existing.announcements_json;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE branches
        SET address = ?, phone = ?, email = ?, working_hours_json = ?, departments_json = ?,
            documents_json = ?, daily_operations_json = ?, announcements_json = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(address, phone, email, workingHoursJson, departmentsJson, documentsJson, dailyOpsJson, announcementsJson, now, branchId);

    sqlite
      .prepare('UPDATE company_branches SET address = ?, phone = ?, email = ?, updated_at = ? WHERE id = ?')
      .run(address, phone, email, now, branchId);

    sqlite
      .prepare('UPDATE country_branches SET address = ?, phone = ?, email = ?, updated_at = ? WHERE company_branch_id = ?')
      .run(address, phone, email, now, branchId);

    recordBranchAction(req, 'BRANCH_PROFILE_UPDATED', 'Branch Operations', branchId, `Updated operational profile & working hours for ${existing.name}.`);
    res.json({ success: true, message: 'Branch profile & operational settings updated.' });
  });

  // =========================================================================
  // 3. BRANCH EMPLOYEE MANAGEMENT
  // =========================================================================
  router.get('/employees', requireBranchPermission('employees.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const employees = sqlite
      .prepare(`
        SELECT e.*, u.role as user_role, u.status as user_status, u.last_login_at,
               ber.shift_schedule, ber.daily_task, ber.task_status
        FROM employee_accounts e
        LEFT JOIN users u ON u.id = e.user_id
        LEFT JOIN branch_employee_relationships ber ON ber.employee_id = e.id AND ber.branch_id = e.branch_id
        WHERE e.branch_id = ? AND e.company_id = ?
        ORDER BY e.created_at DESC
      `)
      .all(branchId, companyId)
      .map((row: any) => ({
        ...row,
        attendance: safeJsonParse(row.attendance_json, []),
        leave_requests: safeJsonParse(row.leave_requests_json, []),
        permissions: safeJsonParse(row.permissions_json, []),
      }));

    res.json({ employees });
  });

  router.post('/employees', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { fullName, email, mobile, role, department, jobPosition, employeeCode, password, shiftSchedule, dailyTask } = req.body || {};

    if (!fullName || !email || !mobile || !role) {
      res.status(400).json({ error: 'Full name, email, mobile, and operational role are required.' });
      return;
    }

    if (FORBIDDEN_PRIVILEGED_ROLES.includes(String(role).trim())) {
      rejectGovernanceViolation(
        req,
        res,
        `Branch Manager attempted to create privileged role "${role}" (${email}).`,
        String(email)
      );
      return;
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (hasEmailConflict(cleanEmail)) {
      res.status(409).json({ error: 'An account with this email already exists on the platform.' });
      return;
    }

    const rawPass = password ? String(password) : `BydEmp#${generateSecureToken(6)}!1`;
    if (password) {
      const check = validatePasswordStrength(rawPass);
      if (!check.valid) {
        res.status(400).json({ error: check.reason });
        return;
      }
    }

    const now = nowIso();
    const userId = `usr_${generateSecureToken(6)}`;
    const empId = `emp_${generateSecureToken(6)}`;
    const finalEmpCode = employeeCode
      ? String(employeeCode).trim().toUpperCase()
      : `${branch.code}-${Math.floor(100 + Math.random() * 900)}`;

    const dupCode = sqlite
      .prepare('SELECT id FROM employee_accounts WHERE company_id = ? AND employee_code = ?')
      .get(companyId, finalEmpCode);
    if (dupCode) {
      res.status(409).json({ error: `Employee code ${finalEmpCode} already exists in this company.` });
      return;
    }

    const username = `${cleanEmail.split('@')[0].replace(/[^a-z0-9_]/gi, '_')}_${generateSecureToken(2)}`;
    const dealership = sqlite
      .prepare('SELECT id FROM dealerships WHERE branch_id = ? AND company_id = ? LIMIT 1')
      .get(branchId, companyId) as { id: string } | undefined;

    const passHash = hashPassword(rawPass);
    const totpSecret = generateTotpSecret();
    const deptName = String(department || 'Branch Operations').trim();
    const posName = String(jobPosition || role).trim();
    const deptRow = sqlite
      .prepare('SELECT id FROM employee_departments WHERE company_id = ? AND LOWER(name) = LOWER(?) LIMIT 1')
      .get(companyId, deptName) as { id: string } | undefined;

    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, branch_id, full_name, username, email, mobile, password_hash,
          role, country, city, dealership_id, status, email_verified, two_factor_enabled,
          created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, 0, ?, ?, ?)
      `)
      .run(
        userId,
        companyId,
        branchId,
        String(fullName).trim(),
        username,
        cleanEmail,
        String(mobile).trim(),
        passHash,
        String(role).trim(),
        branch.country_id,
        branch.city,
        dealership?.id || null,
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_accounts (
          id, user_id, company_id, country_id, branch_id, department_id, employee_code,
          full_name, username, email, mobile, department, job_position,
          reporting_manager_id, reporting_manager_name, password_hash,
          email_verified, two_factor_enabled, two_factor_secret,
          status, attendance_json, leave_requests_json, performance_score, permissions_json,
          joined_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, 'Active', '[]', '[]', 93.0, ?, ?, ?, ?)
      `)
      .run(
        empId,
        userId,
        companyId,
        branch.country_id,
        branchId,
        deptRow?.id || null,
        finalEmpCode,
        String(fullName).trim(),
        username,
        cleanEmail,
        String(mobile).trim(),
        deptName,
        posName,
        req.auth!.userId,
        req.auth!.fullName,
        passHash,
        totpSecret,
        JSON.stringify([...CANONICAL_EMPLOYEE_PERMISSIONS]),
        now.slice(0, 10),
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT OR IGNORE INTO employee_profiles (
          id, employee_id, company_id, country_id, branch_id, department_id,
          reporting_manager_id, reporting_manager_name, bio, city, work_location,
          employment_type, responsibilities_json, skills_json, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Full-Time Permanent', ?, '[]', ?)
      `)
      .run(
        `ep_${empId}`,
        empId,
        companyId,
        branch.country_id,
        branchId,
        deptRow?.id || null,
        req.auth!.userId,
        req.auth!.fullName,
        `${posName} at ${branch.name}.`,
        branch.city,
        branch.name,
        JSON.stringify([String(dailyTask || 'Branch customer & EV operational support').trim()]),
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_assignments (
          id, employee_id, company_id, country_id, branch_id, department_id, job_position,
          reporting_manager_id, reporting_manager_name, shift_schedule, effective_from, status, assigned_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?, ?)
      `)
      .run(
        `ea_${empId}`,
        empId,
        companyId,
        branch.country_id,
        branchId,
        deptRow?.id || null,
        posName,
        req.auth!.userId,
        req.auth!.fullName,
        String(shiftSchedule || 'Mon-Sat 09:00-18:00').trim(),
        now.slice(0, 10),
        req.auth!.userId,
        now,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO employee_notifications (
          id, employee_id, company_id, country_id, branch_id, category, title, message,
          sender_name, sender_role, priority, is_read, created_at
        ) VALUES (?, ?, ?, ?, ?, 'Manager Message', ?, ?, ?, 'Branch Manager', 'Normal', 0, ?)
      `)
      .run(
        `enot_${generateSecureToken(5)}`,
        empId,
        companyId,
        branch.country_id,
        branchId,
        `Welcome to ${branch.name} (${finalEmpCode})`,
        `Your Employee account is active. Use Employee ID ${finalEmpCode} or email ${cleanEmail} on the Employee Login Portal.`,
        req.auth!.fullName,
        now
      );

    sqlite
      .prepare(`
        INSERT INTO branch_employee_relationships (
          id, branch_id, company_id, employee_id, employee_code, shift_schedule, daily_task, task_status, assigned_by, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Assigned', ?, ?)
      `)
      .run(
        `ber_${generateSecureToken(5)}`,
        branchId,
        companyId,
        empId,
        finalEmpCode,
        String(shiftSchedule || 'Mon-Sat 09:00-18:00').trim(),
        String(dailyTask || 'Branch customer & EV operational support').trim(),
        req.auth!.userId,
        now
      );

    recordBranchAction(req, 'BRANCH_EMPLOYEE_CREATED', 'Employee Management', empId, `Created branch employee ${fullName} (${finalEmpCode}, ${role}).`);
    res.status(201).json({
      success: true,
      employeeId: empId,
      userId,
      employeeCode: finalEmpCode,
      message: 'Branch employee account created & linked to assigned branch.',
    });
  });

  router.patch('/employees/:id', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (emp.branch_id !== branchId || emp.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `employees/${id}`, `branch=${emp.branch_id}`);
      return;
    }

    const body = req.body || {};
    const newCode = body.employeeCode ? String(body.employeeCode).trim().toUpperCase() : emp.employee_code;
    const department = body.department ? String(body.department).trim() : emp.department;
    const jobPosition = body.jobPosition ? String(body.jobPosition).trim() : emp.job_position;
    const status = body.status && ['Active', 'Suspended', 'On Leave'].includes(body.status) ? body.status : emp.status;
    const perfScore = body.performanceScore !== undefined ? Number(body.performanceScore) : emp.performance_score;
    const perfNotes = body.performanceNotes !== undefined ? String(body.performanceNotes) : emp.performance_notes;
    const now = nowIso();

    sqlite
      .prepare(`
        UPDATE employee_accounts
        SET employee_code = ?, department = ?, job_position = ?, status = ?,
            performance_score = ?, performance_notes = ?, updated_at = ?
        WHERE id = ?
      `)
      .run(newCode, department, jobPosition, status, perfScore, perfNotes, now, id);

    sqlite
      .prepare('UPDATE branch_employee_relationships SET employee_code = ?, updated_at = ? WHERE employee_id = ? AND branch_id = ?')
      .run(newCode, now, id, branchId);

    if (emp.user_id && body.status) {
      const userStatus = status === 'Suspended' ? 'Suspended' : 'Active';
      sqlite.prepare('UPDATE users SET status = ?, updated_at = ? WHERE id = ?').run(userStatus, now, emp.user_id);
      if (userStatus === 'Suspended') {
        sqlite.prepare('UPDATE authentication_sessions SET revoked = 1 WHERE user_id = ?').run(emp.user_id);
      }
    }

    recordBranchAction(req, 'BRANCH_EMPLOYEE_UPDATED', 'Employee Management', id, `Updated ${emp.full_name} (${newCode}, ${status}).`);
    res.json({ success: true });
  });

  router.post('/employees/:id/attendance', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (emp.branch_id !== branchId || emp.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `employees/${id}/attendance`, `branch=${emp.branch_id}`);
      return;
    }

    const { date, status, checkIn, checkOut, notes } = req.body || {};
    const validStatus = ['Present', 'Absent', 'Late', 'Remote', 'Half-Day'].includes(status) ? status : 'Present';
    const recordDate = date ? String(date).slice(0, 10) : nowIso().slice(0, 10);
    const list = safeJsonParse<any[]>(emp.attendance_json, []);
    const filtered = list.filter((a) => a.date !== recordDate);
    filtered.unshift({
      date: recordDate,
      status: validStatus,
      checkIn: checkIn || '09:00',
      checkOut: checkOut || '18:00',
      notes: notes || 'Verified by Branch Manager',
      recordedBy: req.auth!.fullName,
    });

    const now = nowIso();
    sqlite
      .prepare('UPDATE employee_accounts SET attendance_json = ?, updated_at = ? WHERE id = ?')
      .run(JSON.stringify(filtered.slice(0, 90)), now, id);

    sqlite
      .prepare(`
        INSERT INTO employee_attendance (
          id, employee_id, company_id, country_id, branch_id, attendance_date,
          check_in_at, check_out_at, working_hours, status, notes, correction_status, correction_reviewed_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 9.0, ?, ?, 'Reviewed', ?, ?, ?)
        ON CONFLICT(employee_id, attendance_date) DO UPDATE SET
          status = excluded.status,
          notes = excluded.notes,
          correction_status = 'Approved',
          correction_reviewed_by = excluded.correction_reviewed_by,
          updated_at = excluded.updated_at
      `)
      .run(
        `att_${generateSecureToken(5)}`,
        id,
        companyId,
        emp.country_id || req.auth!.country,
        branchId,
        recordDate,
        `${recordDate}T${checkIn || '09:00'}:00.000Z`,
        `${recordDate}T${checkOut || '18:00'}:00.000Z`,
        validStatus,
        notes || 'Verified by Branch Manager',
        req.auth!.fullName,
        now,
        now
      );

    recordBranchAction(req, 'ATTENDANCE_RECORDED', 'Employee Management', id, `${emp.full_name}: ${validStatus} on ${recordDate}.`);
    res.json({ success: true });
  });

  router.patch('/employees/:id/leave', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (emp.branch_id !== branchId || emp.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `employees/${id}/leave`, `branch=${emp.branch_id}`);
      return;
    }

    const { leaveId, action, startDate, endDate, leaveType, reason, reviewNotes } = req.body || {};
    const leaves = safeJsonParse<any[]>(emp.leave_requests_json, []);
    const now = nowIso();

    if (action === 'create') {
      const newLeaveId = `lv_${generateSecureToken(4)}`;
      const sDate = startDate || now.slice(0, 10);
      const eDate = endDate || now.slice(0, 10);
      const lType = leaveType || 'Annual Leave';
      const lReason = reason || 'Personal / family commitment';
      leaves.unshift({
        id: newLeaveId,
        type: lType,
        startDate: sDate,
        endDate: eDate,
        reason: lReason,
        status: 'Pending',
        submittedAt: now,
      });
      sqlite
        .prepare(`
          INSERT OR IGNORE INTO employee_leave_requests (
            id, employee_id, company_id, country_id, branch_id, leave_type, start_date, end_date, total_days, reason, status, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'Pending', ?, ?)
        `)
        .run(newLeaveId, id, companyId, emp.country_id || req.auth!.country, branchId, lType, sDate, eDate, lReason, now, now);
    } else if (leaveId && ['Approved', 'Rejected'].includes(action)) {
      const idx = leaves.findIndex((l) => l.id === leaveId);
      const normRow = sqlite.prepare('SELECT * FROM employee_leave_requests WHERE id = ? AND employee_id = ?').get(leaveId, id) as any;
      if (idx === -1 && !normRow) {
        res.status(404).json({ error: 'Leave request not found.' });
        return;
      }
      if (idx !== -1) {
        leaves[idx].status = action;
        leaves[idx].reviewedBy = req.auth!.fullName;
        leaves[idx].reviewedAt = now;
      }
      if (normRow) {
        sqlite
          .prepare('UPDATE employee_leave_requests SET status = ?, reviewed_by_id = ?, reviewed_by_name = ?, review_notes = ?, reviewed_at = ?, updated_at = ? WHERE id = ?')
          .run(action, req.auth!.userId, req.auth!.fullName, reviewNotes || null, now, now, leaveId);
      }
      if (action === 'Approved') {
        sqlite.prepare("UPDATE employee_accounts SET status = 'On Leave', updated_at = ? WHERE id = ?").run(now, id);
      }
      sqlite
        .prepare(`
          INSERT INTO employee_notifications (
            id, employee_id, company_id, country_id, branch_id, category, title, message,
            sender_name, sender_role, priority, is_read, created_at
          ) VALUES (?, ?, ?, ?, ?, 'Leave Status', ?, ?, ?, 'Branch Manager', 'High', 0, ?)
        `)
        .run(
          `enot_${generateSecureToken(5)}`,
          id,
          companyId,
          emp.country_id || req.auth!.country,
          branchId,
          `Leave Request ${action} (${leaveId})`,
          `Your ${normRow?.leave_type || leaves[idx]?.type || 'Leave'} request has been marked ${action} by ${req.auth!.fullName}.`,
          req.auth!.fullName,
          now
        );
    } else {
      res.status(400).json({ error: 'Provide action=create or leaveId + action=Approved|Rejected.' });
      return;
    }

    sqlite
      .prepare('UPDATE employee_accounts SET leave_requests_json = ?, updated_at = ? WHERE id = ?')
      .run(JSON.stringify(leaves), now, id);

    recordBranchAction(req, 'EMPLOYEE_LEAVE_UPDATED', 'Employee Management', id, `${emp.full_name} leave ${action}.`);
    res.json({ success: true, leaves });
  });

  router.post('/employees/:id/tasks', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (emp.branch_id !== branchId || emp.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `employees/${id}/tasks`, `branch=${emp.branch_id}`);
      return;
    }

    const title = String(req.body.title || '').trim();
    const description = String(req.body.description || '').trim();
    const priority = ['Low', 'Medium', 'High', 'Critical'].includes(String(req.body.priority)) ? String(req.body.priority) : 'Medium';
    const dueDate = String(req.body.dueDate || new Date(Date.now() + 3 * 86400_000).toISOString().slice(0, 10));
    if (!title || !description) {
      res.status(400).json({ error: 'Task title and description are required.' });
      return;
    }

    const now = nowIso();
    const taskId = `tsk_${generateSecureToken(5)}`;
    const taskCode = `TSK-${emp.employee_code}-${Math.floor(100 + Math.random() * 900)}`;

    sqlite
      .prepare(`
        INSERT INTO employee_tasks (
          id, task_code, employee_id, company_id, country_id, branch_id, title, description,
          priority, due_date, status, assigned_by_id, assigned_by_name, work_updates_json, attachment_doc_ids_json, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, '[]', '[]', ?, ?)
      `)
      .run(taskId, taskCode, id, companyId, emp.country_id || req.auth!.country, branchId, title, description, priority, dueDate, req.auth!.userId, req.auth!.fullName, now, now);

    sqlite
      .prepare(`
        INSERT INTO employee_notifications (
          id, employee_id, company_id, country_id, branch_id, category, title, message,
          sender_name, sender_role, priority, is_read, created_at
        ) VALUES (?, ?, ?, ?, ?, 'Task Assigned', ?, ?, ?, 'Branch Manager', ?, 0, ?)
      `)
      .run(
        `enot_${generateSecureToken(5)}`,
        id,
        companyId,
        emp.country_id || req.auth!.country,
        branchId,
        `New Task Assigned: ${title}`,
        `${req.auth!.fullName} assigned "${title}" (Priority: ${priority}, Due: ${dueDate}).`,
        req.auth!.fullName,
        priority === 'Critical' || priority === 'High' ? 'High' : 'Normal',
        now
      );

    recordBranchAction(req, 'EMPLOYEE_TASK_ASSIGNED', 'Employee Management', taskId, `Assigned "${title}" to ${emp.full_name} (${emp.employee_code}).`);
    res.status(201).json({ success: true, taskId, taskCode });
  });

  router.patch('/employees/:id/task-schedule', requireBranchPermission('employees.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const emp = sqlite.prepare('SELECT * FROM employee_accounts WHERE id = ?').get(id) as any;
    if (!emp) {
      res.status(404).json({ error: 'Employee not found.' });
      return;
    }
    if (emp.branch_id !== branchId || emp.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `employees/${id}/task-schedule`, `branch=${emp.branch_id}`);
      return;
    }

    const { shiftSchedule, dailyTask, taskStatus } = req.body || {};
    const now = nowIso();
    const existing = sqlite
      .prepare('SELECT * FROM branch_employee_relationships WHERE branch_id = ? AND employee_id = ?')
      .get(branchId, id) as any;

    if (existing) {
      sqlite
        .prepare(`
          UPDATE branch_employee_relationships
          SET shift_schedule = ?, daily_task = ?, task_status = ?, assigned_by = ?, updated_at = ?
          WHERE id = ?
        `)
        .run(
          shiftSchedule !== undefined ? String(shiftSchedule).trim() : existing.shift_schedule,
          dailyTask !== undefined ? String(dailyTask).trim() : existing.daily_task,
          taskStatus !== undefined ? String(taskStatus).trim() : existing.task_status,
          req.auth!.userId,
          now,
          existing.id
        );
    } else {
      sqlite
        .prepare(`
          INSERT INTO branch_employee_relationships (
            id, branch_id, company_id, employee_id, employee_code, shift_schedule, daily_task, task_status, assigned_by, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          `ber_${generateSecureToken(5)}`,
          branchId,
          companyId,
          id,
          emp.employee_code,
          String(shiftSchedule || 'Mon-Sat 09:00-18:00').trim(),
          String(dailyTask || 'Branch customer & EV operations').trim(),
          String(taskStatus || 'Assigned').trim(),
          req.auth!.userId,
          now
        );
    }

    recordBranchAction(req, 'SHIFT_AND_TASK_ASSIGNED', 'Employee Management', id, `Assigned schedule/task to ${emp.full_name}.`);
    res.json({ success: true });
  });

  router.get('/employees/report', requireBranchPermission('employees.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const emps = sqlite
      .prepare('SELECT * FROM employee_accounts WHERE branch_id = ? AND company_id = ?')
      .all(branchId, companyId) as any[];

    const byDepartment: Record<string, number> = {};
    let activeCount = 0;
    let onLeaveCount = 0;
    let suspendedCount = 0;
    let pendingLeaves = 0;
    let totalPerf = 0;

    for (const e of emps) {
      byDepartment[e.department] = (byDepartment[e.department] || 0) + 1;
      if (e.status === 'Active') activeCount++;
      else if (e.status === 'On Leave') onLeaveCount++;
      else suspendedCount++;
      totalPerf += Number(e.performance_score || 0);
      const leaves = safeJsonParse<any[]>(e.leave_requests_json, []);
      pendingLeaves += leaves.filter((l) => l.status === 'Pending').length;
    }

    res.json({
      totalEmployees: emps.length,
      activeCount,
      onLeaveCount,
      suspendedCount,
      pendingLeaves,
      averagePerformance: emps.length ? Number((totalPerf / emps.length).toFixed(1)) : 0,
      byDepartment,
    });
  });

  // =========================================================================
  // 4. BRANCH VEHICLE INVENTORY & TRANSFER REQUESTS
  // =========================================================================
  router.get('/vehicles', requireBranchPermission('vehicles.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const vehicles = sqlite
      .prepare(`
        SELECT v.*, bi.id as inventory_id, bi.stock_state, bi.condition_grade, bi.condition_notes,
               bi.reserved_customer_name, bi.transfer_request_status, bi.transfer_target_branch_id
        FROM vehicles v
        LEFT JOIN branch_inventory bi ON bi.vehicle_id = v.id
        WHERE v.branch_id = ? AND v.company_id = ?
        ORDER BY v.created_at DESC
      `)
      .all(branchId, companyId);

    const siblingBranches = sqlite
      .prepare('SELECT id, code, name, city FROM branches WHERE company_id = ? AND id != ?')
      .all(companyId, branchId);

    const transferRequests = sqlite
      .prepare("SELECT * FROM branch_escalations WHERE branch_id = ? AND request_type = 'Vehicle Transfer Request' ORDER BY created_at DESC")
      .all(branchId);

    res.json({ vehicles, siblingBranches, transferRequests });
  });

  router.post('/vehicles', requireBranchPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { vin, chassisNumber, model, variant, color, year, salePricePkr, conditionGrade, conditionNotes, stockState } = req.body || {};
    if (!vin || !model || !variant) {
      res.status(400).json({ error: 'VIN, EV model, and variant are required.' });
      return;
    }

    const cleanVin = String(vin).trim().toUpperCase();
    const dup = sqlite.prepare('SELECT id FROM vehicles WHERE vin = ?').get(cleanVin);
    if (dup) {
      res.status(409).json({ error: `Vehicle VIN ${cleanVin} is already registered.` });
      return;
    }

    const dealership = sqlite
      .prepare('SELECT id, name FROM dealerships WHERE branch_id = ? AND company_id = ? LIMIT 1')
      .get(branchId, companyId) as { id: string; name: string } | undefined;

    const vehId = `veh_${generateSecureToken(6)}`;
    const now = nowIso();
    const validStock = ['Available', 'Reserved', 'Sold', 'In Transit'].includes(stockState) ? stockState : 'Available';
    const deliveryStatus = validStock === 'Sold' ? 'Delivered' : validStock === 'Reserved' ? 'Reserved' : validStock === 'In Transit' ? 'In Transit' : 'In Stock';

    sqlite
      .prepare(`
        INSERT INTO vehicles (
          id, company_id, dealership_id, branch_id, vin, chassis_number, model, variant, color, year,
          license_plate, battery_capacity_kwh, battery_health_soh, battery_health_soc, status,
          delivery_status, dealership_purchased, sale_price_pkr, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNREGISTERED', 82.5, 100.0, 95, 'Active', ?, ?, ?, ?)
      `)
      .run(
        vehId,
        companyId,
        dealership?.id || null,
        branchId,
        cleanVin,
        String(chassisNumber || `CHS-${cleanVin.slice(-6)}`).trim(),
        String(model).trim(),
        String(variant).trim(),
        String(color || 'Cosmos Black').trim(),
        Number(year || 2026),
        deliveryStatus,
        branch.name,
        Number(salePricePkr || 15900000),
        now
      );

    sqlite
      .prepare(`
        INSERT INTO branch_inventory (
          id, branch_id, company_id, vehicle_id, vin, stock_state, condition_grade, condition_notes,
          transfer_request_status, updated_by, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'None', ?, ?)
      `)
      .run(
        `binv_${generateSecureToken(6)}`,
        branchId,
        companyId,
        vehId,
        cleanVin,
        validStock,
        String(conditionGrade || 'A+ Factory PDI Passed').trim(),
        String(conditionNotes || 'Logged into branch showroom inventory').trim(),
        req.auth!.fullName,
        now
      );

    recordBranchAction(req, 'BRANCH_VEHICLE_ADDED', 'Vehicle Inventory', vehId, `Added ${model} ${variant} (VIN ${cleanVin}) to ${branch.name}.`);
    res.status(201).json({ success: true, vehicleId: vehId, vin: cleanVin });
  });

  router.patch('/vehicles/:id', requireBranchPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const veh = sqlite.prepare('SELECT * FROM vehicles WHERE id = ?').get(id) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.branch_id !== branchId || veh.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `vehicles/${id}`, `branch=${veh.branch_id}`);
      return;
    }

    const body = req.body || {};
    const validStock = body.stockState && ['Available', 'Reserved', 'Sold', 'In Transit'].includes(body.stockState)
      ? body.stockState
      : undefined;
    const now = nowIso();

    if (validStock) {
      const deliv = validStock === 'Sold' ? 'Delivered' : validStock === 'Reserved' ? 'Reserved' : validStock === 'In Transit' ? 'In Transit' : 'In Stock';
      sqlite
        .prepare('UPDATE vehicles SET delivery_status = ?, sold_at = COALESCE(sold_at, ?) WHERE id = ?')
        .run(deliv, validStock === 'Sold' ? now.slice(0, 10) : null, id);
    }

    if (body.odometerKm !== undefined || body.batteryHealthSoh !== undefined || body.licensePlate !== undefined) {
      sqlite
        .prepare(`
          UPDATE vehicles
          SET odometer_km = COALESCE(?, odometer_km),
              battery_health_soh = COALESCE(?, battery_health_soh),
              license_plate = COALESCE(?, license_plate)
          WHERE id = ?
        `)
        .run(
          body.odometerKm !== undefined ? Number(body.odometerKm) : null,
          body.batteryHealthSoh !== undefined ? Number(body.batteryHealthSoh) : null,
          body.licensePlate ? String(body.licensePlate).trim() : null,
          id
        );
    }

    const existingInv = sqlite.prepare('SELECT * FROM branch_inventory WHERE vehicle_id = ?').get(id) as any;
    if (existingInv) {
      sqlite
        .prepare(`
          UPDATE branch_inventory
          SET stock_state = COALESCE(?, stock_state),
              condition_grade = COALESCE(?, condition_grade),
              condition_notes = COALESCE(?, condition_notes),
              reserved_customer_name = COALESCE(?, reserved_customer_name),
              updated_by = ?, updated_at = ?
          WHERE vehicle_id = ?
        `)
        .run(
          validStock || null,
          body.conditionGrade || null,
          body.conditionNotes || null,
          body.reservedCustomerName || null,
          req.auth!.fullName,
          now,
          id
        );
    } else {
      sqlite
        .prepare(`
          INSERT INTO branch_inventory (
            id, branch_id, company_id, vehicle_id, vin, stock_state, condition_grade, condition_notes, reserved_customer_name, updated_by, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          `binv_${generateSecureToken(5)}`,
          branchId,
          companyId,
          id,
          veh.vin,
          validStock || 'Available',
          body.conditionGrade || 'A+ Factory PDI Passed',
          body.conditionNotes || 'Updated by Branch Manager',
          body.reservedCustomerName || null,
          req.auth!.fullName,
          now
        );
    }

    recordBranchAction(req, 'BRANCH_INVENTORY_UPDATED', 'Vehicle Inventory', id, `Updated inventory/condition for VIN ${veh.vin}.`);
    res.json({ success: true });
  });

  router.post('/vehicles/:id/transfer-request', requireBranchPermission('vehicles.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;
    const { targetBranchId, reason } = req.body || {};

    const veh = sqlite.prepare('SELECT * FROM vehicles WHERE id = ?').get(id) as any;
    if (!veh) {
      res.status(404).json({ error: 'Vehicle not found.' });
      return;
    }
    if (veh.branch_id !== branchId || veh.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `vehicles/${id}/transfer-request`, `branch=${veh.branch_id}`);
      return;
    }
    if (!targetBranchId) {
      res.status(400).json({ error: 'Target branch ID is required.' });
      return;
    }
    const targetBranch = sqlite.prepare('SELECT * FROM branches WHERE id = ? AND company_id = ?').get(targetBranchId, companyId) as any;
    if (!targetBranch) {
      rejectCrossBranchAccess(req, res, `vehicles/${id}/transfer-request`, `targetBranch=${targetBranchId}`);
      return;
    }

    const escId = `besc_${generateSecureToken(6)}`;
    const now = nowIso();
    const branch = getAssignedBranch(req);

    sqlite
      .prepare(`
        INSERT INTO branch_escalations (
          id, branch_id, company_id, country_id, manager_id, manager_name, request_type,
          target_id, title, details, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Vehicle Transfer Request', ?, ?, ?, 'Pending Higher Approval', ?, ?)
      `)
      .run(
        escId,
        branchId,
        companyId,
        branch.country_id,
        req.auth!.userId,
        req.auth!.fullName,
        id,
        `Vehicle Transfer: ${veh.model} (${veh.vin}) -> ${targetBranch.name}`,
        JSON.stringify({ vehicleId: id, vin: veh.vin, fromBranchId: branchId, toBranchId: targetBranchId, toBranchName: targetBranch.name, reason: reason || 'Inter-branch stock balancing' }),
        now,
        now
      );

    sqlite
      .prepare(`
        UPDATE branch_inventory
        SET transfer_request_status = 'Pending Higher Approval', transfer_target_branch_id = ?, updated_by = ?, updated_at = ?
        WHERE vehicle_id = ?
      `)
      .run(targetBranchId, req.auth!.fullName, now, id);

    recordBranchAction(req, 'VEHICLE_TRANSFER_REQUESTED', 'Vehicle Inventory', escId, `Requested transfer of ${veh.vin} to ${targetBranch.name}.`);
    res.status(201).json({ success: true, escalationId: escId });
  });

  // =========================================================================
  // 5. BRANCH SALES & BOOKING MANAGEMENT
  // =========================================================================
  router.get('/sales-bookings', requireBranchPermission('sales.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const bookings = sqlite
      .prepare('SELECT * FROM bookings WHERE branch_id = ? AND company_id = ? ORDER BY created_at DESC')
      .all(branchId, companyId);

    const salesOrders = sqlite
      .prepare('SELECT * FROM branch_sales WHERE branch_id = ? AND company_id = ? ORDER BY created_at DESC')
      .all(branchId, companyId);

    const invoices = sqlite
      .prepare('SELECT * FROM payments_invoices WHERE branch_id = ? AND company_id = ? ORDER BY created_at DESC')
      .all(branchId, companyId);

    const branch = getAssignedBranch(req);

    res.json({
      bookings,
      salesOrders,
      invoices,
      targets: {
        monthlyTargetUnits: branch?.monthly_target_units || 25,
        achievedUnits: branch?.achieved_units || salesOrders.length,
        monthlyRevenuePkr: branch?.monthly_revenue_pkr || 0,
      },
    });
  });

  router.post('/bookings', requireBranchPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { customerId, customerName, customerPhone, bookingType, vehicleModel, preferredDate, preferredTime, notes } = req.body || {};
    if (!customerName || !customerPhone || !vehicleModel) {
      res.status(400).json({ error: 'Customer name, phone, and vehicle model are required.' });
      return;
    }

    const dealership = sqlite.prepare('SELECT id FROM dealerships WHERE branch_id = ? LIMIT 1').get(branchId) as { id: string } | undefined;
    const bookingId = `bkg_${generateSecureToken(6)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO bookings (
          id, company_id, dealership_id, branch_id, customer_id, customer_name, customer_phone,
          booking_type, vehicle_model, preferred_date, preferred_time, city, status, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)
      `)
      .run(
        bookingId,
        companyId,
        dealership?.id || null,
        branchId,
        customerId || `walkin_${generateSecureToken(4)}`,
        String(customerName).trim(),
        String(customerPhone).trim(),
        String(bookingType || 'Vehicle Reservation').trim(),
        String(vehicleModel).trim(),
        String(preferredDate || now.slice(0, 10)),
        String(preferredTime || '11:00 AM'),
        branch.city,
        String(notes || 'Registered at branch showroom desk').trim(),
        now
      );

    recordBranchAction(req, 'BRANCH_BOOKING_CREATED', 'Sales & Bookings', bookingId, `Registered ${bookingType || 'Reservation'} for ${customerName} (${vehicleModel}).`);
    res.status(201).json({ success: true, bookingId });
  });

  router.patch('/bookings/:id', requireBranchPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const bk = sqlite.prepare('SELECT * FROM bookings WHERE id = ?').get(id) as any;
    if (!bk) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }
    if (bk.branch_id !== branchId || bk.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `bookings/${id}`, `branch=${bk.branch_id}`);
      return;
    }

    const { status, notes } = req.body || {};
    const validStatus = ['Pending', 'Confirmed', 'Completed', 'Cancelled'].includes(status) ? status : bk.status;

    sqlite
      .prepare('UPDATE bookings SET status = ?, notes = COALESCE(?, notes) WHERE id = ?')
      .run(validStatus, notes !== undefined ? String(notes) : null, id);

    recordBranchAction(req, 'BRANCH_BOOKING_UPDATED', 'Sales & Bookings', id, `Updated booking ${id} status -> ${validStatus}.`);
    res.json({ success: true });
  });

  router.post('/sales-orders', requireBranchPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { vehicleId, bookingId, vehicleModel, customerName, customerPhone, salesExecName, saleAmountPkr, paidAmountPkr, paymentStatus, deliveryStatus } = req.body || {};
    if (!vehicleModel || !customerName || !customerPhone) {
      res.status(400).json({ error: 'Vehicle model, customer name, and customer phone are required.' });
      return;
    }

    let vin: string | null = null;
    if (vehicleId) {
      const veh = sqlite.prepare('SELECT id, branch_id, company_id, vin FROM vehicles WHERE id = ?').get(vehicleId) as any;
      if (!veh || veh.branch_id !== branchId || veh.company_id !== companyId) {
        rejectCrossBranchAccess(req, res, `sales-orders/vehicle/${vehicleId}`, `branch=${veh?.branch_id}`);
        return;
      }
      vin = veh.vin;
    }

    const id = `bsl_${generateSecureToken(6)}`;
    const orderNumber = `ORD-${branch.code}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = nowIso();
    const saleAmt = Number(saleAmountPkr || 15900000);
    const paidAmt = Number(paidAmountPkr || 2500000);

    sqlite
      .prepare(`
        INSERT INTO branch_sales (
          id, branch_id, company_id, country_id, order_number, booking_id, vehicle_id, vin,
          vehicle_model, customer_name, customer_phone, sales_exec_name, sale_amount_pkr,
          paid_amount_pkr, payment_status, delivery_status, created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        id,
        branchId,
        companyId,
        branch.country_id,
        orderNumber,
        bookingId || null,
        vehicleId || null,
        vin,
        String(vehicleModel).trim(),
        String(customerName).trim(),
        String(customerPhone).trim(),
        String(salesExecName || req.auth!.fullName).trim(),
        saleAmt,
        paidAmt,
        String(paymentStatus || (paidAmt >= saleAmt ? 'Paid' : 'Deposit Paid')),
        String(deliveryStatus || 'Pending PDI'),
        req.auth!.fullName,
        now,
        now
      );

    if (vehicleId) {
      sqlite
        .prepare("UPDATE branch_inventory SET stock_state = 'Reserved', reserved_customer_name = ?, updated_by = ?, updated_at = ? WHERE vehicle_id = ?")
        .run(String(customerName).trim(), req.auth!.fullName, now, vehicleId);
    }

    recordBranchAction(req, 'BRANCH_SALES_ORDER_CREATED', 'Sales & Bookings', id, `Created order ${orderNumber} for ${customerName} (${vehicleModel}).`);
    res.status(201).json({ success: true, salesOrderId: id, orderNumber });
  });

  router.patch('/sales-orders/:id', requireBranchPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const order = sqlite.prepare('SELECT * FROM branch_sales WHERE id = ?').get(id) as any;
    if (!order) {
      res.status(404).json({ error: 'Sales order not found.' });
      return;
    }
    if (order.branch_id !== branchId || order.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `sales-orders/${id}`, `branch=${order.branch_id}`);
      return;
    }

    const { paidAmountPkr, paymentStatus, deliveryStatus, salesExecName } = req.body || {};
    const now = nowIso();
    sqlite
      .prepare(`
        UPDATE branch_sales
        SET paid_amount_pkr = COALESCE(?, paid_amount_pkr),
            payment_status = COALESCE(?, payment_status),
            delivery_status = COALESCE(?, delivery_status),
            sales_exec_name = COALESCE(?, sales_exec_name),
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        paidAmountPkr !== undefined ? Number(paidAmountPkr) : null,
        paymentStatus || null,
        deliveryStatus || null,
        salesExecName || null,
        now,
        id
      );

    if (deliveryStatus === 'Delivered' && order.vehicle_id) {
      sqlite.prepare("UPDATE vehicles SET delivery_status = 'Delivered', sold_at = COALESCE(sold_at, ?) WHERE id = ?").run(now.slice(0, 10), order.vehicle_id);
      sqlite.prepare("UPDATE branch_inventory SET stock_state = 'Sold', updated_by = ?, updated_at = ? WHERE vehicle_id = ?").run(req.auth!.fullName, now, order.vehicle_id);
    }

    recordBranchAction(req, 'BRANCH_SALES_ORDER_UPDATED', 'Sales & Bookings', id, `Updated sales order ${order.order_number} (${deliveryStatus || order.delivery_status}).`);
    res.json({ success: true });
  });

  router.post('/invoices', requireBranchPermission('sales.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { customerName, itemCategory, subtotal, taxRate, paymentGateway, status, salesOrderId } = req.body || {};
    if (!customerName || !subtotal) {
      res.status(400).json({ error: 'Customer name and subtotal amount are required.' });
      return;
    }

    const sub = Number(subtotal);
    const rate = taxRate !== undefined ? Number(taxRate) : 17;
    const taxAmt = Number(((sub * rate) / 100).toFixed(2));
    const total = Number((sub + taxAmt).toFixed(2));
    const country = sqlite.prepare('SELECT currency FROM countries WHERE id = ?').get(branch.country_id) as { currency: string } | undefined;

    const invId = `inv_${generateSecureToken(6)}`;
    const invNum = `BYD-${branch.code}-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO payments_invoices (
          id, company_id, branch_id, invoice_number, customer_name, country, currency,
          dealership_name, item_category, subtotal, tax_rate, tax_amount, total_amount,
          status, payment_gateway, transaction_ref, issued_date, due_date, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)
      .run(
        invId,
        companyId,
        branchId,
        invNum,
        String(customerName).trim(),
        branch.country_id,
        country?.currency || 'PKR',
        branch.name,
        String(itemCategory || 'Vehicle Booking / Retail Sale').trim(),
        sub,
        rate,
        taxAmt,
        total,
        status && ['Paid', 'Pending Payment'].includes(status) ? status : 'Paid',
        String(paymentGateway || 'Bank Wire / Showroom POS').trim(),
        `TXN-${generateSecureToken(4).toUpperCase()}`,
        now.slice(0, 10),
        now.slice(0, 10),
        now
      );

    if (salesOrderId) {
      sqlite
        .prepare('UPDATE branch_sales SET invoice_id = ?, updated_at = ? WHERE id = ? AND branch_id = ?')
        .run(invId, now, salesOrderId, branchId);
    }

    recordBranchAction(req, 'BRANCH_INVOICE_GENERATED', 'Sales & Bookings', invId, `Generated invoice ${invNum} (${total} ${country?.currency || 'PKR'}).`);
    res.status(201).json({ success: true, invoiceId: invId, invoiceNumber: invNum, totalAmount: total });
  });

  router.get('/sales/daily-report', requireBranchPermission('sales.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const targetDate = req.query.date ? String(req.query.date).slice(0, 10) : nowIso().slice(0, 10);

    const dayBookings = sqlite
      .prepare('SELECT * FROM bookings WHERE branch_id = ? AND company_id = ? AND substr(created_at, 1, 10) = ?')
      .all(branchId, companyId, targetDate);

    const daySales = sqlite
      .prepare('SELECT * FROM branch_sales WHERE branch_id = ? AND company_id = ? AND substr(created_at, 1, 10) = ?')
      .all(branchId, companyId, targetDate) as any[];

    const dayInvoices = sqlite
      .prepare('SELECT * FROM payments_invoices WHERE branch_id = ? AND company_id = ? AND issued_date = ?')
      .all(branchId, companyId, targetDate) as any[];

    res.json({
      date: targetDate,
      bookingsCount: dayBookings.length,
      salesCount: daySales.length,
      salesAmountPkr: daySales.reduce((acc, s) => acc + Number(s.sale_amount_pkr || 0), 0),
      collectedAmountPkr: dayInvoices.filter((i) => i.status === 'Paid').reduce((acc, i) => acc + Number(i.total_amount || 0), 0),
      dayBookings,
      daySales,
      dayInvoices,
    });
  });

  // =========================================================================
  // 6. BRANCH CUSTOMER MANAGEMENT (CRM & AUDITED PII MASKING)
  // =========================================================================
  router.get('/customers', requireBranchPermission('customers.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const reveal = req.query.reveal === '1' || req.query.reveal === 'true';

    if (reveal && !req.auth!.permissions.includes('customers.pii.reveal')) {
      logSecurityEvent({
        severity: 'WARNING',
        eventType: 'BRANCH_PII_REVEAL_DENIED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId,
        details: `Branch Manager denied PII reveal on branch ${branchId}: missing "customers.pii.reveal" permission.`,
        ipAddress: getClientIp(req),
      });
      res.status(403).json({
        error: 'Forbidden: Missing "customers.pii.reveal" permission to view unmasked customer contact details.',
      });
      return;
    }

    if (reveal) {
      recordBranchAction(
        req,
        'CUSTOMER_PII_REVEALED',
        'Customer CRM',
        branchId,
        `Authorized Branch Manager revealed unmasked customer PII for branch ${branchId}.`,
        'WARNING'
      );
      logSecurityEvent({
        severity: 'INFO',
        eventType: 'BRANCH_PII_REVEALED',
        userId: req.auth!.userId,
        identifier: req.auth!.email,
        companyId,
        details: `Branch Manager ${req.auth!.email} accessed unmasked customer PII in branch ${branchId}.`,
        ipAddress: getClientIp(req),
      });
    }

    const rawCustomers = sqlite
      .prepare(`
        SELECT id, full_name, email, mobile, cnic_or_id, city, country, status, created_at
        FROM users
        WHERE branch_id = ? AND company_id = ? AND role = 'Customer'
        ORDER BY created_at DESC
      `)
      .all(branchId, companyId) as any[];

    const salesHistory = sqlite
      .prepare('SELECT id, order_number, vehicle_model, sale_amount_pkr, payment_status, delivery_status, customer_name, customer_phone, created_at FROM branch_sales WHERE branch_id = ? AND company_id = ?')
      .all(branchId, companyId) as any[];

    const customers = rawCustomers.map((c) => {
      const orders = salesHistory.filter(
        (s) => s.customer_phone === c.mobile || s.customer_name.toLowerCase() === c.full_name.toLowerCase()
      );
      return {
        id: c.id,
        fullName: c.full_name,
        email: c.email,
        mobile: reveal ? c.mobile : maskPhone(c.mobile),
        cnicOrId: reveal ? (c.cnic_or_id || 'Not Provided') : maskNationalId(c.cnic_or_id),
        city: c.city,
        country: c.country,
        status: c.status,
        piiMasked: !reveal,
        purchaseCount: orders.length,
        orders: orders.map((o) => ({
          id: o.id,
          orderNumber: o.order_number,
          vehicleModel: o.vehicle_model,
          saleAmountPkr: o.sale_amount_pkr,
          deliveryStatus: o.delivery_status,
          createdAt: o.created_at,
        })),
        createdAt: c.created_at,
      };
    });

    const crmRecords = sqlite
      .prepare('SELECT * FROM customer_crm_records WHERE branch_id = ? AND company_id = ? ORDER BY created_at DESC')
      .all(branchId, companyId)
      .map((r: any) => ({
        ...r,
        customer_phone: reveal ? r.customer_phone : maskPhone(r.customer_phone),
        piiMasked: !reveal,
      }));

    res.json({ customers, crmRecords, piiRevealed: reveal });
  });

  router.post('/customers', requireBranchPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { fullName, email, mobile, cnicOrId, password } = req.body || {};
    if (!fullName || !email || !mobile) {
      res.status(400).json({ error: 'Customer full name, email, and mobile number are required.' });
      return;
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (hasEmailConflict(cleanEmail)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const rawPass = password ? String(password) : `BydCust#${generateSecureToken(5)}!1`;
    const custId = `usr_${generateSecureToken(6)}`;
    const username = `${cleanEmail.split('@')[0].replace(/[^a-z0-9_]/gi, '_')}_${generateSecureToken(2)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO users (
          id, company_id, branch_id, full_name, username, email, mobile, password_hash,
          role, country, city, cnic_or_id, status, email_verified, two_factor_enabled,
          created_by, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Customer', ?, ?, ?, 'Active', 1, 0, ?, ?, ?)
      `)
      .run(
        custId,
        companyId,
        branchId,
        String(fullName).trim(),
        username,
        cleanEmail,
        String(mobile).trim(),
        hashPassword(rawPass),
        branch.country_id,
        branch.city,
        cnicOrId ? String(cnicOrId).trim() : null,
        req.auth!.userId,
        now,
        now
      );

    recordBranchAction(req, 'BRANCH_CUSTOMER_REGISTERED', 'Customer CRM', custId, `Registered customer ${fullName} under ${branch.name}.`);
    res.status(201).json({ success: true, customerId: custId });
  });

  router.post('/crm', requireBranchPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const { customerId, customerName, customerEmail, customerPhone, recordType, subject, details, priority, assignedTo, followUpDate } = req.body || {};
    if (!customerName || !customerPhone || !subject || !details) {
      res.status(400).json({ error: 'Customer name, phone, subject, and details are required.' });
      return;
    }

    const crmId = `crm_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO customer_crm_records (
          id, company_id, branch_id, customer_id, customer_name, customer_email, customer_phone,
          record_type, subject, details, assigned_to, priority, status, follow_up_date, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, ?)
      `)
      .run(
        crmId,
        companyId,
        branchId,
        customerId || null,
        String(customerName).trim(),
        customerEmail ? String(customerEmail).trim() : null,
        String(customerPhone).trim(),
        String(recordType || 'Enquiry').trim(),
        String(subject).trim(),
        String(details).trim(),
        assignedTo || req.auth!.fullName,
        String(priority || 'Medium').trim(),
        followUpDate || now.slice(0, 10),
        now,
        now
      );

    recordBranchAction(req, 'CRM_RECORD_CREATED', 'Customer CRM', crmId, `Logged ${recordType || 'Enquiry'}: ${subject}.`);
    res.status(201).json({ success: true, crmId });
  });

  router.patch('/crm/:id', requireBranchPermission('customers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const crm = sqlite.prepare('SELECT * FROM customer_crm_records WHERE id = ?').get(id) as any;
    if (!crm) {
      res.status(404).json({ error: 'CRM record not found.' });
      return;
    }
    if (crm.branch_id !== branchId || crm.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `crm/${id}`, `branch=${crm.branch_id}`);
      return;
    }

    const { status, priority, assignedTo, followUpDate, resolutionNotes } = req.body || {};
    sqlite
      .prepare(`
        UPDATE customer_crm_records
        SET status = COALESCE(?, status),
            priority = COALESCE(?, priority),
            assigned_to = COALESCE(?, assigned_to),
            follow_up_date = COALESCE(?, follow_up_date),
            resolution_notes = COALESCE(?, resolution_notes),
            updated_at = ?
        WHERE id = ?
      `)
      .run(status || null, priority || null, assignedTo || null, followUpDate || null, resolutionNotes || null, nowIso(), id);

    recordBranchAction(req, 'CRM_RECORD_UPDATED', 'Customer CRM', id, `Updated CRM ticket ${id} status -> ${status || crm.status}.`);
    res.json({ success: true });
  });

  // =========================================================================
  // 7. BRANCH DEALERSHIP MANAGEMENT & APPROVAL ESCALATION
  // =========================================================================
  router.get('/dealerships', requireBranchPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const dealerships = sqlite
      .prepare(`
        SELECT d.*,
               (SELECT COUNT(*) FROM vehicles v WHERE v.dealership_id = d.id) as dealer_vehicle_count,
               (SELECT COUNT(*) FROM service_jobs sj WHERE sj.dealership_id = d.id) as service_job_count
        FROM dealerships d
        WHERE d.branch_id = ? AND d.company_id = ?
        ORDER BY d.created_at DESC
      `)
      .all(branchId, companyId);

    const escalations = sqlite
      .prepare("SELECT * FROM branch_escalations WHERE branch_id = ? AND request_type = 'Dealer Approval Request' ORDER BY created_at DESC")
      .all(branchId);

    res.json({ dealerships, escalations });
  });

  router.patch('/dealerships/:id', requireBranchPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.branch_id !== branchId || dlr.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `dealerships/${id}`, `branch=${dlr.branch_id}`);
      return;
    }

    const { managerName, phone, activeTechs, serviceBays, monthlyTargetUnits, status } = req.body || {};
    if (status && status === 'Approved' && dlr.status === 'Pending Approval') {
      res.status(403).json({
        error: 'Pending dealer applications require escalation to Higher Authority via /dealerships/:id/approval-request.',
      });
      return;
    }

    sqlite
      .prepare(`
        UPDATE dealerships
        SET manager_name = COALESCE(?, manager_name),
            phone = COALESCE(?, phone),
            active_techs = COALESCE(?, active_techs),
            service_bays = COALESCE(?, service_bays),
            monthly_target_units = COALESCE(?, monthly_target_units)
        WHERE id = ?
      `)
      .run(
        managerName || null,
        phone || null,
        activeTechs !== undefined ? Number(activeTechs) : null,
        serviceBays !== undefined ? Number(serviceBays) : null,
        monthlyTargetUnits !== undefined ? Number(monthlyTargetUnits) : null,
        id
      );

    recordBranchAction(req, 'BRANCH_DEALERSHIP_UPDATED', 'Dealership Management', id, `Updated operational capacity/target for ${dlr.name}.`);
    res.json({ success: true });
  });

  router.post('/dealerships/:id/approval-request', requireBranchPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;
    const { notes } = req.body || {};

    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.branch_id !== branchId || dlr.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `dealerships/${id}/approval-request`, `branch=${dlr.branch_id}`);
      return;
    }

    const branch = getAssignedBranch(req);
    const escId = `besc_${generateSecureToken(6)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO branch_escalations (
          id, branch_id, company_id, country_id, manager_id, manager_name, request_type,
          target_id, title, details, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Dealer Approval Request', ?, ?, ?, 'Pending Higher Approval', ?, ?)
      `)
      .run(
        escId,
        branchId,
        companyId,
        branch.country_id,
        req.auth!.userId,
        req.auth!.fullName,
        id,
        `Dealer Approval Request: ${dlr.name} (${dlr.code})`,
        String(notes || `Branch Manager reviewed site readiness for ${dlr.name} and recommends higher approval.`).trim(),
        now,
        now
      );

    recordBranchAction(req, 'DEALER_APPROVAL_ESCALATED', 'Dealership Management', escId, `Submitted dealer approval escalation for ${dlr.name}.`);
    res.status(201).json({ success: true, escalationId: escId });
  });

  router.post('/dealerships/:id/communicate', requireBranchPermission('dealers.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;
    const { subject, message } = req.body || {};

    const dlr = sqlite.prepare('SELECT * FROM dealerships WHERE id = ?').get(id) as any;
    if (!dlr) {
      res.status(404).json({ error: 'Dealership not found.' });
      return;
    }
    if (dlr.branch_id !== branchId || dlr.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `dealerships/${id}/communicate`, `branch=${dlr.branch_id}`);
      return;
    }
    if (!subject || !message) {
      res.status(400).json({ error: 'Subject and message body are required.' });
      return;
    }

    const notifId = `ntf_${generateSecureToken(5)}`;
    sqlite
      .prepare(`
        INSERT INTO notifications (id, company_id, branch_id, title, message, category, is_read, created_at)
        VALUES (?, ?, ?, ?, ?, 'Dealer Dispatch', 0, ?)
      `)
      .run(notifId, companyId, branchId, `[${dlr.code}] ${String(subject).trim()}`, String(message).trim(), nowIso());

    recordBranchAction(req, 'DEALER_MESSAGE_SENT', 'Dealership Management', id, `Sent dispatch to ${dlr.name}: ${subject}.`);
    res.status(201).json({ success: true, notificationId: notifId });
  });

  // =========================================================================
  // 8. BRANCH FINANCE MANAGEMENT & REFUND ESCALATION
  // =========================================================================
  router.get('/finance', requireBranchPermission('finance.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const invoices = sqlite
      .prepare('SELECT * FROM payments_invoices WHERE branch_id = ? AND company_id = ? ORDER BY created_at DESC')
      .all(branchId, companyId) as any[];

    const expenses = sqlite
      .prepare('SELECT * FROM branch_expenses WHERE branch_id = ? AND company_id = ? ORDER BY expense_date DESC, created_at DESC')
      .all(branchId, companyId) as any[];

    const refundEscalations = sqlite
      .prepare("SELECT * FROM branch_escalations WHERE branch_id = ? AND request_type = 'Financial Refund Approval' ORDER BY created_at DESC")
      .all(branchId);

    const paidTotal = invoices.filter((i) => i.status === 'Paid').reduce((s, i) => s + Number(i.total_amount || 0), 0);
    const pendingTotal = invoices.filter((i) => i.status === 'Pending Payment').reduce((s, i) => s + Number(i.total_amount || 0), 0);
    const refundedTotal = invoices.filter((i) => i.status === 'Refunded').reduce((s, i) => s + Number(i.total_amount || 0), 0);
    const expensesTotal = expenses.reduce((s, e) => s + Number(e.amount_pkr || 0), 0);

    res.json({
      summary: {
        paidTotal,
        pendingTotal,
        refundedTotal,
        expensesTotal,
        netCashflow: paidTotal - expensesTotal - refundedTotal,
      },
      invoices,
      expenses,
      refundEscalations,
    });
  });

  router.post('/expenses', requireBranchPermission('finance.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const { category, title, amountPkr, expenseDate } = req.body || {};
    if (!category || !title || !amountPkr) {
      res.status(400).json({ error: 'Category, title, and amount are required.' });
      return;
    }

    const expId = `bexp_${generateSecureToken(6)}`;
    const now = nowIso();
    sqlite
      .prepare(`
        INSERT INTO branch_expenses (
          id, branch_id, company_id, category, title, amount_pkr, expense_date, recorded_by, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Recorded', ?)
      `)
      .run(
        expId,
        branchId,
        companyId,
        String(category).trim(),
        String(title).trim(),
        Number(amountPkr),
        String(expenseDate || now.slice(0, 10)).slice(0, 10),
        req.auth!.fullName,
        now
      );

    recordBranchAction(req, 'BRANCH_EXPENSE_RECORDED', 'Branch Finance', expId, `Recorded expense "${title}" (${amountPkr} PKR).`);
    res.status(201).json({ success: true, expenseId: expId });
  });

  router.post('/invoices/:id/refund-request', requireBranchPermission('finance.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;
    const { reason } = req.body || {};

    const inv = sqlite.prepare('SELECT * FROM payments_invoices WHERE id = ?').get(id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    if (inv.branch_id !== branchId || inv.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `invoices/${id}/refund-request`, `branch=${inv.branch_id}`);
      return;
    }

    const branch = getAssignedBranch(req);
    const escId = `besc_${generateSecureToken(6)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO branch_escalations (
          id, branch_id, company_id, country_id, manager_id, manager_name, request_type,
          target_id, title, details, amount, status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'Financial Refund Approval', ?, ?, ?, ?, 'Pending Higher Approval', ?, ?)
      `)
      .run(
        escId,
        branchId,
        companyId,
        branch.country_id,
        req.auth!.userId,
        req.auth!.fullName,
        id,
        `Refund Request: ${inv.invoice_number} (${inv.customer_name})`,
        String(reason || 'Customer requested booking/service refund').trim(),
        Number(inv.total_amount || 0),
        now,
        now
      );

    recordBranchAction(req, 'REFUND_ESCALATION_SUBMITTED', 'Branch Finance', escId, `Submitted refund approval request for ${inv.invoice_number}.`);
    res.status(201).json({ success: true, escalationId: escId });
  });

  router.patch('/invoices/:id/refund', requireBranchPermission('finance.refund.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const inv = sqlite.prepare('SELECT * FROM payments_invoices WHERE id = ?').get(id) as any;
    if (!inv) {
      res.status(404).json({ error: 'Invoice not found.' });
      return;
    }
    if (inv.branch_id !== branchId || inv.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `invoices/${id}/refund`, `branch=${inv.branch_id}`);
      return;
    }

    sqlite.prepare("UPDATE payments_invoices SET status = 'Refunded' WHERE id = ?").run(id);
    recordBranchAction(req, 'INVOICE_REFUNDED_DIRECT', 'Branch Finance', id, `Direct authorized refund executed for ${inv.invoice_number}.`, 'WARNING');
    res.json({ success: true });
  });

  // =========================================================================
  // 9. BRANCH SERVICE, WARRANTY & SPARE PARTS MANAGEMENT
  // =========================================================================
  router.get('/service-warranty', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const serviceJobs = sqlite
      .prepare('SELECT * FROM service_jobs WHERE branch_id = ? AND company_id = ? ORDER BY scheduled_date DESC, created_at DESC')
      .all(branchId, companyId)
      .map((s: any) => ({
        ...s,
        checklist: safeJsonParse(s.checklist_json, []),
        partsUsed: safeJsonParse(s.parts_used_json, []),
      }));

    const warrantyClaims = sqlite
      .prepare('SELECT * FROM warranty_claims WHERE branch_id = ? AND company_id = ? ORDER BY submission_date DESC, created_at DESC')
      .all(branchId, companyId);

    const spareParts = sqlite
      .prepare('SELECT * FROM spare_parts WHERE branch_id = ? AND company_id = ? ORDER BY name ASC')
      .all(branchId, companyId);

    res.json({ serviceJobs, warrantyClaims, spareParts });
  });

  router.post('/service-jobs', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const branch = getAssignedBranch(req);

    const { vin, model, licensePlate, customerName, customerPhone, serviceType, scheduledDate, scheduledTime, technicianAssigned, estimatedCostPkr, reminderDate, customerNotes } = req.body || {};
    if (!vin || !model || !customerName || !customerPhone || !serviceType) {
      res.status(400).json({ error: 'VIN, vehicle model, customer details, and service type are required.' });
      return;
    }

    const dealership = sqlite.prepare('SELECT id, name FROM dealerships WHERE branch_id = ? LIMIT 1').get(branchId) as { id: string; name: string } | undefined;
    const veh = sqlite.prepare('SELECT id FROM vehicles WHERE vin = ? AND branch_id = ?').get(String(vin).trim().toUpperCase(), branchId) as { id: string } | undefined;
    const jobId = `srv_${generateSecureToken(6)}`;
    const ticket = `TKT-${branch.code}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = nowIso();

    sqlite
      .prepare(`
        INSERT INTO service_jobs (
          id, company_id, branch_id, ticket_number, vehicle_id, vin, model, license_plate,
          customer_name, customer_phone, dealership_id, dealership_name, service_type,
          scheduled_date, scheduled_time, reminder_date, status, technician_assigned,
          estimated_cost_pkr, customer_notes, checklist_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Scheduled', ?, ?, ?, '[]', ?)
      `)
      .run(
        jobId,
        companyId,
        branchId,
        ticket,
        veh?.id || `ext_${generateSecureToken(4)}`,
        String(vin).trim().toUpperCase(),
        String(model).trim(),
        String(licensePlate || 'TBD').trim(),
        String(customerName).trim(),
        String(customerPhone).trim(),
        dealership?.id || branchId,
        dealership?.name || branch.name,
        String(serviceType).trim(),
        String(scheduledDate || now.slice(0, 10)),
        String(scheduledTime || '10:30 AM'),
        reminderDate || null,
        technicianAssigned || 'Branch Senior EV Tech',
        Number(estimatedCostPkr || 18500),
        customerNotes || '',
        now
      );

    recordBranchAction(req, 'SERVICE_JOB_CREATED', 'Service & Warranty', jobId, `Scheduled service ${ticket} for ${customerName} (${vin}).`);
    res.status(201).json({ success: true, serviceJobId: jobId, ticketNumber: ticket });
  });

  router.patch('/service-jobs/:id', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const job = sqlite.prepare('SELECT * FROM service_jobs WHERE id = ?').get(id) as any;
    if (!job) {
      res.status(404).json({ error: 'Service job not found.' });
      return;
    }
    if (job.branch_id !== branchId || job.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `service-jobs/${id}`, `branch=${job.branch_id}`);
      return;
    }

    const { status, technicianAssigned, technicianNotes, actualCostPkr, reminderDate } = req.body || {};
    const validStatus = status && ['Pending Approval', 'Scheduled', 'In Progress', 'Completed', 'Cancelled'].includes(status) ? status : job.status;
    const completedAt = validStatus === 'Completed' ? nowIso() : job.completed_at;

    sqlite
      .prepare(`
        UPDATE service_jobs
        SET status = ?,
            technician_assigned = COALESCE(?, technician_assigned),
            technician_notes = COALESCE(?, technician_notes),
            actual_cost_pkr = COALESCE(?, actual_cost_pkr),
            reminder_date = COALESCE(?, reminder_date),
            completed_at = ?
        WHERE id = ?
      `)
      .run(
        validStatus,
        technicianAssigned || null,
        technicianNotes || null,
        actualCostPkr !== undefined ? Number(actualCostPkr) : null,
        reminderDate || null,
        completedAt,
        id
      );

    recordBranchAction(req, 'SERVICE_JOB_UPDATED', 'Service & Warranty', id, `Updated ticket ${job.ticket_number} -> ${validStatus}.`);
    res.json({ success: true });
  });

  router.patch('/warranty-claims/:id', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const claim = sqlite.prepare('SELECT * FROM warranty_claims WHERE id = ?').get(id) as any;
    if (!claim) {
      res.status(404).json({ error: 'Warranty claim not found.' });
      return;
    }
    if (claim.branch_id !== branchId || claim.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `warranty-claims/${id}`, `branch=${claim.branch_id}`);
      return;
    }

    const { status, reviewNotes, approvedAmountPkr } = req.body || {};
    sqlite
      .prepare(`
        UPDATE warranty_claims
        SET status = COALESCE(?, status),
            review_notes = COALESCE(?, review_notes),
            approved_amount_pkr = COALESCE(?, approved_amount_pkr)
        WHERE id = ?
      `)
      .run(status || null, reviewNotes || null, approvedAmountPkr !== undefined ? Number(approvedAmountPkr) : null, id);

    recordBranchAction(req, 'WARRANTY_CLAIM_UPDATED', 'Service & Warranty', id, `Updated warranty claim ${claim.claim_number} -> ${status || claim.status}.`);
    res.json({ success: true });
  });

  router.post('/spare-parts', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;

    const { sku, name, category, compatibleModels, stockQuantity, reorderLevel, unitCostPkr, locationBin } = req.body || {};
    if (!sku || !name || !category) {
      res.status(400).json({ error: 'SKU, part name, and category are required.' });
      return;
    }

    const id = `prt_${generateSecureToken(6)}`;
    const now = nowIso();
    try {
      sqlite
        .prepare(`
          INSERT INTO spare_parts (
            id, branch_id, company_id, sku, name, category, compatible_models,
            stock_quantity, reorder_level, unit_cost_pkr, location_bin, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          id,
          branchId,
          companyId,
          String(sku).trim().toUpperCase(),
          String(name).trim(),
          String(category).trim(),
          String(compatibleModels || 'All BYD EVs').trim(),
          Number(stockQuantity || 10),
          Number(reorderLevel || 4),
          Number(unitCostPkr || 15000),
          String(locationBin || 'A-01').trim(),
          now
        );
    } catch {
      res.status(409).json({ error: `Spare part SKU ${sku} already exists in this branch.` });
      return;
    }

    recordBranchAction(req, 'SPARE_PART_ADDED', 'Service & Warranty', id, `Added spare part ${sku} (${name}).`);
    res.status(201).json({ success: true, partId: id });
  });

  router.patch('/spare-parts/:id', requireBranchPermission('service.manage'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const { id } = req.params;

    const part = sqlite.prepare('SELECT * FROM spare_parts WHERE id = ?').get(id) as any;
    if (!part) {
      res.status(404).json({ error: 'Spare part not found.' });
      return;
    }
    if (part.branch_id !== branchId || part.company_id !== companyId) {
      rejectCrossBranchAccess(req, res, `spare-parts/${id}`, `branch=${part.branch_id}`);
      return;
    }

    const { stockQuantity, reorderLevel, unitCostPkr, locationBin } = req.body || {};
    sqlite
      .prepare(`
        UPDATE spare_parts
        SET stock_quantity = COALESCE(?, stock_quantity),
            reorder_level = COALESCE(?, reorder_level),
            unit_cost_pkr = COALESCE(?, unit_cost_pkr),
            location_bin = COALESCE(?, location_bin),
            updated_at = ?
        WHERE id = ?
      `)
      .run(
        stockQuantity !== undefined ? Number(stockQuantity) : null,
        reorderLevel !== undefined ? Number(reorderLevel) : null,
        unitCostPkr !== undefined ? Number(unitCostPkr) : null,
        locationBin || null,
        nowIso(),
        id
      );

    recordBranchAction(req, 'SPARE_PART_UPDATED', 'Service & Warranty', id, `Adjusted stock for ${part.sku}.`);
    res.json({ success: true });
  });

  // =========================================================================
  // 10. BRANCH REPORTS & MULTI-SHEET EXCEL / CSV EXPORTS
  // =========================================================================
  router.get('/reports', requireBranchPermission('reports.view'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const period = String(req.query.period || 'monthly').toLowerCase();

    const branch = getAssignedBranch(req);
    const employees = sqlite.prepare('SELECT * FROM employee_accounts WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const vehicles = sqlite
      .prepare(`
        SELECT v.*, bi.stock_state FROM vehicles v
        LEFT JOIN branch_inventory bi ON bi.vehicle_id = v.id
        WHERE v.branch_id = ? AND v.company_id = ?
      `)
      .all(branchId, companyId) as any[];
    const sales = sqlite.prepare('SELECT * FROM branch_sales WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const bookings = sqlite.prepare('SELECT * FROM bookings WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const dealerships = sqlite.prepare('SELECT * FROM dealerships WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const invoices = sqlite.prepare('SELECT * FROM payments_invoices WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const expenses = sqlite.prepare('SELECT * FROM branch_expenses WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];
    const crm = sqlite.prepare('SELECT * FROM customer_crm_records WHERE branch_id = ? AND company_id = ?').all(branchId, companyId) as any[];

    const paidRevenue = invoices.filter((i) => i.status === 'Paid').reduce((s, i) => s + Number(i.total_amount || 0), 0);
    const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount_pkr || 0), 0);

    res.json({
      period,
      generatedAt: nowIso(),
      branch: { id: branch.id, code: branch.code, name: branch.name, city: branch.city },
      summary: {
        employeesTotal: employees.length,
        avgAttendanceScore: employees.length ? Number((employees.reduce((s, e) => s + Number(e.performance_score || 0), 0) / employees.length).toFixed(1)) : 0,
        vehiclesTotal: vehicles.length,
        availableVehicles: vehicles.filter((v) => v.stock_state === 'Available').length,
        reservedVehicles: vehicles.filter((v) => v.stock_state === 'Reserved').length,
        soldVehicles: vehicles.filter((v) => v.stock_state === 'Sold').length,
        salesOrdersCount: sales.length,
        salesVolumePkr: sales.reduce((s, x) => s + Number(x.sale_amount_pkr || 0), 0),
        bookingsTotal: bookings.length,
        dealershipsTotal: dealerships.length,
        openCrmCount: crm.filter((c) => c.status === 'Open' || c.status === 'In Progress').length,
        paidRevenuePkr: paidRevenue,
        totalExpensesPkr: totalExpenses,
        netContributionPkr: paidRevenue - totalExpenses,
      },
      dealershipBreakdown: dealerships.map((d) => ({
        name: d.name,
        code: d.code,
        status: d.status,
        monthlyTargetUnits: d.monthly_target_units,
        achievedUnits: d.achieved_units,
        monthlyRevenuePkr: d.monthly_revenue_pkr,
      })),
    });
  });

  router.get('/export', requireBranchPermission('reports.export'), (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;
    const companyId = req.auth!.companyId!;
    const format = String(req.query.format || 'xlsx').toLowerCase();
    const branch = getAssignedBranch(req);

    const employees = sqlite
      .prepare('SELECT employee_code, full_name, department, job_position, status, performance_score, joined_at FROM employee_accounts WHERE branch_id = ? AND company_id = ?')
      .all(branchId, companyId) as any[];
    const vehicles = sqlite
      .prepare(`
        SELECT v.vin, v.model, v.variant, v.color, v.year, v.sale_price_pkr, v.delivery_status, bi.stock_state, bi.condition_grade
        FROM vehicles v LEFT JOIN branch_inventory bi ON bi.vehicle_id = v.id
        WHERE v.branch_id = ? AND v.company_id = ?
      `)
      .all(branchId, companyId) as any[];
    const sales = sqlite
      .prepare('SELECT order_number, vehicle_model, vin, customer_name, sales_exec_name, sale_amount_pkr, paid_amount_pkr, payment_status, delivery_status, created_at FROM branch_sales WHERE branch_id = ? AND company_id = ?')
      .all(branchId, companyId) as any[];
    const finance = sqlite
      .prepare('SELECT invoice_number, item_category, total_amount, currency, status, issued_date FROM payments_invoices WHERE branch_id = ? AND company_id = ?')
      .all(branchId, companyId) as any[];

    recordBranchAction(req, 'BRANCH_REPORT_EXPORTED', 'Reports & Analytics', branchId, `Exported ${format.toUpperCase()} report for ${branch.name}.`);

    if (format === 'csv') {
      const ws = XLSX.utils.json_to_sheet(sales.length ? sales : [{ branch: branch.name, note: 'No branch sales recorded yet' }]);
      const csv = XLSX.utils.sheet_to_csv(ws);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="byd360-branch-${branch.code}-report.csv"`);
      res.send(csv);
      return;
    }

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sales.length ? sales : [{ order_number: 'N/A', branch: branch.name }]), 'Branch Sales');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(vehicles.length ? vehicles : [{ vin: 'N/A', branch: branch.name }]), 'Vehicle Inventory');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(employees.length ? employees : [{ employee_code: 'N/A', branch: branch.name }]), 'Employees');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(finance.length ? finance : [{ invoice_number: 'N/A', branch: branch.name }]), 'Finance');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="byd360-branch-${branch.code}-report.xlsx"`);
    res.send(buf);
  });

  // =========================================================================
  // 11. BRANCH AUDIT LOGS & ESCALATION HISTORY
  // =========================================================================
  router.get('/audit-logs', (req: Request, res: Response) => {
    if (!assertBranchQueryNotSpoofed(req, res)) return;
    const branchId = req.auth!.branchId!;

    const activityLogs = sqlite
      .prepare('SELECT * FROM branch_activity_logs WHERE branch_id = ? ORDER BY created_at DESC LIMIT 100')
      .all(branchId);

    const escalations = sqlite
      .prepare('SELECT * FROM branch_escalations WHERE branch_id = ? ORDER BY created_at DESC LIMIT 50')
      .all(branchId);

    res.json({ activityLogs, escalations });
  });

  return router;
}
