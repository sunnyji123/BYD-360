import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  CheckCircle2,
  AlertCircle,
  Search,
  RefreshCw,
  Shield,
  MessageSquare,
  Calendar,
  Car,
  Wrench,
  HelpCircle,
  Activity,
  XCircle,
} from 'lucide-react';
import { api } from '../../services/api';

type GovernanceScope = 'owner' | 'super-admin' | 'company-admin' | 'country-manager' | 'branch-manager';

interface Props {
  scope: GovernanceScope;
  title?: string;
}

export const AdminCustomerGovernancePanel: React.FC<Props> = ({ scope, title }) => {
  const [subTab, setSubTab] = useState<'directory' | 'inquiries' | 'bookings' | 'service' | 'support' | 'logs'>('directory');
  const [data, setData] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [searchQ, setSearchQ] = useState('');
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState('');
  const [errMsg, setErrMsg] = useState('');

  // Inline response states
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [techDrafts, setTechDrafts] = useState<Record<string, string>>({});

  const loadData = useCallback(async () => {
    setLoading(true);
    setErrMsg('');
    try {
      const [ov, logs] = await Promise.all([
        api.getAdminCustomersOverview(scope, { q: searchQ || undefined }),
        api.getAdminCustomerAuditLogs(scope),
      ]);
      setData(ov);
      setAuditLogs(logs.logs || []);
    } catch (err: any) {
      setErrMsg(err?.message || 'Unable to load customer governance workspace.');
    } finally {
      setLoading(false);
    }
  }, [scope, searchQ]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const flash = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 5000);
  };

  return (
    <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 space-y-5 text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
            Customer Governance &amp; Operations ({scope})
          </span>
          <h3 className="text-base font-bold text-white">
            {title || 'Registered Customers, Bookings, Test Drives, Service & Warranty Governance'}
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
            <input
              type="text"
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Search ID, name, email..."
              className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
            />
          </div>
          <button
            type="button"
            onClick={loadData}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-200 hover:text-white font-bold"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {data?.summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {[
            { label: 'Total Customers', val: data.summary.totalCustomers ?? 0 },
            { label: 'Verified KYC', val: data.summary.verifiedCustomers ?? 0 },
            { label: 'Pending Verify', val: data.summary.pendingVerification ?? 0 },
            { label: 'Open Bookings', val: data.summary.openBookings ?? 0 },
            { label: 'Test Drives', val: data.summary.pendingTestDrives ?? 0 },
            { label: 'Warranty Claims', val: data.summary.openWarrantyClaims ?? 0 },
          ].map((m) => (
            <div key={m.label} className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[10px] text-slate-400">{m.label}</div>
              <div className="text-base font-black font-mono tabular-nums text-white mt-0.5">{m.val}</div>
            </div>
          ))}
        </div>
      )}

      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-1.5">
        {[
          { id: 'directory', label: `Customers (${data?.customers?.length || 0})`, icon: Users },
          { id: 'inquiries', label: `Inquiries & Test Drives (${(data?.inquiries?.length || 0) + (data?.testDrives?.length || 0)})`, icon: Calendar },
          { id: 'bookings', label: `Bookings & Payments (${data?.bookings?.length || 0})`, icon: Car },
          { id: 'service', label: `Service & Warranty (${(data?.serviceRequests?.length || 0) + (data?.warrantyClaims?.length || 0)})`, icon: Wrench },
          { id: 'support', label: `Support Tickets (${data?.supportTickets?.length || 0})`, icon: HelpCircle },
          { id: 'logs', label: `Audit Logs (${auditLogs.length})`, icon: Activity },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold border ${
                subTab === t.id
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {errMsg && (
        <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errMsg}</span>
        </div>
      )}

      {notice && (
        <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* SUBTAB 1: DIRECTORY */}
      {subTab === 'directory' && (
        <div className="space-y-4">
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Customer ID</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3">Location</th>
                  <th className="py-2.5 px-3">Verification</th>
                  <th className="py-2.5 px-3">Account</th>
                  <th className="py-2.5 px-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {(data?.customers || []).map((c: any) => (
                  <tr key={c.id} className="hover:bg-slate-950/60">
                    <td className="py-2.5 px-3 font-mono text-emerald-300 font-bold">{c.customer_code}</td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-white">{c.full_name}</div>
                      <div className="text-[11px] font-mono text-slate-400">{c.email} • {c.mobile}</div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{c.city}, {c.country}</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded font-bold ${c.verification_status === 'Verified' ? 'bg-cyan-950 text-cyan-300' : 'bg-amber-950 text-amber-300'}`}>
                        {c.verification_status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded font-bold ${c.status === 'Active' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={async () => {
                            const detail = await api.getAdminCustomerDetail(scope, c.id);
                            setSelectedCustomer(detail);
                          }}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white font-bold"
                        >
                          Inspect
                        </button>
                        {c.verification_status !== 'Verified' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await api.verifyAdminCustomer(scope, c.id);
                              flash(`Verified ${c.customer_code}.`);
                              await loadData();
                            }}
                            className="px-2 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold"
                          >
                            Verify
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={async () => {
                            const next = c.status === 'Suspended' ? 'Active' : 'Suspended';
                            await api.updateAdminCustomerStatus(scope, c.id, next, `Admin ${scope} action`);
                            flash(`Customer ${c.customer_code} updated to ${next}.`);
                            await loadData();
                          }}
                          className={`px-2 py-1 rounded font-bold border ${
                            c.status === 'Suspended'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40'
                              : 'bg-rose-950 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {c.status === 'Suspended' ? 'Reactivate' : 'Suspend'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedCustomer && (
            <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-bold text-white">
                  {selectedCustomer.customer?.full_name} ({selectedCustomer.customer?.customer_code})
                </div>
                <button type="button" onClick={() => setSelectedCustomer(null)} className="text-slate-400 hover:text-white">
                  <XCircle className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] text-slate-300">
                <div>Vehicles: {selectedCustomer.vehicles?.length || 0}</div>
                <div>Bookings: {selectedCustomer.bookings?.length || 0}</div>
                <div>Invoices: {selectedCustomer.invoices?.length || 0} • Docs: {selectedCustomer.documents?.length || 0}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 2: INQUIRIES & TEST DRIVES */}
      {subTab === 'inquiries' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Customer Inquiries ({data?.inquiries?.length || 0})</span>
            </h4>
            {(data?.inquiries || []).map((inq: any) => (
              <div key={inq.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-emerald-300 font-mono">{inq.inquiry_ref} • {inq.vehicle_model}</span>
                  <span className="text-amber-300">{inq.status}</span>
                </div>
                <div className="text-white font-semibold">{inq.subject}</div>
                <div className="text-slate-400">{inq.message}</div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Official showroom reply..."
                    value={replyDrafts[inq.id] || ''}
                    onChange={(e) => setReplyDrafts({ ...replyDrafts, [inq.id]: e.target.value })}
                    className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-white"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateAdminCustomerInquiry(scope, inq.id, {
                        status: 'Replied',
                        replyText: replyDrafts[inq.id] || 'Showroom advisor responded.',
                      });
                      flash(`Replied to ${inq.inquiry_ref}.`);
                      await loadData();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-black"
                  >
                    Reply
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span>Test Drive Requests ({data?.testDrives?.length || 0})</span>
            </h4>
            {(data?.testDrives || []).map((td: any) => (
              <div key={td.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="text-cyan-300 font-mono">{td.request_number} • {td.vehicle_model}</span>
                  <span className="text-amber-300">{td.status}</span>
                </div>
                <div className="text-slate-300">{td.customer_name} • {td.preferred_date} @ {td.preferred_time} ({td.city})</div>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateAdminCustomerTestDrive(scope, td.id, { status: 'Confirmed' });
                      flash(`Confirmed test drive ${td.request_number}.`);
                      await loadData();
                    }}
                    className="px-2.5 py-1 rounded bg-emerald-600 text-white font-bold"
                  >
                    Confirm Slot
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateAdminCustomerTestDrive(scope, td.id, { status: 'Completed' });
                      flash(`Marked ${td.request_number} Completed.`);
                      await loadData();
                    }}
                    className="px-2.5 py-1 rounded bg-cyan-600 text-white font-bold"
                  >
                    Complete
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateAdminCustomerTestDrive(scope, td.id, { status: 'Declined' });
                      flash(`Declined ${td.request_number}.`);
                      await loadData();
                    }}
                    className="px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-500/40 font-bold"
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: BOOKINGS & PAYMENTS */}
      {subTab === 'bookings' && (
        <div className="space-y-3">
          {(data?.bookings || []).map((b: any) => (
            <div key={b.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="font-bold text-white">
                  <span className="font-mono text-emerald-300 mr-2">{b.booking_ref}</span>
                  {b.customer_name} — {b.vehicle_model} ({b.variant})
                </div>
                <div className="text-slate-400 font-mono">
                  Status: {b.booking_status} • Payment: {b.payment_status} • Delivery: {b.delivery_status}
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={async () => {
                    await api.updateAdminCustomerBooking(scope, b.id, {
                      bookingStatus: 'Approved',
                      paymentStatus: 'Verified',
                      deliveryStatus: 'Vehicle Allocated',
                      paymentMethod: 'Bank Transfer (Admin Verified)',
                    });
                    flash(`Approved booking ${b.booking_ref} & verified payment.`);
                    await loadData();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-black"
                >
                  Approve &amp; Verify Payment
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await api.updateAdminCustomerBooking(scope, b.id, {
                      bookingStatus: 'Delivered',
                      deliveryStatus: 'Delivered',
                    });
                    flash(`Marked ${b.booking_ref} Delivered (vehicle & warranty auto-registered).`);
                    await loadData();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-cyan-600 text-white font-bold"
                >
                  Mark Delivered
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await api.updateAdminCustomerBooking(scope, b.id, {
                      bookingStatus: 'Rejected',
                      deliveryStatus: 'Cancelled',
                    });
                    flash(`Rejected booking ${b.booking_ref}.`);
                    await loadData();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-500/40 font-bold"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 4: SERVICE & WARRANTY */}
      {subTab === 'service' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-bold text-white">Customer Service Requests ({data?.serviceRequests?.length || 0})</h4>
            {(data?.serviceRequests || []).map((sr: any) => (
              <div key={sr.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="font-mono text-cyan-300">{sr.request_number} • {sr.service_type}</span>
                  <span className="text-amber-300">{sr.status}</span>
                </div>
                <div className="text-slate-300">{sr.customer_name} • {sr.preferred_date} @ {sr.preferred_time}</div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Technician Name"
                    value={techDrafts[sr.id] ?? (sr.technician_assigned || '')}
                    onChange={(e) => setTechDrafts({ ...techDrafts, [sr.id]: e.target.value })}
                    className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1 text-white"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      await api.updateAdminCustomerService(scope, sr.id, {
                        status: 'Completed',
                        technicianAssigned: techDrafts[sr.id] || 'Senior EV Specialist',
                      });
                      flash(`Completed service ${sr.request_number}.`);
                      await loadData();
                    }}
                    className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-black"
                  >
                    Mark Completed
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>Customer Warranty Claims ({data?.warrantyClaims?.length || 0})</span>
            </h4>
            {(data?.warrantyClaims || []).map((wc: any) => (
              <div key={wc.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex justify-between font-bold">
                  <span className="font-mono text-amber-300">{wc.claim_number} • {wc.component_category}</span>
                  <span className="text-cyan-300">{wc.status}</span>
                </div>
                <div className="text-slate-300">{wc.customer_name} • {wc.issue_description}</div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      await api.reviewAdminCustomerWarrantyClaim(scope, wc.id, {
                        status: 'Approved',
                        reviewNotes: 'Approved under BYD factory EV warranty policy.',
                      });
                      flash(`Approved warranty claim ${wc.claim_number}.`);
                      await loadData();
                    }}
                    className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 font-black"
                  >
                    Approve Claim
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await api.reviewAdminCustomerWarrantyClaim(scope, wc.id, {
                        status: 'Rejected',
                        reviewNotes: 'Outside warranty terms.',
                      });
                      flash(`Rejected warranty claim ${wc.claim_number}.`);
                      await loadData();
                    }}
                    className="px-3 py-1 rounded-lg bg-rose-950 text-rose-300 border border-rose-500/40 font-bold"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 5: SUPPORT TICKETS */}
      {subTab === 'support' && (
        <div className="space-y-3">
          {(data?.supportTickets || []).map((t: any) => (
            <div key={t.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex justify-between font-bold">
                <span className="font-mono text-cyan-300">{t.ticket_number} • {t.category}</span>
                <span className="text-amber-300">{t.status}</span>
              </div>
              <div className="text-white font-semibold">{t.subject} — {t.customer_name}</div>
              <div className="text-slate-400">{t.description}</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Write customer support reply..."
                  value={replyDrafts[t.id] || ''}
                  onChange={(e) => setReplyDrafts({ ...replyDrafts, [t.id]: e.target.value })}
                  className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    await api.replyAdminCustomerSupportTicket(scope, t.id, {
                      status: 'Resolved',
                      replyText: replyDrafts[t.id] || 'Resolved by customer care desk.',
                    });
                    flash(`Resolved ticket ${t.ticket_number}.`);
                    await loadData();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-black"
                >
                  Reply &amp; Resolve
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBTAB 6: AUDIT LOGS */}
      {subTab === 'logs' && (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {auditLogs.map((l: any) => (
            <div key={l.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 font-mono text-[11px]">
              <div>
                <span className="text-emerald-300 font-bold">{l.action}</span>
                <span className="text-slate-400 ml-2 font-sans">{l.details}</span>
              </div>
              <span className="text-slate-500 shrink-0">{l.created_at?.slice(0, 19).replace('T', ' ')}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
